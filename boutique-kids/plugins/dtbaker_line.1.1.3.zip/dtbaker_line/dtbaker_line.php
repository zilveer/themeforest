<?php 

/** 
 * Plugin Name: dtbaker Line 
 * Description: Insert a decorated line into pages and posts. 
 * Plugin URI: http://dtbaker.net 
 * Version: 1.1.3 
 * Author: dtbaker 
 * Author URI: http://dtbaker.net 
 * Text Domain: dtbaker_line 
 */ 


/**
 * Class dtbaker_Shortcode_Line
 * handles the creation of [dtbaker_line] shortcode
 * adds a button in MCE editor allowing easy creation of shortcode
 * creates a wordpress view representing this shortcode in the editor
 * edit/delete button on wp view as well makes for easy shortcode managements.
 * Author: dtbaker@gmail.com
 * Copyright 2014
 *
 * Version 1.2 - 2015-05-24 - added WordPress 4.2.2 support
 */

class dtbaker_Shortcode_Line {
    private static $instance = null;
    public static function get_instance() {
        if ( ! self::$instance )
            self::$instance = new self;
        return self::$instance;
    }

	public function init(){
		add_action( 'admin_init', array( $this, 'init_plugin' ), 20 );
        add_shortcode('dtbaker_line', array($this,'shortcode_output'));
	}
    public function init_plugin() {
        add_action( 'print_media_templates', array( $this, 'print_media_templates' ) );
        add_action( 'admin_print_footer_scripts', array( $this, 'admin_print_footer_scripts' ), 100 );
	    add_action( 'admin_enqueue_scripts', array( $this, 'admin_css' ) );
	    add_action( 'wp_ajax_dtbaker_plugin_buttons', array( $this, 'wp_ajax_dtbaker_plugin_buttons' ) );
	    add_action( 'dtbaker_plugin_button_code', array( $this, 'dtbaker_plugin_button_code' ) );
	    if ( current_user_can('edit_posts') || current_user_can('edit_pages') ){
		    add_filter("mce_external_plugins", array($this, 'mce_plugin'));
		    add_filter("mce_buttons", array($this, 'mce_button'));
	    }
    }

	public function admin_css(){
		$translation_array = array(
			'layouts' => $this->get_line_layouts()
		);
		wp_localize_script( 'jquery', 'dtbaker_line', $translation_array );

	}

	public function get_line_layouts(){
		$options      = array();
		$options[] = array('text'=>'Heart','value'=>'heart');
		$options[] = array('text'=>'Flower','value'=>'flower');
		$options[] = array('text'=>'Leaf','value'=>'leaf');
		$options[] = array('text'=>'Dash','value'=>'dash');
		$options[] = array('text'=>'Arrow','value'=>'arrow');
		$options[] = array('text'=>'Bordered Rectangle','value'=>'rectangle');
		$options = apply_filters('dtbaker_line_layouts',$options);
		return $options;
	}
	// front end shortcode displaying:
	public function shortcode_output($atts=array(), $innercontent='', $code='') {
	    extract(shortcode_atts(array(
	        'type' => 'heart',
	    ), $atts));
		if($type == 'rectangle'){
			return '<div class="dtbaker_line_'.$type.'"><div>'.$innercontent.'</div></div>';
		}else{
			return '<div class="dtbaker_line_'.$type.'">'.$innercontent.'</div>';
		}
	}
	public function wp_ajax_dtbaker_plugin_buttons() {
		if ( isset( $GLOBALS['dtbaker_done_plugin_buttons'] ) ) {
			die();
		}
		$GLOBALS['dtbaker_done_plugin_buttons'] = true;
		header( "Content-type: text/javascript" );
		do_action( 'dtbaker_plugin_button_code' );
	}
	public function dtbaker_plugin_button_code(){
		include_once __DIR__.'/js/dtbaker_line_button.js';
	}
	public function mce_plugin($plugin_array){
		$plugin_array['dtbaker_plugin_buttons'] = admin_url('admin-ajax.php?action=dtbaker_plugin_buttons');
		return $plugin_array;
	}
	public function mce_button($buttons){
        array_push($buttons, 'dtbaker_plugin_buttons_insert');
		return $buttons;
	}
    /**
     * Outputs the view template with the custom setting.
     */
    public function print_media_templates() {
        if ( ! isset( get_current_screen()->id ) || get_current_screen()->base != 'post' )
            return;
        ?>
        <script type="text/html" id="tmpl-editor-line-heart">
	        <# if ( data.type == "rectangle" ) { #>
				<div class="dtbaker_line_{{ data.type }}"><div>{{ data.innercontent }}</div></div>
			<# }else{ #>
				<div class="dtbaker_line_{{ data.type }}">{{ data.innercontent }}</div>
			<# } #>
		</script>
        <?php
    }
    public function admin_print_footer_scripts() {
        if ( ! isset( get_current_screen()->id ) || get_current_screen()->base != 'post' )
            return;
        ?>
	    <script type="text/javascript">
		    (function($){
			    var media = wp.media, shortcode_string = 'dtbaker_line';
			    wp.mce = wp.mce || {};
			    wp.mce.dtbaker_line = {
				    // wordpress 4.2.2 stuff:
				    template: media.template( 'editor-line-heart' ),
				    getContent: function() {
						var options = this.shortcode.attrs.named;
						options['innercontent'] = this.shortcode.content; //.replace(/<br \/>\n/g, "\n").replace(/\n/g, '<br />');
						return this.template(options);
					},
				    // pre WordPRess 4.2.2 stuff:
					View: {
						template: this.template, //media.template( 'editor-line-heart' ),
						postID: $('#post_ID').val(),
						initialize: function( options ) {
							this.shortcode = options.shortcode;
						},
						getHtml: this.getContent
					},
				    edit: function( data, update ) {
						var shortcode_data = wp.shortcode.next(shortcode_string, data);
					    var values = shortcode_data.shortcode.attrs.named;
						values['innercontent'] = shortcode_data.shortcode.content;//.replace(/<br \/>/g, '');
					    wp.mce.dtbaker_line.popupwindow(tinyMCE.activeEditor, values);
					},
				    edit_old: function( node ) {
					    var data = window.decodeURIComponent( $( node ).attr('data-wpview-text') );
					    var shortcode_data = wp.shortcode.next(shortcode_string, data);
					    var values = shortcode_data.shortcode.attrs.named;
						values['innercontent'] = shortcode_data.shortcode.content;
					    wp.mce.dtbaker_line.popupwindow(tinyMCE.activeEditor, values);
					},
				    // this is called from our tinymce plugin, also can call from our "edit" function above
				    // wp.mce.dtbaker_line.popupwindow(tinyMCE.activeEditor, "bird");
				    popupwindow: function(editor, values, onsubmit_callback){
					    if(!values)values={};
					    if(typeof onsubmit_callback != 'function'){
						    onsubmit_callback = function( e ) {
		                        // Insert content when the window form is submitted (this also replaces during edit, handy!)
							    var s = '[' + shortcode_string;
							    for(var i in e.data){
								    if(e.data.hasOwnProperty(i) && i != 'innercontent'){
									    s += ' ' + i + '="' + e.data[i] + '"';
								    }
							    }
							    s += ']';
							    if(typeof e.data.innercontent != 'undefined'){
								    s += e.data.innercontent;
								    s += '[/' + shortcode_string + ']';
							    }
		                        editor.insertContent( s );
		                    };
					    }
		                editor.windowManager.open( {
		                    title: 'Line',
		                    body: [{
		                        type: 'listbox',
		                        name: 'type',
		                        label: 'Line Type',
			                    value: values['type'],
								values: dtbaker_line.layouts
		                    },{
		                        type: 'textbox',
		                        name: 'innercontent',
		                        label: 'Rectangle Text',
			                    value: values['innercontent']
		                    }],
		                    onsubmit: onsubmit_callback
		                } );
				    }
				};
			    wp.mce.views.register( 'dtbaker_line', wp.mce.dtbaker_line );
			}(jQuery));
	    </script>

        <?php
    }
}

dtbaker_Shortcode_Line::get_instance()->init();
