<div id="shortcodelic_video_generator" class="shortcodelic_meta shortcodelicadd_meta shortcodelic_editelement_panel" data-title="<?php _e('Video', 'shortcodelicadd'); ?>">
    <div class="alignleft shortcodelic_options_area">


        <h3><?php _e('MP4 file', 'shortcodelicadd'); ?>:</h3>
        <div class="pix_upload upload_video">
            <input type="text" data-name="mp4">
            <a class="pix_button" href="#"><?php _e('Insert a video','shortcodelicadd'); ?></a>
        </div>

        <h3><?php _e('OGG file', 'shortcodelicadd'); ?>:</h3>
        <div class="pix_upload upload_video">
            <input type="text" data-name="ogg">
            <a class="pix_button" href="#"><?php _e('Insert a video','shortcodelicadd'); ?></a>
        </div>

        <h3><?php _e('WEBM file', 'shortcodelicadd'); ?>:</h3>
        <div class="pix_upload upload_video">
            <input type="text" data-name="webm">
            <a class="pix_button" href="#"><?php _e('Insert a video','geode'); ?></a>
        </div>

        <h3><?php _e('Autoplay', 'shortcodelicadd'); ?>:</h3>
        <label class="for_select marginhack">
            <span class="for_select">
		        <select data-name="autoplay">
		        	<option value="false">false</option>
		        	<option value="true">true</option>
		        </select>
            </span>
        </label>

        <h3><?php _e('Loop', 'shortcodelicadd'); ?>:</h3>
        <label class="for_select marginhack">
            <span class="for_select">
		        <select data-name="loop">
		        	<option value="false">false</option>
		        	<option value="true">true</option>
		        </select>
            </span>
        </label>

        <h3><?php _e('Fullsize', 'shortcodelicadd'); ?>:</h3>
        <label class="for_select marginhack">
            <span class="for_select">
		        <select data-name="fullsize">
		        	<option value="false">false</option>
		        	<option value="true">true</option>
		        </select>
            </span>
        </label>

        <h3><?php _e('Start volume at', 'shortcodelic'); ?>:</h3>
        <div class="slider_div opacity">
            <input type="text" data-name="volume" value="14">
            <div class="slider_cursor"></div>
        </div><!-- .slider_div -->

        <div class="clear"></div>

    </div>

</div><!-- #shortcodelic_video_generator -->