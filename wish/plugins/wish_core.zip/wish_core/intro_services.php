<?php  /*IJAZ AHMAD*/
// Plain Hero, no images and stuff
class Wish_Services_Intro{

        var $shortcode = 'wish_services_intro';
        var $title = "Services Intro";
        var $details = "Intro section with title and details";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link"  => "http://i.imgur.com/FkfFu3I.png",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'wish'),
            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor
            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
            "params" => array(

                            array(
                                    "type" => "textfield",
                                    "heading" => __("Title", "wish"),
                                    "param_name" => "title",
                                    "admin_label" => true,
                                    "description" => __("The Title.", "wish"),
                                    "value" => __("Branding", 'wish'),
                                    "admin_label" => true,
                            ),


                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __( "Title Text Font", "wish" ),
                                "param_name" => "title_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Title Font Size", "wish"),
                                "param_name" => "title_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("30", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Title color", "wish" ),
                                "param_name" => "title_color",
                                "value" => '#df4322', //Default Red color
                                "description" => __( "Choose Title color", "wish" ),
                                "group"       => "Fonts & Colors",
                            ), 

                            


                            array(
                                "type" => "textfield",
                                "heading" => __("Big Heading", "wish"),
                                "param_name" => "big_title",
                                "description" => __("", "wish"),
                                "value" => __("we are strategists designers.", 'wish'),
                                "admin_label" => false,
                            ),

                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __( "Big Title Text Font", "wish" ),
                                "param_name" => "big_title_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Big Title Font Size", "wish"),
                                "param_name" => "big_title_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("70", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Big Heading color", "wish" ),
                                "param_name" => "big_title_color",
                                "value" => '#000', //Default Red color
                                "description" => __( "Choose Title color", "wish" ),
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "textarea",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Details", 'wish'),
                                "param_name" => "details",
                                "value" => __("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's. Standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.", 'wish'),
                                "description" => __("Details", 'wish'),
                                "admin_label" => false,
                            ),

                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __( "Details Text Font", "wish" ),
                                "param_name" => "details_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Details Font Size", "wish"),
                                "param_name" => "details_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("14", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Details Font Color", "wish" ),
                                "param_name" => "details_color",
                                "value" => '#000', //Default Red color
                                "description" => __( "Choose Regular font color", "wish" ),
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "attach_image",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Image", 'wish'),
                                "param_name" => "image",
                                "description" => __("Image below the details.", 'wish'),
                                "admin_label" => false,
                            ),

                    )

        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'                 => 'Branding',
        'title_font'            => '',
        'title_size'            => '30',
        'title_color'           => '#df4322',

        'big_title'             => 'we are strategists designers.',
        'big_title_font'        => '',
        'big_title_size'        => '70',
        'big_title_color'       => '#000',
  
        'details'               => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's. Standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.",
        'details_font'          => '',
        'details_size'          => '14',
        'details_color'    => '#000',
        'image'                 => 'Image',
      ), $atts ) );


      $img = wp_get_attachment_image_src( $image, array(1140,930) );

      if($image == "Image"){
        $imgsrc = plugins_url('images/02-1.jpg', __FILE__);
        $img[0] = $imgsrc;
      }


        /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        /*Big Title*/
        $decode_font = urldecode($big_title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $big_title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";


        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

      $output = "
            <div class='row services-02-intro'>
                <div class='col-lg-8 col-lg-offset-2'>
                    <h3 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h3>
                    <h1 class='animated' data-animation='fadeInUp' data-animation-delay='300' style='font-family:{$big_title_font_family};font-size:{$big_title_size}px;color:{$big_title_color}'>{$big_title}</h1>
                    <div class='description animated' data-animation='fadeInUp' data-animation-delay='500' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}</div>
                </div>
                <div class='col-lg-12'>
                    <div class='picture animated' data-animation='fadeInUp' data-animation-delay='700'><img src='{$img[0]}' class='img-responsive center-block' alt=''></div>
                </div>
            </div>";
      return $output;
    }


    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }



}//end of class
?>