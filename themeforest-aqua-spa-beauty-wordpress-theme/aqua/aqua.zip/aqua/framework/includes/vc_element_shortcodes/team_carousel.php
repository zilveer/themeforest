<?php
vc_map ( array (
		"name" => 'Team Carousel',
		"base" => "tb_team_carousel",
		"icon" => "tb-icon-for-vc",
		"category" => __ ( 'Aqua', 'jwsthemes' ), 
		'admin_enqueue_js' => array(URI_PATH_FR.'/admin/assets/js/customvc.js'),
		"params" => array (
					array (
							"type" => "tb_taxonomy",
							"taxonomy" => "team_category",
							"heading" => __ ( "Categories", 'jwsthemes' ),
							"param_name" => "category",
							"description" => __ ( "Note: By default, all your projects will be displayed. <br>If you want to narrow output, select category(s) above. Only selected categories will be displayed.", 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"class" => "",
							"heading" => __ ( "Template", 'jwsthemes' ),
							"param_name" => "tpl",
							"value" => array (
								"Default" => "default",
								"Improved" => "improved",
								"Sky Carousel" => "sky",
								"Normal" => "normal",
							),
							"description" => __ ( "", 'jwsthemes' )
					),
					array (
							"type" => "checkbox",
							"heading" => __ ( 'Crop image', 'jwsthemes' ),
							"param_name" => "crop_image",
							"value" => array (
									__ ( "Yes, please", 'jwsthemes' ) => true
							),
							"description" => __ ( 'Crop or not crop image on your Post.', 'jwsthemes' )
					),
					array (
							"type" => "textfield",
							"heading" => __ ( 'Width image', 'jwsthemes' ),
							"param_name" => "width_image",
							"description" => __ ( 'Enter the width of image. Default: 300.', 'jwsthemes' )
					),
					array (
							"type" => "textfield",
							"heading" => __ ( 'Height image', 'jwsthemes' ),
							"param_name" => "height_image",
							"description" => __ ( 'Enter the height of image. Default: 200.', 'jwsthemes' )
					),
					/*Start Owl Option*/
					array (
							"type" => "textfield",
							"heading" => __ ( 'Items', 'jwsthemes' ),
							"param_name" => "items",
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default")
							),
							"description" => __ ( 'This variable allows you to set the maximum amount of items displayed at a time with the widest browser width.', 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"heading" => __ ( 'Single Item', 'jwsthemes' ),
							"param_name" => "singleitem",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "Yes, please", 'jwsthemes' ) => "true",
									__( "No", 'jwsthemes' ) => "false"
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default")
							),
							"description" => __ ( 'Display only one item.', 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"class" => "",
							"heading" => __ ( "Items Scale Up", 'jwsthemes' ),
							"param_name" => "itemsscaleup",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "Yes, please", 'jwsthemes' ) => "true",
									__( "No", 'jwsthemes' ) => "false"
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default","improved")
							),
							"description" => __ ( "Option to not stretch items when it is less than the supplied items", 'jwsthemes' )
					),
					array (
							"type" => "textfield",
							"heading" => __ ( 'Slide Speed', 'jwsthemes' ),
							"param_name" => "slidespeed",
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default","improved")
							),
							"description" => __ ( 'Slide speed in milliseconds', 'jwsthemes' )
					),
					array (
							"type" => "textfield",
							"heading" => __ ( 'Pagination Speed', 'jwsthemes' ),
							"param_name" => "paginationspeed",
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default","improved")
							),
							"description" => __ ( 'Pagination speed in milliseconds', 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"heading" => __ ( 'Auto Play', 'jwsthemes' ),
							"param_name" => "autoplay",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "Yes, please", 'jwsthemes' ) => "true",
									__( "No", 'jwsthemes' ) => "false"
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default","improved")
							),
							"description" => __ ( 'If you set autoPlay: true default speed will be 5 seconds.', 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"heading" => __ ( 'Stop OnHover', 'jwsthemes' ),
							"param_name" => "stoponhover",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "Yes, please", 'jwsthemes' ) => "true",
									__( "No", 'jwsthemes' ) => "false"
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default","improved")
							),
							"description" => __ ( 'Stop autoplay on mouse hover.', 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"heading" => __ ( 'Navigation', 'jwsthemes' ),
							"param_name" => "navigation",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "Yes, please", 'jwsthemes' ) => "true",
									__( "No", 'jwsthemes' ) => "false"
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default","improved")
							),
							"description" => __ ( "Display 'next' and 'prev' buttons", 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"heading" => __ ( 'Scroll Per Page', 'jwsthemes' ),
							"param_name" => "scrollperpage",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "Yes, please", 'jwsthemes' ) => "true",
									__( "No", 'jwsthemes' ) => "false"
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default")
							),
							"description" => __ ( "Scroll per page not per item. This affect next/prev buttons and mouse/touch dragging", 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"class" => "",
							"heading" => __ ( "Pagination", 'jwsthemes' ),
							"param_name" => "pagination",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "Yes, please", 'jwsthemes' ) => "true",
									__( "No", 'jwsthemes' ) => "false"
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default")
							),
							"description" => __ ( "Show pagination", 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"heading" => __ ( 'Pagination Numbers', 'jwsthemes' ),
							"param_name" => "paginationnumbers",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "Yes, please", 'jwsthemes' ) => "true",
									__( "No", 'jwsthemes' ) => "false"
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default")
							),
							"description" => __ ( "Show numbers inside pagination buttons", 'jwsthemes' )
					),
					/*End Owl Option*/
					/*Start Sky Option*/					
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Height", 'jwsthemes' ),
							"param_name" => "height",
							"value" => "450px",
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "Height of carousel", 'jwsthemes' )
					),
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Item width", 'jwsthemes' ),
							"param_name" => "itemwidth",
							"value" => "260",
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "The width of the carousel item images.", 'jwsthemes' )
					),					
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Item height", 'jwsthemes' ),
							"param_name" => "itemheight",
							"value" => "260",
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "The height of the carousel item images.", 'jwsthemes' )
					),					
					array (
							"type" => "dropdown",
							"class" => "",
							"heading" => __ ( "Gradient overlay visible", 'jwsthemes' ),
							"param_name" => "gradientoverlayvisible",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "Yes, please", 'jwsthemes' ) => 1,
									__( "No", 'jwsthemes' ) => 0
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "Indicates whether the gradient overlays will be visible.", 'jwsthemes' )
					),					
					array (
							"type" => "colorpicker",
							"class" => "",
							"heading" => __ ( "Gradient overlay color", 'jwsthemes' ),
							"param_name" => "gradientoverlaycolor",
							"value" => "#FFFFFF",
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "The color of the gradient overlays", 'jwsthemes' )
					),					
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Gradient overlay size", 'jwsthemes' ),
							"param_name" => "gradientoverlaysize",
							"value" => "215",
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "The width of the gradient overlays.", 'jwsthemes' )
					),				
					array (
							"type" => "dropdown",
							"class" => "",
							"heading" => __ ( "Auto slideshow", 'jwsthemes' ),
							"param_name" => "autoslideshow",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "Yes, please", 'jwsthemes' ) => 1,
									__( "No", 'jwsthemes' ) => 0
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "Indicates whether to display the items in auto slideshow mode", 'jwsthemes' )
					),				
					array (
							"type" => "dropdown",
							"class" => "",
							"heading" => __ ( "Enable Mouse Wheel", 'jwsthemes' ),
							"param_name" => "enablemousewheel",
							"value" => array (
									__( "No", 'jwsthemes' ) => "false",
									__( "Yes, please", 'jwsthemes' ) => "true",
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "If it's set to Yes, you can use the mouse wheel to switch between the carousel items.Default: false.", 'jwsthemes' )
					),					
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Distance", 'jwsthemes' ),
							"param_name" => "distance",
							"value" => 15,
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "The distance between the carousel items.", 'jwsthemes' )
					),					
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Selected item distance", 'jwsthemes' ),
							"param_name" => "selecteditemdistance",
							"value" => 50,
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "The distance between the currently selected item and other items.", 'jwsthemes' )
					),						
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Start index", 'jwsthemes' ),
							"param_name" => "startindex",
							"value" => 'auto',
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "The index of the carousel item to show at start-up. Use 0 for the first item and 'auto' for the middle.", 'jwsthemes' )
					),							
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Selected item zoom factor", 'jwsthemes' ),
							"param_name" => "selecteditemzoomfactor",
							"value" => 1.0,
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "The scale factor for the currently selected item. It should be equal to or less than 1.0.", 'jwsthemes' )
					),							
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Unselected item zoom factor", 'jwsthemes' ),
							"param_name" => "unselecteditemzoomfactor",
							"value" => 0.6,
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "The scale factor for the unselected items. It should be equal to or less than 1.0.", 'jwsthemes' )
					),								
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Unselected item alpha", 'jwsthemes' ),
							"param_name" => "unselecteditemalpha",
							"value" => 0.6,
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "The opacity of the unselected carousel items.", 'jwsthemes' )
					),									
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Top margin", 'jwsthemes' ),
							"param_name" => "topmargin",
							"value" => 30,
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "The distance between the top of the plugin and the currently selected item.", 'jwsthemes' )
					),									
					array (
							"type" => "textfield",
							"class" => "",
							"heading" => __ ( "Slide speed", 'jwsthemes' ),
							"param_name" => "slidespeed",
							"value" => 0.45,
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("sky")
							),
							"description" => __ ( "Indicates whether a carousel item can be selected with a single click.", 'jwsthemes' )
					),	
					/*End Sky Option*/
					array (
							"type" => "dropdown",
							"class" => "",
							"heading" => __ ( "Rows", 'jwsthemes' ),
							"param_name" => "rows",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "1 rows", 'jwsthemes' ) => "1",
									__( "2 rows", 'jwsthemes' ) => "2",
									__( "3 rows", 'jwsthemes' ) => "3",
									__( "4 rows", 'jwsthemes' ) => "4"
							),
							"dependency" => array(
								"element"=>"tpl",
								"value"=> array("default")
							),
							"description" => __ ( "", 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"heading" => __ ( 'Show image', 'jwsthemes' ),
							"param_name" => "show_image",
							"value" => array (
									__( "Please select", 'jwsthemes' ) => "",
									__( "Yes, please", 'jwsthemes' ) => 1,
									__( "No", 'jwsthemes' ) => 0
							),
							"description" => __ ( "Show or hide image on your carousel", 'jwsthemes' )
					),
					array (
						"type" => "checkbox",
						"heading" => __ ( 'Show Title', 'jwsthemes' ),
						"param_name" => "show_title",
						"value" => array (
								__ ( "Yes, please", 'jwsthemes' ) => true
						),
						"description" => __ ( 'Show or hide title on your post.', 'jwsthemes' )
					),
					array (
						"type" => "checkbox",
						"heading" => __ ( 'Show Tooltip', 'jwsthemes' ),
						"param_name" => "show_tooltip",
						"value" => array (
								__ ( "Yes, please", 'jwsthemes' ) => true
						),
						"dependency" => array(
							"element"=>"tpl",
							"value"=> array("tooltip")
						),
						"description" => __ ( 'Show or hide tooltip on your post.', 'jwsthemes' )
					),
					array (
						"type" => "checkbox",
						"heading" => __ ( 'Show Information', 'jwsthemes' ),
						"param_name" => "show_info",
						"value" => array (
								__ ( "Yes, please", 'jwsthemes' ) => true
						),
						"description" => __ ( 'Show or hide Information of your post.', 'jwsthemes' )
					),
					array (
						"type" => "checkbox",
						"heading" => __ ( 'Show description', 'jwsthemes' ),
						"param_name" => "show_description",
						"value" => array (
								__ ( "Yes, please", 'jwsthemes' ) => true
						),
						"description" => __ ( 'Show or hide description of your post.', 'jwsthemes' )
					),
					array (
						"type" => "textfield",
						"heading" => __ ( 'Excerpt Length', 'jwsthemes' ),
						"param_name" => "excerpt_length",
						"value" => '',
						"description" => __ ( 'The length of the excerpt, number of words to display. Set to "-1" for no excerpt. Default: 20.', 'jwsthemes' )
					),
					array (
						"type" => "textfield",
						"heading" => __ ( 'Excerpt More', 'jwsthemes' ),
						"param_name" => "excerpt_more",
						"value" => '',
						"description" => __ ( 'The more of the excerpt, character of words to display. Default: "..."', 'jwsthemes' )
					),
					array (
							"type" => "textfield",
							"heading" => __ ( 'Read More', 'jwsthemes' ),
							"param_name" => "read_more",
							"value" => '',
							"description" => __ ( 'Enter desired text for the link or for no link, leave blank or set to \"-1\".', 'jwsthemes' )
					),
					array (
							"type" => "textfield",
							"heading" => __ ( 'Count', 'jwsthemes' ),
							"param_name" => "posts_per_page",
							'value' => '12',
							"description" => __ ( 'The number of posts to display on each page. Set to "-1" for display all posts on the page.', 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"heading" => __ ( 'Order by', 'jwsthemes' ),
							"param_name" => "orderby",
							"value" => array (
									"None" => "none",
									"Title" => "title",
									"Date" => "date",
									"ID" => "ID"
							),
							"description" => __ ( 'Order by ("none", "title", "date", "ID").', 'jwsthemes' )
					),
					array (
							"type" => "dropdown",
							"heading" => __ ( 'Order', 'jwsthemes' ),
							"param_name" => "order",
							"value" => Array (
									"None" => "none",
									"ASC" => "ASC",
									"DESC" => "DESC"
							),
							"description" => __ ( 'Order ("None", "Asc", "Desc").', 'jwsthemes' )
					),
					array (
							"type" => "textfield",
							"heading" => __ ( "Extra class name", "js_composer" ),
							"param_name" => "el_class",
							"description" => __ ( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" )
					)
		)
));