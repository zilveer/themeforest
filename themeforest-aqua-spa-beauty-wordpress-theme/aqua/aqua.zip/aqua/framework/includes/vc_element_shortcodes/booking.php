<?php
vc_map(array(
    "name" => 'Booking Table',
    "base" => "booking-form",
    "icon" => "tb-icon-for-vc",
	"category" => __('Aqua', 'jwsthemes'),
    "description" => __('Booking Table', 'jwsthemes'),
    "params" => array()
));