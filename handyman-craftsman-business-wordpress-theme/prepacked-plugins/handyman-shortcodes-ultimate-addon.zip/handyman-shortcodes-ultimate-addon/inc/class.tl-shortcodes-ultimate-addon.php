<?php
/**
 * Class TL_Shortcodes_Ultimate_Addon
 */
class TL_Shortcodes_Ultimate_Addon{


    /**
     * @var
     */
    protected static $_instance;


    /**
     * Array of new shortcodes
     *
     * @var array
     */
    protected $_shortcodes = array();


    /**
     * List of build-in (default) shortcodes that should be removed
     *
     * @var array
     */
    protected $_shortcodes_to_remove = array('posts', 'feed');


    /**
     * List of build-in (default) groups that should be removed
     *
     * @var array
     */
    protected $_groups_to_remove = array('data');//['other'];



    /**
     * Constructor
     */
    private function __construct()
    {

        // Add notice to the admin panel if deps are not installed
        add_action( 'admin_notices'    , array($this, 'adminNotices') );

        if($this->checkDeps()){

            register_activation_hook(TL_SHORTCODES_ADDON_FILE  , array($this, 'activate'));
            register_deactivation_hook(TL_SHORTCODES_ADDON_FILE, array($this, 'deactivate'));

            load_plugin_textdomain( TL_SHORTCODES_ADDON_SLUG, false, TL_SHORTCODES_ADDON_BASE . '/lang' );

            // Add new shortcode group and shortcodes interfaces to parent plugin
            add_action( 'init', array( $this, 'init' ) );

            // Register new shortcodes
            add_action( 'init', array($this, 'registerShortcodes'));

            // Enqueue plugin scrips(css/js) for administration pages
            add_action('admin_enqueue_scripts', array($this, 'enqueueAdminAssets'));

            // Enqueue scripts for front pages
            add_action('wp_enqueue_scripts'	  , array($this, 'enqueueAssets'), 99);

            // Enqueue scripts for preview
            add_action('su/assets/enqueue', array($this, 'enqueueAssets'), 99);

            //Enable shortcodes in widgets
            add_filter('widget_text', 'do_shortcode');
        }
    }


    /**
     * Init
     */
    public function init()
    {
        // Filter unsupported group & shortcodes from "Shortcodes Ultimate Plugin"
        add_filter('tl_remove_unsupported_shortcodes', array($this, 'filterDefaultShortcodes'));
        add_filter('tl_remove_unsupported_groups'    , array($this, 'filterDefaultGroups'));

        // Shortcodes Ultimate hooks
        delete_transient( 'su/generator/popup' );
        add_filter( 'su/data/groups'    , array($this, 'addGroup'), 0, 1);
        add_filter( 'su/data/shortcodes', array($this, 'registerShortcodesToPlugin'), 0, 1);

        //add_action( 'su/assets/register', [$this, 'addCustomCss'],10, 1 );
        //add_action( 'su/generator/preview/before', array( $this, 'addCustomCss' ) );
    }


    public function addCustomCss($a)
    {
      /*  if(function_exists('layers_generate_customizer_fonts')){
            layers_generate_customizer_fonts();
        }
        if(function_exists('layers_enqueue_custom_fonts')){
            layers_enqueue_custom_fonts();
        }

        global $layers_inline_css;
        echo '<style type="text/css">'.$layers_inline_css.'</style>';*/
    }


    /**
     * Enqueueu scripts for administration panel
     *
     * @param $hook
     */
    public function enqueueAdminAssets($hook)
    {
        global $wp_customize;
        if ( !isset( $wp_customize ) ) {
            // do stuff
            wp_enqueue_style(TL_SHORTCODES_ADDON_SLUG . '-admin', self::_pluginAsset('css/admin.css'), array(), TL_SHORTCODES_ADDON_VER );
        }
    }


    /**
     * Enqueue scripts for front
     */
        public function enqueueAssets()
    {
        wp_register_style(TL_SHORTCODES_ADDON_SLUG.'css', self::_pluginAsset('css/plugin.css'), false, TL_SHORTCODES_ADDON_VER, 'all' );
        wp_enqueue_style(TL_SHORTCODES_ADDON_SLUG.'css');
    }


    /**
     * Append "mazzareli" shortcode group
     *
     * @param array $groups
     *
     * @return array
     */
    public function addGroup($groups)
    {
        $groups = apply_filters('tl_remove_unsupported_groups', $groups);
        $groups['themelaboratory'] = __( 'ThemeLabs', TL_SHORTCODES_ADDON_SLUG );
        return $groups;
    }


    /**
     * Filter to modify original shortcodes data and add custom shortcodes
     *
     * @param array $shortcodes Basic plugin shortcodes
     *
     * @return array Modified array
     */
    public function registerShortcodesToPlugin($shortcodes)
    {
        $shortcodes = apply_filters('tl_remove_unsupported_shortcodes', $shortcodes);

        $new_shortcodes = TL_Shortcodes::single()->getInterfaces();

        foreach($new_shortcodes as $shortcode => $values)
        {
            $new_shortcodes[$shortcode]['group'] = 'themelaboratory';
            if(!isset($new_shortcodes[$shortcode]['desc']))
                $new_shortcodes[$shortcode]['desc'] = '';
        }
        $shortcodes = array_merge($shortcodes, $new_shortcodes);
        return $shortcodes;
    }


    /**
     * We are not providing CSS support for all builtin shortcodes
     * so they should be removed
     *
     * @param $shortcodes
     * @return array
     */
    public function filterDefaultShortcodes($shortcodes)
    {
        // Clean all shortcodes that belongs to a certain group
        foreach($shortcodes as $ii => $shortcode){
            if(in_array($shortcode['group'], $this->_groups_to_remove)){
                unset($shortcodes[$ii]);
            }
        }

        foreach($shortcodes as $ii => $shortcode){
            if(in_array($ii, $this->_shortcodes_to_remove)){
                unset($shortcodes[$ii]);
            }
        }
        return $shortcodes;
    }


    /**
     * Filter built-in groups
     *
     * @param $groups
     *
     * @return mixed
     */
    public function filterDefaultGroups($groups)
    {
        foreach($groups as $ii => $g){
            if(in_array($ii, $this->_groups_to_remove)){
                unset($groups[$ii]);
            }
        }
        return $groups;
    }



    /**
     * Function to show admin notice if Shortcodes Ultimate is not installed
     */
    public function adminNotices()
    {
        // Check that plugin is not installed
        if ( function_exists( 'shortcodes_ultimate' ) ) return;
        echo '<div class="error">
			 	<p>
			 	    '.__('For full functionality of this plugin you need to install and activate plugin', TL_SHORTCODES_ADDON_SLUG).' <strong>Shortcodes Ultimate</strong>. <a href="' . admin_url( 'plugin-install.php?tab=search&s=shortcodes+ultimate' ) . '">'.__('Install now', TL_SHORTCODES_ADDON_SLUG).' &rsaquo;</a>
			 	</p>
			  </div>';
    }


    /**
     * Check if Shortcodes Ultimate plugin is active
     *
     * @return bool
     */
    protected function checkDeps()
    {
        if(!in_array( 'shortcodes-ultimate/shortcodes-ultimate.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) )){
            return false;
        }
        else{
            return true;
        }
    }


    /**
     * Register shortcode to the wordpress API
     */
    public function registerShortcodes()
    {
        $ms = TL_Shortcodes::single()->doShortcodeHandlers();
    }


    /**
     *
     */
    public function activate(){
        do_action( TL_SHORTCODES_ADDON_SLUG . '_tl_activation' ); // check system requirements before activation
    }

    public function deactivate(){}


    /**
     * @return TL_Shortcodes_Ultimate_Addon
     */
    public static function single()
    {
        if(self::$_instance === null){
            self::$_instance = new TL_Shortcodes_Ultimate_Addon();
        }
        return self::$_instance;
    }


    /**
     * @param $file
     * @return string
     */
    protected static function _pluginAsset($file){
        return TL_SHORTCODES_ADDON_URI . 'assets/' . $file;
    }
}