<?php

require_once "ait-posts.php";