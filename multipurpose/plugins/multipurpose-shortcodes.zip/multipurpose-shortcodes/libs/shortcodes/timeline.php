<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// shortcode for Timeline
add_shortcode('timeline', 'multipurpose_timeline');
add_shortcode('timeline_events', 'multipurpose_timeline_events');
add_shortcode('timeline_event', 'multipurpose_timeline_event');
add_shortcode('timeline_milestone', 'multipurpose_timeline_milestone');
add_shortcode('timeline_begin', 'multipurpose_timeline_begin');

function multipurpose_timeline_events($atts, $content = ''){
    $output = '<ul class="timeline-events">';
    $output .= do_shortcode($content);
    $output .= '<p>&nbsp;</p>';
    $output .= '</ul>';
    return $output;
}

function multipurpose_timeline($atts, $content = ''){
    $output = '<div class="timeline">';
    $output .= '<div class="line"></div>';
    $output .= do_shortcode($content);
    $output .= '</div>';
    return $output;
}

function multipurpose_timeline_event($atts, $content = ''){
    $output = '<li class="timeline-event">';
    $output .= '<div class="event-body">';
    $output .= do_shortcode($content);
    $output .= '</div>';
    $output .= '</li>';
    return $output;
}

function multipurpose_timeline_milestone($atts, $content = ''){
    $output = '<li class="timeline-milestone">';
    $output .= do_shortcode($content);
    $output .= '</li>';
    return $output;
}

function multipurpose_timeline_begin($atts, $content = ''){
    $output = '<div class="timeline-begin">';
    $output .= do_shortcode($content);
    $output .= '</div>';
    return $output;
}
