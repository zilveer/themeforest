<?php
/**
 * Plugin Name: Apital Custom Posts
 * Description: Create theme custom posts.
 * Version: 1.0.0
 * Author: NrgThemes
 * Author URI: http://nrgthemes.com/
 * License: GPL2
 */

if ( !function_exists('fw_apital_create_custom_post_types') ) :

    function fw_apital_create_custom_post_types()
    {

        // Member
        $labels = array(
            'name' => __('Members', 'tfuse'),
            'singular_name' => __('Member', 'tfuse'),
            'add_new' => __('Add New', 'tfuse'),
            'add_new_item' => __('Add New', 'tfuse'),
            'edit_item' => __('Edit Member info', 'tfuse'),
            'new_item' => __('New Member', 'tfuse'),
            'all_items' => __('All Members', 'tfuse'),
            'view_item' => __('View Member info', 'tfuse'),
            'search_items' => __('Search Member', 'tfuse'),
            'not_found' =>  __('Nothing found', 'tfuse'),
            'not_found_in_trash' => __('Nothing found in Trash', 'tfuse'),
            'parent_item_colon' => ''
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'query_var' => true,
            'has_archive' => true,
            'rewrite' => array('slug'=> 'fw-member'),
            'menu_position' => 5,
            'supports' => array('title','editor','excerpt','comments','thumbnail')
        );

        // Add new taxonomy, make it hierarchical (like categories)
        $labels = array(
            'name' => __('Categories','tfuse'),
            'singular_name' => __('Category','tfuse'),
            'search_items' => __('Search Categories','tfuse'),
            'all_items' => __('All Categories','tfuse'),
            'parent_item' => __('Parent Category','tfuse'),
            'parent_item_colon' => __('Parent Category:','tfuse'),
            'edit_item' => __('Edit Category','tfuse'),
            'update_item' => __('Update Category','tfuse'),
            'add_new_item' => __('Add New Category','tfuse'),
            'new_item_name' => __('New Category Name','tfuse')
        );

        register_taxonomy('fw-members', array('fw-member'), array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'fw-members')
        ));

        register_post_type( 'fw-member' , $args );

        // TESTIMONIALS
        $labels = array(
            'name' => __('Testimonials', 'tfuse'),
            'singular_name' => __('Testimonial', 'tfuse'),
            'add_new' => __('Add New', 'tfuse'),
            'add_new_item' => __('Add New Testimonial', 'tfuse'),
            'edit_item' => __('Edit Testimonial', 'tfuse'),
            'new_item' => __('New Testimonial', 'tfuse'),
            'all_items' => __('All Testimonials', 'tfuse'),
            'view_item' => __('View Testimonial', 'tfuse'),
            'search_items' => __('Search Testimonials', 'tfuse'),
            'not_found' =>  __('Nothing found', 'tfuse'),
            'not_found_in_trash' => __('Nothing found in Trash', 'tfuse'),
            'parent_item_colon' => ''
        );

        $args = array(
            'labels' => $labels,
            'public' => false,
            'publicly_queryable' => false,
            'show_ui' => true,
            'query_var' => true,
            'rewrite' => true,
            'menu_position' => 5,
            'supports' => array('title','editor','thumbnail')
        );
        register_post_type( 'fw-testimonials' , $args );
		
		$labels = array(
            'name' => __('Tags','fw' ),
            'singular_name' => __('Tag', 'fw'),
            'search_items' => __('Search Tags','fw'),
            'popular_items' => __( 'Popular Tags','fw' ),
            'all_items' => __('All Tags','fw'),
            'parent_item' => null,
            'parent_item_colon' => null,
            'edit_item' => __('Edit Tag','fw'),
            'update_item' => __('Update Tag','fw'),
            'add_new_item' => __('Add New Tag','fw'),
            'new_item_name' => __('New Tag Name','fw'),
            'separate_items_with_commas' => __( 'Separate tags with commas','fw' ),
            'add_or_remove_items' => __( 'Add or remove tags','fw' ),
            'choose_from_most_used' => __( 'Choose from the most used tags','fw' ),
        );
        
        register_taxonomy('tags', 'fw-portfolio', array(
            'hierarchical' => false,
            'labels' => $labels,
            'public' => true,
            'show_ui' => true,
            'update_count_callback' => '_update_post_term_count',
            'query_var' => true,
            'rewrite' => array('slug' => 'portfolio-tag')
        ));
    }
    add_action( 'init', 'fw_apital_create_custom_post_types');
endif;