<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// add shortcode for Recent Posts in Columns
add_shortcode('recent_posts_in_columns', 'multipurpose_recent_posts_in_columns');

function multipurpose_recent_posts_in_columns($atts, $content = null) {
    if (isset($atts) && !empty($atts))
        array_walk($atts, 'multipurpose_arrangement_shortcode_arr_value');

    extract(shortcode_atts(array(
        'number_of_columns' => '2',
        'thumbnail' => '',
        'excerpt' => '',
        'excerpt_words' => '',
        'strip_html' => '',
        'headline' => '',
        'translate_read_more' => ''
                    ), $atts));

    global $wpdb;
	
	//category name paremeter set
	$category_name = '';
	if( !empty($atts['category_name']) ) {
		$category_name = $atts['category_name'];
	} 

    $args = array(
        'posts_per_page' => $number_of_columns,
        'orderby' => 'post_date',
        'order' => 'DESC',
        'post_type' => 'post',
        'post_status' => 'publish',
		'category_name' => $category_name,
        'suppress_filters' => true);

    $posts_array = get_posts($args);

    $output = '<section class="columns hp-latest' . $number_of_columns . '">';

    if (!empty($posts_array)) {
        foreach ($posts_array as $key_data => $val_data) {

            $comment = get_comment_count($val_data->ID);
            $output .='<article class="col col' . $number_of_columns . '">';

            if ($thumbnail == 'yes') {
                if (has_post_thumbnail($val_data->ID)) {
                    $output .= '<a href="' . get_permalink($val_data->ID) . '">' . get_the_post_thumbnail($val_data->ID, 'thumbnail-medium', $val_data->post_title) . '</a>';
                }
            }

            if ($headline == 'yes') {
                $output .= '<h2><a href="' . get_permalink($val_data->ID) . '">' . $val_data->post_title . '</a></h2>';
            }

            if ($excerpt == 'yes') {
                if (!empty($val_data->post_excerpt)) {
                    $output .= '<p>' . multipurpose_cut_character_word($excerpt_words, $val_data->post_excerpt, $strip_html) . '</p>';
                } elseif (!empty($val_data->post_content)) {
                    $output .= '<p>' . multipurpose_cut_character_word($excerpt_words, $val_data->post_content, $strip_html) . '</p>';
                }
            }

            if (!empty($translate_read_more))
                $output .= '<p class="more"><a href="' . get_permalink($val_data->ID) . '">'.$translate_read_more.'</a></p>';

            $output.= '</article>';
        }
    }

    $output .= '</section>';

    return $output;
}
