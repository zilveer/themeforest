<?php

add_action('init', 'tb_icon_integrateWithVC');

function tb_icon_integrateWithVC() {
    vc_map(array(
        "name" => __("Icon", 'jwsthemes'),
        "base" => "icon",
        "class" => "icon",
        "category" => __('Aqua', 'jwsthemes'),
        "icon" => "tb-icon-for-vc",
        "params" => array(
            array(
                "type" => "colorpicker",
                "class" => "",
                "heading" => __("Color", 'jwsthemes'),
                "param_name" => "color",
                "value" => "",
                "description" => __("Color.", 'jwsthemes')
            ),        
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Font size", 'jwsthemes'),
                "param_name" => "fontsize",
                "value" => "",
                "description" => __("Font size.", 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Link", 'jwsthemes'),
                "param_name" => "link",
                "value" => "",
                "description" => __("Link.", 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Class", 'jwsthemes'),
                "param_name" => "class",
                "value" => "",
                "description" => __("Class.", 'jwsthemes')
            ),
            array(
                "type" => "textarea",
                "holder" => "div",
                "class" => "",
                "heading" => __("Text", 'jwsthemes'),
                "param_name" => "content",
                "value" => "",
                "description" => __("Text.", 'jwsthemes')
            )
        )
    ));
}
