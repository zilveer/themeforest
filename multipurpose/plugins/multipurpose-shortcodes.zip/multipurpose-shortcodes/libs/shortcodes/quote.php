<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');
// shortcode blockquote
add_shortcode('quote', 'multipurpose_quote_group');
add_shortcode('quote_content', 'multipurpose_quote_content');
add_shortcode('quote_signature', 'multipurpose_quote_signature');

function multipurpose_quote_group( $atts, $content = null ) {
    global $quote;
    $quote = '';	
    $output = '<blockquote class="quote">';    
    $output .= do_shortcode($content);
    $output .= '</blockquote>';
    return $output;  
}  

function multipurpose_quote_content($atts, $content = null) {
    global $quote;
    if($content) {
        $output = '<p>'.do_shortcode($content).'</p>';
    }
    return $output;
}
function multipurpose_quote_signature($atts, $content = null) {
    global $quote;
    $name = '';
    extract(shortcode_atts(array(  
        'name' => ''
    ), $atts));  
    
    $output = '<p class="signature"><span>'.$name.'</span> '.do_shortcode($content).'</p>';   
    return $output;
}
