<?php
require_once( plugin_dir_path( __FILE__ ) .'portfolio.php' );
require_once( plugin_dir_path( __FILE__ ) .'testimonial.php' );
require_once( plugin_dir_path( __FILE__ ) .'logos.php' );
require_once( plugin_dir_path( __FILE__ ) .'cause.php' );
require_once( plugin_dir_path( __FILE__ ) .'sermons.php' );