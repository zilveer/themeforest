<?php
	global $options;

    if (isset($_GET['page']) && $_GET['page']=='shortcodelic_css') {
?>

        <section id="pix_content_loaded">
            <h3><?php _e('Options','shortcodelic'); ?>: <small><?php _e('Compile CSS file','shortcodelic'); ?></small></h3>

            <?php if (get_option('shortcodelic_allow_ajax')=='true') { ?>
            <form action="/" class="dynamic_form ajax_form cf">
            <?php } else { ?>
            <form method="post" class="dynamic_form cf" action="<?php echo admin_url("admin.php?page=shortcodelic_admin"); ?>">
            <?php } ?>
            
                <div class="pix_columns cf">

                    <div class="clear"></div>
                    <label for="shortcodelic_css_code"><?php _e( 'Custom CSS', 'shortcodelic' ); ?>:</label>
                    <textarea name="shortcodelic_css_code" id="shortcodelic_css_code"><?php echo stripslashes(esc_html(get_option('shortcodelic_css_code'))); ?></textarea>

                    <label for="shortcodelic_load_css_inline">
                        <input type="hidden" name="shortcodelic_load_css_inline" value="0">
                        <input type="checkbox" id="shortcodelic_load_css_inline" name="shortcodelic_load_css_inline" value="true" <?php checked( get_option('shortcodelic_load_css_inline'), 'true' ) ?>>
                        <span></span>
                        <?php _e( 'Put CSS code inside head tag', 'shortcodelic'); ?> <small>(<a href="#" data-dialog="<?php _e('If you have problem to load the CSS file to your server, check this option','shortcodelic'); ?>"><?php _e('more info','shortcodelic'); ?></a>)</small>
                    </label>

                    <br>
                    <br>

                </div><!-- .pix_columns -->


                <div class="clear"></div>

                <a class="pix-save-options save-css pix_button alignleft" href="#"><?php _e('Get the entire CSS file','shortcodelic'); ?></a>

                <input type="hidden" name="download_css" value="" />
                <input type="hidden" name="compile_css" value="compile_css" />
                <input type="hidden" name="action" value="shortocodelic_data_save" />
                <input type="hidden" name="shortcodelic_security" value="<?php echo wp_create_nonce('shortcodelic_data'); ?>" />

                <button type="submit" class="pix-save-options pix_button compile push alignright"><?php _e('Save options','shortcodelic'); ?><i class="scicon-awesome-ok"></i></button>
                <div id="gradient-save-button"></div>

            </form><!-- .dynamic_form -->

        </section><!-- #pix_content_loaded -->
<?php 
	}