<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_dtbaker_Blog_Posts extends Widget_Base {

	public function get_id() {
		return 'dtbaker_blog_posts';
	}

	public function get_title() {
		return __( 'Recent Blog Posts', 'dtbaker_blog_posts' );
	}

	public function get_icon() {
		return 'post-list';
	}

	protected function _register_controls() {
		$this->add_control(
			'section_blog_posts',
			[
				'label' => __( 'Blog Posts', 'dtbaker_blog_posts' ),
				'type' => Controls_Manager::SECTION,
			]
		);


		$this->add_control(
			'posts_per_page',
			[
				'label' => __( 'Count', 'dtbaker_blog_posts' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 5,
				'title' => __( 'How many blog posts to show', 'dtbaker_blog_posts' ),
				'section' => 'section_blog_posts',
			]
		);


		$this->add_control(
			'columns',
			[
				'label' => __( 'Columns', 'dtbaker_blog_posts' ),
				'type' => Controls_Manager::SELECT,
				'default' => 1,
				'section' => 'section_blog_posts',
				'options' => apply_filters('dtbaker_blog_posts_columns', [
					1 => __( 'One', 'dtbaker_blog_posts' ),
					2 => __( 'Two', 'dtbaker_blog_posts' ),
				]),
			]
		);

		$this->add_control(
			'output',
			[
				'label' => __( 'Output Type', 'dtbaker_blog_posts' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'summary',
				'section' => 'section_blog_posts',
				'options' => apply_filters('dtbaker_blog_posts_output', [
					'summary' => __( 'Blog Summary/Excerpt', 'dtbaker_blog_posts' ),
					'full' => __( 'Full Blog Post', 'dtbaker_blog_posts' ),
				]),
			]
		);

		do_action('dtbaker_blog_posts_elementor_controls', $this);

	}

	protected function render( $instance = [] ) {

		$output = !empty($instance['output']) ? esc_attr($instance['output']) : 'summary';
//		echo '[blog_posts columns="'.(int)$instance['columns'].'" posts_per_page="'.(int)$instance['posts_per_page'].'" output="'.$output.'"]';
		$html = do_shortcode('[blog_posts columns="'.(int)$instance['columns'].'" posts_per_page="'.(int)$instance['posts_per_page'].'" output="'.$output.'"]');

		echo apply_filters('dtbaker_blog_posts_elementor_render', $html, $instance);

	}

	protected function content_template() {}
	
	public function render_plain_content( $instance = [] ) {}

}
