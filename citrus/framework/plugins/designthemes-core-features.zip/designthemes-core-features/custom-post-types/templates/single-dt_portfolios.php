<?php 
get_header();
$portfolio_settings = get_post_meta ( $post->ID, '_portfolio_settings', TRUE );
$portfolio_settings = is_array ( $portfolio_settings ) ? $portfolio_settings : array ();

$layout = isset( $portfolio_settings['layout'] ) ? $portfolio_settings['layout'] : 'single-portfloio-layout-one';
$container_start =  $container_middle =  $container_end = "";
if( $layout === "single-portfloio-layout-two" ) {
	$container_start	 =	'<div class="column dt-sc-one-half first">';
	$container_middle	 =	'</div>';
	$container_middle  .=	'<div class="column dt-sc-one-half">'; 
	$container_end	 =	'</div>';
	$post_thumbnail = 'portfolio-single';
}elseif( $layout === "single-portfloio-layout-three" ){
	$container_start	 =	'<div class="column dt-sc-one-half right-gallery">';
	$container_middle	 =	'</div>';
	$container_middle  .=	'<div class="column dt-sc-one-half first">'; 
	$container_end	 =	'</div>';
	$post_thumbnail = 'portfolio-single';
}elseif( $layout === "single-portfloio-layout-one" ) {
	$container_middle = "<div class='dt-sc-hr-invisible-small'></div>";
	$post_thumbnail = 'portfolio-single-fullwidth';
}
global $dt_allowed_html_tags;
?>
      
<div class="container">
    <!-- **Primary Section** -->
    <div id="primary" class="content-full-width">
	<?php
    if( have_posts() ):
		while( have_posts() ):
		the_post();?>
		<!-- #post-<?php the_ID()?> starts -->
		<article id="post-<?php the_ID(); ?>" <?php post_class('portfolio-single'); ?>>
        
			<?php echo $container_start; ?>
            <ul class="portfolio-slider">
				<?php
                if( array_key_exists("items_name",$portfolio_settings) ) {
					foreach( $portfolio_settings["items_name"] as $key => $item ){
						$current_item = $portfolio_settings["items"][$key];
						if( "video" === $item ) {
							echo "<li><div class='dt-video-wrap'>".wp_oembed_get( $current_item )."</div></li>";
						} else {
							$attachment_id = dt_get_attachment_id_from_url($current_item);
							$img_attributes = wp_get_attachment_image_src($attachment_id, $post_thumbnail);
							echo "<li><img src='".$img_attributes[0]."' width='".$img_attributes[1]."' height='".$img_attributes[2]."' /></li>";
						}
					}
				} 
				else {
					echo "<li> <img src='http://placehold.it/1160' alt='' title=''/></li>";
                }
				?>
            </ul>
            <?php 
			echo $container_middle;
            
            echo '<h4>'.__('Overview', 'dt_themes').'</h4>';
            
			if(array_key_exists("show-subtitle-category",$portfolio_settings)) {
			
				if( array_key_exists("sub-title",$portfolio_settings) ):
				echo '<h5>'.wp_kses($portfolio_settings["sub-title"], $dt_allowed_html_tags).'</h5>';
				endif;
				
				the_terms($post->ID,'portfolio_entries','<p> <span><strong>'.__(" Category","dt_themes").' : </strong></span> ',', ','</p>');
            
			}
			
            the_content();?>
            <div class="dt-sc-margin20"> </div>
            
            <div class="project-details">
            	<?php if( isset( $portfolio_settings["client-name"] ) || isset( $portfolio_settings["location"] ) || isset( $portfolio_settings["website-link"] )): ?>
                    <h5><?php echo __('Project Details', 'dt_themes'); ?></h5>
                    <ul class="client-detail">
                        <?php if( isset( $portfolio_settings["client-name"] ) ): ?>
                        <li> <p> <span class="fa fa-user"> </span> <strong> <?php echo __('Client Name :', 'dt_themes'); ?> </strong> <?php echo wp_kses($portfolio_settings["client-name"], $dt_allowed_html_tags); ?> </p> </li>
                        <?php endif; ?>
                        <?php if( isset( $portfolio_settings["location"] ) ): ?>
                        <li> <p> <span class="fa fa-map-marker"> </span> <strong>  <?php echo __('Location :', 'dt_themes'); ?></strong> <?php echo wp_kses($portfolio_settings["location"], $dt_allowed_html_tags);?> </p> </li>
                        <?php endif;?>
                        <?php if( isset( $portfolio_settings["website-link"] ) ): ?>
                        <li> <p> <span class="fa fa-link"> </span> <strong> <?php echo __('Website :', 'dt_themes'); ?> </strong> <a href="<?php echo wp_kses($portfolio_settings["website-link"], $dt_allowed_html_tags);?>" alt="" title=""> <?php echo $portfolio_settings["website-link"];?> </a> </p> </li>
                        <?php endif;?>
                    </ul>
                <?php endif;?>
                
                <?php 
                if(array_key_exists("show-social-share",$portfolio_settings)):
					echo '<h5>'.__('Share', 'dt_themes').'</h5>';
					echo '<div class="dt-sc-social-icons">';
					dttheme_social_bookmarks('sb-portfolio');
					echo '</div>';
                endif;
                
                edit_post_link( __( 'Edit','dt_themes'));
                ?>
            </div>
            
            <?php echo $container_end; ?>
            
            <!-- **Post Nav** -->
            <div class="post-pagination">
				<?php previous_post_link('%link', __('Previous Post','dt_themes'));?>
                <?php next_post_link('%link', __('Next Post','dt_themes'));?>
            </div>
            
            <?php
            if(!dttheme_option('general', 'disable-portfolio-comment')): 
				comments_template();
            endif;
            ?>  
                       
            <div class="dt-sc-hr-invisible-small"></div>
             
		</article><!-- #post-<?php the_ID()?> Ends -->
		<?php endwhile;
    endif;
	wp_reset_query();?>
    
    </div><!-- **Primary Section** -->
</div>
        
<?php if(array_key_exists("show-related-items",$portfolio_settings)): ?>

    <div class="recent-portfolio">
        <div class="recent-portfolio-bg">
            <!--main-title starts-->
            <div class="main-title aligncenter">
                <h3><?php _e('Related','dt_themes');?><span class="wlast"> <?php _e('Portfolio','dt_themes');?></span>
                <span class="small-line"></span></h3>
            </div>
        </div>
        <!--main-title ends-->
        
		<?php 
        $category_ids = array();
        $input  = wp_get_object_terms( $post->ID, 'portfolio_entries');
        
        foreach($input as $category) $category_ids[] = $category->term_id;
        
        $args = array('orderby' => 'rand',
                'showposts' => '4' ,
                'post__not_in' => array($post->ID),
                'tax_query' => array( array( 'taxonomy'=>'portfolio_entries', 'field'=>'id', 'operator'=>'IN', 'terms'=>$category_ids )));
                
        query_posts($args);
        if( have_posts() ):
            $count = 1;
            while( have_posts() ):
                the_post();
                $the_id = get_the_ID();
                
                $portfolio_item_meta = get_post_meta($the_id,'_portfolio_settings',TRUE);
                $portfolio_item_meta = is_array($portfolio_item_meta) ? $portfolio_item_meta  : array();
                
                $first = ( $count === 1 ) ? " first" : "";
				
				$even_cls = '';
				$no = $wp_query->current_post+1;
				if(($no%2) == 0) $even_cls .= ' even-item';
				?>
                
            <!--gallery-no-space starts-->
            <div class="column dt-sc-one-fourth gallery no-space <?php echo $even_cls; ?>">
                <figure> 
                    <?php 
					$popup = "http://placehold.it/1160";
                    if( array_key_exists('items_name', $portfolio_item_meta) ) {
						$item =  $portfolio_item_meta['items_name'][0];
						$popup = $portfolio_item_meta['items'][0];
						if( "video" === $item ) {
							$items = array_diff( $portfolio_item_meta['items_name'] , array("video") );
							if( !empty($items) ) {
								echo "<img src='".$portfolio_item_meta['items'][key($items)]."' width='1160' height='1160' alt='' />";	
							} else {
								echo '<img src="http://placehold.it/1160" width="1160" height="1160" alt="" />';
							}
						} else {
							echo "<img src='".$portfolio_item_meta['items'][0]."' width='1160' height='1160' alt='' />";
						}
					} else {
						echo "<img src='{$popup}' alt='' />";
					}
					?>
                            
                    <!--image-overlay starts-->
                    <div class="image-overlay">
                        <span class="white-box"></span>
                        <div class="image-overlay-text">
                            <h4><a href="<?php the_permalink();?>" title="<?php printf( esc_attr__('%s'), the_title_attribute('echo=0'));?>"><?php the_title();?></a></h4>
                            <span class="small-line"></span>
							<?php if( array_key_exists("sub-title",$portfolio_item_meta) ): ?>
                                <p><a href="<?php the_permalink();?>"><?php echo $portfolio_item_meta["sub-title"];?></a></p>
                            <?php endif;?>
                            <ul class="links">
                                <li><a href="<?php echo $popup;?>" class="zoom" data-gal="prettyPhoto[gallery]" title="<?php printf( esc_attr__('%s'), the_title_attribute('echo=0'));?>"><span class="hexagon"><span class="corner1"></span><span class="corner2"></span><i class="fa fa-search"></i></span></a></li>
                                <li><a href="<?php the_permalink();?>" class="link" title="<?php printf( esc_attr__('%s'), the_title_attribute('echo=0'));?>"><span class="hexagon"><span class="corner1"></span><span class="corner2"></span><i class="fa fa-external-link"></i></span></a></li>
                            </ul>
                        </div>
                        <span class="border-line"></span>
                    </div>
                    <!--image-overlay ends-->
                </figure> 
            </div>
            <!--gallery-no-space ends--> 
            
		<?php 			
			$count++;
			endwhile;
		endif;
		wp_reset_query();
		?>
        
    </div>

<?php endif;?> 
<?php get_footer();?>