<?php

/**
 * Plugin Name: createIT Videos Plugin
 * Plugin URI: http://woovideo.createit.pl/
 * Description: Videos for Woocommerce
 * Version: 1.1
 * Author: createIT
 * Author URI: http://createit.pl
 */


if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class ctWooVideoPlugin {

    /**
     * Initiate object
     */

    public function __construct() {
        add_action( 'admin_init', array( $this, 'activationWooCommerceCheck' ) );

        $this->setupConsts();
        $this->loadFiles();

        add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'descLinks' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'registerAdminAssets' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'registerAssets' ) );
        add_filter( 'woocommerce_get_settings_pages', array( $this, 'loadSettingsPage' ) );
        register_activation_hook(__FILE__, array($this, 'onPluginActivate'));
    }

    /**
     * Activation callback
     */
    public function onPluginActivate(){

        $defaults = array(
            '_location' => 'tab',
            '_gallery_location' => 'above',
            '_video_location_priority' => 100,
            '_video_class' => '',

            //inline video settings
            '_video_align' => 'none',
            '_video_clearing' => 'no',
            '_video_autoplay' => 'no',
            '_video_margin_left' => 0,
            '_video_margin_top' => 0,
            '_video_margin_right' => 0,
            '_video_margin_bottom' => 0,

            //thumbnail settings
            '_select_icon' => 'play-circle-o',
            '_icon_size' => '80',
            '_icon_position' => 'center',
            '_icon_opacity' => '5',

            //player settings
            '_player_height' => 0,
            '_player_width' => 0,

            //button_settings
            '_button_location' => 'above_tabs',
            '_button_location_priority' => 100,
            '_button_color' => '#000000',
            '_button_text_color' => '#ffffff',
            '_button_label' => 'custom',
            '_custom_button_label' => 'Video',
            '_button_align' => 'left',
            '_button_clearing' => 'no',
            '_button_class' => (get_option('wc_ct_woovideo_button_class')) ? get_option('wc_ct_woovideo_button_class') : '',
            '_button_margin_left' => 0,
            '_button_margin_top' => 0,
            '_button_margin_right' => 0,
            '_button_margin_bottom' => 0,
            '_button_padding_left' => 10,
            '_button_padding_top' => 5,
            '_button_padding_right' => 10,
            '_button_padding_bottom' => 5,
            '_button_height' => 100,
            '_button_width' => 100,
            '_button_border_radius' => 5,

        );

        foreach($defaults as $key => $value) {
            update_option( 'wc_ct_woovideo' . $key, $value);
        }

    }

    /**
     * WooCommmerce Active?
     * @return bool
     */

    public static function hasWooCommerce() {
        return class_exists( 'WooCommerce' );
    }

    /**
     * Setup constants
     */

    protected function setupConsts() {
        define( 'CT_WOOVIDEO_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
        define( 'CT_WOOVIDEO_URI', WP_PLUGIN_URL . '/' . basename( dirname( __FILE__ ) ) );
        define( 'CT_WOOVIDEO_ASSETS', str_replace(get_site_url(),'',CT_WOOVIDEO_URI . '/assets/'));
    }

    /**
     * Check if we have WooCommerce
     */

    public function activationWooCommerceCheck() {
        if ( ! self::hasWooCommerce() ) {
            add_action( 'admin_notices', array( $this, 'showWooCommerceNotice' ) );
        }
    }

    /**
     * Show notice
     */

    public function showWooCommerceNotice() {
        echo '<div class="ct-notice error">
                	<p><strong>' . __( 'createIT Woocommerce Videos Plugin', 'ct-woovideo' ) . '</strong> &#8211; ' . __( 'WooCommerce Plugin must be installed and activated in order to use this plugin.', 'ct-woovideo' ) . '</p>
                </div>';
    }

    /**
     * Load files
     */

    protected function loadFiles() {
        require_once dirname(__FILE__) . '/ctWooVideoAdmin.php';
        require_once dirname(__FILE__) . '/ctWooVideoDisplay.php';
    }

    /**
     * Load settings page
     */

    public function loadSettingsPage(){
        require_once dirname(__FILE__) . '/ctWooVideoSettings.php';
    }

    /**
     * Add plugin links
     */

    public function descLinks( $links ) {

        return array_merge( array(
            '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=ct_woovideo' ) . '">' . __( 'Settings', 'ct-woovideo' ) . '</a>',
            '<a href="http://createit.support/documentation/woocommerce-videos/">' . __( 'Docs', 'ct-woovideo' ) . '</a>',
        ), $links );

    }

    /**
     * Initiate object
     */

    public function registerAdminAssets() {
        global $post;
        $screen = get_current_screen();

        // Meta boxes
        if ( in_array( $screen->id, array( 'product', 'edit-product', 'woocommerce_page_wc-settings' ) ) ) {


            wp_enqueue_media();
            wp_enqueue_style( 'ct-admin-style', CT_WOOVIDEO_ASSETS . '/css/admin.css' );
            wp_enqueue_style( 'wp-color-picker' );
            wp_enqueue_script( 'jquery' );
            wp_enqueue_script( 'ct-woovideo-settings', CT_WOOVIDEO_ASSETS . '/js/ct.wv.sett.js', array('jquery') );
            wp_enqueue_script( 'ct-woovideo-admin-metabox', CT_WOOVIDEO_ASSETS . '/js/ct.wv.admin.metabox.js', array( 'jquery', 'wp-color-picker' ) );

            $params = array(
                'post_id'                                  => isset( $post->ID ) ? $post->ID : '',
                'plugin_url'                               => plugins_url(),
                'ajax_url'                                 => admin_url( 'admin-ajax.php' ),
                'woocommerce_placeholder_img_src'          => wc_placeholder_img_src(),
                'add_video_nonce'                          => wp_create_nonce("add-video"),
                'delete_videos_nonce'                      => wp_create_nonce("delete-videos"),
                'save_videos_nonce'                        => wp_create_nonce("save-videos"),
                'ct_woovideo_show_shortcode_nonce'         => wp_create_nonce("show-shortcode"),
                'ct_woovideo_show_button_shortcode_nonce'  => wp_create_nonce("show-button-shortcode"),
                'restore_defaults_nonce'                   => wp_create_nonce("restore-defaults"),
                'i18n_delete_all_videos'                   => esc_js( __( 'Are you sure you want to delete all videos? This cannot be undone.', 'ct-woovideo' ) ),
                'i18n_restore_all_video_defaults'          => esc_js( __( 'Are you sure you want to restore all videos default settings?', 'ct-woovideo' ) ),
                'i18n_restore_all_button_defaults'         => esc_js( __( 'Are you sure you want to restore all buttons default settings?', 'ct-woovideo' ) ),
                'i18n_choose_image'                        => esc_js( __( 'Choose an image', 'ct-woovideo' ) ),
                'i18n_set_image'                           => esc_js( __( 'Set video image', 'ct-woovideo' ) ),
                'i18n_remove_video'                        => esc_js( __( 'Are you sure you want to remove this video? It can\'t be undone.', 'ct-woovideo' ) ),
                'i18n_choose_video'                        => esc_js( __( 'Choose a video', 'ct-woovideo' ) ),
                'upload_list_video'                        => esc_js( __( 'Open Media Library'))
            );

            wp_localize_script( 'ct-woovideo-admin-metabox', 'ct_woovideo_admin_videos', $params );
            wp_localize_script( 'ct-woovideo-settings', 'ct_woovideo_admin_videos', $params );
        }
    }

    /**
     * Add front-end assets
     */

    public function registerAssets() {
        wp_enqueue_style( 'ct-woovideo-display-style', CT_WOOVIDEO_ASSETS . '/css/ct.woovideo.css' );
        wp_enqueue_style( 'magnific-popup', CT_WOOVIDEO_ASSETS . '/css/magnific-popup.css' );

        wp_enqueue_script( 'magnific-popup', CT_WOOVIDEO_ASSETS . '/js/jquery.magnific-popup.min.js', array( 'jquery' ));
        wp_enqueue_script( 'fitvids', CT_WOOVIDEO_ASSETS . '/js/jquery.fitvids.js', array( 'jquery', 'magnific-popup' ), false, true);
        wp_enqueue_script( 'ct-woovideo-display', CT_WOOVIDEO_ASSETS . '/js/ct.wv.front.js', array( 'jquery', 'magnific-popup', 'fitvids' ), false, true);
    }

}

new ctWooVideoPlugin();