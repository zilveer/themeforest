<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

function multipurpose_testimonial($attr, $content = null) {
	extract(shortcode_atts(array('name' => false, 'name_link' => false, 'org' => false, 'org_link' => false, 'avatar' => false), $attr));
	$html = '<div class="testimonial"><div>';
	$html .= wpautop(do_shortcode($content));
	$html .= '</div>';
	if ($avatar) {
		$html .= '<img src="'.$avatar.'" alt="'.$name.'">';
	}
	
	$html .= '<p>';
	//link start
	if ($name_link) { 
		$html .= '<a href="'.$name_link.'">';
	}
	$html .= $name;
	//link end
	if ($name_link) { 
		$html .= '</a>';
	}
	if ($org) {
		$html .= '<br>';
		$html .= '<span>';
		//link start
		if ($org_link) { 
			$html .= '<a href="'.$org_link.'">';
		}
		//org
		$html .= $org;
		//link end
		if ($org_link) { 
			$html .= '</a>';
		}
		$html .= '</span>';
	}
	$html .= '</p></div>';
	return $html;
}

function multipurpose_testimonial_slider($attr, $content = null) {
	extract(shortcode_atts(array('title' => false, 'delay' => false, 'duration' => false, 'auto' => false), $attr));
	$html = '<div class="testimonial-slider" data-delay="'.$delay.'" data-duration="'.$duration.'" data-auto="'.$auto.'">';
	$html .= '<nav class="controls"><a href="#" class="prev">'.__('Previous', 'multipurpose').'</a><a href="#" class="next">'.__('Next', 'multipurpose').'</a></nav>';
	$html .= '<h2 class="underline"><span>'.$title.'</span></h2>';
	$html .= '<div class="slider-box">';
	$html .= str_replace('<br />', '', do_shortcode($content));
	$html .= '</div>';
	$html .= '</div>';
	return $html;
}

function multipurpose_testimonial_shortcodes() {
	add_shortcode('testimonial', 'multipurpose_testimonial');
	add_shortcode('testimonial_slider', 'multipurpose_testimonial_slider');
}

add_action('init', 'multipurpose_testimonial_shortcodes');