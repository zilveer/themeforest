<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Roundabout", "wish"),
    "description" => __("Roundabout Carousel with Images ", 'wish'),
    "controls" => "full",
    "base" => "wish_roundabout",
    "as_parent" => array('only' => 'wish_roundabout_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#ffffff', //Default color
            "description" => __( "Choose Background color", "wish" )
        ),



    ),

));//ends vc_map



//////////////child elements
vc_map( array(
    "name" => __("image", "wish"),
    "base" => "wish_roundabout_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_roundabout'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

         array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "value" => "Image",
            "admin_label" => false,    
        ),

         array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Lorem Ipsum är en utfyllnadstext från tryck- och förlagsindustrin. Lorem ipsum har varit standard ända.", 'wish'),
            "description" => __("Details", 'wish'),
            "admin_label" => false,
        ),

         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000', //Default color
            "description" => __( "Choose Description color", "wish" )
        ),


    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Roundabout extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'bgcolor' => '#ffffff',
          ), $atts ) );


          wp_enqueue_script('wish-roundabout', plugins_url('assets/jquery.roundabout.min.js', __FILE__), array('jquery') );


        $aaa = rtrim(do_shortcode($content), "``");

        $each = explode("``", $aaa);

        // $data = explode("||", $each);

        $data = array();
        // $data2 = array();

        $d1 = array();
        $d2 = array();
        $d3 = array();

        foreach ($each as $key => $value) {
              $data = explode("||", $value);  
              $d1[] = $data[0];
              $d2[] = $data[1];
              $d3[] = $data[2];
        }
        


      $output .= "
      <div class='roundabout'>
      <div id='carousel' style='background:{$bgcolor}'>";



      foreach ($d1 as $key => $value) {
            $output .=  $value;
      }
                   





       $output .=  "</div>
      <ul id='carousel-descriptions'>";

      foreach ($d2 as $key => $value) {
            $output .=  $value;
      }

      $output .=  "</ul>
      <div id='carousel-controls'>";

      foreach ($d3 as $key => $value) {
            $output .=  $value;
      }


        $output .= "</div>
                    </div>
                    ";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Roundabout_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image' => 'Image',
            'details' => 'Lorem Ipsum är en utfyllnadstext från tryck- och förlagsindustrin. Lorem ipsum har varit standard ända.',
            'details_color' => '#000',
          ), $atts ) );

          $img = wp_get_attachment_image_src( $image, 'full' );

          if($image == "Image"){
            $imgsrc = plugins_url('images/slide1.png', __FILE__);
            $img[0] = $imgsrc;
          }

          $output = "<img src='{$img[0]}' alt='' class='slide' /> || <li class='desc' style='color:{$details_color}'>{$details}</li> || <span class='control'></span>
 ``";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>