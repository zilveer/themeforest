<?php

/*
Plugin Name: MultiPurpose Shortcodes
Plugin URI: http://thememotive.com/
Description: Shortcodes for WordPress theme.
Version: 1.0.8
Author: ThemeMotive
Author URI: http://thememotive.com/
License: commercial
License URI: commercial
*/

if( !defined('_MULTIPURPOSE_SHORTCODE'))
{
    define('_MULTIPURPOSE_SHORTCODE',1);

    $plugin_dir_path = dirname(__FILE__);
    define('_MULTIPURPOSE_SHORTCODE_PLUGIN_PATH',$plugin_dir_path);
    define('_MULTIPURPOSE_SHORTCODE_PLUGIN_URL',plugin_dir_url( __file__ ));
    define('_MULTIPURPOSE_SHORTCODE_PLUGIN_LIBS_PATH',_MULTIPURPOSE_SHORTCODE_PLUGIN_PATH.DIRECTORY_SEPARATOR.'libs'.DIRECTORY_SEPARATOR);
    define('_MULTIPURPOSE_SHORTCODE_PLUGIN_SHORTCODES_PATH',_MULTIPURPOSE_SHORTCODE_PLUGIN_LIBS_PATH.'shortcodes'.DIRECTORY_SEPARATOR);

    function multipurpose_wp_gear_manager_admin_styles() 
    {
        wp_enqueue_style('style', _MULTIPURPOSE_SHORTCODE_PLUGIN_URL. 'libs/css/style.css',true);
    }

    add_action('admin_print_styles', 'multipurpose_wp_gear_manager_admin_styles');
    
    require_once(_MULTIPURPOSE_SHORTCODE_PLUGIN_LIBS_PATH.'index.php');
}
