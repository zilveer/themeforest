<?php 
	/* Price Table Group  ---------------------------------------------*/




	//Visual Composer
	
	
	add_shortcode('price_table_single', 'jx_ievent_price_table_single');
	
	function jx_ievent_price_table_single($atts, $content = null) { 
		extract(shortcode_atts(array(
				'type'=>'',
				'switch'=>'yes',
				'btn_1'=>'Standard',
				'btn_2'=>'VIP',
				'count'=>'',
					'standard_package_name' => 'Standard',
					'standard_price' => '209',
					'standard_sub_price' => '99',
					'standard_feature_a' => 'Conference Tickets',
					'standard_feature_b' => 'Easy Access',
					'standard_feature_c' => 'Printed Materials',
					'standard_feature_d' => 'Conference Tickets',
					'standard_feature_e' => 'Easy Access',
					'standard_feature_f' => 'Printed Materials',
					'standard_feature_g' => 'More Options',	
					'standard_feature_h' => 'More Options',	
					'standard_feature_i' => 'More Options',	
									
					'show_btn' =>'',
					'btn_text' =>'',
					'btn_link' =>'',
					'modal' =>''
	
				), $atts)); 
		 
		//initial variables
		$out=''; 
		
		$list_icon = "";
		
		if($type =="1") {
		$list_icon ="fa-chevron-right";
		} elseif ($type =="2") {
		$list_icon ="fa-check";
		} elseif ($type =="3") {
		$list_icon ="fa-chevron-right";		
		} elseif ($type =="4") {
		$list_icon ="fa-chevron-right";
		}
		
		
		$item_count='';
			$feature_list='';
			$vip_list=''; 
			$add_btn='';
			
			if($standard_feature_a):
			$feature_list ='<li><i class="fa '.$list_icon.'"></i>'.$standard_feature_a.'</li>';
			endif;
			
			if($standard_feature_b):
			$feature_list .='<li><i class="fa '.$list_icon.'"></i>'.$standard_feature_b.'</li>';
			endif;
			
			if($standard_feature_c):
			$feature_list .='<li><i class="fa '.$list_icon.'"></i>'.$standard_feature_c.'</li>';
			endif;
			
			if($standard_feature_d):		
			$feature_list .='<li><i class="fa '.$list_icon.'"></i>'.$standard_feature_d.'</li>';
			endif;
			
			if($standard_feature_e):
			$feature_list .='<li><i class="fa '.$list_icon.'"></i>'.$standard_feature_e.'</li>';
			endif;
			
			if($standard_feature_f):
			$feature_list .='<li><i class="fa '.$list_icon.'"></i>'.$standard_feature_f.'</li>';
			endif;
			
			if($standard_feature_g):
			$feature_list .='<li><i class="fa '.$list_icon.'"></i>'.$standard_feature_g.'</li>';
			endif;
			
			if($standard_feature_h):
			$feature_list .='<li><i class="fa '.$list_icon.'"></i>'.$standard_feature_h.'</li>';
			endif;
			
			if($standard_feature_i):
			$feature_list .='<li><i class="fa '.$list_icon.'"></i>'.$standard_feature_i.'</li>';
			endif;
		
			
			if($show_btn=='yes'):
			$add_btn='<div class="jx-ievent-price-btn"><a href="'.$btn_link.'">'.$btn_text.'</a></div>
			<!-- Button -->
			'.do_shortcode($content).'
			';
			elseif($modal=='yes'):
			$add_btn='<div class="jx-ievent-price-btn"><a href="#'.$btn_link.'" class="open-popup-link">'.$btn_text.'</a></div>
			<!-- Button -->
			'.do_shortcode($content).'
			';
			endif;		

		
		//function code
		
		if ($count==2):
			$item_count="two-item";
		elseif($count==3 or $count=''):
			$item_count="three-item";
		endif;  

		switch($type){ 
		case '1':
		
		$out .='
			<div class="jx-ievent-pricing-container '.$item_count.'">	
			<div class="jx-ievent-price-table">
				<ul class="jx-ievent-pricing-list jx-ievent-bounce-invert">
				
					<li>
						<ul class="jx-ievent-pricing-wrapper">
							<li data-type="standard" class="is-visible">
								
								<div class="jx-ievent-price-item">            
									<div class="jx-ievent-price">'.$standard_price.'<span>.'.$standard_sub_price.'</span></div>            
									<div class="jx-ievent-package-name jx-ievent-uppercase">'.$standard_package_name.'</div>            
									<div class="jx-ievent-package-feature">            
										<ul>            
											'.$feature_list.'	
										</ul>
									</div>
									'.$add_btn.'                        
								</div>					
								
							</li>							
						</ul>
						<!-- .jx-ievent-pricing-wrapper -->
					</li>
					
					<!-- Item 1 -->
				
				</ul>
			</div>
		</div>'; 
		
		break;
		
		case '2':
		
		$out .='
			<div class="jx-ievent-price-table jx-ievent-price-2">
			
				<div class="jx-ievent-head">					
					<div class="jx-ievent-package-name"><span>'.$standard_package_name.'</span></div>            
					<div class="jx-ievent-price"><span class="jx-ievent-dollar">$</span>'.$standard_price.'<span class="jx-ievent-sub-price">.'.$standard_sub_price.'</span></div>  
					'.$add_btn.'  
					
				</div>                     
													  
			</div>
			'; 

		break;

		case '3':
		
		$out .='
				<div class="jx-ievent-price-table jx-ievent-price-3">
				
					<div class="jx-ievent-head">
						<div class="jx-ievent-package-name">'.$standard_package_name.'</div>            
						<div class="jx-ievent-price">$ '.$standard_price.'<span>.'.$standard_sub_price.'</span></div>  
					</div>                      

					<div class="jx-ievent-package-feature">            
						<ul>            
						'.$feature_list.'	
						</ul>
					</div>
					
					'.$add_btn.'  
					                      
				</div>
			'; 

		break;
		
		case '4':
		
		$out .='
				<div class="jx-ievent-price-table jx-ievent-price-4">
				
					<div class="jx-ievent-head">
						<div class="jx-ievent-package-name">'.$standard_package_name.'</div>            
						<div class="jx-ievent-price">$ '.$standard_price.'<span>.'.$standard_sub_price.'</span></div>  
					</div>                      

					<div class="jx-ievent-package-feature">            
						<ul>            
						'.$feature_list.'	
						</ul>
					</div>
					
					'.$add_btn.'  
					                      
				</div>
			'; 

		break;

		
		}

		
		//return output
		return $out;
	}
	
	
	
	add_action( 'vc_before_init', 'vc_price_table_single' );
	
	
	function vc_price_table_single() {	
		vc_map(array(
      "name" => esc_html__( "Price Table", "TEXT_DOMAIN" ),
      "base" => "price_table_single",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_speaker.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Add Price Table','TEXT_DOMAIN'),
      "params" => array(
		 		 
				 
				 
		array(
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => __("Select Your Price Table Style",'TEXT_DOMAIN'),
			 "param_name" => "type",
			 "value" => array(   
				__('Select Your Style', 'TEXT_DOMAIN') => 'Select Your Price Table Style',
				__('Style A', 'TEXT_DOMAIN') => '1',
				__('Style B', 'TEXT_DOMAIN') => '2',
				__('Style C', 'TEXT_DOMAIN') => '3',
				__('Style D', 'TEXT_DOMAIN') => '4',
					),
		),

        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Package Name", "TEXT_DOMAIN" ),
            "param_name" => "standard_package_name",
			"value" => "Standard", //Default Counter Up Text
            "description" => esc_html__( "Type Title Here", "TEXT_DOMAIN" )
         ),
		 
		 
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Price", "TEXT_DOMAIN" ),
            "param_name" => "standard_price",
			"value" => "209", //Default Counter Up Text
            "description" => esc_html__( "Type Price Here", "TEXT_DOMAIN" )
         ),
		 
		 
    	array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Sub Price", "TEXT_DOMAIN" ),
            "param_name" => "standard_sub_price",
			"value" => "99", //Default Counter Up Text
            "description" => esc_html__( "Type Sub Price Here", "TEXT_DOMAIN" )
         ),
		 
		 
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Feature A", "TEXT_DOMAIN" ),
            "param_name" => "standard_feature_a",
			"value" => "Conference Tickets", //Default Counter Up Text
            "description" => esc_html__( "Type Your Text Here", "TEXT_DOMAIN" )
         ),
		 
		 
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Feature B", "TEXT_DOMAIN" ),
            "param_name" => "standard_feature_b",
			"value" => "Easy Access", //Default Counter Up Text
            "description" => esc_html__( "Type Your Text Here", "TEXT_DOMAIN" )
         ),
		 
		 
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Feature C", "TEXT_DOMAIN" ),
            "param_name" => "standard_feature_c",
			"value" => "Printed Materials", //Default Counter Up Text
            "description" => esc_html__( "Type Your Text Here", "TEXT_DOMAIN" )
         ),
		 
		 
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Feature D", "TEXT_DOMAIN" ),
            "param_name" => "standard_feature_d",
			"value" => "Conference Tickets", //Default Counter Up Text
            "description" => esc_html__( "Type Your Text Here", "TEXT_DOMAIN" )
         ),
		 
		 
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Feature E", "TEXT_DOMAIN" ),
            "param_name" => "standard_feature_e",
			"value" => "Easy Access", //Default Counter Up Text
            "description" => esc_html__( "Type Your Text Here", "TEXT_DOMAIN" )
         ),
		 
		 
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Feature F", "TEXT_DOMAIN" ),
            "param_name" => "standard_feature_f",
			"value" => "Printed Materials", //Default Counter Up Text
            "description" => esc_html__( "Type Your Text Here", "TEXT_DOMAIN" )
         ),
		 
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Feature G", "TEXT_DOMAIN" ),
            "param_name" => "standard_feature_g",
			"value" => "More Options", //Default Counter Up Text
            "description" => esc_html__( "Type Your Text Here", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Feature H", "TEXT_DOMAIN" ),
            "param_name" => "standard_feature_h",
			"value" => "More Options", //Default Counter Up Text
            "description" => esc_html__( "Type Your Text Here", "TEXT_DOMAIN" )
         ),
		 
		 array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Standard Feature I", "TEXT_DOMAIN" ),
            "param_name" => "standard_feature_i",
			"value" => "More Options", //Default Counter Up Text
            "description" => esc_html__( "Type Your Text Here", "TEXT_DOMAIN" )
         ),
		 	    
		 
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Button Text", "TEXT_DOMAIN" ),
            "param_name" => "btn_text",
			"value" => "Buy Now", //Default Counter Up Text
            "description" => esc_html__( "Type Your Text Here", "TEXT_DOMAIN" )
         ),
		 
	
	    array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "button Link", "TEXT_DOMAIN" ),
            "param_name" => "btn_link",
			"value" => "#", //Default Counter Up Text
            "description" => esc_html__( "Type Your Text Here", "TEXT_DOMAIN" )
         ),
		 
		 
		 array(
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => __("Show Button",'TEXT_DOMAIN'),
			 "param_name" => "show_btn",
			 "value" => array(   
					__('No', 'TEXT_DOMAIN') => 'no',
					__('Yes', 'TEXT_DOMAIN') => 'yes',
					),
		),
		 
		
      )
   )); 
	}

?>