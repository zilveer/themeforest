<?php 
/*
* Plugin Name: TL Layers Handyman Plugin
* Version: 1.5.1
* Plugin URI: http://www.themelaboratory.com/
* Description: Add 9 Widget for LayersWP Builder(Extended Layers Content Widget, Pricing Table, Services and Blog Tips...). Add 2 Standard WP Widgets (TL Recent Posts, TL Recent Tweets). CPTs(Testimonials, Services and Portfolio Cpt.)
* Author: Theme Laboratory
* Author URI: http://www.themelaboratory.com/
* Text Domain: layers-insert-staff
*
* WordPress -
* Requires at least: 4.2
* Tested up to: 4.4.1
*
* Layers - 
* Requires at least 1.2.11
* Tested up to: 1.2.13
*
* LICENSE:
*
* Copyright 2015  ThemeLaboratory  (email : milos@themelaboratory.com)
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License, version 2, as 
* published by the Free Software Foundation.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*
* GNU General Public License for more details.
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
if ( ! defined( 'ABSPATH' ) ) exit;

// define constants (optional)
define( 'TL_INSERT_STAFF_REQ_PHP'    , '5.4'  );
define( 'TL_INSERT_STAFF_REQ_WP'     , '4.3' );
define( 'TL_INSERT_STAFF_REQ_LAYERS' , '1.5');

define( 'TL_INSERT_STAFF_FILE' , __FILE__ );
define( 'TL_INSERT_STAFF_DIR' , plugin_dir_path( __FILE__ ) );
define( 'TL_INSERT_STAFF_URI' , plugin_dir_url( __FILE__ ) );
define( 'TL_INSERT_STAFF_VER' , '1.5.1' );

define( 'TL_INSERT_STAFF_BASE', trim(plugin_basename(TL_INSERT_STAFF_DIR)));
define( 'TL_INSERT_STAFF_SLUG', TL_INSERT_STAFF_BASE );

// Minimize markup code on admin side in customizer
define('TL_INSERT_STAFF_WIDGET_FORM_MIN', true);

// --- Load plugin class & function files ---

require_once 'inc/helpers.php';


// Register new CPTs && related metaboxes
require_once 'inc/post-types/class.services-post-type.php';
require_once 'inc/post-types/class.portfolio-post-type.php';
require_once 'inc/post-types/class.testimonials-post-type.php';
require_once 'inc/post-types/class.team-post-type.php';

// Filters related to layers widgets
//require_once 'widgets/filters.php';

// Ajax
require_once 'inc/ajax.php';

// Plugin class
require_once 'inc/class.layers-insert-staff.php';

// Instantiate Plugin
global $tl_layers_insert_staff_extension;
$tl_layers_insert_staff_extension = TL_Layers_Insert_Staff::single();