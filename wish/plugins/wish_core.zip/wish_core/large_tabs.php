<?php  
// Plain Hero, no images and stuff
class Wish_Vertical_Tabs {

        var $shortcode = 'wish_vertical_tabs';
        var $title = "Giant Tabs";
        var $details = "Giant Vertical Tabs";
        // var $settings = array();
        //var $path = "/templates/rating_hero.php";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link"  => "http://i.imgur.com/FR7rXpg.png",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'wish'),
            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor
            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
            "params" => array(
                                        // fields for tab 1
                                        array(
                                            "type" => "textfield",
                                            "heading" => __("Title Tab 1", "wish"),
                                            "param_name" => "title_1",
                                            "description" => __("Title For Tab 1", "wish"),
                                            "value" => __("UI/UX Design", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 1",
                                        ), 

                                        array(
                                            "type" => "textfield",
                                            "heading" => __("Sub Title Tab 1", "wish"),
                                            "param_name" => "sub_title_1",
                                            "description" => __("Subtitle For Tab 1", "wish"),
                                            "value" => __("we are strategists designers.", "wish"),
                                            "admin_label" => false,
                                            "group"        => "Tab 1",
                                        ),

                                        array(
                                            "type" => "wish_fontawesome_param",
                                            "heading" => __("Icon For Tab 1", "wish"),
                                            "param_name" => "icon_1",
                                            "description" => __("The Icon code from Font Awesome For Tab 1", "wish"),
                                            "value" => __("fa-paper-plane-o", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 1",
                                        ),


                                        array(
                                            "type" => "textarea",
                                            "holder" => "div",
                                            "class" => "",
                                            "heading" => __("Details For Tab 1", 'wish'),
                                            "param_name" => "details_1",
                                            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
                                            "description" => __("The Details", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 1",
                                        ),


                                        array(
                                            "type" => "textarea",
                                            "holder" => "div",
                                            "class" => "",
                                            "heading" => __("More Details For Tab 1", 'wish'),
                                            "param_name" => "more_details_1",
                                            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
                                            "description" => __("The details on the left side when the tab was clicked", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 1",
                                        ),


                                        // ends fields for tab 1        





                                        // fields for tab 2
                                        array(
                                            "type" => "textfield",
                                            "heading" => __("Title Tab 2", "wish"),
                                            "param_name" => "title_2",
                                            "description" => __("Title For Tab 2", "wish"),
                                            "value" => __("UI/UX Design", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 2",
                                        ), 


                                        array(
                                            "type" => "textfield",
                                            "heading" => __("Sub Title Tab 2", "wish"),
                                            "param_name" => "sub_title_2",
                                            "description" => __("Subtitle For Tab 2", "wish"),
                                            "value" => __("we are strategists designers.", "wish"),
                                            "admin_label" => false,
                                            "group"        => "Tab 2",
                                        ),

                                        array(
                                            "type" => "wish_fontawesome_param",
                                            "heading" => __("Icon For Tab 2", "wish"),
                                            "param_name" => "icon_2",
                                            "description" => __("The Icon code from Font Awesome For Tab 2", "wish"),
                                            "value" => __("fa-paper-plane-o", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 2",
                                        ),


                                        array(
                                            "type" => "textarea",
                                            "holder" => "div",
                                            "class" => "",
                                            "heading" => __("Details", 'wish'),
                                            "param_name" => "details_2",
                                            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
                                            "description" => __("The Details", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 2",
                                        ),


                                        array(
                                            "type" => "textarea",
                                            "holder" => "div",
                                            "class" => "",
                                            "heading" => __("More Details For Tab 2", 'wish'),
                                            "param_name" => "more_details_2",
                                            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
                                            "description" => __("The details on the left side when the tab was clicked", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 2",
                                        ),



                                        // ends fields for tab 2 




                                        // fields for tab 3
                                        array(
                                            "type" => "textfield",
                                            "heading" => __("Title Tab 3", "wish"),
                                            "param_name" => "title_3",
                                            "description" => __("Title For Tab 3", "wish"),
                                            "value" => __("UI/UX Design", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 3",
                                        ), 

                                        array(
                                            "type" => "textfield",
                                            "heading" => __("Sub Title Tab 3", "wish"),
                                            "param_name" => "sub_title_3",
                                            "description" => __("Subtitle For Tab 3", "wish"),
                                            "value" => __("we are strategists designers.", "wish"),
                                            "admin_label" => false,
                                            "group"        => "Tab 3",
                                        ),


                                        array(
                                            "type" => "wish_fontawesome_param",
                                            "heading" => __("Icon For Tab 3", "wish"),
                                            "param_name" => "icon_3",
                                            "description" => __("The Icon code from Font Awesome For Tab 3", "wish"),
                                            "value" => __("fa-paper-plane-o", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 3",
                                        ),


                                        array(
                                            "type" => "textarea",
                                            "holder" => "div",
                                            "class" => "",
                                            "heading" => __("Details", 'wish'),
                                            "param_name" => "details_3",
                                            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
                                            "description" => __("The Details", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 3",
                                        ),


                                        array(
                                            "type" => "textarea",
                                            "holder" => "div",
                                            "class" => "",
                                            "heading" => __("More Details For Tab 3", 'wish'),
                                            "param_name" => "more_details_3",
                                            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
                                            "description" => __("The details on the left side when the tab was clicked", 'wish'),
                                            "admin_label" => false,
                                            "group"        => "Tab 3",
                                        ),


                                        // ends fields for tab 3 

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Icon Color", "wish" ),
                                            "param_name" => "icon_color",
                                            "value" => '#43b573', //Default Black color
                                            "description" => __( "Choose Icon color", "wish" ),
                                            "admin_label" => false,
                                            "group"        => "Fonts & Colors",
                                        ),


                                        /*Title*/
                                        array(
                                            "type" => "google_fonts",
                                            "class" => "",
                                            "heading" => __( "Title Text Font", "wish" ),
                                            "param_name" => "title_font",
                                            "value" => '', //Default Red color
                                            "description" => __( "Choose Font", "wish" ),
                                            "group"   => "Fonts & Colors",
                                            'settings' => array(
                                                 'fields'=>array(
                                                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                               )
                                            )       
                                        ),


                                        array(
                                            "type" => "wish_number",
                                            "heading" => __("Title Font Size", "wish"),
                                            "param_name" => "title_size",
                                            "description" => __("Font size in px", "wish"),
                                            "value" => __("18", 'wish'),
                                            "admin_label" => true,
                                            "group"       => "Fonts & Colors",
                                        ),

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Title Text Color", "wish" ),
                                            "param_name" => "title_color",
                                            "value" => '#fff', //Default Black color
                                            "description" => __( "Choose text color", "wish" ),
                                            "admin_label" => false,
                                            "group"        => "Fonts & Colors",
                                        ),

                                        /*Title 2*/
                                        array(
                                            "type" => "google_fonts",
                                            "class" => "",
                                            "heading" => __( "Title 2 Text Font", "wish" ),
                                            "param_name" => "title2_font",
                                            "value" => '', //Default Red color
                                            "description" => __( "Choose Font", "wish" ),
                                            "group"   => "Fonts & Colors",
                                            'settings' => array(
                                                 'fields'=>array(
                                                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                               )
                                            )       
                                        ),


                                        array(
                                            "type" => "wish_number",
                                            "heading" => __("Title 2 Font Size", "wish"),
                                            "param_name" => "title2_size",
                                            "description" => __("Font size in px", "wish"),
                                            "value" => __("30", 'wish'),
                                            "admin_label" => true,
                                            "group"       => "Fonts & Colors",
                                        ),

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Title 2 Text Color", "wish" ),
                                            "param_name" => "title2_color",
                                            "value" => '#df4322', //Default Black color
                                            "description" => __( "Choose text color", "wish" ),
                                            "admin_label" => false,
                                            "group"        => "Fonts & Colors",
                                        ),


                                        /*Subtitle*/
                                        array(
                                            "type" => "google_fonts",
                                            "class" => "",
                                            "heading" => __( "SubTitle Text Font", "wish" ),
                                            "param_name" => "subtitle_font",
                                            "value" => '', //Default Red color
                                            "description" => __( "Choose Font", "wish" ),
                                            "group"   => "Fonts & Colors",
                                            'settings' => array(
                                                 'fields'=>array(
                                                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                               )
                                            )       
                                        ),


                                        array(
                                            "type" => "wish_number",
                                            "heading" => __("SubTitle Font Size", "wish"),
                                            "param_name" => "subtitle_size",
                                            "description" => __("Font size in px", "wish"),
                                            "value" => __("70", 'wish'),
                                            "admin_label" => true,
                                            "group"       => "Fonts & Colors",
                                        ),

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Subtitle Text Color", "wish" ),
                                            "param_name" => "subtitle_color",
                                            "value" => '#000000', //Default Black color
                                            "description" => __( "Choose text color", "wish" ),
                                            "admin_label" => false,
                                            "group"        => "Fonts & Colors",
                                        ),



                                        /*Details*/
                                        array(
                                            "type" => "google_fonts",
                                            "class" => "",
                                            "heading" => __( "Details Text Font", "wish" ),
                                            "param_name" => "details_font",
                                            "value" => '', //Default Red color
                                            "description" => __( "Choose Font", "wish" ),
                                            "group"   => "Fonts & Colors",
                                            'settings' => array(
                                                 'fields'=>array(
                                                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                               )
                                            )       
                                        ),


                                        array(
                                            "type" => "wish_number",
                                            "heading" => __("Details Font Size", "wish"),
                                            "param_name" => "details_size",
                                            "description" => __("Font size in px", "wish"),
                                            "value" => __("14", 'wish'),
                                            "admin_label" => true,
                                            "group"       => "Fonts & Colors",
                                        ),

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Details Text Color", "wish" ),
                                            "param_name" => "details_color",
                                            "value" => '#000000', //Default Black color
                                            "description" => __( "Choose text color", "wish" ),
                                            "admin_label" => false,
                                            "group"        => "Fonts & Colors",
                                         ),



                                        /*More Details*/
                                        array(
                                            "type" => "google_fonts",
                                            "class" => "",
                                            "heading" => __( "More Details Text Font", "wish" ),
                                            "param_name" => "more_details_font",
                                            "value" => '', //Default Red color
                                            "description" => __( "Choose Font", "wish" ),
                                            "group"   => "Fonts & Colors",
                                            'settings' => array(
                                                 'fields'=>array(
                                                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                               )
                                            )       
                                        ),


                                        array(
                                            "type" => "wish_number",
                                            "heading" => __("More Details Font Size", "wish"),
                                            "param_name" => "more_details_size",
                                            "description" => __("Font size in px", "wish"),
                                            "value" => __("14", 'wish'),
                                            "admin_label" => true,
                                            "group"       => "Fonts & Colors",
                                        ),

                                         array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "More Details Text Color", "wish" ),
                                            "param_name" => "more_details_color",
                                            "value" => '#000000', //Default Black color
                                            "description" => __( "Choose text color", "wish" ),
                                            "admin_label" => false,
                                            "group"        => "Fonts & Colors",
                                         ),

                                         /*Background*/
                                         array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Background Color", "wish" ),
                                            "param_name" => "bgcolor",
                                            "value" => '#fff',
                                            "description" => __( "Choose the background color", "wish" ),
                                            "admin_label" => false,
                                            "group"        => "Fonts & Colors",
                                        ),


                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Background Gradient Color 1", "wish" ),
                                            "param_name" => "bgcolor1",
                                            "value" => '#9b2920', //Default Red color
                                            "description" => __( "Choose background gradient color 1", "wish" ),
                                            "admin_label" => false,
                                            "group"        => "Fonts & Colors",
                                        ), 

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Background Gradient Color 2", "wish" ),
                                            "param_name" => "bgcolor2",
                                            "value" => '#ec5022', //Default Red color
                                            "description" => __( "Choose background gradient color 2", "wish" ),
                                            "admin_label" => false,
                                            "group"        => "Fonts & Colors",
                                        ),

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Background Gradient Color 3", "wish" ),
                                            "param_name" => "bgcolor3",
                                            "value" => '#f5a21f', //Default Red color
                                            "description" => __( "Choose background gradient color 3", "wish" ),
                                            "admin_label" => false,
                                            "group"        => "Fonts & Colors",
                                        ), 

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Background Gradient Color 4", "wish" ),
                                            "param_name" => "bgcolor4",
                                            "value" => '#f69420', //Default Red color
                                            "description" => __( "Choose background gradient color 4", "wish" ),
                                            "admin_label" => false,
                                            "group"        => "Fonts & Colors",
                                        ), 


                                        // ends fields for tab 3 


                    )
        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title_1'        => 'UI/UX Design',
        'title_2'        => 'Web',
        'title_3'        => 'Photography',

        'sub_title_1'    => 'we are strategists designers.',
        'sub_title_2'    => 'we are strategists designers.',
        'sub_title_3'    => 'we are strategists designers.',

        'icon_1'         => 'icon 1',
        'icon_2'         => 'icon 2',
        'icon_3'         => 'icon 3',

        'details_1'      => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever.',
        'details_2'      => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever.',
        'details_3'      => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever.',

        'more_details_1' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever.',
        'more_details_2' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever.',
        'more_details_3' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever.',


        'title_font'        => '',
        'title2_font'       => '',
        'subtitle_font'     => '',
        'details_font'      => '',
        'more_details_font' => '',

        'title_size'        => '18',
        'title2_size'       => '30',
        'subtitle_size'     => '70',
        'details_size'      => '14',
        'more_details_size' => '14',

        'icon_color'            => '#43b573',
        'title_color'           => '#fff',
        'title2_color'           => '#df4322',
        'subtitle_color'        => '#000',
        'details_color'         => '#000',
        'more_details_color'    => '#000',

        'bgcolor'   => '#fff',
        'bgcolor1'  => '#9b2920',
        'bgcolor2'  => '#ec5022',
        'bgcolor3'  => '#f5a21f',
        'bgcolor4'  => '#f69420',
        'css'       => '',


      ), $atts ) );

    /*Title*/
    $decode_font = urldecode($title_font);
    $decode_font = explode('|', $decode_font);
    $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
    preg_match("/family=(.*):/", $font_string, $output_array);
    $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

    wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


    /*Title2*/
    $decode_font = urldecode($title2_font);
    $decode_font = explode('|', $decode_font);
    $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
    preg_match("/family=(.*):/", $font_string, $output_array);
    $title2_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

    wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


    /*SubTitle*/
    $decode_font = urldecode($subtitle_font);
    $decode_font = explode('|', $decode_font);
    $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
    preg_match("/family=(.*):/", $font_string, $output_array);
    $subtitle_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

    wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


    /*Details*/
    $decode_font = urldecode($details_font);
    $decode_font = explode('|', $decode_font);
    $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
    preg_match("/family=(.*):/", $font_string, $output_array);
    $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

    wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


    /*More Details*/
    $decode_font = urldecode($more_details_font);
    $decode_font = explode('|', $decode_font);
    $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
    preg_match("/family=(.*):/", $font_string, $output_array);
    $more_details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

    wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );




       $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' )); 

      $output = "";

      $output .= "
      <style>
        .services h3{font-family:{$title2_font_family};font-size:{$title2_size}px;color:{$title2_color}}
        .services h1{font-family:{$subtitle_font_family};font-size:{$subtitle_size}px;color:{$subtitle_color}}
        .services .description{font-family:{$more_details_font_family};font-size:{$more_details_size}px;color:{$more_details_color}}
        .services-tabs ul li h3{font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}}
        .services-tabs ul li.active h3, .services-tabs ul li:hover h3{color:#ffffff}
        .services-tabs ul li a:hover, .services-tabs ul li:hover a{color:#ffffff;}
        .services-tabs ul li .description{font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}}
        .services-tabs ul li:hover .description,.services-tabs ul li.active .description{color:#ffffff;}
        .services-tabs ul li:hover{color:#ffffff;}

        .services-tabs ul li.active, .services-tabs ul li:hover {
            background: {$bgcolor1};
            background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJod…EiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
            background: -moz-linear-gradient(left, {$bgcolor1} 0%, {bgcolor2} 30%, {bgcolor3} 70%, {$bgcolor4} 100%);
            background: -webkit-gradient(linear, left top, right top, color-stop(0%, {$bgcolor1}), color-stop(30%, {$bgcolor2}), color-stop(70%, {bgcolor3}), color-stop(100%, #{$bgcolor4}));
            background: -webkit-linear-gradient(left, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            background: -o-linear-gradient(left, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            background: -ms-linear-gradient(left, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            background: linear-gradient(to right, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='{$bgcolor1}', endColorstr='{$bgcolor4}', GradientType=1 );
        }

      </style>
      <div class='services {$css_class}' style='background-color:{$bgcolor}'>
            <div class='container'>
                <div class='row services-tabs'>
                   
                    <div class='col-lg-6 pull-right'>
                        <ul class='nav nav-pills nav-stacked'>


                            <li class='active animated' data-animation='fadeInUp' data-animation-delay='600'>
                                <div class='point'></div>
                                <a href='#uiux' data-toggle='tab' title=''>
                                    <div class='icon' style='color:{$icon_color}'><i class='fa {$icon_1}'></i></div>
                                    <div class='info'>
                                        <h3>{$title_1}</h3>
                                        <div class='description'>{$details_1}</div>
                                    </div>
                                </a>
                            </li>

                            <li class='animated' data-animation='fadeInUp' data-animation-delay='1000'>
                                <div class='point'></div>
                                <a href='#web' data-toggle='tab' title=''>
                                    <div class='icon' style='color:{$icon_color}'><i class='fa {$icon_2}'></i></div>
                                    <div class='info'>
                                        <h3>{$title_2}</h3>
                                        <div class='description'>{$details_2}</div>
                                    </div>
                                </a>
                            </li>


                            <li class='animated' data-animation='fadeInUp' data-animation-delay='1400'>
                                <div class='point'></div>
                                <a href='#photography' data-toggle='tab' title=''>
                                    <div class='icon' style='color:{$icon_color}'><i class='fa {$icon_3}'></i></div>
                                    <div class='info'>
                                        <h3>{$title_3}</h3>
                                        <div class='description'>{$details_3}</div>
                                    </div>
                                </a>
                            </li>



                        </ul>
                    </div>

                    <div class='col-lg-6 pull-left'>
                        <div class='tab-content'>

                            <div class='tab-pane fade in active' id='uiux'>
                                <h3 class='animated' data-animation='fadeInRight' data-animation-delay='100'>{$title_1}</h3>
                                <h1 class='animated' data-animation='fadeInRight' data-animation-delay='400'>{$sub_title_1}</h1>
                                <div class='description animated' data-animation='fadeInRight' data-animation-delay='800'>{$more_details_1}</div>
                            </div>

                            <div class='tab-pane fade in' id='web'>
                                <h3 class='animated' data-animation='fadeInRight' data-animation-delay='100'>{$title_2}</h3>
                                <h1 class='animated' data-animation='fadeInRight' data-animation-delay='400'>{$sub_title_2}</h1>
                                <div class='description animated' data-animation='fadeInRight' data-animation-delay='800'>{$more_details_2}</div>
                            </div>

                            <div class='tab-pane fade in' id='photography'>
                                <h3 class='animated' data-animation='fadeInRight' data-animation-delay='100'>{$title_3}</h3>
                                <h1 class='animated' data-animation='fadeInRight' data-animation-delay='400'>{$sub_title_3}</h1>
                                <div class='description animated' data-animation='fadeInRight' data-animation-delay='800'>{$more_details_3}</div>
                            </div>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>";


      return $output;
    }

    /*
    Load plugin css and javascript files which you may need on front end of your site
    */
    public function loadCssAndJs() {
      wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
      wp_enqueue_style( 'vc_extend_style' );

      // If you need any javascript files on front end, here is how you can load them.
      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );
    }

    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }


    public function outputTitleTrue( $title ) {
        return '<h4 class="wpb_element_title">' . __( $title, 'js_composer' ) . ' ' . $this->settings( 'logo' ) . '</h4>';
    }





}//end of class
?>