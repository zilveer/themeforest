<?php

add_action('init', 'tb_grid_integrateWithVC');

function tb_grid_integrateWithVC() {
    vc_map(array(
        "name" => __("Grid", 'jwsthemes'),
        "base" => "tb_grid",
        "class" => "tb-grid",
        "category" => __('Aqua', 'jwsthemes'),
        "icon" => "tb-icon-for-vc",
        "params" => array(
            array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => __("Post Type", 'jwsthemes'),
                "param_name" => "post_type",
                "value" => array(
                    "Post" => "post",
                    "Portfolio" => "portfolio",
                ),
				"description" => __('Select post type on your grid.', 'jwsthemes')
            ),
			array (
				"type" => "tb_taxonomy",
				"taxonomy" => "category",
				"dependency" => array(
					"element"=>"post_type",
					"value"=>"post"
					)
				,
				"heading" => __ ( "Categories", 'jwsthemes' ),
				"param_name" => "category",
				"class" => "post_category",
				"description" => __ ( "Note: By default, all your projects will be displayed. <br>If you want to narrow output, select category(s) above. Only selected categories will be displayed.", 'jwsthemes' )
			),
			array (
				"type" => "tb_taxonomy",
				"taxonomy" => "portfolio_category",
				"dependency" => array(
					"element"=>"post_type",
					"value"=>"portfolio"
					)
				,
				"heading" => __ ( "Categories", 'jwsthemes' ),
				"param_name" => "portfolio_category",
				"class" => "post_category",
				"description" => __ ( "Note: By default, all your projects will be displayed. <br>If you want to narrow output, select category(s) above. Only selected categories will be displayed.", 'jwsthemes' )
			),
			array (
				"type" => "textfield",
				"heading" => __ ( 'Number of posts to show', 'jwsthemes' ),
				"param_name" => "posts_per_page",
				'value' => '-1',
				"description" => __ ( 'The number of posts to display. Set to "-1" for display all posts on the page.', 'jwsthemes' )
			),
            array(
                "type" => "checkbox",
                "heading" => __('Show Filter', 'jwsthemes'),
                "param_name" => "show_filter",
                "value" => array(
                    __("Yes, please", 'jwsthemes') => 1
                ),
                "description" => __('Show or hide filter on your grid.', 'jwsthemes')
            ),
			array(
                "type" => "checkbox",
                "heading" => __('Show Sorter', 'jwsthemes'),
                "param_name" => "show_sorter",
                "value" => array(
                    __("Yes, please", 'jwsthemes') => 1
                ),
                "description" => __('Show or hide sorter on your grid.', 'jwsthemes')
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Columns", 'jwsthemes'),
                "param_name" => "columns",
                "value" => array(
                    "4 Columns" => "4",
                    "3 Columns" => "3",
                    "2 Columns" => "2",
                    "1 Column" => "1",
                ),
				"description" => __('Select columns of grid.', 'jwsthemes')
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Template", 'jwsthemes'),
                "param_name" => "tpl",
                "value" => array(
                    "Template 1" => "tpl1",
                ),
                "description" => __('Select template on your grid.', 'jwsthemes')
            ),
			array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Padding Item", 'jwsthemes'),
                "param_name" => "padding_item",
                "value" => "",
                "description" => __("Please, Enter number width 'px' for padding item on your grid. Ex: 5px;", 'jwsthemes')
            ),
            array(
                "type" => "checkbox",
                "heading" => __('Crop image', 'jwsthemes'),
                "param_name" => "crop_image",
                "value" => array(
                    __("Yes, please", 'jwsthemes') => true
                ),
                "description" => __('Crop or not crop image on your Post.', 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "heading" => __('Width image', 'jwsthemes'),
                "param_name" => "width_image",
                "description" => __('Enter the width of image. Default: 300.', 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "heading" => __('Height image', 'jwsthemes'),
                "param_name" => "height_image",
                "description" => __('Enter the height of image. Default: 200.', 'jwsthemes')
            ),
            array(
                "type" => "checkbox",
                "heading" => __('Show Title', 'jwsthemes'),
                "param_name" => "show_title",
                "value" => array(
                    __("Yes, please", 'jwsthemes') => true
                ),
                "description" => __('Show or hide title of post on your grid.', 'jwsthemes')
            ),
            array(
                "type" => "checkbox",
                "heading" => __('Show Description', 'jwsthemes'),
                "param_name" => "show_description",
                "value" => array(
                    __("Yes, please", 'jwsthemes') => true
                ),
                "description" => __('Show or hide description of post on your grid.', 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "heading" => __('Excerpt Length', 'jwsthemes'),
                "param_name" => "excerpt_length",
                "value" => '',
                "description" => __('The length of the excerpt, number of words to display.', 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "heading" => __('Excerpt More', 'jwsthemes'),
                "param_name" => "excerpt_more",
                "value" => "",
                "description" => __('Excerpt More', 'jwsthemes')
            ),
            array(
                "type" => "dropdown",
                "heading" => __('Order by', 'jwsthemes'),
                "param_name" => "orderby",
                "value" => array(
                    "None" => "none",
                    "Title" => "title",
                    "Date" => "date",
                    "ID" => "ID"
                ),
                "description" => __('Order by ("none", "title", "date", "ID").', 'jwsthemes')
            ),
            array(
                "type" => "dropdown",
                "heading" => __('Order', 'jwsthemes'),
                "param_name" => "order",
                "value" => Array(
                    "None" => "none",
                    "ASC" => "ASC",
                    "DESC" => "DESC"
                ),
                "description" => __('Order ("None", "Asc", "Desc").', 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Extra Class", 'jwsthemes'),
                "param_name" => "el_class",
                "value" => "",
                "description" => __ ( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'jwsthemes' )
            ),
        )
    ));
}
