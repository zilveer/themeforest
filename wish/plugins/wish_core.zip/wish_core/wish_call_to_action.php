<?php  /*IJAZ AHMAD*/
// Plain Hero, no images and stuff
class Wish_Wish_Call_To_Action{

        var $shortcode = 'wish_wish_call_to_action';
        var $title = "Wish Call To Action";
        var $details = "Wish Call To Action with a text";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link"  => "http://i.imgur.com/Q0jWkQf.png",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'wish'),
            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor
            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
            "params" => array(

                            array(
                                "type" => "textfield",
                                "heading" => __("Title", "wish"),
                                "param_name" => "title",
                                "description" => __("The Title.", "wish"),
                                "value" => __("Want to work with us?", 'wish'),
                                "admin_label" => true,
                            ),

                            array(
                                "type" => "textarea",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Details", 'wish'),
                                "param_name" => "details",
                                "value" => __("Get in touch and we�ll walk you through the rest.", 'wish'),
                                "description" => __("Details", 'wish'),
                                "admin_label" => false,
                            ),

                            array(
                                "type" => "vc_link",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Link To The Page", 'wish'),
                                "param_name" => "link",
                                "description" => __("The Link below the text", 'wish'),
                                "admin_label" => false,
                            ),

                            array(
                                "type" => "textfield",
                                "heading" => __("Link Title", "wish"),
                                "param_name" => "link_text",
                                "description" => __("The Link Title", "wish"),
                                "value" => __("Get in Touch", 'wish'),
                                "admin_label" => false,
                            ),


                            /*Title*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __("Title Text Font", "wish" ),
                                "param_name" => "title_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Title Size", "wish"),
                                "param_name" => "title_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("40", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __("Title Text Color", "wish" ),
                                "param_name" => "title_color",
                                "value" => '#fff ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),


                            /*Details*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __("Details Text Font", "wish" ),
                                "param_name" => "details_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Details Size", "wish"),
                                "param_name" => "details_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("20", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __("Details Text Color", "wish" ),
                                "param_name" => "details_color",
                                "value" => '#fff ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),


                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __("Burron font Color", "wish" ),
                                "param_name" => "but_font_color",
                                "value" => '#fff ', //Default Black color
                                "description" => __( "Choose button font color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),




                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __("Button border Color", "wish" ),
                                "param_name" => "but_border_color",
                                "value" => '#fff ', //Default Black color
                                "description" => __( "Choose button border color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),



                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Background Gradient Color 1", "wish" ),
                                "param_name" => "bgcolor1",
                                "value" => '#9b2920', //Default Red color
                                "description" => __( "Choose background gradient color 1", "wish" ),
                                "group"         => "Fonts & Colors",
                            ), 
                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Background Gradient Color 2", "wish" ),
                                "param_name" => "bgcolor2",
                                "value" => '#ec5022', //Default Red color
                                "description" => __( "Choose background gradient color 2", "wish" ),
                                "group"         => "Fonts & Colors",
                            ),
                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Background Gradient Color 3", "wish" ),
                                "param_name" => "bgcolor3",
                                "value" => '#f5a21f', //Default Red color
                                "description" => __( "Choose background gradient color 3", "wish" ),
                                "group"         => "Fonts & Colors",
                            ), 
                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Background Gradient Color 4", "wish" ),
                                "param_name" => "bgcolor4",
                                "value" => '#f69420', //Default Red color
                                "description" => __( "Choose background gradient color 4", "wish" ),
                                "group"         => "Fonts & Colors",
                            ), 

                            



                    )

        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'         => 'Want to work with us?',
        'title_font'    => '',
        'title_size'    => '40',
        'title_color'  => '#ffffff',

        'details' => 'Get in touch and we�ll walk you through the rest.',
        'details_font'  => '',
        'details_size'  => '20',
        'details_color' => '#ffffff',

        'link' => '',
        'link_text' => 'Get in Touch',

        'but_font_color'    => '#fff',
        'but_border_color'  => '#fff',

        'bgcolor1'      => '#9b2920',
        'bgcolor2' => '#ec5022',
        'bgcolor3' => '#f5a21f',
        'bgcolor4' => '#f69420',
      ), $atts ) );


        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


      if($link == "||" || $link == "" ){
            
            $link_text = "Read More";
            $link_url = "#";
            $link_target = "";
            $link_string = "";

          }else{

            $link = vc_build_link($link); //parse the link
            $link_url = esc_url($link["url"]);
            $link_target = esc_attr($link["target"]);
            if ($link_text == "") {
                $link_string = "";
            }
            else{
                $link_string = "<div class='buttons pull-right animated' data-animation='fadeInLeft' data-animation-delay='800'><a href='{$link_url}' class='nofill' style='border-color:{$but_border_color};color:{$but_font_color} !important'>{$link_text}</a></div>";
            }

          }


      $output = "
      <style>
        .orange-bg {
            background: {$bgcolor1};
            background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJod…EiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
            background: -moz-linear-gradient(left, {$bgcolor1} 0%, {bgcolor2} 30%, {bgcolor3} 70%, {$bgcolor4} 100%);
            background: -webkit-gradient(linear, left top, right top, color-stop(0%, {$bgcolor1}), color-stop(30%, {$bgcolor2}), color-stop(70%, {bgcolor3}), color-stop(100%, #{$bgcolor4}));
            background: -webkit-linear-gradient(left, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            background: -o-linear-gradient(left, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            background: -ms-linear-gradient(left, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            background: linear-gradient(to right, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='{$bgcolor1}', endColorstr='{$bgcolor4}', GradientType=1 );
        }
      </style>
      <div class='orange-bg'>
            <div class='container getintouch'>
                <div class='row'>
                    <div class='col-lg-6'>
                        <h1 class='animated' data-animation='fadeInRight' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                        <div class='description animated' data-animation='fadeInRight' data-animation-delay='500' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                    </div>
                    <div class='col-lg-6'>
                        {$link_string}
                    </div>
                </div>
            </div>
        </div>";
      return $output;
    }

    /*
    Load plugin css and javascript files which you may need on front end of your site
    */
    public function loadCssAndJs() {
      //wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
      //wp_enqueue_style( 'vc_extend_style' );

      // If you need any javascript files on front end, here is how you can load them.
      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );
    }

    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }



}//end of class
?>