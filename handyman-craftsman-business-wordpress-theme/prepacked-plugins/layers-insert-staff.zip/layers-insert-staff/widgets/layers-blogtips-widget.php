<?php /**
 * TL_Layers_BlogTips_Widget Widget
 *
 * This file is used to register and display the Layers - TL_Layers_BlogTips_Widget.
 *
 * @package Layers
 * @since Layers 1.0.0
 */
if(!class_exists('TL_Layers_Abstract_Widget')){ return; }

if (!class_exists('TL_Layers_BlogTips_Widget')) {
    class TL_Layers_BlogTips_Widget extends TL_Layers_Abstract_Widget
    {

        /**
         *  Widget construction
         */
        public function __construct()
        {
            /**
             * Widget variables
             *
             * @param    string $widget_title Widget title
             * @param    string $widget_id Widget slug for use as an ID/classname
             * @param    string $post_type (optional) Post type for use in widget options
             * @param    string $taxonomy (optional) Taxonomy slug for use as an ID/classname
             * @param    array $checkboxes (optional) Array of checkbox names to be saved in this widget. Don't forget these please!
             */
            $this->widget_title = __('TL Blog Tips', TL_INSERT_STAFF_SLUG);
            $this->widget_id = 'blogtips';
            $this->post_type = 'post';
            $this->taxonomy = 'category';
            $this->checkboxes = array(
                'show_call_to_action'
            ); // @TODO: Try make this more dynamic, or leave a different note reminding users to change this if they add/remove checkboxes


            /* Widget settings. */
            $widget_ops = array('classname' => 'obox-layers-' . $this->widget_id . '-widget',
                                'description' => __('This widget is used to display your ', 'layerswp') . $this->widget_title . '.');

            /* Widget control settings. */
            $control_ops = array('width'  => LAYERS_WIDGET_WIDTH_SMALL,
                            'height' => NULL,
                            'id_base'=> LAYERS_THEME_SLUG . '-widget-' . $this->widget_id);

            /* Create the widget. */
            parent::__construct(LAYERS_THEME_SLUG . '-widget-' . $this->widget_id, $this->widget_title, $widget_ops, $control_ops);

            /* Setup Widget Defaults */
            $this->defaults = array(
                'title' => __('TIPS FROM BLOG', TL_INSERT_STAFF_SLUG),
                'excerpt' => __('Nostra ridiculus tellus maecenas eleifend at, conubia sollicitudin repudiandae sit, nostrud debitis dicta. Quasi praesent porttitor tellus aliquid gravida mauris.', 'layerswp'),
                'text_style' => 'regular',
                'category' => 0,
                'excerpt_length' => 140,
                'posts_per_page' => 3,
                'design' => array(
                    'layout' => 'layout-boxed',
                    'imageratios' => 'image-square',
                    'liststyle' => 'list-grid',
                    'gutter' => 'on',
                    'background' => array( 'position' => 'center', 'repeat' => 'no-repeat' ),
                    'fonts' => array(
                        'align' => 'text-center',
                        'size' => 'medium',
                        'color' => NULL,
                        'excerpt-color' => NULL,
                        'shadow' => NULL
                    )
                )
            );

            /* Add filters */
            $this->_addFilters();
        }



        /**
         * Widget front end display
         *
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        {
            // Turn $args array into variables.
            extract($args);

            $this->backup_inline_css();

            // $instance Defaults
            $instance_defaults = $this->defaults;

            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            //@todo change this to a new markup

            // Apply Section Styling
            $this->_apply_widget_section_styling($widget_id, $widget);

            $this->inline_css .= layers_inline_styles('#' . $widget_id, 'background', array('selectors' => array('.layers-masonry-column'), 'background' => array('color' => $this->check_and_return($widget, 'design', 'column-background-color'))));
            $this->inline_css .= layers_inline_button_styles('#' . $widget_id, 'button', array('selectors' => array('.thumbnail-body a.button'), 'button' => $this->check_and_return($widget, 'design', 'buttons')));

            // Begin query arguments
            $query_args              = array();
            $query_args['post_type'] = $this->post_type;
            $query_args['posts_per_page'] = $widget['posts_per_page'];
            if (isset($widget['order'])) {

                $decode_order = json_decode($widget['order'], true);
                if (is_array($decode_order)) {
                    foreach ($decode_order as $key => $value) {
                        $query_args[$key] = $value;
                    }
                }
            }

            /**
             * Set featured posts. If one is not selected get first available blogpost
             */

            $featured_post = null;
            if(isset($widget['featured_post']) && $widget['featured_post'] != '')
            {
                $featured_post = $widget['featured_post'];
                $featured_query = array( 'p' => (int) $featured_post, 'suppress_filters' => false);
            }else{
                // Get Featured post
                $featured_query = array( 'post_type' => 'post',
                                    'posts_per_page' => 1,
                                    'orderby' => 'date',
                                    'order'   => 'DESC',
                                    'suppress_filters' => false);
            }

            $featured_post = tl_get_posts($featured_query, true);
            $featured_post = isset($featured_post[0]) ? $featured_post[0] : null;

            // Do the special taxonomy array()
            if (isset($widget['category']) && '' != $widget['category'] && 0 != $widget['category']) {
                $query_args['tax_query'] = array(
                    array(
                        "taxonomy" => $this->taxonomy,
                        "field" => "id",
                        "terms" => $widget['category']
                    )
                );
            } elseif (!isset($widget['hide_category_filter'])) {
                $terms = get_terms($this->taxonomy);
            } // if we haven't selected which category to show, let's load the $terms for use in the filter


            // Do the WP_Query for POST LIST
            $post_query = new WP_Query($query_args);

            // Set the meta to display
            global $layers_post_meta_to_display;
            $layers_post_meta_to_display = array();
            if (isset($widget['show_dates']))      $layers_post_meta_to_display[] = 'date';
            if (isset($widget['show_author']))     $layers_post_meta_to_display[] = 'author';
            if (isset($widget['show_categories'])) $layers_post_meta_to_display[] = 'categories';
            if (isset($widget['show_tags']))       $layers_post_meta_to_display[] = 'tags';

            /**
             * Generate the widget container class
             */
            $widget_container_class = array();
            $widget_container_class[] = 'tl-blogtips-widget';
            $widget_container_class[] = 'widget content-vertical-massive';
            $widget_container_class[] = $this->widget_id;
            $widget_container_class[] = $this->check_and_return($widget, 'design', 'advanced', 'customclass');
            $widget_container_class[] = $this->get_widget_spacing_class($widget);
            $widget_container_class = implode(' ', apply_filters('layers_'.$this->widget_id.'_widget_container_class', $widget_container_class, $this, $widget)); ?>

            <div class=" <?php echo esc_attr($widget_container_class); ?>" id="<?php echo esc_attr($widget_id); ?>">
                <?php echo $this->custom_anchor( $widget ); ?>
                <?php do_action( 'layers_before_'.$this->widget_id.'_widget_inner', $this, $widget ); ?>
                <?php if ('' != $this->check_and_return($widget, 'title') || '' != $this->check_and_return($widget, 'excerpt')) { ?>
                    <div class="container clearfix">
                        <?php
                        /**
                         * Generate the Section Title Classes
                         */
                        $section_title_class = array();
                        $section_title_class[] = 'section-title clearfix';
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'size');
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'align');
                        $section_title_class[] = ($this->check_and_return($widget, 'design', 'background', 'color') && 'dark' == tl_layers_is_light_or_dark_recalculated($this->check_and_return($widget, 'design', 'background', 'color')) ? 'invert' : '');
                        $section_title_class = implode(' ', $section_title_class); ?>
                        <div class="<?php echo esc_attr($section_title_class); ?>">
                            <?php if ('' != $widget['title']) { ?>
                                <h3 class="heading">
                                    <?php echo apply_filters('tl_colorize_title_' . $this->widget_id, esc_html($widget['title'])); ?>
                                </h3>
                            <?php } ?>
                            <?php if ('' != $widget['excerpt']) { ?>
                                <div class="excerpt"><?php echo $widget['excerpt']; ?></div>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>


                <div class="grid container list-grid">
                    <!-- POSTS -->
                    <?php
                    $column_classes = array();
                    $column_classes[] = 'layers-masonry-column';
                    $column_classes[] = 'column' . ('on' != $this->check_and_return($widget, 'design', 'gutter') ? '-flush' : '');
                    $column_classes[] = 'span-6';
                    $column_classes = implode(' ', $column_classes);
                    ?>
                    <!-- COLUMN #1 -->
                    <div class="featured-post thumbnail <?php echo esc_attr($column_classes); ?>">
                        <article>
                            <?php if($featured_post): ?>
                            <div class="thumbnail-body">
                                <div class="overlay">
                                    <header class="article-title large">
                                        <h3 class="heading">
                                            <a title="<?php esc_attr($featured_post->post_title); ?>" href="<?php echo get_the_permalink($featured_post->ID); ?>" ><?php echo esc_html($featured_post->post_title); ?></a>
                                        </h3>
                                    </header>
                                    <p class="excerpt">
                                        <?php echo mb_substr($featured_post->post_content, 0, $widget['excerpt_length']); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="thumbnail-media">
                                <?php echo tl_post_featured_media( array( 'post_id'    => $featured_post->ID,
                                                            'wrap_class' => 'thumbnail',
                                                            'size'       => 'layers-landscape-medium',
                                                            'force_vid'  => true ) ); ?>
                            </div>
                            <?php endif; ?>
                        </article>
                    </div>
                    <!-- COLUMN #1 END -->

                    <!-- COLUMN #2 -->
                    <div class="last post-list <?php echo esc_html($column_classes); ?>">
                        <?php if ($post_query->have_posts()): ?>
                        <?php while ($post_query->have_posts()): $post_query->the_post(); ?>
                                <?php include(TL_INSERT_STAFF_DIR . 'widgets/partials/content-blogtip-list.php' ); ?>
                        <?php endwhile; // while have_posts ?>
                        <?php endif; // if have_posts ?>

                    </div>
                    <!-- COLUMN #2 END -->
                    <!-- POSTS END -->

                </div>
                <div class="container aligncenter">
                    <?php
                    /**
                     * Set Blog link
                     */
                    $blog_link_id = null;
                    if(isset($widget['blog_link']) && $widget['blog_link'] != ''){
                        $blog_link_id = (int) $widget['blog_link'];
                    }else{
                        $blog_link_id = get_option('page_for_posts');
                    }
                    ?>
                    <a href="<?php echo get_the_permalink($blog_link_id); ?>" class="hvr-sweep-to-top goto-section-page button large">
                        <?php _e('GO TO OUR BLOG', TL_INSERT_STAFF_SLUG); ?><i class="icon-ti-angle-double-right"></i>
                    </a>
                </div>

                <?php
                // Reset WP_Query
                wp_reset_postdata();

                do_action( 'layers_after_' . $this->id . '_widget_inner', $this, $widget );

                // Print the Inline Styles for this Widget
                $this->print_inline_css();

                // Apply the advanced widget styling
                $this->apply_widget_advanced_styling($widget_id, $widget);
                ?>
            </div>
        <?php }



        /**
         * Widget form
         *
         * @param array $instance
         * @return string|void
         */
        public function form($instance)
        {
            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            ob_start('tl_sanitize_output');

            $this->design_bar(
                'side', // CSS Class Name
                array(
                    'name' => $this->get_layers_field_name('design'),
                    'id' => $this->get_layers_field_id('design'),
                    'widget_id' => $this->widget_id,
                ), // Widget Object
                $widget, // Widget Values
                apply_filters('layers_' . $this->widget_id . '_widget_design_bar_components', array(
                    'fonts',
                    'display' => array(
                        'icon-css' => 'icon-display',
                        'label' => __('Display', 'layerswp'),
                        'elements' => array(
                            'excerpt_length' => array(
                                'type' => 'number',
                                'name' => $this->get_layers_field_name('excerpt_length'),
                                'id' => $this->get_layers_field_id('excerpt_length'),
                                'min' => 0,
                                'max' => 10000,
                                'value' => (isset($widget['excerpt_length'])) ? $widget['excerpt_length'] : NULL,
                                'label' => __('Excerpts Length', TL_INSERT_STAFF_SLUG)
                            )
                        )
                    ),
                    'columns',
                    'background',
                    'advanced'
                ))
            ); ?>
            <div class="layers-container-large">
                <?php $this->form_elements()->header(array(
                    'title'      => __('Tips From Blog', TL_INSERT_STAFF_SLUG),
                    'icon_class' => 'post'
                )); ?>
                <section class="layers-accordion-section layers-content">
                    <div class="layers-row layers-push-bottom">
                        <p class="layers-form-item">
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'text',
                                    'name' => $this->get_layers_field_name('title'),
                                    'id' => $this->get_layers_field_id('title'),
                                    'placeholder' => __('Enter title here', TL_INSERT_STAFF_SLUG),
                                    'value' => (isset($widget['title'])) ? $widget['title'] : NULL,
                                    'class' => 'layers-text layers-large'
                                )
                            ); ?>
                        </p>
                        <p class="layers-form-item">
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'rte',
                                    'name' => $this->get_layers_field_name('excerpt'),
                                    'id' => $this->get_layers_field_id('excerpt'),
                                    'placeholder' => __('Short Excerpt', TL_INSERT_STAFF_SLUG),
                                    'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                    'class' => 'layers-textarea layers-large'
                                )
                            ); ?>
                        </p>
                        <?php // Grab the terms as an array and loop 'em to generate the $options for the input
                        $terms = get_terms($this->taxonomy, array('hide_empty' => false));
                        if (!is_wp_error($terms)) { ?>
                            <p class="layers-form-item">
                                <label for="<?php echo esc_attr($this->get_layers_field_id('category')); ?>"><?php echo __('Category to Display', TL_INSERT_STAFF_SLUG); ?></label>
                                <?php $category_options[0] = __('All', TL_INSERT_STAFF_SLUG);
                                foreach ($terms as $t) $category_options[$t->term_id] = $t->name;
                                echo $this->form_elements()->input(
                                    array(
                                        'type' => 'select',
                                        'name' => $this->get_layers_field_name('category'),
                                        'id' => $this->get_layers_field_id('category'),
                                        'placeholder' => __('Select a Category', TL_INSERT_STAFF_SLUG),
                                        'value' => (isset($widget['category'])) ? $widget['category'] : NULL,
                                        'options' => $category_options,
                                    )
                                ); ?>
                            </p>
                        <?php } // if !is_wp_error
                        ?>
                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('posts_per_page')); ?>"><?php echo __('Number of items to show', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php $select_options['-1'] = __('Show All', TL_INSERT_STAFF_SLUG);
                            $select_options = $this->form_elements()->get_incremental_options($select_options, 1, 20, 1);
                            echo $this->form_elements()->input(
                                array(
                                    'type' => 'number',
                                    'name' => $this->get_layers_field_name('posts_per_page'),
                                    'id' => $this->get_layers_field_id('posts_per_page'),
                                    'value' => (isset($widget['posts_per_page'])) ? $widget['posts_per_page'] : NULL,
                                    'min' => '-1',
                                    'max' => '100'
                                )
                            ); ?>
                        </p>
                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('order')); ?>"><?php echo __('Sort by', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'select',
                                    'name' => $this->get_layers_field_name('order'),
                                    'id' => $this->get_layers_field_id('order'),
                                    'value' => (isset($widget['order'])) ? $widget['order'] : NULL,
                                    'options' => $this->form_elements()->get_sort_options()
                                )
                            ); ?>
                        </p>
                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('featured_post')); ?>"><?php echo __('Primary blogpost', TL_INSERT_STAFF_SLUG); ?></label>

                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'select',
                                    'name' => $this->get_layers_field_name('featured_post'),
                                    'id' => $this->get_layers_field_id('featured_post'),
                                    'value' => (isset($widget['featured_post'])) ? $widget['featured_post'] : NULL,
                                    'options' => tl_get_posts(array('post_type' => 'post')),
                                    'placeholder' => __('-- None --', TL_INSERT_STAFF_SLUG),
                                    'class' => 'layers-select layers-large tl-select-post-item',
                                )
                            ); ?>
                            <small class="layers-small-note">
                               <?php _e('By default widget selects first blog post.', TL_INSERT_STAFF_SLUG) ?>
                            </small>
                        </p>
                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('blog_link')); ?>"><?php echo __('Select blog page', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'select',
                                    'name' => $this->get_layers_field_name('blog_link'),
                                    'id' => $this->get_layers_field_id('blog_link'),
                                    'value' => (isset($widget['blog_link'])) ? $widget['blog_link'] : NULL,
                                    'options' => tl_get_posts(array('post_type' => 'page')),
                                    'placeholder' => __('-- None --', TL_INSERT_STAFF_SLUG),
                                    'class' => 'layers-select layers-large tl-select-post-item',
                                )
                            ); ?>
                            <small class="layers-small-note">
                                <?php _e('By default widget selects default Wordpress blog page. Select a page to change link to the blog page.', TL_INSERT_STAFF_SLUG) ?>
                            </small>
                        </p>
                    </div>
                </section>
            </div>
        <?php
            ob_end_flush();
        } // Form


        protected function _addFilters()
        {
            add_filter('tl_colorize_title_' . $this->widget_id, 'tl_colorize_title', 10, 2);
            add_filter('tl/layers/background_component/' . $this->widget_id . '/args', array($this, 'customizeBackgroundComponent'), 10, 4);
            add_filter('tl/layers/fonts_component/' . $this->widget_id . '/args'     , array($this, 'customizeFontsComponent'), 10, 4);
        }


        /**
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeFontsComponent($args, $position, $widget, $values)
        {
            if($position == 'side'){

                //Add at the beggining of the array
                $args['elements'] = array('fonts-title-heading' => array('type'  => 'layers-heading', 'label' => 'Title Options')) + $args['elements'];

                // this goes to the all widgets
                $args['elements']['fonts-excerpt-heading'] = array(
                    'type'  => 'layers-heading',
                    'label' => 'Excerpt Options',
                );

                $args['elements']['fonts-excerpt-color'] = array(
                    'type'  => 'color',
                    'label' => 'Excerpt Color',
                    'name'  => $widget['name'].'[fonts][excerpt-color]',
                    'id'    => $widget['id'] . '-fonts-excerpt-color',
                    'value' => isset($values['fonts']['excerpt-color']) ? $values['fonts']['excerpt-color'] : null,
                );
            }
            return $args;
        }


        public function customizeBackgroundComponent($args, $position, $widget, $values)
        {
            if($position == 'side'){
                unset($args['elements']['background-darken']);
            }
            return $args;
        }

    } // Class

    // Add our function to the widgets_init hook.
    register_widget("TL_Layers_BlogTips_Widget");
}