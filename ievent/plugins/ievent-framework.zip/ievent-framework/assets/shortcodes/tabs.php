<?php 
	/* Exhibition Placeholder Group  ---------------------------------------------*/
	
	add_shortcode('tabs_group', 'jx_ievent_tabs_group');
	
	function jx_ievent_tabs_group($atts, $content = null) { 
		extract(shortcode_atts(array(
				'date_1' => '',
				'day_1' => '',
				'date_2' => '',
				'day_2' => '',
				'date_3' => '',
				'day_3' => '',
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		if (($date_1!='')&(!$date_2)&(!$date_3)):
			$tab_width="full-width";
		elseif(($date_1!='' & $date_2!='')&(!$date_3)):
			$tab_width="half-width";
		elseif(($date_1!='' & $date_2!='' & $date_3!='')):			
			$tab_width="third-width";
		endif;
		
		//function code

				$out .='	
					<div class="shortcode_tab_e jx-ievent-white-tab jx-ievent-arrow-tab">
					
					<div id="ParentTab">
					<ul class="resp-tabs-list parenttab_1">';
			
				
				if($date_1):
				$out .='<li class="resp-tab-item '.$tab_width.'">
						<div class="jx-ievent-tab-date jx-ievent-uppercase">'.$date_1.'</div>
						<div class="jx-ievent-tab-day jx-ievent-uppercase">'.$day_1.'</div>
					</li>';  
				endif;
				
				if($date_2):
				$out .='<li class="resp-tab-item '.$tab_width.'">
						<div class="jx-ievent-tab-date jx-ievent-uppercase">'.$date_2.'</div>
						<div class="jx-ievent-tab-day jx-ievent-uppercase">'.$day_2.'</div>
					</li>';  
				endif;
				
				if($date_3):
				$out .='<li class="resp-tab-item '.$tab_width.'">
						<div class="jx-ievent-tab-date jx-ievent-uppercase">'.$date_3.'</div>
						<div class="jx-ievent-tab-day jx-ievent-uppercase">'.$day_3.'</div>
					</li>';  
				endif;    
			
			$out .='</ul>'.do_shortcode($content).'<div class="mb60"></div></div></div>';

				
		//return output
		return $out;
	}


	
	
	/* Exhibition Placeholder  ---------------------------------------------*/
	
	add_shortcode('tab_content_group', 'jx_ievent_tab_content_group');
	
	function jx_ievent_tab_content_group($atts, $content = null) { 
		extract(shortcode_atts(array(
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 
		
		//function code
			
			$out ='
			<div class="resp-tabs-container parenttab_1">'.do_shortcode($content).'</div>
			';

		
		//return output
		return $out;
	}
	
	/* Exhibition Placeholder  ---------------------------------------------*/
	
	add_shortcode('subtabs_group', 'jx_ievent_subtabs_group');
	
	function jx_ievent_subtabs_group($atts, $content = null) { 
		extract(shortcode_atts(array(
					'tab_id' => '',
					'tab_classid' => '',
					'hall_a' => '',
					'hall_b' => '',
					'hall_c' => '',
					'hall_d' => '',
					'hall_d' => '',
					'hall_count' => '4'
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 
		
		//function code
		
						
			if ($hall_count=='2'):
				$hall_class="two-halls";
				$halls ='<li><div class="jx-ievent-tab-title">'.$hall_a.'</div></li>';
				$halls .='<li><div class="jx-ievent-tab-title">'.$hall_b.'</div></li>';
			endif;
			
			if ($hall_count=='3'):
				$hall_class="three-halls";
				$halls ='<li><div class="jx-ievent-tab-title">'.$hall_a.'</div></li>';
				$halls .='<li><div class="jx-ievent-tab-title">'.$hall_b.'</div></li>';
				$halls .='<li><div class="jx-ievent-tab-title">'.$hall_c.'</div></li>';
			endif;
			
			if ($hall_count=='4'):
				$hall_class="four-halls";
				$halls ='<li><div class="jx-ievent-tab-title">'.$hall_a.'</div></li>';
				$halls .='<li><div class="jx-ievent-tab-title">'.$hall_b.'</div></li>';
				$halls .='<li><div class="jx-ievent-tab-title">'.$hall_c.'</div></li>';
				$halls .='<li><div class="jx-ievent-tab-title">'.$hall_d.'</div></li>';
			endif;
			
			$out ='
			 <div>
				 <div id="'.$tab_id.'">
					
					<ul class="resp-tabs-list jx-ievent-subtab '.$tab_classid.' '.$hall_class.'">
						'.$halls.'                        
					</ul>                            
					<!-- EOF Child Tab Head -->
					
					 <div class="resp-tabs-container jx-ievent-event-schedule '.$tab_classid.'">
					 	'.do_shortcode($content).'
					 </div>
											 
				 </div>
				 <!-- Item#1 -->
			 </div>
			';

		
		//return output
		return $out;
	}



	/* Exhibition Placeholder  ---------------------------------------------*/
	
	add_shortcode('accordion_group', 'jx_ievent_accordion_group');
	
	function jx_ievent_accordion_group($atts, $content = null) { 
		extract(shortcode_atts(array(
					'accordion_id' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		$id = rand(0,100); 
		
		//function code
			
			$out ='
			<div>
				<div data-accordion-group class="jx-ievent-accordion-box">'.do_shortcode($content).'</div>
			</div>
			';

		
		//return output
		return $out;
	}
	


	/* Exhibition Placeholder  ---------------------------------------------*/
	
	add_shortcode('tabs_point', 'jx_ievent_tabs_point');
	
	function jx_ievent_tabs_point($atts, $content = null) { 
		extract(shortcode_atts(array(
					'speaker_photo' => '',
					'icon' => 'fa-coffee',
					'time_from' => '',
					'time_to' => '',
					'name' => '',
					'title' =>'',
					'short_description' =>'',
					'open' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 
		
		if ($speaker_photo):
			$image = '<img src="'.$speaker_photo.'" alt="">';
			$speaker_name='<i class="fa fa-microphone"></i> <span>'.$name.'</span>';
		elseif ($icon):
			$image = '<i class="fa '.$icon.'"></i>';
			$speaker_name='';
		endif;
		
		
		
		//function code
			
			$out ='			
				<div class="item"> 					  
					<div class="left-position">
					<div class="image">'.$image.'</div>
					<!-- Image -->
					</div>
					<!-- Left item Position -->
					
					<div class="right-position">
					
						<div data-accordion class="head">
							<div class="date"><i class="fa fa-clock-o"></i> <span>'.$time_from.' - '.$time_to.'</span> '.$speaker_name.'</div>
							<div class="title" data-control>'.$title.'</div>                        
							<!-- Title -->';
							
				if ($short_description):
				$out .='<div data-content>
							<div class="content"><p>'.$short_description.'</p></div>
						</div>
						<!-- Content -->
							';
				endif;
							
				$out .='
						</div>							
					</div>
				</div>					
				<!-- Item # 1 --> 
				<div class="clearfix"></div>
			';

		
		//return output
		return $out;
	}
	
	
	
	


?>