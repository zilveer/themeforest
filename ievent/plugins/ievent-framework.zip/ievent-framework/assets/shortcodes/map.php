<?php 
	/* Subscribe  ---------------------------------------------*/
	
	add_shortcode('map', 'jx_ievent_map');
	
	function jx_ievent_map($atts, $content = null) { 
		extract(shortcode_atts(array(
			'title' => '',
			'description' => '',
			'place_name' => 'Mariot Hotel, Browadway',
			'address_a' => '339 Marina Street, New York, NY 10001',
			'address_b' => '1 987 586-45432',
			'address_c' => '4.9 mi / 7.9 km from Downtown',
			"address" => '',
			"lat" =>"40.6700",
			"lng" =>"-73.9400",
			"zoom" =>"14",
			"marker_image"=>'',
			"google_map_style"=>'[{"featureType":"all","stylers":[{"saturation":-100},{"gamma":0.5}]}]',
			"show_address_box"=>'yes',
			"map_height"=>'450px',
		
		), $atts)); 
		 
		 
		 global $ievent_data;	
		
		$lat_info='';
		$lng_info='';
		$out=''; 
		$show_map_code='';
		
	
		//initial variables
		
		
		
		
		//function code
			if($show_address_box=='yes'):
			$show_map_code='<div class="container">
					<div class="jx-ievent-venue-box">
					
						<div class="jx-ievent-hotel-name jx-ievent-uppercase">'.$place_name.'</div>
					
						<div class="jx-ievent-venue-address">
							<div class="jx-ievent-venue-heading"><i class="fa fa-map-marker"></i>'.esc_html__('Address','ievent').'</div>
							<div class="jx-ievent-address-1">'.$address_a.'</div>
							<div class="jx-ievent-address-2">'.$address_b.'</div>
							<div class="jx-ievent-address-3">'.$address_c.'</div>
						</div>
					</div>
				</div>';
			endif;
			
			$out ='
			<div class="jx-ievent-container">
				'.$show_map_code.'
				<div class="jx-ievent-google-map">
					<div id="map" class="jx-ievent-map" style="height:'.$map_height.';"></div>
				</div>
			</div>
			';

			
			$out.='
			
			 <script type="text/javascript">
			 
          
            google.maps.event.addDomListener(window, "load", init);     	
			
			
            function init() {
                // Basic options for a simple Google Map
                // For more options see: https://developers.google.com/maps/documentation/javascript/reference#MapOptions
                
				var isDraggable = jQuery(document).width() > 480 ? true : false;
				
				var mapOptions = {
                    scrollwheel: false,
					draggable: isDraggable,
					// How zoomed in you want the map to start at (always required)
                    zoom: '.$zoom.',
                    // The latitude and longitude to center the map (always required)
                    center: new google.maps.LatLng('.$lat.', '.$lng.'), // New York
                    // How you would like to style the map. 
                    // This is where you would paste any style found on Snazzy Maps.
                    styles: [{"featureType":"water","elementType":"geometry.fill","stylers":[{"color":"#d3d3d3"}]},{"featureType":"transit","stylers":[{"color":"#808080"},{"visibility":"off"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"visibility":"on"},{"color":"#b3b3b3"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"road.local","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"weight":1.8}]},{"featureType":"road.local","elementType":"geometry.stroke","stylers":[{"color":"#d7d7d7"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#ebebeb"}]},{"featureType":"administrative","elementType":"geometry","stylers":[{"color":"#a7a7a7"}]},{"featureType":"road.arterial","elementType":"geometry.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"road.arterial","elementType":"geometry.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"landscape","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#efefef"}]},{"featureType":"road","elementType":"labels.text.fill","stylers":[{"color":"#696969"}]},{"featureType":"administrative","elementType":"labels.text.fill","stylers":[{"visibility":"on"},{"color":"#737373"}]},{"featureType":"poi","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road.arterial","elementType":"geometry.stroke","stylers":[{"color":"#d6d6d6"}]},{"featureType":"road","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"color":"#dadada"}]}]
                };
                // Get the HTML DOM element that will contain your map 
                // We are using a div with id="map" seen below in the <body>
    
                var mapElement = document.getElementById("map");
                // Create the Google Map using our element and options defined above
                var map = new google.maps.Map(mapElement, mapOptions);
                // Lets also add a marker while we are at it
               
				var latlng = new google.maps.LatLng('.$lat.', '.$lng.');
				new google.maps.Marker({
					position: latlng,
					icon: "'.$ievent_data['map_location_pointer'].'",
					map: map
				});

            }
      </script>
			
			';
		
			
		//return output
		return $out;
	}
	//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_ievent_map' );
	
	
	function vc_ievent_map() {	
		vc_map(array(
		  "name" => esc_html__( "Google Map", "TEXT_DOMAIN" ),
		  "base" => "map",
		  "class" => "",
		  "icon" => get_template_directory_uri().'/images/icon/vc_map.png',
		  "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
		  "description" => __('Add Map','TEXT_DOMAIN'),
		  "params" => array(
					 
			 
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Place Name", "TEXT_DOMAIN" ),
				"param_name" => "place_name",
				"value" => "Mariot Hotel, Browadway", 
				"description" => esc_html__( "Add Place Name", "TEXT_DOMAIN" )
			 ),
			 
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Address A", "TEXT_DOMAIN" ),
				"param_name" => "address_a",
				"value" => "339 Marina Street, New York, NY 10001", 
				"description" => esc_html__( "Add Address A", "TEXT_DOMAIN" )
			 ),
		
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Address B", "TEXT_DOMAIN" ),
				"param_name" => "address_b",
				"value" => "1 987 586-45432", 
				"description" => esc_html__( "Add Adddress B", "TEXT_DOMAIN" )
			 ),	
			 
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Address C", "TEXT_DOMAIN" ),
				"param_name" => "address_c",
				"value" => "4.9 mi / 7.9 km from Downtown", 
				"description" => esc_html__( "Add Address C", "TEXT_DOMAIN" )
			 ),	
			 
 
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Lat", "TEXT_DOMAIN" ),
				"param_name" => "lat",
				"value" => "40.6700", 
				"description" => esc_html__( "Add Lat", "TEXT_DOMAIN" )
			 ),	
			 
			 
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Lng", "TEXT_DOMAIN" ),
				"param_name" => "lng",
				"value" => "-73.9400", 
				"description" => esc_html__( "Add Lng", "TEXT_DOMAIN" )
			 ),
			 
			 array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "zoom", "TEXT_DOMAIN" ),
				"param_name" => "zoom",
				"value" => "14", 
				"description" => esc_html__( "Set Google map zoom value from 1 to 20", "TEXT_DOMAIN" )
			 ),
			 
			 array(
				"type" => "dropdown",
				"class" => "",
				"heading" => __("Show Address Box",'TEXT_DOMAIN'),
				"param_name" => "show_address_box",
				"value" => array(   
					__('Yes', 'TEXT_DOMAIN') => 'yes',
					__('No', 'TEXT_DOMAIN') => 'no',
					),
				),
				
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Map Height", "TEXT_DOMAIN" ),
				"param_name" => "map_height",
				"value" => "450px", 
				"description" => esc_html__( "Set Google map height in px", "TEXT_DOMAIN" )
			 ),
			 
	
			 
		  )
	   )); 
	}
?>