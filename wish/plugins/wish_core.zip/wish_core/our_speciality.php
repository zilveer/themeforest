<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Our Speciality", "wish"),
    "description" => __("", 'wish'),
    "controls" => "full",
    "base" => "wish_our_speciality",
    "as_parent" => array('only' => 'wish_our_speciality_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/P707fdI.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Our Speciality Title and Position", "wish"),
            "value" => __("Our Speciality", 'wish'),
            "admin_label" => false,
        ),

        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("24", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "bg_color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#ffffff;', //Default Red color
            "description" => __( "Choose Background color", "wish" ),
            "group"         => "Fonts & Colors",
        ), 
         array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Ribbon Image", 'wish'),
            "param_name" => "ribbon",
            "description" => __("Banner image behind the title, leave blank for default", 'wish'),
            "admin_label" => false,
        ),

    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Our Speciality", "wish"),
    "base" => "wish_our_speciality_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_our_speciality'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Image", 'wish'),
            "param_name" => "image",
            "description" => __("Image", 'wish'),
        ), 

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat", 'wish'),
            "description" => __("The details below the title", 'wish'),
            "admin_label" => false,
        ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Our_Speciality extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title'         => 'Our Speciality',
            'title_font'    => '',
            'title_size'    => '24',
            'title_color'   => '#fff',

            'bgcolor'   => 'bgcolor',
            'ribbon'    => 'ribbon',
          ), $atts ) );

          /*title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



          $rib = wp_get_attachment_image_src( $ribbon, 'full' );

      if($ribbon == "ribbon"){
        $ribsrc = plugins_url('images/heading-bg.png', __FILE__);
        $rib[0] = $ribsrc;
      }


      $output = "<div class='our-speciality grey-bg' style='background-color:{$bgcolor};'>
            <div class='container'>
                <div class='row'>
                    <div class='col-lg-12'>
                        <div class='main-heading animated flipInX visible' data-animation='flipInX' data-animation-delay='100' style='background-image:url({$rib[0]});'>
                            <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    " . do_shortcode($content) . "
                
            </div>
            </div>
            </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Our_Speciality_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image'   => 'image',
            'details' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#000',
          ), $atts ) );

          /*details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


          $img = wp_get_attachment_image_src( $image, array(600,398) );

          if($image == "image"){
            $imgsrc = plugins_url('images/default.jpg', __FILE__);
            $img[0] = $imgsrc;
          }

          $output = "<div class='col-lg-6 block animated fadeInUp visible' data-animation='fadeInUp' data-animation-delay='400'>
                        <div class='picture'><img src='{$img[0]}' class='img-responsive' alt=''></div>
                        <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                    </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>