<?php
//Register "container" content element
vc_map( array(
    "name" => __("Custom Portfolio", "wish"),
    "description" => __("Maonry Portfolio With Categories filters", 'wish'),
    "controls" => "full",
    "base" => "wish_custom_portfolio",
    "as_parent" => array('only' => 'wish_custom_portfolio_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link" => "http://i.imgur.com/XCfVuNe.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Title", "wish"),
            "value" => __("recent work", 'wish'),
            "admin_label" => true,
        ), 

        array(
            "type" => "textfield",
            "heading" => __("subtitle", "wish"),
            "param_name" => "subtitle",
            "description" => __("Subtitle", "wish"),
            "value" => __("Dive into projects", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Categories", "wish"),
            "param_name" => "categories",
            "description" => __("Enter Categories seperated by commas", "wish"),
            "value" => __("Design, Web", 'wish'),
            "admin_label" => false,
        ),

        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("30", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#df4322 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Subtitle*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Subtitle Text Font", "wish" ),
            "param_name" => "subtitle_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Subtitle Size", "wish"),
            "param_name" => "subtitle_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Subtitle Text Color", "wish" ),
            "param_name" => "subtitle_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#F4F4F4',
            "description" => __( "Choose background color", "wish" ),
            "group"         => "Fonts & Colors",
            "admin_label" => false,
         ),


         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Theme Color", "wish" ),
            "param_name" => "hover_color",
            "value" => '#DF4322',
            "description" => __( "Choose theme color", "wish" ),
            "group"         => "Fonts & Colors",
            "admin_label" => false,
         ),

    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Portfolio Image", "wish"),
    "base" => "wish_custom_portfolio_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_custom_portfolio'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,    
        ),

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Image Title", "wish"),
            "value" => __("Design", 'wish'),
            "admin_label" => true,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Categories", "wish"),
            "param_name" => "categories",
            "description" => __("Enter Categories seperated by commas", "wish"),
            "value" => __("Design, Web", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "checkbox",
            "class" => "",
            "heading" => __( "Large?", "wish" ),
            "param_name" => "large",
            "value" => false,
            "description" => __( "Make this image larger", "wish" ),
            "admin_label" => false,
         ),

        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("18", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Custom_Portfolio extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title' => 'recent work',
            'title_font'  => '',
            'title_size'  => '30',
            'title_color' => '#DF4322',

            'bgcolor'   => '#e7f6ff',
            'subtitle'  => 'Dive into project', 
            'subtitle_font' => '',
            'subtitle_size' => '20',
            'subtitle_color'  => '#000',

            'categories' => "",
            'hover_color' => '#DF4322',
          ), $atts ) );

          /*title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*title*/
        $decode_font = urldecode($subtitle_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $subtitle_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

         wp_enqueue_script('wish-isotope-portfolio', plugins_url('assets/isotope/jquery.isotope.min.js', __FILE__), array('jquery') );
         wp_enqueue_script('wish-isotope-portfolio-masonry', plugins_url('assets/isotope/custom-isotope-mansory.js', __FILE__), array('jquery') );
          


          $categories = explode(",", $categories);


      $output = "<div id='portfolio'>
                    <style>
                    #portfolio-mansory .picture{
                        background-color: {$hover_color};
                    }
                    .picture-overlay .icons > :first-child .icon a{
                        color: {$hover_color};
                    }
                    </style>
                    <div class='grey-bg'>
                      <div class='container'>
                        <div class='row index-header'>
                          <div class='col-lg-12'>
                            <h3 class='animated' data-animation='fadeInRight' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h3>
                            <h1 class='animated' data-animation='fadeInRight' data-animation-delay='400' style='font-family:{$subtitle_font_family};font-size:{$subtitle_size}px;color:{$subtitle_color};'>{$subtitle}</h1>
                            <!-- Portfolio Nav Starts -->
                            <div id='options' class='animated' data-animation='fadeInRight' data-animation-delay='500'>
                              <ul id='filters' class='option-set clearfix' data-option-key='filter'>
                                <li>Filter:</li>
                                <li><a href='#filter' data-option-value='*' class='selected'>All</a></li>";

                                foreach ($categories as $key => $value) {

                                    $value = trim ($value);
                                    $filter_class = str_replace(" ", "-", $value);
                                    $output .=  "<li><a href='#filter' data-option-value='.{$filter_class}'>{$value}</a></li>";

                                }


                $output .=  " </ul>
                            </div>
                            <!-- Portfolio Nav Ends -->
                          </div>
                        </div>
                      </div>
                    </div>
                      
                      <div id='portfolio-mansory' class='animated' data-animation='fadeInUp' data-animation-delay='600'>

                      ".do_shortcode($content)."


                      </div>
                    </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Custom_Portfolio_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image'   => 'Image',
            'title' => 'web',
            'title_font'  => '',
            'title_size'  => '18',
            'title_color' => '#000',
            'categories' => '',
            'large'     => false,
          ), $atts ) );

          /*title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

          $thumb = wp_get_attachment_image_src( $image, array(440,330));
          $img = wp_get_attachment_image_src( $image, 'full');



          $class = "";
          if($large){
            $class = "item-h2";
            $thumb = wp_get_attachment_image_src( $image, array(440,660));
          }

          $class = sanitize_html_class($class);

          if($image == "Image"){
            $img[0] = plugins_url('images/9.jpg', __FILE__);
            $thumb[0] = plugins_url('images/9.jpg', __FILE__);

            if($large){
                  $img[0] = plugins_url('images/2-b.jpg', __FILE__);
                  $thumb[0] = plugins_url('images/2-b.jpg', __FILE__);
            }


          }


          $categories = explode(",", $categories);

          $cat = "";

          // print_r($categories);

          foreach ($categories as $key => $value) {
             $value = trim ($value);
            $filter_class = str_replace(" ", "-", $value);
            $cat .=  $filter_class . " ";
          }



          $output = "<figure class='hovereffect item photos {$class} {$cat}'>
                        <div class='picture'>
                          <img src='{$thumb[0]}' alt=''/>                       
                          <!-- Picture Overlay Starts -->
                          <div class='picture-overlay'>
                            <div class='icons'>
                              <div><span class='icon'><a class='image-popup-vertical-fit' href='{$img[0]}' title='{$title}'><i class='fa fa-search'></i></a></span></div>
                            </div>
                          </div>
                          <!-- Picture Overlay Ends -->
                        </div>
                        <!-- Project Info Starts -->
                        <div class='info'>
                          <div class='caption' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</div>
                        </div>
                        <!-- Project Info Ends -->
                      </figure>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>