<?php

/*---------------------------------------------------------------*/
/* Create custom param for Visual Composer
/*---------------------------------------------------------------*/

// Preview param
function mnky_preview_param($settings, $value) {
	$output = '';

	$output .= '<div class="mnky_preview '.$settings['param_name'].'">';
	foreach ( $settings['value'] as $preview ) {
		$selected = ( $preview == $value ) ? ' checked' : '';
			
		$output .= '<label><input type="radio" name="preview" value="' . $preview . '" id="' . $preview . '"'.$selected.'><span class="' . $preview . '"></span></label>';
	}
	$output .= '</div>';
		
	return '<input name="'.$settings['param_name'].'" id="mnky_selected_preview" class="wpb_vc_param_value  '.$settings['param_name'].' '.$settings['type'].'_field"  value="'.$value.'" type="hidden"/>'. $output;	
}

vc_add_shortcode_param('mnky_preview', 'mnky_preview_param', MNKY_PLUGIN_URL . 'assets/js/extend-params.js' );



// Info param
function mnky_info_param($settings, $value) {
	return '<div class="mnky_info '.$settings['param_name'].'">'.$value.'</div>';
}

vc_add_shortcode_param('mnky_info', 'mnky_info_param');