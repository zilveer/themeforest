<?php

/*

Plugin Name: Wish Theme Core Plugin

Plugin URI: http://wpbakery.com/vc

Description: Wish Theme Core Components

Version: 1.2

Author: Jamal Khan

Author URI: http://redhawk-studio.com

License: GPLv2 or later

*/



// don't load directly

if (!defined('ABSPATH')) die('-1');





function wish_admin_notice() {

    ?>

    <div class="vc_notfound updated">

        <p><?php _e( 'Visual Composer Needs To Be Activated For Wish Core To Work.', 'wish' ); ?></p>

    </div>

    <?php

}





//check if visual composer installed:

if ( ! defined( 'WPB_VC_VERSION' ) ) {

        add_action('admin_notices', 'wish_admin_notice' );

        return;

}else{//if vc installed:



//remove default templates:

add_filter( 'vc_load_default_templates', 'wish_vc_remove_templates' );

function wish_vc_remove_templates($data) {

    return array(); // This will remove all default templates

}





function wish_revslider_buildShortcode1() {

    if ( class_exists( 'RevSlider' ) ) {



        $slider = new RevSlider();

        $arrSliders = $slider->getArrSliders();



        $revsliders = array();

        if ( $arrSliders ) {

            foreach ( $arrSliders as $slider ) {

                /** @var $slider RevSlider */

                $revsliders[ $slider->getTitle() ] = $slider->getAlias();

            }

        } else {

            $revsliders[ __( 'No sliders found', 'js_composer' ) ] = 0;

        }



        return $revsliders;



    }

}



$revsliders = wish_revslider_buildShortcode1();

    

include "params/fontawesome.php";

include "params/number.php";





// includes

include "text_2_cols.php";

include "services.php";

include "video_strip.php";

include "featured_projects.php";

include "team.php";

include "large_tabs.php";

include "parallax.php";

include "about_us_carousel.php";

include "image_banner.php";

include "banner_tabs.php";

include "projects_portfolio.php";

include "slider_portfolio.php";

include "horizontal_tabs.php";

include "restaurant-menu.php";

include "our_story.php";

include "team_carousel.php";

include "image_list.php";

include "working_hours.php";

include "intro_section.php";

include "parallax_carousel.php";

include "parallax_icons_features.php";

include "services_links.php";

include "statement.php";

include "simple_testimonials.php";

include "parallax_testimonials.php";

include "featured_story.php";

include "timeline_horizontal.php";

include "carousel_blog.php";

include "school_intro.php";

include "our_staff.php";

include "latest_blog.php";

include "parallax_video.php";

include "our_mission.php";

include "departments.php";

include "funfacts.php";

include "our_speciality.php";

include "services_tabs.php";

include "school_slider.php";

include "parallax_featured.php";

include "contact_form.php";

include "our_skills.php";

include "featured_products.php";

include "image_with_details.php";

include "parallax_medical_banner.php";

include "big_intro_section.php";

include "info_strip.php";

include "our_clients.php";

include "our_team.php";

include "parallax_construction_video.php";

include "we_build.php";

include "wish_call_to_action.php";

include "features.php";

include "parallax_services.php";

include "hand_testimonial.php";

include "funfacts_large.php";

include "what_we_do.php";

include "corporate_features.php";

//include "our_stats.php";

include "simple_banner_2_columns.php";

include "simple_banner_3_columns.php";

include "benefits.php";

include "typing_banner.php";

include "portfolio.php";

include "restaurant_menu_2.php";

include "content_slider.php";

include "FAQs.php";

include "Insights.php";

include "welcome.php";

include "area_of_practice.php";

include "latest_news.php";

include "vertical_tabs.php";

include "alerts.php";

include "wish_team.php";

include "projects_portfolio_2.php";

include "big_quote.php";

include "big_intro_section_2.php";

include "horizontal_tabs_2.php";

include "text_banner.php";

include "highlight.php";

include "our_clients_2.php";

include "text_intro.php";

include "home_services_tabs.php";

include "work_process.php";

include "custom_portfolio.php";

include "quote.php";

include "creative_team.php";

include "parallax_text_banner.php";

include "custom_portfolio_2.php";

include "principal_message.php";

include "wish_recommended_products.php";

include "wish_topsellers_products.php";

include "wish_latest_products.php";

include "construction_slider.php";

include "features_2.php";

include "hosting_packages.php";

include "team_2.php";

include "statement_2.php";

include "about_us.php";

include "our_staff_2.php";
include "intro_services.php";
include "services_pictures.php";
include "work_process_2.php";
include "news_letter.php";
include "pricing_table.php";
include "pricing_table_2.php";
include "custom_project_portfolio.php";
include "custom_heading.php";
include "key_features.php";
include "demo_thumbs.php";
include "vertical_timeline.php";
include "wish_button.php";

include "wish_posts_carousal.php";


//init

new Wish_posts_carousal();

new Wish_2_Cols_Text();

new Wish_Video_Strip();

new Wish_Featured_Projects();

new Wish_Team_Gallery();

new Wish_Vertical_Tabs();

new Wish_Parallax();

new Wish_Banner_Image();

new Wish_Projects_portfolio();

new Wish_Projects_Slider();

new Wish_Our_Story();
new Wish_Working_Hours();
new Wish_Simple_Statement();
new Wish_Featured_Story();
new Wish_Carousel_Blog();
new Wish_Latest_Blog();
new Wish_Parallax_video();
new Wish_Parallax_Featured_Product();
new Wish_Contact_Form();
new Wish_Parallax_Medical();
new Wish_Big_Intro();
new Wish_Info_Strip();
new Wish_Parallax_Construction_video();
new Wish_Wish_Call_To_Action();
new Wish_Hand_Testimonial();
new Wish_Portfolio();
new Wish_welcome();
new Wish_Team();
new Wish_Projects_portfolio_2();
new Wish_big_quote();
new Wish_Big_Intro2();
new Wish_Text_banner();
new Wish_Highlight();
new Wish_Text_Intro();
new Wish_Parallax_Text_Banner();
new Wish_Principal_Message();
new Wish_Recommended_products();
new Wish_topsellers_products();
new Wish_Latest_Products();
new Wish_Team_Gallery_2();
new Wish_Simple_Statement_2();
new Wish_Services_Intro();
new Wish_Newsletter();
new Wish_Custom_Heading();
new Demo_Thumbs();
new Wish_Button();


}//ends visual composer installed









//custom texonomies for projects

add_action( 'init', 'orane_projects_taxonomy', 0 );

function orane_projects_taxonomy() {

    register_taxonomy(

        'wish_project_types',

        'project',

        array(

            'labels' => array(

                'name' => 'Types',

                'add_new_item' => 'Add New Type',

                'new_item_name' => "New Type"

            ),

            'show_ui' => true,

            'show_tagcloud' => false,

            'hierarchical' => true

        )

    );

}



/*=============================== custom post type PROJECTS====================================*/

add_action( 'init', 'create_post_type_projects' );

function create_post_type_projects() {

    register_post_type( 'wish_projects',

        array(

            'labels' => array(

                'name' => __( 'Projects' ),

                'add_new' => __( 'Add New Project' ),

                'add_new_item' => __( 'Add New Project' ),

                'singular_name' => __( 'project' )

            ),

        'public' => true,

        'has_archive' => true,

        'supports' => array( 'title', 'editor', 'thumbnail' )



        )

    );



}

add_action( 'init', 'projects_taxonomies' );

function projects_taxonomies() {

    register_taxonomy(

        'projects_categories',

        'wish_projects',

        array(

            'labels' => array(

                'name' => 'Projects Categories',

                'add_new_item' => 'Add New category',

                'new_item_name' => "Project Types"

            ),

            'show_ui' => true,

            'show_tagcloud' => false,

            'hierarchical' => true

        )

    );

}

/*=============================== custom post type Portfolio====================================*/

add_action( 'init', 'create_post_type_portfolio' );

function create_post_type_portfolio() {

    register_post_type( 'wish_portfolio',

        array(

            'labels' => array(

                'name' => __( 'Portfolio' ),

                'add_new' => __( 'Add New Portfolio' ),

                'add_new_item' => __( 'Add New Portfolio' ),

                'singular_name' => __( 'portfolio' )

            ),

        'public' => true,

        'has_archive' => true,

        'supports' => array( 'title','editor', 'thumbnail' )

        )

    );



}

/*=============================== custom post type Teams====================================*/

add_action( 'init', 'create_post_type_teams' );

function create_post_type_teams() {

    register_post_type( 'wish_team',

        array(

            'labels' => array(

                'name' => __( 'Team' ),

                'singular_name' => __( 'team' )

            ),

        'public' => true,

        'has_archive' => true,

        'supports' => array( 'title', 'editor', 'thumbnail' )



        )

    );



}

/*=============================== custom post type Testimonials====================================*/

add_action( 'init', 'create_post_type_testimonials' );

function create_post_type_testimonials() {

    register_post_type( 'wish_testimonials',

        array(

            'labels' => array(

                'name' => __( 'Testimonials' ),

                'singular_name' => __( 'testimonial' )

            ),

        'public' => true,

        'has_archive' => true,

        'supports' => array( 'title', 'editor', 'thumbnail' )



        )

    );



}

/*=============================== custom post type Testimonials====================================*/

add_action( 'init', 'create_post_type_clients' );

function create_post_type_clients() {

    register_post_type( 'wish_clients',

        array(

            'labels' => array(

                'name' => __( 'Clients' ),

                'singular_name' => __( 'clients' )

            ),

        'public' => true,

        'has_archive' => true,

        'supports' => array( 'title', 'thumbnail' )



        )

    );



}

/*=============================== custom post type Skills====================================*/

// add_action( 'init', 'create_post_type_skills' );

// function create_post_type_skills() {

//     register_post_type( 'wish_services',

//         array(

//             'labels' => array(

//                 'name' => __( 'Services' ),

//                 'singular_name' => __( 'services' )

//             ),

//         'public' => true,

//         'has_archive' => true,

//         'supports' => array( 'title', 'editor' )



//         )

//     );



// }

// add_action( 'init', 'skills_taxonomies' );

// function skills_taxonomies() {

//     register_taxonomy(

//         'skills_categories',

//         'wish_services',

//         array(

//             'labels' => array(

//                 'name' => 'Services Categories',

//                 'add_new_item' => 'Add New Service',

//                 'new_item_name' => "Services Types"

//             ),

//             'show_ui' => true,

//             'show_tagcloud' => false,

//             'hierarchical' => true

//         )

//     );

// }







// // custom post type for photography:

// add_action( 'init', 'create_post_type_photography' );

// function create_post_type_photography() {

// 	register_post_type( 'wish_photography',

// 		array(

// 			'labels' => array(

// 				'name' => __( 'Photography' ),

// 				'add_new' => __( 'Add Photography' ),

// 				'add_new_item' => __( 'Add New Photography' ),

// 				'singular_name' => __( 'photography' )

// 			),

// 		'public' => true,

// 		'has_archive' => true,

// 		'supports' => array( 'title', 'thumbnail' )

		

// 		)

// 	);

	

// }

// add_action( 'init', 'photography_taxonomies' );

// function photography_taxonomies() {

//     register_taxonomy(

//         'photography_categories',

//         'wish_photography',

//         array(

//             'labels' => array(

//                 'name' => 'Categories',

//                 'add_new_item' => 'Add New Category',

//                 'new_item_name' => "Photography Types"

//             ),

//             'show_ui' => true,

//             'show_tagcloud' => false,

//             'hierarchical' => true

//         )

//     );

// }







// alter visual composer row

vc_add_param("vc_row", array(

    "type" => "dropdown",

    "group" => "Width",

    "class" => "",

    "heading" => "Width",

    "param_name" => "type",

    "value" => array(

        "Full Width" => "in_container",

        "Container" => "container",       

    ),

    "std"       =>   "Full Width",

));



add_action( 'init', 'portfolio_taxonomies' );

function portfolio_taxonomies() {

    register_taxonomy(

        'portfolio_categories',

        'wish_portfolio',

        array(

            'labels' => array(

                'name' => 'Portfolio Categories',

                'add_new_item' => 'Add New category',

                'new_item_name' => "Portfolio Types"

            ),

            'show_ui' => true,

            'show_tagcloud' => false,

            'hierarchical' => true

        )

    );

}











//check if offline

function is_online($sCheckHost = 'www.google.com')

{

return (bool) @fsockopen($sCheckHost, 80, $iErrno, $sErrStr, 5);

}



//for styling in certain elements

function wish_line2SpanColor($title,$color='#fff'){



     $title1 = preg_replace("/\|(.+?)\|/", "<span style='color:{$color}'>$1</span>", $title);

     return $title1;



}



function wish_line2Bold($title){



     $title1 = preg_replace("/\|(.+?)\|/", "<b>$1</b>", $title);

     return $title1;



}



function wish_line2Span($title){



     $title1 = preg_replace("/\|(.+?)\|/", "<span>$1</span>", $title);

     return $title1;



}





//shorten the string to a certain # of words

function wish_shorten_string($oldstring, $wordsreturned)

{

  $retval = $oldstring;

  $string = preg_replace('/(?<=\S,)(?=\S)/', ' ', $oldstring);

  $string = str_replace("\n", " ", $string);

  $array = explode(" ", $string);

  if (count($array)<=$wordsreturned)

  {

    $retval = $string;

  }

  else

  {

    array_splice($array, $wordsreturned);

    $retval = implode(" ", $array)." ...";

  }

  return $retval;

}







//list all contact form 7 forms

function getAllContactForm7(){



    $args = array('post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1);

    if( $cf7Forms = get_posts( $args ) ){



        $arr = array();

        foreach($cf7Forms as $cf7Form){

            // echo(do_shortcode('[contact-form-7 id="'.$cf7Form->ID.'" title="'.($cf7Form->post_title).'"]'));

            // $arr[$cf7Form->ID] = $cf7Form->post_title;

            $arr[$cf7Form->post_title] = $cf7Form->ID;

        }



        return $arr;









    }



   return $arr["error"] = "No Contact Forms Created";



}







//update server settings

require 'plugin-update-checker.php';

$wish_core_updater = PucFactory::buildUpdateChecker(

    'http://redhawk-studio.com/themes/updates/wish-core-metadata.json',

    __FILE__

);





?>