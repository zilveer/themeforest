<?php
function imt_checkupdatecf($custom_field, $value, $post_id){
    //create or update a custom field
    $data = get_post_meta($post_id, $custom_field, TRUE);
    if(isset($data)) update_post_meta($post_id, $custom_field, $value);
    else add_post_meta($post_id, $custom_field, $value, TRUE);
}

function checkIfSelected($val1, $val2, $type){
    // check if val1 is equal with val2 and return an select attribute for checkbox, radio or select tag
    if($val1==$val2){
        if($type=='checkbox') return 'checked="checked"';
        else return 'selected="selected"';
    }else return '';
}



/***********************TEAM FUNCTIONS***************************/

function imt_init_plugin_arr(){
    //SHORTCODE INIT VALUES ARRAY
   $arr = array(
                        'team' => 'all',
                        'order_by' => 'date',
                        'order' => 'ASC',
                        'limit' => 4,
                        'name' => 1,
                        'photo' => 1,
                        'description' => 1,
                        'job' => 1,
                        'email' => 0,
                        'location' => 0,
                        'tel' => 0,
                        'website' => 0,
                        'social_icon' => 1,
                        'skills' => 1,
                        'page_inside' => 0,
                        'inside_template' => '',
                        'theme' => 'theme_1',
                        'color_scheme' => '',
                        'slider_cols' => 1,
                        'columns' => 4,
                        //slide opt
                        'slider_set' => 0,
                        'items_per_slide' => 2,
                        'bullets' => 1,
                        'nav_button' => 1,
                        'autoplay' => 1,
                        'stop_hover' => 1,
                        'speed' => 500,
                        'pagination_speed' => 500,
                        'responsive' => 1,
                        'lazy_load' => 0,
                        'lazy_effect' => 0,
                        'slide_css_transition' => 'none',
                        );
    return $arr;
}

function imt_init_widget_arr(){
    //WIDGET INIT VALUES ARRAY
  $arr = array(
                        'team' => 'all',
                        'order_by' => 'title',
                        'order' => 'ASC',
                        'limit' => 3,
                        'page_inside' => 0,
                        'inside_template' => '',
                        'theme' => 'theme_1',
                        'color_scheme' => '',
                        'show' => 'name,photo,description,skills,social_icon',
                        'slider_cols' => 1,
                        'columns' => 1,
                        //slide opt
                        'slider_set' => 0,
                        'items_per_slide' => 2,
                        'slide_opt' => 'bullets,nav_button,autoplay,stop_hover,responsive',
                        'slide_speed' => 500,
                        'slide_pagination_speed' => 500,
                        'slide_css_transition' => 'fade',
              );
  return $arr;
}

function imt_metabox_ti($team){
    $email = esc_html(get_post_meta($team->ID, 'in_team_email', true));
    $telephone = esc_html(get_post_meta($team->ID, 'in_team_telephone', true));
    $location = esc_html(get_post_meta($team->ID, 'in_team_location', true));
    $job_title = esc_html(get_post_meta($team->ID, 'in_team_jobtitle', true));
    $website = esc_html(get_post_meta($team->ID, 'in_team_website', true));
    ?>
    <table class="it-table">
		<tr>
            <td class="it-label"><i class="icon-tags"></i> Job Title: </td>
            <td>
                <input type="text" value="<?php echo $job_title;?>" name="in_team_jobtitle" />
            </td>
        </tr>
        <tr>
            <td class="it-label"><i class="icon-envelope"></i> E-Mail: </td>
            <td>
                <input type="text" value="<?php echo $email;?>" name="in_team_email" />
            </td>
        </tr>
        <tr>
            <td class="it-label"><i class="icon-globe"></i> Website: </td>
            <td>
                <input type="text" value="<?php echo $website;?>" name="in_team_website" />
            </td>
        </tr>
	</table>
	<table class="it-table">
        <tr>
            <td class="it-label"><i class="icon-phone"></i> Telephone: </td>
            <td>
                <input type="text" value="<?php echo $telephone;?>" name="in_team_telephone" />
            </td>
        </tr>
        <tr>
            <td class="it-label" style="vertical-align:top;"><i class="icon-home"></i> Location: </td>
            <td>
                <textarea value="<?php echo $location;?>" name="in_team_location"><?php echo $location;?></textarea>
            </td>
        </tr>
    </table>
	<div class="clear"></div>
<?php
}

function imt_save_ti($post_id){
    if( isset($_POST['in_team_email']) ) imt_checkupdatecf('in_team_email', $_POST['in_team_email'], $post_id);
    if( isset($_POST['in_team_telephone']) ) imt_checkupdatecf('in_team_telephone', $_POST['in_team_telephone'], $post_id);
    if( isset($_POST['in_team_location']) ) imt_checkupdatecf('in_team_location', $_POST['in_team_location'], $post_id);
    if( isset($_POST['in_team_jobtitle']) ) imt_checkupdatecf('in_team_jobtitle', $_POST['in_team_jobtitle'], $post_id);
    if( isset($_POST['in_team_website']) ) imt_checkupdatecf('in_team_website', $_POST['in_team_website'], $post_id);
}

function imt_metabox_tsm($team){
    $fb_link = esc_html(get_post_meta($team->ID, 'indeed_fb_lnk', true));
    $tw_link = esc_html(get_post_meta($team->ID, 'indeed_tw_lnk', true));
    $lk_link = esc_html(get_post_meta($team->ID, 'indeed_ld_lnk', true));
    $g_link = esc_html(get_post_meta($team->ID, 'indeed_gp_lnk', true));
    $isg_link = esc_html(get_post_meta($team->ID, 'indeed_ins_lnk', true));
    ?>
    <table class="it-table">
        <tr>
            <td class="it-label"><i class="icon-share"></i> Facebook: </td>
            <td>
                <input type="text" value="<?php echo $fb_link;?>" name="indeed_fb_lnk" />
            </td>
        </tr>
        <tr>
            <td class="it-label"><i class="icon-share"></i> Twiter: </td>
            <td>
                <input type="text" value="<?php echo $tw_link;?>" name="indeed_tw_lnk" />
            </td>
        </tr>
        <tr>
            <td class="it-label"><i class="icon-share"></i> Linkedin: </td>
            <td>
                <input type="text" value="<?php echo $lk_link;?>" name="indeed_ld_lnk" />
            </td>
        </tr>
	</table>
	<table class="it-table">
        <tr>
            <td class="it-label"><i class="icon-share"></i> Google: </td>
            <td>
                <input type="text" value="<?php echo $g_link;?>" name="indeed_gp_lnk" />
            </td>
        </tr>
        <tr>
            <td class="it-label"><i class="icon-share"></i> Instagram: </td>
            <td>
                <input type="text" value="<?php echo $isg_link;?>" name="indeed_ins_lnk" />
            </td>
         </tr>
     </table>
	 <div class="clear"></div>
 <?php
 }
function imt_save_tsm($post_id){
    if( isset($_POST['indeed_fb_lnk']) ) imt_checkupdatecf('indeed_fb_lnk', $_POST['indeed_fb_lnk'], $post_id);
    if( isset($_POST['indeed_tw_lnk']) ) imt_checkupdatecf('indeed_tw_lnk', $_POST['indeed_tw_lnk'], $post_id);
    if( isset($_POST['indeed_ld_lnk']) ) imt_checkupdatecf('indeed_ld_lnk', $_POST['indeed_ld_lnk'], $post_id);
    if( isset($_POST['indeed_gp_lnk']) ) imt_checkupdatecf('indeed_gp_lnk', $_POST['indeed_gp_lnk'], $post_id);
    if( isset($_POST['indeed_ins_lnk']) ) imt_checkupdatecf('indeed_ins_lnk', $_POST['indeed_ins_lnk'], $post_id);
}

function imt_metabox_ts($team){
    for($i=0;$i<4;$i++){
        $skill_arr[] = esc_html(get_post_meta($team->ID, 'indeed_team_skill_'.$i, true));
        $percent[] = esc_html(get_post_meta($team->ID, 'indeed_skill_percent_'.$i, true));
    }
    ?>
    <table class="it-table">
    <?php
        foreach($skill_arr as $k=>$skill){
    ?>
              <tr>
                  <td class="it-label"><i class="icon-check"></i> Skill Name: </td>
                  <td>
                      <input type="text" value="<?php echo $skill;?>" name="indeed_team_skill_<?php echo $k;?>" />
                  </td>
                  <td> - </td>
                  <td>
                      <input type="number" min="0" max="100" value="<?php echo $percent[$k];?>" name="indeed_skill_percent_<?php echo $k;?>" style="width:45px; min-width:45px;" />%
                  </td>
              </tr>
    <?php
        }
    ?>
    </table>
	<div class="clear"></div>
    <?php
}
function imt_save_ts($post_id){
    for($i=0;$i<4;$i++){
        if( isset($_POST['indeed_team_skill_'.$i]) ) imt_checkupdatecf('indeed_team_skill_'.$i, $_POST['indeed_team_skill_'.$i], $post_id);
        if( isset($_POST['indeed_skill_percent_'.$i]) ) imt_checkupdatecf('indeed_skill_percent_'.$i, $_POST['indeed_skill_percent_'.$i], $post_id);
    }
}

?>