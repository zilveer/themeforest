<?php
if (!class_exists('TL_Layers_Abstract_Widget')) { return; }

if (!class_exists('TL_Layers_Pricetable_Widget')) {
    class TL_Layers_Pricetable_Widget extends TL_Layers_Abstract_Widget
    {
        /**
         *  Widget construction
         */
        public function __construct()
        {
            /**
             * Widget variables
             *
             * @param    string $widget_title Widget title
             * @param    string $widget_id Widget slug for use as an ID/classname
             * @param    string $post_type (optional) Post type for use in widget options
             * @param    string $taxonomy (optional) Taxonomy slug for use as an ID/classname
             * @param    array $checkboxes (optional) Array of checkbox names to be saved in this widget. Don't forget these please!
             */
            $this->widget_title = __('TL Price Table', TL_INSERT_STAFF_SLUG);
            $this->widget_id = 'tl_pricetable';
            $this->post_type = '';
            $this->taxonomy = '';
            $this->checkboxes = array('primary', 'shadow');


            /* Widget settings. */
            $widget_ops = array('classname' => 'obox-layers-' . $this->widget_id . '-widget', 'description' => __('This widget is used to display your ', TL_INSERT_STAFF_SLUG) . $this->widget_title . '.');

            /* Widget control settings. */
            $control_ops = array('width' => LAYERS_WIDGET_WIDTH_LARGE, 'height' => NULL, 'id_base' => LAYERS_THEME_SLUG . '-widget-' . $this->widget_id);

            /* Create the widget. */
            parent::__construct(LAYERS_THEME_SLUG . '-widget-' . $this->widget_id, $this->widget_title, $widget_ops, $control_ops);

            /* Setup Widget Defaults */
            $this->defaults = array(
                'title' => __('Our Rates', TL_INSERT_STAFF_SLUG),
                'excerpt' => __('At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti.', TL_INSERT_STAFF_SLUG),
                'link' => '',
                'design' => array(
                    'layout' => 'layout-boxed',
                    'columns' => '3',
                    'gutter' => 'on',
                    'background' => array(
                        'position' => 'center',
                        'repeat' => 'no-repeat'
                    ),
                    'fonts' => array(
                        'align' => 'text-left',
                        'size' => 'medium',
                        'color' => NULL,
                        'excerpt-color' => NULL,
                        'shadow' => NULL
                    )
                ),
            );

            $this->register_repeater_defaults('column', 3, array(
                'title' => __('Your Item Title', TL_INSERT_STAFF_SLUG),
                'sub_title' => __('Your Item Subtitle', TL_INSERT_STAFF_SLUG),
                'excerpt' => __('Give us a brief description of the service that you are promoting. Try keep it short so that it is easy for people to scan your page.', TL_INSERT_STAFF_SLUG),
                'period' => __('month', TL_INSERT_STAFF_SLUG),
                'currency' => '$',
                'price' => '00',
                'sub_price' => '00',
                'design' => array(
                    'bg_colors' => array(
                        'column' => null,
                        'features' => null,
                        'button' => null,
                        'button_hover' => null,
                    ),
                    'text_colors' => array(
                        'heading' => null,
                        'sub_heading' => null,
                        'features' => null,
                        'button' => null,
                        'button_hover' => null,
                    )
                )
            ));

            $this->_addFilter();
        }


        /**
         * Render widget at front
         *
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        {
            $this->backup_inline_css();

            // Turn $args array into variables.
            extract($args);

            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            // Apply Section Styling
            $this->_apply_widget_section_styling($widget_id, $widget);


            /**
             * Generate the widget container class
             */
            $widget_container_class = array();
            $widget_container_class[] = 'widget content-vertical-massive tl-pricetable-widget';
            $widget_container_class[] = $this->check_and_return($widget, 'design', 'advanced', 'customclass');
            $widget_container_class[] = $this->get_widget_spacing_class($widget);
            $widget_container_class = implode(' ', apply_filters('layers_'.$this->widget_id.'_widget_container_class', $widget_container_class, $this, $widget)); ?>

            <div class="<?php echo esc_attr($widget_container_class); ?>" id="<?php echo esc_attr($widget_id); ?>">
                <?php
                    echo $this->custom_anchor( $widget );
                    do_action( 'layers_before_'.$this->widget_id.'_widget_inner', $this, $widget );
                ?>
                <?php if ('' != $this->check_and_return($widget, 'title') || '' != $this->check_and_return($widget, 'excerpt')) { ?>
                    <div class="container clearfix">
                        <?php
                        /**
                         * Generate the Section Title Classes
                         */
                        $section_title_class = array();
                        $section_title_class[] = 'section-title clearfix';
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'size');
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'align');
                        $section_title_class[] = ($this->check_and_return($widget, 'design', 'background', 'color') && 'dark' == tl_layers_is_light_or_dark_recalculated($this->check_and_return($widget, 'design', 'background', 'color')) ? 'invert' : '');
                        $section_title_class = implode(' ', $section_title_class); ?>
                        <div class="<?php echo esc_attr($section_title_class); ?>">
                            <?php if ('' != $widget['title']) { ?>
                                <h3 class="heading">
                                    <?php echo apply_filters('tl_colorize_title_' . $this->widget_id, esc_html($widget['title'])); ?>
                                </h3>
                            <?php } ?>
                            <?php if ('' != $widget['excerpt']) { ?>
                                <div class="excerpt"><?php echo $widget['excerpt']; ?></div>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>


                <?php if (!empty($widget['columns'])) { ?>
                    <div class="list-grid <?php echo esc_attr($this->get_widget_layout_class($widget)); ?>">
                        <?php // Set total width so that we can apply .last to the final container
                        $total_width = 0;
                        $column_width = 4;
                        ?>

                        <div class="grid pricing-table">

                            <?php foreach (explode(',', $widget['column_ids']) as $column_key) {

                                // Make sure we've got a column going on here
                                if (!isset($widget['columns'][$column_key])) continue;

                                // Setup the relevant slide
                                $column = $widget['columns'][$column_key];

                                // Inline style for element backgrounds
                                if (!empty($column['design']['bg_colors']['column'])) {
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' .price-item-inner', 'css', 'background-color:' . $column['design']['bg_colors']['column'] . ';');
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' .pricetable-body span.arrow', 'css', 'border-top-color:' . $column['design']['bg_colors']['column'] . ';');
                                }

                                if (!empty($column['design']['bg_colors']['features']))
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' .pricetable-body', 'css', 'background-color: ' . $column['design']['bg_colors']['features'] . ';');

                                if (!empty($column['design']['bg_colors']['button']))
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' a.button', 'css', 'background-color: ' . $column['design']['bg_colors']['button'] . ';');

                                if (!empty($column['design']['bg_colors']['button_hover']))
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' a.button:hover', 'css', 'background-color: ' . $column['design']['bg_colors']['button_hover'] . ';');

                                // Inline style for text coloring

                                if (!empty($column['design']['text_colors']['heading']))
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'color', array('selectors' => array('h5.heading'), 'color' => $column['design']['text_colors']['heading']));

                                if (!empty($column['design']['text_colors']['sub_heading'])) {
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'color', array('selectors' => array('.pricetable-subtitle'), 'color' => $column['design']['text_colors']['sub_heading']));
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'border', array('selectors' => array('.pricetable-subtitle:before', '.pricetable-subtitle:after'), 'border' => array('color' => $column['design']['text_colors']['sub_heading'])));
                                }

                                if (!empty($column['design']['text_colors']['features']))
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'color', array('selectors' => array('.pricetable-body',
                                        '.pricetable-body li',
                                        '.pricetable-body p'),
                                        'color' => $column['design']['text_colors']['features']));

                                if (!empty($column['design']['text_colors']['button']))
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'color', array('selectors' => array('a.button'), 'color' => $column['design']['text_colors']['button']));

                                if (!empty($column['design']['text_colors']['button_hover']))
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'color', array('selectors' => array('a.button:hover'), 'color' => $column['design']['text_colors']['button_hover']));


                                // Add the correct span class
                                $span_class = 'span-' . $column_width;

                                // Add .last to the final column
                                $total_width += $column_width;

                                if (12 == $total_width) {
                                   // $span_class .= ' last';
                                    $total_width = 0;
                                } elseif ($total_width > 12) {
                                    $total_width = 0;
                                }

                                // Set the column link
                                $link = $this->check_and_return($column, 'link');

                                /**
                                 * Set Individual Column CSS
                                 */
                                $column_class = array();
                                $column_class[] = 'layers-masonry-column pricing-table-column';
                                $column_class[] = $span_class;
                                $column_class[] = 'column' . ('on' != $this->check_and_return($widget, 'design', 'gutter') ? '-flush' : '');

                                if ('' != $this->check_and_return($column, 'design', 'background', 'color')) {
                                    $column_class[] = 'content';
                                }

                                $column_class[] = ('on' == $this->check_and_return($column, 'design', 'primary')) ? 'primary' : '';
                                $column_class[] = ('on' == $this->check_and_return($column, 'design', 'shadow')) ? 'has-shadow' : '';

                                $column_class = implode(' ', $column_class); ?>

                                <div id="<?php echo esc_attr($widget_id); ?>-<?php echo esc_attr($column_key); ?>" class="<?php echo esc_attr($column_class); ?>">
                                    <?php
                                    /**
                                     * Set Overlay CSS Classes
                                     */
                                    $column_inner_class = array();
                                    $column_inner_class[] = 'price-item-inner';
                                    if (!$this->check_and_return($widget, 'design', 'gutter')) {
                                        $column_inner_class[] = 'no-push-bottom';
                                    }

                                    $column_inner_class = implode(' ', $column_inner_class); ?>

                                    <div class="<?php echo esc_attr($column_inner_class); ?>">

                                        <header>
                                            <h5 class="heading"><?php echo esc_html($column['title']); ?></h5>

                                            <p class="pricetable-subtitle"><?php echo esc_html($column['sub_title']); ?></p>
                                        </header>

                                        <section class="pricetable-body">
                                            <span class="arrow"></span>

                                            <div class="pricing-plan-price">

                                                <span class="pricing-plan-number">
                                                     <sup class="pricing-plan-currency"><?php echo esc_html($column['currency']); ?></sup>
                                                     <span style="display: inline-block;"><?php echo esc_html($column['price']); ?></span>
                                                         <sup class="pricing-plan-decimal"><?php echo esc_html($column['sub_price']); ?></sup>
                                                         <sub class="pricing-plan-period">/<?php echo esc_html($column['period']); ?></sub>
                                                </span>

                                            </div>
                                            <div class="excerpt"><?php echo $column['excerpt']; ?></div>
                                        </section>

                                        <footer>
                                            <?php if ($this->check_and_return($column, 'link_text')) { ?>
                                                <a href="<?php echo esc_url($link); ?>" class="button btn-medium">
                                                    <?php echo esc_html($column['link_text']); ?>
                                                    <i class="icon-ti-angle-double-right"></i>
                                                </a>
                                            <?php } ?>
                                        </footer>

                                    </div>
                                </div>
                            <?php } // main foreach by columns ?>
                        </div>
                        <!-- .pricing-table -->
                    </div><!-- .grid -->
                <?php } // columns
                ?>

                <?php if (isset($widget['link']) && $widget['link'] != ''): ?>
                    <div class="container aligncenter">
                        <a class="button btn-medium" title="<?php _e('View All Rates', TL_INSERT_STAFF_SLUG); ?>" href="<?php echo get_the_permalink($widget['link']); ?>">
                            <?php echo strtoupper(__('View All Rates', TL_INSERT_STAFF_SLUG)); ?>
                            <i class="icon-ti-angle-double-right"></i>
                        </a>
                    </div>
                <?php endif;

                do_action( 'layers_after_' . $this->id . '_widget_inner', $this, $widget );

                // Print the Inline Styles for this Widget
                $this->print_inline_css();

                // Apply the advanced widget styling
                $this->apply_widget_advanced_styling($widget_id, $widget);
                ?>
            </div>
        <?php }



        /**
         *  Widget form
         *
         * @param array $instance
         * @return string|void
         */
        public function form($instance)
        {
            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            if (TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_start('tl_sanitize_output');

            $this->design_bar(
                'side', // CSS Class Name
                array(
                    'name' => $this->get_layers_field_name('design'),
                    'id' => $this->get_layers_field_id('design'),
                    'widget_id' => $this->widget_id,
                ), // Widget Object
                $widget, // Widget Values
                apply_filters('layers_' . $this->widget_id . '_widget_design_bar_components', array(
                    'layout',
                    'gutter' => array(
                        'icon-css' => 'icon-list-masonry',
                        'label' => __('Gutter', 'layerswp'),
                        'wrapper-class' => 'layers-small to layers-pop-menu-wrapper layers-animate',
                        'elements' => array(
                            'gutter' => array(
                                'type' => 'checkbox',
                                'label' => __('Gutter', 'layerswp'),
                                'name' => $this->get_layers_field_name('design', 'gutter'),
                                'id' => $this->get_layers_field_id('design', 'gutter'),
                                'value' => (isset($widget['design']['gutter'])) ? $widget['design']['gutter'] : NULL
                            )
                        )
                    ),
                    'fonts',
                    'background',
                    'advanced'
                )) // Standard Components
            ); ?>

            <div class="layers-container-large widget-<?php echo esc_attr($this->widget_id)?>"
                 id="layers-<?php echo esc_attr($this->widget_id); ?>-widget-<?php echo esc_attr($this->number); ?>">
                <?php $this->form_elements()->header(array(
                    'title' => __('Price Table', TL_INSERT_STAFF_SLUG),
                    'icon_class' => 'text'
                )); ?>
                <section class="layers-accordion-section layers-content">
                    <p class="layers-form-item">
                        <?php echo $this->form_elements()->input(
                            array(
                                'type' => 'text',
                                'name' => $this->get_layers_field_name('title'),
                                'id' => $this->get_layers_field_id('title'),
                                'placeholder' => __('Enter title here', TL_INSERT_STAFF_SLUG),
                                'value' => (isset($widget['title'])) ? $widget['title'] : NULL,
                                'class' => 'layers-text layers-large'
                            )
                        ); ?>
                    </p>

                    <p class="layers-form-item">
                        <?php echo $this->form_elements()->input(
                            array(
                                'type' => 'rte',
                                'name' => $this->get_layers_field_name('excerpt'),
                                'id' => $this->get_layers_field_id('excerpt'),
                                'label' => 'Short Excerpt',
                                'placeholder' => __('Short Excerpt', TL_INSERT_STAFF_SLUG),
                                'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                'class' => 'layers-textarea layers-large'
                            )
                        ); ?>
                    </p>

                    <p class="layers-form-item">
                        <label for="<?php echo esc_attr($this->get_layers_field_id('link')); ?>"><?php _e('Button Link', TL_INSERT_STAFF_SLUG); ?></label>
                        <?php echo $this->form_elements()->input(array(
                            'type' => 'select',
                            'name' => $this->get_layers_field_name('link'),
                            'id' => $this->get_layers_field_id('link'),
                           // 'label' => __('Select a Page', TL_INSERT_STAFF_SLUG),
                            'options' => tl_get_posts(array('post_type' => 'page')),
                            'value' => (isset($widget['link'])) ? $widget['link'] : NULL,
                            'class' => 'layers-select layers-large tl-select-post-item',
                            'placeholder' => __('Select a link for bottom button', TL_INSERT_STAFF_SLUG),
                        ));
                        ?>
                    </p>

                    <!--<p class="layers-form-item">
                        <label for="<?php /*echo esc_attr($this->get_layers_field_id('link_lbl')); */?>"><?php /*_e('Button Label', TL_INSERT_STAFF_SLUG); */?></label>
                        <?php /*echo $this->form_elements()->input(array(
                            'type' => 'text',
                            'name' => $this->get_layers_field_name('link_lbl'),
                            'id' => $this->get_layers_field_id('link_lbl'),
                            // 'label' => __('Select a Page', TL_INSERT_STAFF_SLUG),
                            'value' => (isset($widget['link_lbl'])) ? $widget['link_lbl'] : NULL,
                            'class' => 'layers-text layers-large',
                            'placeholder' => __('Button Label...', TL_INSERT_STAFF_SLUG),
                        ));
                        */?>
                    </p>-->

                </section>
                <section class="layers-accordion-section layers-content">
                    <div class="layers-form-item">
                        <?php $this->repeater('column', $widget); ?>
                    </div>
                </section>
            </div>
            <?php
            if (TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_end_flush();
        } // Form


        /**
         * Column in administration panel
         *
         * @param $item_guid
         * @param $widget
         */
        public function column_item($item_guid, $widget)
        {
            ob_start();
            ?>
            <li class="layers-accordion-item" data-guid="<?php echo esc_attr($item_guid); ?>">
                <a class="layers-accordion-title">
						<span>
							<?php _e('Column', 'layerswp'); ?>
                            <span class="layers-detail">
								<?php echo(isset($widget['title']) ? ': ' . substr(stripslashes(strip_tags($widget['title'])), 0, 50) : NULL); ?>
                                <?php echo(isset($widget['title']) && strlen($widget['title']) > 50 ? '...' : NULL); ?>
							</span>
						</span>
                </a>
                <section class="layers-accordion-section layers-content">
                    <?php $this->design_bar(
                        'top', // CSS Class Name
                        array(
                            'name' => $this->get_layers_field_name('design'),
                            'id' => $this->get_layers_field_id('design'),
                            'widget_id' => $this->widget_id . '_item',
                            'number' => $this->number,
                            'show_trash' => true
                        ), // Widget Object
                        $widget, // Widget Values
                        apply_filters('layers_' . $this->widget_id . '_widget_column_design_bar_components', array(
                            'text_colors' => array(
                                'icon-css' => 'icon-font-size',
                                'label' => 'Text Colors',
                                'elements' => array(
                                    'heading' => array(
                                        'type' => 'color',
                                        'label' => __('HEADING TEXT', 'layerwp'),
                                        'name' => $this->get_layers_field_name('design', 'text_colors', 'heading'),
                                        'id' => $this->get_layers_field_id('design', 'text_colors', 'heading'),
                                        'value' => (isset($widget['design']['text_colors']['heading'])) ? $widget['design']['text_colors']['heading'] : NULL,
                                    ),
                                    'sub_heading' => array(
                                        'type' => 'color',
                                        'label' => __('SUB HEADING TEXT', 'layerwp'),
                                        'name' => $this->get_layers_field_name('design', 'text_colors', 'sub_heading'),
                                        'id' => $this->get_layers_field_id('design', 'text_colors', 'sub_heading'),
                                        'value' => (isset($widget['design']['text_colors']['sub_heading'])) ? $widget['design']['text_colors']['sub_heading'] : NULL,
                                    ),
                                    'features' => array(
                                        'type' => 'color',
                                        'label' => __('BODY TEXT', 'layerwp'),
                                        'name' => $this->get_layers_field_name('design', 'text_colors', 'features'),
                                        'id' => $this->get_layers_field_id('design', 'text_colors', 'features'),
                                        'value' => (isset($widget['design']['text_colors']['features'])) ? $widget['design']['text_colors']['features'] : NULL,
                                    ),
                                    'button' => array(
                                        'type' => 'color',
                                        'label' => __('BUTTON TEXT', 'layerwp'),
                                        'name' => $this->get_layers_field_name('design', 'text_colors', 'button'),
                                        'id' => $this->get_layers_field_id('design', 'text_colors', 'button'),
                                        'value' => (isset($widget['design']['text_colors']['button'])) ? $widget['design']['text_colors']['button'] : NULL,
                                    ),
                                    'button_hover' => array(
                                        'type' => 'color',
                                        'label' => __('BUTTON TEXT HOVER', 'layerwp'),
                                        'name' => $this->get_layers_field_name('design', 'text_colors', 'button_hover'),
                                        'id' => $this->get_layers_field_id('design', 'text_colors', 'button_hover'),
                                        'value' => (isset($widget['design']['text_colors']['button_hover'])) ? $widget['design']['text_colors']['button_hover'] : NULL,
                                    ),
                                )
                            ),
                            'bg_colors' => array(
                                'icon-css' => 'icon-photo',
                                'label' => 'Backgroud Colors',
                                'elements' => array(
                                    'column_bg' => array(
                                        'type' => 'color',
                                        'label' => __('COLUMN BACKGROUND', 'layerwp'),
                                        'name' => $this->get_layers_field_name('design', 'bg_colors', 'column'),
                                        'id' => $this->get_layers_field_id('design', 'bg_colors', 'column'),
                                        'value' => (isset($widget['design']['bg_colors']['column'])) ? $widget['design']['bg_colors']['column'] : NULL,
                                    ),
                                    'features' => array(
                                        'type' => 'color',
                                        'label' => __('BODY BACKGROUND', 'layerwp'),
                                        'name' => $this->get_layers_field_name('design', 'bg_colors', 'features'),
                                        'id' => $this->get_layers_field_id('design', 'bg_colors', 'features'),
                                        'value' => (isset($widget['design']['bg_colors']['features'])) ? $widget['design']['bg_colors']['features'] : NULL,
                                    ),
                                    'button_bg' => array(
                                        'type' => 'color',
                                        'label' => __('BUTTON BACKGROUND', 'layerwp'),
                                        'name' => $this->get_layers_field_name('design', 'bg_colors', 'button'),
                                        'id' => $this->get_layers_field_id('design', 'bg_colors', 'button'),
                                        'value' => (isset($widget['design']['bg_colors']['button'])) ? $widget['design']['bg_colors']['button'] : NULL,
                                    ),
                                    'button_hover_bg' => array(
                                        'type' => 'color',
                                        'label' => __('BUTTON HOVER BG', 'layerwp'),
                                        'name' => $this->get_layers_field_name('design', 'bg_colors', 'button_hover'),
                                        'id' => $this->get_layers_field_id('design', 'bg_colors', 'button_hover'),
                                        'value' => (isset($widget['design']['bg_colors']['button_hover'])) ? $widget['design']['bg_colors']['button_hover'] : NULL,
                                    ),
                                )
                            ),
                            'advanced-options' => array(
                                'icon-css' => 'icon-settings',
                                'label' => 'Advanced options',
                                'elements' => array(
                                    'primary' => array(
                                        'type' => 'checkbox',
                                        'label' => __('Primary', 'layerwp'),
                                        'name' => $this->get_layers_field_name('design', 'primary'),
                                        'id' => $this->get_layers_field_id('design', 'primary'),
                                        'value' => (isset($widget['design']['primary'])) ? $widget['design']['primary'] : NULL,
                                    ),
                                    'shadow' => array(
                                        'type' => 'checkbox',
                                        'label' => __('Add Shadow', 'layerwp'),
                                        'name' => $this->get_layers_field_name('design', 'shadow'),
                                        'id' => $this->get_layers_field_id('design', 'shadow'),
                                        'value' => (isset($widget['design']['shadow'])) ? $widget['design']['shadow'] : NULL,
                                    )
                                )
                            )
                        ))
                    ); ?>
                    <div class="layers-panel">
                        <div class="layers-content">
                            <div class="layers-panel-title">
                                <h4 class="heading"><?php _e('Headings & Price', TL_INSERT_STAFF_SLUG); ?></h4>
                            </div>
                            <div class="layers-row">
                                <p class="layers-form-item">
                                    <label for="<?php echo esc_attr($this->get_layers_field_id('title')); ?>"><?php _e('Title', TL_INSERT_STAFF_SLUG); ?></label>
                                    <?php echo $this->form_elements()->input(
                                        array(
                                            'type' => 'text',
                                            'name' => $this->get_layers_field_name('title'),
                                            'id' => $this->get_layers_field_id('title'),
                                            'placeholder' => __('Enter title here', TL_INSERT_STAFF_SLUG),
                                            'value' => (isset($widget['title'])) ? $widget['title'] : NULL,
                                            'class' => 'layers-text'
                                        )
                                    ); ?>
                                </p>

                                <p class="layers-form-item">
                                    <label for="<?php echo esc_attr($this->get_layers_field_id('sub_title')); ?>"><?php _e('Sub Title', TL_INSERT_STAFF_SLUG); ?></label>
                                    <?php echo $this->form_elements()->input(
                                        array(
                                            'type' => 'text',
                                            'name' => $this->get_layers_field_name('sub_title'),
                                            'id' => $this->get_layers_field_id('sub_title'),
                                            'placeholder' => __('Enter subtitle here', TL_INSERT_STAFF_SLUG),
                                            'value' => (isset($widget['sub_title'])) ? $widget['sub_title'] : NULL,
                                            'class' => 'layers-text'
                                        )
                                    ); ?>
                                </p>
                            </div>
                            <p></p>

                            <div class="layers-row">
                                <p class="layers-form-item layers-column layers-span-3">
                                    <label
                                        for="<?php echo esc_attr($this->get_layers_field_id('price')); ?>"><?php _e('Price', TL_INSERT_STAFF_SLUG); ?></label>
                                    <?php echo $this->form_elements()->input(
                                        array(
                                            'type' => 'text',
                                            'name' => $this->get_layers_field_name('price'),
                                            'id' => $this->get_layers_field_id('price'),
                                            'placeholder' => __('Price', TL_INSERT_STAFF_SLUG),
                                            'value' => (isset($widget['price'])) ? $widget['price'] : NULL,
                                            'class' => 'layers-text',
                                        )
                                    ); ?>
                                </p>

                                <p class="layers-form-item layers-column layers-span-3">
                                    <label for="<?php echo esc_attr($this->get_layers_field_id('sub_price')); ?>"><?php _e('Sub price', TL_INSERT_STAFF_SLUG); ?></label>
                                    <?php echo $this->form_elements()->input(
                                        array(
                                            'type' => 'text',
                                            'name' => $this->get_layers_field_name('sub_price'),
                                            'id' => $this->get_layers_field_id('sub_price'),
                                            'placeholder' => __('Sub price', TL_INSERT_STAFF_SLUG),
                                            'value' => (isset($widget['sub_price'])) ? $widget['sub_price'] : NULL,
                                            'class' => 'layers-text',
                                        )
                                    ); ?>
                                </p>

                                <p class="layers-form-item layers-column layers-span-3">
                                    <label
                                        for="<?php echo esc_attr($this->get_layers_field_id('currency')); ?>"><?php _e('Currency', TL_INSERT_STAFF_SLUG); ?></label>
                                    <?php echo $this->form_elements()->input(
                                        array(
                                            'type' => 'text',
                                            'name' => $this->get_layers_field_name('currency'),
                                            'id' => $this->get_layers_field_id('currency'),
                                            'placeholder' => __('Currency', TL_INSERT_STAFF_SLUG),
                                            'value' => (isset($widget['currency'])) ? $widget['currency'] : NULL,
                                            'class' => 'layers-text',
                                        )
                                    ); ?>
                                </p>

                                <p class="layers-form-item layers-column layers-span-3">
                                    <label
                                        for="<?php echo esc_attr($this->get_layers_field_id('period')); ?>"><?php _e('Period', TL_INSERT_STAFF_SLUG); ?></label>
                                    <?php echo $this->form_elements()->input(
                                        array(
                                            'type' => 'text',
                                            'name' => $this->get_layers_field_name('period'),
                                            'id' => $this->get_layers_field_id('period'),
                                            'placeholder' => __('Period', TL_INSERT_STAFF_SLUG),
                                            'value' => (isset($widget['period'])) ? $widget['period'] : NULL,
                                            'class' => 'layers-text',
                                        )
                                    ); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="layers-panel">
                        <div class="layers-content">
                            <div class="layers-panel-title">
                                <h4 class="heading"><?php _e('Body', TL_INSERT_STAFF_SLUG); ?></h4>
                            </div>
                            <div class="layers-row">
                                <p class="layers-form-item">
                                    <label
                                        for="<?php echo esc_attr($this->get_layers_field_id('excerpt')); ?>"><?php _e('Features', TL_INSERT_STAFF_SLUG); ?></label>
                                    <?php echo $this->form_elements()->input(
                                        array(
                                            'type' => 'rte',
                                            'name' => $this->get_layers_field_name('excerpt'),
                                            'id' => $this->get_layers_field_id('excerpt'),
                                            'placeholder' => __('Features', TL_INSERT_STAFF_SLUG),
                                            'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                            'class' => 'layers-form-item layers-textarea',
                                            'rows' => 8,
                                        )
                                    ); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="layers-panel">
                        <div class="layers-content">
                            <div class="layers-panel-title"><h4 class="heading"><?php _e('Footer', TL_INSERT_STAFF_SLUG); ?></h4></div>
                            <div class="layers-row">
                                <div class="layers-row">
                                    <p class="layers-form-item layers-column layers-span-6">
                                        <label for="<?php echo esc_attr($this->get_layers_field_id('link')); ?>"><?php _e('Button Link', TL_INSERT_STAFF_SLUG); ?></label>
                                        <?php echo $this->form_elements()->input(
                                            array(
                                                'type' => 'text',
                                                'name' => $this->get_layers_field_name('link'),
                                                'id' => $this->get_layers_field_id('link'),
                                                'placeholder' => __('http://', 'layerswp'),
                                                'value' => (isset($widget['link'])) ? $widget['link'] : NULL,
                                                'class' => 'layers-text',
                                            )
                                        ); ?>
                                    </p>

                                    <p class="layers-form-item layers-column layers-span-6">
                                        <label
                                            for="<?php echo esc_attr($this->get_layers_field_id('link_text')); ?>"><?php _e('Button Text', TL_INSERT_STAFF_SLUG); ?></label>
                                        <?php echo $this->form_elements()->input(
                                            array(
                                                'type' => 'text',
                                                'name' => $this->get_layers_field_name('link_text'),
                                                'id' => $this->get_layers_field_id('link_text'),
                                                'placeholder' => __('e.g. "Read More"', TL_INSERT_STAFF_SLUG),
                                                'value' => (isset($widget['link_text'])) ? $widget['link_text'] : NULL
                                            )
                                        ); ?>
                                    </p>
                                </div>
                                <!-- .layers-row -->
                            </div>
                        </div>
                    </div>
                    <!-- .layers-panel -->
                </section>
            </li>
            <?php

            $form = ob_get_clean();
            $form = preg_replace('/>[\n\t]+</', '><', $form);
            echo str_replace("\t", '', $form);

        }


        /**
         *
         */
        protected function _addFilter()
        {
            add_filter('tl_colorize_title_' . $this->widget_id, 'tl_colorize_title', 10, 2);

            add_filter('tl/layers/background_component/' . $this->widget_id . '/args', array($this, 'customizeBackgroundComponent'), 10, 4);
            add_filter('tl/layers/fonts_component/' . $this->widget_id . '/args', array($this, 'customizeFontsComponent'), 10, 4);
        }


        /**
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeFontsComponent($args, $position, $widget, $values)
        {
            if ($position == 'side') {

                //Add at the beggining of the array
                $args['elements'] = array('fonts-title-heading' => array('type' => 'layers-heading', 'label' => 'Title Options')) + $args['elements'];


                // this goes to the all widgets
                $args['elements']['fonts-excerpt-heading'] = array(
                    'type' => 'layers-heading',
                    'label' => 'Excerpt Options',
                );

                $args['elements']['fonts-excerpt-color'] = array(
                    'type' => 'color',
                    'label' => 'Excerpt Color',
                    'name' => $widget['name'] . '[fonts][excerpt-color]',
                    'id' => $widget['id'] . '-fonts-excerpt-color',
                    'value' => isset($values['fonts']['excerpt-color']) ? $values['fonts']['excerpt-color'] : null,
                );
            }
            return $args;
        }


        public function customizeBackgroundComponent($args, $position, $widget, $values)
        {
            if ($position == 'side') {
                unset($args['elements']['background-darken']);
            }
            return $args;
        }


        public function customizeButtonsComponent($args, $position, $widget, $values)
        {
            if ($position == 'side') {
                unset($args['elements']['buttons-size']);
            }
            return $args;
        }

    } // Class

    // Add our function to the widgets_init hook.
    register_widget("TL_Layers_Pricetable_Widget");
} // If