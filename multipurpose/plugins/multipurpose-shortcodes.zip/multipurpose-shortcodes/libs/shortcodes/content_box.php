<?php
if (!defined('_MULTIPURPOSE_SHORTCODE')) die('Access denied');

// shortcode for content_box
add_shortcode('content_box', 'multipurpose_content_box');

function multipurpose_content_box($atts, $content = null) {

    $box_type = '';
    extract(shortcode_atts(array(
        'box_type' => ''
    ), $atts));

    $output = '<div class="box';

    if ($box_type != '' && $box_type != 'normal')
    {
        $output .= ' ' . $box_type;
    }
    
    $output .= '">';

    $output .= do_shortcode($content);
    $output .= '</div>';

    return $output;
}
