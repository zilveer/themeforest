<?php
/*
Plugin Name: Extra Fonts
Plugin URI: http://themeforest.net/user/Pirenko/portfolio
Description: Plugin that adds extra fonts to work with themes by Pirenko
Version: 1.0
Author: Pirenko
Author URI: http://www.pirenko.com
License: GPLv2
*/
define( 'PRK_FONTS_DIR', WP_PLUGIN_DIR . '/astro_framework/prk_fonts');
add_action('admin_menu', 'prk_extra_fonts_admin_add_page');
function prk_extra_fonts_admin_add_page() 
{
	add_theme_page('Custom Plugin Page', 'Extra Fonts', 'manage_options', 'prk_fonts', 'plugin_options_page');
}
function plugin_options_page() 
{
	?>
	<div class="wrap prk_fonts_wrapper">
	<div class="icon32" id="icon-themes"></div>
	<h2>Extra Fonts Management <a class="thickbox add-new-h2" href="admin-ajax.php?action=pirenko-font-form&amp;width=640&amp;height=400" title="Add New Font">Add New</a></h2>
	<?php settings_fields('prk_fonts_options'); ?>
	<?php plugin_setting_string(); ?>
	</div>
	<?php
}

add_action('admin_init', 'plugin_admin_init');
function plugin_admin_init() 
{
	load_plugin_textdomain( 'prk_fonts_lang', PRK_FONTS_DIR . '/lang', basename( dirname( __FILE__ ) ) . '/lang' );
	add_action('wp_ajax_pirenko-font-form', 'prk_show_fonts_form');
    add_action('wp_ajax_pirenko-font-add', 'prk_add_font');
    add_action('wp_ajax_pirenko-font-remove', 'prk_remove_font');
	register_setting( 'prk_font_plugin_option', 'prk_font_plugin_option', 'plugin_options_validate' );
	$before_clear=get_option('prk_font_plugin_option');
	//CHECK IF EMPTY
	if (!isset($before_clear) || (isset($before_clear) && $before_clear==""))
	{
		update_option( 'prk_font_plugin_option', array());
	}
	add_settings_section('plugin_main', 'Main Settings', 'plugin_section_text', 'prk_fonts');
	add_settings_field('plugin_text_string', 'Plugin Text Input', 'plugin_setting_string', 'prk_fonts', 'plugin_main');
}
function plugin_section_text() { } 
function plugin_setting_string() 
{
	$options = get_option('prk_font_plugin_option');
	$options_output = '';
	if (isset($_GET["error"]) && $_GET["error"]=="true")
	{
		$options_output .= '<div class="error"><p>' . __('Error: Please make sure that you give your font a valid Name!', 'prk_fonts_lang') . '</p></div>';
	}
	if (isset($_GET["added"]) && $_GET["added"]=="true")
	{
		$options_output .= '<div class="updated"><p>' . __('Your font was successfully added!', 'prk_fonts_lang') . '</p></div>';
	}
	if (isset($_GET["removed"]) && $_GET["removed"]=="true")
	{
		$options_output .= '<div class="updated"><p>' . __('Your font was successfully removed!', 'prk_fonts_lang') . '</p></div>';
	}
    $options_output .= '<table cellspacing="0" class="wp-list-table widefat fixed media">';
    $options_output .= '<thead>';
    $options_output .= '<tr>';
    $options_output .= '<th class="column-author"><span>' . __('Font Name', 'prk_fonts_lang') . '</span></th>';
    $options_output .= '<th class="column-author"><span>' . __('Hosted', 'prk_fonts_lang') . '</span></th>';
    $options_output .= '<th><span>' . __('Font URL', 'prk_fonts_lang') . '</span></th>';
    $options_output .= '<th><span>' . __('Font CSS', 'prk_fonts_lang') . '</span></th>';
    $options_output .= '</tr>';
    $options_output .= '</thead>';
    $options_output .= '<tbody>';
    $colorizer=0;
    foreach ($options as $font) {
    	if ($font['erased']=="false")
    	{
	        $alternate_class = ($colorizer % 2 == 0) ? 'alternate' : '';
	        $options_output .= "<tr valign=\"top\" class=\"$alternate_class author-self status-inherit\">";
	        $options_output .= '<td class="title column-title"><strong>' . $font['label'] . '</strong>';
	        $options_output .= '<div class="row-actions"><span class="delete">';
	        $options_output .= '<form id="pirenko-font-remove" method="post" action="admin-ajax.php">';
	        $options_output .= '<input type="hidden" name="action" value="pirenko-font-remove" />';
	    	$options_output .= '<input type="hidden" name="nonce" value="' . wp_create_nonce('pirenko-font-remove') . '" />';
	    	$options_output .= '<input type="hidden" name="font_name" value="' . $font['label'] . '" />';
	    	$options_output .= '<input id="prk-fonts-form-submit" type="submit" value="' . __('Remove Font', 'prk_fonts_lang') . '" class="button-primary button-secondary"></form>';
	        $options_output .= '</span></div>';
	        $options_output .= '</td>';
	        $options_output .= '<td class="title column-title"><strong>' . $font['hosted'] . '</strong></td>';
	        if ($font['hosted']=="system")
	        	$options_output .= '<td class="title column-title"></td>';
	        else
	        	$options_output .= '<td class="title column-title"><strong>' . $font['value'] . '</strong></td>';
	        $options_output .= '<td class="title column-title"><strong>' . $font['css'] . '</strong></td>';
	        $colorizer++;
	    }
    }
    $options_output .= '<tfoot>';
    $options_output .= '<tr>';
    $options_output .= '<th class="column-author"><span>' . __('Font Name', 'prk_fonts_lang') . '</span></th>';
    $options_output .= '<th class="column-author"><span>' . __('Hosted', 'prk_fonts_lang') . '</span></th>';
    $options_output .= '<th><span>' . __('Font URL', 'prk_fonts_lang') . '</span></th>';
    $options_output .= '<th><span>' . __('Font CSS', 'prk_fonts_lang') . '</span></th>';
    $options_output .= '</tr>';
    $options_output .= '</tfoot>';
    $options_output .= '</tbody>';
    $options_output .= '</table>';
    $options_output .= '<div class="fonts_opt_desc">';
    $options_output .= '<h3>3 types of fonts can be used</h3>';
    $options_output .= 'Google Fonts Directory: <a href="http://www.google.com/fonts/" target="_blank">http://www.google.com/fonts/</a>';
	$options_output .= '<br><br>Self Hosted Fonts Examples: <a href="http://www.fontsquirrel.com/" target="_blank">http://www.fontsquirrel.com/</a>';
	$options_output .= '<br><br>Safe System Fonts: <a href="http://www.w3schools.com/cssref/css_websafe_fonts.asp" target="_blank">http://www.w3schools.com/cssref/css_websafe_fonts.asp</a>';
	$options_output .= '</div>';
    echo $options_output;
}
function plugin_options_validate($input) {
	return $input;
}

function prk_show_fonts_form()
{
    $output_form = '<div id="thickbox"><form id="pirenko-font-add" method="post" action="admin-ajax.php">';
    $output_form .= '<fieldset>';
    $output_form .= '<div class="fonts_options">';
    $output_form .= '<label for="font_name"><strong>' . __('Font name', 'prk_fonts_lang') . '</strong></label>';
    $output_form .= '<br><input type="text" name="font_name" class="required">';
    $output_form .= '<br><div class="clearer_fonts">'. __('How the font will be identified on the font selector', 'prk_fonts_lang') . '</div>';
    $output_form .= '</div>';
    $output_form .= '<div class="fonts_options">';
    $output_form .= '<label for="font_url"><strong>' . __('Font URL', 'prk_fonts_lang') . '</strong></label>';
    $output_form .= '<br><input type="text" name="font_url" class="required prk_full_input">';
    $output_form .= '<br><div class="clearer_fonts">' . __('Google font URL example', 'prk_fonts_lang') . ': http://fonts.googleapis.com/css?family=Fauna+One</div>';
    $output_form .= '<div class="clearer_fonts">' . __('Self hosted font example', 'prk_fonts_lang').': http://www.pirenko.com/wp-content/themes/aria/inc/fonts/bebas_neue/stylesheet.css<</div>';
    $output_form .= '<div class="clearer_fonts">' . __('For system default fonts leave this field blank', 'prk_fonts_lang').'</div>';
    $output_form .= '</div>';
    $output_form .= '<div class="fonts_options">';
    $output_form .= '<label for="font_css"><strong>' . __('CSS font-family', 'prk_fonts_lang') . '</strong></label>';
    $output_form .= '<br><input type="text" name="font_css" class="required prk_half_input">';
    $output_form .= "<div class='clearer_fonts'>". __('CSS example', 'prk_fonts_lang') . ": 'Fauna One', serif;</div>";
    $output_form .= '</div>';
    $output_form .= '<input type="hidden" name="action" value="pirenko-font-add" />';
    $output_form .= '<input type="hidden" name="nonce" value="' . wp_create_nonce('pirenko-font-add') . '" />';
    $output_form .= '<div>';
    $output_form .= '<input id="prk-fonts-form-submit" type="submit" value="' . __('Add Font', 'prk_fonts_lang') . '" class="button-primary button-secondary">';
    $output_form .= '</div>';
    $output_form .= '</fieldset>';
    $output_form .= '</form></div>';
    echo $output_form;
    die();
}
function string_starts($main, $sub)
{
    $length = strlen($sub);
    return (substr($main, 0, $length) === $sub);
}
function split_font_name($font_url)
{
    if (string_starts($font_url, 'http://fonts.googleapis.com/css?family=') ||
        string_starts($font_url, 'https://fonts.googleapis.com/css?family=')) {
        $first = stripos($font_url, '=');
        $font_name = substr($font_url, $first + 1);
        return $font_name;
    } else {
        return $font_url;
    }
}
function prk_clean_str($string) {
   $string = str_replace('', '-', $string); // Replaces all spaces with hyphens.
   return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}
function prk_add_font() {
	$font_url="";
	if (isset($_POST['font_name']) && !empty($_POST['font_name'])) 
	{
    	$font_url = trim($_POST['font_url']);
    	if ($font_url!="") {
	    	if (string_starts($font_url, 'http://fonts.googleapis.com/css?family=') || string_starts($font_url, 'https://fonts.googleapis.com/css?family=')) {
	    		$hosted='google';
	    	}
	    	else
	    	{
	    		$hosted='plugin';
	    	}
	    }
	    else
	    {
	    	$hosted='system';
	    }
		$before_append=get_option('prk_font_plugin_option');
		$last_element = count($before_append);
		$before_append[$last_element]['value']=split_font_name($font_url);
		if ($hosted=='system')
		{
			$before_append[$last_element]['value']=prk_clean_str($_POST['font_name']);
		}
		$before_append[$last_element]['hosted']=$hosted;
		$before_append[$last_element]['css']=str_replace('"',"'",stripslashes($_POST['font_css']));
		if (substr($before_append[$last_element]['css'], -1)!=";")
		{
			$before_append[$last_element]['css']=$before_append[$last_element]['css'].";";
		}
		$before_append[$last_element]['label']=$_POST['font_name'];
		$before_append[$last_element]['erased']="false";
		update_option( 'prk_font_plugin_option', $before_append);
		wp_redirect(admin_url('themes.php?page=prk_fonts&added=true'));
    }
    else
    {
    	wp_redirect(admin_url('themes.php?page=prk_fonts&error=true'));
    }
}
function prk_remove_font()
{
	//wp_redirect(admin_url('themes.php?page=prk_fonts'));
	if (isset($_POST['font_name']) && !empty($_POST['font_name'])) 
	{
		$before_remove=get_option('prk_font_plugin_option');
		$i=0;
		foreach ($before_remove as $font) {
			if ($font['label']==$_POST['font_name']) 
			{
				$before_remove[$i]['erased']="true";
			}
			$i++;
		}
		update_option( 'prk_font_plugin_option', $before_remove);
	}
	wp_redirect(admin_url('themes.php?page=prk_fonts&removed=true'));
}


