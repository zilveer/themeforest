<?php
if (!class_exists('TL_Layers_Abstract_Widget')) {
    return;
}

if (!class_exists('TL_Layers_Team_Widget')) {

    /**
     * @todo Saving icon filter to implement
     *
     * Class TL_Layers_Team_Widget
     */
    class TL_Layers_Team_Widget extends TL_Layers_Abstract_Widget
    {

        /**
         * Allowed meta keys for team CPT
         * @var
         */
        protected $_allowed_keys;


        /**
         *  Widget construction
         */
        public function __construct()
        {
            /**
             * Widget variables
             *
             * @param    string $widget_title Widget title
             * @param    string $widget_id Widget slug for use as an ID/classname
             * @param    string $post_type (optional) Post type for use in widget options
             * @param    string $taxonomy (optional) Taxonomy slug for use as an ID/classname
             * @param    array $checkboxes (optional) Array of checkbox names to be saved in this widget. Don't forget these please!
             */
            $this->widget_title = __('TL Team', TL_INSERT_STAFF_SLUG);
            $this->widget_id = 'tl_team';
            $this->post_type = 'tl_team';
            $this->taxonomy = '';
            $this->checkboxes = array(
                'gutter',
                'link_on_title',
                'show_excerpts',
                'popup',
                'show_social_icons',
                'link_on_title'
            );

            $this->_allowed_keys = apply_filters('tl/cpt_' . $this->post_type . '/get_meta_keys', null);

            /* Widget settings. */
            $widget_ops = array('classname' => 'obox-layers-' . $this->widget_id . '-widget', 'description' => __('This widget is used to display your ', 'layerswp') . $this->widget_title . '.');

            /* Widget control settings. */
            $control_ops = array('width' => LAYERS_WIDGET_WIDTH_SMALL,
                'height' => NULL,
                'id_base' => LAYERS_THEME_SLUG . '-widget-' . $this->widget_id);

            /* Create the widget. */
            parent::__construct(LAYERS_THEME_SLUG . '-widget-' . $this->widget_id, $this->widget_title, $widget_ops, $control_ops);


            /* Setup Widget Defaults */
            $this->defaults = array(
                'title' => __('HANDYMAN TEAM', TL_INSERT_STAFF_SLUG),
                'excerpt' => 'Nostra ridiculus tellus meacenes eleifend at, conubia sollicitudin repodiandea sit, nostrud debitis dicta. Quasi preasesent porttitor tellus aliquid gravida mauris.',

                //Custom options
                'text_style' => 'regular',
                'show_excerpts' => 'on',
                'excerpt_length' => 100,
                'show_social_icons' => 'on',
                'link_on_title' => 'on',
                'page_id' => null,
                'design' => array(
                    'layout' => 'layout-boxed',
                    'liststyle' => 'list-grid',
                    'columns' => '4',
                    'gutter' => 'on',
                    'background' => array(
                        'position' => 'center',
                        'repeat' => 'no-repeat',
                    ),
                    'fonts' => array(
                        'align' => 'text-center',
                        'size' => 'medium',
                        'color' => NULL,
                    )
                ),
            );

            $this->register_repeater_defaults('column', 4, array(
                'title' => __('John Smith', TL_INSERT_STAFF_SLUG),
                'excerpt' => __('Give us a brief description of the service that you are promoting. Try keep it short so that it is easy for people to scan your page.', TL_INSERT_STAFF_SLUG),
                'width' => '3',
                'team_member_id' => null,

                'icon_color' => '#ffffff',
                'icon_class' => '',

                'design' => array(
                    'imagealign' => 'image-top',
                    'imageratios' => 'image-square',
                    'background' => array(
                        'color-meta' => '#ffffff',
                        'color' => '#e2e2e2'
                    ),
                    'fonts' => array(
                        'align' => 'text-center',
                        'size' => 'medium',
                        'color' => null,
                        //Name
                        'name-align' => 'text-center',
                        'name-color' => null,
                        // Position
                        'position-color' => '#cccccc',
                    )
                )
            ));

            /* Add Filters */
            $this->_addFilters();

            $this->get_theme_colors();
        }


        /**
         * Print administration form
         *
         * @param array $instance
         * @return string|void
         */
        public function form($instance)
        {
            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            if (TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_start('tl_sanitize_output');

            $this->design_bar(
                'side', // CSS Class Name
                array(
                    'name' => $this->get_layers_field_name('design'),
                    'id' => $this->get_layers_field_id('design'),
                    'widget_id' => $this->widget_id,
                ), // Widget Object
                $widget, // Widget Values
                apply_filters('layers_' . $this->widget_id . '_widget_design_bar_components', array(
                    'layout',
                    'liststyle' => array(
                        'icon-css' => 'icon-list-masonry',
                        'label' => __('List Style', 'layerswp'),
                        'wrapper-class' => 'layers-small to layers-pop-menu-wrapper layers-animate',
                        'elements' => array(
                            'liststyle' => array(
                                'type' => 'select-icons',
                                'name' => $this->get_layers_field_name('design', 'liststyle'),
                                'id' => $this->get_layers_field_id('design', 'liststyle'),
                                'value' => (isset($widget['design']['liststyle'])) ? $widget['design']['liststyle'] : NULL,
                                'options' => array(
                                    'list-grid' => __('Grid', 'layerswp'),
                                    'list-masonry' => __('Masonry', 'layerswp')
                                )
                            ),
                            'gutter' => array(
                                'type' => 'checkbox',
                                'label' => __('Gutter', 'layerswp'),
                                'name' => $this->get_layers_field_name('design', 'gutter'),
                                'id' => $this->get_layers_field_id('design', 'gutter'),
                                'value' => (isset($widget['design']['gutter'])) ? $widget['design']['gutter'] : NULL
                            )
                        )
                    ),
                    'display' => array(
                        'icon-css' => 'icon-display',
                        'label' => __('Display', 'layerswp'),
                        'elements' => array(
                            'text_style' => array(
                                'type' => 'select',
                                'name' => $this->get_layers_field_name('text_style'),
                                'id' => $this->get_layers_field_id('text_style'),
                                'value' => (isset($widget['text_style'])) ? $widget['text_style'] : NULL,
                                'label' => __('Title &amp; Excerpt Position', 'layerswp'),
                                'options' => array(
                                    'regular' => __('Regular', 'layerswp'),
                                    'overlay' => __('Overlay', 'layerswp')
                                )
                            ),
                            'link_on_title' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('link_on_title'),
                                'id' => $this->get_layers_field_id('link_on_title'),
                                'value' => (isset($widget['link_on_title'])) ? $widget['link_on_title'] : NULL,
                                'label' => __('Add link to a member\'s name', TL_INSERT_STAFF_SLUG)
                            ),
                            'show_excerpts' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('show_excerpts'),
                                'id' => $this->get_layers_field_id('show_excerpts'),
                                'value' => (isset($widget['show_excerpts'])) ? $widget['show_excerpts'] : NULL,
                                'label' => __('Show Member Excerpts', TL_INSERT_STAFF_SLUG)
                            ),
                            'excerpt_length' => array(
                                'type' => 'number',
                                'name' => $this->get_layers_field_name('excerpt_length'),
                                'id' => $this->get_layers_field_id('excerpt_length'),
                                'min' => 0,
                                'max' => 10000,
                                'value' => (isset($widget['excerpt_length'])) ? $widget['excerpt_length'] : NULL,
                                'label' => __('Excerpts Length', 'layerswp')
                            ),
                            'popup' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('popup'),
                                'id' => $this->get_layers_field_id('popup'),
                                'value' => (isset($widget['popup'])) ? $widget['popup'] : NULL,
                                'label' => __('Show details in popup (for CPT only)', TL_INSERT_STAFF_SLUG),
                            ),
                            'show_social_icons' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('show_social_icons'),
                                'id' => $this->get_layers_field_id('show_social_icons'),
                                'value' => (isset($widget['show_social_icons'])) ? $widget['show_social_icons'] : NULL,
                                'label' => __('Show Social Links', TL_INSERT_STAFF_SLUG)
                            ),
                        )
                    ),
                    'fonts',
                    'background',
                    'advanced'
                )) // Components
            ); ?>
            <div class="layers-container-large layers-tl_column-widget"
                 id="layers-<?php echo esc_attr($this->widget_id);?>-widget-<?php echo $this->number; ?>">
                <?php $this->form_elements()->header(array(
                    'title' => 'Team',
                    'icon_class' => 'text'
                )); ?>
                <section class="layers-accordion-section layers-content">
                    <p class="layers-form-item">
                        <?php echo $this->form_elements()->input(
                            array(
                                'type' => 'text',
                                'name' => $this->get_layers_field_name('title'),
                                'id' => $this->get_layers_field_id('title'),
                                'placeholder' => __('Enter title here', 'layerswp'),
                                'value' => (isset($widget['title'])) ? $widget['title'] : NULL,
                                'class' => 'layers-text layers-large'
                            )
                        ); ?>
                    </p>

                    <p class="layers-form-item">
                        <?php echo $this->form_elements()->input(
                            array(
                                'type' => 'rte',
                                'name' => $this->get_layers_field_name('excerpt'),
                                'id' => $this->get_layers_field_id('excerpt'),
                                'placeholder' => __('Short Excerpt', 'layerswp'),
                                'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                'class' => 'layers-textarea layers-large'
                            )
                        ); ?>
                    </p>

                    <p class="layers-form-item">
                        <label
                            for="<?php echo esc_attr($this->get_layers_field_id('page_id')); ?>"><?php echo __('Team\'s page link', TL_INSERT_STAFF_SLUG); ?></label>
                        <?php echo $this->form_elements()->input(
                            array(
                                'type' => 'select',
                                'name' => $this->get_layers_field_name('page_id'),
                                'id' => $this->get_layers_field_id('page_id'),
                                'value' => (isset($widget['page_id'])) ? $widget['page_id'] : NULL,
                                'options' => tl_get_posts(array('post_type' => 'page')),
                                'placeholder' => __('-- None --', TL_INSERT_STAFF_SLUG),
                                'class' => 'layers-select layers-large tl-select-post-item',
                            )
                        ); ?>
                    </p>
                </section>
                <section class="layers-accordion-section layers-content">
                    <div class="layers-form-item">
                        <?php $this->repeater('column', $widget); ?>
                    </div>
                </section>
            </div>
            <?php
            if (TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_end_flush();
        }


        /**
         * Helper method. Renders column in administation panel.
         *
         * @param $item_guid
         * @param $widget
         */
        function column_item($item_guid, $widget)
        {
            ?>
            <li class="layers-accordion-item" data-guid="<?php echo esc_attr($item_guid); ?>">
                <a class="layers-accordion-title">
						<span>
							<?php _e('Column', 'layerswp'); ?>
                            <span class="layers-detail">
								<?php echo(isset($widget['title']) ? ': ' . substr(stripslashes(strip_tags($widget['title'])), 0, 50) : NULL); ?>
                                <?php echo(isset($widget['title']) && strlen($widget['title']) > 50 ? '...' : NULL); ?>
							</span>
						</span>
                </a>
                <section class="layers-accordion-section layers-content">
                    <?php $this->design_bar(
                        'top', // CSS Class Name
                        array(
                            'name' => $this->get_layers_field_name('design'),
                            'id' => $this->get_layers_field_id('design'),
                            'widget_id' => $this->widget_id . '_item',
                            'number' => $this->number,
                            'show_trash' => true
                        ), // Widget Object
                        $widget, // Widget Values
                        array(
                            'background',
                            'featuredimage',
                            'fonts',
                            'width' => array(
                                'icon-css' => 'icon-columns',
                                'label' => 'Column Width',
                                'elements' => array(
                                    'layout' => array(
                                        'type' => 'select',
                                        'label' => '',
                                        'name' => $this->get_layers_field_name('width'),
                                        'id' => $this->get_layers_field_id('width'),
                                        'value' => (isset($widget['width'])) ? $widget['width'] : NULL,
                                        'options' => array(
                                            '2' => __('2 of 12 columns', 'layerswp'),
                                            '3' => __('3 of 12 columns', 'layerswp'),
                                            '4' => __('4 of 12 columns', 'layerswp'),
                                            '6' => __('6 of 12 columns', 'layerswp'),
                                        )
                                    )
                                )
                            ),
                            'member_icon' => array(
                                'icon-css' => 'icon-call-to-action',
                                'label' => 'Member Icon',
                                'label' => 'Icon Options',
                                'wrapper-class' => 'layers-pop-menu-wrapper layers-content-small tl-title-options',
                                'elements' => array(
                                    'icon_color' => array(
                                        'type' => 'color',
                                        'label' => 'Icon Color',
                                        'name' => $this->get_layers_field_name('icon_color'),
                                        'id' => $this->get_layers_field_id('icon_color'),
                                        'value' => isset($widget['icon_color']) ? $widget['icon_color'] : null
                                    ),
                                    'icon_btn' => array(
                                        'type' => 'button',
                                        'class' => 'expand-icons',
                                        'label' => 'Select an Icon',
                                        'name' => $this->get_layers_field_name('icon_btn'),
                                        'id' => $this->get_layers_field_id('icon_btn'),
                                    ),
                                    'icon_class' => array(
                                        'type' => 'hidden',
                                        'name' => $this->get_layers_field_name('icon_class'),
                                        'id' => $this->get_layers_field_id('icon_class'),
                                        'value' => (isset($widget['icon_class']) && $widget['icon_class'] != '') ? $widget['icon_class'] : null
                                    )
                                )
                            ),
                        )
                    ); ?>
                    <div class="layers-row">
                        <p class="layers-form-item">
                            <label
                                for="<?php echo esc_attr($this->get_layers_field_id('team_member_id')); ?>"><?php _e('Pick Team Member', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'select',
                                    'name' => $this->get_layers_field_name('team_member_id'),
                                    'id' => $this->get_layers_field_id('team_member_id'),
                                    'value' => (isset($widget['team_member_id'])) ? $widget['team_member_id'] : NULL,
                                    'options' => tl_get_posts(array('post_type' => 'tl_team')),
                                    'placeholder' => __('-- None --', TL_INSERT_STAFF_SLUG),
                                    'class' => 'layers-select layers-large tl-select-post-item',
                                )
                            ); ?>
                        </p>

                        <p class="layers-form-item">
                            <label
                                for="<?php echo $this->get_layers_field_id('title'); ?>"><?php _e('Title', 'layerswp'); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'text',
                                    'name' => $this->get_layers_field_name('title'),
                                    'id' => $this->get_layers_field_id('title'),
                                    'placeholder' => __('Enter title here', 'layerswp'),
                                    'value' => (isset($widget['title'])) ? $widget['title'] : NULL,
                                    'class' => 'layers-text'
                                )
                            ); ?>
                        </p>

                        <p class="layers-form-item">
                            <label
                                for="<?php echo $this->get_layers_field_id('excerpt'); ?>"><?php _e('Excerpt', 'layerswp'); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'rte',
                                    'name' => $this->get_layers_field_name('excerpt'),
                                    'id' => $this->get_layers_field_id('excerpt'),
                                    'placeholder' => __('Short Excerpt', 'layerswp'),
                                    'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                    'class' => 'layers-form-item layers-textarea',
                                    'rows' => 6
                                )
                            ); ?>
                            <small
                                class="layers-small-note"><?php _e('If left blank the excerpt will be pulled from the select Team CPT.', TL_INSERT_STAFF_SLUG)?></small>
                        </p>
                    </div>
                </section>
            </li>
        <?php }


        /**
         * Print Widget
         *
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        {
            $this->backup_inline_css();

            // Turn $args array into variables.
            extract($args);

            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            // Enqueue Masonry if need be
            if ('list-masonry' == $this->check_and_return($widget, 'design', 'liststyle')) $this->enqueue_masonry();

            $this->_setColorDefaults($widget_id);

            // Apply Section Styling
            $this->_apply_widget_section_styling($widget_id, $widget);


            /**
             * Generate the widget container class
             */
            $widget_container_class = array();
            $widget_container_class[] = 'widget content-vertical-massive our-team';
            $widget_container_class[] = $this->check_and_return($widget, 'design', 'advanced', 'customclass');
            $widget_container_class[] = $this->get_widget_spacing_class($widget);
            $widget_container_class = implode(' ', apply_filters('layers_'.$this->widget_id.'_widget_container_class', $widget_container_class, $this, $widget)); ?>

            <div class="<?php echo $widget_container_class; ?>" id="<?php echo esc_attr($widget_id); ?>">
                <?php
                    echo $this->custom_anchor( $widget );
                    do_action( 'layers_before_'.$this->widget_id.'_widget_inner', $this, $widget );
                ?>
                <?php if ('' != $this->check_and_return($widget, 'title') || '' != $this->check_and_return($widget, 'excerpt')) { ?>
                    <div class="container clearfix">
                        <?php
                        /**
                         * Generate the Section Title Classes
                         */
                        $section_title_class = array();
                        $section_title_class[] = 'section-title clearfix';
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'size');
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'align');

                        $section_title_class = implode(' ', $section_title_class); ?>
                        <div class="<?php echo $section_title_class; ?>">
                            <?php if ('' != $widget['title']) { ?>
                                <h3 class="heading"><?php echo apply_filters('tl_colorize_title_' . $this->widget_id, esc_html($widget['title'])); ?></h3>
                            <?php } ?>
                            <?php if ('' != $widget['excerpt']) { ?>
                                <div class="excerpt"><?php echo $widget['excerpt']; ?></div>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>
                <?php if (!empty($widget['columns'])) { ?>
                    <div
                        class="<?php echo $this->get_widget_layout_class($widget); ?> <?php echo $this->check_and_return($widget, 'design', 'liststyle'); ?>">
                        <div class="grid">
                            <?php // Set total width so that we can apply .last to the final container
                            $total_width = 0; ?>
                            <?php foreach (explode(',', $widget['column_ids']) as $column_key) {

                                // Make sure we've got a column going on here
                                if (!isset($widget['columns'][$column_key])) continue;

                                // Setup the relevant column
                                $column = $widget['columns'][$column_key];

                                // Set the column background styling
                                if (!empty($column['design']['background'])) $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'background', array('background' => $column['design']['background']));
                                // Set section title colors
                                if (!empty($column['design']['background']['color-meta']))
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' .thumbnail-meta{ background-color:' . $column['design']['background']['color-meta'] . ';}');

                                // Column Icon Color
                                if (!empty($column['icon_color'])) {
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' .member-icon{ color:' . $column['icon_color'] . ';}');
                                }

                                if (!empty($column['design']['fonts']['color'])) {
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'color', array('selectors' => array('div.excerpt', 'div.excerpt p', '.social-icon'), 'color' => $column['design']['fonts']['color']));
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, array('selectors' => array('.social-icon'),
                                        'css' => array('border-color' => $column['design']['fonts']['color'])));
                                }

                                //Name colors
                                if (!empty($column['design']['fonts']['name-color'])) {
                                    $color = $column['design']['fonts']['name-color'];
                                } else {
                                    $color = layers_get_theme_mod('theme-secondary-color');
                                }
                                $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, array('selectors' => array('.thumbnail-meta a', '.thumbnail-meta .heading'),
                                    'css' => array('color' => $color)));

                                if (!empty($column['design']['fonts']['name-color-hover'])) {
                                    $color = $column['design']['fonts']['name-color-hover'];
                                } else {
                                    $color = layers_get_theme_mod('theme-primary-color');
                                }
                                $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, array('selectors' => array('.thumbnail-meta a:hover'),
                                    'css' => array('color' => $color)));


                                if (!empty($column['design']['fonts']['position-color'])) {
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, array('selectors' => array('.thumbnail-meta span'),
                                        'css' => array('color' => $column['design']['fonts']['position-color'])
                                    ));
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, array('selectors' => array('.thumbnail-meta span:before', '.thumbnail-meta span:after'),
                                        'css' => array('border-color' => $column['design']['fonts']['position-color'])
                                    ));

                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' .thumbnail-meta span:before,
                                                      #' . $widget_id . '-' . $column_key . ' .thumbnail-meta span:after{ border-color:' . $column['design']['fonts']['position-color'] . ';
                                                                                                                        border-color: rgba(' . apply_filters('tl/hex2rgba', $column['design']['fonts']['position-color'], 0.35, true) . ');}');

                                }

                                if (!isset($column['width'])) $column['width'] = $this->column_defaults['width'];
                                // Add the correct span class
                                $span_class = 'span-' . $column['width'];

                                // Add .last to the final column
                                $total_width += $column['width'];

                                if (12 == $total_width) {
                                    $span_class .= ' last';
                                    $total_width = 0;
                                } elseif ($total_width > 12) {
                                    $total_width = 0;
                                }

                                //$post = null;
                                $social_icons = null;

                                $column['team_member_id'] = (int)$column['team_member_id'];

                                if ($column['team_member_id']) {
                                    // Get Member's metadata
                                    $member_meta = $this->_getMemberMeta($column['team_member_id'], null);

                                    if ($member_meta) {
                                        $social_icons = $member_meta;
                                        unset($social_icons['_tl_member_position']);
                                    }
                                }

                                // Set Featured Media

                                // Set Image Sizes
                                if (isset($column['design']['imageratios'])) {

                                    // Translate Image Ratio into something usable
                                    $image_ratio = layers_translate_image_ratios($column['design']['imageratios']);

                                    if (!isset($column['width'])) $column['width'] = 6;

                                    if (4 >= $column['width']) {
                                        $use_image_ratio = $image_ratio . '-medium';
                                    } else {
                                        $use_image_ratio = $image_ratio . '-large';
                                    }

                                } else {
                                    if (4 >= $column['width']) {
                                        $use_image_ratio = 'medium';
                                    } else {
                                        $use_image_ratio = 'full';
                                    }
                                }

                                $media = tl_layers_get_feature_media($column['team_member_id'], $use_image_ratio, null, true, false, false);
                                $the_post = null;

                                // Load post if excerpt in customizer is empty
                                if (!empty($column['team_member_id']) && isset($widget['show_excerpts']) && (!isset($column['excerpt']) || $column['excerpt'] == '')) {
                                    $the_post = tl_get_posts(array('post_type' => 'tl_team', 'post_id' => $column['team_member_id']), true);
                                    $the_post = isset($the_post[0]) ? $the_post[0] : null;
                                }


                                // Set the column link
                                $link_on_title = $this->check_and_return($widget, 'link_on_title');
                                $link = null;
                                $popup = null;
                                if ($link_on_title) {
                                    $link = get_the_permalink($column['team_member_id']);
                                    $popup = $this->check_and_return($widget, 'popup');

                                    if ($popup == 'on') {
                                        $popup = 'class="ajax-popup-link" data-id="' . esc_attr($column['team_member_id']) . '" data-title="' . esc_attr($column['title']) . '"';
                                    }
                                }

                                /**
                                 * Set Individual Column CSS
                                 */
                                $column_class = array();
                                $column_class[] = 'layers-masonry-column';
                                $column_class[] = $span_class;
                                $column_class[] = ('list-masonry' == $this->check_and_return($widget, 'design', 'liststyle') ? 'no-gutter' : '');
                                $column_class[] = 'column' . ('on' != $this->check_and_return($widget, 'design', 'gutter') ? '-flush' : '');
                                $column_class[] = ($this->check_and_return($widget, 'text_style') == 'overlay' ? 'with-overlay' : '');

                                if (false != $media) {
                                    $column_class[] = 'has-image';
                                }
                                $column_class = implode(' ', $column_class); ?>

                                <div id="<?php echo $widget_id; ?>-<?php echo $column_key; ?>"
                                     class="<?php echo $column_class; ?>">
                                    <?php
                                    /**
                                     * Set Overlay CSS Classes
                                     */
                                    $column_inner_class = array();
                                    $column_inner_class[] = 'media';
                                    if (!$this->check_and_return($widget, 'design', 'gutter')) {
                                        $column_inner_class[] = 'no-push-bottom';
                                    }

                                    $column_inner_class[] = $this->check_and_return($column, 'design', 'imagealign');
                                    $column_inner_class[] = $this->check_and_return($column, 'design', 'fonts', 'size');
                                    $column_inner_class = implode(' ', $column_inner_class); ?>

                                    <div class="<?php echo $column_inner_class; ?>">
                                        <?php if (NULL != $media) { ?>
                                            <div
                                                class="media-image <?php echo((isset($column['design']['imageratios']) && 'image-round' == $column['design']['imageratios']) ? 'image-rounded' : ''); ?>">
                                                <?php echo $media; ?>
                                                <?php if ($this->check_and_return($column, 'icon_class')): ?>
                                                    <span
                                                        class="member-icon <?php echo esc_attr($column['icon_class']) ?>"></span>
                                                <?php endif; ?>
                                            </div><!-- .media-image -->
                                        <?php } ?>

                                        <?php //if ($this->check_and_return($column, 'excerpt')) { ?>

                                        <!-- .media-body removed form tag below -->
                                        <div
                                            class="thumbnail-body  <?php echo (isset($column['design']['fonts']['align'])) ? $column['design']['fonts']['align'] : ''; ?>">
                                            <div class="overlay">
                                                <?php if ($this->check_and_return($column, 'icon_class')): ?>
                                                    <span
                                                        class="member-icon <?php echo esc_attr($column['icon_class']) ?>"></span>
                                                <?php endif; ?>
                                                <?php if (isset($widget['show_excerpts'])): ?>
                                                    <div class="excerpt">
                                                        <?php
                                                        if (isset($column['excerpt']) && $column['excerpt'] != '') {
                                                            layers_the_content(substr($column['excerpt'], 0, $widget['excerpt_length']));
                                                            echo '&#8230;';
                                                        } else {
                                                            if ($the_post) {

                                                                $post = $the_post;
                                                                setup_postdata($post);

                                                                layers_the_content(substr(get_the_content(), 0, $widget['excerpt_length']));
                                                                echo '&#8230;';
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if (count($social_icons) > 0 && $this->check_and_return($widget, 'show_social_icons')): ?>
                                                    <div class="social-icons text-center">
                                                        <?php $this->_renderSocialIcons($social_icons) ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <!-- .thumbnail-body -->
                                        <?php //} ?>
                                    </div>
                                    <!-- .media -->
                                    <?php
                                    // Classes for meta section
                                    $meta_classes = array();
                                    $meta_classes[] = $this->check_and_return($column, 'design', 'fonts', 'name-align');
                                    $meta_classes = implode(' ', $meta_classes);
                                    ?>
                                    <!-- Meta section -->
                                    <div class="thumbnail-meta <?php echo esc_attr($meta_classes) ?>">
                                        <h4 class="heading ">
                                            <a <?php echo $popup ?>
                                                href="<?php echo($link_on_title ? esc_url($link) : '#') ?>"><?php echo esc_html($column['title']) ?></a>
                                        </h4>
                                        <?php if (isset($member_meta['_tl_member_position'])): ?>
                                            <span><?php echo esc_html($member_meta['_tl_member_position']) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <!-- .thumbnail-meta -->
                                </div><!-- Column End -->
                            <?php }
                            wp_reset_postdata();
                            ?>
                        </div>
                    </div>
                <?php } ?>
                <?php if ($this->check_and_return($widget, 'page_id')): ?>
                    <div class="container aligncenter">
                        <a href="<?php echo get_the_permalink($this->check_and_return($widget, 'page_id')) ?>"
                           class="hvr-float goto-section-page button large">
                            <?php _e('MEET OUR TEAM', TL_INSERT_STAFF_SLUG) ?><i class="icon-ti-angle-double-right"></i>
                        </a>
                    </div>
                <?php endif;

                do_action( 'layers_after_' . $this->id . '_widget_inner', $this, $widget );

                // Print the Inline Styles for this Widget
                $this->print_inline_css();

                // Apply the advanced widget styling
                $this->apply_widget_advanced_styling($widget_id, $widget);
                ?>
            </div>
            <?php if ('list-masonry' == $this->check_and_return($widget, 'design', 'liststyle')) { ?>
            <script type="text/javascript">
                "use strict";
                jQuery(function ($) {
                    layers_masonry_settings['<?php echo $widget_id; ?>'] = [{
                        itemSelector: '.layers-masonry-column',
                        layoutMode: 'masonry',
                        gutter: <?php echo ( isset( $widget['design'][ 'gutter' ] ) ? 20 : 0 ); ?>
                    }];
                    $('#<?php echo $widget_id; ?>').find('.list-masonry').layers_masonry(layers_masonry_settings['<?php echo $widget_id; ?>'][0]);
                });
            </script>
        <?php } // masonry trigger
        }


        /**
         * Render Members social icons
         *
         * @param $icons
         */
        protected function _renderSocialIcons($icons)
        {
            $str = '';
            if (isset($icons['_tl_member_fb'])) {
                $str .= '<a title="' . __('Member\'s facebook profile', TL_INSERT_STAFF_SLUG) . '" target="_blank" href="' . esc_attr($icons['_tl_member_fb']) . '" class="social-icon hvr-float"><i class="icon-ti-facebook"></i></a>';
            }

            if (isset($icons['_tl_member_gp'])) {
                $str .= '<a title="' . __('Member\'s Google+ profile', TL_INSERT_STAFF_SLUG) . '" target="_blank" href="' . esc_attr($icons['_tl_member_gp']) . '" class="social-icon hvr-float"><i class="icon-ti-google"></i></a>';
            }

            if (isset($icons['_tl_member_ld'])) {
                $str .= '<a title="' . __('Member\'s LinkedIn profile', TL_INSERT_STAFF_SLUG) . '" target="_blank" href="' . esc_attr($icons['_tl_member_ld']) . '" class="social-icon hvr-float"><i class="icon-ti-linkedin"></i></a>';
            }

            if (isset($icons['_tl_member_yt'])) {
                $str .= '<a title="' . __('Member\'s Youtube Channel', TL_INSERT_STAFF_SLUG) . '" target="_blank" href="' . esc_attr($icons['_tl_member_yt']) . '" class="social-icon hvr-float"><i class="icon-ti-youtube"></i></a>';
            }

            if (isset($icons['_tl_member_tw'])) {
                $str .= '<a title="' . __('Member\'s Twitter profile', TL_INSERT_STAFF_SLUG) . '" target="_blank" href="' . esc_attr($icons['_tl_member_tw']) . '" class="social-icon hvr-float"><i class="icon-ti-twitter-alt"></i></a>';
            }

            if (isset($icons['_tl_member_pin'])) {
                $str .= '<a title="' . __('Member\'s Pinterest profile', TL_INSERT_STAFF_SLUG) . '" target="_blank" href="' . esc_attr($icons['_tl_member_pin']) . '" class="social-icon hvr-float"><i class="icon-ti-pinterest-alt"></i></a>';
            }

            if (isset($icons['_tl_member_cl'])) {
                $str .= '<a target="_blank" href="' . esc_attr($icons['_tl_member_cl']) . '" class="social-icon"><i class="icon-ti-pencil-alt"></i></a>';
            }
            echo $str;
        }


        /**
         * @param $post_id
         * @param $key
         * @return array|mixed|string
         */
        protected function _getMemberMeta($post_id, $key)
        {
            $return = array();
            if ($post_id == 0) return $return;
            $meta = tl_get_metadata($post_id, $key);

            foreach ($this->_allowed_keys as $k) {
                $v = $this->check_and_return($meta, $k);
                if ($v && trim($v) != '') $return[$k] = $v;
            }
            return $return;
        }


        protected function _addFilters()
        {
            add_filter('tl_colorize_title_' . $this->widget_id, 'tl_colorize_title', 10, 2);
            add_filter('tl/layers/background_component/' . $this->widget_id . '/args', array($this, 'customizeBackgroundComponent'), 10, 4);
            add_filter('tl/layers/fonts_component/' . $this->widget_id . '/args', array($this, 'customizeFontsComponent'), 10, 4);
            add_filter('tl/layers/featuredimage_component/' . $this->widget_id . '/args', array($this, 'customizeFeaturedImageComponent'), 10, 4);
        }


        /**
         * @param $widget_container_id
         */
        protected function _setColorDefaults($widget_container_id)
        {
            if ($this->colors) {
                $this->inline_css .= layers_inline_styles('#' . $widget_container_id . ' .media-image img{ border-color:' . $this->colors->get('_secondary') . '; }');
                $this->inline_css .= layers_inline_styles('#' . $widget_container_id . ' .media-image .member-icon{ background-color:' . $this->colors->get('_secondary') . '; }');

                // Social Icons Hover
                $this->inline_css .= layers_inline_styles('#' . $widget_container_id, array('selectors' => array('.social-icon:hover'),
                    'css' => array('color' => $this->colors->get('_secondary'),
                        'background-color' => $this->colors->get('_primary'),
                        'border-color' => $this->colors->get('_primary'))));
            }
        }

        /**
         * Customize build-in image tools
         *
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeFeaturedImageComponent($args, $position, $widget, $values)
        {
            unset($args['elements']['featuredimage']);
            unset($args['elements']['featuredvideo']);
            return $args;
        }


        /**
         * Customize built in fonts tools in top(column) and sidebar
         *
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeFontsComponent($args, $position, $widget, $values)
        {
            if ($position == 'side') {

                //Add at the beggining of the array
                $args['elements'] = array('fonts-title-heading' => array('type' => 'layers-heading', 'label' => 'Title Options')) + $args['elements'];

                // this goes to the all widgets
                $args['elements']['fonts-excerpt-heading'] = array(
                    'type' => 'layers-heading',
                    'label' => 'Excerpt Options',
                );

                $args['elements']['fonts-excerpt-color'] = array(
                    'type' => 'color',
                    'label' => 'Excerpt Color',
                    'name' => $widget['name'] . '[fonts][excerpt-color]',
                    'id' => $widget['id'] . '-fonts-excerpt-color',
                    'value' => isset($values['fonts']['excerpt-color']) ? $values['fonts']['excerpt-color'] : null,
                );
            } elseif ($position == 'top') {

                unset($args['elements']['fonts-size']);

                //Add at the beggining of the array
                $args['elements'] = array('fonts-name-excerpt' => ['type' => 'layers-heading', 'label' => 'Excerpt Options']) + $args['elements'];

                $args['elements']['fonts-color']['label'] = __('Excerpt Color', TL_INSERT_STAFF_SLUG);

                $args['elements']['fonts-name-heading'] = array(
                    'type' => 'layers-heading',
                    'label' => 'Name Options',
                );

                $args['elements']['fonts-name-align'] = array(
                    'type' => 'select-icons',
                    'label' => __('NAME ALIGNMENT'),
                    'name' => $widget['name'] . '[fonts][name-align]',
                    'id' => $widget['id'] . '-fonts-name-align',
                    'value' => isset($values['fonts']['name-align']) ? $values['fonts']['name-align'] : null,
                    'options' => array(
                        'text-left' => __('Left', TL_INSERT_STAFF_SLUG),
                        'text-center' => __('Center', TL_INSERT_STAFF_SLUG),
                        'text-right' => __('Right', TL_INSERT_STAFF_SLUG),
                    ),
                    'wrapper' => 'div',
                    'wrapper-class' => 'layers-icon-group'
                );

                $args['elements']['fonts-name-color'] = array(
                    'type' => 'color',
                    'label' => __('Name Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[fonts][name-color]',
                    'id' => $widget['id'] . '-fonts-name-color',
                    'value' => isset($values['fonts']['name-color']) ? $values['fonts']['name-color'] : null,
                );
                $args['elements']['fonts-name-color-hover'] = array(
                    'type' => 'color',
                    'label' => __('Name Hover Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[fonts][name-color-hover]',
                    'id' => $widget['id'] . '-fonts-name-color-hover',
                    'value' => isset($values['fonts']['name-color-hover']) ? $values['fonts']['name-color-hover'] : null,
                );

                $args['elements']['fonts-position-color'] = array(
                    'type' => 'color',
                    'label' => 'Position Color',
                    'name' => $widget['name'] . '[fonts][position-color]',
                    'id' => $widget['id'] . '-fonts-position-color',
                    'value' => isset($values['fonts']['position-color']) ? $values['fonts']['position-color'] : null,
                );
            }

            return $args;
        }


        /**
         * Customize built in background tools
         *
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeBackgroundComponent($args, $position, $widget, $values)
        {
            unset($args['elements']['background-darken']);

            if ($position == 'top') {
                $args['elements']['background-color-meta'] = array(
                    'type' => 'color',
                    'label' => __('Bottom Background Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[background][color-meta]',
                    'id' => $widget['id'] . '-background-color-meta',
                    'value' => isset($values['background']['color-meta']) ? $values['background']['color-meta'] : null,
                );
            }
            return $args;
        }


        /**
         * Customize built in Buttons tools
         *
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeButtonsComponent($args, $position, $widget, $values)
        {
            if ($position == 'side') {
                unset($args['elements']['buttons-size']);
            }
            return $args;
        }
    }
}//if
register_widget('TL_Layers_Team_Widget');