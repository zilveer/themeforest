<?php  /*IJAZ AHMAD*/

// Plain Hero, no images and stuff

class Wish_Recommended_Products {



        var $shortcode = 'wish_recommended_products';

        var $title = "Wish Recommended Products";

        var $details = "Woocommerce Recommended Products";

        //var $path = "/templates/rating_hero.php";



    function __construct() {

        // We safely integrate with VC with this hook

        add_action( 'init', array( $this, 'integrateWithVC' ) );

 

        // Use this when creating a shortcode addon

        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );



        // Register CSS and JS

        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );

    }

 

    public function integrateWithVC() {

        // Check if Visual Composer is installed

        if ( ! defined( 'WPB_VC_VERSION' ) ) {

            // Display notice that Visual Compser is required

            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));

            return;

        }

 

        vc_map( array(

            "name" => __($this->title, 'wish'),

            "description" => __($this->details, 'wish'),

            "base" => $this->shortcode,

            "class" => "",

            "controls" => "full",

            "link"  => "http://i.imgur.com/kVlWk67.png",

            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"

            "category" => __('Wish Components', 'wish'),

            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor

            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor

            "params" => array(





                            array(

                                "type" => "textfield",

                                "heading" => __("The Title", "wish"),

                                "param_name" => "title",

                                "admin_label" => true,

                                "value" => __("Recommended Products", 'wish'),

                            ),

                            array(

                                "type" => "dropdown",

                                "heading" => __("Max Items", "wish"),

                                "param_name" => "max_items",

                                "description" => __("Maximum Number Of Products to show.", "wish"),

                                "value" => array( 

                                                  "4"     => "4",

                                                  "8"     => "8",

                                                  "12"     => "12",

                                                  "16"     => "16",

                                                  "20"     => "20",

                                                ),

                                "std"       =>   4,

                            ),





                            array(

                                "type" => "vc_link",

                                "holder" => "div",

                                "class" => "",

                                "heading" => __("Link To The Page", 'wish'),

                                "param_name" => "link",

                                "description" => __("The Link To The Appointment page.", 'wish'),

                                "admin_label" => false,

                            ),



                            array(

                                "type" => "textfield",

                                "heading" => __("Link Title", "wish"),

                                "param_name" => "link_text",

                                "description" => __("Title of the link", "wish"),

                                "value" => __("Add to Bag", 'wish'),

                                "admin_label" => false,

                            ),



                            array(

                                "type" => "google_fonts",

                                "class" => "",

                                "heading" => __( "Title Text Font", "wish" ),

                                "param_name" => "title_font",

                                "value" => '', //Default Red color

                                "description" => __( "Choose Font", "wish" ),

                                "group"   => "Fonts & Colors",

                                'settings' => array(

                                     'fields'=>array(

                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

                                   )

                                )       

                            ),





                            array(

                                "type" => "wish_number",

                                "heading" => __("Title Size", "wish"),

                                "param_name" => "title_size",

                                "description" => __("Font size in px", "wish"),

                                "value" => __("30", 'wish'),

                                "admin_label" => true,

                                "group"       => "Fonts & Colors",

                            ),



                            array(

                                "type" => "colorpicker",

                                "class" => "",

                                "heading" => __( "Title Text Color", "wish" ),

                                "param_name" => "title_color",

                                "value" => '#000', //Default Black color

                                "description" => __( "Choose text color", "wish" ),

                                "group"         => "Fonts & Colors",

                             ),







                    )



        ) );

    }

    



    public function renderShortcode( $atts, $content = null ) {

      extract( shortcode_atts( array(

        'title'       => 'Recommended Products',

        'title_font'  => '',

        'title_size'  => '30',

        'title_color' => '#000',

        'max_items'   => '4',



        'link'  => '',

        'link_text' => 'Add to Bag',

      ), $atts ) );



      /*Title*/

        $decode_font = urldecode($title_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );





        if($link == "||" || $link == "" ){

            

            $link_text = "Add to Bag";

            $link_url = "#";

            $link_target = "";

            $link_String="";



          }else{



            $link = vc_build_link($link); //parse the link

            $link_url = esc_url($link["url"]);

            $link_target = esc_attr($link["target"]);

            $link_String="<div class='buttons'><a href='{$link_url}' class='fill'>{$link_text}</a></div>";

            if ($link_text == "") {

                $link_String = "";

            }



          }


          if(!function_exists('get_product')){
          	return "";
          }






        // wp_enqueue_script('wish-flex-js', plugins_url('assets/flex-slider/jquery.flexslider.js', __FILE__), array('jquery') );

        // wp_enqueue_script('wish-flex-custom', plugins_url('assets/flex-slider/flexslider.js', __FILE__), array('jquery') );



        //in progress

      $args = array(  

            'post_type' => 'product',  

            'meta_key' => '_featured',  

            'meta_value' => 'yes',  

            'posts_per_page' => $max_items,

        );  

          

        $featured_query = new WP_Query( $args );  



        $output = "";



        if ($featured_query->have_posts()) : 







        $output = "<div class='container shop-products products-recommended'>

                    <div class='row'>

                      <div class='col-lg-12'>

                        <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>

                      </div>";

              

          

          

            while ($featured_query->have_posts()) : $featured_query->the_post();  

                  

               $product = get_product( $featured_query->post->ID );  



               //$thumbid = get_post_thumbnail_id( $product );

               $thumbid = $product->get_image_id();

               $thumb = wp_get_attachment_image_src($thumbid, array(300,300));

               $thumb_big = wp_get_attachment_image_src($thumbid, 'full');



               $flip_image = $product->get_gallery_attachment_ids();



               $flip_image = wp_get_attachment_image_src( $flip_image[0], array(300,300) );



               $title = get_the_title($product);

               $excerpt = get_the_excerpt();



               $out_thumb = $thumb[0];

               $out_big = $thumb_big[0];



               $date= get_the_date();



               if($out_thumb[0] == ""){

                    $out_thumb = plugins_url('images/240x240.gif', __FILE__);   

               }



               if($thumb_big[0] == ""){

                    $out_big = plugins_url('images/1000x1000.gif', __FILE__);   

               }               



               $link = esc_url(get_post_permalink());

               $title = get_the_title();  

               $category = $product->get_categories();

               $price = $product->price;



                $output .= "<div class='col-lg-3 col-md-3 col-sm-6 block opacity-class'>

                              <div class='wish-product-img'>

                                <a href='{$link}'>

                                  <div class='first-flip '><img  src='{$out_thumb}' class='attachment-shop_catalog wp-post-image' alt='T_5_front'></div>

                                  <div class='back-flip back'><img  src='{$flip_image[0]}' class='attachment-shop_catalog' alt='T_5_back'></div>

                                </a>

                              </div>

                              <div class='caption'>{$title}</div>

                              <div class='category'>{$category}</div>

                              <div class='price'>£{$price}</div>

                              {$link_String}

                            </div>";



                          

                    endwhile;  

                      

                 

                  

                wp_reset_query(); // Remember to reset  







                     $output .=   "

                                </div>

                              </div>";



          endif; 





      return $output;

    }



    /*

    Load plugin css and javascript files which you may need on front end of your site

    */

    public function loadCssAndJs() {

      //wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );

      //wp_enqueue_style( 'vc_extend_style' );



      // If you need any javascript files on front end, here is how you can load them.

      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );

    }



    /*

    Show notice if your plugin is activated but Visual Composer is not

    */

    public function showVcVersionNotice() {

        $plugin_data = get_plugin_data(__FILE__);

        echo '

        <div class="updated">

          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>

        </div>';

    }







}//end of class

?>