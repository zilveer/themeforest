<?php  /*IJAZ AHMAD*/
// Plain Hero, no images and stuff
class Wish_Text_Banner {

        var $shortcode = 'wish_text_banner';
        var $title = "Text Banner";
        var $details = "";
        //var $path = "/templates/rating_hero.php";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link"  => "http://i.imgur.com/wL2ubyq.png",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'wish'),
            //'admin_enqueue_js' => array(plugins_url('admin_assets/vc_admin.js', __FILE__)), // This will load js file in the VC backend editor
            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
            "params" => array(
                                        // fields for tab 1
                                        array(
                                            "type" => "textfield",
                                            "heading" => __("Title", "wish"),
                                            "param_name" => "title",
                                            "description" => __("The Title", "wish"),
                                            "value" => __("Our Services", 'wish'),
                                            "admin_label" => true,
                                        ),

                                        array(
                                            "type" => "textarea",
                                            "holder" => "div",
                                            "class" => "",
                                            "heading" => __("Details", 'wish'),
                                            "param_name" => "details",
                                            "value" => __("We do play a lot, but we also work hard and like to challenge ourselves with proposing new projects that will further better", 'wish'),
                                            "description" => __("The details below the title", 'wish'),
                                            "admin_label" => false,
                                        ),

                                        
                                
                                        /*Title*/
                                        array(
                                            "type" => "google_fonts",
                                            "class" => "",
                                            "heading" => __( "Title Text Font", "wish" ),
                                            "param_name" => "title_font",
                                            "value" => '', //Default Red color
                                            "description" => __( "Choose Font", "wish" ),
                                            "group"   => "Fonts & Colors",
                                            'settings' => array(
                                                 'fields'=>array(
                                                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                               )
                                            )       
                                        ),


                                        array(
                                            "type" => "wish_number",
                                            "heading" => __("Title Font Size", "wish"),
                                            "param_name" => "title_size",
                                            "description" => __("Font size in px", "wish"),
                                            "value" => __("30", 'wish'),
                                            "admin_label" => true,
                                            "group"       => "Fonts & Colors",
                                        ),

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Title Text Color", "wish" ),
                                            "param_name" => "title_color",
                                            "value" => '#df4322', //Default Black color
                                            "description" => __( "Choose text color", "wish" ),
                                            "group"       => "Fonts & Colors",
                                         ),


                                        /*Details*/
                                        array(
                                            "type" => "google_fonts",
                                            "class" => "",
                                            "heading" => __( "Details Text Font", "wish" ),
                                            "param_name" => "details_font",
                                            "value" => '', //Default Red color
                                            "description" => __( "Choose Font", "wish" ),
                                            "group"   => "Fonts & Colors",
                                            'settings' => array(
                                                 'fields'=>array(
                                                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                               )
                                            )       
                                        ),


                                        array(
                                            "type" => "wish_number",
                                            "heading" => __("Details Font Size", "wish"),
                                            "param_name" => "details_size",
                                            "description" => __("Font size in px", "wish"),
                                            "value" => __("20", 'wish'),
                                            "admin_label" => true,
                                            "group"       => "Fonts & Colors",
                                        ),

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Details Text Color", "wish" ),
                                            "param_name" => "details_color",
                                            "value" => '#000000', //Default Black color
                                            "description" => __( "Choose text color", "wish" ),
                                            "group"       => "Fonts & Colors",
                                         ),

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Background Color", "wish" ),
                                            "param_name" => "bgcolor",
                                            "value" => '#f4f4f4', //Default Black color
                                            "description" => __( "Choose text color", "wish" ),
                                            "group"   => 'Fonts & Colors'
                                         ),




                    )
        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'         => 'Our Services',
        'details'       => 'We do play a lot, but we also work hard and like to challenge ourselves with proposing new projects that will further better',
        
        'title_font'    => '',
        'title_size'    => '30',
        'title_color'   => '#df4322',

        'details_font'  => '',
        'details_size' => '20',
        'details_color' => '#000',

        'bgcolor' => '#f4f4f4'
      ), $atts ) );
     // $content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content



      /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



      $output = "<div class='text-banner' style='background-color:{$bgcolor}'>
                    <div class='col-lg-8 col-lg-offset-2'>
                        <h2 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:$title_color'>{$title}</h2>
                        <div class='herotext animated' data-animation='fadeInUp' data-animation-delay='400' style='font-family:{$details_font_family};font-size:{$details_size}px;color:$details_color'>{$details}</div>
                    </div>
                </div>";


      return $output;
    }

    /*
    Load plugin css and javascript files which you may need on front end of your site
    */
    public function loadCssAndJs() {
      wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
      wp_enqueue_style( 'vc_extend_style' );

      // If you need any javascript files on front end, here is how you can load them.
      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );
    }

    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }


    public function outputTitleTrue( $title ) {
        return '<h4 class="wpb_element_title">' . __( $title, 'js_composer' ) . ' ' . $this->settings( 'logo' ) . '</h4>';
    }





}//end of class
?>