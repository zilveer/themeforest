<?php get_header(); ?>

<div id="main">
	<div id="post-area">
		<div id="woo-content">
			<?php woocommerce_content(); ?>
			<?php wp_link_pages(); ?>
		</div><!--woo-content-->
	</div><!--post-area-->
</div><!--main -->

<?php get_sidebar('woo'); ?>
<?php get_footer(); ?>