<?php

//define needed constants
define('EDGE_CORE_VERSION', '1.1.2');
define('EDGE_CORE_ABS_PATH', dirname(__FILE__));
define('EDGE_CORE_REL_PATH', dirname(plugin_basename(__FILE__ )));

//include all necessary files
require_once EDGE_CORE_ABS_PATH.'/helpers/carousel.php';
require_once EDGE_CORE_ABS_PATH.'/helpers/theme.php';
require_once EDGE_CORE_ABS_PATH.'/cpt/edge-cpt.php';
require_once EDGE_CORE_ABS_PATH.'/cpt/portfolio/edgt.portfolio.php';
require_once EDGE_CORE_ABS_PATH.'/cpt/edgt-slider/shortcodes/edgt.slidersc.php';
require_once EDGE_CORE_ABS_PATH.'/cpt/edgt-slider/edgt-slider-settings.php';
require_once EDGE_CORE_ABS_PATH.'/cpt/testimonials/shortcodes/edgt.testimonialssc.php';
require_once EDGE_CORE_ABS_PATH.'/cpt/carousels/shortcodes/edgt.carouselsc.php';
require_once EDGE_CORE_ABS_PATH.'/cpt/masonry-gallery/shortcodes/edgt.masonry-gallery.php';