<form action="{$homeUrl}" id="searchform" method="get" class="searchform">
	<div>
	   	<label class="screen-reader-text" for="s">{_}Search for:{/_}</label>
		<input type="text" name="s" id="s" placeholder="search..." class="s">
		<input type="submit" name="submit" id="searchsubmit" value="Search" class="searchsubmit">
	</div>
</form>