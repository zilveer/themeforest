<?php 

/** 
 * Plugin Name: Social Icon Widget 
 * Description: Display a widget with nice social icons. 
 * Plugin URI: http://dtbaker.net 
 * Version: 1.0.2 
 * Author: dtbaker 
 * Author URI: http://dtbaker.net 
 * Text Domain: dtbaker-social-icons-widget 
 */ 

require_once plugin_dir_path( __FILE__ ) . 'widget.php';

/**
* Load textdomain
 */
function dtbaker_social_icons_widget_load_textdomain() {
    load_plugin_textdomain( 'dtbaker-social-icons-widget', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'dtbaker_social_icons_widget_load_textdomain' );

/**
* Register the widget
 */
add_action( 'widgets_init', 'dtbaker_social_icons_widget_register' );
function dtbaker_social_icons_widget_register() {
	register_widget( 'dtbaker_Social_Icons_Widget' );
}