<?php  
//Register "container" content element
vc_map( array(
    "name" => __("Parallax Services", "wish"),
    "description" => __("Boxes of services on parallax background", 'wish'),
    "controls" => "full",
    "base" => "wish_parallax_services",
    "as_parent" => array('only' => 'wish_parallax_services_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link" => "http://i.imgur.com/0j8mK8A.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Parallax background image", 'wish'),
            "param_name" => "image",
            "value" => 'Image',
        ),

    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Service", "wish"),
    "base" => "wish_parallax_services_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_parallax_services'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("RESPONSIVE", "wish"),
            "value" => __("Control Panel", 'wish'),
            "admin_label" => true,
        ), 


        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
            "description" => __("Details", 'wish')
        ),

        array(
            "type" => "wish_fontawesome_param",
            "heading" => __("Icon", "wish"),
            "param_name" => "icon",
            "description" => __("The Icon code from Font Awesome, copy the codes from <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank'>here</a>", "wish"),
            "value" => __("fa-cog", 'wish'),
            "admin_label" => true,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("18", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#df4322 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#555 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



       
    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Parallax_Services extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'image'   => 'Image',
      ), $atts ) );

      $img = wp_get_attachment_image_src( $image, 'full' );

      if($image == "Image"){
        $imgsrc = plugins_url('images/bg_hosting.jpg', __FILE__);
        $img[0] = $imgsrc;
      }
     

      $output = "<div class='parallax-1 parallax-services' style='background-image:url({$img[0]});'>
                    <div class='container'>
                        <div class='parallax-service-outer'>

                            ".do_shortcode($content)."
                
                        </div>
                    </div>
                </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Parallax_Services_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'title'         => 'RESPONSIVE',
            'title_font'    => '',
            'title_size'    => '18',
            'title_color'   => '#df4322',

            'icon'          => 'fa-cog',
            'details'       => 'Duis aute irure dolor in reprehenderit in voluptate. Excepteur sint occaecat cupidatat non proi.',  
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#555',
          ), $atts ) );

        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );
          
          $output = "<div class='parallax-service'>
                        <div class='block animated' data-animation='flipInY' data-animation-delay='400'>
                            <div class='icon'><i class='fa {$icon}'></i></div>
                            <div class='caption' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</div>
                            <div class='service-text' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                        </div>
                    </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>