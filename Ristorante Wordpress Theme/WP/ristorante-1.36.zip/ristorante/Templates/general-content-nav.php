{willPaginate}
	<nav id="{$location}">
		<div class="nav-previous">{prevPostsLink '<span class="meta-nav">&larr;</span>'}</div>
		<div class="nav-next">{nextPostsLink '<span class="meta-nav">&rarr;</span>'}</div>
	</nav>
{/willPaginate}
