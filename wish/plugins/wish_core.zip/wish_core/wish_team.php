<?php  
// Plain Hero, no images and stuff
class Wish_Team {

        var $shortcode = 'wish_team';
        var $title = "Wish Team";
        var $details = "Team Gallery With a large top image";
        //var $path = "/templates/rating_hero.php";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
    }
    

    public function renderShortcode( $atts, $content = null ) {

        //to process:

        $args = array(
          'numberposts' => 4,
          'post_type' => 'wish_team',
          'offset' => 0,
          'posts_per_page' => 4,
        );

      $team_query = new WP_Query( $args );

      $output = ""; 

      $output .= "<div class='row no-gutter-3 team'>";

                        while (  $team_query->have_posts() ) :  $team_query->the_post(); 

                               $pid =  get_the_ID();
                               //echo get_post_meta(get_the_ID(), '_projects_mb_feature', TRUE);

                               $thumbid = get_post_thumbnail_id( $pid );
                               $full = wp_get_attachment_image_src($thumbid, 'team-thumb-size');
                               $thumb = wp_get_attachment_image_src($thumbid, 'team-thumb-size');
                               $out_img = $thumb[0];
                               $full_img = $full[0];

                               if($out_img == ""){
                                    $out_img = plugins_url('images/200x200.gif', __FILE__);   
                               }

                               $link = get_post_permalink();
                               $title = get_the_title(); 

                               $designation = get_post_meta( $pid, 'wish_designation', true );
                               $content = get_the_content();



      $output .= "<!-- Member Starts -->
                          <div class='col-lg-2 col-md-3 col-sm-6 col-xs-6 member animated flipInY visible' data-animation='flipInY' data-animation-delay='100'>
                            <a class='simple-ajax-popup' href='team-popups/member-1.html'>
                              <div class='picture'><img src='{$out_img[0]}' class='img-responsive center-block' alt=''></div>
                              <div class='info'>
                                <div class='name'>{$title}</div>
                                <div class='designation'>{$designation}</div>
                                <div class='icons'><i class='fa fa-envelope-o'></i></div>
                              </div>
                            </a>
                          </div>
                          <!-- Member Ends -->
                          ";
               $output .= "<div class='modal fade team-popup-modal' id='team-popup-{$pid}' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                            <div class='modal-dialog team-modal-dialog'>
                              <div class='modal-content'>

                                <div class='modal-body row no-gutters'>



                                  <div class='team-modal-image col-md-5'>
                                      <img src='{$full_img}' alt='' class='img-responsive'>
                                  </div>
                                  
                                  <div class='team-modal-content col-md-7'>
                                  <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                                          <h3>{$title}</h3>
                                          <h5>{$designation}</h5>
                                          <div class='team-modal-text-text'>
                                                {$content}
                                          </div>
                                  </div>

                                </div>

                              </div>
                            </div>
                        </div>";     


              $output .= "</div>";     

                        endwhile;   
                        wp_reset_postdata(); 

      
      return $output;
    }

    /*
    Load plugin css and javascript files which you may need on front end of your site
    */
    public function loadCssAndJs() {
      //wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
      //wp_enqueue_style( 'vc_extend_style' );

      // If you need any javascript files on front end, here is how you can load them.
      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );
    }

    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }



}//end of class
?>