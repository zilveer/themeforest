<?php $icons = array();
$icons['Kallyas-Restaurant']['ue900'] = 'ue900';
$icons['Kallyas-Restaurant']['ue901'] = 'ue901';
$icons['Kallyas-Restaurant']['ue902'] = 'ue902';