/**
 * Swiper with filter control
 */
;(function($) {
    "use strict";

    /* !!! NOT IN USE!!!! */

    var __NAMESPACE__ = 'tlSwiper';

    // Plugin standalone function
    $.tlSwiper = function(element, options) {

        /**
         * privileged property
         *
         * @type {{}}
         */
        this.options = {};

        /**
         * Reference to provided element
         *
         * @type {null}
         * @private
         */
        var _el = null;


        element.data(__NAMESPACE__, this);


        /**
         * @param element (Swiper container)
         * @param options
         */
        this.init = function(element, options){

            this.options = $.extend({}, $.tlSwiper.defaults, options);
            this._el = element;

            this.options.onBefore(this);

            _init_filter.call(this);
            _init_swiper.call(this);

            // Callback
            this.options.onComplete(this);
        };



        /* --------------------- PRIVILEGED METHODS --------------------------- */


        this.collapse = function(){
            $(this.options.filter_wrapper + " .portfolio-selector").toggleClass("hidden");
        };


        /**
         * Updates visible slides
         *
         * @param filter
         */
        this.update_swiper = function(filter){

        };

        /**
         * Cleanup all changes
         */
        this.destroy = function(){
            this.swipper.destroy(true, true);
        };


        // Fire!
        this.init(element, options);

        /* --------------------- PRIVATE METHODS -------------------------- */


        /**
         * Bind events and set defaults
         *
         * @private
         */
        function _init_filter(){

            var $swipper = this._el;

            // Bind events on filters
            var options = this.options;
            var $that = this;

            // Open/Close a list of filters
            $swipper.parent().find(options.filter_wrapper + " .selected").on("click", function(e){
                $(options.filter_wrapper + " .portfolio-selector").toggleClass("hidden");
            });

            // Select a filter
            //$(options.filter_wrapper + " ul.portfolio-selector li").on("click", function(e){
            $swipper.parent().find(options.filter_wrapper + " ul.portfolio-selector li").on("click", function(e){
                $swipper.parent().find(options.filter_wrapper + " .selected").data("filter", $(this).data("filter"));
                $swipper.parent().find(options.filter_wrapper + " .selected").html($(this).html());
                $that.collapse();

                $(this).trigger("updateSlides", [$(this).data("filter")]);
            });
        }


        /**
         * @param element
         * @private
         */
        function _init_swiper(){

             this.options.swiper_options = $.extend({}, $.tlSwiper.defaults.swiper_options, this.options.swiper_options);

            var widget_id = this._el.parent().attr("id");

             var mySwiper = new Swiper ( "#" + widget_id, {
                 slideClass: 'swiper-slide',
                 wrapperClass: 'list-grid',
                 pagination: "#"+widget_id + ' .swiper-pagination',
                 paginationClickable: true,
                 loop: true,
                 slidesPerView: 1
             });

            mySwiper.update();

             var all_slides = this._el.find("article").clone(true);
             this.swipper = mySwiper;
             this.all_slides = all_slides;

            // Show / Hide slides
            $("#" + widget_id + " " + this.options.filter_wrapper + " li").on("updateSlides", function(){
                var $clicked = $(this);
                mySwiper.removeAllSlides();
                all_slides.each(function(){
                    if($(this).hasClass($clicked.data("filter"))) {
                        mySwiper.appendSlide(this);
                        $("body").trigger("tl_portfolio_swiper_complete");
                    }
                });
            });
        }
    };


    $.tlSwiper.defaults = {
        filter_wrapper: '',
        swiper_options : {loop: true, direction: 'vertical', slideClass: "swiper-slide"},
        onBefore: function(el){
            el._el.css("visibility", "hidden");
        },
        onComplete: function(el){
            el._el.css("visibility", "visible");
        }
    };

    /* -- Used for manipulation under DOM elements -- */
    $.fn.tlSwiper = function(options) {
        return this.each(function() {
            (new $.tlSwiper($(this), options));
        });
    };
})(jQuery);