<?php

if( ! class_exists( 'WP_Import' ) ) {
	require trailingslashit( YOUXI_IMPORTER_DIR ) . 'vendor/wordpress-importer/wordpress-importer.php';
}

class Youxi_WP_Import extends WP_Import {

	/**
	 * If fetching attachments is enabled then attempt to create a new attachment
	 *
	 * @param array $post Attachment post details from WXR
	 * @param string $url URL to fetch attachment from
	 * @return int|WP_Error Post ID on success, WP_Error otherwise
	 */
	function process_attachment( $post, $url ) {
		if ( ! $this->fetch_attachments )
			return new WP_Error( 'attachment_processing_error',
				__( 'Fetching attachments is not enabled', 'youxi' ) );

		// if the URL is absolute, but does not contain address, then upload it assuming base_site_url
		if ( preg_match( '|^/[\w\W]+$|', $url ) )
			$url = rtrim( $this->base_url, '/' ) . $url;

		// $upload = $this->fetch_remote_file( $url, $post );
		if( $this->attachments_dir && $this->attachments_baseurl ) {

			$local_file = str_replace( $this->attachments_baseurl, $this->attachments_dir, $url );
			$upload = $this->fetch_local_file( $local_file, $post );

			if( is_wp_error( $upload ) ) {
				$upload = $this->fetch_remote_file( $url, $post );
			}
		} else {
			$upload = $this->fetch_remote_file( $url, $post );
		}

		if ( is_wp_error( $upload ) )
			return $upload;

		if ( $info = wp_check_filetype( $upload['file'] ) )
			$post['post_mime_type'] = $info['type'];
		else
			return new WP_Error( 'attachment_processing_error', __('Invalid file type', 'youxi') );

		$post['guid'] = $upload['url'];

		// as per wp-admin/includes/upload.php
		$post_id = wp_insert_attachment( $post, $upload['file'] );
		wp_update_attachment_metadata( $post_id, wp_generate_attachment_metadata( $post_id, $upload['file'] ) );

		// remap resized image URLs, works by stripping the extension and remapping the URL stub.
		if ( preg_match( '!^image/!', $info['type'] ) ) {
			$parts = pathinfo( $url );
			$name = basename( $parts['basename'], ".{$parts['extension']}" ); // PATHINFO_FILENAME in PHP 5.2

			$parts_new = pathinfo( $upload['url'] );
			$name_new = basename( $parts_new['basename'], ".{$parts_new['extension']}" );

			$this->url_remap[$parts['dirname'] . '/' . $name] = $parts_new['dirname'] . '/' . $name_new;
		}

		return $post_id;
	}

	/**
	 * Attempt to copy a local file attachment
	 *
	 * @param string $path Local path of item to fetch
	 * @param array $post Attachment details
	 * @return array|WP_Error Local file location details on success, WP_Error otherwise
	 */
	function fetch_local_file( $path, $post ) {

		// extract the file name and extension from the url
		$file_name = basename( $path );

		// get placeholder file in the upload dir with a unique, sanitized filename
		$upload = wp_upload_bits( $file_name, 0, '', $post['upload_date'] );
		if ( $upload['error'] )
			return new WP_Error( 'upload_dir_error', $upload['error'] );

		// make sure the local file exists
		if( ! file_exists( $path ) ) {
			@unlink( $upload['file'] );
			return new WP_Error( 'import_file_error', __( 'The specified local file does not exists', 'youxi' ) );
		}

		// read the local file and write it to the placeholder file
		$out_fp = fopen( $upload['file'], 'w' );
		if ( ! $out_fp ) {
			return new WP_Error( 'import_file_error', __( 'The output file can not be created', 'youxi' ) );
		}

		$content = @file_get_contents( $path );
		fwrite( $out_fp, $content );
		fclose( $out_fp );
		clearstatcache();

		$filesize = filesize( $upload['file'] );
		$max_size = (int) $this->max_attachment_size();
		if ( ! empty( $max_size ) && $filesize > $max_size ) {
			@unlink( $upload['file'] );
			return new WP_Error( 'import_file_error', sprintf(__('Attachment file is too large, limit is %s', 'youxi'), size_format($max_size) ) );
		}

		// keep track of the old and new urls so we can substitute them later
		$this->url_remap[$url] = $upload['url'];
		$this->url_remap[$post['guid']] = $upload['url']; // r13735, really needed?

		return $upload;
	}
}

function youxi_importer_handle_wp_xml( $data ) {

	$data = wp_parse_args( $data, array(
		'xml' => '', 
		'attachments_baseurl' => '', 
		'attachments_dir' => ''
	));

	// Import the content
	$wp_import = new Youxi_WP_Import();
	$wp_import->attachments_baseurl = $data['attachments_baseurl'];
	$wp_import->attachments_dir = $data['attachments_dir'];
	$wp_import->fetch_attachments = true;

	ob_start();

	set_time_limit(0);
	$wp_import->import( $data['xml'] );

	return ob_get_clean();
}
