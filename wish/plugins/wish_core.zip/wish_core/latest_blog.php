<?php  /*IJAZ AHMAD*/

// Plain Hero, no images and stuff

class Wish_Latest_Blog {



        var $shortcode = 'wish_latest_blog';

        var $title = "Latest Blog";

        var $details = "A Carousel Of Your Latest Blog Posts";

        //var $path = "/templates/rating_hero.php";



    function __construct() {

        // We safely integrate with VC with this hook

        add_action( 'init', array( $this, 'integrateWithVC' ) );

 

        // Use this when creating a shortcode addon

        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );



        // Register CSS and JS

        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );

    }

 

    public function integrateWithVC() {

        // Check if Visual Composer is installed

        if ( ! defined( 'WPB_VC_VERSION' ) ) {

            // Display notice that Visual Compser is required

            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));

            return;

        }

 

        vc_map( array(

            "name" => __($this->title, 'wish'),

            "description" => __($this->details, 'wish'),

            "base" => $this->shortcode,

            "class" => "",

            "controls" => "full",

            "link"  => "http://i.imgur.com/EflmZro.png",

            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"

            "category" => __('Wish Components', 'wish'),

            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor

            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor

            "params" => array(





                            array(

                                    "type" => "textfield",

                                    "heading" => __("The Title", "wish"),

                                    "param_name" => "title",

                                    "admin_label" => true,

                                    "value" => __("ENROLL YOUR CHILD NOW!", 'wish'),

                            ),

                            array(

                                "type" => "checkbox",

                                "class" => "",

                                "heading" => __( "Show Title?", "wish" ),

                                "param_name" => "show_title",

                                "value" => false,

                                "description" => __( "Tik to show the above Title", "wish" ),

                                "admin_label" => false,

                             ),





                            array(

                                    "type" => "attach_image",

                                    "holder" => "div",

                                    "class" => "",

                                    "heading" => __("Image", 'wish'),

                                    "param_name" => "image",

                                    "description" => __("The parallax image in the background", 'wish'),

                            ), 

                            array(

                                "type" => "checkbox",

                                "class" => "",

                                "heading" => __( "Show Image?", "wish" ),

                                "param_name" => "show_image",

                                "value" => false,

                                "description" => __( "Tik to show the above Image", "wish" ),

                                "admin_label" => false,

                             ),

                        

                            array(

                                "type" => "dropdown",

                                "heading" => __("Max Items", "wish"),

                                "param_name" => "max_items",

                                "description" => __("Maximum Number Of Blog Items to show.", "wish"),

                                "value" => array( 

                                                  "2"     => "2",

                                                  "4"     => "4",

                                                  "6"     => "6",

                                                ),

                                "std"       =>   5,

                            ),



                            array(

                                "type" => "dropdown",

                                "heading" => __("Excerpt Length", "wish"),

                                "param_name" => "excerpt_length",

                                "description" => __("How many words to show from the post?", "wish"),

                                "value" => array( 

                                                  "6"     => "6",

                                                  "10"     => "10",

                                                  "15"     => "14",

                                                  "20"    => "20",

                                                  "25"    => "25",

                                                  "30"    => "30",

                                                ),

                                "std"       =>   14,

                            ),











                            array(

                                    "type" => "textfield",

                                    "heading" => __("The Heading", "wish"),

                                    "param_name" => "heading",

                                    "admin_label" => true,

                                    "value" => __("latest news", 'wish'),

                            ),

                           

                            /*Title*/

                            array(

                                "type" => "google_fonts",

                                "class" => "",

                                "heading" => __("Title Text Font", "wish" ),

                                "param_name" => "title_font",

                                "value" => '', //Default Red color

                                "description" => __( "Choose Font", "wish" ),

                                "group"   => "Fonts & Colors",

                                'settings' => array(

                                     'fields'=>array(

                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

                                   )

                                )       

                            ),





                            array(

                                "type" => "wish_number",

                                "heading" => __("Title Size", "wish"),

                                "param_name" => "title_size",

                                "description" => __("Font size in px", "wish"),

                                "value" => __("30", 'wish'),

                                "admin_label" => true,

                                "group"       => "Fonts & Colors",

                            ),



                            array(

                                "type" => "colorpicker",

                                "class" => "",

                                "heading" => __("Title Text Color", "wish" ),

                                "param_name" => "title_color",

                                "value" => '#df4322 ', //Default Black color

                                "description" => __( "Choose text color", "wish" ),

                                "group"         => "Fonts & Colors",

                             ),





                            /*Heading*/

                            array(

                                "type" => "google_fonts",

                                "class" => "",

                                "heading" => __("Heading Text Font", "wish" ),

                                "param_name" => "heading_font",

                                "value" => '', //Default Red color

                                "description" => __( "Choose Font", "wish" ),

                                "group"   => "Fonts & Colors",

                                'settings' => array(

                                     'fields'=>array(

                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

                                   )

                                )       

                            ),





                            array(

                                "type" => "wish_number",

                                "heading" => __("Heading Size", "wish"),

                                "param_name" => "heading_size",

                                "description" => __("Font size in px", "wish"),

                                "value" => __("26", 'wish'),

                                "admin_label" => true,

                                "group"       => "Fonts & Colors",

                            ),



                            array(

                                "type" => "colorpicker",

                                "class" => "",

                                "heading" => __("Heading Text Color", "wish" ),

                                "param_name" => "heading_color",

                                "value" => '#000 ', //Default Black color

                                "description" => __( "Choose text color", "wish" ),

                                "group"         => "Fonts & Colors",

                             ),







                            /*Blog Title*/

                            array(

                                "type" => "google_fonts",

                                "class" => "",

                                "heading" => __("Blog Title Text Font", "wish" ),

                                "param_name" => "blog_title_font",

                                "value" => '', //Default Red color

                                "description" => __( "Choose Font", "wish" ),

                                "group"   => "Fonts & Colors",

                                'settings' => array(

                                     'fields'=>array(

                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

                                   )

                                )       

                            ),





                            array(

                                "type" => "wish_number",

                                "heading" => __("Blog Title Size", "wish"),

                                "param_name" => "blog_title_size",

                                "description" => __("Font size in px", "wish"),

                                "value" => __("20", 'wish'),

                                "admin_label" => true,

                                "group"       => "Fonts & Colors",

                            ),



                            array(

                                "type" => "colorpicker",

                                "class" => "",

                                "heading" => __("Blog Title Text Color", "wish" ),

                                "param_name" => "blog_title_color",

                                "value" => '#000 ', //Default Black color

                                "description" => __( "Choose text color", "wish" ),

                                "group"         => "Fonts & Colors",

                             ),







                            /*Blog Date*/

                            array(

                                "type" => "google_fonts",

                                "class" => "",

                                "heading" => __("Blog Date Text Font", "wish" ),

                                "param_name" => "blog_date_font",

                                "value" => '', //Default Red color

                                "description" => __( "Choose Font", "wish" ),

                                "group"   => "Fonts & Colors",

                                'settings' => array(

                                     'fields'=>array(

                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

                                   )

                                )       

                            ),





                            array(

                                "type" => "wish_number",

                                "heading" => __("Blog Date Size", "wish"),

                                "param_name" => "blog_date_size",

                                "description" => __("Font size in px", "wish"),

                                "value" => __("16", 'wish'),

                                "admin_label" => true,

                                "group"       => "Fonts & Colors",

                            ),



                            array(

                                "type" => "colorpicker",

                                "class" => "",

                                "heading" => __("Blog Date Text Color", "wish" ),

                                "param_name" => "blog_date_color",

                                "value" => '#000 ', //Default Black color

                                "description" => __( "Choose text color", "wish" ),

                                "group"         => "Fonts & Colors",

                             ),







                            /*Blog details*/

                            array(

                                "type" => "google_fonts",

                                "class" => "",

                                "heading" => __("Blog details Text Font", "wish" ),

                                "param_name" => "blog_details_font",

                                "value" => '', //Default Red color

                                "description" => __( "Choose Font", "wish" ),

                                "group"   => "Fonts & Colors",

                                'settings' => array(

                                     'fields'=>array(

                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

                                   )

                                )       

                            ),





                            array(

                                "type" => "wish_number",

                                "heading" => __("Blog details Size", "wish"),

                                "param_name" => "blog_details_size",

                                "description" => __("Font size in px", "wish"),

                                "value" => __("14", 'wish'),

                                "admin_label" => true,

                                "group"       => "Fonts & Colors",

                            ),



                            array(

                                "type" => "colorpicker",

                                "class" => "",

                                "heading" => __("Blog details Text Color", "wish" ),

                                "param_name" => "blog_details_color",

                                "value" => '#000 ', //Default Black color

                                "description" => __( "Choose text color", "wish" ),

                                "group"         => "Fonts & Colors",

                             ),





                             array(

                                    "type" => "colorpicker",

                                    "class" => "",

                                    "heading" => __( "Background Color", "wish" ),

                                    "param_name" => "bg_color",

                                    "value" => '#fff', //Default Red color

                                    "description" => __( "Choose the background color", "wish" ),

                                    "group"         => "Fonts & Colors",

                            ),









                    )



        ) );

    }

    



    public function renderShortcode( $atts, $content = null ) {

      extract( shortcode_atts( array(

        'title'         => 'ENROLL YOUR CHILD NOW!',

        'title_font'    => '',

        'title_size'    => '30',

        'title_color'   => '#df4322',



        'heading'       => 'latest news',

        'heading_font'  => '',

        'heading_size'  => '26',

        'heading_color' => '#000',



        'blog_title_font'   => '',

        'blog_title_size'   => '20',

        'blog_title_color'  => '#000',



        'blog_date_font'   => '',

        'blog_date_size'   => '16',

        'blog_date_color'  => '#000',





        'blog_details_font'     => '',

        'blog_details_size'     => '14',

        'blog_details_color'    => '#000',



        'show_title'        => false,

        'image'             => 'image',

        'show_image'        => false,

        "max_items"         => "",

        'excerpt_length'    => 15,

        'bg_color'          => '#fff',

      ), $atts ) );



        /*title*/

        $decode_font = urldecode($title_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



        /*heading*/

        $decode_font = urldecode($heading_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $heading_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );





        /*blog_title*/

        $decode_font = urldecode($blog_title_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $blog_title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );





        /*blog_date*/

        $decode_font = urldecode($blog_date_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $blog_date_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );





        /*blog_details*/

        $decode_font = urldecode($blog_details_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $blog_details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );





        // wp_enqueue_script('wish-flex-js', plugins_url('assets/flex-slider/jquery.flexslider.js', __FILE__), array('jquery') );

        // wp_enqueue_script('wish-flex-custom', plugins_url('assets/flex-slider/flexslider.js', __FILE__), array('jquery') );



        //in progress

        $args = array(

          // 'post_type' => 'wish_projects',

          'posts_per_page'  => $max_items,

        );



        $proj_query = new WP_Query( $args );





                // $ctax = get_terms('projects_categories');

                // $tarray = array();

                // foreach($ctax as $tkey=>$tvalue){

                //         $tarray[$tvalue->slug] =  $tvalue->name;

                // }

         $img = wp_get_attachment_image_src( $image, 'full' );



          if($image == "image"){

            $imgsrc = plugins_url('images/school-icons.png', __FILE__);

            $img[0] = $imgsrc;

          }



          $title_string = "";

          $image_string = "";

          if ($show_title == true) {

            $title_string = "<h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>";

          }

          if ($show_image == true) {

            $image_string = "<div class='icons'><img src='{$img[0]}' class='img-responsive  center-block' alt=''></div>";

          }



               

      $output = "<div class='latest-news' style='{background-color:{$bg_color};}'>

      <div class='container'>

        <div class='row'>

          <div class='col-lg-12 header'>

            {$title_string}

          </div>
          </div>

          <div class='row'>
          <div class='col-lg-12'>
            {$image_string}

            <h3 style='font-family:{$heading_font_family};font-size:{$heading_size}px;color:{$heading_color};'>{$heading}</h3>

          </div>";

                    

                        while ( $proj_query->have_posts() ) : $proj_query->the_post();  



                               $pid =  get_the_ID();

                               



                               $thumbid = get_post_thumbnail_id( $pid );

                               $thumb = wp_get_attachment_image_src($thumbid, array(250,300) );

                               $thumb_big = wp_get_attachment_image_src($thumbid, '250x300');



                               $title = get_the_title($pid);

                               $excerpt = wish_shorten_string(get_the_excerpt(), $excerpt_length);

                              



                               $out_thumb = $thumb[0];

                               $out_big = $thumb_big[0];



                               $date= get_the_date();



                               if($out_thumb[0] == ""){

                                    $out_thumb = plugins_url('images/240x240.gif', __FILE__);   

                               }



                               if($thumb_big[0] == ""){

                                    $out_big = plugins_url('images/1000x1000.gif', __FILE__);   

                               }               



                               $link = esc_url(get_post_permalink());

                               $title = get_the_title();  



                                $output .= "<div class='col-lg-6 col-md-6 col-sm-6 block'>

                                                <div class='row'>

                                                  <div class='col-lg-6'>

                                                    <div class='picture'><img src='{$out_thumb}' class='img-responsive' alt=''></div>

                                                  </div>

                                                  <div class='col-lg-6'>

                                                    <div class='info'>

                                                      <div class='caption' style='font-family:{$blog_title_font_family};font-size:{$blog_title_size}px;color:{$blog_title_color};'>{$title}</div>

                                                      <div class='date' style='font-family:{$blog_date_font_family};font-size:{$blog_date_size}px;color:{$blog_date_color};'>{$date}</div>

                                                      <div class='description' style='font-family:{$blog_details_font_family};font-size:{$blog_details_size}px;color:{$blog_details_color};'>{$excerpt}</div>

                                                      <div class='buttons'><a href='{$link}' class='fill'>". __("Read More", "wish") ."</a></div>

                                                    </div>

                                                  </div>

                                                </div>

                                              </div>";







                        endwhile;   

                        wp_reset_postdata();        





                     $output .=   "</div>

      </div>

    </div>";





      return $output;

    }



    /*

    Load plugin css and javascript files which you may need on front end of your site

    */

    public function loadCssAndJs() {

      //wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );

      //wp_enqueue_style( 'vc_extend_style' );



      // If you need any javascript files on front end, here is how you can load them.

      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );

    }



    /*

    Show notice if your plugin is activated but Visual Composer is not

    */

    public function showVcVersionNotice() {

        $plugin_data = get_plugin_data(__FILE__);

        echo '

        <div class="updated">

          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>

        </div>';

    }







}//end of class

?>