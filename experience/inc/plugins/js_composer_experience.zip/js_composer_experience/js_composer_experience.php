<?php
/*
	Plugin Name:    Experience Visual Composer Extension
	Plugin URI:     
	Description:    A plugin to add new elements to Visual Composer intended for use with the Experience theme.
	Author:         
	Author URI:     
	Version:        1.0.6
	Text Domain:    js_composer_experience
	Domain Path:	/locale
*/

if ( !defined( 'ABSPATH' ) ) exit;

if ( !class_exists( 'JsComposerExperience' ) ) {
	
	/**
	 * Main plugin class used to load shortcodes, scripts and language files
	 **/
	class JsComposerExperience {		

		public function __construct() {
			
			add_action( 'admin_notices', 								array( $this, 'jsComposerExperienceShowAdminNotices' ) );
			add_action( 'admin_enqueue_scripts', 						array( $this, 'jsComposerExperienceAdminNoticeScripts' ) );
			add_action( 'wp_ajax_js_composer_experience_dismiss_notice',array( $this, 'jsComposerExperienceUpdateDismissNoticeOption' ) );			
			add_action( 'vc_before_init',								array( $this, 'jsComposerExperienceLoadElements' ) );			
			add_action( 'init',											array( $this, 'jsComposerExperienceLoadTextDomains' ) );
			add_action( 'admin_enqueue_scripts',						array( $this, 'jsComposerExperienceAdminScripts' ) );
			add_action( 'wp_enqueue_scripts',							array( $this, 'jsComposerExperienceFrontScripts' ) );
			register_deactivation_hook( __FILE__, 						array( $this, 'jsComposerExperienceRemoveDismissNoticeOption' ) );			
			
		}
		
		
		/**
		 * Displays theme related admin notices.
		 **/
		public function jsComposerExperienceShowAdminNotices() {
			if ( !defined( 'WPB_VC_VERSION' ) && get_option( 'js-composer-experience-notice-dismissed' ) != '1' ) {		
				echo '<div class="notice error js-composer-experience-vc-notice is-dismissible">
					<p>'. wp_kses( __( "The <strong>Experience Visual Composer Extension</strong> plugin requires that <strong><a href='http://codecanyon.net/item/visual-composer-page-builder-for-wordpress/242431?ref=EugeneO' target='_blank'>WPBakery Visual Composer</a></strong> plugin is installed and activated.", "js_composer_experience" ), array( 'strong' => array(), 'a' => array( 'href' => array(), 'target' => array() ) ) ) .'</p>
				</div>';
			}
		}
		
		
		/**
		 * Enqueues script that updates admin notice dismissed flag in options database
		 **/		
		public function jsComposerExperienceAdminNoticeScripts() {
			if ( !defined( 'WPB_VC_VERSION' ) && get_option( 'js-composer-experience-notice-dismissed' ) != '1' ) {
				wp_enqueue_script( 'js-composer-experience-notice-update',  plugins_url( 'assets/js/js-composer-experience-notice-update.js', __FILE__ ), array( 'jquery' ), '1.0', true  );			
			}
		}


		/**
		 * AJAX action that updates admin notice dismissed flag in options database
		 **/		
		public function jsComposerExperienceUpdateDismissNoticeOption() {		
			if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
				update_option( 'js-composer-experience-notice-dismissed', '1' );
			}		
			die();		
		}

		
		/**
		 * Removes admin notice flag from options database when plugin is deactivated
		 **/		
		public function jsComposerExperienceRemoveDismissNoticeOption() {	
			delete_option( 'js-composer-experience-notice-dismissed' );	
		}
	
	
		/**
		 * Load back end scripts and styles
		 **/
		public function jsComposerExperienceAdminScripts( $hook ) {
			
			if ( 
				'post.php' != $hook
				&& 'edit.php' != $hook
				&& 'post-new.php' != $hook
			) {	
				return;
			}	
	
			// Admin CSS
			//wp_enqueue_style( 'js-composer-experience-admin', plugins_url( 'assets/css/js-composer-experience-admin.css', __FILE__ ) );
		
		}
		
		
		/**
		 *	Load front end scripts and styles
		 **/
		public function jsComposerExperienceFrontScripts() {
			
			$experience_vc_utilities = new jsComposerExperienceUtilities();		
			
			// Element CSS
			wp_enqueue_style( 'js-composer-experience',		plugins_url( 'assets/css/js-composer-experience.css', __FILE__ ), false );
			
			// Fancybox
			wp_enqueue_script( 'jquery-fancybox',			plugins_url( 'assets/js/jquery.fancybox.pack.js', __FILE__  ), array( 'jquery' ), false, 1 );
			wp_enqueue_script( 'jquery-fancybox-media',		plugins_url( 'assets/js/jquery.fancybox-media.js', __FILE__  ), array( 'jquery-fancybox' ), false, 1 );
			wp_enqueue_style( 'fancybox',					plugins_url( 'assets/css/jquery.fancybox.css', __FILE__  ) );
			
			// flexslider
			wp_enqueue_script( 'jquery-flexslider',			plugins_url( 'assets/js/jquery.flexslider.min.js', __FILE__  ), array( 'jquery' ) );
			
			$theme_data  = wp_get_theme();
			$is_child    = $experience_vc_utilities->experienceIsChild( $theme_data );
			$parent_name = false;
			
			if ( $is_child ) {
				$parent_name = $theme_data->parent()->Name;
			}

			if ( ( !$is_child && $theme_data->Name != 'Experience' ) || ( $is_child && $parent_name != 'Experience' ) ) {
				wp_enqueue_style( 'flexslider',				plugins_url( 'assets/css/flexslider.css', __FILE__  ) );				
			}
			
			// MediaElement
			wp_enqueue_script( 'mediaelement' );
			wp_enqueue_script( 'wp-mediaelement' );
			wp_enqueue_style( 'wp-mediaelement' );			
			
			// Custom JS
			wp_enqueue_script( 'js-composer-experience',	plugins_url( 'assets/js/jquery.js-composer-experience.js', __FILE__  ), array( 'jquery' ) );
			
		}
		
		
		/**
		 *	Load Visual Composer elements
		 **/
		public function jsComposerExperienceLoadElements() {
			
			foreach ( glob( dirname( __FILE__ ) . '/include/shortcodes/*.php' ) as $file ) {
				require_once $file;
			}
			
		}
		
		
		/**
		 *	Load language file
		 **/
		public function jsComposerExperienceLoadTextDomains() {
			load_plugin_textdomain( 'js_composer_experience', false, dirname( plugin_basename( __FILE__ ) ) .'/locale' );
		}		

	}
	
	$experience_vc = new JsComposerExperience();
	
}



if ( !class_exists( 'jsComposerExperienceUtilities' ) ) {

	/**
	 * Class containing utility functions to formatting and output within shortcodes
	 **/
	class jsComposerExperienceUtilities {
	
		public function __construct() {}
		
		/**
		 * Resize text
		 **/
		public function experienceResizeText( $string = false, $resize = 9 ) {
			
			if ( $string != false ) {
			
				$long_word = false;			
				$words = explode( " ", $string );
				
				foreach ( $words as $word ) {
					
					if ( strlen( $word ) > intval( $resize ) ) {
						$long_word = true;
					}
				
				}
				
				if (
					$long_word == true 
					|| count( $words ) > 3
				) {
					$string = '<span class="small-text">'. esc_html( $string ) .'</span>'; 
					
				}
				
				// Sanitize string
				$string = wp_kses( $string, array( 'span' => array( 'class' => array() ) ) );
			
				return $string;
				
			} else {
				
				return false;
				
			}

		}
		
		
		/**
		 * Get background image and/or video
		 **/
		public function experienceGetBackground( $image = false, $mp4 = false, $webm = false, $parallax_speed = false, $v_offset = false, $h_offset = false, $echo = true ) {
		
			global $post;
			
			if ( $image != "" ) {
				
				$output = '<div class="background-holder">';
				
					$output .= '<div class="background-image" style="background-image: url('. esc_url( $image ) .');"></div>';				
					
					$output .= '<div class="background-overlay"></div>';
				
				$output .= '</div>';
				
				if ( $echo == true ) {
					echo $output;
				} else {
					return $output;
				}
				
			}

		}
		
		
		/**
		 * Conditional to check if the active theme is a child theme
		 **/
		public function experienceIsChild( $theme_data ) {
			
			$parent = $theme_data->parent();
			
			if ( ! empty( $parent ) ) {
				return true;
			}
			
			return false;
			
		}
		
	
	}

}