<?php
/*
Plugin Name: Indeed My Testimonials
Plugin URI: http://www.wpindeed.com/
Description: The most shainny Testimonials Showcase plugin. With predifined themes and colors scheme you can display your testimonials with few clicks and without any line of code.
Version: 1.2.pix.3
Author: indeed
Author URI: http://www.wpindeed.com
*/

///FUNCTIONS
include_once(plugin_dir_path ( __FILE__ ).'includes/functions.php');

//////// imtst on EACH FUNCTION NAME

add_action( 'init', 'imtst_post_testimonials' );
function imtst_post_testimonials() {
  $labels = array(
    'name'               => 'Testimonials',
    'singular_name'      => 'Testimonial',
    'add_new'            => 'Add New Testimonial',
    'add_new_item'       => 'Add New Testimonial',
    'edit_item'          => 'Edit Testimonial',
    'new_item'           => 'New Testimonial',
    'all_items'          => 'All Testimonials',
    'view_item'          => 'View Testimonial',
    'search_items'       => 'Search Testimonial',
    'not_found'          => 'No Testimonial available',
    'not_found_in_trash' => 'No Testimonials found in Trash',
    'parent_item_colon'  => '',
    'menu_name'          => 'My Testimonials'
  );
  $args = array(
    'labels'             => $labels,
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => 8,
    'menu_icon'          => plugin_dir_url( __FILE__ ) . 'files/images/ed-gray.png',
    'supports'           => array( 'title', 'editor', 'thumbnail' )
  );
    register_post_type( 'testimonials', $args );
}
////////////TAXONOMY
add_action( 'init', 'imtst_taxonomy_testimonials', 0 );
function imtst_taxonomy_testimonials() {
	$labels = array(
		'name'              => _x( 'Groups', 'taxonomy general name' ),
		'singular_name'     => _x( 'Group', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Groups' ),
		'all_items'         => __( 'All Groups' ),
		'parent_item'       => __( 'Parent Group' ),
		'parent_item_colon' => __( 'Parent Group:' ),
		'edit_item'         => __( 'Edit Group' ),
		'update_item'       => __( 'Update Group' ),
		'add_new_item'      => __( 'Add New Group' ),
		'new_item_name'     => __( 'New Group Name' ),
		'menu_name'         => __( 'Groups' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'testimonial_groups' ),
	);
register_taxonomy( 'testimonial_groups', 'testimonials', $args );
}

////RENAME FEATURED IMAGE TO LOGO
add_action('do_meta_boxes', 'imtst_change_image_box');
function imtst_change_image_box(){
    remove_meta_box( 'postimagediv', 'testimonials', 'side' );
    add_meta_box('postimagediv', __('Client Image'), 'post_thumbnail_meta_box', 'testimonials', 'normal', 'high');
}
add_action('admin_head-post-new.php', 'imtst_change_thumbnail_html');
add_action('admin_head-post.php', 'imtst_change_thumbnail_html');
function imtst_change_thumbnail_html( $content ) {
    if ( isset($GLOBALS['post_type']) && $GLOBALS['post_type']=='testimonials' )
      add_filter('admin_post_thumbnail_html', 'imtst_rename_thumb');
}
function imtst_rename_thumb($content){
     return str_replace(__('featured image'), __('Client Image'), $content);
}


///////////////SHORTCODE GENERATOR ( SUBMENU )
add_action( 'admin_menu', 'imtst_shortcode_menu_testimonials' );
function imtst_shortcode_menu_testimonials(){
    add_submenu_page( 'edit.php?post_type=testimonials', 'Shortcode Generator', 'Shortcode Generator', 'manage_options', 'testimonials_shortcode_generator', 'imtst_shortcode_page_testimonials' );
    add_submenu_page( 'edit.php?post_type=testimonials', 'Form Builder', 'Form Builder', 'manage_options', 'testimonials_form_builder', 'imtst_formbuilder_page_testimonials' );
}
function imtst_shortcode_page_testimonials(){
    $dir_path = plugin_dir_path ( __FILE__ );
    $dir_url = plugin_dir_url ( __FILE__ );
    include( $dir_path . 'includes/imtst_shortcode_generator.php' );
}
function imtst_formbuilder_page_testimonials(){
    $dir_path = plugin_dir_path ( __FILE__ );
    $dir_url = plugin_dir_url ( __FILE__ );
    include( $dir_path . 'includes/imtst_form_builder.php' );
}
/////////CUSTOM FIELD
    //////////INFO
    add_action( 'add_meta_boxes', 'imtst_cf_ti' );
    function imtst_cf_ti(){
        add_meta_box('client_personal_info',
                     'Client Information',
                     'imtst_metabox_ti', //function available in function.php
                     'testimonials',
                     'normal',
                     'low');
    }
    add_action('save_post', 'imtst_save_ti');
    //////////RATINGS
    add_action( 'add_meta_boxes', 'imtst_cf_rating' );
    function imtst_cf_rating(){
        add_meta_box('client_rating',
                     'Ratings',
                     'imtst_metabox_rating', //function available in function.php
                     'testimonials',
                     'normal',
                     'low');
    }

////////SHORTCODE
add_shortcode( 'indeed-my-testimonials', 'imtst_shortcode_func_team' );
function imtst_shortcode_func_team($attr){
    $dir_path = plugin_dir_path ( __FILE__ );
    $dir_url = plugin_dir_url( __FILE__ );
    $return_str = true;
    include( $dir_path . 'includes/imtst_view.php' );
    return $final_str;
}
////////SHORTCODE Form Builder
add_shortcode( 'indeed-my-testimonials-form', 'imtst_form_shortcode' );
function imtst_form_shortcode($attr){
    $dir_path = plugin_dir_path ( __FILE__ );
    $dir_url = plugin_dir_url( __FILE__ );

    //wp_enqueue_style ( 'indeed_style', $dir_url.'files/css/style.css' ); //pixedelic
    wp_enqueue_script ( 'testimonials_js', $dir_url.'files/js/functions.js', array(), null );

    $return_str = true;
    include( $dir_path . 'includes/imtst_form_view.php' );
    return $str;
}


////////WIDGET
class IndeedMyTestimonialsWidget extends WP_Widget {
	function IndeedMyTestimonialsWidget() {
		// Instantiate the parent object
		parent::__construct( false, 'Indeed My Testimonials' );
	}

	function widget( $args, $instance ) {
        $dir = plugin_dir_path ( __FILE__ );
	    $current_instance_id = explode('-', $this->id);
		$instance_no = $current_instance_id[1];

        $attr = $instance;
        include ($dir . 'includes/imtst_view.php');

        global $wp_query;
        $a = get_post_meta( $wp_query->post->ID, '_wp_page_template', true );
	}

	function update( $new_instance, $old_instance ){
		$instance = $old_instance;
        $instance['group'] = $new_instance['group'];
        $instance['limit'] = $new_instance['limit'];
        $instance['order'] = $new_instance['order'];
        $instance['order_by'] = $new_instance['order_by'];
        $instance['color_scheme'] = $new_instance['color_scheme'];
        $instance['theme'] = $new_instance['theme'];
        $instance['show'] = $new_instance['show'];
        $instance['page_inside'] = $new_instance['page_inside'];
        $instance['inside_template'] = $new_instance['inside_template'];
        $instance['columns'] = $new_instance['columns'];

        //SLIDER
        $instance['slider_set'] = $new_instance['slider_set'];
        $instance['items_per_slide'] = $new_instance['items_per_slide'];
        $instance['slide_speed'] = $new_instance['slide_speed'];
        $instance['slide_pagination_speed'] = $new_instance['slide_pagination_speed'];
        $instance['slide_css_transition'] = $new_instance['slide_css_transition'];
        $instance['slide_opt'] = $new_instance['slide_opt'];

        return $instance;
	}

	function form( $instance ) {
	    $dir_path = plugin_dir_path ( __FILE__ );
        $dir_url = plugin_dir_url ( __FILE__ );

        wp_enqueue_script( 'functions', $dir_url.'files/js/functions.js');
        wp_enqueue_style( 'be_style', $dir_url.'files/css/style.css');

	    $current_instance_id = explode('-', $this->id);
		$instance_no = $current_instance_id[1];
        include ( $dir_path . 'includes/imtst_widget_form.php' );
	}
}

function register_IndeedMyTestimonialsWidget() {
	register_widget( 'IndeedMyTestimonialsWidget' );
}
add_action( 'widgets_init', 'register_IndeedMyTestimonialsWidget' );


////STYLE AND JS
add_action('wp_enqueue_scripts', 'imtst_fe_head');
function imtst_fe_head(){
  $dir_url = plugin_dir_url ( __FILE__ );
  wp_enqueue_style( 'imtst_style', $dir_url.'files/css/style.css' );
  wp_enqueue_style ( 'owl.carousel', $dir_url.'files/css/owl.carousel.css' );
  wp_enqueue_style ( 'owl.theme', $dir_url.'files/css/owl.theme.css' );
  wp_enqueue_style ( 'owl.transitions', $dir_url.'files/css/owl.transitions.css' );

  wp_enqueue_script( 'jquery' );
  wp_enqueue_script ( 'owl.carousel', $dir_url.'files/js/owl.carousel.js', array(), null );
  wp_enqueue_script ( 'front_end_testimonials_js', $dir_url .'files/js/front_end.js', array(), null );
}


add_action("admin_enqueue_scripts", 'imtst_be_head');
function imtst_be_head(){
    $is_edit = FALSE;
    $itst_screen = get_current_screen();
    if( $itst_screen->post_type=="testimonials") $is_edit = TRUE;

    $plugin_pages = array('testimonials_shortcode_generator', 'testimonials', 'testimonials_form_builder');
    if( (isset($_GET['page']) && in_array($_GET['page'], $plugin_pages))
        || (isset($_GET['post_type']) && in_array($_GET['post_type'], $plugin_pages))
        || $is_edit==TRUE ){
          $dir_path = plugin_dir_url ( __FILE__ );
          wp_enqueue_style ( 'font-awesome', $dir_path.'files/css/font-awesome.min.css' );
          wp_enqueue_style ( 'imtst_style', $dir_path.'files/css/style.css' );
          wp_enqueue_style ( 'owl.carousel', $dir_path.'files/css/owl.carousel.css' );
          wp_enqueue_style ( 'owl.theme', $dir_path.'files/css/owl.theme.css' );
          wp_enqueue_style ( 'owl.transitions', $dir_path.'files/css/owl.transitions.css ');

          wp_enqueue_script('jquery');
          wp_enqueue_script ( 'functions', $dir_path.'files/js/functions.js', array(), null );
          wp_enqueue_script ( 'owl.carousel', $dir_path.'files/js/owl.carousel.js', array(), null );
    }
}

//////  INSIDE TEMPLATE OPTION
add_filter( 'template_include', 'imtst_portfolio_page_template', 99 );
function imtst_portfolio_page_template( $template ) {
    if(get_post_type()=='testimonials' && isset($_REQUEST['imtst_cpt']) && $_REQUEST['imtst_cpt']!=''){
        $template = urldecode($_REQUEST['imtst_cpt']);
        $template .= ".php";
    	$new_template = locate_template( $template );
        return $new_template;
    }
    else return $template;
}


//////////CUSTOM ADMIN COLUMNS
///IMAGE COLUMN
add_filter('manage_edit-testimonials_columns', 'imtst_custom_admin_column');
function imtst_custom_admin_column($columns) {
    $new_columns['cb'] = '<input type="checkbox" />';
    $new_columns['title'] = __('Client Name', '');

    $new_columns['quote'] = 'Quote';
    $new_columns['postimagediv'] = 'Client Image';
    $new_columns['taxonomy-clients_groups'] = __('Groups');
    $new_columns['date'] = _x('Date', 'column name');
    return $new_columns;
}
add_action('manage_posts_custom_column',  'imtst_display_columns' );
function imtst_display_columns($name) {
    global $post;
    switch($name){
        case 'postimagediv':
            $src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail', false, '' );
            if($src!='') echo "<img src='{$src[0]}' width='50' height='50' title='{$post->post_title}'/>";
        break;
        case 'quote':
            $the_content = $post->post_content;
            $arr = explode(" ", $the_content);
      			if (count($arr) > 15){
      			    array_splice($arr, 15);
      				$the_content = implode(" ", $arr);
                    $the_content .= " ...";
      			}
            echo $the_content;
        break;
    }
}

//////AJAX
function imtst_submit_form() {
  //print_r($_REQUEST);
    //die();
}
add_action('wp_ajax_imtst_submit_form', 'imtst_submit_form');
add_action('wp_ajax_nopriv_imtst_submit_form', 'imtst_submit_form');

/**
 * Load text domain for translation.
 * pixedelic
 *
 * @since    1.2.pix.3
 */
function pixedelic_4_imt_load_plugin_textdomain() {

  $domain = 'indeed-my-testimonials';
  $locale = apply_filters( 'plugin_locale', get_locale(), $domain );

  load_textdomain( $domain, WP_LANG_DIR . '/' . $domain . '/' . $domain . '-' . $locale . '.mo' );
  load_plugin_textdomain( $domain, FALSE, dirname( plugin_basename( __FILE__ ) ) . '/lang/' );
}