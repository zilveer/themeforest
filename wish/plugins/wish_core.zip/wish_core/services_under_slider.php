<?php  /*IJAZ AHMAD*/
//Register "container" content element
function wish_revslider_buildShortcode() {
    if ( class_exists( 'RevSlider' ) ) {

        $slider = new RevSlider();
        $arrSliders = $slider->getArrSliders();

        $revsliders = array();
        if ( $arrSliders ) {
            foreach ( $arrSliders as $slider ) {
                /** @var $slider RevSlider */
                $revsliders[ $slider->getTitle() ] = $slider->getAlias();
            }
        } else {
            $revsliders[ __( 'No sliders found', 'js_composer' ) ] = 0;
        }

        return $revsliders;

    }
}

$revsliders = wish_revslider_buildShortcode();


vc_map( array(
    "name" => __("School Slider", "wish"),
    "description" => __("Services with Image Name and Links", 'wish'),
    "controls" => "full",
    "base" => "wish_school_slider",
    "as_parent" => array('only' => 'wish_service_school_slider'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element

         array(
            "type" => "textfield",
            "heading" => __("title", "wish"),
            "param_name" => "title",
            "description" => __("Services under slider", "wish"),
            "value" => __("Services under slider", 'wish'),
            "admin_label" => false,
        ),
         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Font color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000', //Default Red color
            "description" => __( "Choose text color", "wish" )
         ),
         array(
            'type' => 'dropdown',
            'heading' => __( 'Revolution Slider', 'js_composer' ),
            'param_name' => 'alias',
            'admin_label' => true,
            'value' => $revsliders,
            'description' => __( 'Select your Revolution Slider.', 'js_composer' )
        ),

    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Service", "wish"),
    "base" => "wish_service_school_slider",
    "content_element" => true,
    "as_child" => array('only' => 'wish_school_slider'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,    
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background color", "wish" ),
            "param_name" => "bg_color",
            "value" => '#478943', //Default Red color
            "description" => __( "Choose background color", "wish" )
         ),        

        array(
            "type" => "wish_fontawesome_param",
            "holder" => "div",
            "class" => "",
            "heading" => __("Custom Icon", 'wish'),
            "param_name" => "custom_icon",
            "value" => __("fa-book", 'wish'),
            "description" => __("Get Font Awesome Icons Code Here: <a target='_blank' href='http://fortawesome.github.io/Font-Awesome/cheatsheet/'>Link</a>, New icons may not work. Leave blank if you want to use the above icon.", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Icon color", "wish" ),
            "param_name" => "icon_color",
            "value" => '#fff', //Default Red color
            "description" => __( "Choose color of icon", "wish" )
         ),

        array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("Link To The Page", 'wish'),
            "param_name" => "link",
            "description" => __("The Link To The Appointment page.", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Link Title", "wish"),
            "param_name" => "link_text",
            "description" => __("Title of the link", "wish"),
            "value" => __("Fee Structure", 'wish'),
            "admin_label" => false,
        ),


    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_School_Slider extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'bgcolor'   => '',
            'alias' => $revsliders,
          ), $atts ) );

      $output = "<div id='slider'>" . do_shortcode("[rev_slider " . $alias . "]") . "
      </div>
      <div class='container home-intro'>
            <div class='row'>
                    " . do_shortcode($content) . "
            </div>
        </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Service_School_Slider extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'custom_icon' => 'fa-book',
            'bg_color' => '#478943',
            'icon_color' => '#fff',
            'image'   => 'Image',
            'link' => '#',
            'link_text' => 'Fee Structure',
          ), $atts ) );



          $img = wp_get_attachment_image_src( $image, array(360,220) );

          if($image == "Image"){
            $imgsrc = plugins_url('images/school1.jpg', __FILE__);
            $img[0] = $imgsrc;
          }

          if($link == "||" || $link == "" ){
            
            $link_text = "Fee Structure";
            $link_url = "#";
            $link_target = "";
            $link_String="";

          }else{

            $link = vc_build_link($link); //parse the link
            $link_url = esc_url($link["url"]);
            $link_target = esc_attr($link["target"]);
            $link_String="<div class='btn center-block'><a href='#' class='fill'>{$link_text}</a></div>";
            if ($link_text == "") {
                $link_String = "";
            }

          }

          $output = "<div class='col-lg-3 col-md-3'>
                    <div class='block animated' data-animation='fadeInUp' data-animation-delay='100'>
                        <div class='picture'><img src='{$img[0]}' class='img-responsive' alt=''></div>
                        <div class='icon' style='background-color:{$bg_color}'><i class='fa {$custom_icon}' style='color:{$icon_color}'></i></div>
                        {$link_String}
                    </div>
                </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>