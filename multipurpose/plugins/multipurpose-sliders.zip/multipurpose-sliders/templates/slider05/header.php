<section class="slider5 p%PATTERN%">
  <div>
    <div class="slider">
