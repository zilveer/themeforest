<?php

if(!isset($attr)){

///////////////PREVIEW

    $current_path = $_SERVER['SCRIPT_FILENAME'];

    $dir_arr = explode( 'wp-content/', $current_path );

    $dir = $dir_arr[0];

    require_once( $dir . 'wp-load.php' );

    $attr = $_REQUEST;

}

    $show_arr = explode(',', $attr['show']);

    if($attr['order_by']=='name') $orderby = 'title';

    else $orderby = 'date';

    if($attr['limit']==0) $limit = -1;

    else $limit = $attr['limit'];

    $args = array(

    	'posts_per_page'   => $limit,

    	'orderby'          => $orderby,

    	'order'            => $attr['order'],

    	'post_type'        => 'testimonials',

    	'post_status'      => 'publish',

        );

    if($attr['group']=='all'){

      $args['tax_query'] = array();

    }else {

      $args['tax_query'] = array(

                                    array(

                   			            'taxonomy' => 'testimonial_groups',

                                        'field' => 'slug',

                                        'terms' => $attr['group']

                                         )

                                );

    }

    $the_posts = get_posts($args);



    //final_str will contain the output

    $final_str = "";



if(count($the_posts)>0){

    if($attr['slider_set']==1){

        $parent_class = 'carousel_view';

    }else    $parent_class = 'ict_content_cl';

    $num = rand(1, 10000);

    $div_parent_id = 'indeed_carousel_view_widget_' . $num;

    $arrow_wrapp_id = 'wrapp_arrows_widget_' . $num;

    $ul_id = 'indeed_ul_' . $num;

    if(isset($dir_path)) $dir_path .= 'themes/';

    else {

        $dir_path = plugin_dir_path (__FILE__);

        $dir_path = str_replace('includes', 'themes', $dir_path);

    }

    $theme_file = $dir_path . $attr['theme'] . "/index.php";

    if( file_exists( $theme_file ) ) include( $theme_file );

    else die();

	$url_path = plugin_dir_url (__FILE__);

    $url_path = str_replace('includes', 'themes', $url_path);

    //$final_str .= '<link rel="stylesheet" href="'.$url_path.$attr['theme'] .'/style.css" type="text/css" media="all">'; //pixedelic

    if($attr['color_scheme']!=''){

        $url_path = str_replace( 'themes', 'layouts', $url_path );

        //$final_str .= '<link rel="stylesheet" href="'. $url_path . 'style_' . $attr['color_scheme'] . '.css" type="text/css" media="all">'; //pixedelic

		$color_class = 'style_' . $attr['color_scheme'];

    } else {

        $color_class = '';

        $final_str_2 = '';  //pixedelic
    }

    $final_str .= "<div class='$color_class'>";

    $final_str .= "<div class='{$attr['theme']}'>";

    $final_str .= '<style scoped>@import url('.$url_path.$attr['theme'] .'/style.css);</style>'; //pixedelic

    $final_str .= "<div class='ict_wrapp'>";

    $final_str .= "<div class='$parent_class' id='$div_parent_id' >";

    $default_item = $list_item_template;

    $li_width = 100 / $attr['columns'];

    $li_width .= '%';

    $j = 1;

    $breaker_div = 1;

    $new_div = 1;

    $total_items = count($the_posts);

    if($attr['slider_set']==1) $items_per_slide = $attr['items_per_slide'];

    else $items_per_slide = $total_items;

    foreach($the_posts as $post){

        if($new_div==1){

            $div_id = $ul_id.'_' . $breaker_div;

            $final_str .= "<ul id='$div_id' class=''>"; /////ADDING THE UL

        }

            $final_str .= "<li style='width: $li_width'>";

        ////NAME

        if(in_array('name', $show_arr)){

            $name = get_the_title($post->ID);

            $list_item_template = str_replace("IMTST_NAME", $name, $list_item_template);

        }else $list_item_template = str_replace("IMTST_NAME", "", $list_item_template);

        ////QUOTE

        if(in_array('quote', $show_arr)){

            $quote = $post->post_content;

            $list_item_template = str_replace("IMTST_QUOTE", $quote, $list_item_template);

        }else { $list_item_template = str_replace("IMTST_QUOTE", "", $list_item_template);

			    $list_item_template = str_replace("#SHOW_QUOTE", "hide", $list_item_template);

			  }

        ////IMAGE

        if(in_array('image', $show_arr)){

            $src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), array( 150,150 ), false, '' );

            $list_item_template = str_replace("IMTST_IMAGE", $src[0],$list_item_template);

        }else {$list_item_template = str_replace("IMTST_IMAGE", "", $list_item_template);

			   $list_item_template = str_replace("#SHOW_IMG", "hide", $list_item_template);

		}

        ////CLIENT JOB

        if(in_array('job', $show_arr)){

            $job = get_post_meta( $post->ID, 'imtst_jobtitle', true );

            $list_item_template = str_replace("IMTST_CLIENT_JOB", $job, $list_item_template);

			if(in_array('name', $show_arr)){$list_item_template = str_replace("#SHOW_JOB", "show", $list_item_template);}

        }else $list_item_template = str_replace("IMTST_CLIENT_JOB", "", $list_item_template);

        ////CLIENT URL

        if(in_array('client_url', $show_arr)){

            $client_url = get_post_meta( $post->ID, 'imtst_clienturl', true );

            $list_item_template = str_replace("#IMTST_CLIENT_URL", ' href="'.$client_url.'" ', $list_item_template);

        }else $list_item_template = str_replace("#IMTST_CLIENT_URL", "", $list_item_template);

        ////COMPANY

        if(in_array('company', $show_arr)){

            $company = get_post_meta( $post->ID, 'imtst_company', true );

            $list_item_template = str_replace("IMTST_COMPANY", $company, $list_item_template);

			 if(in_array('job', $show_arr)){$list_item_template = str_replace("#SHOW_COMP", "show", $list_item_template);}

        }else $list_item_template = str_replace("IMTST_COMPANY", "", $list_item_template);

        ////COMPANY URL

        if(in_array('company_url', $show_arr)){

            $company_url = get_post_meta( $post->ID, 'imtst_companyurl', true );

            $list_item_template = str_replace("#COMPANY_URL", ' href="'.$company_url.'" ', $list_item_template);

        }else $list_item_template = str_replace("#COMPANY_URL", "", $list_item_template);

        ////STARS

        if(in_array('stars', $show_arr)){

            $rating = get_post_meta( $post->ID, 'imtst_stars', true );

            $stars = imtst_return_stars($rating);

            $list_item_template = str_replace("IMTST_STARS", $stars, $list_item_template);

        }else $list_item_template = str_replace("IMTST_STARS", "", $list_item_template);

        ////DATE

        if(in_array('date', $show_arr)){

            $date = get_the_time('Y-m-d', $post->ID);

            $list_item_template = str_replace("IMTST_DATE", $date, $list_item_template);

			if(in_array('stars', $show_arr)){$list_item_template = str_replace("#SHOW_DATE", "show", $list_item_template);}

        }else $list_item_template = str_replace("IMTST_DATE", "", $list_item_template);



        ////LINKS

        //if($attr['page_inside']==1){ //pixedelic

            $link = get_permalink( $post->ID );

            if($attr['inside_template']!="default"){

                $u_template = urlencode( $attr['inside_template'] );

                $link = add_query_arg( array('imtst_cpt' => $u_template ), $link );

            }


            $list_item_template = str_replace("#IMTST_POST_LINK#", $link, $list_item_template);

        //} else $list_item_template = str_replace("#IMTST_POST_LINK#", "", $list_item_template); //pixedelic



        $final_str .= $list_item_template;

        $final_str .= "</li><!-- ciao -->";

        $list_item_template = $default_item;

      if( $j % $items_per_slide==0 || $j==$total_items ){

      	  $breaker_div++;

      	  $new_div = 1;

          $final_str .= "</ul>";

      }else $new_div = 0;

      $j++;

    }

        $final_str .= "</div>";

        

        if($attr['slider_set']==1){

            $total_pages = $total_items / $items_per_slide;

            if($total_pages>1){

              $navigation = 'false';

              $bullets = 'false';

              $autoplay = 'false';

              $stop_hover = 'false';

              $lazy_effect = 'false';

              $responsive = 'false';

              $lazy_load = 'false';

              if( strpos( $attr['slide_opt'], 'nav_button')!==FALSE) $navigation = 'true';

              if( strpos( $attr['slide_opt'], 'bullets')!==FALSE) $bullets = 'true';

              if( strpos( $attr['slide_opt'], 'autoplay')!==FALSE) $autoplay = 'true';

              if( strpos( $attr['slide_opt'], 'stop_hover')!==FALSE) $stop_hover = 'true';

              if( strpos( $attr['slide_opt'], 'lazy_effect')!==FALSE) $lazy_effect = "'fade'";

              if( strpos( $attr['slide_opt'], 'responsive')!==FALSE) $responsive = 'true';

              if( strpos( $attr['slide_opt'], 'lazy_load')!==FALSE) $lazy_load = 'true';

              if( $attr['slide_css_transition']=='none' ) $slider_effect = 'false';

              else $slider_effect = "'{$attr['slide_css_transition']}'";

                $final_str .= "<script>

                            		jQuery(document).ready(function() {

                            		  var owl = jQuery('#{$div_parent_id}');

                            		  owl.owlCarousel({

                                            singleItem : true,

                                            items : 1,

                                            itemsDesktop : false,

                                            itemsDesktopSmall : false,

                                            itemsTablet: false,

                                            itemsMobile : false,

                                            transitionStyle : $slider_effect,

                                            paginationSpeed : {$attr['slide_pagination_speed']},

                                            slideSpeed : {$attr['slide_speed']},

                                			navigation : $navigation,

                                			pagination : $bullets,

                                			autoPlay : $autoplay,

                                			stopOnHover : $stop_hover,

                                			responsive : $responsive,

                                			lazyEffect : $lazy_effect,

                                            lazyLoad : $lazy_load,

                            		  });

                            		});    		

                               </script>";

            }

        }

        $final_str .= "</div>";//end of ict_wrapp

        $final_str .= "</div>";//end of theme_n

        $final_str .= "</div>";//end of style_xxxxxx

        if(!isset($return_str) || $return_str!=true ) echo $final_str;

}

?>