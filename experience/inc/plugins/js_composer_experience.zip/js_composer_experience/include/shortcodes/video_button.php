<?php 
if ( class_exists( 'WPBakeryShortCode' ) ) {

	// ---------- VIDEO ---------- //

	class WPBakeryShortCode_experience_video_button extends WPBakeryShortCode {		
		
		/**
		 * @param $atts - shortcode attributes
		 * @param @content - shortcode content
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = null ) {
			
			$experience_vc_utilities = new jsComposerExperienceUtilities();
			
			$output = $css_class = $background = '';
		
			extract( shortcode_atts( array(
				'el_class' 			=> '',
				'css'				=> '',		
				'url'				=> '',
				'poster_image'		=> '',
				'orientation'		=> ''
			), $atts ) );
			
			$el_class = $this->getExtraClass( $el_class );			
			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $el_class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );
			
			if ( !empty( $poster_image ) ) {
			
				if ( !empty( $orientation ) ) {
					$orientation = 'poster-portrait';
				} else {
					$orientation = 'poster-landscape';
				}
				
				$poster_image_id = preg_replace( '/[^\d]/', '', $poster_image );
				$poster_image_id = wp_get_attachment_image_src( $poster_image_id, 'full' );
				if ( ! empty( $poster_image_id[0] ) ) {
					$poster_image_id = $poster_image_id[0];
				}
			
				$background = $experience_vc_utilities->experienceGetBackground( $poster_image_id, false, false, false, false, false, false );
			
			} else {
			
				$orientation = '';
				
			}
			
			$output .= '<div class="video_lightbox wpb_content_element '. esc_attr( $orientation .' '. $css_class ) .'">'.
							$background
							.'<div class="video-button-holder">
								<div class="video-button">
									<a class="fancybox" href="'. esc_url( $url ) .'">
										<span class="play"></span>
									</a>
								</div>
							</div>
						</div>';
		
			return $output;
			
		}
	
	}
	
}

/* --------- VIDEO BUTTON --------- */
	
vc_map( array(
	"base"			=> "experience_video_button",
	"name"			=> esc_html__( "Video Button", "js_composer_experience" ),
	"description"	=> esc_html__( "Play button that links to a video", "js_composer_experience" ),
	"class"			=> "",	
	"params"		=> array(
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label"	=> true
		),
		
		// Video URL
		array(
			"param_name"	=> "url",
			"heading"		=> esc_html__( "Video URL", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the URL to the video that will open when the play button is clicked.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label"	=> true
		),
		
		// CSS
		array(
			"type"		 => "css_editor",
			"heading"	 => esc_html__( "CSS", "js_composer_experience" ),
			"param_name" => "css",
			"group"		 => esc_html__( "Design options", "js_composer_experience" )
		),
		
		// Poster
		array(
			"param_name"	=> 'poster_image',
			"heading"		=> esc_html__( 'Poster Image', "js_composer_experience" ),
			"description"	=> esc_html__( "Select a poster image to display behind the video button.", "js_composer_experience" ),
			"type"			=> 'attach_image'
		),
		
		// orientation		
		array(
			"param_name"	=> "orientation",			
			"heading"		=> esc_html__( "Orientation", "js_composer_experience" ),
			"description"	=> esc_html__( "Choose the poster image orientation.", "js_composer_experience" ),
			"type"			=> "dropdown",
			'value'			=> array(
				esc_html__( 'Landscape', "js_composer_experience" )	=> '',
				esc_html__( 'Portrait', "js_composer_experience" )	=> 'portrait'
			)
		),
		
	)
	
) );