<?php

if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// add shortcode pricing plans
add_shortcode('pricing_plans', 'multipurpose_pricing_plans');
add_shortcode('pricing_plan', 'multipurpose_pricing_plan');
add_shortcode('price_item', 'multipurpose_price_item');
add_shortcode('strong', 'multipurpose_strong');

function multipurpose_pricing_plans($atts, $content = null) {
    $output = '<div class="pricing-plans">';
    $output .= do_shortcode($content);
    $output .= '</div>';
    return $output;
}

function multipurpose_pricing_plan($atts, $content = null) {
    if ($atts['selected'] == 'yes') {
        $output = '<div class="pricing-plan selected">';
    } else {
        $output = '<div class="pricing-plan">';
    }

    if (!empty($atts['title'])) {
        $output .= '<h2>' . $atts['title'] . '</h2>';
    }
    if (!empty($atts["subtitle"])) {
        $output .= '<p class="subtitle">' . $atts["subtitle"] . '</p>';
    }
    $output .= '<hr>';
	//in case price is with "," as separator
	$find = ',';
	$replace = '.';
	$price_to_numeric = str_replace($find, $replace, $atts['price']);
    if (isset($atts['price']) && !is_numeric($price_to_numeric) ) {
        $output .= '<p class="price free">' . $atts["price"] . '</p>';
    } else {
        if (!empty($atts["price"])) {
            $output .= '<p class="price">';
			
			if (isset($atts["before_price"])) {
				if($atts["before_price"] != '') {
					$output .= '<sup>'.$atts["before_price"].'</sup>';
				}
			} else {
				$output .= '<sup>$</sup>';
			}
			
			$output .= '<strong>' . $atts["price"] . '</strong>';
			
			if (isset($atts["after_price"])) {
				$output .= $atts["after_price"];
			} else {
				$output .= '/mo';
			}
			
			$output .= '</p>';
        }
    }

    $output .= do_shortcode($content);
    if (!empty($atts["button_link"])) {
        $output .='<p class="buy"><a href="' . $atts["button_link"] . '" class="button">';
    }
    if (!empty($atts["button_text"])) {
        $output .= $atts["button_text"];
    }
    $output .= '</a></p>';
    $output .= '</div>';
    
    return $output;
}

function multipurpose_price_item($atts, $content = null) {
    $output = '<li>';
    $output .= do_shortcode($content);
    $output .= '</li>';
    return $output;
}

function multipurpose_strong($atts, $content = null) {
    return '<strong>' . do_shortcode($content) . '</strong>';
}
