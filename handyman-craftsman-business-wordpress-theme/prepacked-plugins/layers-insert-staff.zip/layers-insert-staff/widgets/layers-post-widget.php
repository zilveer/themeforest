<?php
if (!class_exists('TL_Layers_Abstract_Widget')) { return; }

if (!class_exists('TL_Layers_Post_Widget')) {

    /**
     * @todo Apply CPT filter for Meta data. The idea is:
     *
     * every CPT adds his own filter e.g.
     *
     * apply_filters('tl/cpt_{CPT_ID}/get_meta'   , post_id);
     * apply_filters('tl/cpt_{CPT_ID}/filter_meta', meta_data);
     *
     * Class TL_Layers_Post_Widget
     */
    class TL_Layers_Post_Widget extends TL_Layers_Abstract_Widget
    {

        /**
         * Allowed meta keys for team CPT
         * @var
         */
        protected $_allowed_keys = array();

        /**
         * @var
         */
        public $grid_fields;

        /**
         * @var
         */
        public $defaults;


        /**
         *  Widget construction
         */
        public function __construct()
        {
            /**
             * Widget variables
             *
             * @param    string $widget_title Widget title
             * @param    string $widget_id Widget slug for use as an ID/classname
             * @param    string $post_type (optional) Post type for use in widget options
             * @param    string $taxonomy (optional) Taxonomy slug for use as an ID/classname
             * @param    array $checkboxes (optional) Array of checkbox names to be saved in this widget. Don't forget these please!
             */
            $this->widget_title = __('TL Post Grid', TL_INSERT_STAFF_SLUG);
            $this->widget_id = 'tl_post';
            $this->post_type = '';
            $this->taxonomy = '';
            $this->checkboxes = array(
                'gutter',
                'link_on_title',
                'show_date',
                'show_author',
                'show_meta',
                'show_media',
                'popup',
                'force_video',
                'stretch',
                'show_pagination',
                'top', 'left', 'bottom', 'right'
            );


            /* Widget settings. */
            $widget_ops = array('classname' => 'obox-layers-' . $this->widget_id . '-widget', 'description' => __('This widget is used to display your ', 'layerswp') . $this->widget_title . '.');

            /* Widget control settings. */
            $control_ops = array(
                'width' => LAYERS_WIDGET_WIDTH_SMALL,
                'height' => NULL,
                'id_base' => LAYERS_THEME_SLUG . '-widget-' . $this->widget_id
            );

            /* Create the widget. */
            parent::__construct(LAYERS_THEME_SLUG . '-widget-' . $this->widget_id,
                                $this->widget_title,
                                $widget_ops,
                                $control_ops);

            $this->_init();

            /* Add Filters */
            $this->_addFilters();
        }


        /**
         * Set defaults and so on
         */
        protected function _init()
        {
            /* Setup Widget Defaults */
            $this->defaults = array(

                'title' => __('POSTS', TL_INSERT_STAFF_SLUG),
                'excerpt' => 'Nostra ridiculus tellus meacenes eleifend at, conubia sollicitudin repodiandea sit, nostrud debitis dicta. Quasi preasesent porttitor tellus aliquid gravida mauris.',

                //Custom options
                'text_style' => 'regular',
                'excerpt_length' => 100,
                'link_on_title' => 'on',
                'show_meta' => 'on',
                'show_tax' => 'on',
                'show_author' => 'on',
                'show_date' => 'on',
                'show_media' => 'on',

                'page_id' => null,
                'button_label' => null,
                'posts_per_page' => '-1',
                'post_type' => 'post',

                'design' => array(
                    'layout' => 'layout-boxed',
                    'liststyle' => 'list-grid',
                    'columns' => '4',
                    'gutter' => 'on',

                    'shadow_length' => 6,
                    'shadow_blur' => 10,
                    'shadow_spread' => 0,
                    'shadow_color' => '#9b9b9b',

                    'background' => array(
                        'position' => 'center',
                        'repeat' => 'no-repeat',
                    ),
                    'fonts' => array(
                        'align' => 'text-center',
                        'size' => 'medium',
                        'color' => NULL,
                        'post-align' => 'text-left',
                        'post-size' => 'medium',
                    ),
                    'imageratios' => 'image-square',
                    'buttons' => array(
                        'label' => __('Read More', TL_INSERT_STAFF_SLUG),
                        'align' => 'text-center',
                        'buttons-size' => 'medium',
                    ),
                    'borders' => array(
                        'style' => 'solid',
                        'color' => layers_get_theme_mod('theme-secondary-color'),
                        'width' => 5
                    )
                )
            );

            $this->grid_fields = array(
                'title' => __('Title', TL_INSERT_STAFF_SLUG),
                'excerpt' => __('Excerpt', TL_INSERT_STAFF_SLUG),
                'metas' => __('Metas (Author, Date, Category/Tag)', TL_INSERT_STAFF_SLUG),
                'button' => __('Button', TL_INSERT_STAFF_SLUG),
            );
        }


        /**
         * Print administration form
         *
         * @param array $instance
         * @return string|void
         */
        public function form($instance)
        {
            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            $design_bar_components = apply_filters('layers_' . $this->widget_id . '_widget_design_bar_components', array(
                'layout',
                'columns',
                'liststyle',
                'display' => array(
                    'icon-css' => 'icon-display',
                    'label' => __('Display', 'layerswp'),
                    'elements' => array(
                        'text_style' => array(
                            'type' => 'select',
                            'name' => $this->get_layers_field_name('text_style'),
                            'id' => $this->get_layers_field_id('text_style'),
                            'value' => (isset($widget['text_style'])) ? $widget['text_style'] : NULL,
                            'label' => __('Title &amp; Excerpt Position', TL_INSERT_STAFF_SLUG),
                            'options' => array(
                                'regular' => __('Regular', 'layerswp'),
                                'overlay' => __('Overlay', 'layerswp')
                            )
                        ),
                        'link_on_title' => array(
                            'type' => 'checkbox',
                            'name' => $this->get_layers_field_name('link_on_title'),
                            'id' => $this->get_layers_field_id('link_on_title'),
                            'value' => (isset($widget['link_on_title'])) ? $widget['link_on_title'] : NULL,
                            'label' => __('Add link to a post title', TL_INSERT_STAFF_SLUG)
                        ),
                        'show_author' => array(
                            'type' => 'checkbox',
                            'name' => $this->get_layers_field_name('show_author'),
                            'id' => $this->get_layers_field_id('show_author'),
                            'value' => (isset($widget['show_author'])) ? $widget['show_author'] : NULL,
                            'label' => __('Show Author', TL_INSERT_STAFF_SLUG)
                        ),
                        'show_date' => array(
                            'type' => 'checkbox',
                            'name' => $this->get_layers_field_name('show_date'),
                            'id' => $this->get_layers_field_id('show_date'),
                            'value' => (isset($widget['show_date'])) ? $widget['show_date'] : NULL,
                            'label' => __('Show Date', TL_INSERT_STAFF_SLUG)
                        ),
                        'show_meta' => array(
                            'type' => 'checkbox',
                            'name' => $this->get_layers_field_name('show_meta'),
                            'id' => $this->get_layers_field_id('show_meta'),
                            'value' => (isset($widget['show_meta'])) ? $widget['show_meta'] : NULL,
                            'label' => __('Show Meta', TL_INSERT_STAFF_SLUG)
                        ),
                        'show_tax' => array(
                            'type' => 'checkbox',
                            'name' => $this->get_layers_field_name('show_tax'),
                            'id' => $this->get_layers_field_id('show_tax'),
                            'value' => (isset($widget['show_tax'])) ? $widget['show_tax'] : NULL,
                            'label' => __('Show Taxonomies (e.g. Categories)', TL_INSERT_STAFF_SLUG)
                        ),
                        'show_media' => array(
                            'type' => 'checkbox',
                            'name' => $this->get_layers_field_name('show_media'),
                            'id' => $this->get_layers_field_id('show_media'),
                            'value' => (isset($widget['show_media'])) ? $widget['show_media'] : NULL,
                            'label' => __('Show Featured Images/Videos', TL_INSERT_STAFF_SLUG)
                        ),
                        'force_video' => array(
                            'type' => 'checkbox',
                            'name' => $this->get_layers_field_name('force_video'),
                            'id' => $this->get_layers_field_id('force_video'),
                            'value' => (isset($widget['force_video'])) ? $widget['force_video'] : NULL,
                            'label' => __('Use Video instead of Featured Image if available', TL_INSERT_STAFF_SLUG)
                        ),
                        'excerpt_length' => array(
                            'type' => 'number',
                            'name' => $this->get_layers_field_name('excerpt_length'),
                            'id' => $this->get_layers_field_id('excerpt_length'),
                            'min' => 0,
                            'max' => 10000,
                            'value' => (isset($widget['excerpt_length'])) ? $widget['excerpt_length'] : NULL,
                            'label' => __('Post Excerpt Length', TL_INSERT_STAFF_SLUG)
                        ),
                        'popup' => array(
                            'type' => 'checkbox',
                            'name' => $this->get_layers_field_name('popup'),
                            'id' => $this->get_layers_field_id('popup'),
                            'value' => (isset($widget['popup'])) ? $widget['popup'] : NULL,
                            'label' => __('Show details in popup', TL_INSERT_STAFF_SLUG),
                        ),
                        'show_pagination' => array(
                            'type' => 'checkbox',
                            'name' => $this->get_layers_field_name('show_pagination'),
                            'id' => $this->get_layers_field_id('show_pagination'),
                            'value' => (isset($widget['show_pagination'])) ? $widget['show_pagination'] : NULL,
                            'label' => __('Show Pagination', TL_INSERT_STAFF_SLUG),
                        ),
                    )
                ),
                'featuredimage',
                'fonts',
                'buttons',
                'background',
                'advanced'
            ));

            //$design_bar_custom_components = ;

            if (TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_start('tl_sanitize_output');

            $this->design_bar(
                'side', // CSS Class Name
                array(
                    'name' => $this->get_layers_field_name('design'),
                    'id' => $this->get_layers_field_id('design'),
                    'widget_id' => $this->widget_id,
                ), // Widget Object
                $widget, // Widget Values
                $design_bar_components// Standard Components
            ); ?>
            <div class="layers-container-large layers-tl_column-widget tl-post-widget" id="layers-<?php echo esc_attr($this->widget_id);?>-widget-<?php echo $this->number; ?>">
                <?php $this->form_elements()->header(array(
                    'title' => 'Post',
                    'icon_class' => 'text'
                )); ?>
                <!-- Main Form -->
                <section class="layers-accordion-section layers-content">
                    <p class="layers-form-item">
                        <?php echo $this->form_elements()->input(
                            array(
                                'type' => 'text',
                                'name' => $this->get_layers_field_name('title'),
                                'id' => $this->get_layers_field_id('title'),
                                'placeholder' => __('Enter title here', 'layerswp'),
                                'value' => (isset($widget['title'])) ? $widget['title'] : NULL,
                                'class' => 'layers-text layers-large'
                            )
                        ); ?>
                    </p>

                    <p class="layers-form-item">
                        <?php echo $this->form_elements()->input(
                            array(
                                'type' => 'rte',
                                'name' => $this->get_layers_field_name('excerpt'),
                                'id' => $this->get_layers_field_id('excerpt'),
                                'placeholder' => __('Short Excerpt', 'layerswp'),
                                'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                'class' => 'layers-textarea layers-large'
                            )
                        ); ?>
                    </p>

                    <div class="layers-row">
                        <p class="layers-form-item layers-column layers-span-6">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('page_id')); ?>"><?php echo __('Button', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'select',
                                    'name' => $this->get_layers_field_name('page_id'),
                                    'id' => $this->get_layers_field_id('page_id'),
                                    'value' => (isset($widget['page_id'])) ? $widget['page_id'] : NULL,
                                    'options' => tl_get_posts(array('post_type' => 'page')),
                                    'placeholder' => __('-- None --', TL_INSERT_STAFF_SLUG),
                                    'class' => 'layers-select layers-large tl-select-post-item ',
                                )
                            ); ?>
                            <small class="layers-small-note"><?php _e('Adds button at the bottom of the widget.', TL_INSERT_STAFF_SLUG) ?></small>
                        </p>

                        <p class="layers-form-item layers-column layers-span-6">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('post_type')); ?>"><?php echo __('Available Post Types', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'select',
                                    'name' => $this->get_layers_field_name('post_type'),
                                    'id' => $this->get_layers_field_id('post_type'),
                                    'value' => (isset($widget['post_type'])) ? $widget['post_type'] : NULL,
                                    'options' => $this->filterPostTypesFields(tl_get_registered_post_types()),
                                    'placeholder' => __('-- Select Post Type --', TL_INSERT_STAFF_SLUG),
                                    'class' => 'layers-select layers-large tl-select-post-item tl-select-cpt',
                                )
                            ); ?>
                            <small class="layers-small-note"><?php _e('Select a type of posts you want to display.', TL_INSERT_STAFF_SLUG) ?></small>
                        </p>
                        <p class="layers-form-item layers-column layers-span-12">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('button_label')); ?>"><?php echo __('Button Label', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'text',
                                    'name' => $this->get_layers_field_name('button_label'),
                                    'id' => $this->get_layers_field_id('button_label'),
                                    'value' => (isset($widget['button_label'])) ? $widget['button_label'] : NULL,
                                )
                            ); ?>
                        </p>
                        <p>&nbsp;</p>
                    </div>
                    <ul id="<?php echo esc_attr($this->widget_id); ?>_list_<?php echo esc_attr($this->number); ?>" class="layers-accordions layers-accordions-sortable layers-sortable"
                        data-id_base="<?php echo $this->id_base; ?>">
                        <?php $this->column_item($widget); ?>
                    </ul>
                    <div class="layers-row">
                        <p class="layers-form-item layers-column layers-span-6">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('posts_per_page')); ?>"><?php echo __('Number of Items to show', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'number',
                                    'name' => $this->get_layers_field_name('posts_per_page'),
                                    'id' => $this->get_layers_field_id('posts_per_page'),
                                    'value' => (isset($widget['posts_per_page'])) ? $widget['posts_per_page'] : NULL,
                                    'min' => '-1',
                                    'max' => '100'
                                )
                            ); ?>
                            <small class="layers-small-note"><?php _e('Enter -1 to list all posts.', TL_INSERT_STAFF_SLUG)?></small>
                        </p>
                        <p class="layers-form-item layers-column layers-span-6">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('sort_by')); ?>"><?php echo __('Sort Items By', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'select',
                                    'name' => $this->get_layers_field_name('sort_by'),
                                    'id' => $this->get_layers_field_id('sort_by'),
                                    'placeholder' => __('Sort By', 'layerswp'),
                                    'value' => (isset($widget['sort_by'])) ? $widget['sort_by'] : NULL,
                                    'class' => 'layers-large',
                                    'options' => array(
                                        '{"orderby":"title","order":"asc"}' => 'By Title (A-Z)',
                                        '{"orderby":"title","order":"desc"}' => 'By Title (Z-A)',
                                        '{"orderby":"date","order":"desc"}' => 'Newest First',
                                        '{"orderby":"date","order":"asc"}' => 'Oldest First',
                                        '{"orderby":"menu_order","order":"desc"}' => 'Custom Order',
                                        '{"orderby":"rand","order":"desc"}' => 'Random',
                                    )
                                )
                            ); ?>
                        </p>
                    </div>
                    <p class="layers-form-item">
                        <label for="<?php echo esc_attr($this->get_layers_field_id('posts_include')); ?>"><?php echo __('List of posts to include.', TL_INSERT_STAFF_SLUG); ?></label>
                        <?php echo $this->form_elements()->input(array(
                            'type' => 'text',
                            'name' => $this->get_layers_field_name('posts_include'),
                            'id' => $this->get_layers_field_id('posts_include'),
                            'value' => (isset($widget['posts_include'])) ? $widget['posts_include'] : NULL,
                        )); ?>
                        <small class="layers-small-note"><?php _e('Enter a list of post separated by commas. E.g. 33,1,43,7', TL_INSERT_STAFF_SLUG)?></small>
                    </p>
                </section>
                <!-- Main Form End -->
            </div>
            <?php
            if (TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_end_flush();
        }


        /**
         * Helper method. Renders column in administation panel.
         *
         * @param null $instance
         */
        public function column_item($instance = NULL)
        {
            // $instance Defaults
            $instance_defaults = array();

            // Parse $instance
            $instance = wp_parse_args($instance, $instance_defaults);

            $available_fields = $this->_getAvailableGridFields($instance);
            ?>
            <li class="layers-accordion-item">
                <a class="layers-accordion-title">
						<span>
							<?php _e('Post Grid Settings', TL_INSERT_STAFF_SLUG); ?>
                            <span class="layers-detail"></span>
						</span>
                </a>
                <small class="layers-small-note"><?php _e('Drag & drop available elements to particular containers and build POST grid.', TL_INSERT_STAFF_SLUG) ?></small>
                <section class="layers-accordion-section layers-content">
                    <div class="post-grid layers-row ui-widget ui-helper-clearfix">
                        <div class="layers-column layers-span-6">
                            <div class="layers-form-item">
                                <label><?php _e('Available Fields', TL_INSERT_STAFF_SLUG) ?></label>
                                <ul id="available-items-<?php echo esc_attr($this->id) ?>" class="available-items ui-helper-reset ui-helper-clearfix">
                                    <?php $this->_adminRenderGridContent('all', $instance)?>
                                </ul>
                            </div>
                        </div>
                        <div class="layers-column layers-span-6">
                            <div class="layers-form-item">
                                <label><?php _e('Grid Containers', TL_INSERT_STAFF_SLUG)?></label>

                                <div class="destination-containers">
                                    <label><?php _e('Header Grid', TL_INSERT_STAFF_SLUG) ?></label>
                                    <ul id="header-grid-<?php echo esc_attr($this->id) ?>" data-position="header" class="droptrue header-grid">
                                        <?php $this->_adminRenderGridContent('header', $instance)?>
                                    </ul>
                                    <label><?php _e('Over Image Grid', TL_INSERT_STAFF_SLUG) ?></label>
                                    <ul id="media-grid-<?php echo esc_attr($this->id) ?>" data-position="media" class="droptrue media-grid">
                                        <?php $this->_adminRenderGridContent('media', $instance)?>
                                    </ul>
                                    <label><?php _e('Body Grid', TL_INSERT_STAFF_SLUG) ?></label>
                                    <ul id="body-grid-<?php echo esc_attr($this->id) ?>" data-position="body" class="droptrue body-grid">
                                        <?php $this->_adminRenderGridContent('body', $instance)?>
                                    </ul>
                                    <label><?php _e('Footer Grid', TL_INSERT_STAFF_SLUG) ?></label>
                                    <ul id="footer-grid-<?php echo esc_attr($this->id) ?>" data-position="footer" class="droptrue footer-grid">
                                        <?php $this->_adminRenderGridContent('footer', $instance)?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <small class="layers-small-note">Use BODY GRID CONTAINER for "overlay"</small>
                    </div>
                </section>
                <?php
                echo $this->form_elements()->input(array(
                    'type' => 'hidden',
                    'name' => $this->get_layers_field_name('header_items'),
                    'id' => $this->get_layers_field_id('header_items'),
                    'value' => (isset($instance['header_items'])) ? esc_attr($instance['header_items']) : NULL,
                ));
                echo $this->form_elements()->input(array(
                    'type' => 'hidden',
                    'name' => $this->get_layers_field_name('media_items'),
                    'id' => $this->get_layers_field_id('media_items'),
                    'value' => (isset($instance['media_items'])) ? esc_attr($instance['media_items']) : NULL,
                ));
                echo $this->form_elements()->input(array(
                    'type' => 'hidden',
                    'name' => $this->get_layers_field_name('body_items'),
                    'id' => $this->get_layers_field_id('body_items'),
                    'value' => (isset($instance['body_items'])) ? esc_attr($instance['body_items']) : NULL,
                ));
                echo $this->form_elements()->input(array(
                    'type' => 'hidden',
                    'name' => $this->get_layers_field_name('footer_items'),
                    'id' => $this->get_layers_field_id('footer_items'),
                    'value' => (isset($instance['footer_items'])) ? esc_attr($instance['footer_items']) : NULL,
                )); ?>
            </li>
        <?php }


        /**
         * Print Widget
         *
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        {
            $this->backup_inline_css();

            // Turn $args array into variables.
            extract($args);

            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            // Enqueue Masonry if need be
            if ('list-masonry' == $this->check_and_return($widget, 'design', 'liststyle')) $this->enqueue_masonry();

            $this->_set_color_defaults($widget_id);

            /* Section styles */
            $this->_apply_widget_section_styling($widget_id, $widget);


            // Set the span class for post column
            if ('list-list' == $widget['design']['liststyle']) {
                $col_count = 1;
                $span_class = 'span-12';
            } else {
                $col_count = str_ireplace('columns-', '', $widget['design']['columns']);
                $span_class = 'span-' . (12 / $col_count);
            }


            // Set Image Sizes

            global $use_image_ratio;
            if (isset($widget['design']['imageratios'])) {

                // Translate Image Ratio
                $image_ratio = layers_translate_image_ratios($widget['design']['imageratios']);

                if ('layout-boxed' == $this->check_and_return($widget, 'design', 'layout') && $col_count > 2) {
                    $use_image_ratio = $image_ratio . '-medium';
                } elseif ('layout-boxed' != $this->check_and_return($widget, 'design', 'layout') && $col_count > 3) {
                    $use_image_ratio = $image_ratio . '-medium';
                } else {
                    $use_image_ratio = $image_ratio . '-large';
                }
            } else {
                $use_image_ratio = 'large';
            }

            // Create Post Query
            $post_query = $this->_create_query_post($widget);


            // Set the meta to display
            global $layers_post_meta_to_display;
            $layers_post_meta_to_display = array();
            if (isset($widget['show_date'])) $layers_post_meta_to_display[] = 'date';
            if (isset($widget['show_author'])) $layers_post_meta_to_display[] = 'author';
            if (isset($widget['show_meta'])) {
                $layers_post_meta_to_display[] = 'tags';
                //$layers_post_meta_to_display[] = 'categories';
            }
            if (isset($widget['show_tax'])) $layers_post_meta_to_display[] = 'categories';


            /**
             * Generate the widget container class
             */
            $widget_container_class = array();
            $widget_container_class[] = 'widget content-vertical-massive';
            $widget_container_class[] = 'tl-post';
            $widget_container_class[] = $this->check_and_return($widget, 'design', 'advanced', 'customclass');
            $widget_container_class[] = $this->get_widget_spacing_class($widget);
            $widget_container_class = implode(' ', apply_filters('layers_'.$this->widget_id.'_widget_container_class', $widget_container_class, $this, $widget)); ?>


            <div class="<?php echo $widget_container_class; ?>" id="<?php echo $widget_id; ?>">
                <?php
                    echo $this->custom_anchor( $widget );
                    do_action( 'layers_before_'.$this->widget_id.'_widget_inner', $this, $widget );
                ?>
                <?php if ('' != $this->check_and_return($widget, 'title') || '' != $this->check_and_return($widget, 'excerpt')) { ?>
                    <div class="container clearfix">
                        <?php
                        /**
                         * Generate the Section Title Classes
                         */
                        $section_title_class = array();
                        $section_title_class[] = 'section-title clearfix';
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'size');
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'align');
                        $section_title_class = implode(' ', $section_title_class); ?>
                        <div class="<?php echo $section_title_class; ?>">
                            <?php if ('' != $widget['title']) { ?>
                                <h3 class="heading"><?php echo apply_filters('tl_colorize_title_' . $this->widget_id, esc_html($widget['title'])); ?></h3>
                            <?php } ?>
                            <?php if ('' != $widget['excerpt']) { ?>
                                <div class="excerpt"><?php echo $widget['excerpt']; ?></div>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>
                <div class="grid <?php echo $this->get_widget_layout_class($widget); ?> <?php echo $this->check_and_return($widget, 'design', 'liststyle'); ?>">
                    <?php

                    /**
                     * Apply inline CSS to particular elements
                     */
                    $this->_apply_column_styles($widget_id, $widget);

                    if ($post_query->have_posts()):

                        /**
                         * Post Item layout
                         */
                        $post_item_layout = array();
                        $post_item_layout['header'] = $this->check_and_return($widget, 'header_items') ? json_decode($widget['header_items']) : array();
                        $post_item_layout['media'] = $this->check_and_return($widget, 'media_items') ? json_decode($widget['media_items']) : array();
                        $post_item_layout['body'] = $this->check_and_return($widget, 'body_items') ? json_decode($widget['body_items']) : array();
                        $post_item_layout['footer'] = $this->check_and_return($widget, 'footer_items') ? json_decode($widget['footer_items']) : array();

                        /**
                         * Set Column CSS for grid layout
                         */
                        $post_column_class = array();
                        $post_column_class[] = 'layers-masonry-column thumbnail';
                        $post_column_class[] = ('list-masonry' == $this->check_and_return($widget, 'design', 'liststyle') ? 'no-gutter' : '');
                        $post_column_class[] = 'column' . ('on' != $this->check_and_return($widget, 'design', 'gutter') ? '-flush' : '');
                        $post_column_class[] = $span_class;
                        $post_column_class[] = ('overlay' == $this->check_and_return($widget, 'text_style') ? 'with-overlay' : '');
                        $post_column_class = implode(' ', $post_column_class);

                        while ($post_query->have_posts()):  $post_query->the_post();

                            if ('list-list' == $widget['design']['liststyle']): // Create a list
                                ?>
                                <article id="post-<?php the_ID(); ?>"
                                         class="grid push-bottom-large <?php echo($this->check_and_return($widget, 'design', 'background', 'column-color') ? 'content' : '')?>">

                                    <!-- this was a spot -->

                                    <?php // Layers Featured Media

                                    if (isset($widget['show_media'])) {
                                        echo tl_post_featured_media(array(
                                            'wrap' => 'div',
                                            'wrap_class' => 'thumbnail-media span-5 column' . ((isset($widget['design']['imageratios']) && 'image-round' == $widget['design']['imageratios']) ? ' image-rounded' : ''),
                                            'size' => $use_image_ratio,
                                            'force_vid' => $this->check_and_return($widget, 'force_video') ? true : false,
                                            'use_pretty_photo' => true
                                        ));
                                    } // if Show Media
                                    ?>
                                    <div class="column span-7 <?php echo esc_attr($this->check_and_return($widget, 'design', 'fonts', 'post-align'))?>">
                                        <header class="article-title <?php echo esc_attr($this->check_and_return($widget, 'design', 'fonts', 'post-size'))?>">
                                            <?php if ($this->check_and_return($widget, 'link_on_title')) :
                                                $popup = '';
                                                if ($this->check_and_return($widget, 'popup')) {
                                                    $popup = 'data-title = "' . get_the_title_rss() . '" data-id="' . get_the_ID() . '"';
                                                }
                                                ?>
                                                <h3 class="heading"><a <?php echo $popup; ?> class="<?php echo(isset($widget['popup']) ? 'ajax-popup-link' : '')?>"
                                                                                             href="<?php the_permalink(); ?>" title="<?php the_title_rss()?>"><?php the_title(); ?></a></h3>
                                            <?php else: ?>
                                                <h3 class="heading"><?php the_title(); ?></h3>
                                            <?php endif; ?>
                                        </header>
                                        <?php
                                        if (isset($widget['excerpt_length']) && '' == $widget['excerpt_length']) {
                                            echo '<div class="copy push-bottom ' . esc_attr($this->check_and_return($widget, 'design', 'fonts', 'post-size')) . '">';
                                            the_content();
                                            echo '</div>';
                                        } else if (isset($widget['excerpt_length']) && 0 != $widget['excerpt_length'] && strlen(get_the_excerpt()) > $widget['excerpt_length']) {
                                            echo '<div class="copy push-bottom ' . esc_attr($this->check_and_return($widget, 'design', 'fonts', 'post-size')) . '">' . substr(get_the_excerpt(), 0, $widget['excerpt_length']) . '&#8230;</div>';
                                        } else if ('' != get_the_excerpt()) {
                                            echo '<div class="copy push-bottom ' . esc_attr($this->check_and_return($widget, 'design', 'fonts', 'post-size')) . '">' . get_the_excerpt() . '</div>';
                                        }

                                        /**
                                         * Meta data
                                         */
                                        if (!empty($layers_post_meta_to_display)) {
                                            tl_layers_post_meta(get_the_ID(), $layers_post_meta_to_display, 'footer', 'meta-info push-bottom ');
                                        }?>
                                        <?php
                                        /*
                                         * Button
                                        */
                                        if ($this->check_and_return($widget, 'design', 'buttons', 'label')):
                                            $popup = '';
                                            if ($this->check_and_return($widget, 'popup')) {
                                                $popup = 'data-title = "' . get_the_title_rss() . '" data-id="' . get_the_ID() . '"';
                                            }


                                            $btn_classes   = array();
                                            $btn_classes[] = 'button';
                                            $btn_classes[] = isset($widget['popup']) ? 'ajax-popup-link' : '';
                                            $btn_classes[] = 'btn-' . $this->check_and_return($widget, 'design', 'buttons', 'buttons-size');
                                            $btn_classes[] = $this->check_and_return($widget, 'design', 'buttons', 'animation');
                                            $btn_classes = implode(' ', $btn_classes);

                                            ?>
                                            <div class="btn-wrapper <?php echo esc_attr($widget['design']['buttons']['align'])?>">
                                                <a <?php echo $popup; ?> href="<?php the_permalink() ?>" title="<?php the_title_rss()?>"
                                                                         class="<?php echo esc_attr($btn_classes)?>">
                                                    <?php echo esc_html($this->check_and_return($widget, 'design', 'buttons', 'label')) ?>
                                                </a>
                                            </div>
                                        <?php endif ?>

                                    </div>

                                </article>
                            <?php else: // create a grid ?>
                                <article
                                    class="<?php echo esc_attr($this->check_and_return($widget, 'design', 'fonts', 'post-align')) ?> <?php echo $post_column_class; ?> <?php echo esc_attr($this->check_and_return($widget, 'design', 'fonts', 'post-size')) ?>"
                                    data-cols="<?php echo $col_count; ?>">
                                    <?php

                                    $this->_render_column_part('header', $post_item_layout, $widget);

                                    if (isset($widget['show_media'])) { ?>
                                        <div
                                            class="thumbnail-media <?php echo((isset($widget['design']['imageratios']) && 'image-round' == $widget['design']['imageratios']) ? ' image-rounded' : '') ?>">
                                            <?php
                                            echo tl_post_featured_media([
                                                'size' => $use_image_ratio,
                                                'force_vid' => $this->check_and_return($widget, 'force_video') ? true : false,
                                                'use_pretty_photo' => true
                                            ]);
                                            $this->_render_column_part('media', $post_item_layout, $widget);
                                            ?>
                                        </div>
                                    <?php }

                                    $this->_render_column_part('body', $post_item_layout, $widget);
                                    $this->_render_column_part('footer', $post_item_layout, $widget);
                                    ?>
                                </article>
                            <?php endif;
                        endwhile; // while have posts
                    endif; // if have posts
                    ?>
                </div>
                <?php if (isset($widget['show_pagination'])) { ?>
                    <div class="grid products container list-grid">
                        <?php layers_pagination(array('query' => $post_query), 'div', 'pagination grid span-12 text-center'); ?>
                    </div>
                <?php } ?>
                <?php if ($this->check_and_return($widget, 'page_id')):

                    $button_label = ($this->check_and_return($widget, 'button_label') ? $this->check_and_return($widget, 'button_label') : get_the_title($this->check_and_return($widget, 'page_id')));

                    ?>
                    <div class="container aligncenter">
                        <a href="<?php echo get_the_permalink($this->check_and_return($widget, 'page_id')) ?>" class="hvr-sweep-to-top goto-section-page button large">
                            <?php echo esc_html($button_label); ?><i class="icon-ti-angle-double-right"></i>
                        </a>
                    </div>
                <?php endif;

                // Reset WP_Query
                wp_reset_postdata();

                do_action( 'layers_after_' . $this->id . '_widget_inner', $this, $widget );

                // Print the Inline Styles for this Widget
                $this->print_inline_css();

                // Apply the advanced widget styling
                $this->apply_widget_advanced_styling($widget_id, $widget);
                ?>
            </div>
            <?php if ('list-masonry' == $this->check_and_return($widget, 'design', 'liststyle')) { ?>
            <script type="text/javascript">
                "use strict";
                jQuery(function ($) {
                    layers_masonry_settings['<?php echo $widget_id; ?>'] = [{
                        itemSelector: '.layers-masonry-column',
                        layoutMode: 'masonry',
                        gutter: <?php echo ( isset( $widget['design'][ 'gutter' ] ) ? 20 : 0 ); ?>
                    }];
                    $('#<?php echo $widget_id; ?>').find('.list-masonry').layers_masonry(layers_masonry_settings['<?php echo $widget_id; ?>'][0]);
                });
            </script>
        <?php } // masonry trigger
        }


        /**
         * @param $position
         * @param $widget
         */
        protected function _render_column_part($position, $layout, $widget)
        {
            if (!empty($layout[$position])):?>
                <div class="post-<?php echo esc_attr($position)?>">
                    <?php if ($position == 'body') : ?>
                    <div class="thumbnail-body">
                        <div class="overlay">
                            <?php endif; ?>
                            <?php
                            foreach ($layout[$position] as $b):
                                switch ($b) {
                                    case 'title': ?>
                                        <header class="article-title">
                                            <?php if ($this->check_and_return($widget, 'link_on_title')) :
                                                $popup = '';
                                                if ($this->check_and_return($widget, 'popup')) {
                                                    $popup = 'data-title = "' . get_the_title_rss() . '" data-id="' . get_the_ID() . '"';
                                                }
                                                ?>
                                                <h3 class="heading"><a <?php echo $popup; ?> class="<?php echo(isset($widget['popup']) ? 'ajax-popup-link' : '')?>"
                                                                                             href="<?php the_permalink(); ?>" title="<?php the_title_rss()?>"><?php the_title(); ?></a></h3>
                                            <?php else: ?>
                                                <h3 class="heading"><?php the_title(); ?></h3>
                                            <?php endif; ?>
                                        </header>
                                        <?php
                                        break;
                                    case 'metas':
                                        global $layers_post_meta_to_display;
                                        tl_layers_post_meta(get_the_ID(), $layers_post_meta_to_display, 'footer', 'meta-info push-bottom');
                                        break;
                                    case 'button':
                                        if ($this->check_and_return($widget, 'design', 'buttons', 'label')):
                                            $popup = '';
                                            if ($this->check_and_return($widget, 'popup')) {
                                                $popup = 'data-title = "' . get_the_title_rss() . '" data-id="' . get_the_ID() . '"';
                                            }

                                            $btn_classes   = array();
                                            $btn_classes[] = 'button';
                                            $btn_classes[] = isset($widget['popup']) ? 'ajax-popup-link' : '';
                                            $btn_classes[] = 'btn-' . $this->check_and_return($widget, 'design', 'buttons', 'buttons-size');
                                            $btn_classes[] = $this->check_and_return($widget, 'design', 'buttons', 'animation');
                                            $btn_classes = implode(' ', $btn_classes);

                                            ?>
                                            <div class="btn-wrapper <?php echo esc_attr($widget['design']['buttons']['align'])?>">
                                                <a <?php echo $popup; ?> href="<?php the_permalink() ?>" title="<?php the_title_rss()?>"
                                                                         class="<?php echo esc_attr($btn_classes) ?>">
                                                    <?php echo esc_html($this->check_and_return($widget, 'design', 'buttons', 'label')) ?>
                                                </a>
                                            </div>
                                        <?php endif;
                                        break;
                                    case 'custom_fields':
                                        break;
                                    case 'excerpt':
                                        if (isset($widget['excerpt_length']) && '' == $widget['excerpt_length']) {
                                            echo '<div class="excerpt">';
                                            the_content();
                                            echo '</div>';
                                        } else if (isset($widget['excerpt_length']) && 0 != $widget['excerpt_length'] && strlen(get_the_excerpt()) > $widget['excerpt_length']) {
                                            echo '<div class="excerpt">' . substr(get_the_excerpt(), 0, $widget['excerpt_length']) . '&#8230;</div>';
                                        } else if ('' != get_the_excerpt()) {
                                            echo '<div class="excerpt">' . get_the_excerpt() . '</div>';
                                        }
                                        break;
                                }
                            endforeach;
                            ?>
                            <?php if ($position == 'body') : ?>
                        </div>
                        <!-- .overlay -->
                    </div>
                    <!-- .thumbnail-body -->
                <?php endif; ?>
                </div>
            <?php endif;
        }


        /**
         * @param $widget_id
         * @param $widget
         */
        protected function _apply_column_styles($widget_id, $widget)
        {
            // Column Background color
            if ($this->check_and_return($widget, 'design', 'background', 'column-color')) {
                $this->inline_css .= layers_inline_styles(array('selectors' => array('#' . $widget_id . ' article'), 'css' => array('background-color' => $widget['design']['background']['column-color'])));
            }

            // Image borders
            if ($this->check_and_return($widget, 'design', 'borders', 'top') ||
                $this->check_and_return($widget, 'design', 'borders', 'bottom') ||
                $this->check_and_return($widget, 'design', 'borders', 'left') ||
                $this->check_and_return($widget, 'design', 'borders', 'right')
            ) {
                foreach (array('top', 'bottom', 'left', 'right') as $pos) {
                    if ($this->check_and_return($widget, 'design', 'borders', $pos)) {
                        $image_borders['border-' . $pos] = $this->check_and_return($widget, 'design', 'borders', 'width') . 'px ' . $this->check_and_return($widget, 'design', 'borders', 'style') . ' ' . $this->check_and_return($widget, 'design', 'borders', 'color');
                    }
                }
                $this->inline_css .= layers_inline_styles(array('selectors' => array('#' . $widget_id . ' .thumbnail-media'), 'css' => $image_borders));
            }

            // Column sections background
            foreach (array('header', 'media', 'body', 'footer') as $s) {
                if ($this->check_and_return($widget, $s . '_items') && $this->check_and_return($widget, $s . '_items') != '[]') {
                    if ($this->check_and_return($widget, 'design', 'background', $s . '-color')) {
                        $bg_color = ($s == 'media') ? 'rgba(' . apply_filters('tl/hex2rgba', $widget['design']['background'][$s . '-color'], .5, true) . ')' : $widget['design']['background'][$s . '-color'];

                        $this->inline_css .= layers_inline_styles(array('selectors' => array('#' . $widget_id . ' .post-' . $s),
                            'css' => array('background-color' => $bg_color)));
                    }
                }
            }


            // Column Shadow

            // @todo test with gutter
            if ('on' == $this->check_and_return($widget, 'design', 'shadow_show') &&
                'on' == $this->check_and_return($widget, 'design', 'gutter')
            ) {

                $l      = $widget['design']['shadow_length'] . 'px';
                $blur   = $widget['design']['shadow_blur'] . 'px';
                $spread = $widget['design']['shadow_spread'] . 'px';
                $color  = $widget['design']['shadow_color'];

                $this->inline_css .= layers_inline_styles(array('selectors' => array('#' . $widget_id . ' article'),
                    'css' => array(
                        '-webkit-box-shadow' => $l . ' ' . $l . ' ' . $blur . ' ' . $spread . ' ' . $color,
                        '-moz-box-shadow' => $l . ' ' . $l . ' ' . $blur . ' ' . $spread . ' ' . $color,
                        'box-shadow' => $l . ' ' . $l . ' ' . $blur . ' ' . $spread . ' ' . $color,
                    )
                ));
            }

            if ($this->check_and_return($widget, 'design', 'fonts', 'post-meta-color')) {
                $this->inline_css .= layers_inline_styles(array('selectors' => array('#' . $widget_id . ' .meta-info a', '#' . $widget_id . ' .meta-info .meta-item'),
                    'css' => array('color' => $widget['design']['fonts']['post-meta-color'])));
            }

            if ($this->check_and_return($widget, 'design', 'fonts', 'post-meta-color-hover')) {
                $this->inline_css .= layers_inline_styles(array('selectors' => array('#' . $widget_id . ' .meta-info a:hover'),
                                      'css' => array('color' => $widget['design']['fonts']['post-meta-color-hover'])));
            }

            // Column titles colors
            $this->inline_css .= layers_inline_styles(array('selectors' => array('#' . $widget_id . ' .article-title .heading a', '#' . $widget_id . ' .article-title .heading'),
                'css' => $this->prepare_inline_styles($widget, array('color' => array('design', 'fonts', 'post-title-color')))));

            $this->inline_css .= layers_inline_styles(array('selectors' => array('#' . $widget_id . ' .article-title .heading a:hover'),
                'css' => $this->prepare_inline_styles($widget, array('color' => array('design', 'fonts', 'post-title-color-hover')))));


            //Column Excerpt color
            $this->inline_css .= layers_inline_styles(array('selectors' => array('#' . $widget_id . ' article .excerpt'),
                'css' => $this->prepare_inline_styles($widget, array('color' => array('design', 'fonts', 'post-excerpt-color'))))
            );

            $this->_apply_button_styling($widget_id, $widget);
        }



        /**
         * @param $position
         * @param $widget
         */
        protected function _adminRenderGridContent($position, $widget)
        {
            if ($position == 'all') {
                $items = array_keys($this->grid_fields);
            } else {
                $items = isset($widget[$position . '_items']) ? json_decode($widget[$position . '_items']) : array();
            }

            if (is_array($items)) {
                foreach ($items as $v) { ?>
                    <li data-item="<?php echo esc_attr($v) ?>" id="<?php echo esc_attr($this->id) ?>_<?php echo esc_attr($v) ?>">
                        <span><?php echo esc_html($this->grid_fields[$v]) ?></span><a href="#" class="remove-btn icon-trash"></a>
                    </li>
                <?php }
            }
        }


        /**
         * @param $post_id
         * @param $key
         * @return array|mixed|string
         */
        protected function _getMemberMeta($post_id, $key)
        {
            $return = array();
            if ($post_id == 0) return $return;
            $meta = tl_get_metadata($post_id, $key);

            foreach ($this->_allowed_keys as $k) {
                $v = $this->check_and_return($meta, $k);
                if ($v && trim($v) != '') $return[$k] = $v;
            }
            return $return;
        }


        /**
         * Register all required filters
         */
        protected function _addFilters()
        {
            add_filter('tl_colorize_title_' . $this->widget_id, 'tl_colorize_title', 10, 2);

            add_filter('tl/layers/background_component/' . $this->widget_id . '/args'   , array($this, 'customizeBackgroundComponent'), 10, 4);
            add_filter('tl/layers/fonts_component/' . $this->widget_id . '/args'        , array($this, 'customizeFontsComponent'), 10, 4);
            add_filter('tl/layers/featuredimage_component/' . $this->widget_id . '/args', array($this, 'customizeFeaturedImageComponent'), 10, 4);
            add_filter('tl/layers/buttons_component/' . $this->widget_id . '/args'      , array($this, 'customizeButtonsComponent'), 10, 4);
            add_filter('tl/layers/columns_component/' . $this->widget_id . '/args'      , array($this, 'customizeColumnsComponent'), 10, 4);
        }


        /**
         * @param $widget_container_id
         */
        protected function _set_color_defaults($widget_container_id)
        {
            //$colors = \Handyman\Core\Colors::single();
        }


        /**
         * Customize built in fonts tools in top(column) and sidebar
         *
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeFontsComponent($args, $position, $widget, $values)
        {
            if ($position == 'side') {
                $args['elements']['fonts-color']['label'] = __('Section Title Color', TL_INSERT_STAFF_SLUG);
                $args['elements']['fonts-excerpt-color'] = array(
                    'type' => 'color',
                    'label' => 'Section Excerpt Color',
                    'name' => $widget['name'] . '[fonts][excerpt-color]',
                    'id' => $widget['id'] . '-fonts-excerpt-color',
                    'value' => isset($values['fonts']['excerpt-color']) ? $values['fonts']['excerpt-color'] : null,
                );

                $args['elements']['fonts-grid-heading'] = array(
                    'type' => 'layers-heading',
                    'label' => __('Grid Item Options', TL_INSERT_STAFF_SLUG),
                );

                // Post text alignment
                $args['elements']['fonts-post-align'] = array(
                    'type' => 'select-icons',
                    'label' => __('Post Text alignment', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[fonts][post-align]',
                    'id' => $widget['id'] . '-fonts-post-align',
                    'value' => isset($values['fonts']['post-align']) ? $values['fonts']['post-align'] : null,
                    'options' => array(
                        'text-left' => __('Left', TL_INSERT_STAFF_SLUG),
                        'text-center' => __('Center', TL_INSERT_STAFF_SLUG),
                        'text-right' => __('Right', TL_INSERT_STAFF_SLUG),
                    ),
                    'wrapper' => 'div',
                    'wrapper-class' => 'layers-icon-group'
                );

                // Post text size
                $args['elements']['fonts-post-size'] = array(
                    'type' => 'select',
                    'label' => __('Post Text Size', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[fonts][post-size]',
                    'value' => isset($values['fonts']['post-size']) ? $values['fonts']['post-size'] : null,
                    'options' => array(
                        'small' => __('Small', TL_INSERT_STAFF_SLUG),
                        'medium' => __('Medium', TL_INSERT_STAFF_SLUG),
                        'large' => __('Large', TL_INSERT_STAFF_SLUG),
                    )
                );

                // Post title
                $args['elements']['fonts-post-title-color'] = array(
                    'type' => 'color',
                    'label' => __('Post Title Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[fonts][post-title-color]',
                    'id' => $widget['id'] . '-fonts-post-title-color',
                    'value' => isset($values['fonts']['post-title-color']) ? $values['fonts']['post-title-color'] : null,
                );
                $args['elements']['fonts-post-title-color-hover'] = array(
                    'type' => 'color',
                    'label' => __('Post Title Hover Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[fonts][post-title-color-hover]',
                    'id' => $widget['id'] . '-fonts-post-title-color-hover',
                    'value' => isset($values['fonts']['post-title-color-hover']) ? $values['fonts']['post-title-color-hover'] : null,
                );

                // Excerpt alignment
                $args['elements']['fonts-post-excerpt-color'] = array(
                    'type' => 'color',
                    'label' => __('Post Excerpt Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[fonts][post-excerpt-color]',
                    'id' => $widget['id'] . '-fonts-post-excerpt-color',
                    'value' => isset($values['fonts']['post-excerpt-color']) ? $values['fonts']['post-excerpt-color'] : null,
                );

                // Tag & Category
                $args['elements']['fonts-post-meta-color'] = array(
                    'type' => 'color',
                    'label' => __('Post Meta Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[fonts][post-meta-color]',
                    'id' => $widget['id'] . '-fonts-post-meta-color',
                    'value' => isset($values['fonts']['post-meta-color']) ? $values['fonts']['post-meta-color'] : null,
                );
                $args['elements']['fonts-post-meta-color-hover'] = array(
                    'type' => 'color',
                    'label' => __('Post Meta Hover Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[fonts][post-meta-color-hover]',
                    'id' => $widget['id'] . '-fonts-post-meta-color-hover',
                    'value' => isset($values['fonts']['post-meta-color-hover']) ? $values['fonts']['post-meta-color-hover'] : null,
                );
            }
            return $args;
        }


        /**
         * Customize built in background tools
         *
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeBackgroundComponent($args, $position, $widget, $values)
        {
            unset($args['elements']['background-darken']);

            if ($position == 'side') {

                $args['elements']['background-grid-heading'] = array(
                    'type' => 'layers-heading',
                    'label' => __('Column Item Background Options', TL_INSERT_STAFF_SLUG),
                );

                $args['elements']['background-column-color'] = array(
                    'type' => 'color',
                    'label' => __('Column Background Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[background][column-color]',
                    'id' => $widget['id'] . '-background-column-color',
                    'value' => isset($values['background']['column-color']) ? $values['background']['column-color'] : null,
                );

                $args['elements']['background-header-color'] = array(
                    'type' => 'color',
                    'label' => __('Item\'s Header Background Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[background][header-color]',
                    'id' => $widget['id'] . '-background-header-color',
                    'value' => isset($values['background']['header-color']) ? $values['background']['header-color'] : null,
                );
                $args['elements']['background-media-color'] = array(
                    'type' => 'color',
                    'label' => __('Item\'s Media Background Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[background][media-color]',
                    'id' => $widget['id'] . '-background-media-color',
                    'value' => isset($values['background']['media-color']) ? $values['background']['media-color'] : null,
                );
                $args['elements']['background-body-color'] = array(
                    'type' => 'color',
                    'label' => __('Item\'s Body Background Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[background][body-color]',
                    'id' => $widget['id'] . '-background-body-color',
                    'value' => isset($values['background']['body-color']) ? $values['background']['body-color'] : null,
                );
                $args['elements']['background-footer-color'] = array(
                    'type' => 'color',
                    'label' => __('Item\'s Footer Background Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[background][footer-color]',
                    'id' => $widget['id'] . '-background-footer-color',
                    'value' => isset($values['background']['footer-color']) ? $values['background']['footer-color'] : null,
                );
            }
            return $args;
        }


        /**
         * Customize built in Buttons tools
         *
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeButtonsComponent($args, $position, $widget, $values)
        {
            return $args;
        }


        public function customizeFeaturedImageComponent($args, $position, $widget, $values)
        {
            if($position == 'side'){
                unset($args['elements']['featuredimage']);
                unset($args['elements']['featuredvideo']);

                $args['elements']['imageratios']['wrapper-class'] .= ' large-icons';

                $args['elements']['borders-top'] = array(
                    'type' => 'checkbox',
                    'name' => $widget['name'] . '[borders][top]',
                    'id' => $widget['id'] . '-borders-top',
                    'value' => (isset($values['borders']['top'])) ? $values['borders']['top'] : NULL,
                    'label' => __('Enable top border', TL_INSERT_STAFF_SLUG)
                );

                $args['elements']['borders-right'] = array(
                    'type' => 'checkbox',
                    'name' => $widget['name'] . '[borders][right]',
                    'id' => $widget['id'] . '-borders-right',
                    'value' => (isset($values['borders']['right'])) ? $values['borders']['right'] : NULL,
                    'label' => __('Enable right border', TL_INSERT_STAFF_SLUG)
                );

                $args['elements']['borders-bottom'] = array(
                    'type' => 'checkbox',
                    'name' => $widget['name'] . '[borders][bottom]',
                    'id' => $widget['id'] . '-borders-bottom',
                    'value' => (isset($values['borders']['bottom'])) ? $values['borders']['bottom'] : NULL,
                    'label' => __('Enable bottom border', TL_INSERT_STAFF_SLUG)
                );

                $args['elements']['borders-left'] = array(
                    'type' => 'checkbox',
                    'name' => $widget['name'] . '[borders][left]',
                    'id' => $widget['id'] . '-borders-left',
                    'value' => (isset($values['borders']['left'])) ? $values['borders']['left'] : NULL,
                    'label' => __('Enable left border', TL_INSERT_STAFF_SLUG)
                );

                $args['elements']['borders-style'] = array(
                    'type' => 'select',
                    'label' => __('Border Style', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[borders][style]',
                    'id' => $widget['id'] . '-borders-style',
                    'value' => (isset($values['borders']['style'])) ? $values['borders']['style'] : NULL,
                    'options' => array(
                        'solid' => 'Solid',
                        'dotted' => 'Dotted',
                        'dashed' => 'Dashed',
                        'double' => 'Double',
                        'groove' => 'Groove',
                        'ridge' => 'Ridge',
                        'inset' => 'Inset',
                        'outset' => 'Outset',
                    ),
                );

                $args['elements']['borders-width'] = array(
                    'type' => 'number',
                    'label' => __('Border Width', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[borders][width]',
                    'id' => $widget['id'] . '-borders-width',
                    'value' => isset($values['borders']['width']) ? $values['borders']['width'] : null,
                    'min' => 1,
                    'max' => 30,
                );

                $args['elements']['borders-color'] = array(
                    'type' => 'color',
                    'label' => __('Image\'s border Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[borders][color]',
                    'id' => $widget['id'] . '-borders-color',
                    'value' => isset($values['borders']['color']) ? $values['borders']['color'] : null,
                );
            }

            return $args;
        }


        /**
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeImageRatiosComponent($args, $position, $widget, $values)
        {
            return $args;
        }


        /**
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeColumnsComponent($args, $position, $widget, $values)
        {
            unset($args['elements']['color']);

            $args['elements']['shadow_heading'] = array(
                'type' => 'layers-heading',
                'label' => 'Shadow options'
            );

            $args['elements']['shadow_show'] = array(
                'type' => 'checkbox',
                'label' => __('Show Shadow', TL_INSERT_STAFF_SLUG),
                'name' => $widget['name'] . '[shadow_show]',
                'id' => $widget['id'] . '-shadow_show',
                'value' => isset($values['shadow_show']) ? $values['shadow_show'] : null,
            );

            $args['elements']['shadow_length'] = array(
                'type' => 'number',
                'label' => __('Shadow Length', TL_INSERT_STAFF_SLUG),
                'name' => $widget['name'] . '[shadow_length]',
                'id' => $widget['id'] . '-shadow_length',
                'value' => isset($values['shadow_length']) ? $values['shadow_length'] : null,
            );

            $args['elements']['shadow_blur'] = array(
                'type' => 'number',
                'label' => __('Shadow Blur', TL_INSERT_STAFF_SLUG),
                'name' => $widget['name'] . '[shadow_blur]',
                'id' => $widget['id'] . '-shadow_blur',
                'value' => isset($values['shadow_blur']) ? $values['shadow_blur'] : null,
            );

            $args['elements']['shadow_spread'] = array(
                'type' => 'number',
                'label' => __('Shadow Spread', TL_INSERT_STAFF_SLUG),
                'name' => $widget['name'] . '[shadow_spread]',
                'id' => $widget['id'] . '-shadow_spread',
                'value' => isset($values['shadow_spread']) ? $values['shadow_spread'] : null,
            );

            $args['elements']['shadow_color'] = array(
                'type' => 'color',
                'label' => __('Shadow Color', TL_INSERT_STAFF_SLUG),
                'name' => $widget['name'] . '[shadow_color]',
                'id' => $widget['id'] . '-shadow_color',
                'value' => isset($values['shadow_color']) ? $values['shadow_color'] : null,
            );

            return $args;
        }


        /**
         * @param $objects
         * @return array
         */
        public function filterPostTypesFields($objects)
        {
            $list = array();
            foreach ($objects as $k => $v) {
                $list[$k] = $v->label;
            }

            $list['post'] = __('Blog Posts', TL_INSERT_STAFF_SLUG);
            $list['page'] = __('Pages', TL_INSERT_STAFF_SLUG);

            return $list;
        }


        /**
         * @param $widget
         * @return array
         */
        protected function _getAvailableGridFields($widget)
        {
            $f = array_keys($this->grid_fields);

            if (isset($widget['header_items']) && $widget['header_items'] != '') {
                $t = json_decode($widget['header_items']);
                $f = array_diff($f, $t);
            }

            if (isset($widget['media_items']) && $widget['media_items'] != '') {
                $t = json_decode($widget['media_items']);
                $f = array_diff($f, $t);
            }

            if (isset($widget['body_items']) && $widget['body_items'] != '') {
                $t = json_decode($widget['body_items']);
                $f = array_diff($f, $t);
            }

            if (isset($widget['footer_items']) && $widget['footer_items'] != '') {
                $t = json_decode($widget['footer_items']);
                $f = array_diff($f, $t);
            }
            $r = array();
            foreach ($f as $key => $val) {
                $r[$val] = $this->grid_fields[$val];
            }
            return $r;
        }


        /**
         * @param $widget
         * @return WP_Query
         */
        protected function _create_query_post($widget)
        {
            // Begin query arguments
            $query_args = array();
            if (get_query_var('paged')) {
                $query_args['paged'] = get_query_var('paged');
            } else if (get_query_var('page')) {
                $query_args['paged'] = get_query_var('page');
            } else {
                $query_args['paged'] = 1;
            }

            $query_args['post_type'] = $widget['post_type'];
            $query_args['posts_per_page'] = $widget['posts_per_page'];

            if (isset($widget['sort_by'])) {

                $decode_order = json_decode($widget['sort_by'], true);

                if (is_array($decode_order)) {
                    foreach ($decode_order as $key => $value) {
                        $query_args[$key] = $value;
                    }
                }
            }

            // Do the special taxonomy array()
            if (isset($widget['category']) && '' != $widget['category'] && 0 != $widget['category']) {

                $query_args['tax_query'] = array(
                    array(
                        "taxonomy" => $this->taxonomy,
                        "field" => "id",
                        "terms" => $widget['category']
                    )
                );
            } elseif (!isset($widget['hide_category_filter'])) {
                $terms = get_terms($this->taxonomy);
            } // if we haven't selected which category to show, let's load the $terms for use in the filter

            if (isset($widget['posts_include']) && trim($widget['posts_include']) != '') {
                $pps = explode(',', $widget['posts_include']);

                if (is_array($pps) && !empty($pps))
                    $query_args['post__in'] = $pps;
            }

            return new WP_Query($query_args);
        }
    }
}//if
register_widget('TL_Layers_Post_Widget');