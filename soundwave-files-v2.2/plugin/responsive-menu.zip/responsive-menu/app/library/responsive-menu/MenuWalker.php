<?php

class RM_MenuWalker extends Walker_Nav_Menu {
    
        
    /**
     * Added for potentially using a Menu Walker in future
     * if needed.
     *
     * @return null
     * @added 2.2
     */
    
  
}