<?php
/** Default */
//Colors
($btnBgClr == "") ? $btnBgClr = '#e85115' : $btnBgClr = $btnBgClr;
($btnBgClrHover == "") ? $btnBgClrHover = '#e85115' : $btnBgClrHover = $btnBgClrHover;
($btnTxtClr == "") ? $btnTxtClr = '#fff' : $btnTxtClr = $btnTxtClr;

//Shadow
($hboxshadow == "0") ? $hboxshadow = '0' : $hboxshadow = $hboxshadow;
($vboxshadow == "0") ? $vboxshadow = '3' : $vboxshadow = $vboxshadow;
($bboxshadow == "0") ? $bboxshadow = '0' : $bboxshadow = $bboxshadow;
($sboxshadow == "0") ? $sboxshadow = '0' : $sboxshadow = $sboxshadow;
($cboxshadow == "") ? $cboxshadow = '#b94111' : $cboxshadow = $cboxshadow;

//Border
($btnRadiusValue == "") ? $btnRadiusValue = '4' : $btnRadiusValue = $btnRadiusValue;

//Padding small
($btpTop == "") ? $btpTopSmall = '7' : $btpTopSmall = $btpTop;
($btpRight == "") ? $btpRightSmall = '20' : $btpRightSmall = $btpRight;
($btpBottom == "") ? $btpBottomSmall = '7' : $btpBottomSmall = $btpBottom;
($btpLeft == "") ? $btpLeftSmall = '20' : $btpLeftSmall = $btpLeft;

//Padding
($btpTop == "") ? $btpTop = '15' : $btpTop = $btpTop;
($btpRight == "") ? $btpRight = '40' : $btpRight = $btpRight;
($btpBottom == "") ? $btpBottom = '15' : $btpBottom = $btpBottom;
($btpLeft == "") ? $btpLeft = '40' : $btpLeft = $btpLeft;

?>

<style type="text/css">
    /* Volume style */
    .ct-style-volume.<?php echo $value; ?> {
        background: <?php echo $btnBgClr; ?> !important;
        -webkit-box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        -moz-box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;

        border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -moz-border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -webkit-border-radius: <?php echo $btnRadiusValue; ?>px !important;

        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClr; ?> !important;

        color: <?php echo $btnTxtClr; ?> !important;
        font-weight: bold !important;
        padding: <?php echo $btpTop; ?>px <?php echo $btpRight; ?>px <?php echo $btpBottom; ?>px <?php echo $btpLeft; ?>px !important;
        position: relative !important;
        text-decoration: none !important;
        display: inline-block !important;
        margin: <?php echo $btmTop; ?>px <?php echo $btmRight; ?>px <?php echo $btmBottom; ?>px <?php echo $btmLeft; ?>px !important;
        text-align: center !important;
    }

    .ct-style-volume.small.<?php echo $value; ?> {
        font-size: 13px !important;
        padding: <?php echo $btpTopSmall; ?>px <?php echo $btpRightSmall; ?>px <?php echo $btpBottomSmall; ?>px <?php echo $btpLeftSmall; ?>px !important;
        display:block !important;
        text-align: center !important;
    }

    .ct-style-volume.<?php echo $value; ?>:hover, .ct-style-volume.small.<?php echo $value; ?>:hover {
        background: <?php echo $btnBgClrHover; ?> !important;
        color: <?php echo $btnTxtClrHover; ?> !important;
        text-decoration: none !important;
        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClrHover; ?> !important;

        -webkit-box-shadow: <?php echo $hboxshadow; ?>px 2px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        -moz-box-shadow: <?php echo $hboxshadow; ?>px 2px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        box-shadow: <?php echo $hboxshadow; ?>px 2px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        top: 1px !important;
    }
</style>