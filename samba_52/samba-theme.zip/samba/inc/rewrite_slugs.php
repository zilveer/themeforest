<?php
    $options=get_option('samba_theme_options');
    $options['just_saved']="false";
    update_option('samba_theme_options', $options);
