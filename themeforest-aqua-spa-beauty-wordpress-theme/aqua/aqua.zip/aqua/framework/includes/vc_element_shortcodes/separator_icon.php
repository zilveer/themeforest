<?php

add_action('init', 'tb_separator_icon_integrateWithVC');

function tb_separator_icon_integrateWithVC() {
    vc_map(array(
        "name" => __("Separator Icon", 'jwsthemes'),
        "base" => "tb_separator_icon",
        "class" => "tb-separator-icon",
        "category" => __('Aqua', 'jwsthemes'),
        "icon" => "tb-icon-for-vc",
        "params" => array(
            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => __("Icon", 'jwsthemes'),
                "param_name" => "spr_icon",
                "value" => "",
                "description" => __("Separator Icon.", 'jwsthemes')
            ),
			array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Width", 'jwsthemes'),
                "param_name" => "spr_width",
                "value" => array(
                    "100%" => "100%",
                    "90%" => "90%",
                    "80%" => "80%",
                    "70%" => "70%",
                    "60%" => "60%",
                    "50%" => "50%",
                    "40%" => "40%",
                    "30%" => "30%",
                    "20%" => "20%",
                    "10%" => "10%"
                ),
                "description" => __("Separator Width.", 'jwsthemes')
            ),
			array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Align", 'jwsthemes'),
                "param_name" => "spr_align",
                "value" => array(
                    "Left" => "left",
                    "Center" => "center",
					"Right" => "right"
                ),
                "description" => __('Separator Align.', 'jwsthemes')
            ),
			array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Animation", 'jwsthemes'),
                "param_name" => "animation",
                "value" => array(
                    "No" => "",
                    "Top to bottom" => "top-to-bottom",
                    "Bottom to top" => "bottom-to-top",
                    "Left to right" => "left-to-right",
                    "Right to left" => "right-to-left",
                    "Appear from center" => "appear"
                ),
                "description" => __("Animation", 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Extra Class", 'jwsthemes'),
                "param_name" => "el_class",
                "value" => "",
                "description" => __("Extra Class.", 'jwsthemes')
            ),
        )
    ));
}
