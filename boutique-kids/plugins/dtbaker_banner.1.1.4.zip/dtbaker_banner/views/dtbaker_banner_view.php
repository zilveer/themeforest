<div class="dtbaker_banner dtbaker_banner_<?php echo esc_attr($sc_atts->type);?>" id="dtbaker_banner_<?php echo esc_attr($sc_atts->id);?>">
	<span class="text">
	<?php if($sc_atts->linkhref): ?>
	<a href="<?php echo esc_attr($sc_atts->linkhref);?>" class="link dtbaker_banner">
	<?php endif; ?>
		<?php echo $sc_atts->text;?>
	<?php if($sc_atts->linkhref): ?>
	</a>
	<?php endif; ?>
		</span>
</div>