<?php
/*
Plugin Name: Indeed My Team
Plugin URI: http://www.wpindeed.com/
Description: The best looking and easy to use plugin that helps you to display your team in different showcases
Version: 1.5
Author: indeed
Author URI: http://www.wpindeed.com
*/

///FUNCTIONS
include_once(plugin_dir_path ( __FILE__ ).'includes/functions.php');

add_action( 'init', 'imt_post_team' );
function imt_post_team() {
  $labels = array(
    'name'               => 'Members',
    'singular_name'      => 'Team',
    'add_new'            => 'Add New Member',
    'add_new_item'       => 'Add New Member',
    'edit_item'          => 'Edit Member',
    'new_item'           => 'New Member',
    'all_items'          => 'All Members',
    'view_item'          => 'View Member',
    'search_items'       => 'Search Team Member',
    'not_found'          => 'No Team Members available',
    'not_found_in_trash' => 'No Team Members found in Trash',
    'parent_item_colon'  => '',
    'menu_name'          => 'Team Members'
  );
  $args = array(
    'labels'             => $labels,
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => 8,
    'menu_icon'          => plugin_dir_url( __FILE__ ) . 'files/images/ed-gray.png',
    'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' )
  );
    register_post_type( 'team', $args );
}
////////////TAXONOMY
add_action( 'init', 'imt_taxonomy_team', 0 );
function imt_taxonomy_team() {
	$labels = array(
		'name'              => _x( 'Teams', 'taxonomy general name' ),
		'singular_name'     => _x( 'Team', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Teams' ),
		'all_items'         => __( 'All Teams' ),
		'parent_item'       => __( 'Parent Catergory' ),
		'parent_item_colon' => __( 'Parent Catergory:' ),
		'edit_item'         => __( 'Edit Team' ),
		'update_item'       => __( 'Update Catergory' ),
		'add_new_item'      => __( 'Add New Team' ),
		'new_item_name'     => __( 'New Catergory Name' ),
		'menu_name'         => __( 'Teams' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'team_cats' ),
	);
register_taxonomy( 'team_cats', 'team', $args );
}

///////////////SHORTCODE GENERATOR ( SUBMENU )
add_action( 'admin_menu', 'imt_shortcode_menu_team' );
function imt_shortcode_menu_team(){
    add_submenu_page( 'edit.php?post_type=team', 'Shortcode Generator', 'Shortcode Generator', 'manage_options', 'team_shortcode_generator', 'imt_shortcode_page_team' );
}
function imt_shortcode_page_team(){
    $dir_path = plugin_dir_path ( __FILE__ );
    $dir_url = plugin_dir_url ( __FILE__ );
    include( $dir_path . 'includes/imt_shortcode_generator.php' );
}
/////////CUSTOM FIELD
    //////////INFO
    add_action( 'add_meta_boxes', 'imt_cf_ti' );
    function imt_cf_ti(){
        add_meta_box('team_personal_info',
                     'Personal Information',
                     'imt_metabox_ti', //function available in function.php
                     'team',
                     'normal',
                     'high');
    }
    add_action('save_post', 'imt_save_ti');
    ////////SOCIAL MEDIA
    add_action( 'add_meta_boxes', 'imt_cf_tsm' );
    function imt_cf_tsm(){
        add_meta_box('indeed_team_sm',
                     'Social Media',
                     'imt_metabox_tsm', //function available in function.php
                     'team',
                     'normal',
                     'high');
    }
    add_action('save_post', 'imt_save_tsm');
    /////////TEAM SKILLS
    add_action( 'add_meta_boxes', 'imt_cf_ts' );
    function imt_cf_ts(){
        add_meta_box('indeed_team_skills',
                     'Skills',
                     'imt_metabox_ts', //function available in function.php
                     'team',
                     'normal',
                     'high');
    }
    add_action('save_post', 'imt_save_ts');
	/////////FEATURE IMAGE
	add_action( 'add_meta_boxes', 'imt_cf_mp' );
    function imt_cf_mp(){
		remove_meta_box( 'postimagediv', 'team', 'side' );
        add_meta_box('postimagediv',
                     'Member Picture',
                     'post_thumbnail_meta_box', 
                     'team',
                     'side',
                     'low');
    }
	
	add_action( 'add_meta_boxes', 'imt_cf_exp' );
    function imt_cf_exp(){
        add_meta_box('postexcerpt',
                     'Short Description',
                     'post_excerpt_meta_box',
                     'team',
                     'normal',
                     'high');
    }

////////SHORTCODE
add_shortcode( 'indeed-my-team', 'imt_shortcode_func_team' );
function imt_shortcode_func_team($attr){
    $dir_path = plugin_dir_path ( __FILE__ );
    $dir_url = plugin_dir_url( __FILE__ );
    $return_str = true;
    include( $dir_path . 'includes/imt_view.php' );
    return $final_str;
}

////////WIDGET
class IndeedMyTeamWidget extends WP_Widget {
	function IndeedMyTeamWidget() {
		// Instantiate the parent object
		parent::__construct( false, 'Indeed My Team' );
	}

	function widget( $args, $instance ) {
        $dir = plugin_dir_path ( __FILE__ );
	    $current_instance_id = explode('-', $this->id);
		$instance_no = $current_instance_id[1];

        $attr = $instance;
        include ($dir . 'includes/imt_view.php');

        global $wp_query;
        $a = get_post_meta( $wp_query->post->ID, '_wp_page_template', true );
	}

	function update( $new_instance, $old_instance ){
		$instance = $old_instance;
        $instance['color_scheme'] = $new_instance['color_scheme'];
        $instance['theme'] = $new_instance['theme'];
        $instance['show'] = $new_instance['show'];
        $instance['team'] = $new_instance['team'];
        $instance['limit'] = $new_instance['limit'];
        $instance['order'] = $new_instance['order'];
        $instance['order_by'] = $new_instance['order_by'];
        $instance['page_inside'] = $new_instance['page_inside'];
        $instance['inside_template'] = $new_instance['inside_template'];
        $instance['columns'] = $new_instance['columns'];

        //SLIDER
        $instance['slider_set'] = $new_instance['slider_set'];
        $instance['items_per_slide'] = $new_instance['items_per_slide'];
        $instance['slide_speed'] = $new_instance['slide_speed'];
        $instance['slide_pagination_speed'] = $new_instance['slide_pagination_speed'];
        $instance['slide_css_transition'] = $new_instance['slide_css_transition'];
        $instance['slide_opt'] = $new_instance['slide_opt'];

        return $instance;
	}

	function form( $instance ) {
	    $dir_path = plugin_dir_path ( __FILE__ );
        $dir_url = plugin_dir_url ( __FILE__ );

        wp_enqueue_script( 'functions', $dir_url.'files/js/functions.js');
        wp_enqueue_style( 'be_style', $dir_url.'files/css/style.css');

	    $current_instance_id = explode('-', $this->id);
		$instance_no = $current_instance_id[1];
        include ( $dir_path . 'includes/imt_widget_form.php' );
	}
}

function register_IndeedMyTeamWidget() {
	register_widget( 'IndeedMyTeamWidget' );
}
add_action( 'widgets_init', 'register_IndeedMyTeamWidget' );


////STYLE AND JS
add_action('wp_enqueue_scripts', 'imt_fe_head');
function imt_fe_head(){
  $dir_path = plugin_dir_url ( __FILE__ );
  wp_enqueue_style( 'be_style', $dir_path.'files/css/style.css' );
  wp_enqueue_style ( 'owl.carousel', $dir_path.'files/css/owl.carousel.css' );
  wp_enqueue_style ( 'owl.theme', $dir_path.'files/css/owl.theme.css' );
  wp_enqueue_style ( 'owl.transitions', $dir_path.'files/css/owl.transitions.css' );

  wp_enqueue_script( 'jquery' );
  wp_enqueue_script ( 'owl.carousel', $dir_path.'files/js/owl.carousel.js', array(), null );
}


add_action("admin_enqueue_scripts", 'imt_be_head');
function imt_be_head(){
    $is_edit = FALSE;
    $screen = get_current_screen();
    if( $screen->post_type=="team") $is_edit = TRUE;

    $plugin_pages = array('team_shortcode_generator', 'team');
    if( (isset($_GET['page']) && in_array($_GET['page'], $plugin_pages))
        || (isset($_GET['post_type']) && in_array($_GET['post_type'], $plugin_pages))
        || $is_edit==TRUE ){
          $dir_path = plugin_dir_url ( __FILE__ );
          wp_enqueue_style ( 'font-awesome', $dir_path.'files/css/font-awesome.min.css' );
          wp_enqueue_style ( 'indeed_style', $dir_path.'files/css/style.css' );
          wp_enqueue_style ( 'owl.carousel', $dir_path.'files/css/owl.carousel.css' );
          wp_enqueue_style ( 'owl.theme', $dir_path.'files/css/owl.theme.css' );
          wp_enqueue_style ( 'owl.transitions', $dir_path.'files/css/owl.transitions.css ');

          wp_enqueue_script( 'jquery' );
          wp_enqueue_script ( 'functions', $dir_path.'files/js/functions.js', array(), null );
          wp_enqueue_script ( 'owl.carousel', $dir_path.'files/js/owl.carousel.js', array(), null );
    }
}


//////
add_filter( 'template_include', 'itm_portfolio_page_template', 99 );
function itm_portfolio_page_template( $template ) {
    if(get_post_type()=='team' && isset($_REQUEST['team_cpt']) && $_REQUEST['team_cpt']!=''){
        $template = urldecode($_REQUEST['team_cpt']);
        $template .= ".php";
    	$new_template = locate_template( $template );
        return $new_template;
    }
    else return $template;
}
?>