<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// add shortcode for more link
add_shortcode('more','multipurpose_more');

function multipurpose_more($atts, $content = null) {
extract(shortcode_atts(array(  
        'link_url'=> ''
    ), $atts));  

    $output = '<p class="more"><a href="'.$link_url.'">'.$content.'</a></p>';
    return $output;
}
