<?php 

	/* Media Box  ---------------------------------------------*/
	
	add_shortcode('media_center', 'jx_ievent_media_center');
	
	function jx_ievent_media_center($atts, $content = null) { 
		extract(shortcode_atts(array(
					'color_style' => '',
					'button_link' => '',
					'count' => '3'
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		$image_size ='small-blog';
		global $wp_embed;
		global $data;
		
		$dark_light_color ='';
		$column_class='';
		$button_link_url='';
		$j=0;
		
		
		$args = array('post_type' => 'post','orderby' => 'date', 'order' => 'DESC','showposts' => $count ); 
		
		$out ='<div class="jx-ievent-media-center container'.$dark_light_color.'">';
		
		$loop = new WP_Query( $args ); 		
		while ( $loop->have_posts() ) : $loop->the_post();  
		
			if(get_the_category()):
				$cats = get_the_category(); 
		    	$cat_name = $cats[0]->name;
			endif; 	
		//function code
			
		
			if( $j % $count == 0 ){
			$column_class = 'alpha';
			}elseif ($j%$count== $count-1){
			$column_class = 'omega';
			}else{
			$column_class = '';
			}
			
			
			$out .='<div class="one-third columns '.$column_class.'">';
						
			$out .='<div class="jx-ievent-blog-image flexslider small-blog">
                    <ul class="slides"> ';

						   if(get_post_meta( get_the_ID(), 'jx_ievent_video_code', true )):
                                
								
							$out .='<li>
                                    <div class="image jx-ievent-image-wrapper">
                                    <div class="full-video">
                                        <div class="full-widthvideo">
                                        '.$wp_embed->run_shortcode('[embed width="380"]'.esc_url(get_post_meta(get_the_ID(), 'jx_ievent_video_code', true)).'[/embed]').'
                                        </div><!-- EOF full-widthvideo-->
                                    </div><!-- EOF full-video-->
                                    
                                    <div class="jx-ievent-image-overlay"></div>
                                    
                                     <div class="jx-ievent-image-hover">
                                        <a href="'.get_post_meta(get_the_ID(), 'jx_ievent_video_code', true).'" class="jx-ievent-blog-more" data-rel="prettyPhoto"><i class="line-icon vc_li vc_li-video"></i></a>                            
                                    </div>
                                    <!-- Image Hover -->
                                    </div>
                                </li>';
                           
						   
						   endif;
						        
								                                 
                           if(has_post_thumbnail()): 
							  $post_image_id = get_post_thumbnail_id(get_the_id());
							  $image_url = wp_get_attachment_image_src($post_image_id, 'large');
							  $image_small = wp_get_attachment_image_src($post_image_id, $image_size);
							  $image_data = wp_get_attachment_metadata($post_image_id);
							  
	
                           $out .='<li>
                                    <div class="image jx-ievent-image-wrapper">
                                    '.get_the_post_thumbnail(get_the_id(),$image_size).'
									<div class="jx-ievent-image-overlay"></div>
                                      <div class="jx-ievent-image-hover">
                                        <a href="'.get_the_permalink().'" class="jx-ievent-blog-more"><i class="line-icon vc_li vc_li-clip"></i></a>
                                      </div>
                                     </div>
                                </li>'; 
                           
                           endif;
						                                     
                           if(kd_mfi_get_featured_image_id('featured-image-2', 'post')):
						                                                                       
                                $i = 2;
                                while($i <= $data['text_slideshow_count'] ):
                                $attachment_id = kd_mfi_get_featured_image_id('featured-image-'.$i, 'post');
                                
                                $out .='<li><div class="image jx-ievent-image-wrapper">';
                                
									if($attachment_id):
										$image_url = wp_get_attachment_image_src($attachment_id, 'large');
										$image_small = wp_get_attachment_image_src($attachment_id, $image_size);
										$image_data = wp_get_attachment_metadata($attachment_id);
														
										
										$out .='
										<img src="'.$image_small[0].'" alt="'.$image_data['image_meta']['title'].'" />									
										<div class="jx-ievent-image-overlay"></div>
										<div class="jx-ievent-image-hover">
											<a href="'.get_the_permalink().'" class="jx-ievent-blog-more"><i class="line-icon vc_li vc_li-clip"></i></a>
										</div>
										</div></li>
										';										
								   
									endif; $i++;
                            	endwhile;
							endif; // End of slideshow 
                                                  
             $out .='</ul><!-- end #slider -->
                 </div><!-- end of Flexslider -->';
			
			$out .='		
				<div class="title"><a href="'.get_the_permalink().'">'. get_the_title() .'</a></div>
				<!-- Title -->
				<div class="date"><i class="line-icon vc_li vc_li-calendar"></i> <span>'.get_the_time('j F  Y').'</span> <i class="line-icon vc_li vc_li-tag"></i><span>'.$cat_name.'</span></div>
				<!-- Date -->
				<div class="description">' .excerpt('20'). '</div>
				<!-- Description -->
			</div>
                    
            <!-- Item # 1 -->
			';
			$j++;
			
			endwhile;
			wp_reset_query();
			
		if ($button_link):
			$button_link_url=$button_link;
		else:
			$button_link_url= get_site_url().'/blog';
		endif;
		
		$out .='</div>
		<div class="row"></div>
		<div class="row"></div>
		
		<div class="jx-ievent-btn-center"> 
			<a href="'.$button_link_url.'" class="jx-ievent-btn-default"><i class="line-icon vc_li vc_li-note"></i>'.esc_html__('View All','ievent').'</a>
		</div>
		<!-- Read More Button -->
		';
			
			//wp_reset_query(); 
		
		//return output
		return $out;
	}



	//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_media_center' );
	
	
	function vc_media_center() {	
		vc_map(array(
      "name" => esc_html__( "Media Center", "TEXT_DOMAIN" ),
      "base" => "media_center",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_news.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Add Media Center','TEXT_DOMAIN'),
      "params" => array(
		
		
		array(
		"type" => "dropdown",
		"class" => "",
		"heading" => __("ColorStyle",'TEXT_DOMAIN'),
		"param_name" => "color_style",
		"value" => array(   
			__('Light', 'TEXT_DOMAIN') => 'light',
			__('Dark', 'TEXT_DOMAIN') => 'dark',
			),
		),
		 		 
		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Button Link", "TEXT_DOMAIN" ),
            "param_name" => "button_link",
			"value" => "#", //Default Counter Up Text
            "description" => esc_html__( "Set button link", "TEXT_DOMAIN" )
         ),   
        
		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Post Count", "TEXT_DOMAIN" ),
            "param_name" => "count",
			"value" => "3", //Default Counter Up Text
            "description" => esc_html__( "Number of posts", "TEXT_DOMAIN" )
         )

      )
   )); 
	}



?>