<?php
// Register Custom Post Type
function tb_add_post_type_space() {
    // Register taxonomy
    $labels = array(
            'name'              => _x( 'Space Category', 'taxonomy general name', 'jwsthemes' ),
            'singular_name'     => _x( 'Space Category', 'taxonomy singular name', 'jwsthemes' ),
            'search_items'      => __( 'Search Space Category', 'jwsthemes' ),
            'all_items'         => __( 'All Space Category', 'jwsthemes' ),
            'parent_item'       => __( 'Parent Space Category', 'jwsthemes' ),
            'parent_item_colon' => __( 'Parent Space Category:', 'jwsthemes' ),
            'edit_item'         => __( 'Edit Space Category', 'jwsthemes' ),
            'update_item'       => __( 'Update Space Category', 'jwsthemes' ),
            'add_new_item'      => __( 'Add New Space Category', 'jwsthemes' ),
            'new_item_name'     => __( 'New Space Category Name', 'jwsthemes' ),
            'menu_name'         => __( 'Space Category', 'jwsthemes' ),
    );

    $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'space_category' ),
    );
    if(function_exists('custom_reg_taxonomy')) {
        custom_reg_taxonomy( 'space_category', array( 'space' ), $args );
    }
    //Register tags
    $labels = array(
            'name'              => _x( 'Space Tag', 'taxonomy general name', 'jwsthemes' ),
            'singular_name'     => _x( 'Space Tag', 'taxonomy singular name', 'jwsthemes' ),
            'search_items'      => __( 'Search Space Tag', 'jwsthemes' ),
            'all_items'         => __( 'All Space Tag', 'jwsthemes' ),
            'parent_item'       => __( 'Parent Space Tag', 'jwsthemes' ),
            'parent_item_colon' => __( 'Parent Space Tag:', 'jwsthemes' ),
            'edit_item'         => __( 'Edit Space Tag', 'jwsthemes' ),
            'update_item'       => __( 'Update Space Tag', 'jwsthemes' ),
            'add_new_item'      => __( 'Add New Space Tag', 'jwsthemes' ),
            'new_item_name'     => __( 'New Space Tag Name', 'jwsthemes' ),
            'menu_name'         => __( 'Space Tag', 'jwsthemes' ),
    );

    $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'portfolio_tag' ),
    );
    
    if(function_exists('custom_reg_taxonomy')) {
        custom_reg_taxonomy( 'portfolio_tag', array( 'space' ), $args );
    }
    
    //Register post type space
    $labels = array(
            'name'                => _x( 'Space', 'Post Type General Name', 'jwsthemes' ),
            'singular_name'       => _x( 'Space Item', 'Post Type Singular Name', 'jwsthemes' ),
            'menu_name'           => __( 'Space', 'jwsthemes' ),
            'parent_item_colon'   => __( 'Parent Item:', 'jwsthemes' ),
            'all_items'           => __( 'All Items', 'jwsthemes' ),
            'view_item'           => __( 'View Item', 'jwsthemes' ),
            'add_new_item'        => __( 'Add New Item', 'jwsthemes' ),
            'add_new'             => __( 'Add New', 'jwsthemes' ),
            'edit_item'           => __( 'Edit Item', 'jwsthemes' ),
            'update_item'         => __( 'Update Item', 'jwsthemes' ),
            'search_items'        => __( 'Search Item', 'jwsthemes' ),
            'not_found'           => __( 'Not found', 'jwsthemes' ),
            'not_found_in_trash'  => __( 'Not found in Trash', 'jwsthemes' ),
    );
    $args = array(
            'label'               => __( 'Space', 'jwsthemes' ),
            'description'         => __( 'Space Description', 'jwsthemes' ),
            'labels'              => $labels,
            'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', 'post-formats', ),
            'taxonomies'          => array( 'space_category', 'portfolio_tag' ),
            'hierarchical'        => true,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'menu_icon'           => 'dashicons-welcome-view-site',
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'page',
    );
    
    if(function_exists('custom_reg_post_type')) {
        custom_reg_post_type( 'space', $args );
    }
    
}

// Hook into the 'init' action
add_action( 'init', 'tb_add_post_type_space', 0 );
