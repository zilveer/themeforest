<?php
vc_map(array(
    "name" => 'Google Maps',
    "base" => "maps",
    "category" => __('Aqua', 'jwsthemes'),
	"icon" => "tb-icon-for-vc",
    "description" => __('Google Maps API V3', 'jwsthemes'),
    "params" => array(
        array(
            "type" => "textfield",
            "heading" => __('API Key', 'jwsthemes'),
            "param_name" => "api",
            "value" => '',
            "description" => __('Enter you api key of map, get key from (https://console.developers.google.com)', 'jwsthemes')
        ),
        array(
            "type" => "textfield",
            "heading" => __('Address', 'jwsthemes'),
            "param_name" => "address",
            "value" => 'New York, United States',
            "description" => __('Enter address of Map', 'jwsthemes')
        ),
        array(
            "type" => "textfield",
            "heading" => __('Coordinate', 'jwsthemes'),
            "param_name" => "coordinate",
            "value" => '',
            "description" => __('Enter coordinate of Map, format input (latitude, longitude)', 'jwsthemes')
        ),
        array(
            "type" => "checkbox",
            "heading" => __('Click Show Info window', 'jwsthemes'),
            "param_name" => "infoclick",
            "value" => array(
                __("Yes, please", 'jwsthemes') => true
            ),
            "group" => __("Marker", 'jwsthemes'),
            "description" => __('Click a marker and show info window (Default Show).', 'jwsthemes')
        ),
        array(
            "type" => "textfield",
            "heading" => __('Marker Coordinate', 'jwsthemes'),
            "param_name" => "markercoordinate",
            "value" => '',
            "group" => __("Marker", 'jwsthemes'),
            "description" => __('Enter marker coordinate of Map, format input (latitude, longitude)', 'jwsthemes')
        ),
        array(
            "type" => "textfield",
            "heading" => __('Marker Title', 'jwsthemes'),
            "param_name" => "markertitle",
            "value" => '',
            "group" => __("Marker", 'jwsthemes'),
            "description" => __('Enter Title Info windows for marker', 'jwsthemes')
        ),
        array(
            "type" => "textarea",
            "heading" => __('Marker Description', 'jwsthemes'),
            "param_name" => "markerdesc",
            "value" => '',
            "group" => __("Marker", 'jwsthemes'),
            "description" => __('Enter Description Info windows for marker', 'jwsthemes')
        ),
        array(
            "type" => "attach_image",
            "heading" => __('Marker Icon', 'jwsthemes'),
            "param_name" => "markericon",
            "value" => '',
            "group" => __("Marker", 'jwsthemes'),
            "description" => __('Select image icon for marker', 'jwsthemes')
        ),
        array(
            "type" => "textarea_raw_html",
            "heading" => __('Marker List', 'jwsthemes'),
            "param_name" => "markerlist",
            "value" => '',
            "group" => __("Multiple Marker", 'jwsthemes'),
            "description" => __('[{"coordinate":"41.058846,-73.539423","icon":"","title":"title demo 1","desc":"desc demo 1"},{"coordinate":"40.975699,-73.717636","icon":"","title":"title demo 2","desc":"desc demo 2"},{"coordinate":"41.082606,-73.469718","icon":"","title":"title demo 3","desc":"desc demo 3"}]', 'jwsthemes')
        ),
        array(
            "type" => "textfield",
            "heading" => __('Info Window Max Width', 'jwsthemes'),
            "param_name" => "infowidth",
            "value" => '200',
            "group" => __("Marker", 'jwsthemes'),
            "description" => __('Set max width for info window', 'jwsthemes')
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Map Type", 'jwsthemes'),
            "param_name" => "type",
            "value" => array(
                "ROADMAP" => "ROADMAP",
                "HYBRID" => "HYBRID",
                "SATELLITE" => "SATELLITE",
                "TERRAIN" => "TERRAIN"
            ),
            "description" => __('Select the map type.', 'jwsthemes')
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Style Template", 'jwsthemes'),
            "param_name" => "style",
            "value" => array(
                "Default" => "",
                "Custom" => "custom",
                "Light Monochrome" => "light-monochrome",
                "Blue water" => "blue-water",
                "Midnight Commander" => "midnight-commander",
                "Paper" => "paper",
                "Red Hues" => "red-hues",
                "Hot Pink" => "hot-pink"
            ),
            "group" => __("Map Style", 'jwsthemes'),
            "description" => 'Select your heading size for title.'
        ),
        array(
            "type" => "textarea_raw_html",
            "heading" => __('Custom Template', 'jwsthemes'),
            "param_name" => "content",
            "value" => '',
            "group" => __("Map Style", 'jwsthemes'),
            "description" => __('Get template from http://snazzymaps.com', 'jwsthemes')
        ),
        array(
            "type" => "textfield",
            "heading" => __('Zoom', 'jwsthemes'),
            "param_name" => "zoom",
            "value" => '13',
            "description" => __('zoom level of map, default is 13', 'jwsthemes')
        ),
        array(
            "type" => "textfield",
            "heading" => __('Width', 'jwsthemes'),
            "param_name" => "width",
            "value" => 'auto',
            "description" => __('Width of map without pixel, default is auto', 'jwsthemes')
        ),
        array(
            "type" => "textfield",
            "heading" => __('Height', 'jwsthemes'),
            "param_name" => "height",
            "value" => '350px',
            "description" => __('Height of map without pixel, default is 350px', 'jwsthemes')
        ),
        array(
            "type" => "checkbox",
            "heading" => __('Scroll Wheel', 'jwsthemes'),
            "param_name" => "scrollwheel",
            "value" => array(
                __("Yes, please", 'jwsthemes') => true
            ),
            "group" => __("Controls", 'jwsthemes'),
            "description" => __('If false, disables scrollwheel zooming on the map. The scrollwheel is disable by default.', 'jwsthemes')
        ),
        array(
            "type" => "checkbox",
            "heading" => __('Pan Control', 'jwsthemes'),
            "param_name" => "pancontrol",
            "value" => array(
                __("Yes, please", 'jwsthemes') => true
            ),
            "group" => __("Controls", 'jwsthemes'),
            "description" => __('Show or hide Pan control.', 'jwsthemes')
        ),
        array(
            "type" => "checkbox",
            "heading" => __('Zoom Control', 'jwsthemes'),
            "param_name" => "zoomcontrol",
            "value" => array(
                __("Yes, please", 'jwsthemes') => true
            ),
            "group" => __("Controls", 'jwsthemes'),
            "description" => __('Show or hide Zoom Control.', 'jwsthemes')
        ),
        array(
            "type" => "checkbox",
            "heading" => __('Scale Control', 'jwsthemes'),
            "param_name" => "scalecontrol",
            "value" => array(
                __("Yes, please", 'jwsthemes') => true
            ),
            "group" => __("Controls", 'jwsthemes'),
            "description" => __('Show or hide Scale Control.', 'jwsthemes')
        ),
        array(
            "type" => "checkbox",
            "heading" => __('Map Type Control', 'jwsthemes'),
            "param_name" => "maptypecontrol",
            "value" => array(
                __("Yes, please", 'jwsthemes') => true
            ),
            "group" => __("Controls", 'jwsthemes'),
            "description" => __('Show or hide Map Type Control.', 'jwsthemes')
        ),
        array(
            "type" => "checkbox",
            "heading" => __('Street View Control', 'jwsthemes'),
            "param_name" => "streetviewcontrol",
            "value" => array(
                __("Yes, please", 'jwsthemes') => true
            ),
            "group" => __("Controls", 'jwsthemes'),
            "description" => __('Show or hide Street View Control.', 'jwsthemes')
        ),
        array(
            "type" => "checkbox",
            "heading" => __('Over View Map Control', 'jwsthemes'),
            "param_name" => "overviewmapcontrol",
            "value" => array(
                __("Yes, please", 'jwsthemes') => true
            ),
            "group" => __("Controls", 'jwsthemes'),
            "description" => __('Show or hide Over View Map Control.', 'jwsthemes')
        )
    )
));