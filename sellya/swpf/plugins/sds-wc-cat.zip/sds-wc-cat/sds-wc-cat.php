<?php
/*
Plugin Name: Smartdatasoft Woocommerce Latest Product by Category 
Description: A woocommerce plugin that helps to build tabs with categories, subcategories and products.
Version: 1.1
Author: Smart Data Soft
Author URI: http://www.smartdatasoft.com/
*/

if(!class_exists('SDS_WC_frontend')):

	include 'lib/class.SDS_WC_cat.php';

	class SDS_WC_frontend extends SDS_WC_cat{
		
		public $q, $id, $plugindir, $pluginurl;
		
		function __construct(){
			
			global $woocommerce;
				
			parent::__construct();
			
			$this->plugindir = dirname(__FILE__);
			
			$this->pluginurl = plugins_url('',__FILE__);
			
			if(isset($woocommerce)) echo "Woocommerce!";
			
			add_action('admin_menu', array($this,'register_SDS_WC_cat_admin_panel'));			
					
			add_action('wp_enqueue_scripts', array($this,'enqueue_SDS_WC_cat_scripts'));
			
			add_action('wp_enqueue_scripts',array($this,'sds_load_default_js'),100);
			
			add_action('wp_enqueue_scripts',array($this,'sds_header_css'),18);
			
			add_shortcode('sds-wc-cat',array($this,'sds_WC_frontend_callback'));
				
		}
		
		function sds_header_css(){
			wp_enqueue_style('sds-wc-cat',"{$this->pluginurl}/assets/css/sds-wc-cat.css",array(),'1.0');	
		}
		
		function sds_load_default_js(){
			
			
			wp_enqueue_script('elastislide',"{$this->pluginurl}/assets/js/jquery.elastislide.js" ,array('jquery'),'1.0',true);
			//wp_enqueue_script('jcarousel-min',"{$this->pluginurl}/assets/js/jquery.jcarousel.min.js" ,array('jquery'));
			
			wp_enqueue_script('sds-custom-js',"{$this->pluginurl}/assets/js/custom.js" ,array('jquery'),'1.0',true);
			
			//wp_enqueue_style('jcarousel-css',"{$this->pluginurl}/assets/css/carousel.css");
			
		}
		function common_query_part(){
			
			global $smof_data;
			
			$product_id = get_the_ID();
			
			$product = get_product($product_id);
			
			?>
			
            
            <li>

				<div class="pbox">
         
                    <div class="image">

                      <a href="<?php the_permalink(); ?>">

                          <?php
                                
                            do_action( 'woocommerce_before_shop_loop_item_title' );
                        ?>

                      </a>      

                    </div><!--.image -->
                    <div class="description hidden-phone hidden-tablet">
                                          
                        <?php 							
                            echo apply_filters( 'woocommerce_short_description', $product->post->post_excerpt );							
                        ?>
                    </div>

                      <div class="rating hidden-phone hidden-tablet">

                            <div id="reviews">

                                <div id="comments">                        

                                    <div itemtype="http://schema.org/AggregateRating" itemscope="" itemprop="aggregateRating">

                                      <?php echo $product->get_rating_html();?>  
                                    </div>

                                </div><!--#comments-->

                            </div><!--#reviews-->

                      </div><!--.rating-->

                      <div class="name"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>

                      
                        <?php
                              /**
                               * woocommerce_after_shop_loop_item_title hook
                               *
                               * @hooked woocommerce_template_loop_price - 10
                               */
                               do_action( 'woocommerce_after_shop_loop_item_title' );
                          ?>
                        
                            
                          <div class="cart"><?php do_action( 'woocommerce_after_shop_loop_item' ); ?></div>

                      <div class="clear"></div>

                    </div><!--.pbox -->

                </li>
            
			
			<?php
		}
		function query($data = array()){						
			
			if($this->q->have_posts()): 
				
				echo "<ul class='products'>";
				
				while($this->q->have_posts()): $this->q->the_post();
				
					$this->common_query_part();
				
				endwhile; 
			
			
				echo "</ul>";
				
			endif;
			
			wp_reset_query();
			
		   
		}
		
		function sds_product_no_child_cat($data){
			
			$cat_id = intval($data['catdropdown']);		
			
			$term = get_term($cat_id,'product_cat');
			
			$limit = !empty($data['limit']) ? $data['limit']: get_option('posts_per_page');
			
			$args = array('post_type'=>'product','showposts'=>$limit);
			
			$args['tax_query'] = array(                
				array(
			  
				'taxonomy' => 'product_cat',
				'field' => 'slug',
				'terms' => array($term->slug),
				'include_children'=>false
				
			));
			
			$this->q = new WP_Query($args);
			
			echo "
			<div class='featured-wrap'>
				<h2>$term->name</h2>
				<div class='product-grid'>
					<div class='woocommerce'>
					<div id='$this->id' class='products-slider textwidget'>";
			
			
				$this->query();
			
			echo "</div></div></div></div>";			
		   
		}
		
		function sds_product_with_subcat($data){
			
			$cat_id = intval($data['catdropdown']);
			
			$limit = !empty($data['limit']) ? $data['limit']: get_option('posts_per_page'); 
			
			$terms = array();
			
			$parent = get_term($cat_id,'product_cat');
			
			$terms[] = $parent->slug;
			
			$args = array('post_type'=>'product','showposts'=>$limit);
			
			$args['tax_query'] = array(array(
			  
				'taxonomy' => 'product_cat',
				'field' => 'slug',
				'terms' => $terms
				
			));
			
			$this->q = new WP_Query($args);
			
			echo "
			<div class='featured-wrap'>
				<h2>$parent->name</h2>
				<div class='product-grid'>
					<div class='woocommerce'>
					<div id='$this->id' class='products-slider textwidget'>";
			
			
				$this->query($data);
			
			echo "</div></div></div></div>";
			
		   
		}
		
		function sds_product_with_tab($data){
			
			$cat_id = intval($data['catdropdown']);
			
			$limit = !empty($data['limit']) ? $data['limit']: get_option('posts_per_page'); 
			
			$terms = get_terms('product_cat',array('parent'=>$cat_id));
			
			$args = array('post_type'=>'product','showposts'=>$limit);          
			
			if(!empty($terms)):
			
			?>
    <div class='featured-wrap'>        
        <div class='product-grid'>
            <div class='woocommerce'>
                <div class="sds_tabs">
                    <ul>
		   <?php $i = 0;
				
				foreach($terms as $term): $i++;?>
				
					<li><a href="#tab-<?php echo $i?>"><?php echo $term->name?></a></li>
					
			<?php endforeach;?>
				</ul>
			   
			<?php
			
				$i = 0;
				
				foreach($terms as $term):
					
					$i++;
					
					$id = $this->id;
					
					$id .= "-$i";
					
					echo "<div id='tab-{$i}' class='$id products-slider'>";
					
					$args['tax_query'] = array(                
						array(
					  
						'taxonomy' => 'product_cat',
						'field' => 'slug',
						'terms' => array($term->slug),
						'include_children'=>false
						
					));
					
					$this->q = new WP_Query($args);
			
					$this->query();
					
					
					echo "</div>";
				
					if($data['displaydropdown'] == 'carousel'):
				
						add_action('wp_footer',create_function('$id',"echo \"
					
						<script type='text/javascript'>
						
						jQuery('.{$id}').elastislide({
	
							speed       : 450,	// animation speed
						
							easing      : '',	// animation easing effect	
						
							minItems	: 1			
						
						});
						
						</script>\";"),200);
					
					
					endif;
				endforeach;
			
			?>
			</div></div></div></div>
			<?php
			
			endif;
		   
		}
		
		function sds_WC_frontend_callback($atts){
			
			global $woocommerce;
			
			extract( shortcode_atts( array(
			  'id' => '',			  
		 	), $atts ) );
			
			if(!isset($woocommerce)) return ;
			
			
			ob_start();
			
			
			if(empty($id)):
				
				foreach($this->sortdata as $i=>$data):
							
					if($data['statusdropdown'] == 1):
					
						$carousel = '';
						
						$this->id = '';
						
						
						if($data['displaydropdown'] == 'carousel'):
						
							$carousel = 'jcarousel-skin-opencart';
						
							$this->id = "jcarousel-$i";
						
						endif;
						
						echo "<section class='featured span sds-wc-cat'>";
						
						switch($data['subcatsetdropdown']):
			
								case 1: 
									
									$this->sds_product_with_subcat($data);
									
									break;
							
								case 2: 
									
									$this->sds_product_with_tab($data);
									
									break;
			
								default:
									
									$this->sds_product_no_child_cat($data);
									
								break;
							
						endswitch;
						
						echo "</section>";
						
						
						if($data['displaydropdown'] == 'carousel' and $data['subcatsetdropdown'] < 2):
						
							$elid = $this->id;
						
							add_action('wp_footer',create_function('$elid',"echo \"
							<script type='text/javascript'>
							
							jQuery('#$elid').elastislide({
	
								speed       : 450,	// animation speed
							
								easing      : '',	// animation easing effect	
							
								minItems	: 1			
							
							});
							
							</script>\";"),200);
						endif;
						
					endif;
								
				endforeach;
			
			else:
			
			
				if(isset($this->sortdata[intval($id)-1])):
				
					$data = $this->sortdata[intval($id)-1];
					
					if($data['statusdropdown'] == 1):
											
						$carousel = '';
						
						$this->id = '';
						
						
						if($data['displaydropdown'] == 'carousel'):
						
							$carousel = 'jcarousel-skin-opencart';
						
							$this->id = "jcarousel-$id";
						
						endif;
						
						echo "<section class='featured span sds-wc-cat'>";
						
						switch($data['subcatsetdropdown']):
			
								case 1: 
									
									$this->sds_product_with_subcat($data);
									
									break;
							
								case 2: 
									
									$this->sds_product_with_tab($data);
									
									break;
			
								default:
									
									$this->sds_product_no_child_cat($data);
									
								break;
							
						endswitch;
						
						echo "</section>";
						
						
						if($data['displaydropdown'] == 'carousel' and $data['subcatsetdropdown'] < 2):
						
							$elid = $this->id;
						
							add_action('wp_footer',create_function('$elid',"echo \"
							<script type='text/javascript'>
							
							jQuery('#$elid').elastislide({
	
								speed       : 450,	// animation speed
							
								easing      : '',	// animation easing effect	
							
								minItems	: 1			
							
							});
							
							</script>\";"),200);
						endif;
						
					endif;
					
				endif;
			
			endif;
			
			$contents = ob_get_contents();
			
			ob_end_clean();
			
			return $contents;
			
			
		}
		
		
		
		
	}
	
	$sdswccat = new SDS_WC_frontend();
	
endif;

?>