<?php
/**
 * @package MegaMain
 * @subpackage MegaMain
 * @since mm 2.0
 */
	/* 
	 * Functions provide information about PHP configuration.
	 */
/*
	global $mega_main_menu;
	$current_class = $mega_main_menu;
	if ( isset( $_GET[ 'mm_page' ] ) && !empty( $_GET[ 'mm_page' ] ) ) {
		if ( $_GET[ 'mm_page' ] == 'phpinfo' ) {
			echo phpinfo();
			die();
		}
	}
*/
?>