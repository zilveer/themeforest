<?php
// Register Custom Post Type
function tb_add_post_type_team() {
    // Register taxonomy
    $labels = array(
            'name'              => _x( 'Team Category', 'taxonomy general name', 'jwsthemes' ),
            'singular_name'     => _x( 'Team Category', 'taxonomy singular name', 'jwsthemes' ),
            'search_items'      => __( 'Search Team Category', 'jwsthemes' ),
            'all_items'         => __( 'All Team Category', 'jwsthemes' ),
            'parent_item'       => __( 'Parent Team Category', 'jwsthemes' ),
            'parent_item_colon' => __( 'Parent Team Category:', 'jwsthemes' ),
            'edit_item'         => __( 'Edit Team Category', 'jwsthemes' ),
            'update_item'       => __( 'Update Team Category', 'jwsthemes' ),
            'add_new_item'      => __( 'Add New Team Category', 'jwsthemes' ),
            'new_item_name'     => __( 'New Team Category Name', 'jwsthemes' ),
            'menu_name'         => __( 'Team Category', 'jwsthemes' ),
    );

    $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'team_category' ),
    );
    if(function_exists('custom_reg_taxonomy')) {
        custom_reg_taxonomy( 'team_category', array( 'team' ), $args );
    }
    //Register tags
    $labels = array(
            'name'              => _x( 'Team Tag', 'taxonomy general name', 'jwsthemes' ),
            'singular_name'     => _x( 'Team Tag', 'taxonomy singular name', 'jwsthemes' ),
            'search_items'      => __( 'Search Team Tag', 'jwsthemes' ),
            'all_items'         => __( 'All Team Tag', 'jwsthemes' ),
            'parent_item'       => __( 'Parent Team Tag', 'jwsthemes' ),
            'parent_item_colon' => __( 'Parent Team Tag:', 'jwsthemes' ),
            'edit_item'         => __( 'Edit Team Tag', 'jwsthemes' ),
            'update_item'       => __( 'Update Team Tag', 'jwsthemes' ),
            'add_new_item'      => __( 'Add New Team Tag', 'jwsthemes' ),
            'new_item_name'     => __( 'New Team Tag Name', 'jwsthemes' ),
            'menu_name'         => __( 'Team Tag', 'jwsthemes' ),
    );

    $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'team_tag' ),
    );
    
    if(function_exists('custom_reg_taxonomy')) {
        custom_reg_taxonomy( 'team_tag', array( 'team' ), $args );
    }
    
    //Register post type Team
    $labels = array(
            'name'                => _x( 'Team', 'Post Type General Name', 'jwsthemes' ),
            'singular_name'       => _x( 'Team Item', 'Post Type Singular Name', 'jwsthemes' ),
            'menu_name'           => __( 'Team', 'jwsthemes' ),
            'parent_item_colon'   => __( 'Parent Item:', 'jwsthemes' ),
            'all_items'           => __( 'All Items', 'jwsthemes' ),
            'view_item'           => __( 'View Item', 'jwsthemes' ),
            'add_new_item'        => __( 'Add New Item', 'jwsthemes' ),
            'add_new'             => __( 'Add New', 'jwsthemes' ),
            'edit_item'           => __( 'Edit Item', 'jwsthemes' ),
            'update_item'         => __( 'Update Item', 'jwsthemes' ),
            'search_items'        => __( 'Search Item', 'jwsthemes' ),
            'not_found'           => __( 'Not found', 'jwsthemes' ),
            'not_found_in_trash'  => __( 'Not found in Trash', 'jwsthemes' ),
    );
    $args = array(
            'label'               => __( 'Team', 'jwsthemes' ),
            'description'         => __( 'Team Description', 'jwsthemes' ),
            'labels'              => $labels,
            'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', 'post-formats', ),
            'taxonomies'          => array( 'team_category', 'team_tag' ),
            'hierarchical'        => true,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'menu_icon'           => 'dashicons-groups',
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'page',
    );
    
    if(function_exists('custom_reg_post_type')) {
        custom_reg_post_type( 'team', $args );
    }
    
}

// Hook into the 'init' action
add_action( 'init', 'tb_add_post_type_team', 0 );
