<?php

if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// add shortcode recent_posts
function multipurpose_filter_recent_post_class($content) {
    return ' latest';
}

add_shortcode('recent_posts', 'multipurpose_recent_posts');

function multipurpose_recent_posts($atts, $content = null) {
    global $wpdb;
    add_filter('multipurpose_filters_recent_posts_class', 'multipurpose_filter_recent_post_class');
    $output = '';
	
	//category name paremeter set
	$category_name = '';
	if( !empty($atts['category_name']) ) {
		$category_name = $atts['category_name'];
	} 
	
    $args = array(
        'posts_per_page' => $atts['number_posts'],
        'orderby' => 'post_date',
        'order' => 'DESC',
        'post_type' => 'post',
        'post_status' => 'publish',
		'category_name' => $category_name,
        'suppress_filters' => true
    );
    
    $posts_array = get_posts($args);
    
    if (!empty($posts_array)) {
        foreach ($posts_array as $key_data => $val_data) {
            $comment = get_comment_count($val_data->ID);

            if ($atts['thumbnail'] == 'yes') {
                $output .='<article class="post">';
                if (has_post_thumbnail($val_data->ID)) {
                    $output .= '<a href="' . get_permalink($val_data->ID) . '">' . get_the_post_thumbnail($val_data->ID, 'post-thumbnail', $val_data->post_title) . '</a>';
                }
            } else {
                $output .='<article>';
            }

            if ($atts['headline'] == 'yes') {
                $output .= '<h3><a href="' . get_permalink($val_data->ID) . '">' . $val_data->post_title . '</a></h3>';
            }
            if ($atts['meta'] == 'yes') {
                $output .= '<p class="post-meta">' . get_the_time("F d, Y", $val_data->ID) . ' <span>|</span> <a href="' . get_permalink($val_data->ID) . '#comment">' . $comment["approved"];
			if($comment["approved"] == 1) {
				if (!empty($atts["translate_comment"])) {
					$output .= ' '.$atts["translate_comment"];
				} else {
					$output .= ' comment';
				}
			} else {
				if (!empty($atts["translate_comments"])) {
					$output .= ' '.$atts["translate_comments"];
				} else {
					$output .= ' comments';
				}
			} 
			$output .= '</a></p>';
            }
            if ($atts['excerpt'] == 'yes') {
                if (!empty($val_data->post_excerpt)) {
					$output .= '<p>' . multipurpose_cut_character_word($atts["excerpt_words"], $val_data->post_excerpt, $atts["strip_html"]) . '</p>';
                } elseif (!empty($val_data->post_content)) {
                    $output .= '<p>' . multipurpose_cut_character_word($atts["excerpt_words"], $val_data->post_content, $atts["strip_html"]) . '</p>';
                }
            }


            if (isset($atts['read_more']) && !empty($atts['read_more']))
                $output .= '<p class="more"><a href="' . get_permalink($val_data->ID) . '">' . $atts['read_more'] . '</a></p>';
            $output.= '</article>';
        }
    }

    return $output;
}
