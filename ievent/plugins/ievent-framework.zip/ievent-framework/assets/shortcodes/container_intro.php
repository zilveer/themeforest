<?php 

	/* Container  ---------------------------------------------*/
	
	add_shortcode('container_intro', 'jx_ievent_container_intro');
	
	function jx_ievent_container_intro($atts, $content = null) { 
		extract(shortcode_atts(array(
			'bg_color' => '',
			'bg_image' => '',
			'bg_icon' => '',
			'class' => '',
			'id' => '',
			'container_class' => ''
			
			
			
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		$background_color ="";
		
		if($bg_color =="white") {
		$background_color ="jx-ievent-white-bg";
		} elseif ($bg_color =="grey") {
		$background_color ="jx-ievent-grey-bg";
		} elseif ($bg_color =="default") {
		$background_color ="jx-ievent-default-bg";
		}
		
		if (($bg_image =="") and ($bg_color=="default")) {
			$parallax_image ="<div class='parallax-no jx-ievent-default-bg'></div>";
		} else {
			$parallax_image ="<div class='parallax-no-height jx-ievent-tint-black' style='background-image:url(".$bg_image.");'></div>";
		}
		
		if($bg_icon =="") {
		$background_icon ="";
		} else {
		$background_icon ="<div class='container-bg-icon'><i class='fa ".$bg_icon."'></i></div>";
		}
		
		//function code
			
			$out ='
			<div id="'.$id.'" class="jx-ievent-container container-no-margin jx-ievent-padding '.$class.'">
				'.$parallax_image.'
				<!-- Background Image -->
				'.$background_icon.'
				<!-- Background Icon -->
				<div class="container '.$container_class.'">'.do_shortcode($content).'</div>
			</div>
			';
			

		//return output
		return $out;
	}


?>