<?php 

add_action('wp_update_nav_menu_item', 'custom_nav_update',10, 3);
function custom_nav_update($menu_id, $menu_item_db_id, $args ) {
    if(empty($_REQUEST['menu-item-iconvalue'])){
        update_post_meta( $menu_item_db_id, '_menu_item_iconvalue', '0' );
	}else{
		if ( is_array($_REQUEST['menu-item-iconvalue']) ) {
        $custom_value = $_REQUEST['menu-item-iconvalue'][$menu_item_db_id];
        update_post_meta( $menu_item_db_id, '_menu_item_iconvalue', $custom_value );
    }
	}
	
	if(empty($_REQUEST['menu-item-iconvalued'])){
        update_post_meta( $menu_item_db_id, '_menu_item_iconvalued', '0' );
	}else{
		if ( is_array($_REQUEST['menu-item-iconvalued']) ) {
			$custom_value = $_REQUEST['menu-item-iconvalued'][$menu_item_db_id];
			update_post_meta( $menu_item_db_id, '_menu_item_iconvalued', $custom_value );
		}
	}
	
	if(empty($_REQUEST['menu-item-uploadicon'])){
        update_post_meta( $menu_item_db_id, '_menu_item_uploadicon', '' );
	}else{
		if ( is_array($_REQUEST['menu-item-uploadicon']) ) {
			$custom_value = $_REQUEST['menu-item-uploadicon'][$menu_item_db_id];
			update_post_meta( $menu_item_db_id, '_menu_item_uploadicon', $custom_value );
		}
	}
	
	if(empty($_REQUEST['menu-item-iconbgcolor'])){
        update_post_meta( $menu_item_db_id, '_menu_item_iconbgcolor', '' );// Icon bg color default
	}else{
		if ( is_array($_REQUEST['menu-item-iconbgcolor']) ) {
			$custom_value = $_REQUEST['menu-item-iconbgcolor'][$menu_item_db_id];
			update_post_meta( $menu_item_db_id, '_menu_item_iconbgcolor', $custom_value );
		}
	}
	
	if(empty($_REQUEST['menu-item-iconbordercolor'])){
        update_post_meta( $menu_item_db_id, '_menu_item_iconbordercolor', '' );// Icon border color default
	}else{
		if ( is_array($_REQUEST['menu-item-iconbordercolor']) ) {
			$custom_value = $_REQUEST['menu-item-iconbordercolor'][$menu_item_db_id];
			update_post_meta( $menu_item_db_id, '_menu_item_iconbordercolor', $custom_value );
		}
	}
	
	if(empty($_REQUEST['menu-item-iconbgopacity'])){
        update_post_meta( $menu_item_db_id, '_menu_item_iconbgopacity', '' );// Icon bg opacity default
	}else{
		if ( is_array($_REQUEST['menu-item-iconbgopacity']) ) {
			$custom_value = $_REQUEST['menu-item-iconbgopacity'][$menu_item_db_id];
			update_post_meta( $menu_item_db_id, '_menu_item_iconbgopacity', $custom_value );
		}
	}
	
	
	if(empty($_REQUEST['menu-item-iconborderopacity'])){
        update_post_meta( $menu_item_db_id, '_menu_item_iconborderopacity', '' );// Icon border opacity default
	}else{
		if ( is_array($_REQUEST['menu-item-iconborderopacity']) ) {
			$custom_value = $_REQUEST['menu-item-iconborderopacity'][$menu_item_db_id];
			update_post_meta( $menu_item_db_id, '_menu_item_iconborderopacity', $custom_value );
		}
	}
	
	if(empty($_REQUEST['menu-item-icontextcolor'])){
        update_post_meta( $menu_item_db_id, '_menu_item_icontextcolor', '' );// Icon bg color default
	}else{
		if ( is_array($_REQUEST['menu-item-icontextcolor']) ) {
			$custom_value = $_REQUEST['menu-item-icontextcolor'][$menu_item_db_id];
			update_post_meta( $menu_item_db_id, '_menu_item_icontextcolor', $custom_value );
		}
	}
}

add_filter( 'wp_setup_nav_menu_item','custom_nav_item' );
function custom_nav_item($menu_item) {
    $menu_item->iconvalue = get_post_meta( $menu_item->ID, '_menu_item_iconvalue', true );
	$menu_item->iconvalued = get_post_meta( $menu_item->ID, '_menu_item_iconvalued', true );
	$menu_item->uploadicon = get_post_meta( $menu_item->ID, '_menu_item_uploadicon', true );
	$menu_item->iconbgcolor = get_post_meta( $menu_item->ID, '_menu_item_iconbgcolor', true );
	$menu_item->iconbordercolor = get_post_meta( $menu_item->ID, '_menu_item_iconbordercolor', true );
	$menu_item->iconbgopacity = get_post_meta( $menu_item->ID, '_menu_item_iconbgopacity', true );
	$menu_item->iconborderopacity = get_post_meta( $menu_item->ID, '_menu_item_iconborderopacity', true );
	$menu_item->icontextcolor = get_post_meta( $menu_item->ID, '_menu_item_icontextcolor', true );
    return $menu_item;
}

add_filter( 'wp_edit_nav_menu_walker', 'custom_nav_edit_walker',10,2 );
function custom_nav_edit_walker($walker,$menu_id) {
    return 'Walker_Nav_Menu_Edit_Custom_Aura';
}

class Walker_Nav_Menu_Edit_Custom_Aura extends Walker_Nav_Menu  {
function start_lvl( &$output, $depth = 0, $args = array() ) {}
function end_lvl(&$output, $depth = 0, $args = array()) {
}

function start_el(&$output, $item = array(), $depth = 0, $args = array(), $id = 0) {
    global $_wp_nav_menu_max_depth;
	global $webbumobile_option; // Get options from options panel.
	
    $_wp_nav_menu_max_depth = $depth > $_wp_nav_menu_max_depth ? $depth : $_wp_nav_menu_max_depth;

    $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

    ob_start();
    $item_id = esc_attr( $item->ID );
    $removed_args = array(
        'action',
        'customlink-tab',
        'edit-menu-item',
        'menu-item',
        'page-tab',
        '_wpnonce',
    );

    $original_title = '';
    if ( 'taxonomy' == $item->type ) {
        $original_title = get_term_field( 'name', $item->object_id, $item->object, 'raw' );
        if ( is_wp_error( $original_title ) )
            $original_title = false;
    } elseif ( 'post_type' == $item->type ) {
        $original_object = get_post( $item->object_id );
        $original_title = $original_object->post_title;
    }

    $classes = array(
        'menu-item menu-item-depth-' . $depth,
        'menu-item-' . esc_attr( $item->object ),
        'menu-item-edit-' . ( ( isset( $_GET['edit-menu-item'] ) && $item_id == $_GET['edit-menu-item'] ) ? 'active' : 'inactive'),
    );

    $title = $item->title;

    if ( ! empty( $item->_invalid ) ) {
        $classes[] = 'menu-item-invalid';
        $title = sprintf( __( '%s (Invalid)' , 'aurat2d'), $item->title );
    } elseif ( isset( $item->post_status ) && 'draft' == $item->post_status ) {
        $classes[] = 'pending';
        $title = sprintf( __('%s (Pending)', 'aurat2d'), $item->title );
    }

    $title = empty( $item->label ) ? $title : $item->label;

    ?>
    <li id="menu-item-<?php echo $item_id; ?>" class="<?php echo implode(' ', $classes ); ?>">
        <dl class="menu-item-bar">
            <dt class="menu-item-handle">
                <span class="item-title"><?php echo esc_html( $title ); ?></span>
                <span class="item-controls">
                    <span class="item-type"><?php echo esc_html( $item->type_label ); ?></span>
                    <span class="item-order hide-if-js">
                        <a href="<?php
                            echo wp_nonce_url(
                                add_query_arg(
                                    array(
                                        'action' => 'move-up-menu-item',
                                        'menu-item' => $item_id,
                                    ),
                                    remove_query_arg($removed_args, admin_url( 'nav-menus.php' ) )
                                ),
                                'move-menu_item'
                            );
                        ?>" class="item-move-up"><abbr title="<?php esc_attr_e('Move up', 'aurat2d'); ?>">&#8593;</abbr></a>
                        |
                        <a href="<?php
                            echo wp_nonce_url(
                                add_query_arg(
                                    array(
                                        'action' => 'move-down-menu-item',
                                        'menu-item' => $item_id,
                                    ),
                                    remove_query_arg($removed_args, admin_url( 'nav-menus.php' ) )
                                ),
                                'move-menu_item'
                            );
                        ?>" class="item-move-down"><abbr title="<?php esc_attr_e('Move down'); ?>">&#8595;</abbr></a>
                    </span>
                    <a class="item-edit" id="edit-<?php echo $item_id; ?>" title="<?php esc_attr_e('Edit Menu Item', 'aurat2d'); ?>" href="<?php
                        echo ( isset( $_GET['edit-menu-item'] ) && $item_id == $_GET['edit-menu-item'] ) ? admin_url( 'nav-menus.php' ) : add_query_arg( 'edit-menu-item', $item_id, remove_query_arg( $removed_args, admin_url( 'nav-menus.php#menu-item-settings-' . $item_id ) ) );
                    ?>"><?php _e( 'Edit Menu Item', 'aurat2d' ); ?></a>
                </span>
            </dt>
        </dl>

        <div class="menu-item-settings" id="menu-item-settings-<?php echo $item_id; ?>">
            <?php if( 'custom' == $item->type ) : ?>
                <p class="field-url description description-wide">
                    <label for="edit-menu-item-url-<?php echo $item_id; ?>">
                        <?php _e( 'URL', 'aurat2d' ); ?><br />
                        <input type="text" id="edit-menu-item-url-<?php echo $item_id; ?>" class="widefat code edit-menu-item-url" name="menu-item-url[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->url ); ?>" />
                    </label>
                </p>
            <?php endif; ?>
            <p class="description description-thin">
                <label for="edit-menu-item-title-<?php echo $item_id; ?>">
                    <?php _e( 'Navigation Label', 'aurat2d' ); ?><br />
                    <input type="text" id="edit-menu-item-title-<?php echo $item_id; ?>" class="widefat edit-menu-item-title" name="menu-item-title[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->title ); ?>" />
                </label>
            </p>
            <p class="description description-thin">
                <label for="edit-menu-item-attr-title-<?php echo $item_id; ?>">
                    <?php _e( 'Title Attribute', 'aurat2d' ); ?><br />
                    <input type="text" id="edit-menu-item-attr-title-<?php echo $item_id; ?>" class="widefat edit-menu-item-attr-title" name="menu-item-attr-title[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->post_excerpt ); ?>" />
                </label>
            </p>
            <p class="field-link-target description">
                <label for="edit-menu-item-target-<?php echo $item_id; ?>">
                    <input type="checkbox" id="edit-menu-item-target-<?php echo $item_id; ?>" value="_blank" name="menu-item-target[<?php echo $item_id; ?>]"<?php checked( $item->target, '_blank' ); ?> />
                    <?php _e( 'Open link in a new window/tab', 'aurat2d' ); ?>
                </label>
            </p>
            <p class="field-css-classes description description-thin">
                <label for="edit-menu-item-classes-<?php echo $item_id; ?>">
                    <?php _e( 'CSS Classes (optional)', 'aurat2d' ); ?><br />
                    <input type="text" id="edit-menu-item-classes-<?php echo $item_id; ?>" class="widefat code edit-menu-item-classes" name="menu-item-classes[<?php echo $item_id; ?>]" value="<?php echo esc_attr( implode(' ', $item->classes ) ); ?>" />
                </label>
            </p>
            <p class="field-xfn description description-thin">
                <label for="edit-menu-item-xfn-<?php echo $item_id; ?>">
                    <?php _e( 'Link Relationship (XFN)', 'aurat2d' ); ?><br />
                    <input type="text" id="edit-menu-item-xfn-<?php echo $item_id; ?>" class="widefat code edit-menu-item-xfn" name="menu-item-xfn[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->xfn ); ?>" />
                </label>
            </p>
            <p class="field-description description description-wide">
                <label for="edit-menu-item-description-<?php echo $item_id; ?>">
                    <?php _e( 'Description', 'aurat2d' ); ?><br />
                    <textarea id="edit-menu-item-description-<?php echo $item_id; ?>" class="widefat edit-menu-item-description" rows="3" cols="20" name="menu-item-description[<?php echo $item_id; ?>]"><?php echo esc_html( $item->description ); // textarea_escaped ?></textarea>
                    <span class="description"><?php _e('The description will be displayed in the menu if the current theme supports it.', 'aurat2d'); ?></span>
                </label>
            </p>        
            <?php
            /*
             * Icon Field ------------------------------------------------------------------------
             */
            ?>  
            <p class="field-breakline description description-wide"></p>
            
            <p class="field-iconname description description-wide auramobile-select2-wrapper">
                <label for="edit-menu-item-iconname-<?php echo $item_id; ?>">
                    <?php _e( 'Icon Name', 'aurat2d' ); ?><br />
                   
                    <select name="menu-item-iconname[<?php echo $item_id; ?>]" id="edit-menu-item-iconname-<?php echo $item_id; ?>" class="input-block-level aura_wpmse_select2_<?php echo $item_id; ?>" required>
                    	<?php if($item->iconvalue != ''){?>
                        <option value="<?php echo esc_attr( $item->iconvalue ); ?>" data-icon="<?php echo esc_attr( $item->iconvalued ); ?>" selected><?php echo esc_attr( $item->iconvalue ); ?></option>
                        <?php }else{?>
                        <option value="0" data-icon="0"><?php echo __('Please Select an Icon','aurat2d');?></option>
                        <?php }?>
                        <option value="Glass" data-icon="glass">f000</option>
                        <option value="Music" data-icon="music">f001</option>
                        <option value="Search" data-icon="search">f002</option>
                        <option value="Envelope Alt" data-icon="envelope-alt">f003</option>
                        <option value="Heart" data-icon="heart">f004</option>
                        <option value="Star" data-icon="star">f005</option>
                        <option value="Star Empty" data-icon="star-empty">f006</option>
                        <option value="User" data-icon="user">f007</option>
                        <option value="Film" data-icon="film">f008</option>
                        <option value="th-large" data-icon="th-large">f009</option>
                        <option value="th" data-icon="th">f00a</option>
                        <option value="th-list" data-icon="th-list">f00b</option>
                        <option value="OK" data-icon="ok">f00c</option>
                        <option value="Remove" data-icon="remove">f00d</option>
                        <option value="Zoom In" data-icon="zoom-in">f00e</option>
                        <option value="Zoom Out" data-icon="zoom-out">f010</option>
                        <option value="Off" data-icon="off">f011</option>
                        <option value="signal" data-icon="signal">f012</option>
                        <option value="cog" data-icon="cog">f013</option>
                        <option value="trash" data-icon="trash">f014</option>
                        <option value="home" data-icon="home">f015</option>
                        <option value="file-alt" data-icon="file-alt">f016</option>
                        <option value="time" data-icon="time">f017</option>
                        <option value="road" data-icon="road">f018</option>
                        <option value="download-alt" data-icon="download-alt">f019</option>
                        <option value="download" data-icon="download">f01a</option>
                        <option value="upload" data-icon="upload">f01b</option>
                        <option value="inbox" data-icon="inbox">f01c</option>
                        <option value="play-circle" data-icon="play-circle">f01d</option>
                        <option value="repeat" data-icon="repeat">f01e</option>
                        <option value="refresh" data-icon="refresh">f021</option>
                        <option value="list-alt" data-icon="list-alt">f022</option>
                        <option value="lock" data-icon="lock">f023</option>
                        <option value="flag" data-icon="flag">f024</option>
                        <option value="headphones" data-icon="headphones">f025</option>
                        <option value="volume-off" data-icon="volume-off">f026</option>
                        <option value="volume-down" data-icon="volume-down">f027</option>
                        <option value="volume-up" data-icon="volume-up">f028</option>
                        <option value="qrcode" data-icon="qrcode">f029</option>
                        <option value="barcode" data-icon="barcode">f02a</option>
                        <option value="tag" data-icon="tag">f02b</option>
                        <option value="tags" data-icon="tags">f02c</option>
                        <option value="book" data-icon="book">f02d</option>
                        <option value="bookmark" data-icon="bookmark">f02e</option>
                        <option value="print" data-icon="print">f02f</option>
                        <option value="camera" data-icon="camera">f030</option>
                        <option value="font" data-icon="font">f031</option>
                        <option value="bold" data-icon="bold">f032</option>
                        <option value="italic" data-icon="italic">f033</option>
                        <option value="text-height" data-icon="text-height">f034</option>
                        <option value="text-width" data-icon="text-width">f035</option>
                        <option value="align-left" data-icon="align-left">f036</option>
                        <option value="align-center" data-icon="align-center">f037</option>
                        <option value="align-right" data-icon="align-right">f038</option>
                        <option value="align-justify" data-icon="align-justify">f039</option>
                        <option value="list" data-icon="list">f03a</option>
                        <option value="indent-left" data-icon="indent-left">f03b</option>
                        <option value="indent-right" data-icon="indent-right">f03c</option>
                        <option value="facetime-video" data-icon="facetime-video">f03d</option>
                        <option value="picture" data-icon="picture">f03e</option>
                        <option value="pencil" data-icon="pencil">f040</option>
                        <option value="map-marker" data-icon="map-marker">f041</option>
                        <option value="adjust" data-icon="adjust">f042</option>
                        <option value="tint" data-icon="tint">f043</option>
                        <option value="edit" data-icon="edit">f044</option>
                        <option value="share" data-icon="share">f045</option>
                        <option value="check" data-icon="check">f046</option>
                        <option value="move" data-icon="move">f047</option>
                        <option value="step-backward" data-icon="step-backward">f048</option>
                        <option value="fast-backward" data-icon="fast-backward">f049</option>
                        <option value="backward" data-icon="backward">f04a</option>
                        <option value="play" data-icon="play">f04b</option>
                        <option value="pause" data-icon="pause">f04c</option>
                        <option value="stop" data-icon="stop">f04d</option>
                        <option value="forward" data-icon="forward">f04e</option>
                        <option value="fast-forward" data-icon="fast-forward">f050</option>
                        <option value="step-forward" data-icon="step-forward">f051</option>
                        <option value="eject" data-icon="eject">f052</option>
                        <option value="chevron-left" data-icon="chevron-left">f053</option>
                        <option value="chevron-right" data-icon="chevron-right">f054</option>
                        <option value="plus-sign" data-icon="plus-sign">f055</option>
                        <option value="minus-sign" data-icon="minus-sign">f056</option>
                        <option value="remove-sign" data-icon="remove-sign">f057</option>
                        <option value="ok-sign" data-icon="ok-sign">f058</option>
                        <option value="question-sign" data-icon="question-sign">f059</option>
                        <option value="info-sign" data-icon="info-sign">f05a</option>
                        <option value="screenshot" data-icon="screenshot">f05b</option>
                        <option value="remove-circle" data-icon="remove-circle">f05c</option>
                        <option value="ok-circle" data-icon="ok-circle">f05d</option>
                        <option value="ban-circle" data-icon="ban-circle">f05e</option>
                        <option value="arrow-left" data-icon="arrow-left">f060</option>
                        <option value="arrow-right" data-icon="arrow-right">f061</option>
                        <option value="arrow-up" data-icon="arrow-up">f062</option>
                        <option value="arrow-down" data-icon="arrow-down">f063</option>
                        <option value="share-alt" data-icon="share-alt">f064</option>
                        <option value="resize-full" data-icon="resize-full">f065</option>
                        <option value="resize-small" data-icon="resize-small">f066</option>
                        <option value="plus" data-icon="plus">f067</option>
                        <option value="minus" data-icon="minus">f068</option>
                        <option value="asterisk" data-icon="asterisk">f069</option>
                        <option value="exclamation-sign" data-icon="exclamation-sign">f06a</option>
                        <option value="gift" data-icon="gift">f06b</option>
                        <option value="leaf" data-icon="leaf">f06c</option>
                        <option value="fire" data-icon="fire">f06d</option>
                        <option value="eye-open" data-icon="eye-open">f06e</option>
                        <option value="eye-close" data-icon="eye-close">f070</option>
                        <option value="warning-sign" data-icon="warning-sign">f071</option>
                        <option value="plane" data-icon="plane">f072</option>
                        <option value="calendar" data-icon="calendar">f073</option>
                        <option value="random" data-icon="random">f074</option>
                        <option value="comment" data-icon="comment">f075</option>
                        <option value="magnet" data-icon="magnet">f076</option>
                        <option value="chevron-up" data-icon="chevron-up">f077</option>
                        <option value="chevron-down" data-icon="chevron-down">f078</option>
                        <option value="retweet" data-icon="retweet">f079</option>
                        <option value="shopping-cart" data-icon="shopping-cart">f07a</option>
                        <option value="folder-close" data-icon="folder-close">f07b</option>
                        <option value="folder-open" data-icon="folder-open">f07c</option>
                        <option value="resize-vertical" data-icon="resize-vertical">f07d</option>
                        <option value="resize-horizontal" data-icon="resize-horizontal">f07e</option>
                        <option value="bar-chart" data-icon="bar-chart">f080</option>
                        <option value="twitter-sign" data-icon="twitter-sign">f081</option>
                        <option value="facebook-sign" data-icon="facebook-sign">f082</option>
                        <option value="camera-retro" data-icon="camera-retro">f083</option>
                        <option value="key" data-icon="key">f084</option>
                        <option value="cogs" data-icon="cogs">f085</option>
                        <option value="comments" data-icon="comments">f086</option>
                        <option value="thumbs-up-alt" data-icon="thumbs-up-alt">f087</option>
                        <option value="thumbs-down-alt" data-icon="thumbs-down-alt">f088</option>
                        <option value="star-half" data-icon="star-half">f089</option>
                        <option value="heart-empty" data-icon="heart-empty">f08a</option>
                        <option value="signout" data-icon="signout">f08b</option>
                        <option value="linkedin-sign" data-icon="linkedin-sign">f08c</option>
                        <option value="pushpin" data-icon="pushpin">f08d</option>
                        <option value="external link" data-icon="external-link">f08e</option>
                        <option value="signin" data-icon="signin">f090</option>
                        <option value="trophy" data-icon="trophy">f091</option>
                        <option value="github sign" data-icon="github-sign">f092</option>
                        <option value="upload alt" data-icon="upload-alt">f093</option>
                        <option value="lemon" data-icon="lemon">f094</option>
                        <option value="phone" data-icon="phone">f095</option>
                        <option value="check-empty" data-icon="check-empty">f096</option>
                        <option value="bookmark-empty" data-icon="bookmark-empty">f097</option>
                        <option value="phone-sign" data-icon="phone-sign">f098</option>
                        <option value="twitter" data-icon="twitter">f099</option>
                        <option value="facebook" data-icon="facebook">f09a</option>
                        <option value="github" data-icon="github">f09b</option>
                        <option value="unlock" data-icon="unlock">f09c</option>
                        <option value="credit-card" data-icon="credit-card">f09d</option>
                        <option value="rss" data-icon="rss">f09e</option>
                        <option value="hdd" data-icon="hdd">f0a0</option>
                        <option value="bullhorn" data-icon="bullhorn">f0a1</option>
                        <option value="bell" data-icon="bell">f0a2</option>
                        <option value="certificate" data-icon="certificate">f0a3</option>
                        <option value="hand right" data-icon="hand-right">f0a4</option>
                        <option value="hand left" data-icon="hand-left">f0a5</option>
                        <option value="hand up" data-icon="hand-up">f0a6</option>
                        <option value="hand down" data-icon="hand-down">f0a7</option>
                        <option value="circle arrow left" data-icon="circle-arrow-left">f0a8</option>
                        <option value="circle arrow right" data-icon="circle-arrow-right">f0a9</option>
                        <option value="circle arrow up" data-icon="circle-arrow-up">f0aa</option>
                        <option value="circle arrow down" data-icon="circle-arrow-down">f0ab</option>
                        <option value="globe" data-icon="globe">f0ac</option>
                        <option value="wrench" data-icon="wrench">f0ad</option>
                        <option value="tasks" data-icon="tasks">f0ae</option>
                        <option value="filter" data-icon="filter">f0b0</option>
                        <option value="briefcase" data-icon="briefcase">f0b1</option>
                        <option value="fullscreen" data-icon="fullscreen">f0b2</option>
                        <option value="group" data-icon="group">f0c0</option>
                        <option value="link" data-icon="link">f0c1</option>
                        <option value="cloud" data-icon="cloud">f0c2</option>
                        <option value="beaker" data-icon="beaker">f0c3</option>
                        <option value="cut" data-icon="cut">f0c4</option>
                        <option value="copy" data-icon="copy">f0c5</option>
                        <option value="paper clip" data-icon="paper-clip">f0c6</option>
                        <option value="save" data-icon="save">f0c7</option>
                        <option value="sign blank" data-icon="sign-blank">f0c8</option>
                        <option value="reorder" data-icon="reorder">f0c9</option>
                        <option value="list ul" data-icon="list-ul">f0ca</option>
                        <option value="list ol" data-icon="list-ol">f0cb</option>
                        <option value="strikethrough" data-icon="strikethrough">f0cc</option>
                        <option value="underline" data-icon="underline">f0cd</option>
                        <option value="table" data-icon="table">f0ce</option>
                        <option value="magic" data-icon="magic">f0d0</option>
                        <option value="truck" data-icon="truck">f0d1</option>
                        <option value="pinterest" data-icon="pinterest">f0d2</option>
                        <option value="pinterest sign" data-icon="pinterest-sign">f0d3</option>
                        <option value="google plus sign" data-icon="google-plus-sign">f0d4</option>
                        <option value="google plus" data-icon="google-plus">f0d5</option>
                        <option value="money" data-icon="money">f0d6</option>
                        <option value="caret down" data-icon="caret-down">f0d7</option>
                        <option value="caret up" data-icon="caret-up">f0d8</option>
                        <option value="caret left" data-icon="caret-left">f0d9</option>
                        <option value="caret right" data-icon="caret-right">f0da</option>
                        <option value="columns" data-icon="columns">f0db</option>
                        <option value="sort" data-icon="sort">f0dc</option>
                        <option value="sort down" data-icon="sort-down">f0dd</option>
                        <option value="sort up" data-icon="sort-up">f0de</option>
                        <option value="Envelope" data-icon="envelope">f0e0</option>
                        <option value="linkedin" data-icon="linkedin">f0e1</option>
                        <option value="undo" data-icon="undo">f0e2</option>
                        <option value="legal" data-icon="legal">f0e3</option>
                        <option value="dashboard" data-icon="dashboard">f0e4</option>
                        <option value="comment alt" data-icon="comment-alt">f0e5</option>
                        <option value="comments alt" data-icon="comments-alt">f0e6</option>
                        <option value="bolt" data-icon="bolt">f0e7</option>
                        <option value="sitemap" data-icon="sitemap">f0e8</option>
                        <option value="umbrella" data-icon="umbrella">f0e9</option>
                        <option value="paste" data-icon="paste">f0ea</option>
                        <option value="lightbulb" data-icon="lightbulb">f0eb</option>
                        <option value="exchange" data-icon="exchange">f0ec</option>
                        <option value="cloud download" data-icon="cloud-download">f0ed</option>
                        <option value="cloud upload" data-icon="cloud-upload">f0ee</option>
                        <option value="user md" data-icon="user-md">f0f0</option>
                        <option value="stethoscope" data-icon="stethoscope">f0f1</option>
                        <option value="suitcase" data-icon="suitcase">f0f2</option>
                        <option value="bell alt" data-icon="bell-alt">f0f3</option>
                        <option value="coffee" data-icon="coffee">f0f4</option>
                        <option value="food" data-icon="food">f0f5</option>
                        <option value="file text alt" data-icon="file-text-alt">f0f6</option>
                        <option value="building" data-icon="building">f0f7</option>
                        <option value="hospital" data-icon="hospital">f0f8</option>
                        <option value="ambulance" data-icon="ambulance">f0f9</option>
                        <option value="medkit" data-icon="medkit">f0fa</option>
                        <option value="fighter-jet" data-icon="fighter-jet">f0fb</option>
                        <option value="beer" data-icon="beer">f0fc</option>
                        <option value="h sign" data-icon="h-sign">f0fd</option>
                        <option value="plus sign alt" data-icon="plus-sign-alt">f0fe</option>
                        <option value="double angle left" data-icon="double-angle-left">f100</option>
                        <option value="double angle right" data-icon="double-angle-right">f101</option>
                        <option value="double angle up" data-icon="double-angle-up">f102</option>
                        <option value="double angle down" data-icon="double-angle-down">f103</option>
                        <option value="angle left" data-icon="angle-left">f104</option>
                        <option value="angle right" data-icon="angle-right">f105</option>
                        <option value="angle up" data-icon="angle-up">f106</option>
                        <option value="angle down" data-icon="angle-down">f107</option>
                        <option value="desktop" data-icon="desktop">f108</option>
                        <option value="laptop" data-icon="laptop">f109</option>
                        <option value="tablet" data-icon="tablet">f10a</option>
                        <option value="mobile phone" data-icon="mobile-phone">f10b</option>
                        <option value="circle blank" data-icon="circle-blank">f10c</option>
                        <option value="quote left" data-icon="quote-left">f10d</option>
                        <option value="quote right" data-icon="quote-right">f10e</option>
                        <option value="spinner" data-icon="spinner">f110</option>
                        <option value="circle" data-icon="circle">f111</option>
                        <option value="reply" data-icon="reply">f112</option>
                        <option value="github alt" data-icon="github-alt">f113</option>
                        <option value="folder close-alt" data-icon="folder-close-alt">f114</option>
                        <option value="folder open-alt" data-icon="folder-open-alt">f115</option>
                        <option value="expand alt" data-icon="expand-alt">f116</option>
                        <option value="collapse alt" data-icon="collapse-alt">f117</option>
                        <option value="smile" data-icon="smile">f118</option>
                        <option value="frown" data-icon="frown">f119</option>
                        <option value="meh" data-icon="meh">f11a</option>
                        <option value="gamepad" data-icon="gamepad">f11b</option>
                        <option value="keyboard" data-icon="keyboard">f11c</option>
                        <option value="Flag Alt" data-icon="flag-alt">f11d</option>
                        <option value="Flag Checkered" data-icon="flag-checkered">f11e</option>
                        <option value="Terminal" data-icon="terminal">f120</option>
                        <option value="Code" data-icon="code">f121</option>
                        <option value="Reply All" data-icon="reply-all">f122</option>
                        <option value="Mail Reply All" data-icon="mail-reply-all">f122</option>
                        <option value="Star Half Empty" data-icon="star-half-empty">f123</option>
                        <option value="Location Arrow" data-icon="location-arrow">f124</option>
                        <option value="Crop" data-icon="crop">f125</option>
                        <option value="Code Fork" data-icon="code-fork">f126</option>
                        <option value="Unlink" data-icon="unlink">f127</option>
                        <option value="Question" data-icon="question">f128</option>
                        <option value="Info" data-icon="info">f129</option>
                        <option value="Exclamation" data-icon="exclamation">f12a</option>
                        <option value="Superscript" data-icon="superscript">f12b</option>
                        <option value="Subscript" data-icon="subscript">f12c</option>
                        <option value="Eraser" data-icon="eraser">f12d</option>
                        <option value="Puzzle Piece" data-icon="puzzle-piece">f12e</option>
                        <option value="Microphone" data-icon="microphone">f130</option>
                        <option value="Microphone-off" data-icon="microphone-off">f131</option>
                        <option value="Shield" data-icon="shield">f132</option>
                        <option value="Calendar Empty" data-icon="calendar-empty">f133</option>
                        <option value="Fire Extinguisher" data-icon="fire-extinguisher">f134</option>
                        <option value="Rocket" data-icon="rocket">f135</option>
                        <option value="MaxCDN" data-icon="maxcdn">f136</option>
                        <option value="Chevron Sign Left" data-icon="chevron-sign-left">f137</option>
                        <option value="Chevron Sign Right" data-icon="chevron-sign-right">f138</option>
                        <option value="Chevron Sign Up" data-icon="chevron-sign-up">f139</option>
                        <option value="Chevron Sign Down" data-icon="chevron-sign-down">f13a</option>
                        <option value="HTML 5 Logo" data-icon="html5">f13b</option>
                        <option value="CSS 3 Logo" data-icon="css3">f13c</option>
                        <option value="Anchor" data-icon="anchor">f13d</option>
                        <option value="Unlock Alt" data-icon="unlock-alt">f13e</option>
                        <option value="Bullseye" data-icon="bullseye">f140</option>
                        <option value="Horizontal Ellipsis" data-icon="ellipsis-horizontal">f141</option>
                        <option value="Vertical Ellipsis" data-icon="ellipsis-vertical">f142</option>
                        <option value="RSS Sign" data-icon="rss-sign">f143</option>
                        <option value="Play Sign" data-icon="play-sign">f144</option>
                        <option value="Ticket" data-icon="ticket">f145</option>
                        <option value="Minus Sign Alt" data-icon="minus-sign-alt">f146</option>
                        <option value="Check Minus" data-icon="check-minus">f147</option>
                        <option value="Level Up" data-icon="level-up">f148</option>
                        <option value="Level Down" data-icon="level-down">f149</option>
                        <option value="Check Sign" data-icon="check-sign">f14a</option>
                        <option value="Edit Sign" data-icon="edit-sign">f14b</option>
                        <option value="Exteral Link Sign" data-icon="external-link-sign">f14c</option>
                        <option value="Share Sign" data-icon="share-sign">f14d</option>
                        <option value="Compass" data-icon="compass">f14e</option>
                        <option value="Collapse" data-icon="collapse">f150</option>
                        <option value="Collapse Top" data-icon="collapse-top">f151</option>
                        <option value="Expand" data-icon="expand">f152</option>
                        <option value="Euro (EUR)" data-icon="eur">f153</option>
                        <option value="GBP" data-icon="gbp">f154</option>
                        <option value="US Dollar" data-icon="usd">f155</option>
                        <option value="Indian Rupee (INR)" data-icon="inr">f156</option>
                        <option value="Japanese Yen (JPY)" data-icon="jpy">f157</option>
                        <option value="Renminbi (CNY)" data-icon="cny">f158</option>
                        <option value="Korean Won (KRW)" data-icon="krw">f159</option>
                        <option value="Bitcoin (BTC)" data-icon="btc">f15a</option>
                        <option value="File" data-icon="file">f15b</option>
                        <option value="File Text" data-icon="file-text">f15c</option>
                        <option value="Sort By Alphabet" data-icon="sort-by-alphabet">f15d</option>
                        <option value="Sort By Alphabet Alt" data-icon="sort-by-alphabet-alt">f15e</option>
                        <option value="Sort By Attributes" data-icon="sort-by-attributes">f160</option>
                        <option value="Sort By Attributes Alt" data-icon="sort-by-attributes-alt">f161</option>
                        <option value="Sort By Order" data-icon="sort-by-order">f162</option>
                        <option value="Sort By Order Alt" data-icon="sort-by-order-alt">f163</option>
                        <option value="thumbs-up" data-icon="thumbs-up">f164</option>
                        <option value="thumbs-down" data-icon="thumbs-down">f165</option>
                        <option value="YouTube Sign" data-icon="youtube-sign">f166</option>
                        <option value="YouTube" data-icon="youtube">f167</option>
                        <option value="Xing" data-icon="xing">f168</option>
                        <option value="Xing Sign" data-icon="xing-sign">f169</option>
                        <option value="YouTube Play" data-icon="youtube-play">f16a</option>
                        <option value="Dropbox" data-icon="dropbox">f16b</option>
                        <option value="Stack Exchange" data-icon="stackexchange">f16c</option>
                        <option value="Instagram" data-icon="instagram">f16d</option>
                        <option value="Flickr" data-icon="flickr">f16e</option>
                        <option value="App.net" data-icon="adn">f170</option>
                        <option value="Bitbucket" data-icon="bitbucket">f171</option>
                        <option value="Bitbucket Sign" data-icon="bitbucket-sign">f172</option>
                        <option value="Tumblr" data-icon="tumblr">f173</option>
                        <option value="Tumblr Sign" data-icon="tumblr-sign">f174</option>
                        <option value="Long Arrow Down" data-icon="long-arrow-down">f175</option>
                        <option value="Long Arrow Up" data-icon="long-arrow-up">f176</option>
                        <option value="Long Arrow Left" data-icon="long-arrow-left">f177</option>
                        <option value="Long Arrow Right" data-icon="long-arrow-right">f178</option>
                        <option value="Apple" data-icon="apple">f179</option>
                        <option value="Windows" data-icon="windows">f17a</option>
                        <option value="Android" data-icon="android">f17b</option>
                        <option value="Linux" data-icon="linux">f17c</option>
                        <option value="Dribbble" data-icon="dribbble">f17d</option>
                        <option value="Skype" data-icon="skype">f17e</option>
                        <option value="Foursquare" data-icon="foursquare">f180</option>
                        <option value="Trello" data-icon="trello">f181</option>
                        <option value="Female" data-icon="female">f182</option>
                        <option value="Male" data-icon="male">f183</option>
                        <option value="Gittip" data-icon="gittip">f184</option>
                        <option value="Sun" data-icon="sun">f185</option>
                        <option value="Moon" data-icon="moon">f186</option>
                        <option value="Archive" data-icon="archive">f187</option>
                        <option value="Bug" data-icon="bug">f188</option>
                        <option value="VK" data-icon="vk">f189</option>
                        <option value="Weibo" data-icon="weibo">f18a</option>
                        <option value="Renren" data-icon="renren">f18b</option>
                    </select>
				<script>
				(function($) {
				  "use strict";
				    function aura_menu_format(icon) {
						var originalOption = icon.element;
						if($(originalOption).data('icon') != '0'){
						return '<i class="icon icon-' + $(originalOption).data('icon') + '"></i> ' + $(originalOption).val();
						}else{
						return '<?php echo __('Please Select an Icon','aurat2d')?>';
						}
					}
					$('.aura_wpmse_select2_<?php echo $item_id; ?> option').text(function(i,v){
						return this.value;
					});


					$('.aura_wpmse_select2_<?php echo $item_id; ?>').select2({
						width: "100%",
						formatResult: aura_menu_format,
						formatSelection: aura_menu_format,
					});
					$( ".aura_wpmse_select2_<?php echo $item_id; ?>" )
					  .change(function(icon) {
						var str2="";
						var str3="";
						$( "#edit-menu-item-iconname-<?php echo $item_id; ?> option:selected" ).each(function() {
						  str2 = $( this ).val();
						  str3 = $( this ).attr('data-icon');
						});
						$( "#edit-menu-item-iconvalue-<?php echo $item_id; ?>" ).val( str2 );
						$( "#edit-menu-item-iconvalued-<?php echo $item_id; ?>" ).val( str3 );
					  })
					  .trigger( "change" );
				})(jQuery);
                </script>
                <input name="menu-item-iconvalue[<?php echo $item_id; ?>]" id="edit-menu-item-iconvalue-<?php echo $item_id; ?>" type="hidden" value="<?php 
				if(empty($item->iconvalue)){
					echo '0';
				}else{
					echo esc_attr( $item->iconvalue );
				}
				 ?>">
                <input name="menu-item-iconvalued[<?php echo $item_id; ?>]" id="edit-menu-item-iconvalued-<?php echo $item_id; ?>" type="hidden" value="<?php
				if(empty($item->iconvalued)){
					echo '0';
				}else{
					echo esc_attr( $item->iconvalued );
				}
				?>">
                </label>
            </p>
            
            
            
            <?php
            /*
             * Upload Icon Field ------------------------------------------------------------------
             */
            ?>  
            
            <p class="field-breakline description description-wide"></p>
            
            <p class="field-uploadicon description description-wide">
            <label for="edit-menu-item-uploadicon-<?php echo $item_id; ?>">
            <?php _e( 'Image Icon Upload - ', 'aurat2d' ); ?>
            <small><?php _e( 'Enter an URL or Upload Icon Image (Optional)', 'aurat2d' ); ?></small><br />
                <input id="edit-menu-item-uploadicon-<?php echo $item_id; ?>" type="text" class="aura-upimg" size="36" name="menu-item-uploadicon[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->uploadicon ); ?>" /> 
                <input id="edit-menu-item-uploadicon-<?php echo $item_id; ?>-button" class="button" type="button" value="<?php echo __('Upload Icon','aurat2d');?>" />
                
            </label>
            <script>
			(function($) {
			  "use strict";
			  $(document).ready(function($){
				var custom_uploader;
				$('#edit-menu-item-uploadicon-<?php echo $item_id; ?>-button').click(function(e) {
					e.preventDefault();
					if (custom_uploader) {
						custom_uploader.open();
						return;
					}
					custom_uploader = wp.media.frames.file_frame = wp.media({
						title: '<?php echo __('Choose Image Icon','aurat2d');?>',
						button: {
							text: '<?php echo __('Choose Image Icon','aurat2d');?>'
						},
						multiple: false
					});
			 
					custom_uploader.on('select', function() {
						var attachment;
						attachment = custom_uploader.state().get('selection').first().toJSON();
						$('#edit-menu-item-uploadicon-<?php echo $item_id; ?>').val(attachment.url);
					});
			 
					custom_uploader.open();
			 
				});
				});
			})(jQuery);
			</script>
            </p>
            
            
            <?php
            /*
             * Icon BG Color ----------------------------------------------------------------------
             */
            ?>  
            
            <p class="field-breakline description description-wide"></p>
            
            <p class="field-iconbgcolor description description-thin">
                <label for="edit-menu-item-iconbgcolor-<?php echo $item_id; ?>">
                    <?php _e( 'Button Background Color', 'aurat2d' ); ?><br />
                    <input type="text" id="edit-menu-item-iconbgcolor-<?php echo $item_id; ?>" class="widefatcode edit-menu-item-iconbgcolor" name="menu-item-iconbgcolor[<?php echo $item_id; ?>]" value="<?php 
					if($item->iconbgcolor != ''){
						echo esc_attr( $item->iconbgcolor );
					}else{
						echo $webbumobile_option['menudefaults_iconbgcolor'];
					}
					?>" data-default-color="<?php echo $webbumobile_option['menudefaults_iconbgcolor']?>"/>
                </label>
                <script type="text/javascript">
				(function($) {
				  "use strict";
					$(document).ready(function($) {   
						$('#edit-menu-item-iconbgcolor-<?php echo $item_id; ?>').wpColorPicker();
					}); 
				})(jQuery);            
				</script>
            </p>
            
            <?php
            /*
             * Icon Border Color ----------------------------------------------------------------------
             */
            ?> 
            
            
            <p class="field-iconbordercolor description description-thin">
                <label for="edit-menu-item-iconbordercolor-<?php echo $item_id; ?>">
                    <?php _e( 'Button Border Color', 'aurat2d' ); ?><br />
                    <input type="text" id="edit-menu-item-iconbordercolor-<?php echo $item_id; ?>" class="widefat code edit-menu-item-iconbordercolor" name="menu-item-iconbordercolor[<?php echo $item_id; ?>]" value="<?php 
					if($item->iconbordercolor != ''){
						echo esc_attr( $item->iconbordercolor );
					}else{
						echo $webbumobile_option['menudefaults_iconbordercolor'];
					}
					?>" data-default-color="<?php echo $webbumobile_option['menudefaults_iconbordercolor']?>"/>
                </label>
                <script type="text/javascript">
				(function($) {
				  "use strict";
				   $(document).ready(function($) {   
						$('#edit-menu-item-iconbordercolor-<?php echo $item_id; ?>').wpColorPicker();
				   
				   });   
				})(jQuery);
				          
				</script>
            </p>
            
            <?php
            /*
             * Icon BG Opacity ----------------------------------------------------------------------
             */
            ?> 
            
            
            <p class="field-iconbgopacity description description-thin">
                <label for="edit-menu-item-iconbgopacity-<?php echo $item_id; ?>">
                    <?php _e( 'Button Background Opacity', 'aurat2d' ); ?><br />
                    <input type="text" id="edit-menu-item-iconbgopacity-<?php echo $item_id; ?>" class="widefat code edit-menu-item-iconbgopacity aura-admin-slider" name="menu-item-iconbgopacity[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->iconbgopacity ); ?>" />
                </label>
            </p>
            
            <?php
            /*
             * Icon Border Opacity ----------------------------------------------------------------------
             */
            ?> 
            
            <p class="field-iconborderopacity description description-thin">
                <label for="edit-menu-item-iconborderopacity-<?php echo $item_id; ?>">
                    <?php _e( 'Button Border Opacity', 'aurat2d' ); ?><br />
                    <input type="text" id="edit-menu-item-iconborderopacity-<?php echo $item_id; ?>" class="widefat code edit-menu-item-iconborderopacity aura-admin-slider" name="menu-item-iconborderopacity[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->iconborderopacity ); ?>" />
                </label>
            </p>
            
            <div class="field-iconbgopacityvalue description description-thin" id="edit-menu-item-iconbgopacityvalue-<?php echo $item_id; ?>"></div>
			<script type="text/javascript">
			(function($) {
			"use strict";
            $(function() {
                $( "#edit-menu-item-iconbgopacityvalue-<?php echo $item_id; ?>" ).slider({
                  value:<?php 
				  if($item->iconbgopacity != ''){
				  	echo esc_attr( $item->iconbgopacity ); 
				  }else{
					echo '1';// Default Opacity
				  }
				  ?>,
                  min: 0,
                  max: 1,
                  step: 0.1,
                  slide: function( event, ui ) {
                    $( "#edit-menu-item-iconbgopacity-<?php echo $item_id; ?>" ).val( ui.value );
                  }
                });
                $( "#edit-menu-item-iconbgopacity-<?php echo $item_id; ?>" ).val( $( "#edit-menu-item-iconbgopacityvalue-<?php echo $item_id; ?>" ).slider( "value" ) );
              }); 
			  })(jQuery);            
            </script>
            
            <div class="field-iconborderopacityvalue description description-thin" id="edit-menu-item-iconborderopacityvalue-<?php echo $item_id; ?>"></div>
			<script type="text/javascript">
			(function($) {
			"use strict";
            $(function() {
                $( "#edit-menu-item-iconborderopacityvalue-<?php echo $item_id; ?>" ).slider({
                  value:<?php 
				  if($item->iconborderopacity != ''){
				  	echo esc_attr( $item->iconborderopacity ); 
				  }else{
					echo '1';// Default Opacity
				  }
				  ?>,
                  min: 0,
                  max: 1,
                  step: 0.1,
                  slide: function( event, ui ) {
                    $( "#edit-menu-item-iconborderopacity-<?php echo $item_id; ?>" ).val( ui.value );
                  }
                });
                $( "#edit-menu-item-iconborderopacity-<?php echo $item_id; ?>" ).val( $( "#edit-menu-item-iconborderopacityvalue-<?php echo $item_id; ?>" ).slider( "value" ) );
              }); 
			  })(jQuery);            
            </script>
            
            
            <?php
            /*
             * Icon Color ----------------------------------------------------------------------
             */
            ?> 
            <p class="field-breakline description description-wide"></p>
            
            <p class="field-icontextcolor description description-thin">
                <label for="edit-menu-item-icontextcolor-<?php echo $item_id; ?>">
                    <?php _e( 'Icon Color', 'aurat2d' ); ?><br />
                    <input type="text" id="edit-menu-item-icontextcolor-<?php echo $item_id; ?>" class="widefatcode edit-menu-item-icontextcolor" name="menu-item-icontextcolor[<?php echo $item_id; ?>]" value="<?php 
					if($item->icontextcolor != ''){
						echo esc_attr( $item->icontextcolor );
					}else{
						echo $webbumobile_option['menudefaults_icontextcolor'];
					}
					?>" data-default-color="<?php echo $webbumobile_option['menudefaults_icontextcolor']?>"/>
                </label>
                <script type="text/javascript">
				(function($) {
				  "use strict";
					$(document).ready(function($) {   
						$('#edit-menu-item-icontextcolor-<?php echo $item_id; ?>').wpColorPicker();
					}); 
				})(jQuery);            
				</script>
            </p>
			<p class="field-breakline description description-wide"></p>
            
            <?php
            /*
             * end added field
             */
            ?>
            <div class="menu-item-actions description-wide submitbox">
                <?php if( 'custom' != $item->type && $original_title !== false ) : ?>
                    <p class="link-to-original">
                        <?php printf( __('Original: %s', 'aurat2d'), '<a href="' . esc_attr( $item->url ) . '">' . esc_html( $original_title ) . '</a>' ); ?>
                    </p>
                <?php endif; ?>
                <a class="item-delete submitdelete deletion" id="delete-<?php echo $item_id; ?>" href="<?php
                echo wp_nonce_url(
                    add_query_arg(
                        array(
                            'action' => 'delete-menu-item',
                            'menu-item' => $item_id,
                        ),
                        remove_query_arg($removed_args, admin_url( 'nav-menus.php' ) )
                    ),
                    'delete-menu_item_' . $item_id
                ); ?>"><?php _e('Remove', 'aurat2d'); ?></a> <span class="meta-sep"> | </span> <a class="item-cancel submitcancel" id="cancel-<?php echo $item_id; ?>" href="<?php echo esc_url( add_query_arg( array('edit-menu-item' => $item_id, 'cancel' => time()), remove_query_arg( $removed_args, admin_url( 'nav-menus.php' ) ) ) );
                    ?>#menu-item-settings-<?php echo $item_id; ?>"><?php _e('Cancel', 'aurat2d'); ?></a>
            </div>

            <input class="menu-item-data-db-id" type="hidden" name="menu-item-db-id[<?php echo $item_id; ?>]" value="<?php echo $item_id; ?>" />
            <input class="menu-item-data-object-id" type="hidden" name="menu-item-object-id[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->object_id ); ?>" />
            <input class="menu-item-data-object" type="hidden" name="menu-item-object[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->object ); ?>" />
            <input class="menu-item-data-parent-id" type="hidden" name="menu-item-parent-id[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->menu_item_parent ); ?>" />
            <input class="menu-item-data-position" type="hidden" name="menu-item-position[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->menu_order ); ?>" />
            <input class="menu-item-data-type" type="hidden" name="menu-item-type[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->type ); ?>" />
        </div><!-- .menu-item-settings-->
        <ul class="menu-item-transport"></ul>
    <?php
    $output .= ob_get_clean();
    }
}

?>