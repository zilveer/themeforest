<?php

define('QODE_CORE_VERSION', '1.0.3');
define('QODE_CORE_ABS_PATH', dirname(__FILE__));
define('QODE_CORE_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('QODE_CORE_CPT_PATH', QODE_CORE_ABS_PATH.'/post-types');