<?php header('Content-type: text/javascript');?>
<?php //Setup location of WordPress
$absolute_path = __FILE__;
$path_to_file = explode( 'wp-content', $absolute_path );
$path_to_wp = $path_to_file[0];
//Access WordPress
require_once( $path_to_wp.'/wp-load.php' );
?>
(function($) {
"use strict";   
 
   
 			
            //Mobile Detect
            tinymce.PluginManager.add( 'webbushort_mdetect', function( editor, url ) {
            
                editor.addButton( 'webbushort_mdetect', {
                    type: 'splitbutton',
                    icon: false,
                    title:  '<?php echo __('Mobile Detect','wmft2d') ?>',
                    onclick : function(e) {},
                    onshow : function(e) {
                        $.menu = $('#'+e.control._id+'-body');
                            $('#'+e.control._id+'').addClass('wmfautofix'); 
                            $.menu.addClass('mceListBoxMenu'); 
                            $.menu.addClass('wmfautofix'); 
            
                        if($.menu.data('added')) return;
                        $.menu.append('<div style="padding: 0 10px 10px"><label><?php echo __('Select Option','wmft2d') ?><br/>\
                        <select name="dtype">\
                        <option value="notphone"><?php echo __('Only Show Desktops & Tablets','wmft2d') ?></option>\
                        <option value="nottablet"><?php echo __('Only Show Desktops & Phones','wmft2d') ?></option>\
                        <option value="notmobile"><?php echo __('Only Show Desktops','wmft2d') ?></option>\
                        <option value="phone"><?php echo __('Only Show Phones','wmft2d') ?></option>\
                        <option value="tablet"><?php echo __('Only Show Tablets','wmft2d') ?></option>\
                        <option value="mobile"><?php echo __('Only Show Phones & Tablets','wmft2d') ?></option>\
                        <option value="ios"><?php echo __('Only Show iOS Devices','wmft2d') ?></option>\
                        <option value="android"><?php echo __('Only Show Android Devices','wmft2d') ?></option>\
                        <option value="wm"><?php echo __('Only Show WM Devices','wmft2d') ?></option>\
                        <option value="iPhone"><?php echo __('Only Show iPhone','wmft2d') ?></option>\
                        <option value="iPad"><?php echo __('Only Show iPad','wmft2d') ?></option>\
                        <option value="Samsung"><?php echo __('Only Show Samsung','wmft2d') ?></option>\
                        <option value="BlackBerry"><?php echo __('Only Show BlackBerry','wmft2d') ?></option>\
                        </select></label>\
                        </div>');
            
                        $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                        .click(function(){
                            var dtype = $.menu.find('select[name=dtype]').val();
                            if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
                             editor.insertContent('[wmf_detect type="'+dtype+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_detect]');
                            }else{
                             editor.insertContent('[wmf_detect type="'+dtype+'"]<?php echo __('Code goes here...','wmft2d') ?>[/wmf_detect]'); 
                            }
                                    
                            
                            e.control.hide();
                            }).wrap('<div style="padding: 0 10px 10px"></div>')
                            $.menu.data('added',true); 
                    
                        
                    },
                });
            });
          
          
            //Seperator
            tinymce.PluginManager.add( 'webbushort_sp', function( editor, url ) {
            
            	editor.addButton( 'webbushort_sp', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Seperator','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px"><label><?php echo __('Align','wmft2d') ?><br/>\
						<select name="align">\
                        <option value="left"><?php echo __('Left','wmft2d') ?></option>\
                        <option value="center"><?php echo __('Center','wmft2d') ?></option>\
						<option value="right"><?php echo __('Right','wmft2d') ?></option>\
                        </select></label>\
                        <label><?php echo __('Size','wmft2d') ?><br/>\
						<input type="text" size="6" id="size" name="size" value="16" onclick="this.select()" /></label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var title = $.menu.find('input[name=title]').val();
                        var align = $.menu.find('select[name=align]').val();
                        var size = $.menu.find('input[name=size]').val();
                        if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
                         editor.insertContent('[wmf_sp align="'+align.toLowerCase()+'" size="'+size.toLowerCase()+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_sp]');
                        }else{
                         editor.insertContent('[wmf_sp align="'+align.toLowerCase()+'" size="'+size.toLowerCase()+'"]<?php echo __('Title(Optional)','wmft2d') ?>[/wmf_sp]'); 
                        }
                                
                        
                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //FontIcon
            tinymce.PluginManager.add( 'webbushort_fonticon', function( editor, url ) {
            
            	editor.addButton( 'webbushort_fonticon', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Font Icon','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px"><label><?php echo __('BG Color','wmft2d') ?><br/>\
                        <input type="text" maxlength="6" size="6" id="colorpickerField1" name="colorpickerField1" value="#000000" onclick="this.select()" /></label>\
						<label><?php echo __('Size','wmft2d') ?><br/>\
                        <input type="text" maxlength="6" size="6" id="size" name="size" value="24" onclick="this.select()" /></label>\
						<label><?php echo __('Icon Name','wmft2d') ?><br/>\
                        <input type="text" size="6" id="icon" name="icon" value="icon-heart" onclick="this.select()" /></label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){

                        var colorpickerField1 = $.menu.find('input[name=colorpickerField1]').val();
                        var size = $.menu.find('input[name=size]').val();
                        var icon = $.menu.find('input[name=icon]').val();
                        editor.insertContent('[wmf_fonticon color="'+colorpickerField1.toLowerCase()+'" size="'+size.toLowerCase()+'" icon="'+icon.toLowerCase()+'"][/wmf_fonticon]'); 
                        
                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Dropcap
            tinymce.PluginManager.add( 'webbushort_dropcap', function( editor, url ) {
            
            	editor.addButton( 'webbushort_dropcap', {
                //type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Dropcap Config','wmft2d') ?>',
                onclick : function(e) {
                    tb_show('<?php echo __('Dropcap Config','wmft2d') ?>','../wp-content/plugins/wmfshortcodes/js/dropcap.html?TB_iframe=true'); 
                    var TB_WIDTH = 490,
                        TB_HEIGHT = 370; 
                    $("#TB_window").animate({
                        marginLeft: '-' + parseInt((TB_WIDTH / 2), 10) + 'px',
                        width: TB_WIDTH + 'px',
                        height: TB_HEIGHT + 'px',
                        
                    });
                    
                    $("#TB_window iframe").animate({
                        width: TB_WIDTH + 'px',
                        height: TB_HEIGHT + 'px',
                    });
                    
                },
            });
            });
            
            
            //Highlight
            tinymce.PluginManager.add( 'webbushort_highlight', function( editor, url ) {
            
            	editor.addButton( 'webbushort_highlight', {
                //type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Highlight Color','wmft2d') ?>',
                onclick : function(e) {
                    tb_show('<?php echo __('Highlight Color','wmft2d') ?>','../wp-content/plugins/wmfshortcodes/js/highlight.html?TB_iframe=true'); 
                    var TB_WIDTH = 490,
                        TB_HEIGHT = 370; 
                    $("#TB_window").animate({
                        marginLeft: '-' + parseInt((TB_WIDTH / 2), 10) + 'px',
                        width: TB_WIDTH + 'px',
                        height: TB_HEIGHT + 'px',
                        
                    });
                    
                    $("#TB_window iframe").animate({
                        width: TB_WIDTH + 'px',
                        height: TB_HEIGHT + 'px',
                    });
                    
                },
            });
            });
            
            
            //Notifications
            tinymce.PluginManager.add( 'webbushort_notifications', function( editor, url ) {
            
            	editor.addButton( 'webbushort_notifications', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Notifications','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px"><label><?php echo __('Color','wmft2d') ?><br/>\
                        <select name="style">\
                        <option value="wmfalert-info" selected> <?php echo __('Light Blue','wmft2d') ?></option>\
                        <option value="wmfalert-success"> <?php echo __('Green','wmft2d') ?></option>\
                        <option value="wmfalert-warning"> <?php echo __('Yellow','wmft2d') ?></option>\
                        <option value="wmfalert-danger"> <?php echo __('Red','wmft2d') ?></option>\
                        </select></label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var style = $.menu.find('select[name=style]').val();
									
                        if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
                         editor.insertContent('[wmf_notify style="'+style.toLowerCase()+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_notify]');
                        }else{
                         editor.insertContent('[wmf_notify style="'+style.toLowerCase()+'"]<?php echo __('Alert text goes here.','wmft2d') ?>[/wmf_notify]'); 
                        }

                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Collapse
            tinymce.PluginManager.add( 'webbushort_collapse', function( editor, url ) {
            
            	editor.addButton( 'webbushort_collapse', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Collapse','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding:0 10px 10px">\
                        <label><?php echo __('Number of collapse item','wmft2d') ?><br />\
                        <input type="text" name="itemnum" value="2" onclick="this.select()"  /></label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var shortcode = '[wmf_toggles]<br class="ws"/>';
                        var num = $.menu.find('input[name=itemnum]').val();
                        var i;
                            for(i=0;i<num;i++){
                                shortcode += '[wmf_toggle title="Title"]';
                                shortcode += '<?php echo __('Collapse content goes here.','wmft2d') ?>';
                                shortcode += '[/wmf_toggle]<br class="ws"/>';
                            }

                        shortcode+= '[/wmf_toggles]';

                        editor.insertContent(shortcode);

                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Tabs
            tinymce.PluginManager.add( 'webbushort_tabs', function( editor, url ) {
            
            	editor.addButton( 'webbushort_tabs', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Tabs','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding:0 10px 10px">\
                       <label><?php echo __('Number of tab','wmft2d') ?><br />\
                       <input type="text" name="tabnum" value="2" onclick="this.select()"  /></label>\
                       </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var shortcode = '[wmf_tabs]<br class="ws"/>';
                        var num = $.menu.find('input[name=tabnum]').val();
                        var k;
                            for(k=0;k<num;k++){
                                shortcode += '[wmf_tab title="Title"]';
                                shortcode += '<?php echo __('Tab content goes here.','wmft2d') ?>';
                                shortcode += '[/wmf_tab]<br class="ws"/>';
                            }

                        shortcode+= '[/wmf_tabs]';
						
                        editor.insertContent(shortcode);

                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Buttons
            tinymce.PluginManager.add( 'webbushort_button', function( editor, url ) {
            
            	editor.addButton( 'webbushort_button', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Button','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Button Text','wmft2d') ?><br />\
                        <input type="text" name="btext" value="<?php echo __('Button','wmft2d') ?>" onclick="this.select()" /></label>\
                        <label><?php echo __('URL','wmft2d') ?><br />\
                        <input type="text" name="link" value="#" onclick="this.select()" /></label>\
						<label><?php echo __('Size','wmft2d') ?><br/>\
                        <select name="size">\
                        <option value="wmfbtn-xs"><?php echo __('Mini','wmft2d') ?></option>\
                        <option value="wmfbtn-sm"><?php echo __('Small','wmft2d') ?></option>\
                        <option value="normal" selected><?php echo __('Normal','wmft2d') ?></option>\
                        <option value="wmfbtn-lg"><?php echo __('Large','wmft2d') ?></option>\
                        </select></label>\
                        <label><?php echo __('Types','wmft2d') ?><br/>\
                        <select name="type">\
                        <option value="wmfbtn-primary"> <?php echo __('Blue','wmft2d') ?></option>\
                        <option value="wmfbtn-info" selected> <?php echo __('Light Blue','wmft2d') ?></option>\
                        <option value="wmfbtn-success"> <?php echo __('Green','wmft2d') ?></option>\
                        <option value="wmfbtn-warning"> <?php echo __('Yellow','wmft2d') ?></option>\
                        <option value="wmfbtn-danger"> <?php echo __('Red','wmft2d') ?></option>\
                        <option value="wmfbtn-default"> <?php echo __('Transparent','wmft2d') ?></option>\
						<option value="wmfbtn-link"> <?php echo __('Link','wmft2d') ?></option>\
                        </select>\
						<label><?php echo __('Target','wmft2d') ?><br/>\
						<select name="target">\
						<option value="" selected> <?php echo __('Select','wmft2d') ?></option>\
                        <option value="_self"> _self</option>\
                        <option value="_blank"> _blank</option>\
                        <option value="_parent"> _parent</option>\
                        </select>\
						</label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var size = $.menu.find('select[name=size]').val();
                        var type = $.menu.find('select[name=type]').val();
                        var target = $.menu.find('select[name=target]').val();
                        var btext = $.menu.find('input[name=btext]').val();
                        var link = $.menu.find('input[name=link]').val();
                        editor.insertContent('[wmf_button size="'+size.toLowerCase()+'" color="'+type.toLowerCase()+'" target="'+target+'" url="'+link+'"]'+btext+'[/wmf_button]');
                                
                        
                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Button Groups
            tinymce.PluginManager.add( 'webbushort_buttong', function( editor, url ) {
            
            	editor.addButton( 'webbushort_buttong', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Button Group','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px"><label>Align<br/>\
                        <select name="align">\
                        <option value="left"><?php echo __('Left','wmft2d') ?></option>\
                        <option value="right"><?php echo __('Right','wmft2d') ?></option>\
                        <option value="center" selected><?php echo __('Center','wmft2d') ?></option>\
                        </select></label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var align = $.menu.find('select[name=align]').val();
                        if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
                         editor.insertContent('[wmf_buttong align="'+align.toLowerCase()+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_buttong]');
                        }else{
                         editor.insertContent('[wmf_buttong align="'+align.toLowerCase()+'"]<?php echo __('Button codes goes here.','wmft2d') ?>[/wmf_buttong]'); 
                        }
                        
                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Labels & Badges
            tinymce.PluginManager.add( 'webbushort_lb', function( editor, url ) {
            
            	editor.addButton( 'webbushort_lb', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Labels & Badges','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Color','wmft2d') ?><br/>\
						<select name="color">\
                        <option value="default"><?php echo __('Grey','wmft2d') ?></option>\
                        <option value="primary"><?php echo __('Blue','wmft2d') ?></option>\
						<option value="success"><?php echo __('Green','wmft2d') ?></option>\
						<option value="info"><?php echo __('Light Blue','wmft2d') ?></option>\
						<option value="warning"><?php echo __('Yellow','wmft2d') ?></option>\
						<option value="danger"><?php echo __('Red','wmft2d') ?></option>\
                        </select>\
						<label><?php echo __('Type','wmft2d') ?><br/>\
						<select name="type">\
                        <option value="wmfbadge"><?php echo __('Badge','wmft2d') ?></option>\
                        <option value="label"><?php echo __('Label','wmft2d') ?></option>\
                        </select></label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var color = $.menu.find('select[name=color]').val();
                        var type = $.menu.find('select[name=type]').val();
                        if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
                        editor.insertContent('[wmf_lb color="'+color.toLowerCase()+'" type="'+type.toLowerCase()+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_lb]');
                        }else{
                        editor.insertContent('[wmf_lb color="'+color.toLowerCase()+'" type="'+type.toLowerCase()+'"]<?php echo __('Text goes here.','wmft2d') ?>[/wmf_lb]'); 
                        }
                        
                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Table
            tinymce.PluginManager.add( 'webbushort_table', function( editor, url ) {
            
            	editor.addButton( 'webbushort_table', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Table','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px"><label><?php echo __('Type','wmft2d') ?><br/>\
                        <select name="type">\
                        <option value="striped"><?php echo __('Striped','wmft2d') ?></option>\
						<option value="bordered"><?php echo __('Bordered','wmft2d') ?></option>\
						<option value="hover"><?php echo __('Striped with Hover Effect','wmft2d') ?></option>\
						<option value="condensed"><?php echo __('Condensed','wmft2d') ?></option>\
                        </select></label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        
                        var type = $.menu.find('select[name=type]').val();
						editor.insertContent('[wmf_table type="'+type.toLowerCase()+'" cols="#,First Name, Last Name, Username" data="1, Filip, Stefansson, filipstefansson, 2, Victor, Meyer, Pudge, 3, Mans, Ketola-Backe, mossboll"][/wmf_table]'); 
                        
                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Maps
            tinymce.PluginManager.add( 'webbushort_maps', function( editor, url ) {
            
            	editor.addButton( 'webbushort_maps', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Maps','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Lat','wmft2d') ?><br />\
                        <input type="text" name="lat" value="38.428971" onclick="this.select()" /></label>\
						<label><?php echo __('Lng','wmft2d') ?><br />\
                        <input type="text" name="lng" value="27.134342" onclick="this.select()" /></label>\
						<label><?php echo __('Zoom','wmft2d') ?><br />\
                        <input type="text" name="zoom" value="14" onclick="this.select()" /></label>\
						<label><?php echo __('Height','wmft2d') ?><br />\
                        <input type="text" name="height" value="150" onclick="this.select()" /></label>\
						<label><?php echo __('Map Type','wmft2d') ?><br/>\
                        <select name="type">\
                        <option value="m" selected><?php echo __('ROADMAP','wmft2d') ?></option>\
                        <option value="k"><?php echo __('SATELLITE','wmft2d') ?></option>\
                        <option value="h"><?php echo __('HYBRID','wmft2d') ?></option>\
                        <option value="p"><?php echo __('TERRAIN','wmft2d') ?></option>\
                        </select></label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var type = $.menu.find('select[name=type]').val();
                        var lat = $.menu.find('input[name=lat]').val();
                        var lng = $.menu.find('input[name=lng]').val();
                        var zoom = $.menu.find('input[name=zoom]').val();
                        var height = $.menu.find('input[name=height]').val();
                        editor.insertContent('[wmf_maps height="'+height+'" type="'+type+'" lat="'+lat+'" lng="'+lng+'" zoom="'+zoom+'"][/wmf_maps]');

                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Video
            tinymce.PluginManager.add( 'webbushort_video', function( editor, url ) {
            
            	editor.addButton( 'webbushort_video', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Video','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Video ID','wmft2d') ?><br />\
                        <input type="text" name="id" value="rMltoD1jCGI" onclick="this.select()" /></label>\
						<label><?php echo __('Width','wmft2d') ?><br />\
                        <input type="text" name="w" value="600" onclick="this.select()" /></label>\
						<label><?php echo __('Height','wmft2d') ?><br />\
                        <input type="text" name="h" value="430" onclick="this.select()" /></label>\
						<label><?php echo __('Site','wmft2d') ?><br/>\
                        <select name="type">\
                        <option value="youtube" selected>Youtube</option>\
                        <option value="vimeo">Vimeo</option>\
                        <option value="dailymotion">Dailymotion</option>\
                        <option value="yahoo">Yahoo</option>\
						<option value="bliptv">Bliptv</option>\
						<option value="veoh">Veoh</option>\
						<option value="viddler">Viddler</option>\
                        </select></label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var type = $.menu.find('select[name=type]').val();
                        var w = $.menu.find('input[name=w]').val();
                        var h = $.menu.find('input[name=h]').val();
                        var id = $.menu.find('input[name=id]').val();
                        editor.insertContent('[wmf_video h="'+h+'" w="'+w+'" type="'+type+'" id="'+id+'"][/wmf_video]');

                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Twitter
            tinymce.PluginManager.add( 'webbushort_twitter', function( editor, url ) {
            
            	editor.addButton( 'webbushort_twitter', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Twitter Page','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Twitter Username','wmft2d') ?><br />\
                        <input type="text" name="tu" value="webbudesign" onclick="this.select()" /></label>\
						<label><?php echo __('Tweet Limit','wmft2d') ?><br />\
                        <input type="text" name="tn" value="3" onclick="this.select()" /></label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var tu = $.menu.find('input[name=tu]').val();
                        var tn = $.menu.find('input[name=tn]').val();
                        editor.insertContent('[wmf_twitter user="'+tu+'" numb="'+tn+'"][/wmf_twitter]');

                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Progress Bar
            tinymce.PluginManager.add( 'webbushort_progress', function( editor, url ) {
            
            	editor.addButton( 'webbushort_progress', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Progress Bar','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('% Progress','wmft2d') ?><br />\
                        <input type="text" name="value" value="10" onclick="this.select()" /></label>\
                        <label><?php echo __('Color','wmft2d') ?><br/>\
                        <select name="color">\
                        <option value=""> <?php echo __('Blue','wmft2d') ?></option>\
                        <option value="progress-bar-info" selected> <?php echo __('Light Blue','wmft2d') ?></option>\
                        <option value="progress-bar-success"> <?php echo __('Green','wmft2d') ?></option>\
                        <option value="progress-bar-warning"> <?php echo __('Yellow','wmft2d') ?></option>\
                        <option value="progress-bar-danger"> <?php echo __('Red','wmft2d') ?></option>\
                        </select>\
						<label><?php echo __('Type','wmft2d') ?><br/>\
						<select name="type">\
						<option value="" selected> <?php echo __('Normal','wmft2d') ?></option>\
                        <option value="progress-striped "> <?php echo __('Striped','wmft2d') ?></option>\
                        <option value="progress-striped active"> <?php echo __('Striped Active','wmft2d') ?></option>\
                        </select>\
						</label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var type = $.menu.find('select[name=type]').val();
                        var color = $.menu.find('select[name=color]').val();
                        var value = $.menu.find('input[name=value]').val();
                        editor.insertContent('[wmf_prg value="'+value.toLowerCase()+'" color="'+color.toLowerCase()+'" type="'+type.toLowerCase()+'"][/wmf_prg]');
                        
                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Services
            tinymce.PluginManager.add( 'webbushort_services', function( editor, url ) {
            
            	editor.addButton( 'webbushort_services', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Services','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Title','wmft2d') ?><br />\
                        <input type="text" name="title" value="<?php echo __('Title','wmft2d') ?>" onclick="this.select()" /></label>\
                        <label><?php echo __('Icon','wmft2d') ?><br />\
                        <input type="text" name="icon" value="<?php echo __('icon-heart','wmft2d') ?>" onclick="this.select()" /></label>\
                        <label><?php echo __('URL','wmft2d') ?><br />\
                        <input type="text" name="link" value="#" onclick="this.select()" /></label>\
						<label><?php echo __('Target','wmft2d') ?><br/>\
						<select name="target">\
						<option value="" selected> <?php echo __('Select','wmft2d') ?></option>\
                        <option value="_self"> _self</option>\
                        <option value="_blank"> _blank</option>\
                        <option value="_parent"> _parent</option>\
                        </select>\
						</label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var target = $.menu.find('select[name=target]').val();
                        var title = $.menu.find('input[name=title]').val();
                        var icon = $.menu.find('input[name=icon]').val();
                        var link = $.menu.find('input[name=link]').val();
                       
                        
                        if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
                        editor.insertContent('[wmf_services title="'+title+'" icon="'+icon+'" target="'+target+'" link="'+link+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_services]');
                        }else{
                        editor.insertContent('[wmf_services title="'+title+'" icon="'+icon+'" target="'+target+'" link="'+link+'"]<?php echo __('Content goes here...','wmft2d') ?>[/wmf_services]');
                        }

                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Padding
            tinymce.PluginManager.add( 'webbushort_padding', function( editor, url ) {
            
            	editor.addButton( 'webbushort_padding', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Padding','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    if($.menu.data('added')) return;
                    $.menu.append('<div style="padding:0 10px 10px">\
                        <label><?php echo __('Padding Size','wmft2d') ?><br />\
                        <input type="text" name="size" value="20" onclick="this.select()"  /></label>\
                        </div>');
            
                    $('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($.menu)
                    .click(function(){
                        var shortcode = '';
                        var size = $.menu.find('input[name=size]').val();
                        
                        shortcode += '[wmf_pad size="'+size+'"]';
                        shortcode += '';
                        shortcode += '[/wmf_pad]<br class="ws"/>';
                        
                        editor.insertContent(shortcode);

                        e.control.hide();
                        }).wrap('<div style="padding: 0 10px 10px"></div>')
                        $.menu.data('added',true); 
                
                    
                },
            });
            });
            
            
            //Grid System
            tinymce.PluginManager.add( 'webbushort_cl', function( editor, url ) {
            
            	editor.addButton( 'webbushort_cl', {
                type: 'splitbutton',
                icon: false,
                title:  '<?php echo __('Columns','wmft2d') ?>',
                onclick : function(e) {},
                onshow : function(e) {
                    $.menu = $('#'+e.control._id+'-body');
                        $('#'+e.control._id+'').addClass('wmfautofix'); 
                        $.menu.addClass('mceListBoxMenu'); 
                        $.menu.addClass('wmfautofix'); 
            
                    
                
                    
                },
                 menu: [
                    {text: '1/6 Columns', onclick: function() {editor.insertContent('[wmf_row class="row"]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]');}},
                    
                    
                    {text: '3/4 - 1/4  <?php echo __('Columns','wmft2d') ?>', onclick: function() {editor.insertContent('[wmf_row]<br class="ws"/>[wmf_col cls="9"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]');}},
                    
                    {text: '1/4 - 3/4  <?php echo __('Columns','wmft2d') ?>', onclick: function() {editor.insertContent('[wmf_row]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="9"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]');}},
                    
                    {text: '2/3 - 1/3  <?php echo __('Columns','wmft2d') ?>', onclick: function() {editor.insertContent('[wmf_row]<br class="ws"/>[wmf_col cls="8"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="4"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]');}},
                    
                    {text: '1/3 - 2/3  <?php echo __('Columns','wmft2d') ?>', onclick: function() {editor.insertContent('[wmf_row]<br class="ws"/>[wmf_col cls="4"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="8"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]');}},
                    
                    {text: '4 <?php echo __('Columns','wmft2d') ?>', onclick: function() {editor.insertContent('[wmf_row]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]');}},
                    
                    {text: '3 <?php echo __('Columns','wmft2d') ?>', onclick: function() {editor.insertContent('[wmf_row]<br class="ws"/>[wmf_col cls="4" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="4" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="4" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]');}},
                    
                    {text: '2 <?php echo __('Columns','wmft2d') ?>', onclick: function() {editor.insertContent('[wmf_row]<br class="ws"/>[wmf_col cls="6" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="6" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]');}},
                    
                    {text: '<?php echo __('Full Width','wmft2d') ?>', onclick: function() {editor.insertContent('[wmf_row]<br class="ws"/>[wmf_col cls="12" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]');}}
                ]
            });
            });
            
            
       
 
})(jQuery);