<?php  
//Register "container" content element
vc_map( array(
    "name" => __("Fancy Carousel", "wish"),
    "description" => __("Fancy Sliding Carousel", 'wish'),
    "controls" => "full",
    "base" => "wish_sliding_carousel",
    "as_parent" => array('only' => 'wish_sliding_carousel_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Carousel Title", "wish"),
            "value" => __("Carousel Title", 'wish'),
            "admin_label" => true,
        ), 

    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Carousel Item", "wish"),
    "base" => "wish_sliding_carousel_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_sliding_carousel_single'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Features Section Title", "wish"),
            "value" => __("Our Features", 'wish'),
            "admin_label" => true,
        ), 

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,
        ),


       
    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Sliding_Carousel extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title' => 'title',
      ), $atts ) );

      $str = substr_count(do_shortcode($content), '<figure>');
     
      $output = "<div class='ia-container'>
                  " . do_shortcode($content) . "        
                ";

       for ($i=0; $i < $str; $i++) { 
            $output .= "</figure>";
       }         

      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class
if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Sliding_Carousel_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'title'   => 'title',
            'details' => 'details',
            'image'    => 'Image'
          ), $atts ) );
          
      $img = wp_get_attachment_image_src( $image, array(1200, 800) );

      if($image == "Image"){
        $img[0] = plugins_url('images/1200x800.jpg', __FILE__);
      }

          $output = "<figure>
                        <img src='{$img[0]}' alt='Carousel Image' />
                        <input type='radio' name='radio-set' checked='checked'/>
                        <figcaption><span>{$title}</span></figcaption>
                    ";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>