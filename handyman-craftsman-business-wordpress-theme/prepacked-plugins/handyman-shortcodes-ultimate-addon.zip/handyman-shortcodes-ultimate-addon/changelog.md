**2015-08-19** v1.0.1
	* Refactoring for WP 4.3
	
**2015-09-11** v1.0.3
    * Defined path to language files
    * Added english language (handyman-shortcodes-ultimate-addon-en_US.po)
**2015-10-07** v1.0.4
    * Css improvement
    * Translations updated