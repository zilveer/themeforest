<?php
if( !defined('_MULTIPURPOSE_SHORTCODE')) die('Access denied');

//shortcode for Unordered list
add_shortcode('unordered_list', 'multipurpose_unordered_list');
function multipurpose_unordered_list( $atts, $content = null ) {
    if(isset($atts) && !empty($atts))
            array_walk($atts, 'multipurpose_arrangement_shortcode_arr_value');

    extract(shortcode_atts(array(  
        'style' => ''
    ), $atts));  

    $output_content = do_shortcode($content);

    if ($style != '')
        $output = preg_replace('/<ul>/', '<ul class="'.$style.'">', $output_content);
    else 
        $output = $output_content;

    return $output;  
}  

function multipurpose_bullet_item($atts, $content = null) {
    return '<li>'.do_shortcode($content).'</li>';
}