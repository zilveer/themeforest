<section class="slider9 p%PATTERN%">
  <div class="slider">
