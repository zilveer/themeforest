<?php
/**
 * Theme laboratories Content Widget
 *
 * It is basicly orginal Layers Content Widget with a few tweeks.
 *
 * Features.
 *   - Add 250 Icons. It can be assigned to column main title
 *   -
 *
 * @since Layers 1.4.1
 */

if(!class_exists('TL_Layers_Abstract_Widget')){ return; }

if (!class_exists('TL_Layers_Content_Widget')) {
    class TL_Layers_Content_Widget extends TL_Layers_Abstract_Widget
    {

        protected $_icons = array();

        /**
         *  Widget construction
         */
        public function __construct()
        {
            /**
             * Widget variables
             *
             * @param    string $widget_title Widget title
             * @param    string $widget_id Widget slug for use as an ID/classname
             * @param    string $post_type (optional) Post type for use in widget options
             * @param    string $taxonomy (optional) Taxonomy slug for use as an ID/classname
             * @param    array $checkboxes (optional) Array of checkbox names to be saved in this widget. Don't forget these please!
             */
            $this->widget_title = __('TL Content', 'layerswp');
            $this->widget_id = 'tl_column';
            $this->post_type = '';
            $this->taxonomy = '';
            $this->checkboxes = array('responsive');

            /* Widget settings. */
            $widget_ops = array('classname' => 'obox-layers-' . $this->widget_id . '-widget', 'description' => __('This widget is used to display your ', 'layerswp') . $this->widget_title . '.');

            /* Widget control settings. */
            $control_ops = array('width' => LAYERS_WIDGET_WIDTH_LARGE,
                                 'height' => NULL,
                                 'id_base' => LAYERS_THEME_SLUG . '-widget-' . $this->widget_id);

            /* Create the widget. */
            parent::__construct(LAYERS_THEME_SLUG . '-widget-' . $this->widget_id, $this->widget_title, $widget_ops, $control_ops);

            /* Setup Widget Defaults */
            $this->defaults = array(
                'title' => __('Our Services', 'layerswp'),
                'excerpt' => __('Our services run deep and are backed by over ten years of experience.', 'layerswp'),
                'design' => array(
                    'layout' => 'layout-boxed',
                    'liststyle' => 'list-grid',
                    'columns' => '4',
                    'gutter' => 'on',
                    'background' => array(
                        'position' => 'center',
                        'repeat' => 'no-repeat'
                    ),
                    'fonts' => array(
                        'align' => 'text-center',
                        'size' => 'medium',
                        'color' => NULL,
                        'excerpt-color' => NULL,
                        'shadow' => NULL
                    )
                )
            );

            $this->register_repeater_defaults( 'column', 4, array(
                'title' => __('Your service title', 'layerswp'),
                'excerpt' => __('Give us a brief description of the service that you are promoting. Try keep it short so that it is easy for people to scan your page.', 'layerswp'),
                'width' => '3',
                'post_item' => null,
                'design' => array(
                    'imagealign' => 'image-top',
                    'background' => NULL,
                    'fonts' => array(
                        'align' => 'text-left',
                        'size' => 'medium',
                        'color' => NULL,
                        'shadow' => NULL
                    ),
                ),
            ));

            /* Load Icons */
            $this->loadIcons();

            /* Add Filters */
            $this->_addFilters();

            add_action('wp_enqueue_scripts', array($this, 'enqueue_css'), 999);
        }


        public function enqueue_css(){
            wp_enqueue_style(
                'theme-flaticons',
                parent::asset_path('css/themify-icons.min.css', false, true),
                array(''),
                TL_THEME_VER
            );
        }


        /**
         * Widget front end display
         *
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        {
            $this->backup_inline_css();

            // Turn $args array into variables.
            extract($args);

            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );


            // Enqueue Masonry if need be
            if ('list-masonry' == $this->check_and_return($widget, 'design', 'liststyle')) $this->enqueue_masonry();

            $this->_apply_button_styling($widget_id, $widget);

            $this->_apply_widget_section_styling($widget_id, $widget);

            $this->_apply_widget_additional_styling($widget_id, $widget);

            /**
             * Generate the widget container class
             */

            $is_testimonial_widget = false;
            if($this->check_and_return($widget, 'design', 'advanced', 'customclass') == 'testimonials-widget'){
                $is_testimonial_widget = true;
            }

            $widget_container_class = array();
            $widget_container_class[] = 'layers-content-widget layers-tl-content-widget';
            $widget_container_class[] = 'content-vertical-massive';
            //@TBD
            $widget_container_class[] = $this->check_and_return($widget, 'design', 'background', 'darken') ? 'make-relative' : '';
            $widget_container_class[] = $this->check_and_return($widget, 'design', 'advanced', 'customclass');
            $widget_container_class[] = $this->get_widget_spacing_class($widget);
            $widget_container_class = implode(' ', apply_filters('layers_content_widget_container_class', $widget_container_class, $this, $widget)); ?>

            <div id="<?php echo esc_attr($widget_id); ?>" class="<?php echo esc_attr($widget_container_class); ?>">
                <?php if($this->check_and_return($widget, 'design', 'background', 'darken')):?><div class="bg-overlay"></div><?php endif;?>
                <?php echo $this->custom_anchor( $widget ); ?>
                <?php do_action( 'layers_before_' . $this->id . '_widget_inner', $this, $widget ); ?>
                <?php if ('' != $this->check_and_return($widget, 'title') || '' != $this->check_and_return($widget, 'excerpt')) { ?>
                    <div class="container clearfix">
                        <?php
                        /**
                         * Generate the Section Title Classes
                         */
                        $section_title_class = array();
                        $section_title_class[] = 'section-title clearfix';
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'size');
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'align');
                        $section_title_class[] = ($this->check_and_return($widget, 'design', 'background', 'color') && 'dark' == tl_layers_is_light_or_dark_recalculated($this->check_and_return($widget, 'design', 'background', 'color')) ? 'invert' : '');

                        $section_title_class = implode(' ', $section_title_class); ?>

                        <div class="<?php echo esc_attr($section_title_class); ?>">
                            <?php if ('' != $widget['title']) { ?>
                                <h3 class="heading"><?php echo apply_filters('tl_colorize_title_' . $this->widget_id, esc_html($widget['title'])); ?></h3>
                            <?php } ?>
                            <?php if ('' != $widget['excerpt']) { ?>
                                <div class="excerpt"><?php echo $widget['excerpt']; ?></div>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>
                <?php if (!empty($widget['columns'])) { ?>
                    <div class="<?php echo esc_attr($this->get_widget_layout_class($widget)); ?> <?php echo esc_attr($this->check_and_return($widget, 'design', 'liststyle')); ?>">
                        <div class="grid">

                        <?php // Set total width so that we can apply .last to the final container
                        $total_width = 0; ?>
                        <?php foreach (explode(',', $widget['column_ids']) as $column_key) {

                            // Make sure we've got a column going on here
                            if (!isset($widget['columns'][$column_key])) continue;

                            // Setup the relevant slide
                            $column = $widget['columns'][$column_key];

                            $post_id = isset($column['post_item']) ? (int)$column['post_item'] : null;

                            $column_margins = isset($column['c_margin']) ? $column['c_margin'] : array();
                            $column_padding = isset($column['c_padding'])? $column['c_padding'] : array();
                            $has_custom_margin = $has_custom_padding = false;

                            foreach($column_margins as $k => $v){
                                if($v!=''){
                                    $column_margins[$k] = $v . 'px';
                                    $has_custom_margin = true;
                                }
                            }

                            foreach($column_padding as $k => $v){
                                if($v!='') {
                                    $column_padding[$k] = $v . 'px';
                                    $has_custom_padding = true;
                                }
                            }

                            $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' > .media', 'margin', array('margin' => $column_margins));
                            $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' > .media', 'padding', array('padding' => $column_padding));

                            // Set the background styling
                            if (!empty($column['design']['background'])) $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'background', array('background' => $column['design']['background']));
                            if (!empty($column['design']['fonts']['shadow'])) $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'text-shadow', array('selectors' => array('h5.heading a', 'h5.heading', 'div.excerpt', 'div.excerpt p'), 'text-shadow' => $column['design']['fonts']['shadow']));

                            /* Column exerpt */
                            if (!empty($column['design']['fonts']['color']))
                                $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'color', array('selectors' => array('div.excerpt', 'div.excerpt p'),
                                    'color' => $column['design']['fonts']['color']));

                            /* Column Title color */
                            if (!empty($column['design']['fonts']['titlecolor'])) {
                                $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, array('selectors' => array('h5.heading a', 'h5.heading', '.header-icon i'),
                                                                                                 'css' => array('color' => $column['design']['fonts']['titlecolor'])));
                            }

                            if (!isset($column['width'])) $column['width'] = $this->column_defaults['width'];
                            // Add the correct span class
                            $span_class = 'span-' . $column['width'];

                            // Add .last to the final column
                            $total_width += $column['width'];

                            if (12 == $total_width) {
                                $span_class .= ' last';
                                $total_width = 0;
                            } elseif ($total_width > 12) {
                                $total_width = 0;
                            }

                            // Set Featured Media
                            $featureimage = $this->check_and_return($column, 'design', 'featuredimage');
                            $featurevideo = $this->check_and_return($column, 'design', 'featuredvideo');

                            // Set Image Sizes
                            if (isset($column['design']['imageratios'])) {

                                // Translate Image Ratio into something usable
                                $image_ratio = layers_translate_image_ratios($column['design']['imageratios']);

                                if (!isset($column['width'])) $column['width'] = 6;

                                if ($column['width'] < 7) {
                                    $use_image_ratio = $image_ratio . '-medium';
                                } else {
                                    $use_image_ratio = $image_ratio . '-large';
                                }
                            } else {
                                if (7 < $column['width']) {
                                    $use_image_ratio = 'medium';
                                } else {
                                    $use_image_ratio = 'full';
                                }
                            }

                            $media = layers_get_feature_media(
                                $featureimage,
                                $use_image_ratio,
                                $featurevideo
                            );

                            // Set the column link
                            $link = $this->check_and_return($column, 'link');

                            // Set the Icon service icon if any
                            $icon_title = (isset($column['icon_title']) && $column['icon_title'] != '') ? $column['icon_title'] : null;

                            /**
                             * Set Individual Column CSS
                             */
                            $column_class = array();
                            $column_class[] = 'layers-masonry-column';
                            $column_class[] = $this->id_base . '-' . $column_key;
                            $column_class[] = $span_class;
                            $column_class[] = ('list-masonry' == $this->check_and_return($widget, 'design', 'liststyle') ? 'no-gutter' : '');
                            $column_class[] = 'column' . ('on' != $this->check_and_return($widget, 'design', 'gutter') ? '-flush' : '');

                            $column_class[] = ('on' == $this->check_and_return($column, 'c_no_padding') ? 'no-padding' : '');
                            $column_class[] = isset($column['c_class']) ? $column['c_class'] : '';

                            if($has_custom_margin){
                                $column_class[] = 'has-custom-margin';
                            }
                            if($has_custom_padding){
                                $column_class[] = 'has-custom-padding';
                            }

                            if ('' != $this->check_and_return($column, 'design', 'background', 'image') || '' != $this->check_and_return($column, 'design', 'background', 'color')) {
                                $column_class[] = 'content';
                            }
                            if (false != $media) {
                                $column_class[] = 'has-image';
                            }

                            $column_class = implode(' ', $column_class); ?>

                            <div id="<?php echo esc_attr($widget_id); ?>-<?php echo esc_attr($column_key); ?>" class="<?php echo esc_attr($column_class); ?>">
                                <?php /**
                                 * Set Overlay CSS Classes
                                 */
                                $column_inner_class = array();
                                $column_inner_class[] = 'media';
                                if (!$this->check_and_return($widget, 'design', 'gutter')) {
                                    $column_inner_class[] = 'no-push-bottom';
                                }

                                if($icon_title){
                                    $column_inner_class[] = 'has-icon-ti';
                                }

                                $column_inner_class[] = $this->check_and_return($column, 'design', 'imagealign');
                                $column_inner_class[] = $this->check_and_return($column, 'design', 'fonts', 'size');
                                $column_inner_class = implode(' ', $column_inner_class);

                                $image_responsive = $this->check_and_return($column, 'design', 'responsive') ? 'responsive-image' : '';

                                ?>
                                <div class="<?php echo esc_attr($column_inner_class); ?>">
                                    <?php if (NULL != $media) { ?>
                                        <div class="media-image <?php echo esc_attr($image_responsive);  echo((isset($column['design']['imageratios']) && 'image-round' == $column['design']['imageratios']) ? ' image-rounded' : ''); ?>">
                                            <?php if (NULL != $link) { ?><a href="<?php echo esc_url($link); ?>"><?php } ?>
                                                <?php echo $media; ?>
                                                <?php if (NULL != $link) { ?></a><?php } ?>
                                        </div>
                                    <?php } ?>

                                    <?php if(isset($column['icon_pull']) && isset($column['icon_title'])): ?>
                                        <div class="header-icon">
                                            <i class="<?php /* this filter TBD in the future */ echo esc_attr(apply_filters('tl/themify_filter', $column['icon_title'])); ?>"></i>
                                        </div>
                                    <?php endif; ?>
                                    <?php
                                        $show_btn = ($post_id || (isset($column['link']) && $this->check_and_return($column, 'link_text')));
                                        if ($this->check_and_return($column, 'title') || $this->check_and_return($column, 'excerpt') || $show_btn) { ?>
                                        <div class="media-body <?php echo (isset($column['design']['fonts']['align'])) ? $column['design']['fonts']['align'] : ''; ?>">
                                            <?php if ($this->check_and_return($column, 'title')) { ?>
                                                <h5 class="heading">
                                                    <?php if(!isset($column['icon_pull']) && isset($column['icon_title'])): ?>
                                                        <i class="<?php /* this filter TBD in the future */ echo esc_attr(apply_filters('tl/themify_filter', $column['icon_title'])); ?>"></i>
                                                    <?php endif; ?>

                                                    <?php if ($post_id || (NULL != $link && !(isset($column['link']) && $this->check_and_return($column, 'link_text')))) {
                                                    $the_link = $post_id ? get_the_permalink($post_id) : $column['link'];
                                                    ?>
                                                    <a data-title="<?php echo esc_attr($column['title']); ?>" class="ajax-popup-link" <?php echo ($post_id ? 'data-id="' . esc_attr($post_id) . '"' : ''); ?> href="<?php echo esc_url($the_link); ?>"><?php } ?>
                                                        <?php echo esc_html($column['title']); ?>
                                                        <?php if ($post_id || (NULL != $link && !(isset($column['link']) && $this->check_and_return($column, 'link_text')))) { ?></a><?php } ?>
                                                </h5>
                                            <?php } ?>
                                            <?php if ($this->check_and_return($column, 'excerpt')) { ?>
                                                <div class="excerpt"><?php echo apply_filters('the_content', $column['excerpt']); ?></div>
                                            <?php } ?>
                                            <?php if ($show_btn) {

                                                $the_link = $post_id ? get_the_permalink($post_id) : $column['link'];

                                                $btn_classes   = array();
                                                $btn_classes[] = 'ajax-popup-link button'; //button-secondary-style
                                                $btn_classes[] = 'btn-' . $this->check_and_return($widget, 'design', 'buttons', 'buttons-size');
                                                $btn_classes[] = $this->check_and_return($widget, 'design', 'buttons', 'animation');
                                                $btn_classes = implode(' ', $btn_classes);
                                                ?>
                                                <a <?php echo ($post_id ? 'data-id="' . esc_attr($post_id) . '"' : ''); ?> href="<?php echo esc_url($the_link); ?>"
                                                                                                                           data-title="<?php echo esc_attr($column['title']); ?>" class="<?php echo esc_attr($btn_classes)?>">
                                                    <?php echo esc_html($column['link_text']); ?><i class="icon-ti-angle-double-right"></i>
                                                </a>
                                            <?php } ?>
                                            <p class="phantom-padding"></p>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                        <?php } ?>
                        </div><!-- .grid -->
                    </div>
                <?php }

                if($is_testimonial_widget): ?>
                    <div class="container">
                        <?php echo \Handyman\Front\get_partners(); ?>
                    </div>
                <?php endif;

                do_action( 'layers_after_' . $this->id . '_widget_inner', $this, $widget );

                // Print the Inline Styles for this Widget
                $this->print_inline_css();

                // Apply the advanced widget styling
                $this->apply_widget_advanced_styling($widget_id, $widget);
                ?>
            </div>

            <?php if ('list-masonry' == $this->check_and_return($widget, 'design', 'liststyle')) { ?>
            <script>
                jQuery(function ($) {
                    "use strict";
                    layers_masonry_settings['<?php echo esc_attr($widget_id); ?>'] = [{
                        itemSelector: '.layers-masonry-column',
                        layoutMode: 'masonry',
                        gutter: <?php echo ( isset( $widget['design'][ 'gutter' ] ) ? 20 : 0 ); ?>
                    }];
                    $('#<?php echo esc_attr($widget_id); ?>').find('.list-masonry').layers_masonry(layers_masonry_settings['<?php echo esc_attr($widget_id); ?>'][0]);
                });
            </script>
        <?php } // masonry trigger ?>
        <?php }



        /**
         *  Widget form
         *
         * We use regular HTML here, it makes reading the widget much easier than if we used just php to echo all the HTML out.
         *
         */
        public function form($instance)
        {
            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );


            $design_bar_components = apply_filters('layers_' . $this->widget_id . '_widget_design_bar_components', array(
                'layout',
                'liststyle' => array(
                    'icon-css' => 'icon-list-masonry',
                    'label' => __('List Style', 'layerswp'),
                    'wrapper-class' => 'layers-small to layers-pop-menu-wrapper layers-animate',
                    'elements' => array(
                        'liststyle' => array(
                            'type' => 'select-icons',
                            'name' => $this->get_field_name('design') . '[liststyle]',
                            'id' => $this->get_field_id('design-liststyle'),
                            'value' => (isset($widget['design']['liststyle'])) ? $widget['design']['liststyle'] : NULL,
                            'options' => array(
                                'list-grid' => __('Grid', 'layerswp'),
                                'list-masonry' => __('Masonry', 'layerswp')
                            )
                        ),
                        'gutter' => array(
                            'type' => 'checkbox',
                            'label' => __('Gutter', 'layerswp'),
                            'name' => $this->get_field_name('design') . '[gutter]',
                            'id' => $this->get_field_id('design-gutter'),
                            'value' => (isset($widget['design']['gutter'])) ? $widget['design']['gutter'] : NULL
                        )
                    )
                ),
                'fonts',
                'buttons',
                'background',
                'advanced'
            ));

            if(TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_start('tl_sanitize_output');

            $this->design_bar(
                'side', // CSS Class Name
                array(
                    'name' => $this->get_layers_field_name('design'),
                    'id' => $this->get_layers_field_id('design'),
                    'widget_id' => $this->widget_id,
                ), // Widget Object
                $widget, // Widget Values
                $design_bar_components//, // Standard Components
            ); ?>
            <div class="layers-container-large layers-tl_column-widget" id="layers-<?php echo esc_attr($this->widget_id); ?>-widget-<?php echo esc_attr($this->number); ?>">
                <?php $this->form_elements()->header(array(
                    'title' => 'TL Content',
                    'icon_class' => 'text'
                )); ?>
                <section class="layers-accordion-section layers-content">
                    <p class="layers-form-item">
                        <?php echo $this->form_elements()->input(
                            array(
                                'type' => 'text',
                                'name' => $this->get_layers_field_name('title'),
                                'id' => $this->get_layers_field_id('title'),
                                'placeholder' => __('Enter title here', 'layerswp'),
                                'value' => (isset($widget['title'])) ? $widget['title'] : NULL,
                                'class' => 'layers-text layers-large'
                            )
                        ); ?>
                    </p>
                    <p class="layers-form-item">
                        <?php echo $this->form_elements()->input(
                            array(
                                'type' => 'rte',
                                'name' => $this->get_layers_field_name('excerpt'),
                                'id' => $this->get_layers_field_id('excerpt'),
                                'placeholder' => __('Short Excerpt', 'layerswp'),
                                'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                'class' => 'layers-textarea layers-large'
                            )
                        ); ?>
                    </p>
                </section>
                <section class="layers-accordion-section layers-content">
                    <div class="layers-form-item">
                        <?php $this->repeater( 'column', $widget ); ?>
                    </div>
                </section>
            </div>
        <?php
            if(TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_end_flush();
        } // Form


        /**
         * @param $item_guid
         * @param $widget
         */
        function column_item( $item_guid, $widget )
        {
            ?>
            <li class="layers-accordion-item" data-guid="<?php echo esc_attr($item_guid); ?>">
                <a class="layers-accordion-title">
						<span>
							<?php _e('Column', 'layerswp'); ?>
                            <span class="layers-detail">
								<?php echo(isset($widget['title']) ? ': ' . substr(stripslashes(strip_tags($widget['title'])), 0, 50) : NULL); ?>
                                <?php echo(isset($widget['title']) && strlen($widget['title']) > 50 ? '...' : NULL); ?>
							</span>
						</span>
                </a>
                <section class="layers-accordion-section layers-content">
                    <?php $this->design_bar(
                        'top', // CSS Class Name
                        array(
                            'name' => $this->get_layers_field_name('design'),
                            'id' => $this->get_layers_field_id('design'),
                            'widget_id' => $this->widget_id . '_item',
                            'number' => $this->number,
                            'show_trash' => true
                        ), // Widget Object
                        $widget, // Widget Values
                        array(
                            'background',
                            'featuredimage',
                            'imagealign',
                            'fonts',
                            'title_attrs' => array(
                                'icon-css' => 'icon-call-to-action',
                                'label' => 'Icon',
                                'wrapper-class' => 'layers-pop-menu-wrapper layers-content-small tl-title-options',
                                'elements' => array(
                                    'icon_pull' => array(
                                        'type' => 'checkbox',
                                        'label' => __('Pull Icon to left', 'layerswp'),
                                        'name'  => $this->get_layers_field_name('icon_pull'),//'widget-' . $widget['id_base'] . '[' . $widget['number'] . '][columns][' . $item_guid . '][icon_pull]',
                                        'id'    => $this->get_layers_field_id('icon_pull'),//'widget-' . $widget['id_base'] . '-' . $widget['number'] . '-' . $item_guid . '-icon_pull',
                                        'value' => (isset($widget['icon_pull'])) ? $widget['icon_pull'] : NULL,
                                    ),
                                    'icon_btn' => array(
                                        'type' => 'button',
                                        'class' => 'expand-icons themify',
                                        'label' => 'Select an Icon',
                                        'name' => $this->get_layers_field_name('icon_btn'),
                                        'id' => $this->get_layers_field_id('icon_btn'),
                                    ),
                                    'icon_title' => array(
                                        'type' => 'hidden',
                                        'name' => $this->get_layers_field_name('icon_title'),
                                        'id' => $this->get_layers_field_id('icon_title'),
                                        'value' => (isset($widget['icon_title']) && $widget['icon_title'] != '') ? $widget['icon_title'] : null
                                    )
                                ),
                            ),
                            'width' => array(
                                'icon-css' => 'icon-columns',
                                'label' => 'Column Width',
                                'elements' => array(
                                    'layout' => array(
                                        'type' => 'select',
                                        'label' => '',
                                        'name' => $this->get_layers_field_name('width'),//'widget-' . $widget['id_base'] . '[' . $widget['number'] . '][columns][' . $item_guid . '][width]',
                                        'id' => $this->get_layers_field_id('width'),//'widget-' . $widget['id_base'] . '-' . $widget['number'] . '-' . $item_guid . '-width',
                                        'value' => (isset($widget['width'])) ? $widget['width'] : NULL,
                                        'options' => array(
                                            '1' => __('1 of 12 columns', 'layerswp'),
                                            '2' => __('2 of 12 columns', 'layerswp'),
                                            '3' => __('3 of 12 columns', 'layerswp'),
                                            '4' => __('4 of 12 columns', 'layerswp'),
                                            '5' => __('5 of 12 columns', 'layerswp'),
                                            '6' => __('6 of 12 columns', 'layerswp'),
                                            '7' => __('7 of 12 columns', 'layerswp'),
                                            '8' => __('8 of 12 columns', 'layerswp'),
                                            '9' => __('9 of 12 columns', 'layerswp'),
                                            '10' => __('10 of 12 columns', 'layerswp'),
                                            '11' => __('11 of 12 columns', 'layerswp'),
                                            '12' => __('12 of 12 columns', 'layerswp')
                                        )
                                    ),
                                    'c_no_padding' => array(
                                        'type'=> 'checkbox',
                                        'label' => __('Force column without padding', 'layerswp'),
                                        'name' => $this->get_layers_field_name('c_no_padding'),//'widget-' . $widget['id_base'] . '[' . $widget['number'] . '][columns][' . $item_guid . '][c_no_padding]',
                                        'id' => $this->get_layers_field_id('c_no_padding'),//'widget-' . $widget['id_base'] . '-' . $widget['number'] . '-' . $item_guid . '-c_no_padding',
                                        'value' => (isset($widget['c_no_padding'])) ? $widget['c_no_padding'] : NULL,
                                    ),
                                    'c_padding' => array(
                                        'type' => 'trbl-fields',
                                        'label' => __('Column inner padding (px)', 'layerswp'),
                                        'name' => $this->get_layers_field_name('c_padding'),//'widget-' . $widget['id_base'] . '[' . $widget['number'] . '][columns][' . $item_guid . '][c_padding]',
                                        'id' => $this->get_layers_field_id('c_padding'),//'widget-' . $widget['id_base'] . '-' . $widget['number'] . '-' . $item_guid . '-c_padding',
                                        'value' => (isset($widget['c_padding']) && is_array($widget['c_padding'])) ? $widget['c_padding'] : NULL,
                                    ),
                                    'c_margin'  => array(
                                        'type' => 'trbl-fields',
                                        'label' => __('Column inner margin (px)', 'layerswp'),
                                        'name' => $this->get_layers_field_name('c_margin'),//'widget-' . $widget['id_base'] . '[' . $widget['number'] . '][columns][' . $item_guid . '][c_margin]',
                                        'id' => $this->get_layers_field_id('c_margin'),//'widget-' . $widget['id_base'] . '-' . $widget['number'] . '-' . $item_guid . '-c_margin',
                                        'value' => (isset($widget['c_margin']) && is_array($widget['c_margin'])) ? $widget['c_margin'] : NULL,
                                    ),
                                    'c_class'  => array(
                                        'type' => 'text',
                                        'placeholder' => 'example-class',
                                        'label' => __('Custom class', 'layerswp'),
                                        'name' => $this->get_layers_field_name('c_class'),//'widget-' . $widget['id_base'] . '[' . $widget['number'] . '][columns][' . $item_guid . '][c_class]',
                                        'id' => $this->get_layers_field_id('c_class'),//'widget-' . $widget['id_base'] . '-' . $widget['number'] . '-' . $item_guid . '-c_class',
                                        'value' => (isset($widget['c_class'])) ? $widget['c_class'] : NULL,
                                    ),
                                )
                            ),
                        )
                    );
                    ?>
                    <div class="layers-row">
                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('post_item'))?>"><?php _e('Select a page', 'layerswp'); ?></label>
                            <?php echo $this->form_elements()->input(array(
                                'type' => 'select',
                                'name' => $this->get_layers_field_name('post_item'),
                                'id' => $this->get_layers_field_id('post_item'),
                                'label' => __('Select a Page', 'layerswp'),
                                'options' => tl_get_posts(array('post_type'    => 'page',
                                    'meta_key'     => '_wp_page_template',
                                    'meta_value'   => 'builder.php',
                                    'meta_compare' => '!='
                                )),
                                'value' => (isset($widget['post_item'])) ? $widget['post_item'] : NULL,
                                'class' => 'layers-select layers-large tl-select-post-item',
                                'placeholder' => __('-- None --', 'layerswp'),
                            ));
                            ?>
                        </p>
                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('title')); ?>"><?php _e('Title', 'layerswp'); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'text',
                                    'name' => $this->get_layers_field_name('title'),
                                    'id' => $this->get_layers_field_id('title'),
                                    'placeholder' => __('Enter title here', 'layerswp'),
                                    'value' => (isset($widget['title'])) ? $widget['title'] : NULL,
                                    'class' => 'layers-text'
                                )
                            ); ?>
                        </p>
                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('excerpt')); ?>"><?php _e('Excerpt', 'layerswp'); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'rte',
                                    'name' => $this->get_layers_field_name('excerpt'),
                                    'id' => $this->get_layers_field_id('excerpt'),
                                    'placeholder' => __('Short Excerpt', 'layerswp'),
                                    'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                    'class' => 'layers-form-item layers-textarea',
                                    'rows' => 6
                                )
                            ); ?>
                        </p>
                        <div class="layers-row">
                            <p class="layers-form-item layers-column layers-span-6">
                                <label for="<?php echo esc_attr($this->get_layers_field_id('link')); ?>"><?php _e('Button Link', 'layerswp'); ?></label>
                                <?php echo $this->form_elements()->input(
                                    array(
                                        'type' => 'text',
                                        'name' => $this->get_layers_field_name('link'),
                                        'id' => $this->get_layers_field_id('link'),
                                        'placeholder' => __('http://', 'layerswp'),
                                        'value' => (isset($widget['link'])) ? $widget['link'] : NULL,
                                        'class' => 'layers-text',
                                    )
                                ); ?>
                            </p>
                            <p class="layers-form-item layers-column layers-span-6">
                                <label for="<?php echo esc_attr($this->get_layers_field_id('link_text')); ?>"><?php _e('Button Text', 'layerswp'); ?></label>
                                <?php echo $this->form_elements()->input(
                                    array(
                                        'type' => 'text',
                                        'name' => $this->get_layers_field_name('link_text'),
                                        'id' => $this->get_layers_field_id('link_text'),
                                        'placeholder' => __('e.g. "Read More"', 'layerswp'),
                                        'value' => (isset($widget['link_text'])) ? $widget['link_text'] : NULL,
                                    )
                                ); ?>
                            </p>
                        </div>
                    </div>
                </section>
            </li>
        <?php
        }


        protected function _addFilters()
        {
            add_filter('tl/layers/customizer/before_save_' . $this->widget_id, array($this, 'filterTitleIcons'),10,2);
            add_filter('tl_colorize_title_' . $this->widget_id, 'tl_colorize_title', 10, 2);

            add_filter('tl/layers/buttons_component/' . $this->widget_id . '/args', array($this, 'customizeButtonsComponent'), 10, 4);
            add_filter('tl/layers/background_component/' . $this->widget_id . '/args', array($this, 'customizeBackgroundComponent'), 10, 4);
            add_filter('tl/layers/fonts_component/' . $this->widget_id . '/args'     , array($this, 'customizeFontsComponent'), 10, 4);
            add_filter('tl/layers/featuredimage_component/' . $this->widget_id . '/args'     , array($this, 'customizeFeaturedImagesComponent'), 10, 4);
        }

        /**
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeFontsComponent($args, $position, $widget, $values)
        {
            if($position == 'side'){

                //Add at the beggining of the array
                $args['elements'] = array('fonts-title-heading' => array('type'  => 'layers-heading', 'label' => 'Title Options')) + $args['elements'];


                // this goes to the all widgets
                $args['elements']['fonts-excerpt-heading'] = array(
                    'type'  => 'layers-heading',
                    'label' => 'Excerpt Options',
                );

                $args['elements']['fonts-excerpt-color'] = array(
                    'type'  => 'color',
                    'label' => 'Excerpt Color',
                    'name'  => $widget['name'].'[fonts][excerpt-color]',
                    'id'    => $widget['id'] . '-fonts-excerpt-color',
                    'value' => isset($values['fonts']['excerpt-color']) ? $values['fonts']['excerpt-color'] : null,
                );
            }elseif($position == 'top'){

                $args['elements']['titlecolor'] = array(
                    'type' => 'color',
                    'label' => 'Title & Icon Color',
                    'name' => $widget['name'].'[fonts][titlecolor]', //$this->get_layers_field_name('titlecolor'),//'widget-' . $widget['id_base'] . '[' . $widget['number'] . '][columns][' . $item_guid . '][titlecolor]',
                    'id' => $widget['id'].'-fonts-titlecolor',     //$this->get_layers_field_id('titlecolor'),//'widget-' . $widget['id_base'] . '-' . $widget['number'] . '-' . $item_guid . '-titlecolor',
                    'value' => isset($values['fonts']['titlecolor']) ? $values['fonts']['titlecolor'] : null
                );
            }
            return $args;
        }



        public function customizeBackgroundComponent($args, $position, $widget, $values)
        {
            return $args;
        }



        public function customizeButtonsComponent($args, $position, $widget, $values)
        {
            if($position == 'side'){
                unset($args['elements']['buttons-label']);
                unset($args['elements']['buttons-align']);
            }
            return $args;
        }



        public function customizeFeaturedImagesComponent($args, $position, $widget, $values)
        {
            if($position == 'top'){
                $args['elements']['responsive'] = array(
                    'type' => 'checkbox',
                    'label' => __('Make image responsive', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[responsive]',
                    'id' => $widget['id'] . '-responsive',
                    'value' => (isset($values['responsive'])) ? $values['responsive'] : NULL,
                );
            }
            return $args;
        }


        /**
         * @param $widget_id
         * @param $widget
         */
        protected function _apply_widget_additional_styling($widget_id, $widget)
        {
            if($this->check_and_return($widget, 'design', 'background', 'darken')){

                $bg_color = $this->check_and_return($widget, 'design', 'background', 'color');
                if(!$bg_color){
                    $bg_color = '#000';
                }
                $bg_color_alpha = apply_filters('tl/hex2rgba', $bg_color, 0.75, true);
                $this->inline_css .= layers_inline_styles('#' . $widget_id . ' .bg-overlay{ background-color:rgba('.$bg_color_alpha.');}' );
            }
        }


        public function loadIcons()
        {
            include_once 'icons.php';
            global $tl_icons;
            foreach($tl_icons as $class){
                $this->_icons[$class] = '.' . $class;
            }

            if(!defined('TL_THEME_VER')){
                define('TL_THEME_VER', '1.0');
            }
        }




        /**
         * Do not save ti-none
         *
         * @param $new_instance
         * @param $old_instance
         */
        public function filterTitleIcons($new_instance, $old_instance)
        {
            // Filter before saving
            foreach($new_instance['columns'] as $k => $v){
                if(isset($v['icon_title']) && $v['icon_title'] == 'ti-none' || $v['icon_title']=='' ){
                    unset($new_instance['columns'][$k]['icon_title']);
                }
            }
            return $new_instance;
        }
    } // Class

    // Add our function to the widgets_init hook.
    register_widget("TL_Layers_Content_Widget");
}