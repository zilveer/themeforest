<?php

//Creating TinyMCE buttons
//********************************************************************
//check user has correct permissions and hook some functions into the tiny MCE architecture.
function multipurpose_add_editor_button() {
    //Check if user has correct level of privileges + hook into Tiny MC methods.
    if (current_user_can('edit_posts') && current_user_can('edit_pages')) {
        //Check if Editor is in Visual, or rich text, edior mode.
        if (get_user_option('rich_editing')) {
            //Called when tiny MCE loads plugins - 'add_custom' is defined below.
            add_filter('mce_external_plugins', 'multipurpose_add_custom');
            //Called when buttons are loading. -'register_button' is defined below.
            add_filter('mce_buttons', 'multipurpose_register_button');
        }
    }
}

//add action is a wordpress function, it adds a function to a specific action...
//in this case the function is added to the 'init' action. Init action runs after wordpress is finished loading!
add_action('init', 'multipurpose_add_editor_button');

//Add button to the button array.
function multipurpose_register_button($buttons) {
    //Use PHP 'array_push' function to add the columnThird button to the $buttons array
    array_push($buttons, "columnThird");
    //Return buttons array to TinyMCE
    return $buttons;
}

//Add custom plugin to TinyMCE - returns associative array which contains link to JS file. The JS file will contain your plugin when created in the following step.
function multipurpose_add_custom($plugin_array) {
    if (get_bloginfo('version') > 3.8)
        $plugin_array['columnThird'] = plugin_dir_url(__file__) . 'js/shortcode-3.9.js';
    else
        $plugin_array['columnThird'] = plugin_dir_url(__file__) . 'js/shortcode.js';

    return $plugin_array;
}

function multipurpose_add_shortcode_menu() {
    ?>	

    <div class="hidden" style="display:none">
        <div class="shortcode-html">
            <a href="javascript:;" class="button-add-shortcode">[+]</a>
            <ul>
                <li class="parent">
                    <a href="javascript:;" onclick="return false;">Elements</a>
                    <ul>				
                        <li><a href="#" data-param='color="e.g. orange, green, turquoise, azure, blue, purple, pink, red, brown, dark-gray, light-gray" size="small or large" open_in_new_window="e.g. yes, no" link="" icon="e.g. fa-home"' data-tag='button' data-all="" data-text="Button text">Button</a></li>
                        <li><a href="#" data-param='box_type="e.g. info, success, notice, error" hide_text="x"'  data-tag='messages' data-all="" data-text="Messages text">Alert message</a></li>
                        <li><a href="#" data-param='box_type="e.g. normal, confirm, warning, info, alert"' data-tag='content_box' data-all="" data-text="<h3>Place for title</h3><p>Place for content</p>">Content box</a></li>			
                        <li><a href="#" data-all='[author image_url="Image url"  image_alt="Image alt" name="Author name" link="Author link"] <br/>[author_content]This is author content[/author_content]<br/>[/author]'>Author Info</a></li>
                        <li><a href="#" data-all='[promobox slogan="Slogan" button_link="Button link" button_text="Button text"][/promobox]'>Promo box</a></li>
                        <li><a href="#" data-param='link_url="put URL here"' data-tag='more' data-all="" data-text="Read more">More link</a></li>
                        <li><a href="#" data-param='' data-tag='intro' data-all="" data-text="<h1><strong>Colored text</strong> place for headline</h1><p>Place for text</p>">Intro</a></li>
                        <li><a href="#" data-param='' data-tag='circle' data-all="" data-text="Put font awesome icon here">Circle</a></li>
                        <li><a href="#" data-all='[icon name="e.g. fa-rocket" size="e.g. 1, 2, 3, 4, 5" color="empty or e.g. #ccc" background_color="empty or e.g. #fff" circled_background="e.g. yes, no"]'>Icon</a></li>
                        <li><a href="#" data-all='[stacked_icons stack_size="e.g. lg, 1, 2, 3, 4, 5" icon_1_name="e.g. fa-circle" icon_1_color="empty or e.g. #000" icon_1_size="e.g. lg, 1, 2, 3, 4, 5" icon_2_name="e.g. fa-thumbs-up" icon_2_color="empty or e.g. #fff" icon_2_size="e.g. lg, 1, 2, 3, 4, 5"]'>Stacked Icons</a></li>
						<li><a href="#" data-all='[fullwidth edges="e.g. 0, 1" id="e.g. fullwidth-container-1" background_color="e.g. #ffe6cc" padding_top="e.g. 9" padding_right="e.g. 0" padding_bottom="e.g. 25" padding_left="e.g. 0" background_image="put image URL here" background_position="e.g. left top, left center, left bottom, right top, right center, right bottom, center top, center center, center bottom" background_repeat="e.g. repeat, no-repeat, repeat-x, repeat-y" parallax="e.g. 0, 1" margin_top="" margin_bottom=""]Place for content[/fullwidth]'>Fullwidth Container</a></li>
						
						 
                    </ul>	
                </li>
                <li class="parent">
                    <a href="javascript:;" onclick="return false;">Columns</a>
                    <ul>
                        <li><a href="#" data-param='' data-tag='columns' data-all="" data-text="">Columns Container</a></li>
                        <li><a href="#" data-all='[columns]<br/>[one_full]One Full[/one_full]<br/>[/columns]'>1/1</a></li>
                        <li><a href="#" data-all='[columns]<br/>[one_half]One half[/one_half] <br/>[one_half]One half[/one_half]<br/>[/columns]'>1/2, 1/2</a></li>
                        <li><a href="#" data-all='[columns]<br/>[one_third]One third[/one_third]<br/>[one_third]One third[/one_third]<br/>[one_third]One third[/one_third]<br/>[/columns]'>1/3, 1/3, 1/3</a></li>
                        <li><a href="#" data-all='[columns]<br/>[one_fourth]One fourth[/one_fourth]<br/>[one_fourth]One fourth[/one_fourth]<br/>[one_fourth]One fourth[/one_fourth]<br/>[one_fourth]One fourth[/one_fourth]<br/>[/columns]'>1/4, 1/4, 1/4, 1/4</a></li>
                        <li><a href="#" data-all='[columns]<br/>[one_third]One third[/one_third]<br/>[two_thirds]Two thirds[/two_thirds]<br/>[/columns]'>1/3, 2/3</a></li>
                        <li><a href="#" data-all='[columns]<br/>[one_fourth]One fourth[/one_fourth]<br/>[one_fourth]One fourth[/one_fourth]<br/>[one_half]One half[/one_half]<br/>[/columns]'>1/4, 1/4, 1/2</a></li>
                        <li><a href="#" data-all='[columns]<br/>[one_fourth]One fourth[/one_fourth]<br/>[three_fourths]Three fourths[/three_fourths]<br/>[/columns]'>1/4, 3/4</a></li>
                        <li><a href="#" data-all='[columns]<br/>[one_fifth]One fifth[/one_fifth]<br/>[one_fifth]One fifth[/one_fifth]<br/>[one_fifth]One fifth[/one_fifth]<br/>[one_fifth]One fifth[/one_fifth]<br/>[one_fifth]One fifth[/one_fifth]<br/>[/columns]'>1/5, 1/5, 1/5, 1/5, 1/5</a></li>
                        <li><a href="#" data-all='[columns]<br/>[one_sixth]One sixth[/one_sixth]<br/>[one_sixth]One sixth[/one_sixth]<br/>[one_sixth]One sixth[/one_sixth]<br/>[one_sixth]One sixth[/one_sixth]<br/>[one_sixth]One sixth[/one_sixth]<br/>[one_sixth]One sixth[/one_sixth]<br/>[/columns]'>1/6, 1/6, 1/6, 1/6, 1/6, 1/6</a></li>
                    </ul>	
                </li>

                <li class="parent">
                    <a href="javascript:;" onclick="return false;">Sections</a>
                    <ul>
                        <li><a href="#" data-all='[accordions]<br/>[accordion title="Accordion one"]<p>Accordion one content</p>[/accordion]<br/>[accordion title="Accordion two"]<p>Accordion two content</p>[/accordion]<br/>[accordion title="Accordion three"]<p>Accordion three content</p>[/accordion]<br/>[/accordions]'>Accordion</a></li>
                        <li><a href="#" data-all='[blog_with_date_exposed number_posts=" e.g. 2" excerpt="e.g. yes, no" excerpt_words="e.g. 30" strip_html="e.g. yes, no"]'>Blog with date exposed</a></li>

                        <li><a href="#" data-all='[clients title="Place for title"] <br/>[client title="client one" link="Link" image_alt="Image alt" image_url="Image url"][/client]<br/>[client title="client two" link="Link" image_alt="Image alt" image_url="Image url"][/client]<br/>[client title="client three" link="Link" image_alt="Image alt" image_url="Image url"][/client]<br/>[/clients]'>Clients</a></li>
                        <li><a href="#" data-param='image_url="put image url here" image_alt="Image description"' data-tag='headline_with_icon' data-all="" data-text="Put headline text here">Headline with image</a></li>
                        <li><a href="#" data-all='[offers]<h2><span>Place for title</span></h2>[offer image_url="Put image url here" image_alt="Image description" link=""]<h3><a href="#">Place for headline</a></h3><p>Place for text</p>[/offer][offer image_url="Put image url here" image_alt="Image description"]<h3><a href="#">Place for headline</a></h3><p>Place for text</p>[/offer][offer image_url="Put image url here" image_alt="Image description"]<h3><a href="#">Place for headline</a></h3><p>Place for text</p>[/offer][/offers]'>Offer</a></li>
                        <li><a href="#" data-all='[recent_posts_in_columns number_of_columns="e.g. 2" thumbnail="e.g. yes, no" excerpt="e.g. yes, no" excerpt_words="e.g. 30" strip_html="e.g. yes, no" headline="e.g. yes, no" translate_read_more="Read more"]'>Recent Posts in Columns</a></li>
                        <li><a href="#" data-all='[recent_projects title="Latest projects" number_of_columns="e.g. 3" view_anchor_text="View" go_anchor_text="Go" excerpt="e.g. yes, no" excerpt_words="e.g. 30" strip_html="e.g. yes, no" headline="e.g. yes, no"][/recent_projects]'>Recent Projects</a></li>	
                        <li><a href="#" data-all='[recent_posts number_posts=" e.g. 2" thumbnail="e.g. yes, no" meta="e.g. yes, no" excerpt="e.g. yes, no" excerpt_words="e.g. 30" strip_html="e.g. yes, no" headline="e.g. yes, no" read_more="Read more"]'>Recent Posts</a></li>
                        <li><a href="#" data-all='[recent_works title="Recent works" number_posts="e.g. 10" view_anchor_text="View" go_anchor_text="Go" excerpt="e.g. yes, no" excerpt_words="e.g. 30" strip_html="e.g. yes, no" headline="e.g. yes, no"][/recent_works]'>Recent Projects Carousel</a></li>
                        <li><a href="#" data-all='[services]<br>[service image_url="Put image url here" image_alt="Image description"]<h3><a href="#">Place for headline</a></h3><p>Place for text</p>[/service][service image_url="Put image url here" image_alt="Image description"]<h3><a href="#">Place for headline</a></h3><p>Place for text</p>[/service][service image_url="Put image url here" image_alt="Image description"]<h3><a href="#">Place for headline</a></h3><p>Place for text</p>[/service][/services]'>Services</a></li>
                        <li><a href="#" data-all='[slider] <br/>[slide title="Slide one" image_url="Image url" image_alt="Image alt"]<br/>[slide_content]Slide content[/slide_content]<br/>[/slide]<br/>[slide title="slide two" image_url="Image url" image_alt="Image alt"]<br/>[slide_content]Slide content[/slide_content]<br>[/slide]<br/>[slide title="Slide three" image_url="Image url" image_alt="Image alt"]<br/>[slide_content]Slide content[/slide_content]<br>[/slide]<br/>[/slider]'>Slider</a></li>
                        <li><a href="#" data-all='[social_icons]<br/>
                               [social link="Link" type="e.g. email, facebook, twitter, pinterest, rss, linkedin, flickr, vimeo, blogger, tumblr, skype, behance, googleplus, youtube, dribble, instagram, picasa, github, stumbleupon, lastfm"]Social icon[/social]<br/>
                               [/social_icons]'>Social Icon</a></li>
                        <li><a href="#" data-all='[table style="e.g. style1, style2"]<br/>[table_open_row]<br/>[table_title]Table title[/table_title]<br/>[table_title]Table title[/table_title]<br/>[/table_open_row]<br/>[table_open_row]<br/>[table_content]Table content[/table_content]<br/>[table_content]Table content[/table_content]<br/>[/table_open_row]<br/>[table_open_row]<br/>[table_content]Table content[/table_content]<br/>[table_content]Table content[/table_content]<br/>[/table_open_row]<br/>[table_open_row]<br/>[table_content]Table content[/table_content]<br/>[table_content]Table content[/table_content]<br/>[/table_open_row]<br/>[table_open_row]<br/>[table_content]Table content[/table_content]<br/>[table_content]Table content[/table_content]<br/>[/table_open_row]<br/>[table_open_row]<br/>[table_content]Table content[/table_content]<br/>[table_content]Table content[/table_content]<br/>[/table_open_row]<br/>[/table]'>Table</a></li>
                        <li><a href="#" data-all='[tabs vertical="e.g. yes, no"]<br/>[tab title="Tab one"]Tab one content[/tab]<br/>[tab title="Tab two"]Tab two content[/tab]<br/>[tab title="Tab three"]Tab three content[/tab]<br/>[/tabs]'>Tabbed content</a></li>
                        <li><a href="#" data-all='[toggles]<br/>[toggle title="Toggle one"]<p>Toggle one content</p>[/toggle]<br/>[toggle title="Toggle two"]<p>Toggle two content</p>[/toggle]<br/>[toggle title="Toggle three"]<p>Toggle three content</p>[/toggle]<br/>[/toggles]'>Toggle</a></li>	
                        <li><a href="#" data-all='[team_member name="e.g. Michael Brown" position="e.g. CEO / Co-Founder" image_url="put image URL here" image_alt="Image description"  facebook="https://facebook.com/" twitter="https://twitter.com" google="https://google.com/" linkedin="https://www.linkedin.com/" mail="put e-mail here"]Place for text[/team_member]'>Team Member</a></li>
                        <li><a href="#" data-all='[testimonial name="e.g. Michael Brown" name_link="" org="e.g. Company Name" org_link="" avatar="put image url here"]Testimonial content[/testimonial]'>Testimonial</a></li>
						 <li><a href="#" data-all='[testimonial_slider title="Testimonials title" delay="9000" duration="800" auto="1"]<br/>[testimonial name="e.g. Michael Brown" org="e.g. Company Name" avatar="put image url here"]Testimonial content[/testimonial]<br/>[testimonial name="e.g. Michael Brown" org="e.g. Company Name" avatar="put image url here"]Testimonial content[/testimonial]<br/>[testimonial name="e.g. Michael Brown" org="e.g. Company Name" avatar="put image url here"]Testimonial content[/testimonial]<br/>[/testimonial_slider]'>Testimonial Slider</a></li>
                        <li><a href="#" data-all='[timeline]<br>[timeline_events]<br>[timeline_event]<h3>Place for event headline</h3><p>Place for event content</p>[/timeline_event]<br>[timeline_milestone]<h2>Place for milestone text</h2>[/timeline_milestone]<br>[timeline_event]<h3>Place for event headline</h3><p>Place for event content</p>[/timeline_event]<br>[/timeline_events]<br>[timeline_begin]<h2>Place for begin headline</h2><p>Place for event content</p>[/timeline_begin]<br>[/timeline]'>Timeline</a></li>
                    </ul>
                    </a>
                </li>
                <li class="parent">
                    <a href="javascript:;" onclick="return false;">Counters and Bar Graphs</a>
                    <ul>
                        <li><a href="#" data-all='[counter month="e.g. 1" year="e.g. 2014" day="e.g. 26" hour="e.g. 19" minute="e.g. 0" translate_days="e.g. days" translate_day="e.g. day" translate_hours="e.g. hours" translate_hour="e.g. hour" translate_minutes="e.g. minutes" translate_minute="e.g. minute" translate_seconds="e.g. seconds" translate_second="e.g. second" location="e.g. GMT"]'>Counters</a></li>
                        <li><a href="#" data-param='percent="100%"' data-tag='progress' data-all="" data-text="Progress text">Progress bar</a></li>
                    </ul>	
                </li>
                <li class="parent">
                    <a href="javascript:;" onclick="return false;">Typography</a>
                    <ul>
                        <li><a href="#" data-param='type="e.g. 1, 2, 3, 4, 5, 6, 7"' data-tag='divider' data-all='' data-text="">Divider</a></li>
                        <li><a href="#" data-param='style="e.g. 1, 2"' data-tag='dropcap' data-all='' data-text="Dropcap">Dropcap</a></li>
                        <li><a href="#" data-all='[unordered_list style="e.g. tick, dash"]<br><ul><li>List Item</li></ul>[/unordered_list]'>List (with tick or dash)</a></li>
                        <li><a href="#" data-param='color="e.g. dark, bright" title="Tooltip title"' data-tag='tooltip' data-all="" data-text="Tooltip text">Tooltip</a></li>
                        <li><a href="#" data-param='type="e.g. h1, h2, h3, h4, h5, h6" underline="eg. yes, no"' data-tag='special_heading' data-all='' data-text="Heading">Special heading</a></li>
                        <li><a href="#" data-all='[quote]<br/>[quote_content]Quote content[/quote_content]<br/>[quote_signature name="Name"]Quote signature[/quote_signature]<br/>[/quote]'>Quote</a></li>
                    </ul>	
                </li>

                <li class="parent">
                    <a href="javascript:;" onclick="return false;">Pricing</a>
                    <ul>
                        <li><a href="#"  data-all='[pricing_plans]<br />[pricing_plan title="Title" subtitle="Subtitle" price="free" selected="no" button_text="Button" button_link="Link" before_price="" after_price=""]<ul><li><strong>Custom</strong> text1</li><li>Custom text2</li><li>Custom text3</li><li><strong>Custom</strong> text4</li></ul>[/pricing_plan]<br />[pricing_plan title="Title" subtitle="Subtitle" price="49" selected="yes" button_text="Button" button_link="Link" before_price="$" after_price="/mo"]<ul><li><strong>Custom</strong> text5</li><li><strong>Custom</strong> text6</li><li><strong>Custom</strong> text7</li><li><strong>Custom</strong> text8</li></ul>[/pricing_plan]<br />[pricing_plan title="Title" subtitle="Subtitle" price="99" selected="no" button_text="Button" button_link="Link" before_price="$" after_price="/mo"]<ul><li><strong>Custom</strong> text9</li><li><strong>Custom</strong> text10</li><li><strong>Custom</strong> text11</li><li><strong>Custom</strong> text12</li></ul>[/pricing_plan]<br />[pricing_plan title="Title" subtitle="Subtitle" price="299" selected="no" button_text="Button" button_link="Link" before_price="$" after_price="/mo"]<ul><li><strong>Custom</strong> text13</li><li><strong>Custom</strong> text14</li><li><strong>Custom</strong> text15</li><li><strong>Custom</strong> text16</li></ul>[/pricing_plan]<br />[/pricing_plans]'>Pricing Plans</a></li>
                        <li><a href="#"  data-all='[pricing_table]<br />[pricing_open_row]<br />[pricing_table_title][/pricing_table_title]<br />[pricing_table_title][sup]$[/sup][strong]Price[/strong]/month[/pricing_table_title]<br />[pricing_table_title][sup]$[/sup][strong]Price[/strong]/month[/pricing_table_title]<br />[pricing_table_title][sup]$[/sup][strong]Price[/strong]/month[/pricing_table_title]<br />[pricing_table_title][sup]$[/sup][strong]Price[/strong]/month[/pricing_table_title]<br />[/pricing_open_row]<br />[pricing_open_row]<br />[pricing_table_content]Table content1[/pricing_table_content]<br />[pricing_table_content]Custom text1[/pricing_table_content]<br />[pricing_table_content]Custom text2[/pricing_table_content]<br />[pricing_table_content]Custom text3[/pricing_table_content]<br />[pricing_table_content]Custom text4[/pricing_table_content]<br />[/pricing_open_row]<br />[pricing_open_row]<br />[pricing_table_content]Table content1[/pricing_table_content]<br />[pricing_table_content]Custom text4[/pricing_table_content]<br />[pricing_table_content]Custom text5[/pricing_table_content]<br />[pricing_table_content]Custom text6[/pricing_table_content]<br />[pricing_table_content]Custom text7[/pricing_table_content]<br />[/pricing_open_row]<br />[pricing_open_row]<br />[pricing_table_content]Table content2[/pricing_table_content]<br />[pricing_table_content][option="yes"]yes[/option][/pricing_table_content][pricing_table_content][option="yes"]yes[/option][/pricing_table_content][pricing_table_content][option="yes"]yes[/option][/pricing_table_content][pricing_table_content][option="yes"]yes[/option][/pricing_table_content]<br />[/pricing_open_row]<br />[pricing_open_row]<br />[pricing_table_content]Table content1[/pricing_table_content]<br />[pricing_table_content]Custom text8[/pricing_table_content]<br />[pricing_table_content]Custom text9[/pricing_table_content]<br />[pricing_table_content]Custom text10[/pricing_table_content]<br />[pricing_table_content]Custom text11[/pricing_table_content]<br />[/pricing_open_row]<br />[pricing_open_row]<br />[pricing_table_content]Table content3[/pricing_table_content]<br />[pricing_table_content][option="no"]no[/option][/pricing_table_content]<br />[pricing_table_content][option="yes"]yes[/option][/pricing_table_content]<br />[pricing_table_content][option="yes"]yes[/option][/pricing_table_content]<br />[pricing_table_content][option="yes"]yes[/option][/pricing_table_content]<br />[/pricing_open_row]<br />[pricing_open_row]<br />[pricing_table_content]Table content4[/pricing_table_content]<br />[pricing_table_content][option="no"]no[/option][/pricing_table_content]<br />[pricing_table_content][option="no"]no[/option][/pricing_table_content]<br />[pricing_table_content][option="yes"]yes[/option][/pricing_table_content]<br />[pricing_table_content][option="yes"]yes[/option][/pricing_table_content]<br />[/pricing_open_row]<br />[pricing_open_row]<br />[pricing_table_content]Table content5[/pricing_table_content]<br />[pricing_table_content][option="no"]no[/option][/pricing_table_content]<br />[pricing_table_content][option="no"]no[/option][/pricing_table_content]<br />[pricing_table_content][option="no"]no[/option][/pricing_table_content]<br />[pricing_table_content][option="yes"]yes[/option][/pricing_table_content]<br />[/pricing_open_row]<br />[pricing_open_row]<br />[pricing_table_content][link link_url="Link URL"]Anchor text[/link][/pricing_table_content]<br />[pricing_table_content][link link_url="Link URL" type="button"]Sign Up[/link][/pricing_table_content]<br />[pricing_table_content][link link_url="Link URL" type="button"]Sign Up[/link][/pricing_table_content]<br />[pricing_table_content][link link_url="Link URL" type="button"]Sign Up[/link][/pricing_table_content]<br />[pricing_table_content][link link_url="Link URL" type="button"]Sign Up[/link][/pricing_table_content]<br />[/pricing_open_row]<br />[/pricing_table]'>Pricing Table</a></li>
                    </ul>	
                </li>

                <li class="boder"><a href="#" data-all='' data-tag='heading' data-param='size="e.g. 1, 2, 3, 4, 5, 6"' data-text="Default Heading">Default Heading</a></li>	
            </ul>
        </div>
    </div>

    <?php
}

add_action('admin_head', 'multipurpose_add_shortcode_menu');
?>