<?php  
// Plain Hero, no images and stuff
class Wish_Team_Gallery {

        var $shortcode = 'wish_team_gallery';
        var $title = "Team Gallery";
        var $details = "Team Gallery With a large top image";
        //var $path = "/templates/rating_hero.php";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link"      => "http://i.imgur.com/8LhX6wN.png",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'wish'),
            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor
            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
            "params" => array(

                                array(
                                    "type" => "textfield",
                                    "heading" => __("Title", "wish"),
                                    "param_name" => "title",
                                    "description" => __("Small title At the top", "wish"),
                                    "value" => __("Our Team", 'wish'),
                                    "admin_label" => true,
                                ),

                                array(
                                    "type" => "textfield",
                                    "heading" => __("SubTitle", "wish"),
                                    "param_name" => "subtitle",
                                    "description" => __("Larger Subtitle below the heading", "wish"),
                                    "value" => __("Our UX Team", 'wish'),
                                    "admin_label" => false,
                                ),

                                array(
                                   "type" => "colorpicker",
                                   "class" => "",
                                   "heading" => __( "Subtitle Text Color", "wish" ),
                                   "param_name" => "subtitle_text_color",
                                   "value" => '#000', //Default Black color
                                   "description" => __( "Choose Subtitle text color", "wish" )
                                ),

                                /*Title*/
                                array(
                                    "type" => "google_fonts",
                                    "class" => "",
                                    "heading" => __("Title Text Font", "wish" ),
                                    "param_name" => "title_font",
                                    "value" => '', //Default Red color
                                    "description" => __( "Choose Font", "wish" ),
                                    "group"   => "Fonts & Colors",
                                    'settings' => array(
                                         'fields'=>array(
                                             'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                             'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                       )
                                    )       
                                ),


                                array(
                                    "type" => "wish_number",
                                    "heading" => __("Title Size", "wish"),
                                    "param_name" => "title_size",
                                    "description" => __("Font size in px", "wish"),
                                    "value" => __("30", 'wish'),
                                    "admin_label" => true,
                                    "group"       => "Fonts & Colors",
                                ),

                                array(
                                    "type" => "colorpicker",
                                    "class" => "",
                                    "heading" => __("Title Text Color", "wish" ),
                                    "param_name" => "title_color",
                                    "value" => '#df4322 ', //Default Black color
                                    "description" => __( "Choose text color", "wish" ),
                                    "group"         => "Fonts & Colors",
                                 ),


                                /*Subtitle*/
                                array(
                                    "type" => "google_fonts",
                                    "class" => "",
                                    "heading" => __("Subtitle Text Font", "wish" ),
                                    "param_name" => "subtitle_font",
                                    "value" => '', //Default Red color
                                    "description" => __( "Choose Font", "wish" ),
                                    "group"   => "Fonts & Colors",
                                    'settings' => array(
                                         'fields'=>array(
                                             'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                             'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                       )
                                    )       
                                ),


                                array(
                                    "type" => "wish_number",
                                    "heading" => __("Subtitle Size", "wish"),
                                    "param_name" => "subtitle_size",
                                    "description" => __("Font size in px", "wish"),
                                    "value" => __("60", 'wish'),
                                    "admin_label" => true,
                                    "group"       => "Fonts & Colors",
                                ),

                                array(
                                    "type" => "colorpicker",
                                    "class" => "",
                                    "heading" => __("Subtitle Text Color", "wish" ),
                                    "param_name" => "subtitle_color",
                                    "value" => '#333333', //Default Black color
                                    "description" => __( "Choose text color", "wish" ),
                                    "group"         => "Fonts & Colors",
                                 ),



                              array(
                                "type" => "attach_image",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Team Banner", 'wish'),
                                "param_name" => "image",
                                "description" => __("Large Team Banner in the center", 'wish'),
                                "admin_label" => false,
                              ),

                              array(
                                  "type" => "colorpicker",
                                  "class" => "",
                                  "heading" => __("Background Color", "wish" ),
                                  "param_name" => "bgcolor",
                                  "value" => '#F4F4F4', //Default Black color
                                  "description" => __( "Choose background color", "wish" ),
                                  "group"         => "Fonts & Colors",
                               ),


                    )

        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {

      extract( shortcode_atts( array(
        'title'       => 'Small Teams',
        'title_font'  => '',
        'title_size'  => '30',
        'title_color' => '#df4322',

        'subtitle'      => 'we are a bunch of UX strategists having a lot of fun together',
        'subtitle_font' => '',
        'subtitle_size' =>  '60',
        'subtitle_color' => '#333333',
        'image'       => 'Image',
        'bgcolor'   => '#F4F4F4'
      ), $atts ) );

        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($subtitle_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $subtitle_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



        //to process:
          $img = wp_get_attachment_image_src( $image, 'team-banner-size' );
          $img = $img[0];
    
          if($image == "Image"){
            $imgsrc = plugins_url('images/team.jpg', __FILE__);
            $img = $imgsrc;
          }



        $args = array(
          'numberposts' => 4,
          'post_type' => 'wish_team',
          'offset' => 0,
          'posts_per_page' => 4,
        );

      $team_query = new WP_Query( $args );

      $output = ""; 

      $output .= "<div id='team' class='container-fluid team small-teams' style='background-color:{$bgcolor}'>
                    <div class='container'>
                      <div class='row'>
                        <div class='col-lg-12'>
                          <h3 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h3>
                          <h1 class='animated' data-animation='fadeInUp' data-animation-delay='400' style='font-family:{$subtitle_font_family};font-size:{$subtitle_size}px;color:{$subtitle_color};'>{$subtitle}</h1>
                          <div class='picture animated' data-animation='fadeInUp' data-animation-delay='600'><img src='{$img}' class='img-responsive center-block' alt='Team Banner'></div>
                        </div>
                      </div>
                    </div>


                    <div class='row'>
                      <div class='col-lg-6'>
                        <div class='row no-gutter-3'>";

                        while (  $team_query->have_posts() ) :  $team_query->the_post(); 

                               $pid =  get_the_ID();
                               //echo get_post_meta(get_the_ID(), '_projects_mb_feature', TRUE);

                               $thumbid = get_post_thumbnail_id( $pid );
                               $full = wp_get_attachment_image_src($thumbid, array(800,800));
                               $thumb = wp_get_attachment_image_src($thumbid, array(200,200));
                               $out_img = $thumb[0];
                               $full_img = $full[0];

                               if($out_img == ""){
                                    $out_img = plugins_url('images/200x200.gif', __FILE__);   
                               }

                               $link = get_post_permalink();
                               $title = get_the_title(); 

                               $designation = get_post_meta( $pid, 'wish_designation', true );
                               $content = get_the_content();



      $output .= "<!-- Member Starts -->
                          <div class='col-lg-3 col-md-3 col-sm-3 col-xs-3 member animated' data-animation='flipInX' data-animation-delay='800'>
                            <a class='simple-ajax-popup' data-toggle='modal' data-target='#team-popup-{$pid}' href='#team-popup-{$pid}'>
                              <div class='picture'><img src='{$out_img}' class='img-responsive center-block' alt=''></div>
                              <div class='info'>
                                <div class='name'>{$title}</div>
                                <div class='designation'>{$designation}</div>
                                <div class='icons'><i class='fa fa-envelope-o'></i></div>
                              </div>
                            </a>
                          </div>
                          <!-- Member Ends -->
                          ";


              $output .= "<div class='modal fade team-popup-modal' id='team-popup-{$pid}' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                            <div class='modal-dialog team-modal-dialog'>
                              <div class='modal-content'>

                                <div class='modal-body row no-gutters'>



                                  <div class='team-modal-image col-sm-6'>
                                      <img src='{$full_img}' alt='' class='img-responsive'>
                                  </div>
                                  
                                  <div class='team-modal-content col-sm-6'>
                                  <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                                          <h3>{$title}</h3>
                                          <h5>{$designation}</h5>
                                          <div class='team-modal-text-text'>
                                                {$content}
                                          </div>
                                  </div>

                                </div>

                              </div>
                            </div>
                        </div>";     

                        endwhile;   
                        wp_reset_postdata(); 

       $output .= "</div></div>";                 





        $args = array(
          'numberposts' => 4,
          'post_type' => 'wish_team',
          'offset' => 4,
          'posts_per_page' => 4,
        );

      $team_query = new WP_Query( $args );


      $output .= "<div class='col-lg-6'>
                        <div class='row no-gutter-3'>";

                        while (  $team_query->have_posts() ) :  $team_query->the_post(); 

                               $pid =  get_the_ID();
                               //echo get_post_meta(get_the_ID(), '_projects_mb_feature', TRUE);

                               $thumbid = get_post_thumbnail_id( $pid );
                               $full = wp_get_attachment_image_src($thumbid, array(800,800));
                               $thumb = wp_get_attachment_image_src($thumbid, array(200,200));
                               $out_img = $thumb[0];
                               $full_img = $full[0];

                               if($out_img == ""){
                                    $out_img = plugins_url('images/200x200.gif', __FILE__);   
                               }

                               $link = get_post_permalink();
                               $title = get_the_title(); 

                               $designation = get_post_meta( $pid, 'wish_designation', true );
                               $content = get_the_content();



      $output .= "<!-- Member Starts -->
                          <div class='col-lg-3 col-md-3 col-sm-3 col-xs-3 member animated' data-animation='flipInX' data-animation-delay='800'>
                            <a class='simple-ajax-popup' data-toggle='modal' data-target='#team-popup-{$pid}' href='#team-popup-{$pid}'>
                              <div class='picture'><img src='{$out_img}' class='img-responsive center-block' alt=''></div>
                              <div class='info'>
                                <div class='name'>{$title}</div>
                                <div class='designation'>{$designation}</div>
                                <div class='icons'><i class='fa fa-envelope-o'></i></div>
                              </div>
                            </a>
                          </div>
                          <!-- Member Ends -->
                          ";




              $output .= "<div class='modal fade team-popup-modal' id='team-popup-{$pid}' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                            <div class='modal-dialog team-modal-dialog'>
                              <div class='modal-content'>

                                <div class='modal-body row no-gutters'>



                                  <div class='team-modal-image col-sm-6'>
                                      <img src='{$full_img}' alt='' class='img-responsive'>
                                  </div>
                                  
                                  <div class='team-modal-content col-sm-6'>
                                  <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                                          <h3>{$title}</h3>
                                          <h5>{$designation}</h5>
                                          <div class='team-modal-text-text'>
                                          {$content}
                                          </div>
                                  </div>

                                </div>

                              </div>
                            </div>
                        </div>";
                                      
                            //wish_set_teampopup($popup_html); 



                        endwhile;   
                        wp_reset_postdata(); 






      $output .= "  </div>
                  </div></div></div>

          ";

      return $output;
    }

    /*
    Load plugin css and javascript files which you may need on front end of your site
    */
    public function loadCssAndJs() {
      //wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
      //wp_enqueue_style( 'vc_extend_style' );

      // If you need any javascript files on front end, here is how you can load them.
      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );
    }

    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }



}//end of class
?>