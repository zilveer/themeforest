<?php 



	/* Section Title Group  ---------------------------------------------*/
	
	add_shortcode('section_title_group', 'jx_ievent_section_title_group');
	
	function jx_ievent_section_title_group($atts, $content = null) { 
		extract(shortcode_atts(array(
					'style' => 'Style-A',
					'color_style' => ''
					
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		if($color_style =="light") {
		$dark_light_color ="jx-ievent-light";
		} elseif ($color_style =="dark") {
		$dark_light_color ="jx-ievent-dark";
		}
		
		if($style =="Style-A") {
		$title_style ="jx-ievent-section-title-1";
		} elseif ($style =="Style-B") {
		$title_style ="jx-ievent-title-2";
		}elseif ($style =="Style-C") {
		$title_style ="jx-ievent-title-3";
		}		
		
		//function code

		$out ='<div class="'.$title_style.' '.$dark_light_color.'">'.do_shortcode($content).'</div>'; 
			
		
		//return output
		return $out;
	}



	/* Section Title  ---------------------------------------------*/
	
	add_shortcode('section_title', 'jx_ievent_section_title');
	
	function jx_ievent_section_title($atts, $content = null) { 
		extract(shortcode_atts(array(
					'icon' => '',
					'title' => ''
				), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 
		
		//function code
			$out ='				
				<div class="jx-ievent-pre-title jx-ievent-short-border">
				<div class="jx-ievent-title-border left"></div>
				<div class="jx-ievent-title-icon"><i class="line-icon '.$icon.'"></i></div>
				<div class="jx-ievent-title-border right"></div> 
				</div>
				<div class="jx-ievent-title jx-ievent-uppercase">'.$title.'</div>
				<div class="jx-ievent-subtitle"><p>'.do_shortcode($content).'</p></div>
				<!-- Section Title -->
			';
			

		
		//return output
		return $out;
	}
	
	
	//Visual Composer
	
	add_shortcode('vc_section_title', 'jx_ievent_vc_section_title');
	
	function jx_ievent_vc_section_title($atts, $content = null) { 
		extract(shortcode_atts(array(
					'icon' => '',
					'style' => '1',
					'title' => '',
					'title_bold' => '',
					'color_style' => 'dark'
				), $atts)); 
		 
		
		//initial variables
		$out='';
		$dark_light_color='';

		if($color_style =="light") {
			$dark_light_color ="jx-ievent-light";
		} elseif ($color_style =="dark") {
			$dark_light_color ="jx-ievent-dark";
		} 
		
		//function code

		switch($style){
		
		case 1:
			$out ='
				<div class="jx-ievent-section-title-1 '.$dark_light_color.'">
					<div class="jx-ievent-pre-title jx-ievent-short-border">
					<div class="jx-ievent-title-border left"></div>
					<div class="jx-ievent-title-icon"><i class="line-icon '.$icon.'"></i></div>
					<div class="jx-ievent-title-border right"></div> 
					</div>
					<div class="jx-ievent-title jx-ievent-uppercase">'.$title.'</div>
					<div class="jx-ievent-subtitle"><p>'.do_shortcode($content).'</p></div>
					<!-- Section Title -->
				</div>
			';
		break;
		
		case 2:
			$out ='
					<div class="jx-ievent-title-2 '.$dark_light_color.'">
						<div class="jx-ievent-title jx-ievent-uppercase">'.$title.'<span> '.$title_bold.'</span></div>
						<div class="jx-ievent-hr-title"></div>
				   </div>
				';
		break;
		
		case 3:
			$out ='
					<div class="jx-ievent-title-3 '.$dark_light_color.'">
						<div class="jx-ievent-title jx-ievent-uppercase">'.$title.'<span> '.$title_bold.'</span></div>
						<div class="jx-ievent-hr-title"></div>
				   </div>
				';
		break;
			
		}
		
		//return output
		return $out;
	}
	
	
	add_action( 'vc_before_init', 'vc_section_title_admin' );
	
	
	function vc_section_title_admin() {	
		vc_map(array(
		  "name" => esc_html__( "Section Title", "TEXT_DOMAIN" ),
		  "base" => "vc_section_title",
		  "class" => "",
		  "icon" => get_template_directory_uri().'/images/icon/vc_section_title.png',
		  "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
		  "description" => __('Add Title','TEXT_DOMAIN'),
		  "params" => array(
					 
	
			array(
				 "type" => "dropdown",
				 "class" => "",
				 "heading" => __("Select Your Color Style",'TEXT_DOMAIN'),
				 "param_name" => "color_style",
				 "value" => array(   
						__('Select Option', 'TEXT_DOMAIN') => '',
						__('Light', 'TEXT_DOMAIN') => 'light',
						__('Dark', 'TEXT_DOMAIN') => 'dark',
						),
			),
			
			array(
				 "type" => "dropdown",
				 "class" => "",
				 "heading" => __("Select Title Type",'TEXT_DOMAIN'),
				 "param_name" => "style",
				 "value" => array(   
						__('Style A', 'TEXT_DOMAIN') => '1',
						__('Style B', 'TEXT_DOMAIN') => '2',
						__('Style C', 'TEXT_DOMAIN') => '3'
						),
			),
			

			array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'TEXT_DOMAIN' ),
					'param_name' => 'icon',
					'settings' => array(
					'emptyIcon' => false, // default true, display an "EMPTY" icon?
					'type' => 'linecons',
					'iconsPerPage' => 200, // default 100, how many icons per/page to display
					),
					'description' => __( 'Select icon from library.', 'TEXT_DOMAIN' ),
					'save_always' => true
				),
				
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Title", "TEXT_DOMAIN" ),
				"param_name" => "title",
				"value" => "Standard Title", //Default Counter Up Text
				"description" => esc_html__( "Add Your Title Here", "TEXT_DOMAIN" )
			 ),
			 
			 array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Title Bold", "TEXT_DOMAIN" ),
				"param_name" => "title_bold",
				"value" => "Bold Title", //Default Counter Up Text
				"description" => esc_html__( "Add Your Title Bold Here", "TEXT_DOMAIN" )
			 ),
			 
			array(
				 "type" => "textarea",
				 "holder" => "div",
				 "class" => "",
				 "heading" => __("Content",'TEXT_DOMAIN'),
				 "param_name" => "content",
				 "value" => "",
			)
	
					 
		  )
	   ));
    
	}


?>