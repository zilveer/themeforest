<?php

add_action('init', 'tb_demo_item_integrateWithVC');

function tb_demo_item_integrateWithVC() {
    vc_map(array(
        "name" => __("Demo Item", 'jwsthemes'),
        "base" => "demo_item",
        "class" => "tb-demo-item",
        "category" => __('Aqua', 'jwsthemes'),
        "icon" => "tb-icon-for-vc",
        "params" => array(
			array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Type", 'jwsthemes'),
                "param_name" => "type",
                "value" => array(
                    "Demo" => "demo",
                    "Comming" => "comming"
                ),
                "description" => __('Select box type for demo item.', 'jwsthemes')
            ),
			array(
                "type" => "attach_image",
                "class" => "",
                "heading" => __("Image", 'jwsthemes'),
                "param_name" => "demo_image",
                "value" => "",
                "description" => __("Select box image for demo item.", 'jwsthemes')
            ),
			array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => __("Title", 'jwsthemes'),
                "param_name" => "title",
                "value" => "",
                "description" => __("Please, enter title for demo item.", 'jwsthemes')
            ),
			array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Button Label", 'jwsthemes'),
                "param_name" => "btn_label",
                "value" => "",
				"dependency" => array(
					"element"=>"type",
					"value"=>"demo"
				),
                "description" => __("Please, enter button label for demo item.", 'jwsthemes')
            ),
			array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Button Link", 'jwsthemes'),
                "param_name" => "btn_link",
                "value" => "",
				"dependency" => array(
					"element"=>"type",
					"value"=>"demo"
				),
                "description" => __("Please, enter button link for demo item.", 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Extra Class", 'jwsthemes'),
                "param_name" => "el_class",
                "value" => "",
                "description" => __ ( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'jwsthemes' )
            ),
        )
    ));
}
