<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

//shortcode Author list
add_shortcode('author', 'multipurpose_author');
add_shortcode('author_content', 'multipurpose_author_content');

function multipurpose_author($atts, $content = null) {
    $output = '<section class="post-author">';
    if (!empty($atts["image_url"])) {
        $output .= '<img src="' . $atts["image_url"] . '" alt="' . $atts['image_alt'] . '">';
    }
    if ($atts["name"]) {
        $output .= '<div><h3>Author: <a href="' . $atts["link"] . '">' . $atts["name"] . '</a></h3>';
    }
    $output.= do_shortcode($content);
    $output .= '</div></section>';

    return $output;
}

function multipurpose_author_content($atts = null, $content = null) {
    $output = '<p>' . $content . '</p>';
    return $output;
}
