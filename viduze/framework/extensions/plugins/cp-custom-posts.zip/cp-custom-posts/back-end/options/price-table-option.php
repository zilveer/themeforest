<?php

	/*	
	*	CrunchPress Price Table Option File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		CrunchPress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) CrunchPress
	*	---------------------------------------------------------------------
	*	This file create and contains the price table post_type meta elements
	*	---------------------------------------------------------------------
	*/
	
	add_action( 'init', 'create_price_table' );
	function create_price_table() {
	
		$labels = array(
			'name' => _x('Price Table', 'Price Table General Name', 'crunchpress'),
			'singular_name' => _x('Price Table Item', 'Price Table Singular Name', 'crunchpress'),
			'add_new' => _x('Add New', 'Add New Price Table Name', 'crunchpress'),
			'add_new_item' => __('Price Table Name', 'crunchpress'),
			'edit_item' => __('Price Table Name', 'crunchpress'),
			'new_item' => __('New Price Table', 'crunchpress'),
			'view_item' => '',
			'search_items' => __('Search Price Table', 'crunchpress'),
			'not_found' =>  __('Nothing found', 'crunchpress'),
			'not_found_in_trash' => __('Nothing found in Trash', 'crunchpress'),
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			//'menu_icon' => CP_PATH_URL . 'back-end/assets/images/portfolio-icon.png',
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_position' => 5,
			"show_in_nav_menus" => false,
			'exclude_from_search' => true,
			'supports' => array('title','editor','author','thumbnail','excerpt','comments')
		); 
		  
		register_post_type( 'price_table' , $args);
		
		register_taxonomy(
			"price-table-category", array("price-table"), array(
				"hierarchical" => true, 
				"label" => "Price Categories", 
				"singular_label" => "Price Categories", 
				"show_in_nav_menus" => false,
				"rewrite" => true));
		register_taxonomy_for_object_type('price-table-category', 'price_table');
		
	}
?>