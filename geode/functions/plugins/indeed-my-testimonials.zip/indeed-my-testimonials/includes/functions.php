<?php
function imtst_checkupdatecf($custom_field, $value, $post_id){
    //create or update a custom field
    $data = get_post_meta($post_id, $custom_field, TRUE);
    if(isset($data)) update_post_meta($post_id, $custom_field, $value);
    else add_post_meta($post_id, $custom_field, $value, TRUE);
}
function imtst_checkIfSelected($val1, $val2, $type){
    // check if val1 is equal with val2 and return an select attribute for checkbox, radio or select tag
    if($val1==$val2){
        if($type=='checkbox') return 'checked="checked"';
        else return 'selected="selected"';
    }else return '';
}
/***********************TEAM FUNCTIONS***************************/
function imtst_init_plugin_arr(){
    //SHORTCODE INIT VALUES ARRAY
   $arr = array(
                        'group' => 'all',
                        'order_by' => 'date',
                        'order' => 'ASC',
                        'limit' => 2,
                        'name' => 1,
                        'image' => 1,
                        'quote' => 1,
                        'job' => 1,
                        'client_url' => 0,
                        'company' => 0,
                        'company_url' => 0,
                        'stars' => 1,
                        'date' => 0,
                        'page_inside' => 0,
                        'inside_template' => '',
                        'theme' => 'theme_1',
                        'color_scheme' => '',
                        'slider_cols' => 1,
                        'columns' => 2,
                        //slide opt
                        'slider_set' => 0,
                        'items_per_slide' => 2,
                        'bullets' => 1,
                        'nav_button' => 1,
                        'autoplay' => 1,
                        'stop_hover' => 1,
                        'speed' => 500,
                        'pagination_speed' => 500,
                        'responsive' => 1,
                        'lazy_load' => 0,
                        'lazy_effect' => 0,
                        'slide_css_transition' => 'none',
                        );
    return $arr;
}
function imtst_init_widget_arr(){
    //WIDGET INIT VALUES ARRAY
  $arr = array(
                        'group' => 'all',
                        'order_by' => 'title',
                        'order' => 'ASC',
                        'limit' => 3,
                        'page_inside' => 0,
                        'inside_template' => '',
                        'theme' => 'theme_1',
                        'color_scheme' => '',
                        'show' => 'name,quote,image,job,client_url,company,company_url,stars,date',
                        'slider_cols' => 1,
                        'columns' => 1,
                        //slide opt
                        'slider_set' => 0,
                        'items_per_slide' => 2,
                        'slide_opt' => 'bullets,nav_button,autoplay,stop_hover,responsive',
                        'slide_speed' => 500,
                        'slide_pagination_speed' => 500,
                        'slide_css_transition' => 'fade',
              );
  return $arr;
}
function imtst_metabox_ti($testimonials){
    $job = esc_html(get_post_meta($testimonials->ID, 'imtst_jobtitle', true));
    $client_url = esc_html(get_post_meta($testimonials->ID, 'imtst_clienturl', true));
    $company = esc_html(get_post_meta($testimonials->ID, 'imtst_company', true));
    $company_url = esc_html(get_post_meta($testimonials->ID, 'imtst_companyurl', true));
    ?>
    <table class="it-table">
        <tr>
            <td class="it-label"><i class="icon-tags"></i> Client Job: </td>
            <td>
                <input type="text" value="<?php echo $job;?>" name="imtst_jobtitle" />
            </td>
        </tr>
        <tr>
            <td class="it-label"><i class="icon-share"></i> Client URL: </td>
            <td>
                <input type="text" value="<?php echo $client_url;?>" name="imtst_clienturl" />
            </td>
        </tr>
        <tr>
            <td class="it-label"><i class="icon-bookmark"></i> Company: </td>
            <td>
                <input type="text" value="<?php echo $company;?>" name="imtst_company" />
            </td>
        </tr>
        <tr>
            <td class="it-label"><i class="icon-share"></i> Company URL: </td>
            <td>
                <input type="text" value="<?php echo $company_url;?>" name="imtst_companyurl" />
            </td>
        </tr>
    </table>
    <div class="clear"></div>
<?php
}
function imtst_save_ti($post_id){
    if( isset($_POST['imtst_jobtitle']) ) imtst_checkupdatecf('imtst_jobtitle', $_POST['imtst_jobtitle'], $post_id);
    if( isset($_POST['imtst_clienturl']) ) imtst_checkupdatecf('imtst_clienturl', $_POST['imtst_clienturl'], $post_id);
    if( isset($_POST['imtst_company']) ) imtst_checkupdatecf('imtst_company', $_POST['imtst_company'], $post_id);
    if( isset($_POST['imtst_companyurl']) ) imtst_checkupdatecf('imtst_companyurl', $_POST['imtst_companyurl'], $post_id);
    if( isset($_POST['imtst_stars']) ) imtst_checkupdatecf('imtst_stars', $_POST['imtst_stars'], $post_id);
}
function imtst_metabox_rating($testimonials){
    $stars = esc_html(get_post_meta($testimonials->ID, 'imtst_stars', true));
    ?>
        <div class="wrapperStars">
                <?php
                for($i=1;$i<6;$i++){
                $class = 'unselected_star';
                if(isset($stars) && $i<=$stars) $class = 'selected_star';
                ?>
                    <div class="<?php echo $class;?>" id="client_star_<?php echo $i;?>" onClick="update_stars(<?php echo $i;?>, '#client_star_', '#clients_stars', 'unselected_star', 'selected_star');" onMouseOver="starHoverSelect(<?php echo $i;?>, '#client_star_', 'unselected_star', 'selected_star');" onMouseOut="updateStars(<?php echo $i;?>, '#client_star_', '#clients_stars', 'unselected_star', 'selected_star');"></div>
                <?php
                }
            ?>
            <div class="clear"></div>
        </div>
        <input type="hidden" value="<?php echo $stars;?>" name="imtst_stars" id="clients_stars" />
    <?php
}
function imtst_return_stars($rating_num){
    $str = "<span class='wrapperStars_fe'>";
    for($i=1;$i<6;$i++){
        $class = 'unselected_star';
        if( $i<=$rating_num) $class = 'selected_star';
        $str .= "<span class='$class'></span>";
    }
    $str .= "<span class='clear'></span></span>";
    return $str;
}

function imtst_returnCheckString($var){
    if(isset($var) && $var!='') return sanitize_text_field($var);
    else return '';
}

/*function imtst_check_req($string, $substring){
    if (strpos($string, $substring) !== false) return "<span class='imtst_req_sign'>*</span>";
    else return "";
}*/// pixedelic 
function imtst_check_req($string, $substring){
    if (strpos($string, $substring) !== false) return "*";
    else return "";
}

function imtst_ckreqpostval( $req_string, $post_name, $post_value ){
    if(strpos($req_string, $post_name)!==false){
        if($post_value=='') return TRUE;
    }
    return FALSE;
}
?>