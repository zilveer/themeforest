<?php  
// Plain Hero, no images and stuff
class Demo_Thumbs {

        var $shortcode = 'demo_thumbs';
        var $title = "Demo Thumbs";
        var $details = "";
        //var $path = "/templates/rating_hero.php";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link"  => "http://i.imgur.com/2QOubct.png",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'js_composer'),
            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor
            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
            "params" => array(

                           // add params same as with any other content element
                            array(
                                "type" => "textfield",
                                "heading" => __("Title", "wish"),
                                "param_name" => "title",
                                "description" => __("Features Section Title", "wish"),
                                "value" => __("MULTIPAGES TEMPLATES", 'wish'),
                                "admin_label" => true,
                            ), 
                            /*Title*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __("Title Text Font", "wish" ),
                                "param_name" => "title_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Title Size", "wish"),
                                "param_name" => "title_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("24", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __("Title Text Color", "wish" ),
                                "param_name" => "title_color",
                                "value" => '#fff', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Background Gradient Color 1", "wish" ),
                                "param_name" => "bgcolor1",
                                "value" => '#9b2920', //Default Red color
                                "description" => __( "Choose background gradient color 1", "wish" ),
                                "group"         => "Fonts & Colors",
                            ), 
                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Background Gradient Color 2", "wish" ),
                                "param_name" => "bgcolor2",
                                "value" => '#ec5022', //Default Red color
                                "description" => __( "Choose background gradient color 2", "wish" ),
                                "group"         => "Fonts & Colors",
                            ),
                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Background Gradient Color 3", "wish" ),
                                "param_name" => "bgcolor3",
                                "value" => '#f5a21f', //Default Red color
                                "description" => __( "Choose background gradient color 3", "wish" ),
                                "group"         => "Fonts & Colors",
                            ), 
                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Background Gradient Color 4", "wish" ),
                                "param_name" => "bgcolor4",
                                "value" => '#f69420', //Default Red color
                                "description" => __( "Choose background gradient color 4", "wish" ),
                                "group"         => "Fonts & Colors",
                            ), 

                    )
        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'   => 'MULTIPAGES TEMPLATES',
        'title_font'  => '',
        'title_size'  => '24',
        'title_color' => '#fff',

        'bgcolor1'      => '#9b2920',
        'bgcolor2' => '#ec5022',
        'bgcolor3' => '#f5a21f',
        'bgcolor4' => '#f69420',
      ), $atts ) );

        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


      $output = "
      <style>
        .orange-bg {
            background: {$bgcolor1};
            background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJod…EiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
            background: -moz-linear-gradient(left, {$bgcolor1} 0%, {bgcolor2} 30%, {bgcolor3} 70%, {$bgcolor4} 100%);
            background: -webkit-gradient(linear, left top, right top, color-stop(0%, {$bgcolor1}), color-stop(30%, {$bgcolor2}), color-stop(70%, {bgcolor3}), color-stop(100%, #{$bgcolor4}));
            background: -webkit-linear-gradient(left, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            background: -o-linear-gradient(left, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            background: -ms-linear-gradient(left, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            background: linear-gradient(to right, {$bgcolor1} 0%, {$bgcolor2} 30%, {$bgcolor3} 70%, {$bgcolor4} 100%);
            filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='{$bgcolor1}', endColorstr='{$bgcolor4}', GradientType=1 );
        }
      </style>
      <div class='demo-thumbs'>
        <div class='orange-bg' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</div>
      </div>";
      return $output;
    }


    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }



}//end of class
?>