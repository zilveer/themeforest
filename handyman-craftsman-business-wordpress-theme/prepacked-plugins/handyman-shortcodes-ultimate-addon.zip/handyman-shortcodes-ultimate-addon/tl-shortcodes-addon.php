<?php
/*
Plugin Name: Addon for Shortcodes Ultimate
Depends: Shortcodes Ultimate
Description: Handyman Theme addon for Shortcodes Ultimate plugin.
Version: 1.0.9
Author: Theme Laboratory
Author URI: http://themelaboratory.com/
License: GPLv2
*/

/*  Copyright 2015 ThemeLaboratory (email : milos@themelaboratory.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

if ( ! defined( 'ABSPATH' ) ) exit;

// define constants (optional)
define( 'TL_SHORTCODES_ADDON_REQ_PHP'    , '5.4'  );
define( 'TL_SHORTCODES_ADDON_REQ_WP'     , '4.2.3'  );

define( 'TL_SHORTCODES_ADDON_FILE' , __FILE__ );
define( 'TL_SHORTCODES_ADDON_DIR' , plugin_dir_path( __FILE__ ) );
define( 'TL_SHORTCODES_ADDON_URI' , plugin_dir_url( __FILE__ ) );
define( 'TL_SHORTCODES_ADDON_VER' , '1.0.9' );

define( 'TL_SHORTCODES_ADDON_BASE', trim(plugin_basename(TL_SHORTCODES_ADDON_DIR)));
define( 'TL_SHORTCODES_ADDON_SLUG', TL_SHORTCODES_ADDON_BASE );

// Helper functions
require_once 'inc/helpers.php';

// Classes
require_once 'inc/class.tl-shortcodes.php';
require_once 'inc/class.tl-shortcodes-ultimate-addon.php';

TL_Shortcodes_Ultimate_Addon::single();