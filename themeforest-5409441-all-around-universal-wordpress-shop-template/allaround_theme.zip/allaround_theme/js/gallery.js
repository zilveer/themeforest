(function($){
	$(document).ready(function(){
		$('#dg-container').gallery();
	});
})(jQuery);