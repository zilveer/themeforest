<?php
$output = $main_styles = $main_style = $content_styles = $content_style = $css_class = '';
	
	$accent_color = '#e74c3c';
	
	if ( function_exists( 'ot_get_option' ) ) {
	  $accent_color = ot_get_option('accent_color');
	}
	
	extract(shortcode_atts(array(
		'el_class' => '',
		'img_url' => '',
		'bg_color' => $accent_color,
		'border_color' => '',
		'width' => '',
		'align' => '',
		'padding' => '45px',
		'margin_left' => '', 
		'margin_right' => '', 
		'css_animation' => '',
		'css_animation_delay' => ''
	), $atts));
	
	$el_class = $this->getExtraClass($el_class);
	$align = $this->getExtraClass($align);
	
	$css_class = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'colored-box'.$el_class.$align, $this->settings['base']);
	$css_class .= $this->getCSSAnimation($css_animation);
	($css_animation != '' && $css_animation_delay != '') ? $css_class .= $this->getExtraClass($css_animation_delay) : '';

	if($img_url != '') {
		$img_url = wp_get_attachment_image_src( $img_url, 'full');
		$img_url = $img_url[0];
		$img = '<img class="colored-box-image" src="'. aq_resize($img_url, 895, 665, true, true, true) .'" alt=""/>';
	} else {
		$img = '';
	}
	
	$main_styles = array(
		($width != '') ? 'max-width:'.$width.';' : null,
		($margin_left != '' && $align != 'aligncenter') ? 'margin-left:'.$margin_left.';' : null,
		($margin_right != '' && $align != 'aligncenter' ) ? 'margin-right:'.$margin_right.';' : null
	); 
	
	if( !empty($main_styles) ){
		$main_style = implode(' ', array_filter($main_styles));	
		$main_style = ' style="'.$main_style.'"';
	}
	
	$content_styles = array(
		($bg_color != '') ? 'background-color:'.$bg_color.';' : null,
		($border_color != '') ? 'border-color:'.$border_color.';' : null,
		($padding != '') ? 'padding:'.$padding.';' : null,
	); 
	
	if( !empty($content_styles) ){
		$content_style = implode(' ', array_filter($content_styles));	
		$content_style = ' style="'.$content_style.'"';
	}
	
	$output .= '<div class="'.$css_class.'" '.$main_style.'>'.$img.'<div class="box-content" '.$content_style.'>';
	$output .= wpb_js_remove_wpautop($content);
	$output .= '</div></div>';

echo $output;