<?php 

	/* Subscribe  ---------------------------------------------*/
	
	add_shortcode('subscribe', 'jx_ievent_subscribe');
	
	function jx_ievent_subscribe($atts, $content = null) { 
		extract(shortcode_atts(array(
		'action'=>'//janxcode.us11.list-manage.com/subscribe/post?u=140e167e4ceaac2863e22db9e&amp;id=fcd462ebc8',
		
		), $atts)); 
		 
		$name='';
		
		$parts = parse_url($action);
		parse_str($parts['query'], $query);
		
		$name=$query['u'].'_'.$query['id'];
		
		//initial variables
		$out=''; 
		
		//function code
			
			$out ='
				<div class="jx-ievent-newsletter">
					<form  class="jx-ievent-form-wrapper cf validate" action="'.$action.'" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" target="_blank" novalidate>
					<div id="message-input-1" class="search-inline-block">
					<input type="text" name="EMAIL" placeholder="Type Your Email" class="jx-ievent-form-name" data-validation-length="email" data-validation="required" id="mce-EMAIL"/>
					</div>
					<div style="position: absolute; left: -5000px;"><input type="text" name="'.$name.'" tabindex="-1" value=""></div>
					<div id="message-submit-1">
					<button type="submit" id="mc-embedded-subscribe"><i class="line-icon icon-paper-plane"></i></button>
					<!-- Submit Button -->	
					</div>
					</form>   				
				</div>
			';
			

		//return output
		return $out;
	}


?>