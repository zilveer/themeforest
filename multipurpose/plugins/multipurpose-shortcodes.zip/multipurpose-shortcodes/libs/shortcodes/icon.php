<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// shortcode for Icon
add_shortcode('icon', 'multipurpose_icon');
function multipurpose_icon($atts, $content=null){
    if(isset($atts) && !empty($atts))
        array_walk($atts, 'multipurpose_arrangement_shortcode_arr_value');

    extract(shortcode_atts(array(  
            'name'=> '',
            'size'=> '',
            'color'=> '',
            'background_color'=> '',
            'circled_background'=> ''
    ), $atts));  

    $arr_size = array('1', '2', '3', '4', '5', '6');
    
    if (in_array($size, $arr_size))
        $size .= 'x';

    $output = '<i class="fa ';
    $output .= !empty($name) ? $name.'' : '';
    $output .= !empty($size) ? ' fa-'.$size: '';
    $output .= $circled_background == 'yes' ? ' fa-radius': '';
    $output .= '"';

    if ((!empty($color) && ($color != 'empty')) || (!empty($background_color) && ($background_color != 'empty')))
    {
            $output .= ' style="';
            $output .= (!empty($color) && ($color != 'empty')) ? 'color: '.$color.';' : '';
            $output .= (!empty($background_color) && ($background_color != 'empty')) ? 'background-color: '.$background_color.';' : '';
            $output .= '"';
    }
    $output .= '></i>';

    return $output;
} 

// shortcode for stacked_icons
add_shortcode('stacked_icons', 'multipurpose_stacked_icons');
function multipurpose_stacked_icons($atts, $content=null){
    
    if(isset($atts) && !empty($atts))
        array_walk($atts, 'multipurpose_arrangement_shortcode_arr_value');

    extract(shortcode_atts(array(  
        'stack_size'=> '',
        'icon_1_name'=> '',
        'icon_1_color'=> '',
        'icon_1_size'=> '',
        'icon_2_name'=> '',
        'icon_2_color'=> '',
        'icon_2_size'=> ''
    ), $atts));  

    $arr_size_class = array('lg' => 'fa-lg', '1' => 'fa-stack-1x', '2' => 'fa-stack-2x', '3' => 'fa-stack-3x', '4' => 'fa-stack-4x', '5' => 'fa-stack-5x');
    $arr_not_color = array('empty', '#fff', '', 'empty or e.g. #000', 'empty or e.g. #fff');

    $output = '<span class="fa-stack';
    if (in_array($stack_size, array_keys($arr_size_class)))
            $output .= ' '.$arr_size_class[$stack_size];
    
    $output .= '">';

    $output .= '<i class="fa';
    if (!empty($icon_1_name))
            $output .= ' '.$icon_1_name;
    
    if (in_array($icon_1_size, array_keys($arr_size_class)))
            $output .= ' '.$arr_size_class[$icon_1_size];
    
    $output .= '"';
    if (!in_array($icon_1_color, $arr_not_color))
            
            $output .= ' style="color: '.$icon_1_color.'"';
    $output .= '></i>';

    $output .= '<i class="fa';
    if (!empty($icon_2_name))
            $output .= ' '.$icon_2_name;
    
    if (in_array($icon_2_size, array_keys($arr_size_class)))
            $output .= ' '.$arr_size_class[$icon_2_size];
    
    $output .= '"';
    
    if (!in_array($icon_2_color, $arr_not_color))
            $output .= ' style="color: '.$icon_2_color.'"';
    
    $output .= '></i>';
    $output .= "</span>";
    
    return $output;
} 