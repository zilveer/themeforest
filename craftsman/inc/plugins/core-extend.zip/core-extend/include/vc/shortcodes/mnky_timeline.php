<?php
$output = $bar = '';
	
	extract(shortcode_atts(array(
		'animation' => '',		
		'bar_color' => '#DFDFDF',
		'bar_color_2' => '',
		'el_class' => '',
	), $atts));
	
	$el_class = $this->getExtraClass($el_class);
	
	$css_class = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'mnky-timeline'.$el_class, $this->settings['base']);
	($animation != 'off') ? $css_class .= $this->getCSSAnimation('mnky-timeline-animation') : '';
	
	($bar_color_2 != '') ? $bar = 'background: linear-gradient(to right, '.$bar_color.' 0%, '.$bar_color_2.' 100%);' : $bar = 'background:'.$bar_color;


	$output .= '<div class="'.$css_class.'">';
	$output .= wpb_js_remove_wpautop($content);
	$output .= '<div class="mnky-timeline-bar" style="'.$bar.'"></div></div>';


echo $output;
