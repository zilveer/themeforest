# Entry Views #

A WordPress plugin for tracking post/page view statistics.

Entry Views keeps track of the number of views a post/page (or any post type) has.  It comes handy with a widget for showing the most viewed posts, a shortcode for displaying a post's view count, and handy template tags for use within theme template files.

## Changelog ##

### Version 1.0.0 ###

* Everything is new!