jQuery(document).ready(function(){
	jQuery('.pix_carousels, .pix_postcarousels, .pix_woocarousels .products').each(function(){
		var t = jQuery(this),
			parent = t.parents('[data-opts]').eq(0),
			opts = typeof t.data('opts')!='undefined' ? t.data('opts') : parent.data('opts'),
			pager = opts.bullets == 'true' ? true : false,
			controls = opts.prev_next == 'true' ? true : false,
			autocontrols = opts.play_pause == 'true' ? true : false,
			autostart = opts.autoplay == 'true' ? true : false,
			hover = opts.hover == 'true' ? true : false;
		var revealBxSlides = function(){
			t.find("[data-src]").each(function(){
				var $lazy = jQuery(this).css({opacity:0}),
					$load = $lazy.attr("data-src");
				if ( $lazy.is(':visible') || $lazy.parents('.bx-clone').length ) {
					jQuery('<img />').one('load',function(){
						$lazy.removeAttr("data-src");
						if ( $lazy.is('img') ) {
							$lazy.attr("src",$load);
						} else {
							$lazy.css("background-image","url("+$load+")");
						}
						$lazy.animate({opacity:1});
					}).attr('src', $load).each(function() {
						if(this.complete) {
							jQuery(this).load();
						}
					});
				}
			});
		};
		revealBxSlides();
		var slider = t.bxSlider({
			slideWidth: '400000',
			useCSS: false,
			minSlides: opts.minslides,
			maxSlides: opts.maxslides,
			slideMargin: parseFloat(opts.slidemargin),
			mode: opts.mode,
			speed: parseFloat(opts.speed),
			infiniteLoop: true,
			hideControlOnEnd: true,
			adaptiveHeight: false,
			adaptiveHeightSpeed: parseFloat(opts.speed)/2,
			pager: pager,
			controls: controls,
			auto: true,
			autoControls: autocontrols,
			pause: parseFloat(opts.timeout),
			autoStart: autostart,
			autoHover: hover,
			onSliderLoad: function(){
				revealBxSlides();
			},
			onSlideAfter: function(){
				revealBxSlides();
			}
		});
	});
});
