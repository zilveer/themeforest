jQuery(document).ready(function(){

    if (jQuery.fn.wpColorPicker) {
        jQuery('#my_meta_box_button_bb_color').wpColorPicker();
    }
    if (jQuery.fn.wpColorPicker) {
        jQuery('#my_meta_box_button_p_color').wpColorPicker();
    }
});/**
 * Created by CreateIT on 2014-12-02.
 */
