<?php
/**
 * Abstract class for LayersWP extensions
 */
abstract class TL_Abstract_Layers_Extension{

	/**
	 * [$_instance description]
	 * 
	 * @var Object
	 */
	protected static $_instance;


	/**
	 * Plugins settings
	 * 
	 * @var array
	 */
	protected $settings;


    /**
     * @var array
     */
    protected  $_errors = array();


	/**
	 * Singleton
	 * 
	 * @return Object
	 */
	public final static function single()
	{
		if(static::$_instance === null){
			static::$_instance = new static();
		}
		return static::$_instance;
	}



	/**
	 * Initialize all staff
	 * @return void
	 */
	abstract public function init();
}