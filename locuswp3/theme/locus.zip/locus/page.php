<?php get_header(); ?>
<div class="borderline">
<p>Please make sure "Your latest posts" is selected as "Front Page Displays" in Settings - Reading in wp-admin.</p>
</div>
<?php get_footer(); ?>