<?php
if( !defined('_MULTIPURPOSE_SHORTCODE')) die('Access denied');

// add shortcode for circle
add_shortcode('circle','multipurpose_circle');

function multipurpose_circle($atts, $content = null) {
    $output = '<span class="circle">'.do_shortcode($content).'</span>';
    return $output;
}