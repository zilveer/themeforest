<?php
if(!isset($attr)){
///////////////PREVIEW
    $current_path = $_SERVER['SCRIPT_FILENAME'];
    $dir_arr = explode( 'wp-content/', $current_path );
    $dir = $dir_arr[0];
    require_once( $dir . 'wp-load.php' );
    $attr = $_REQUEST;
}

    $show_arr = explode(',', $attr['show']);

    if($attr['order_by']=='name') $orderby = 'title';
    else $orderby = 'date';

    if($attr['limit']==0) $limit = -1;
    else $limit = $attr['limit'];

    $args = array(
    	'posts_per_page'   => $limit,
    	'orderby'          => $orderby,
    	'order'            => $attr['order'],
    	'post_type'        => 'team',
    	'post_status'      => 'publish',
        );

    if($attr['team']=='all')$args['category'] = '';
    else $args['category'] = $attr['team'];

    if($attr['team']=='all'){
      $args['tax_query'] = array();
    }else {
      $args['tax_query'] = array(
                                    array(
                   			            'taxonomy' => 'team_cats',
                                        'field' => 'slug',
                                        'terms' => $attr['team']
                                )
                            );
    }

    $the_posts = get_posts($args);

    //final_str will contain the output
    $final_str = "";

if(count($the_posts)>0){

    if($attr['slider_set']==1){
        $parent_class = 'carousel_view';
    }else    $parent_class = 'ict_content_cl';

    $num = rand(1, 10000);
    $div_parent_id = 'indeed_carousel_view_widget_' . $num;
    $arrow_wrapp_id = 'wrapp_arrows_widget_' . $num;
    $ul_id = 'indeed_ul_' . $num;

    if(isset($dir_path)) $dir_path .= 'themes/';
    else {
        $dir_path = plugin_dir_path (__FILE__);
        $dir_path = str_replace('includes', 'themes', $dir_path);
    }

    $theme_file = $dir_path . $attr['theme'] . "/index.php";
    if( file_exists( $theme_file ) ) include( $theme_file );
    else die();

	$url_path = plugin_dir_url (__FILE__);
    $url_path = str_replace('includes', 'themes', $url_path);

    //$final_str .= '<link rel="stylesheet" href="'.$url_path.$attr['theme'] .'/style.css" type="text/css" media="all">'; //pixedelic
    if($attr['color_scheme']!=''){
        $url_path = str_replace( 'themes', 'layouts', $url_path );
        //$final_str .= '<link rel="stylesheet" href="'. $url_path . 'style_' . $attr['color_scheme'] . '.css" type="text/css" media="all">'; //pixedelic
		$color_class = 'style_' . $attr['color_scheme'];
    } else {
        $color_class = '';
        $final_str_2 = ''; //pixedelic
    }
    $final_str .= "<div class='$color_class'>";
    $final_str .= "<div class='{$attr['theme']}'>";
    $final_str .= '<style scoped>@import url('.$url_path.$attr['theme'] .'/style.css);</style>'; //pixedelic
    $final_str .= "<div class='ict_wrapp'>";
    $final_str .= "<div class='$parent_class' id='$div_parent_id' >";

    $default_item = $list_item_template;

    $social_media_string = '';
    $default_details_arr = $details_arr;

    $li_width = 100 / $attr['columns'];
    $li_width .= '%';
    $j = 1;
    $breaker_div = 1;
    $new_div = 1;
    $total_items = count($the_posts);
    if($attr['slider_set']==1) $items_per_slide = $attr['items_per_slide'];
    else $items_per_slide = $total_items;


    foreach($the_posts as $post){

        if($new_div==1){
            $div_id = $ul_id.'_' . $breaker_div;

            $final_str .= "<ul id='$div_id' class=''>"; /////ADDING THE UL
        }
            $final_str .= "<li style='width: $li_width'>";

        ////NAME
        if(in_array('name', $show_arr)){
            $name = get_the_title($post->ID);
            $list_item_template = str_replace("ICT_NAME", $name, $list_item_template);
        }else $list_item_template = str_replace("ICT_NAME", "", $list_item_template);

        ////PHOTO
        if(in_array('photo', $show_arr)){
            $src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), false, '' ); 
            $list_item_template = str_replace("ICT_IMAGE", $src[0],$list_item_template);
        }else $list_item_template = str_replace("ICT_IMAGE", "", $list_item_template);

        ////LINKS
        //if( $attr['page_inside']==1 ){ //pixedelic
            $link = get_permalink( $post->ID );
            if($attr['inside_template']!="default"){
                $u_template = urlencode( $attr['inside_template'] );
                $link = add_query_arg( array('team_cpt' => $u_template ), $link );
            }
            $list_item_template = str_replace("#POST_LINK#", $link, $list_item_template);
        //} else $list_item_template = str_replace("#POST_LINK#", "", $list_item_template); //pixedelic

        ////DESCRIPTION
        if(in_array('description', $show_arr)){
            $description = $post->post_excerpt; //pixedelic
            $list_item_template = str_replace("ICT_DESCRIPTION", $description, $list_item_template);
        }else $list_item_template = str_replace("ICT_DESCRIPTION", "", $list_item_template);

        ////JOB
        if(in_array('job', $show_arr)){
            $job = get_post_meta( $post->ID, 'in_team_jobtitle', true );
            $list_item_template = str_replace("ICT_JOB", $job, $list_item_template);
        }else $list_item_template = str_replace("ICT_JOB", "", $list_item_template);

        ///EMAIL
        if(in_array('email', $show_arr)){
            $email = get_post_meta( $post->ID, 'in_team_email', true );
            if(!empty($email)) $the_email = str_replace("#EMAIL#", $email, $details_arr['in_team_email']);
            else $the_email = "";
            $list_item_template = str_replace("ICT_EMAIL", $the_email, $list_item_template);
        }$list_item_template = str_replace("ICT_EMAIL", "", $list_item_template);

        ///LOCATION
        if(in_array('location', $show_arr)){
            $location = get_post_meta( $post->ID, 'in_team_location', true );
            if(!empty($location)) $the_location = str_replace("#LOCATION#", $location, $details_arr['in_team_location']);
            else $the_location = "";
            $list_item_template = str_replace("ICT_LOCATION", $the_location, $list_item_template);
        }$list_item_template = str_replace("ICT_LOCATION", "", $list_item_template);

        ////TELEPHONE
        if(in_array('tel', $show_arr)){
            $telephone = get_post_meta( $post->ID, 'in_team_telephone', true );
            if(!empty($telephone)) $phone = str_replace("#PHONE#", $telephone, $details_arr['in_team_telephone']);
            else $phone = "";
            $list_item_template = str_replace("ICT_PHONE", $phone, $list_item_template);
        }else $list_item_template = str_replace("ICT_PHONE", "", $list_item_template);

        ////WEBSITE
        if(in_array('website', $show_arr)){
            $website = get_post_meta( $post->ID, 'in_team_website', true );
            if(!empty($website)) $the_website = str_replace("#WEBSITE#", $website, $details_arr['in_team_website']);
            else $the_website = "";
            $list_item_template = str_replace("ICT_WEBSITE", $the_website, $list_item_template);
        }else $list_item_template = str_replace("ICT_WEBSITE", "", $list_item_template);

        ////SKILLS
        if(in_array('skills', $show_arr)){
            $skill_str = "";
            $skill_arr = array();
            $percent = array();
            for($i=0;$i<4;$i++){
                $skill_arr[] = get_post_meta($post->ID, 'indeed_team_skill_'.$i, true);
                $percent[] = get_post_meta($post->ID, 'indeed_skill_percent_'.$i, true);
            }
            foreach($skill_arr as $k=>$skill){
                if(!empty($skill)) $skill_str .= "<div class=\"skill-label\">$skill</div><div class=\"skill-prog\"><div class=\"fill\" data-progress-animation=\"{$percent[$k]}%\" data-appear-animation-delay=\"400\" style=\"width:{$percent[$k]}%;\"></div></div>"; //pixedelic
            }
            $list_item_template = str_replace("ICT_SKILLS", $skill_str, $list_item_template);
        }else $list_item_template = str_replace("ICT_SKILLS", "", $list_item_template);

        //social media
		
		$social_media_string = '';
		if( in_array('social_icon', $show_arr) ){
            $facebook = get_post_meta( $post->ID, 'indeed_fb_lnk', true );
            if( ! empty( $facebook ) ) {   $social_media_string .= str_replace("FB", $facebook, $socials_arr['in_team_fb']); }
			$twitter = get_post_meta( $post->ID, 'indeed_tw_lnk', true );
            if( ! empty( $twitter ) ) {   $social_media_string .= str_replace("TW", $twitter, $socials_arr['in_team_tw']); }
            $linkedin = get_post_meta( $post->ID, 'indeed_ld_lnk', true );
            if( ! empty( $linkedin ) ) {   $social_media_string .= str_replace("LIN", $linkedin, $socials_arr['in_team_lin']); }
            $google_plus = get_post_meta( $post->ID, 'indeed_gp_lnk', true );
            if( ! empty( $google_plus ) ) {   $social_media_string .= str_replace("GP", $google_plus, $socials_arr['in_team_gp']); }
            $instagram = get_post_meta( $post->ID, 'indeed_ins_lnk', true );
            if( ! empty( $instagram ) ) {   $social_media_string .= str_replace("INS", $instagram, $socials_arr['in_team_ins']); }
		}
		$list_item_template = str_replace("ICT_SOCIAL_MEDIA", $social_media_string, $list_item_template);

        $final_str .= $list_item_template;
        $final_str .= "</li>";
        //if($attr['columns']<=$items_per_slide && $j % $attr['columns']==0) $final_str .= "<div class='clear'></div>";

        $list_item_template = $default_item;
        $details_arr = $default_details_arr;

      if( $j % $items_per_slide==0 || $j==$total_items ){
      	  $breaker_div++;
      	  $new_div = 1;
          //$final_str .= "<div class='clear'></div></ul>"; //pixedelic
          $final_str .= "</ul>";
      }else $new_div = 0;
      $j++;
    }
        $final_str .= "</div>";

        $final_str .="<script>
        				/* fill the skills */                            		
	jQuery('.team-member').each(function() {
		var current_set = jQuery(this).find('.fill');
		var show_details = jQuery(this).find('.show-details');
		jQuery('.team-member').find('.fill').css('width','0%');
		if (!show_details.is('div')) {
		current_set.each(function() {
				var i = 0; 
				var current_fill = jQuery(this);
				var progress = current_fill.attr('data-progress-animation');
				var current_width = current_fill.width();
				if (current_width == 0) {
					progress = progress.substring(0, progress.length - 1);
					var check = function() {
						if (i > progress) {
							return false;
						}
						else {
							i += 1;
							current_fill.css('width', i + '%');
							setTimeout(check, 1);
						}
					}
					check();
				}
			});
		}
	});
	jQuery('.team-member').hover(function() {
		
		var current_set = jQuery(this).find('.fill');
		var show_details = jQuery(this).find('.show-details');
		if (show_details.is('div')) {
			current_set.each(function() {
				var i = 0;
				var current_fill = jQuery(this);
				var progress = current_fill.attr('data-progress-animation');
				var current_width = current_fill.width();
				if (current_width == 0) {
					progress = progress.substring(0, progress.length - 1);
					var check = function() {
						if (i > progress) {
							return false;
						}
						else {
							i += 1;
							current_fill.css('width', i + '%');
							setTimeout(check, 1);
						}
					}
					check();
					// each
				}
			});
		}
	});
        </script>";
        
        if($attr['slider_set']==1){
            $total_pages = $total_items / $items_per_slide;

            if($total_pages>1){
              $navigation = 'false';
              $bullets = 'false';
              $autoplay = 'false';
              $stop_hover = 'false';
              $lazy_effect = 'false';
              $responsive = 'false';
              $lazy_load = 'false';

              if( strpos( $attr['slide_opt'], 'nav_button')!==FALSE) $navigation = 'true';
              if( strpos( $attr['slide_opt'], 'bullets')!==FALSE) $bullets = 'true';
              if( strpos( $attr['slide_opt'], 'autoplay')!==FALSE) $autoplay = 'true';
              if( strpos( $attr['slide_opt'], 'stop_hover')!==FALSE) $stop_hover = 'true';
              if( strpos( $attr['slide_opt'], 'lazy_effect')!==FALSE) $lazy_effect = "'fade'";
              if( strpos( $attr['slide_opt'], 'responsive')!==FALSE) $responsive = 'true';
              if( strpos( $attr['slide_opt'], 'lazy_load')!==FALSE) $lazy_load = 'true';
              if( $attr['slide_css_transition']=='none' ) $slider_effect = 'false';
              else $slider_effect = "'{$attr['slide_css_transition']}'";

                $final_str .= "<script>
                            		jQuery(document).ready(function() {
                            		  var owl = jQuery('#{$div_parent_id}');
                            		  owl.owlCarousel({
                                            singleItem : true,
                                            items : 1,
                                            itemsDesktop : false,
                                            itemsDesktopSmall : false,
                                            itemsTablet: false,
                                            itemsMobile : false,
                                            transitionStyle : $slider_effect,
                                            paginationSpeed : {$attr['slide_pagination_speed']},
                                            slideSpeed : {$attr['slide_speed']},
                                			navigation : $navigation,
                                			pagination : $bullets,
                                			autoPlay : $autoplay,
                                			stopOnHover : $stop_hover,
                                			responsive : $responsive,
                                			lazyEffect : $lazy_effect,
                                            lazyLoad : $lazy_load,
                            		  });
                            		});    		
                               </script>";
            }
        }
        $final_str .= "</div>";//end of ict_wrapp
        $final_str .= "</div>";//end of theme_n
        $final_str .= "</div>";//end of style_xxxxxx

        if(!isset($return_str) || $return_str!=true ) echo $final_str;
}
?>