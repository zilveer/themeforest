<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// shortcode headings 
add_shortcode('special_heading', 'multipurpose_special_heading');
add_shortcode('heading', 'multipurpose_header_default');

function multipurpose_special_heading($atts, $content = null) {
    $output = '';

    $output_class = '';

    if (isset($atts["underline"])) {
        if ($atts["underline"] == 'yes')
            $output_class .= 'underline';
    }

    if (isset($atts["type"])) {
        $output = '<' . $atts["type"];

        if ($output_class != '')
            $output .= ' class="' . $output_class . '"';

        $output .= '><span>' . do_shortcode($content) . '</span></' . $atts["type"] . '>';
    }

    return $output;
}

function multipurpose_header_default($atts, $content = null) {
    $output = '';
    if (isset($atts["size"]) && !empty($atts["size"])) {
        $output = '<h' . $atts["size"] . '>' . do_shortcode($content) . '</h' . $atts["size"] . '>';
    }
    return $output;
}
