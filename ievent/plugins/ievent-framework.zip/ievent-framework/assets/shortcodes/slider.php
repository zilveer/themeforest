<?php 
	/* Price Table Group  ---------------------------------------------*/
	
	add_shortcode('slider_group', 'jx_ievent_slider_group');
	
	function jx_ievent_slider_group($atts, $content = null) { 
		extract(shortcode_atts(array(), $atts)); 
		 
		
		//initial variables
		$out=''; 

		$out ='
		<div class="jx-ievent-slider">
		<div class="jx-ievent-top-black"></div>
		
			<div class="jx-ievent-main-slider">		
				<div class="flexslider">
					<ul class="slides">'.do_shortcode($content).'</ul>
				</div>
				
				<!-- here will come info bar -->
				
				<!-- EOF Flexslider -->
			</div>
		
		</div>		
		'; 
				
		//return output
		return $out;
	}



	/* Price Table  ---------------------------------------------*/
	
	add_shortcode('slider', 'jx_ievent_slider');
	
	function jx_ievent_slider($atts, $content = null) { 
		extract(shortcode_atts(array(
			'image' => '',
			'date' => '',
			'month' => ''
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		 
		//function code
			
			$out ='
			<li class="jx-ievent-parallax-fullwidth" style="background-image:url('.$image.'); background-size: cover;">                    
			
				<div class="jx-ievent-event-slide">                        	
					<div class="jx-ievent-slider-content">
						<div class="container">
						'.do_shortcode($content).'
						 </div>
						
						<div class="jx-ievent-right-vertical-border">
							<div class="jx-ievent-date">
								<div class="jx-ievent-slider-day">'.$date.'</div>
								<div class="jx-ievent-slider-month jx-ievent-uppercase">'.$month.'</div>
							</div>
						</div>
						
					</div>
				</div>            	            
				
			</li>
			<!--item 01 -->
						
			';

		
		//return output
		return $out;
	}


?>