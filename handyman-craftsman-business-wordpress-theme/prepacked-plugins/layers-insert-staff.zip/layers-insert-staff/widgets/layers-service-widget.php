<?php
/**
 * Class TL_Layers_Services_Widget
 *
 * Associate post type with a column
 *
 * @since Layers 1.4.1
 */

if (!class_exists('TL_Layers_Abstract_Widget')) {
    return;
}

if (!class_exists('TL_Layers_Services_Widget')) {

    class TL_Layers_Services_Widget extends TL_Layers_Abstract_Widget
    {
        /**
         *  Widget construction
         */
        function __construct()
        {
            /**
             * Widget variables
             *
             * @param    string $widget_title Widget title
             * @param    string $widget_id Widget slug for use as an ID/classname
             * @param    string $post_type (optional) Post type for use in widget options
             * @param    string $taxonomy (optional) Taxonomy slug for use as an ID/classname
             * @param    array $checkboxes (optional) Array of checkbox names to be saved in this widget. Don't forget these please!
             */
            $this->widget_title = __('TL Services', 'layerswp');
            $this->widget_id = 'tl_services';
            $this->post_type = 'tl_service';
            $this->taxonomy = '';
            $this->checkboxes = array('gutter', 'stretch');

            /* Widget settings. */
            $widget_ops = array('classname' => 'obox-layers-' . $this->widget_id . '-widget', 'description' => __('This widget is used to display your ', 'layerswp') . $this->widget_title . '.');

            /* Widget control settings. */
            $control_ops = array('width' => LAYERS_WIDGET_WIDTH_LARGE, 'height' => NULL, 'id_base' => LAYERS_THEME_SLUG . '-widget-' . $this->widget_id);

            /* Create the widget. */
            parent::__construct(LAYERS_THEME_SLUG . '-widget-' . $this->widget_id, $this->widget_title, $widget_ops, $control_ops);

            /* Setup Widget Defaults */
            $this->defaults = array(
                'title' => __('Our Services', 'layerswp'),
                'excerpt' => __('Our services run deep and are backed by over ten years of experience.', 'layerswp'),
                'design' => array(
                    'layout' => 'layout-boxed',
                    'columns' => '4',
                    'background' => array(
                        'position' => 'center',
                        'repeat' => 'no-repeat'
                    ),
                    'fonts' => array(
                        'align' => 'text-center',
                        'size' => 'medium',
                        'color' => NULL,
                        'excertp-color' => NULL,
                        'shadow' => NULL
                    )
                )
            );

            $this->register_repeater_defaults('column', 4, array(
                'title' => __('Your service title', 'layerswp'),
                'excerpt' => '',
                'width' => '3',
                'post_item' => null,
                'design' => array(
                    'imagealign' => 'image-top',
                    'background' => NULL,
                    'fonts' => array(
                        'align' => 'text-center',
                        'size' => 'small',
                        'color' => NULL,
                        'shadow' => NULL
                    ),
                ),
            ));

            $this->_addFilters();
        }


        /**
         * @param array $args
         * @param array $instance
         */
        function widget($args, $instance)
        {
            $this->backup_inline_css();

            // Turn $args array into variables.
            extract($args);

            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            // Apply Section Styling
            $this->_apply_widget_section_styling($widget_id, $widget);


            /**
             * Generate the widget container class
             */
            $widget_container_class = array();
            $widget_container_class[] = 'layers-tl-service-widget';
            $widget_container_class[] = 'widget content-vertical-massive';
            $widget_container_class[] = $this->check_and_return($widget, 'design', 'advanced', 'customclass');
            $widget_container_class[] = $this->get_widget_spacing_class($widget);
            $widget_container_class = implode(' ', apply_filters('layers_'.$this->widget_id.'_widget_container_class', $widget_container_class, $this, $widget)); ?>

            <div class="<?php echo esc_attr($widget_container_class); ?>" id="<?php echo esc_attr($widget_id); ?>">
                <?php
                    echo $this->custom_anchor( $widget );
                    do_action( 'layers_before_'.$this->widget_id.'_widget_inner', $this, $widget );
                ?>
                <?php if ('' != $this->check_and_return($widget, 'title') || '' != $this->check_and_return($widget, 'excerpt')) { ?>
                    <div class="container clearfix">
                        <?php
                        /**
                         * Generate the Section Title Classes
                         */
                        $section_title_class = array();
                        $section_title_class[] = 'section-title clearfix';
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'size');
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'align');
                        $section_title_class[] = ($this->check_and_return($widget, 'design', 'background', 'color') && 'dark' == tl_layers_is_light_or_dark_recalculated($this->check_and_return($widget, 'design', 'background', 'color')) ? 'invert' : '');

                        $section_title_class = implode(' ', $section_title_class); ?>
                        <div class="<?php echo esc_attr($section_title_class); ?>">
                            <?php if ('' != $widget['title']) { ?>
                                <h3 class="heading"><?php echo esc_html($widget['title']); ?></h3>
                            <?php } ?>
                            <?php if ('' != $widget['excerpt']) { ?>
                                <div class="excerpt"><?php echo $widget['excerpt']; ?></div>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>
                <?php if (!empty($widget['columns'])) { ?>
                    <div class="list-grid <?php echo esc_attr($this->get_widget_layout_class($widget)); ?> ">
                        <div class="grid">
                            <?php // Set total width so that we can apply .last to the final container
                            $total_width = 0; ?>
                            <?php foreach (explode(',', $widget['column_ids']) as $column_key) {

                                // Make sure we've got a column going on here
                                if (!isset($widget['columns'][$column_key])) continue;

                                // Setup the relevant column
                                $column = $widget['columns'][$column_key];

                                $column_margins = isset($column['c_margin']) ? $column['c_margin'] : array();
                                $column_padding = isset($column['c_padding']) ? $column['c_padding'] : array();
                                $post_id = isset($column['post_item']) ? (int)$column['post_item'] : null;

                                $has_custom_margin = $has_custom_padding = false;

                                foreach ($column_margins as $k => $v) {
                                    if ($v != '') {
                                        $column_margins[$k] = $v . 'px';
                                        $has_custom_margin = true;
                                    }
                                }
                                foreach ($column_padding as $k => $v) {
                                    if ($v != '') {
                                        $column_padding[$k] = $v . 'px';
                                        $has_custom_padding = true;
                                    }
                                }

                                $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' > .media', 'margin', array('margin' => $column_margins));
                                $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key . ' > .media', 'padding', array('padding' => $column_padding));

                                // Set the background styling
                                if (!empty($column['design']['background']))
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'background', array('background' => $column['design']['background']));

                                if (!empty($column['design']['fonts']['shadow']))
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'text-shadow', array('selectors' => array('h5.heading a',
                                        'h5.heading',
                                        'div.excerpt',
                                        'div.excerpt p'),
                                        'text-shadow' => $column['design']['fonts']['shadow']));

                                /* Column Title color */
                                if ($this->check_and_return($column, 'design', 'fonts', 'color')) {
                                    // Title Color
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'color', array('selectors' => array('h5.heading a',
                                        'h5.heading',
                                        '.excerpt'),
                                        'color' => $this->check_and_return($column, 'design', 'fonts', 'color')));
                                }

                                // Icon Color
                                if ($this->check_and_return($column, 'titlecolor')) {
                                    $this->inline_css .= layers_inline_styles('#' . $widget_id . '-' . $column_key, 'color', array('selectors' => array('.media-image i'),
                                        'color' => $this->check_and_return($column, 'titlecolor')));
                                }

                                if (!isset($column['width'])) $column['width'] = $this->column_defaults['width'];
                                // Add the correct span class
                                $span_class = 'span-' . $column['width'];

                                // Add .last to the final column
                                $total_width += $column['width'];

                                if (12 == $total_width) {
                                    $span_class .= ' last';
                                    $total_width = 0;
                                } elseif ($total_width > 12) {
                                    $total_width = 0;
                                }

                                // Service assigned to this column
                                $post = null;
                                // Load post if any
                                if ($post_id) {
                                    $posts = tl_get_posts([
                                        'post_type' => 'tl_service',
                                        'post__in' => [$post_id]
                                    ], true);

                                    $post = isset($posts[0]) ? $posts[0] : 0;
                                }

                                // Set Featured Media
                                $featureimage = $this->check_and_return($column, 'design', 'featuredimage');
                                $featurevideo = $this->check_and_return($column, 'design', 'featuredvideo');

                                // Set Image Sizes
                                if (isset($column['design']['imageratios'])) {

                                    // Translate Image Ratio into something usable
                                    $image_ratio = layers_translate_image_ratios($column['design']['imageratios']);

                                    if (!isset($column['width'])) $column['width'] = 6;

                                    if (4 > $column['width']) {
                                        $use_image_ratio = $image_ratio . '-medium';
                                    } else {
                                        $use_image_ratio = $image_ratio . '-large';
                                    }

                                } else {

                                    if (4 > $column['width']) {
                                        $use_image_ratio = 'medium';
                                    } else {
                                        $use_image_ratio = 'full';
                                    }
                                }

                                $media = layers_get_feature_media(
                                    $featureimage,
                                    $use_image_ratio,
                                    $featurevideo
                                );


                                // Set the column link
                                if ($post) {
                                    $link = get_the_permalink($post->ID);
                                } else {
                                    $link = $this->check_and_return($column, 'link');
                                }

                                // Set the Icon service icon if any
                                $icon_class = (isset($column['icon_class']) && $column['icon_class'] != '') ? $column['icon_class'] : null;

                                /**
                                 * Set Individual Column CSS
                                 */
                                $column_class = array();
                                $column_class[] = 'layers-masonry-column';
                                $column_class[] = $this->id_base . '-' . $column_key;
                                $column_class[] = $span_class;
                                $column_class[] = 'column-flush';
                                $column_class[] = isset($post) ? 'post-related' : '';

                                if (($this->check_and_return($column, 'design', 'background', 'color') || $this->check_and_return($column, 'design', 'background', 'image'))) {
                                    $column_class[] = 'has-background';
                                }

                                $column_class[] = ('on' == $this->check_and_return($column, 'c_no_padding') ? 'no-padding' : '');
                                $column_class[] = isset($column['c_class']) ? $column['c_class'] : '';

                                if ($has_custom_margin) {
                                    $column_class[] = 'has-custom-margin';
                                }
                                if ($has_custom_padding) {
                                    $column_class[] = 'has-custom-padding';
                                }

                                if ('' != $this->check_and_return($column, 'design', 'background', 'image') || '' != $this->check_and_return($column, 'design', 'background', 'color')) {
                                    $column_class[] = 'content';
                                }
                                if (false != $media) {
                                    $column_class[] = 'has-image';
                                }
                                if ($icon_class) {
                                    $column_class[] = 'has-icon';
                                }

                                $column_class = implode(' ', $column_class); ?>

                                <div id="<?php echo esc_attr($widget_id); ?>-<?php echo esc_attr($column_key); ?>"
                                     class="<?php echo esc_attr($column_class); ?>">

                                    <?php if ($this->check_and_return($column, 'design', 'background', 'darken')): ?>
                                        <div class="bg-overlay"></div>
                                    <?php endif; ?>

                                    <?php
                                    /**
                                     * Set Overlay CSS Classes
                                     */
                                    $column_inner_class = array();
                                    $column_inner_class[] = 'media';
                                    if (!$this->check_and_return($widget, 'design', 'gutter')) {
                                        $column_inner_class[] = 'no-push-bottom';
                                    }

                                    $column_inner_class[] = $this->check_and_return($column, 'design', 'imagealign');
                                    $column_inner_class[] = $this->check_and_return($column, 'design', 'fonts', 'size');
                                    if ($this->check_and_return($column, 'design', 'background', 'darken')) {
                                        $column_inner_class[] = 'darken';
                                    }
                                    $column_inner_class = implode(' ', $column_inner_class); ?>

                                    <div class="<?php echo esc_attr($column_inner_class); ?>">
                                        <div class="media-inner">

                                            <!-- IMAGE OR ICON -->
                                            <?php if (NULL != $media) { ?>
                                                <div
                                                    class="media-image <?php echo((isset($column['design']['imageratios']) && 'image-round' == $column['design']['imageratios']) ? 'image-rounded' : ''); ?>">
                                                    <?php if (NULL != $link) { ?><a class="ajax-popup-link"
                                                                                    data-title="<?php echo esc_attr($column['title']) ?>"
                                                        <?php echo($post_id ? 'data-id="' . esc_attr($post_id) . '"' : ''); ?>
                                                                                    href="<?php echo esc_url($link); ?>"><?php } ?>
                                                        <?php echo $media; ?>
                                                        <?php if (NULL != $link) { ?></a><?php } ?>
                                                </div>
                                            <?php } ?>

                                            <?php if ($icon_class): ?>
                                                <div class="media-image">
                                                    <?php if (NULL != $link) { ?><a class="ajax-popup-link"
                                                                                    data-title="<?php echo esc_attr($column['title']) ?>"
                                                        <?php echo($post_id ? 'data-id="' . esc_attr($post_id) . '"' : ''); ?>
                                                                                    href="<?php echo esc_url($link); ?>"><?php } ?>
                                                        <i class="<?php echo esc_attr($icon_class); ?>"></i>
                                                        <?php if (NULL != $link) { ?></a><?php } ?>
                                                </div>
                                            <?php endif; ?>

                                            <!-- IMAGE OR ICON END -->

                                            <?php if ($this->check_and_return($column, 'title')) { ?>

                                                <div
                                                    class="media-body <?php echo (isset($column['design']['fonts']['align'])) ? $column['design']['fonts']['align'] : ''; ?>">
                                                    <?php if ($this->check_and_return($column, 'title')) { ?>
                                                        <h5 class="heading">
                                                            <?php if (NULL != $link && $this->check_and_return($column, 'link_text')) : ?>
                                                            <a class="ajax-popup-link"
                                                               data-title="<?php echo esc_attr($column['title']) ?>"
                                                                <?php echo($post_id ? 'data-id="' . esc_attr($post_id) . '"' : ''); ?>
                                                               title="<?php echo esc_attr($column['title']); ?>"
                                                               href="<?php echo esc_url($link); ?>">
                                                                <?php endif; ?>
                                                                <?php echo apply_filters('the_title', $column['title']); ?>
                                                                <?php if (NULL != $link && $this->check_and_return($column, 'link_text')) : ?></a><?php endif; ?>
                                                        </h5>
                                                    <?php } ?>
                                                    <?php if ($this->check_and_return($column, 'excerpt')): ?>
                                                        <div
                                                            class="excerpt"><?php echo layers_the_content($column['excerpt']) ?></div>
                                                    <?php endif; ?>
                                                    <?php if ($link && $this->check_and_return($column, 'link_text')) { ?>
                                                        <a data-title="<?php echo esc_attr($column['title']) ?>"
                                                            <?php echo($post_id ? 'data-id="' . esc_attr($post_id) . '"' : ''); ?>
                                                           title="<?php echo esc_attr($link); ?>"
                                                           href="<?php echo esc_url($link); ?>"
                                                           class="ajax-popup-link button-secondary-style button btn-<?php echo esc_attr($this->check_and_return($column, 'design', 'fonts', 'size')); ?>">
                                                            <?php echo esc_html($column['link_text']); ?>
                                                        </a>
                                                    <?php } ?>
                                                    <!-- LINK END -->
                                                </div> <!-- .media-body -->
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <!-- .media -->
                                </div>
                            <?php } ?>
                        </div>
                        <!-- .grid -->
                    </div>
                <?php }

                do_action( 'layers_after_' . $this->id . '_widget_inner', $this, $widget );

                // Print the Inline Styles for this Widget
                $this->print_inline_css();

                // Apply the advanced widget styling
                $this->apply_widget_advanced_styling($widget_id, $widget);
                ?>
            </div>
        <?php } // Widget end


        /**
         *  Widget form
         *
         * @param array $instance
         * @return string|void
         */
        public function form($instance)
        {
            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            if (TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_start('tl_sanitize_output');

            $this->design_bar(
                'side', // CSS Class Name
                array(
                    'name' => $this->get_layers_field_name('design'),
                    'id' => $this->get_layers_field_id('design'),
                    'widget_id' => $this->widget_id,
                ), // Widget Object
                $widget, // Widget Values
                apply_filters('layers_' . $this->widget_id . '_widget_design_bar_components', array(
                    'layout',
                    'fonts',
                    'background',
                    'advanced'
                )) // Standard Components
            ); ?>
            <div class="layers-container-large layers-tl_column-widget"
                 id="layers-<?php echo esc_attr($this->widget_id);?>-widget-<?php echo esc_attr($this->number); ?>">
                <?php $this->form_elements()->header(array(
                    'title' => 'Services',
                    'icon_class' => 'text'
                )); ?>
                <section class="layers-accordion-section layers-content">
                    <p class="layers-form-item">
                        <?php echo $this->form_elements()->input(
                            array(
                                'type' => 'text',
                                'name' => $this->get_layers_field_name('title'),
                                'id' => $this->get_layers_field_id('title'),
                                'placeholder' => __('Enter title here', 'layerswp'),
                                'value' => (isset($widget['title'])) ? $widget['title'] : NULL,
                                'class' => 'layers-text layers-large'
                            )
                        ); ?>
                    </p>

                    <p class="layers-form-item">
                        <?php echo $this->form_elements()->input(
                            array(
                                'type' => 'rte',
                                'name' => $this->get_layers_field_name('excerpt'),
                                'id' => $this->get_layers_field_id('excerpt'),
                                'placeholder' => __('Short Excerpt', 'layerswp'),
                                'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                'class' => 'layers-textarea layers-large'
                            )
                        ); ?>
                    </p>
                </section>
                <section class="layers-accordion-section layers-content">
                    <div class="layers-form-item">
                        <?php $this->repeater('column', $widget); ?>
                    </div>
                </section>
            </div>
            <?php
            if (TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_end_flush();
        } // Form


        /**
         * @param $item_guid
         * @param $widget
         */
        function column_item($item_guid, $widget)
        {
            // Extract Instance if it's there so that we can use the values in our inputs
            ?>
            <li class="layers-accordion-item" data-guid="<?php echo esc_attr($item_guid); ?>">
                <a class="layers-accordion-title">
						<span>
							<?php _e('Column', TL_INSERT_STAFF_SLUG); ?>
                            <span class="layers-detail">
								<?php echo(isset($widget['title']) ? ': ' . substr(stripslashes(strip_tags($widget['title'])), 0, 50) : NULL); ?>
                                <?php echo(isset($widget['title']) && strlen($widget['title']) > 50 ? '...' : NULL); ?>
							</span>
						</span>
                </a>
                <section class="layers-accordion-section layers-content">
                    <?php $this->design_bar(
                        'top', // CSS Class Name
                        array(
                            'name' => $this->get_layers_field_name('design'),
                            'id' => $this->get_layers_field_id('design'),
                            'widget_id' => $this->widget_id . '_item',
                            'number' => $this->number,
                            'show_trash' => true
                        ), // Widget Object
                        $widget, // Widget Values
                        array(
                            'background',
                            'featuredimage',
                            'imagealign',
                            'fonts',
                            'title_attrs' => array(
                                'icon-css' => 'icon-call-to-action',
                                'label' => 'Icon Options',
                                'wrapper-class' => 'layers-pop-menu-wrapper layers-content-small tl-title-options',
                                'elements' => array(
                                    'titlecolor' => array(
                                        'type' => 'color',
                                        'label' => 'Icon Color',
                                        'name' => $this->get_layers_field_name('titlecolor'),//'widget-' . $widget_details->id_base . '[' . $widget_details->number . '][columns][' . $item_guid . '][titlecolor]',
                                        'id' => $this->get_layers_field_id('titlecolor'),//'widget-' . $widget_details->id_base . '-' . $widget_details->number . '-' . $item_guid . '-titlecolor',
                                        'value' => isset($widget['titlecolor']) ? $widget['titlecolor'] : null
                                    ),
                                    'icon_btn' => array(
                                        'type' => 'button',
                                        'class' => 'expand-icons',
                                        'label' => 'Select an Icon',
                                        'name' => $this->get_layers_field_name('icon_btn'),//'widget-' . $widget_details->id_base . '[' . $widget_details->number . '][columns][' . $item_guid . '][icon_btn]',
                                        'id' => $this->get_layers_field_id('icon_btn'),//'widget-' . $widget_details->id_base . '-' . $widget_details->number . '-' . $item_guid . '-icon_btn',
                                    ),
                                    'icon_class' => array(
                                        'type' => 'hidden',
                                        'name' => $this->get_layers_field_name('icon_class'),//'widget-' . $widget_details->id_base . '[' . $widget_details->number . '][columns][' . $item_guid . '][icon_class]',
                                        'id' => $this->get_layers_field_id('icon_class'),//'widget-' . $widget_details->id_base . '-' . $widget_details->number . '-' . $item_guid . '-icon_class',
                                        'value' => (isset($widget['icon_class']) && $widget['icon_class'] != '') ? $widget['icon_class'] : null
                                    )
                                ),
                            ),
                            'width' => array(
                                'icon-css' => 'icon-columns',
                                'label' => 'Column Width',
                                'elements' => array(
                                    'layout' => array(
                                        'type' => 'select',
                                        'label' => '',
                                        'name' => $this->get_layers_field_name('width'),//'widget-' . $widget_details->id_base . '[' . $widget_details->number . '][columns][' . $item_guid . '][width]',
                                        'id' => $this->get_layers_field_id('width'),//'widget-' . $widget_details->id_base . '-' . $widget_details->number . '-' . $item_guid . '-width',
                                        'value' => (isset($widget['width'])) ? $widget['width'] : NULL,
                                        'options' => array(
                                            '1' => __('1 of 12 columns', TL_INSERT_STAFF_SLUG),
                                            '2' => __('2 of 12 columns', TL_INSERT_STAFF_SLUG),
                                            '3' => __('3 of 12 columns', TL_INSERT_STAFF_SLUG),
                                            '4' => __('4 of 12 columns', TL_INSERT_STAFF_SLUG),
                                            '5' => __('5 of 12 columns', TL_INSERT_STAFF_SLUG),
                                            '6' => __('6 of 12 columns', TL_INSERT_STAFF_SLUG),
                                            '7' => __('7 of 12 columns', TL_INSERT_STAFF_SLUG),
                                            '8' => __('8 of 12 columns', TL_INSERT_STAFF_SLUG),
                                            '9' => __('9 of 12 columns', TL_INSERT_STAFF_SLUG),
                                            '10' => __('10 of 12 columns', TL_INSERT_STAFF_SLUG),
                                            '11' => __('11 of 12 columns', TL_INSERT_STAFF_SLUG),
                                            '12' => __('12 of 12 columns', TL_INSERT_STAFF_SLUG)
                                        )
                                    ),
                                    'c_no_padding' => array(
                                        'type' => 'checkbox',
                                        'label' => __('Force column without padding', TL_INSERT_STAFF_SLUG),
                                        'name' => $this->get_layers_field_name('c_no_padding'),//'widget-' . $widget_details->id_base . '[' . $widget_details->number . '][columns][' . $item_guid . '][c_no_padding]',
                                        'id' => $this->get_layers_field_id('c_no_padding'),//'widget-' . $widget_details->id_base . '-' . $widget_details->number . '-' . $item_guid . '-c_no_padding',
                                        'value' => (isset($widget['c_no_padding'])) ? $widget['c_no_padding'] : NULL,
                                    ),
                                    'c_padding' => array(
                                        'type' => 'trbl-fields',
                                        'label' => __('Column inner padding (px)', TL_INSERT_STAFF_SLUG),
                                        'name' => $this->get_layers_field_name('c_padding'),//'widget-' . $widget_details->id_base . '[' . $widget_details->number . '][columns][' . $item_guid . '][c_padding]',
                                        'id' => $this->get_layers_field_id('c_padding'),//'widget-' . $widget_details->id_base . '-' . $widget_details->number . '-' . $item_guid . '-c_padding',
                                        'value' => (isset($widget['c_padding']) && is_array($widget['c_padding'])) ? $widget['c_padding'] : NULL,
                                    ),
                                    'c_margin' => array(
                                        'type' => 'trbl-fields',
                                        'label' => __('Column inner margin (px)', TL_INSERT_STAFF_SLUG),
                                        'name' => $this->get_layers_field_name('c_margin'),//'widget-' . $widget_details->id_base . '[' . $widget_details->number . '][columns][' . $item_guid . '][c_margin]',
                                        'id' => $this->get_layers_field_id('c_margin'),//'widget-' . $widget_details->id_base . '-' . $widget_details->number . '-' . $item_guid . '-c_margin',
                                        'value' => (isset($widget['c_margin']) && is_array($widget['c_margin'])) ? $widget['c_margin'] : NULL,
                                    ),
                                    'c_class' => array(
                                        'type' => 'text',
                                        'placeholder' => 'example-class',
                                        'label' => __('Custom class', TL_INSERT_STAFF_SLUG),
                                        'name' => $this->get_layers_field_name('c_class'),//'widget-' . $widget_details->id_base . '[' . $widget_details->number . '][columns][' . $item_guid . '][c_class]',
                                        'id' => $this->get_layers_field_id('c_class'),//'widget-' . $widget_details->id_base . '-' . $widget_details->number . '-' . $column_guid . '-c_class',
                                        'value' => (isset($widget['c_class'])) ? $widget['c_class'] : NULL,
                                    ),
                                )
                            ),
                        ) // Standard Components
                    );
                    ?>
                    <div class="layers-row">
                        <p class="layers-form-item">
                            <label
                                for="<?php echo esc_attr($this->get_layers_field_id('post_item')) ?>"><?php _e('Select a service', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(array(
                                'type' => 'select',
                                'name' => $this->get_layers_field_name('post_item'),
                                'id' => $this->get_layers_field_id('post_item'),
                                'label' => __('Select a service', TL_INSERT_STAFF_SLUG),
                                'options' => tl_get_posts(['post_type' => 'tl_service']),
                                'value' => (isset($widget['post_item'])) ? $widget['post_item'] : NULL,
                                'class' => 'layers-select layers-large tl-select-post-item',
                                'placeholder' => __('-- None --', TL_INSERT_STAFF_SLUG),
                            ));
                            ?>
                            <span
                                class="customize-control-description"><?php _e('Selected item overwites content of Title/Excerpt fields.', TL_INSERT_STAFF_SLUG); ?></span>
                        </p>

                        <p class="layers-form-item">
                            <label
                                for="<?php echo esc_attr($this->get_layers_field_id('title')); ?>"><?php _e('Title', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'text',
                                    'name' => $this->get_layers_field_name('title'),
                                    'id' => $this->get_layers_field_id('title'),
                                    'placeholder' => __('Enter title here', TL_INSERT_STAFF_SLUG),
                                    'value' => (isset($widget['title'])) ? $widget['title'] : NULL,
                                    'class' => 'layers-text'
                                )
                            ); ?>
                        </p>

                        <p class="layers-form-item">
                            <label
                                for="<?php echo esc_attr($this->get_layers_field_id('excerpt')); ?>"><?php _e('Excerpt', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'rte',
                                    'name' => $this->get_layers_field_name('excerpt'),
                                    'id' => $this->get_layers_field_id('excerpt'),
                                    'placeholder' => __('Excertp', TL_INSERT_STAFF_SLUG),
                                    'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                    'class' => 'layers-text'
                                )
                            ); ?>
                        </p>

                        <div class="layers-row">
                            <p class="layers-form-item layers-column layers-span-6">
                                <label
                                    for="<?php echo esc_attr($this->get_layers_field_id('link')); ?>"><?php _e('Button Link', TL_INSERT_STAFF_SLUG); ?></label>
                                <?php echo $this->form_elements()->input(
                                    array(
                                        'type' => 'text',
                                        'name' => $this->get_layers_field_name('link'),
                                        'id' => $this->get_layers_field_id('link'),
                                        'placeholder' => __('http://', 'layerswp'),
                                        'value' => (isset($widget['link'])) ? $widget['link'] : NULL,
                                        'class' => 'layers-text'
                                    )
                                ); ?>
                                <span
                                    class="customize-control-description"><?php _e('If service selected from a list, it overwrites this option.', TL_INSERT_STAFF_SLUG); ?></span>
                            </p>

                            <p class="layers-form-item layers-column layers-span-6">
                                <label
                                    for="<?php echo esc_attr($this->get_layers_field_id('link_text')); ?>"><?php _e('Button Text', TL_INSERT_STAFF_SLUG); ?></label>
                                <?php echo $this->form_elements()->input(
                                    array(
                                        'type' => 'text',
                                        'name' => $this->get_layers_field_name('link_text'),
                                        'id' => $this->get_layers_field_id('link_text'),
                                        'placeholder' => __('e.g. "Read More"', TL_INSERT_STAFF_SLUG),
                                        'value' => (isset($widget['link_text'])) ? $widget['link_text'] : NULL,
                                    )
                                ); ?>
                            </p>
                        </div>
                    </div>
                </section>
            </li>
        <?php
        }


        protected function _addFilters()
        {
            add_filter('tl_colorize_title_' . $this->widget_id, 'tl_colorize_title', 10, 2);
            add_filter('tl/layers/background_component/' . $this->widget_id . '/args', array($this, 'customizeBackgroundComponent'), 10, 4);
            add_filter('tl/layers/fonts_component/' . $this->widget_id . '/args', array($this, 'customizeFontsComponent'), 10, 4);
        }


        /**
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeFontsComponent($args, $position, $widget, $values)
        {
            if ($position == 'side') {

                //Add at the beggining of the array
                $args['elements'] = array('fonts-title-heading' => array('type' => 'layers-heading', 'label' => 'Title Options')) + $args['elements'];

                // this goes to the all widgets
                $args['elements']['fonts-excerpt-heading'] = array(
                    'type' => 'layers-heading',
                    'label' => 'Excerpt Options',
                );

                $args['elements']['fonts-excerpt-color'] = array(
                    'type' => 'color',
                    'label' => 'Excerpt Color',
                    'name' => $widget['name'] . '[fonts][excerpt-color]',
                    'id' => $widget['id'] . '-fonts-excerpt-color',
                    'value' => isset($values['fonts']['excerpt-color']) ? $values['fonts']['excerpt-color'] : null,
                );
            }
            return $args;
        }


        public function customizeBackgroundComponent($args, $position, $widget, $values)
        {
            if ($position == 'side') {
                unset($args['elements']['background-darken']);
            }
            return $args;
        }


        public function customizeButtonsComponent($args, $position, $widget, $values)
        {
            if ($position == 'side') {
                unset($args['elements']['buttons-size']);
            }
            return $args;
        }

    } // Class

    // Add our function to the widgets_init hook.
    register_widget("TL_Layers_Services_Widget");
}