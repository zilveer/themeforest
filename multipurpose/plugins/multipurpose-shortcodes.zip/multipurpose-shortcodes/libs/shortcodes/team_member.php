<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// shortcode Team Member
add_shortcode('team_member','multipurpose_team_member');

function multipurpose_filter_team_class_default($content) {
    return $content.' team';
}

function multipurpose_filter_team_class_boxed($content) {
    return $content.' boxed';
}

function multipurpose_filter_team_class_circled($content) {
    return $content.' circled';
}

function multipurpose_filter_team_class_centered($content) {
    return $content.' centered';
}

function multipurpose_team_member($atts, $content = null) {
    add_filter('multipurpose_filters_team_class', 'multipurpose_filter_team_class_default', 10);

    if (isset($atts['boxed']) && !empty($atts['boxed']))
        if (multipurpose_arrangement_shortcode_value($atts['boxed']) == "yes")
            add_filter('multipurpose_filters_team_class', 'multipurpose_filter_team_class_boxed', 10);

    if (isset($atts['circled_image']) && !empty($atts['circled_image']))
        if (multipurpose_arrangement_shortcode_value($atts['circled_image']) == "yes")
            add_filter('multipurpose_filters_team_class', 'multipurpose_filter_team_class_circled', 10);

    if (isset($atts['centered']) && !empty($atts['centered']))
        if (multipurpose_arrangement_shortcode_value($atts['centered']) == "yes")
            add_filter('multipurpose_filters_team_class', 'multipurpose_filter_team_class_centered', 10);

    $output = '';

    if (!isset($atts['social_vertical']) || empty($atts['social_vertical']))
        $atts['social_vertical'] = 'no';

    if (multipurpose_arrangement_shortcode_value($atts['social_vertical']) == "yes") {
        $output .= '<div class="img-border"><img';

        if (isset($atts['image_url']) && !empty($atts['image_url']))
            $output .= ' src="' . $atts['image_url'] . '"';

        if (isset($atts['image_alt']) && !empty($atts['image_alt']))
            $output .= ' alt="' . $atts['image_alt'] . '"';

        $output .= '></div>';

        $output .= '<ul class="social';

        if (isset($atts['social_colored']) && !empty($atts['social_colored']))
            if (multipurpose_arrangement_shortcode_value($atts['social_colored']) == "yes")
                $output .= ' social-colored';

        $output .= ' vertical">';

        foreach ($atts as $key => $att) {
            if ($key != 'image_url' and $key != 'image_alt' and $key != 'name' and $key != 'position' and $key != 'divider' and $key != 'social_colored' and $key != 'centered' and $key != 'boxed' and $key != 'circled_image' and $key != 'social_vertical') {
                $class_name = $key;
                $text_name = ucwords($key);
                if ($key == 'google') {
                    $class_name = "googleplus";
                    $text_name = "Google+";
                }
                if ($key == 'mail') {
                    $class_name = "email";
                    $text_name = "E-mail";
                }
                if ($key == 'linkedin') {
                    $text_name = "LinkedIn";
                }
                $output .=!empty($att) ? '<li><a href="' . motive_arrangement_shortcode_value($att) . '" class="' . $class_name . '">' . $text_name . '</a></li>' : "";
            }
        }

        $output .= '</ul>';

        $output .= '<h3>' . (isset($atts['name']) && !empty($atts['name']) ? multipurpose_arrangement_shortcode_value($atts['name']) : "") . '</h3>';
        $output .= '<p class="position">' . (isset($atts['position']) && !empty($atts['position']) ? multipurpose_arrangement_shortcode_value($atts['position']) : "") . '</p>';

        if (isset($atts['divider']) && !empty($atts['divider']))
            if (multipurpose_arrangement_shortcode_value($atts['divider']) == "yes")
                $output .= '<hr>';

        $output .= '<p>' . $content . '</p>';
        
    } else {
        $output .= '<div class="img-border"><img';

        if (isset($atts['image_url']) && !empty($atts['image_url']))
            $output .= ' src="' . $atts['image_url'] . '"';

        if (isset($atts['image_alt']) && !empty($atts['image_alt']))
            $output .= ' alt="' . $atts['image_alt'] . '"';

        $output .= '></div>';

        $output .= '<h3>' . (isset($atts['name']) && !empty($atts['name']) ? multipurpose_arrangement_shortcode_value($atts['name']) : "") . '</h3>';
        $output .= '<p class="position">' . (isset($atts['position']) && !empty($atts['position']) ? multipurpose_arrangement_shortcode_value($atts['position']) : "") . '</p>';

        if (isset($atts['divider']) && !empty($atts['divider']))
            if (multipurpose_arrangement_shortcode_value($atts['divider']) == "yes")
                $output .= '<hr>';

        $output .= '<ul class="social';

        if (isset($atts['social_colored']) && !empty($atts['social_colored']))
            if (multipurpose_arrangement_shortcode_value($atts['social_colored']) == "yes")
                $output .= ' social-colored';

        $output .= '">';

        foreach ($atts as $key => $att) {
            if ($key != 'image_url' and $key != 'image_alt' and $key != 'name' and $key != 'position' and $key != 'divider' and $key != 'social_colored' and $key != 'centered' and $key != 'boxed' and $key != 'circled_image' and $key != 'social_vertical') {
                $class_name = $key;
                $text_name = ucwords($key);
                if ($key == 'google') {
                    $class_name = "googleplus";
                    $text_name = "Google+";
                }
                if ($key == 'mail') {
                    $class_name = "email";
                    $text_name = "E-mail";
                }
                if ($key == 'linkedin') {
                    $text_name = "LinkedIn";
                }
                $output .=!empty($att) ? '<li><a href="' . multipurpose_arrangement_shortcode_value($att) . '" class="' . $class_name . '">' . $text_name . '</a></li>' : "";
            }
        }

        $output .= '</ul>';
        $output .= '<p>' . $content . '</p>';
    }

    return $output;
}