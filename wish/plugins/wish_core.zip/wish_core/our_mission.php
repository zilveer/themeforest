<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Our Mission", "wish"),
    "description" => __("", 'wish'),
    "controls" => "full",
    "base" => "wish_our_mission",
    "as_parent" => array('only' => 'wish_our_mission_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/gAPexkQ.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bg_color",
            "value" => '#ffffff;', //Default Red color
            "description" => __( "Choose Background color", "wish" ),
            "group"     => 'Colors'
        ), 

    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Our Mission", "wish"),
    "base" => "wish_our_mission_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_our_mission'), 
    "params" => array(

        array(
            "type" => "wish_fontawesome_param",
            "holder" => "div",
            "class" => "",
            "heading" => __("Custom Icon", 'wish'),
            "param_name" => "custom_icon",
            "value" => __("fa-adn", 'wish'),
            "description" => __("Get Font Awesome Icons Code Here: <a target='_blank' href='http://fortawesome.github.io/Font-Awesome/cheatsheet/'>Link</a>, New icons may not work. Leave blank if you want to use the above icon.", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Custom Icon color", "wish" ),
            "param_name" => "icon_color",
            "value" => '#e55c4c',
            "description" => __( "Choose Custom Icon color", "wish" ),
            "group"         => "Fonts & Colors",
            "admin_label" => false,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Heading", "wish"),
            "param_name" => "title",
            "description" => __("The Title", "wish"),
            "value" => __("Our Mission Title and Position", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Mes cuml dia sed in lacus ut eniascet eto ingerto aliiqt es site amet eismod ictor ut ligulate ameti dapibus", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("Link To The Page", 'wish'),
            "param_name" => "link",
            "description" => __("The Link To The page.", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Link Title", "wish"),
            "param_name" => "link_text",
            "description" => __("Title of the link", "wish"),
            "value" => __("", 'wish'),
            "admin_label" => false,
        ),



        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#071041 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),




        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),







    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Our_Mission extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'bg_color' => '',
          ), $atts ) );

      $output = "<div class='our-mission' style='background-color:{$bg_color};'>
            <div class='row'>
                    " . do_shortcode($content) . "
                
            </div>
            </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Our_Mission_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'custom_icon'   => 'fa-adn',
            'icon_color' => '#e55c4c',
            
            'title'   => 'Our Mission',
            'title_font'    => '',
            'title_size'   => '24',
            'title_color' => '#071041',

            'details' => 'Mes cuml dia sed in lacus ut eniascet eto ingerto aliiqt es site amet eismod ictor ut ligulate ameti dapibus',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#000',

            'link' => '',
            'link_text' => '',
          ), $atts ) );

          /*title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        if($link == "||" || $link == "" ){
            
            $link_text = "Read More";
            $link_url = "#";
            $link_target = "";
            $link_string="";

          }else{

            $link = vc_build_link($link); //parse the link
            $link_url = esc_url($link["url"]);
            $link_target = esc_attr($link["target"]);
            $link_string="<div class='sqr-buttons'><a href='{$link_url}' target='{$link_target}' class='fill'>{$link_text}</a></div>";
            if ($link_text == "") {
                $link_string = "";
            }

          }

          $output = "<div class='col-lg-4'>
                    <div class='icon' style='background-color:{$icon_color};'><i class='fa {$custom_icon}'></i></div>
                    <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                    <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                    {$link_string}
                </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>