	</div><!-- #wrap -->
	<a id="tb_back_to_top">
		<span class="go_up">
		<i class="icon-up"></i> 
		</span>
	</a>
	<?php wp_footer(); ?>
</body>