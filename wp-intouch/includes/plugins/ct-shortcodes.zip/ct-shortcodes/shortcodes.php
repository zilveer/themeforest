<?php
/*
==============================================================================================
						Columns (Bootstrap Styles)
==============================================================================================
*/

// Row - Container For The Columns
if ( !function_exists('colortheme_row')) {
function colortheme_row( $atts, $content = null ) {
	extract( shortcode_atts( array(), $atts ) );
	
		$code = '<div class="row clearfix">' . do_shortcode( $content ) . '</div>';
		
		return $code;
	}
	add_shortcode('row', 'colortheme_row');
}

// col-lg-1 - 1 Column
if (!function_exists('colortheme_col_lg_1')) {
	function colortheme_col_lg_1( $atts, $content = null ) {
	   return '<div class="col-lg-1">' . do_shortcode($content) . '</div> <!-- .col-lg-1 -->';
	}
	add_shortcode('col-lg-1', 'colortheme_col_lg_1');
}

// col-lg-2 - 2 Columns
if (!function_exists('colortheme_col_lg_2')) {
	function colortheme_col_lg_2( $atts, $content = null ) {
	   return '<div class="col-lg-2">' . do_shortcode($content) . '</div> <!-- .col-lg-2 -->';
	}
	add_shortcode('col-lg-2', 'colortheme_col_lg_2');
}

// col-lg-3 - 3 Columns
if (!function_exists('colortheme_col_lg_3')) {
	function colortheme_col_lg_3( $atts, $content = null ) {
	   return '<div class="col-lg-3">' . do_shortcode($content) . '</div> <!-- .col-lg-3 -->';
	}
	add_shortcode('col-lg-3', 'colortheme_col_lg_3');
}

// col-lg-4 - 4 Columns
if (!function_exists('ccolortheme_col_lg_4')) {
	function colortheme_col_lg_4( $atts, $content = null ) {
	   return '<div class="col-lg-4">' . do_shortcode($content) . '</div> <!-- .col-lg-4 -->';
	}
	add_shortcode('col-lg-4', 'colortheme_col_lg_4');
}

// col-lg-5 - 5 Columns
if (!function_exists('colortheme_col_lg_5')) {
	function colortheme_col_lg_5( $atts, $content = null ) {
	   return '<div class="col-lg-5">' . do_shortcode($content) . '</div> <!-- .col-lg-5 -->';
	}
	add_shortcode('col-lg-5', 'colortheme_col_lg_5');
}

// col-lg-6 - 6 Columns
if (!function_exists('colortheme_col_lg_6')) {
	function colortheme_col_lg_6( $atts, $content = null ) {
	   return '<div class="col-lg-6">' . do_shortcode($content) . '</div> <!-- .col-lg-6 -->';
	}
	add_shortcode('col-lg-6', 'colortheme_col_lg_6');
}

// col-lg-7 - 7 Columns
if (!function_exists('colortheme_col_lg_7')) {
	function colortheme_col_lg_7( $atts, $content = null ) {
	   return '<div class="col-lg-7">' . do_shortcode($content) . '</div> <!-- .col-lg-7 -->';
	}
	add_shortcode('col-lg-7', 'colortheme_col_lg_7');
}

// col-lg-8 - 8 Columns
if (!function_exists('colortheme_col_lg_8')) {
	function colortheme_col_lg_8( $atts, $content = null ) {
	   return '<div class="col-lg-8">' . do_shortcode($content) . '</div> <!-- .col-lg-8 -->';
	}
	add_shortcode('col-lg-8', 'colortheme_col_lg_8');
}

// col-lg-9 - 9 Columns
if (!function_exists('colortheme_col_lg_9')) {
	function colortheme_col_lg_9( $atts, $content = null ) {
	   return '<div class="col-lg-9">' . do_shortcode($content) . '</div> <!-- .col-lg-9 -->';
	}
	add_shortcode('col-lg-9', 'colortheme_col_lg_9');
}

// col-lg-10 - 10 Columns
if (!function_exists('colortheme_col_lg_10')) {
	function colortheme_col_lg_10( $atts, $content = null ) {
	   return '<div class="col-lg-10">' . do_shortcode($content) . '</div> <!-- .col-lg-10 -->';
	}
	add_shortcode('col-lg-10', 'colortheme_col_lg_10');
}

// col-lg-11 - 11 Columns
if (!function_exists('colortheme_col_lg_11')) {
	function colortheme_col_lg_11( $atts, $content = null ) {
	   return '<div class="col-lg-11">' . do_shortcode($content) . '</div> <!-- .col-lg-11 -->';
	}
	add_shortcode('col-lg-11', 'colortheme_col_lg_11');
}

// col-lg-12 - 12 Columns
if (!function_exists('colortheme_col_lg_12')) {
	function colortheme_col_lg_12( $atts, $content = null ) {
	   return '<div class="col-lg-12">' . do_shortcode($content) . '</div> <!-- .col-lg-12 -->';
	}
	add_shortcode('col-lg-12', 'colortheme_col_lg_12');
}


/*
==============================================================================================
						Headings Shortcode
==============================================================================================
*/
if (!function_exists('colortheme_headings')) {
	function colortheme_headings( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'level' => 'h1'
	    ), $atts));
				

			$code = '';

			switch($level) {
				case 'h1':
					$code .= '<h1>' . do_shortcode($content) . '</h1>';
					break;
				case 'h2':
					$code .= '<h2>' . do_shortcode($content) . '</h2>';
					break;
				case 'h3':
					$code .= '<h3>' . do_shortcode($content) . '</h3>';
					break;
				case 'h4':
					$code .= '<h4>' . do_shortcode($content) . '</h4>';
					break;
				case 'h5':
					$code .= '<h5>' . do_shortcode($content) . '</h5>';
					break;
				case 'h6':
					$code .= '<h6>' . do_shortcode($content) . '</h6>';
					break;
			}
			
    	return $code;

	}
	
	add_shortcode('ct_headings', 'colortheme_headings');
}


/*
==============================================================================================
						Clear Float Blocks
==============================================================================================
*/

if (!function_exists('colortheme_clear')) {
	function colortheme_clear($atts, $content = null) {
		return '<div class="clear"></div>';
	}
	add_shortcode('clear', 'colortheme_clear');
}

/*
==============================================================================================
						Divider Plus
==============================================================================================
*/

if (!function_exists('colortheme_divider')) {
	function colortheme_divider() {
		return '<div class="divider-1px"></div>';
	}
	add_shortcode('ct_divider', 'colortheme_divider');
}


/*
==============================================================================================
						Top Margins
==============================================================================================
*/


if (!function_exists('colortheme_margin')) {
	function colortheme_margin( $atts, $content = null ) {
		extract(shortcode_atts(array(			
			'style' => 't',
			'margin' => '5',			
	    ), $atts));

		switch ($style) {
			case 'top':
				$type_margin = 't';
				break;

			case 'bottom':
				$type_margin = 'b';
				break;

			case 'no-top':
				$type_margin = 't-n';
				break;

			case 'no-bottom':
				$type_margin = 'b-n';
				break;
			
			default:
				$type_margin = 't';
				break;
		}

		$code = '';
		if ( $style == 'no-top' || $style == 'no-bottom') {
			$code = '<div class="clear"></div><div class="margin-'. $type_margin .'"></div>';			
		} else $code = '<div class="clear"></div><div class="margin-'. $margin . $type_margin .'"></div>';

		return $code;
	}
	
	add_shortcode('ct_margin', 'colortheme_margin');
}



/*
==============================================================================================
						Highlights
==============================================================================================
*/
if (!function_exists('colortheme_highlight')) {
	function colortheme_highlight( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'text' => '',
			'color' => 'green',
			'type' => 'round'
	    ), $atts));

		return '<span class="highlight '. $type .' '. $color .'">' . do_shortcode ($content) . '</span>';		
	}
	
	add_shortcode('ct_highlight', 'colortheme_highlight');
}

/*
==============================================================================================
						Dropcaps
==============================================================================================
*/
if (!function_exists('colortheme_dropcap')) {
	function colortheme_dropcap( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'text' => '',
			'color' => 'green',
			'size' => 'medium'
	    ), $atts));

		return '<span class="dropcap '. $color . ' ' . $size . '">' . do_shortcode ($content) . '</span>';		
	}
	
	add_shortcode('ct_dropcap', 'colortheme_dropcap');
}


/*
==============================================================================================
						labels
==============================================================================================
*/
if (!function_exists('colortheme_labels')) {
	function colortheme_labels( $atts, $content = null ) {
		extract(shortcode_atts(array(			
			'type' => 'default'			
	    ), $atts));

		$code = '<span class="label label-'. $type . '">' . do_shortcode ($content) . '</span>';
		return $code;
	}
	
	add_shortcode('ct_label', 'colortheme_labels');
}

/*
==============================================================================================
						Badges
==============================================================================================
*/
if (!function_exists('colortheme_badges')) {
	function colortheme_badges( $atts, $content = null ) {
		extract(shortcode_atts(array(			
			'type' => 'default'			
	    ), $atts));

		if ( $type == 'default' ) $code = '<span class="badge">' . do_shortcode ($content) . '</span>';
		else {
			$code = '<span class="badge badge-'. $type . '">' . do_shortcode ($content) . '</span>';
		}
		return $code;
	}
	
	add_shortcode('ct_badge', 'colortheme_badges');
}

/*
==============================================================================================
						Buttons
==============================================================================================
*/
if (!function_exists('colortheme_button')) {
	function colortheme_button( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'url' => '',						
			'style' => 'btn btn-default',
			'size' => 'medium',
			'type' => 'round',
			'target' => '_self'

	    ), $atts));

		
		$output = '';

		$output .= '<a class="'. $style . ' ' . $size . ' ' . $type . '" target="' . $target . '" href="' . $url . '">' . do_shortcode( $content ) . '</a>';

		return $output;

	}
	
	add_shortcode('ct_button', 'colortheme_button');
}

/*
==============================================================================================
						Alerts
==============================================================================================
*/
if (!function_exists('colortheme_alerts')) {
	function colortheme_alerts( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'title'		=> '',						
			'type'		=> 'success'			
	    ), $atts));

		if ( $title == '' ) $code = '<button type="button" class="close" data-dismiss="alert">&times;</button>';
		else $code = '<button type="button" class="close" data-dismiss="alert">&times;</button><strong>' . $title. '</strong>';

		return '<div class="alert alert-'. $type . '">' . $code . '' . do_shortcode ($content) . '</div>';

	}
	
	add_shortcode('ct_alert', 'colortheme_alerts');
}

/*
==============================================================================================
						Progress Bars
==============================================================================================
*/
if (!function_exists('colortheme_progress_bars')) {
	function colortheme_progress_bars( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'type' => 'success',
			'striped' => 'yes',
			'animation' => 'yes',
			'value' => '50',
			'title' => ''

	    ), $atts));

		if ( $striped == 'yes' ) $striped = 'progress-striped'; else $striped = '';
		if ( $animation == 'yes' ) $active = 'active'; else $active = '';
		return '<div class="progress '. $striped . ' ' . $active . '"><div class="progress-bar progress-bar-' . $type . '" aria-valuenow="'.$value.'" aria-valuemin="0" aria-valuemax="100" style="width: '. $value .'%">'. $title .' (' . $value . '%)</div></div>';

	}
	
	add_shortcode('ct_progress', 'colortheme_progress_bars');
}

/*
==============================================================================================
						Font Awesome Icons
==============================================================================================
*/
if (!function_exists('colortheme_icons')) {
	function colortheme_icons( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'title' => 'Icon Title',
			'icon' => 'icon-home',
			'size' => '',
			'color' => '',
			'position' => 'left'
	    ), $atts));

		$code .= '<i class="fa fa-' . $icon . ' pull-' . $position . '" style="font-size: ' . $size . 'px; color: ' . $color . ';"></i>'. do_shortcode($title);

    	return $code;

	}
	
	add_shortcode('ct_icon', 'colortheme_icons');
}

/*
==============================================================================================
						Soundcloud Shortcode
==============================================================================================
*/
if (!function_exists('colortheme_soundcloud')) {
	function colortheme_soundcloud( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'title' => 'Title',
			'url' => '',
			'height' => '200',
			'auto_play' => 'no'
	
	    ), $atts));

		$code = '';
		if ( $auto_play == 'yes' ) $auto_play = 'true'; else $auto_play = 'false';

		$code .= '<div class="soundcloud-shortcode clearfix">';
			
			if ( $title != '' ) {
				$code .='<h3 class="short_title">' . $title . '</h3>';
			}	
				$code .= '<div class="soundcloud-iframe">';	
					$code .= '<iframe height="'.$atts['height'].'" src="https://w.soundcloud.com/player/?url=' . urlencode($url) . '&amp;auto_play=' . $auto_play .'"></iframe>';		
				$code .= '</div> <!-- /soundcloud-iframe -->';

			$code .= do_shortcode($content);

		$code .= '</div> <!-- /soundcloud-shortcode -->';

    	return $code;

	}
	
	add_shortcode('ct_soundcloud', 'colortheme_soundcloud');
}


/*
==============================================================================================
						Video Shortcode
==============================================================================================
*/
if (!function_exists('colortheme_video')) {
	function colortheme_video( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'title' => 'Title',
			'type' => 'vimeo',
			'id' => '7449107'	
	    ), $atts));

		$code = '';
		
		$code .= '<div class="video-shortcode clearfix">';
			
			if ( $title != '' ) {
				$code .='<h3 class="short_title">' . $title . '</h3>';
			}	
					$code .= '<div class="video-post-widget">';
						if ( $type == 'vimeo' ) {
							$code .= '<iframe src="http://player.vimeo.com/video/' . $id . '?title=0&amp;byline=0&amp;portrait=0&amp;"></iframe>';
						}
						if ( $type == 'youtube' ) {
							$code .= '<iframe src="http://www.youtube.com/embed/' . $id . '?autohide=1&amp;showinfo=0"></iframe>';
						}
						if ( $type == 'dailymotion' ) {
							$code .= '<iframe src="http://www.dailymotion.com/embed/video/' . $id . '?logo=0"></iframe>';
						}
					$code .= '</div> <!-- /video-post-widget -->';
						
				$code .= do_shortcode($content);
						
		$code .= '</div> <!-- /video-shortcode -->';

    	return $code;

	}
	
	add_shortcode('ct_video', 'colortheme_video');
}

/*-----------------------------------------------------------------------------------*/
/*	Infobox Shortcodes
/*-----------------------------------------------------------------------------------*/


/*if (!function_exists('colortheme_infobox')) {
	function colortheme_infobox( $atts, $content = null ) {
		$defaults = array();
		extract(shortcode_atts(array(
			'title'   => 'Title',
			'url' => '',
			'more' => 'Read More',
			'icon' => 'icon-home'

	    ), $atts));	

	
			$output = '';
		    $output .= '<div class="infobox clearfix">';
			    if ( $title != '' ) {
					$output .='<h3 class="short_title">' . $title . '</h3>';
				}	
		    	$output .= '<div class="icon-info-circle"><i class="icon icon-' . $icon . '"></i></div>';		    	
				$output .= '<p>' . do_shortcode ($content) . '</p>';	
				$output .= '<div class="clear"></div>';
				$output .= '<a href="' . $url . '">' . $more . '</a><div class="infobox-right-arrow"></div>';
		    $output .= '</div>';

		return $output;
	}
	add_shortcode( 'ct_infobox', 'colortheme_infobox' );
}*/

/*-----------------------------------------------------------------------------------*/
/*	Infoblock Shortcodes
/*-----------------------------------------------------------------------------------*/


if (!function_exists('colortheme_infoblock')) {
	function colortheme_infoblock( $atts, $content = null ) {
		$defaults = array();
		extract(shortcode_atts(array(
			'title'   => 'Title',
			'url' => '',
			'icon' => 'icon-home'

	    ), $atts));	

	
			$output = '';			

		    $output .= '<div class="infoblock clearfix">';
		    	$output .= '<div class="icon-infoblock"><i class="icon icon-' . $icon . '"></i></div>';

				$output .= '<div class="infoblock-info">';

				    if ( $title != '' ) {
						$output .='<h3 class="short_title">' . $title . '</h3>';
					}	
			    	
					$output .= '<p>' . do_shortcode ($content) . '</p>';	

				$output .= '</div>';

		    $output .= '</div>';

		return $output;
	}
	add_shortcode( 'ct_infoblock', 'colortheme_infoblock' );
}



/*-----------------------------------------------------------------------------------*/
/*	Tabs Shortcodes
/*-----------------------------------------------------------------------------------*/

if (!function_exists('ct_tabs')) {
	function ct_tabs( $atts, $content = null ) {
		$defaults = array();
		extract(shortcode_atts(array(
			'title'   => 'Tabs Shortcode Title'
	    ), $atts));		
		
		// Extract the tab titles for use in the tab widget.
		preg_match_all( '/tab title="([^\"]+)"/i', $content, $matches, PREG_OFFSET_CAPTURE );
		
		$tab_titles = array();
		if( isset($matches[1]) ){ $tab_titles = $matches[1]; }
		
		$output = '';
		
		$i = 0;

		global $time_id_collapse;

		$time_id_collapse = rand();

		if ( $title != '' ) {
			$output .='<h4>' . $title . '</h4>';
		}	

		if( count($tab_titles) ){
		    $output .= '<div id="ct-tabs-'. $time_id_collapse .'" class="ct-tabs">';
			$output .= '<ul class="nav nav-tabs">';
			
			foreach( $tab_titles as $tab ){
				if ($i == 0) {
					$act = 'class="active"';
					$i++;
				} else $act = '';

				$output .= '<li ' . $act .'><a href="#ct-tab-'. sanitize_title( $tab[0] ) . '-' . $time_id_collapse .'" data-toggle="tab">' . $tab[0] . '</a></li>';

			}		    
		    
		    $output .= '</ul><div class="tab-content">';
		    $output .= do_shortcode( $content );
		    $output .= '</div></div>';		    
		} else {
			$output .= do_shortcode( $content );
		}
		
		return $output;
	}
	add_shortcode( 'ct_tabs', 'ct_tabs' );
}

if (!function_exists('ct_tab')) {
	function ct_tab( $atts, $content = null ) {
		$defaults = array( 'title' => 'Tab' );
		extract( shortcode_atts( $defaults, $atts ) );		

		global $time_id_collapse;
		$output = '';
		$output .= '<div id="ct-tab-'. sanitize_title( $title ) . '-' . $time_id_collapse .'" class="tab-pane">'. do_shortcode( $content ) .'</div>';

		return $output;

	}
	add_shortcode( 'ct_tab', 'ct_tab' );
}

/*
==============================================================================================
						Toggle
==============================================================================================
*/
if (!function_exists('colortheme_toggle')) {
function colortheme_toggle( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'title' => 'Toggle Title',
	), $atts ) );
	
	$toggle_id = rand();

	$output =  '<div id="ct-accordion-'. $toggle_id .'" class="panel-group">';
			$output .= '<div class="panel panel-default">';
					$output .= '<div class="panel-heading">';
						$output .= '<h4 class="panel-title">';
							$output .= '<a class="accordion-toggle" data-toggle="collapse" data-parent="#ct-accordion-'. $toggle_id .'" href="#' . $toggle_id . '">' . $title . '</a>';
						$output .= '</h4>';
					$output .= '</div>';

				$output .= '<div id="' . $toggle_id .'" class="panel-collapse collapse">';
					$output .= '<div class="panel-body">';
						$output .= do_shortcode( $content );
					$output .= '</div>';
				$output .= '</div>';
			$output .= '</div>';
		$output .= '</div>';
		
	return $output;
}
	add_shortcode('ct_toggle', 'colortheme_toggle');
}


?>