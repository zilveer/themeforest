<?php  
//Register "container" content element
vc_map( array(
    "name" => __("Team Carousel", "wish"),
    "description" => __("The one used in the restaurant 'Our Chefs'", 'wish'),
    "controls" => "full",
    "base" => "wish_team_carousel",
    "as_parent" => array('only' => 'wish_team_carousel_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/WRrZZZd.jpg",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(
        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Background Pattern Image", 'wish'),
            "param_name" => "image",
            "value" => "Image",
        ), 






    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Team Member", "wish"),
    "base" => "wish_team_carousel_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_team_carousel'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Top Title", "wish"),
            "value" => __("Our Top Chef", 'wish'),
            "admin_label" => true,
        ), 


        array(
            "type" => "textfield",
            "heading" => __("Name", "wish"),
            "param_name" => "name",
            "description" => __("Name of the team member", "wish"),
            "value" => __("Jane Doe", 'wish'),
            "admin_label" => true,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Subtitle", "wish"),
            "param_name" => "subtitle",
            "description" => __("A subtitle for this Team Member", "wish"),
            "value" => __("Duis aute irure dolor in reprehenderit", 'wish'),
            "admin_label" => false,
        ), 

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Team Member image on the left, should be a large (better use jpg)", 'wish'),
            "param_name" => "image",
            "admin_label" => false,    
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("40", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),


        array(
            "type" => "textfield",
            "heading" => __("Image Size", "wish"),
            "param_name" => "img_size",
            "description" => __("Image Size eg 800x600", "wish"),
            "value" => __("", 'wish'),
            "admin_label" => true,
        ), 


        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        /*Subtitle*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Subtitle Text Font", "wish" ),
            "param_name" => "subtitle_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Subtitle Size", "wish"),
            "param_name" => "subtitle_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Subtitle Text Color", "wish" ),
            "param_name" => "subtitle_color",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        /*Name*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Name Text Font", "wish" ),
            "param_name" => "name_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Name Size", "wish"),
            "param_name" => "name_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Name Text Color", "wish" ),
            "param_name" => "name_color",
            "value" => '#a7781d ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



       
    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Team_Carousel extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'image'   => 'Image',
      ), $atts ) );

      $img = wp_get_attachment_image_src( $image, 'full' );

      if($image == "Image"){
        $imgsrc = plugins_url('images/bg_team_carousel.jpg', __FILE__);
        $img[0] = $imgsrc;
      }

      $output = "<div class='our-chefs parallax-2' style='background-image:url($img[0]);'>
                    <div class='container-fluid our-chefs-carousel'>
                  " . do_shortcode($content) . "        
                    </div>
                </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Team_Carousel_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'title'   => 'Our Top Chef',
            'title_font'    => '',
            'title_size'    => '40',
            'title_color' => '#fff',

            'subtitle'   => 'Duis aute irure dolor in reprehenderit',
            'subtitle_font' => '',
            'subtitle_size' => '20',
            'subtitle_color' => '#fff',

            'details' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#fff',

            'image'     => 'Image',

            'name'      => 'Jane Doe',
            'name_font' => '',
            'name_size' => '20',
            'name_color' => '#a7781d',
            'img_size'  => '',
          ), $atts ) );


        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($subtitle_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $subtitle_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($name_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $name_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        if($img_size == ""){
            $imgsrc = wp_get_attachment_image_src( $image, 'team-carousel-large' );
        }else{
            $imgsrc = wp_get_attachment_image_src( $image, $img_size );
        }

          $imgsrc2 = wp_get_attachment_image_src( $image, 'team-carousel-thumb' );

          if($image == "Image"){
            $imgsrc[0] = plugins_url('images/chef1.jpg', __FILE__);
          }        

          if($image == "Image"){
            $imgsrc2[0] = plugins_url('images/chef-thumb.jpg', __FILE__);
          }  


          $output = "<div class='row no-gutter-6'>
                        <div class='col-lg-6 picture'><img src='{$imgsrc[0]}' class='img-responsive' alt='Team Member'></div>
                        <div class='col-lg-5 info'>
                            <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                            <div class='name-n-pic'><img src='{$imgsrc2[0]}' width='90' height='90' alt=''><span class='name' style='font-family:{$name_font_family};font-size:{$name_size}px;color:{$name_color};'>{$name}</span></div>
                            <div class='heading' style='font-family:{$subtitle_font_family};font-size:{$subtitle_size}px;color:{$subtitle_color};'>{$subtitle}</div>
                            <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                        </div>
                    </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>