  <article>
    <div>
      <div class="video">%VIDEO%</div>
    </div>
    <h3>%TITLE%</h3>
%CONTENT%
%LINK_TEMPLATE%
  </article>

