<?php
if ( !class_exists( 'SWM_contact_info_list' ) ) {
	class SWM_contact_info_list extends WP_Widget {

	    function __construct() {       
	        $widget_ops = array('classname' => '', 'description' => __('Show Address, Phone, Email and Opening Hours ','swmtranslate'));
	        $control_ops = array('width' => 400, 'height' => 350);       
	        parent::__construct('contact-info-list-widget', __('Widget - Contact Info List','swmtranslate'), $widget_ops, $control_ops);
	    }

	    function widget( $args, $instance ) {
	        extract($args);
	        $title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
	        $contact_address = apply_filters( 'widget_text', empty( $instance['contact_address'] ) ? '' : $instance['contact_address'], $instance );        
	        $contact_phone = apply_filters( 'widget_text', empty( $instance['contact_phone'] ) ? '' : $instance['contact_phone'], $instance );
	        $contact_hours = apply_filters( 'widget_text', empty( $instance['contact_hours'] ) ? '' : $instance['contact_hours'], $instance );
			$contact_email = !empty($instance['contact_email']) ? esc_attr($instance['contact_email']) : '' ;
			$contact_email2 = !empty($instance['contact_email2']) ? esc_attr($instance['contact_email2']) : '' ;
						
	        echo $before_widget;
	        if ( !empty( $title ) ) { echo $before_title . $title . $after_title; }

			echo '<div class="contact_info_list">';		

			echo '<ul class="ci_list">';

			if ( !empty( $contact_address ) ) { 
				echo '<li class="ci_address">'.$contact_address.'</li>';					
			}
			if ( !empty( $contact_phone ) ) { 
				echo '<li class="ci_phone">'.$contact_phone.'</li>';
			}
			if ( !empty( $contact_email ) ) { 
				echo '<li class="ci_email"><a href="mailto:'.$contact_email.'">'.$contact_email.'</a>';

				if ( !empty( $contact_email2 ) ) { 
				   echo '<br /><a href="mailto:'.$contact_email2.'">'.$contact_email2.'</a></li>';	
				}
			}
			if ( !empty( $contact_hours ) ) { 
				echo '<li class="ci_hours">'.$contact_hours.'</li>';	
			}

			echo '</ul>';

			echo '</div>';				 
	        
			echo $after_widget;
	    }

	    function update( $new_instance, $old_instance ) {
	        $instance = $old_instance;
	        $instance['title'] = strip_tags($new_instance['title']);
	        $instance['contact_email'] = esc_attr($new_instance['contact_email']);
	        $instance['contact_email2'] = esc_attr($new_instance['contact_email2']);
	        if ( current_user_can('unfiltered_html') ) {
	            $instance['contact_address'] =  $new_instance['contact_address'];
	            $instance['contact_phone'] =  $new_instance['contact_phone'];	
	            $instance['contact_hours'] =  $new_instance['contact_hours'];
	        } else {
	            $instance['contact_address'] = stripslashes( wp_filter_post_kses( addslashes($new_instance['contact_address']) ) );
	            $instance['contact_phone'] = stripslashes( wp_filter_post_kses( addslashes($new_instance['contact_phone']) ) );	
	            $instance['contact_hours'] = stripslashes( wp_filter_post_kses( addslashes($new_instance['contact_hours']) ) );				
	        } 		
	        return $instance;
	    }

	    function form( $instance ) {
	        $instance = wp_parse_args( (array) $instance, array( 
			'title' => 'Contact Info', 
			'contact_address' => '2936 West Lorem Street, [break] Los Angeles, California - 90005', 
			'contact_phone' => 'Phone: ( 888 ) 743 2143 [break] Fax: ( 888 ) 786 6542 ',
			'contact_email' => 'admin@domainname.com',
			'contact_email2' => 'info@domainname.com',
			'contact_hours' => 'Mon-Sat: 8:30 am - 5:00 pm [break] Sun:10:00 am - 12:00 pm'			
			) );
	        $title = strip_tags($instance['title']);
	        $contact_address = esc_textarea($instance['contact_address']);
	        $contact_phone = esc_textarea($instance['contact_phone']);
			$contact_email = esc_attr($instance['contact_email']);
			$contact_email2 = esc_attr($instance['contact_email2']);
			$contact_hours = esc_textarea($instance['contact_hours']);
			
			?>
	        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'swmtranslate'); ?></label><br />
	        <input style="width:99%;"  id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
			
			 <p><label for="<?php echo $this->get_field_id('contact_address'); ?>"><?php _e('Address:', 'swmtranslate'); ?></label><br />
			<textarea  class="widefat" rows="2" cols="20" id="<?php echo $this->get_field_id('contact_address'); ?>" name="<?php echo $this->get_field_name('contact_address'); ?>"><?php echo $contact_address; ?></textarea></p>	
	       
			<p><label for="<?php echo $this->get_field_id('contact_phone'); ?>"><?php _e('Phone:', 'swmtranslate'); ?></label><br />
			<textarea  class="widefat" rows="2" cols="20" id="<?php echo $this->get_field_id('contact_phone'); ?>" name="<?php echo $this->get_field_name('contact_phone'); ?>"><?php echo $contact_phone; ?></textarea></p>
			
			<p><label for="<?php echo $this->get_field_id('contact_email'); ?>"><?php _e('Email 1:', 'swmtranslate'); ?></label><br />
			<input style="width:99%;"  id="<?php echo $this->get_field_id('contact_email'); ?>" name="<?php echo $this->get_field_name('contact_email'); ?>" type="text" value="<?php echo esc_attr($contact_email); ?>" /></p>

			<p><label for="<?php echo $this->get_field_id('contact_email2'); ?>"><?php _e('Email 2:', 'swmtranslate'); ?></label><br />
			<input style="width:99%;"  id="<?php echo $this->get_field_id('contact_email2'); ?>" name="<?php echo $this->get_field_name('contact_email2'); ?>" type="text" value="<?php echo esc_attr($contact_email2); ?>" /></p>

			<p><label for="<?php echo $this->get_field_id('contact_hours'); ?>"><?php _e('Hours:', 'swmtranslate'); ?></label><br />
			<textarea  class="widefat" rows="2" cols="20" id="<?php echo $this->get_field_id('contact_hours'); ?>" name="<?php echo $this->get_field_name('contact_hours'); ?>"><?php echo $contact_hours; ?></textarea></p>
	       
			<?php
	    }
	}
}
add_action( 'widgets_init', create_function( '', 'register_widget( "SWM_contact_info_list" );' ) );
