<?php

return array(
	'featured' => array(
		'label' => __('Featured', 'ait-toolkit'),
		'type' => 'on-off',
		'default' => false,
	),
);