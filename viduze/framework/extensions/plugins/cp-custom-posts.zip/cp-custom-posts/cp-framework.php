<?php 

	/*
	Plugin Name: Cp Custom Posts
	Plugin URI: http://crunchpress.com/cp-framework
	Description: A simple and easy way to test your theme for all the latest WordPress standards and practices. A great theme development tool!
	Author: Nasir Hayat
	Author URI: http://nasirhayat.com
	Version: 1.0
	*/
	
	// constants
	define('CP_PATH_URL', plugin_dir_url(__FILE__),'cp-framework');           // logical location for CP framework
	define('CP_PATH_SER', plugin_dir_path( __FILE__));                          // Physical location for CP framework
	define( 'FW_BE_URL', CP_PATH_URL . 'back-end' );             // Define URL path of framework directory
	define( 'FW_BE_SER', CP_PATH_SER . 'back-end' );                 // Define server path of framework directory

    define('IS_CP_POSTS','Active' );
	// dashboard option
	
	include_once(FW_BE_SER. '/options/portfolio-option.php');							// Register meta fields portfolio post_type
	include_once(FW_BE_SER. '/options/testimonial-option.php');							// Register meta fields testimonial post_type
	//include_once(FW_BE_SER. '/options/price-table-option.php'); 						// Register meta fields	price post_type
	include_once(FW_BE_SER. '/options/timeline.php'); 
	include_once(FW_BE_SER. '/options/team-option.php');
	include_once(FW_BE_SER. '/options/gallery-option.php');
	
		
?>