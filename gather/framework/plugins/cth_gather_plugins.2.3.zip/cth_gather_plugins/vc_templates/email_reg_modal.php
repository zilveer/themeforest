<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $form_title
 * @var $button
 * @var $success_page
 * @var $submit
 * Shortcode class
 * @var $this WPBakeryShortCode_Cth_Email_Registration
 */
$el_class = $form_title = $button = $success_page = $submit = $layout ='';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
//$eventres_multi_price         = get_option('eventres_multi_price','yes' );
$eventres_item_prices_name      = get_option('eventres_item_prices_name' );
$eventres_item_prices           = get_option('eventres_item_prices' );
$eventres_item_quantity_name    = get_option('eventres_item_quantity_name' );
$eventres_item_quantity         = get_option('eventres_item_quantity' );
$eventres_currency              = get_option('eventres_currency' );
$eventres_terms_content         = get_option('eventres_terms_content' );
$eventres_hide_terms            = get_option('eventres_hide_terms' );

$eventres_add_fields            = get_option('eventres_add_fields','' );
$eventres_is_free_email         = get_option('eventres_is_free_email','no' );
// if($eventres_is_free_email == 'yes'){
//     wp_enqueue_script("eventemailres-js", CTH_EVENTRES_DIR_URL . "assets/js/eventfreeemailres.js", array('jquery','gather-validate-js'), false, true);
// }else{
//     wp_enqueue_script("eventemailres-js", CTH_EVENTRES_DIR_URL . "assets/js/eventemailres.js", array('jquery','gather-validate-js'), false, true);
// }
// wp_enqueue_script("eventres-js", CTH_EVENTRES_DIR_URL . "assets/js/eventres.min.js", array('jquery','gather-validate-js'), false, true);

//Main Ajax script 
$ajax_datas = array(
    'url'           => admin_url( 'admin-ajax.php' ),
    'msg_fname'     => get_option('eventres_message_empty_fname' ),
    'msg_lname'     => get_option('eventres_message_empty_lname' ),
    'msg_email'     => get_option('eventres_message_empty_email' ),
    'msg_pass'     => get_option('eventres_message_empty_pass' ),
    'msg_seats'     => get_option('eventres_message_empty_seats' ),
    'msg_agree'     => get_option('eventres_message_empty_agree' ),
    'msg_wait'     => __('Please wait...','cth-gather-plugins'),
);
if(!empty($eventres_add_fields)){
    $ajax_datas['add_fields_validate'] = array();
    foreach ($eventres_add_fields as $key => $add_field) {
        $field_name = str_replace(array(" ","-"), "_", $add_field['name']);
        // echo'<pre>';var_dump($add_field['required']);
        if(isset($add_field['required'])&& $add_field['required'] == 'true'){
            $ajax_datas['add_fields_validate'][$field_name] = "required";
        }
        
    }
}
if($eventres_is_free_email == 'no'){
    $ajax_datas['add_fields_validate']['os0'] = "required";
    $ajax_datas['add_fields_validate']['quantity'] = "required";
}
wp_enqueue_script("eventemailres-js", CTH_EVENTRES_DIR_URL . "assets/js/eventfreeemailres.min.js", array('jquery','gather-validate-js'), false, true);

wp_localize_script( 'eventemailres-js', 'eventres_ajax',  $ajax_datas);
?>
<a class="btn btn-default btn-xl wow zoomIn email_res_modal" data-wow-delay="0.3s" href="#" data-toggle="modal" data-target="#email-register"><?php echo $button;?></a>
<!-- 
 Registration Popup (EMAIL)
 ====================================== -->

<div class="modal fade register-modal" id="email-register" tabindex="-1" role="dialog" aria-labelledby="register-now-label">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title text-center" id="register-now-label"><?php echo esc_attr($form_title );?></h4>
            </div>
            <div class="modal-body">

                <div class="registration-form <?php echo esc_attr($el_class );?>">
                    <?php if(!empty($content)){
                        echo wpb_js_remove_wpautop($content);
                    }?>
                    <form method="POST" target="_top" id="email-registration-form" <?php if(!empty($success_page)) echo 'data-redirect="'.esc_url($success_page ).'"';?>>
                        
                        <div id="eventreg_msg"></div>
                        
                        <?php
                            // to make our script safe, it's a best practice to use nonce on our form to check things out
                            if ( function_exists( 'wp_nonce_field' ) ) 
                                wp_nonce_field( 'gather_event_email_registration_action', 'gather_event_email_registration_nonce' );
                        ?>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label><?php _e('First Name','cth-gather-plugins');?></label>
                                    <input type="text" class="form-control" name="first_name" placeholder="<?php _e('First Name','cth-gather-plugins');?>" required>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label><?php _e('Last Name','cth-gather-plugins');?></label>
                                    <input type="text" class="form-control" name="last_name" placeholder="<?php _e('Last Name','cth-gather-plugins');?>" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><?php _e('Email Address','cth-gather-plugins');?></label>
                            <input type="email" class="form-control" name="email" placeholder="<?php _e('Email Address','cth-gather-plugins');?>" required>
                        </div>
                        <div class="row aditional_fields">
                            <div class="col-sm-12">
                                <?php if(!empty($eventres_add_fields)){
                                    foreach ($eventres_add_fields as $key => $add_field) {
                                        ?>
                                        <div class="form-group aditional_field_<?php echo esc_attr($key );?>">
                                            
                                        <?php if($add_field['type'] == 'text'):?>
                                            <label><?php echo $add_field['label'];?></label>
                                            <input type="text" class="form-control" name="<?php echo str_replace(array(" ","-"), "_", $add_field['name']);?>" value="<?php echo $add_field['value'];?>" placeholder="<?php echo $add_field['label'];?>">
                                        <?php elseif($add_field['type'] =='textarea'):?>
                                            <label><?php echo $add_field['label'];?></label>
                                            <textarea class="form-control" name="<?php echo str_replace(array(" ","-"), "_", $add_field['name']);?>" placeholder="<?php echo $add_field['label'];?>"><?php echo $add_field['value'];?></textarea>
                                        <?php elseif($add_field['type'] =='select'&&!empty($add_field['value'])):?>
                                            <label><?php echo $add_field['label'];?></label>
                                            <select class="form-control" name="<?php echo str_replace(array(" ","-"), "_", $add_field['name']);?>">
                                                <?php foreach ($add_field['value'] as $key => $f_ops) {
                                                    echo '<option value="'.esc_attr($f_ops['value'] ).'">'.esc_attr($f_ops['name'] ).'</option>';
                                                } ?>
                                            </select>
                                        <?php endif;?>
                                        </div>
                                <?php
                                    }
                                } ?>
                            </div>
                        </div>
                        

                    <?php if($eventres_is_free_email == 'no') :?>
                        <div class="row">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label><?php echo __('Choose a ','cth-gather-plugins') . esc_attr($eventres_item_prices_name );?></label>
                                    <?php if($eventres_item_prices && count($eventres_item_prices)): ?>
                                    <select class="form-control" name="os0" required>
                                        <option value=""><?php _e('Choose...','cth-gather-plugins');?></option>
                                    <?php foreach ($eventres_item_prices as $value) { ?>
                                        <option value="<?php echo esc_attr($value['name'] );?>"><?php echo esc_attr($value['name'] ) .' - '. esc_attr($value['value'] ).' '.esc_attr( $eventres_currency );?></option>
                                    <?php } ?>
                                    </select>
                                    <?php else :?>
                                    <select class="form-control" name="os0" required>
                                        <option value=""><?php _e('Choose...','cth-gather-plugins');?></option>
                                        <option value="Default Pass">Default Pass - 99 USD</option>
                                    </select>
                                    <?php endif;?>
                                </div>
                                <input type="hidden" name="on0" value="<?php echo !empty($eventres_item_prices_name)? esc_attr($eventres_item_prices_name ) : 'Pass';?>">  
                            </div>
                            
                            <div class="col-sm-5">
                                <div class="form-group">
                                    <label><?php echo esc_attr($eventres_item_quantity_name );?></label>
                                    <?php if($eventres_item_quantity && count($eventres_item_quantity)): ?>
                                    <select class="form-control" name="item_quantity" required>
                                        <option value=""><?php _e('Choose...','cth-gather-plugins');?></option>
                                    <?php foreach ($eventres_item_quantity as $value) { ?>
                                        <option value="<?php echo esc_attr($value['value'] );?>"><?php echo esc_attr($value['name'] );?></option>
                                    <?php } ?>
                                    </select>
                                    <?php else : ?>
                                    <input type="text" name="item_quantity" value="1">
                                    <?php endif;?>
                                </div>
                            </div>
                        </div>
                    <?php endif;?>
                        <div class="form-group">
                            <div class="checkbox">
                                <label>
                                <?php if($eventres_hide_terms == 'yes') :?>
                                    <input checked="checked" type="checkbox" name="agree" required style="display:none;">
                                <?php else :?>
                                    <input type="checkbox" name="agree" required>
                                <?php endif;?>
                                    <?php echo wp_kses_post( $eventres_terms_content );?>
                                </label>
                            </div>
                        </div>
                        
                        <div class="text-center top-space">
                            <button type="submit" id="reserve-btn" class="btn btn-success btn-lg"><?php echo esc_attr($submit );?></button>
                            
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
