<div id="shortcodelic_sidebars_generator" class="shortcodelic_meta shortcodelicadd_meta shortcodelic_editelement_panel" data-title="<?php _e('Sidebars', 'shortcodelicadd'); ?>">
    <div class="alignleft shortcodelic_options_area">

        <h3><?php _e('Select a sidebar', 'shortcodelicadd'); ?>:</h3>
        <label class="for_select marginhack">
            <span class="for_select">
                <select>
                    <option value=""><?php _e('select a sidebar...','geode'); ?></option>
                    <?php
                        $get_sidebar_options = $GLOBALS['wp_registered_sidebars'];

                        foreach ($get_sidebar_options as $sidebar) {
                            echo '<option value="'.ucwords( $sidebar['id'] ).'">'.ucwords( $sidebar['name'] ).'</option>';
                        }
                    ?>
                </select>
            </span>
        </label>

    </div>

</div><!-- #shortcodelic_sidebars_generator -->