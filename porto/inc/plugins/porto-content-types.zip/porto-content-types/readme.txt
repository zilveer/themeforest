=== Porto Content Types ===

Register content types (portfolio, member, faq) for porto ecommerce theme.

version: 1.0.0