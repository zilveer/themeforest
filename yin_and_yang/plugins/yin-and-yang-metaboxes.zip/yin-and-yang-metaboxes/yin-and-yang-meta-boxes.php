<?php 
/**
 * @category     WordPress_Plugin
 * @package      CMB2
 * @author       WebDevStudios
 * @license      GPL-2.0+
 * @link         http://webdevstudios.com
 *
 * Plugin Name:  Yin and Yang Meta Boxes
 * Plugin URI:   https://github.com/WebDevStudios/CMB2
 * Description:  Creates meta boxes for the Yin and Yang theme.
 * Author:       WebDevStudios
 * Author URI:   http://webdevstudios.com
 * Contributors: WebDevStudios (@webdevstudios / webdevstudios.com)
 *               Justin Sternberg (@jtsternberg / dsgnwrks.pro)
 *               Jared Atchison (@jaredatch / jaredatchison.com)
 *               Bill Erickson (@billerickson / billerickson.net)
 *               Andrew Norcross (@norcross / andrewnorcross.com)
 *
 * Version:      2.1.0
 *
 * Text Domain:  cmb2
 * Domain Path:  languages
 *
 *
 * Released under the GPL license
 * http://www.opensource.org/licenses/gpl-license.php
 *
 * This is an add-on for WordPress
 * http://wordpress.org/
 *
 * **********************************************************************
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * **********************************************************************
 */
 
/**
 * Get the bootstrap!
 */
if ( file_exists( dirname( __FILE__ ) . '/cmb2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/cmb2/init.php';
} elseif ( file_exists( dirname( __FILE__ ) . '/CMB2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/CMB2/init.php';
}

add_action( 'cmb2_init', 'onioneye_register_portfolio_metabox' );
/**
 * Hook in and add a metabox. 
 */
function onioneye_register_portfolio_metabox() {
	
	$prefix = 'onioneye_'; 
	
	$cmb_add_info = new_cmb2_box( array(
		'id'            => $prefix . 'portfolio_metabox',
		'title'         => __('Item Settings', 'cmb2'), 
		'object_types'  => array('portfolio'), // post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
	) );
	
	$cmb_add_info->add_field( array(
		'name' => __('Image Files', 'cmb2'),
		'desc' => __('Upload or add single or multiple images.', 'cmb2'),
		'id' => $prefix . 'image_list',
		'type' => 'file_list',
	    'preview_size' => array(100, 100),	
	) );
	
	$cmb_add_info->add_field( array(
		'name' => __('Client', 'cmb2'),
		'desc' => __('The name of the client for this portfolio item.', 'cmb2'),
		'id' => $prefix . 'client',
		'type' => 'text',	
	) );
	
	$cmb_add_info->add_field( array(
		'name' => __('Item URL', 'cmb2'),
		'desc' => __('The link/URL of this portfolio item.', 'cmb2'),
		'id' => $prefix . 'item_url',
		'type' => 'text',
	) );
	
	$cmb_add_info->add_field( array(
		'name' => __('Publication Date', 'cmb2'),
		'desc' => __('Display the publication date of this post in the live view?', 'cmb2'),
		'id'   => $prefix . 'publication_date',
		'type' => 'checkbox',
	) );
	
	$cmb_add_info->add_field( array(
		'name' => __('Video Embed Code', 'cmb2'),
		'desc' => __('Add the video embed code, generated on the site the video is hosted on, such as YouTube and Vimeo, to have the video displayed on your project page.', 'cmb2'),
		'id'   => $prefix . 'embed_code',
		'type' => 'textarea_small',
		'sanitization_cb' => false,
	) );
	
}