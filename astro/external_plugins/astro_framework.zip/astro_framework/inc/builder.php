<?php


/* Extra Elements - Astro Theme ----------------------------------------------------- */
if (!function_exists('astro_integrateWithVC')) {
    function astro_integrateWithVC() {
        /* Page Elements Removal ----------------------------------------------------- */
        global $prk_astro_options;
        wpb_remove("vc_masonry_media_grid");
        wpb_remove("vc_empty_space");
        wpb_remove("vc_basic_grid");
        wpb_remove("vc_media_grid");
        wpb_remove("vc_masonry_grid");
        wpb_remove("vc_separator");
        wpb_remove("vc_posts_slider");
        wpb_remove("vc_images_carousel");
        wpb_remove("vc_carousel");
        wpb_remove("vc_toggle");
        wpb_remove("vc_cta_button");
        //wpb_remove("vc_gallery");
        wpb_remove("vc_posts_grid");
        wpb_remove("vc_pie");
        //wpb_remove("vc_icon");
        wpb_remove("vc_round_chart");
        wpb_remove("vc_line_chart");
        wpb_remove("vc_button2");
        //wpb_remove("vc_btn");
        wpb_remove("vc_tta_pageable");
        wpb_remove("vc_text_separator");
        wpb_remove("vc_custom_heading");


        $posts_terms=get_terms('category','hide_empty=0');
        $posts_terms_array=array();
        if (count($posts_terms)) {
            foreach ($posts_terms as $inner_term) {
                $posts_terms_array[$inner_term->name] = $inner_term->slug;
            }
        }
        $portfolio_terms=get_terms('pirenko_skills','hide_empty=0');
        $portfolio_terms_array=array();
        if (count($portfolio_terms)) {
            foreach ($portfolio_terms as $inner_term) {
                $portfolio_terms_array[$inner_term->name] = $inner_term->slug;
            }
        }
        $slides_terms=get_terms('pirenko_slide_set','hide_empty=0');
        $slides_terms_array=array();
        if (count($slides_terms)) {
            foreach ($slides_terms as $inner_term) {
                $slides_terms_array[$inner_term->name] = $inner_term->slug;
            }
        }
        $member_terms=get_terms('pirenko_member_group','hide_empty=0');
        $member_terms_array=array();
        if (count($member_terms)) {
            foreach ($member_terms as $inner_term) {
                $member_terms_array[$inner_term->name] = $inner_term->slug;
            }
        }
        $authors_terms=get_users();
        $authors_terms_array=array();
        if (count($authors_terms)) {
            foreach ($authors_terms as $inner_term) {
                $authors_terms_array[$inner_term->user_nicename] = $inner_term->ID;
            }
        }
        $yes_no_arr = array(__('Yes', "js_composer") => "yes",__('No', "js_composer") => "no");
        $target_arr = array(
            esc_html__( 'Same window', 'js_composer' ) => "_self",
            esc_html__( 'New window', 'js_composer' ) => "_blank"
        );
        $add_css_animation = array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'CSS Animation', 'js_composer' ),
            'param_name' => 'css_animation',
            'admin_label' => true,
            'value' => array(
                esc_html__( 'No', 'js_composer' ) => '',
                esc_html__( 'Simple fade', "js_composer") => 'astro_fade_waypoint',
                esc_html__( 'Zoom in', 'js_composer' ) => "appear",
                esc_html__( 'Flash', 'js_composer' ) => "astro_flash",
                esc_html__( 'Shake', 'js_composer' ) => "astro_shake",
                esc_html__( 'Pulse', 'js_composer' ) => "astro_pulse",
                esc_html__( 'Flip in - vertical', 'js_composer' ) => "flipin_x",
                esc_html__( 'Flip in - horizontal', 'js_composer' ) => "flipin_y",
                esc_html__( 'Flip in - horizontal', 'js_composer' ) => "flipin_y",
                esc_html__( 'Top to bottom - Move Down', 'js_composer' ) => 'top-to-bottom',
                esc_html__( 'Top to bottom - Bounce Down', 'js_composer' ) => 'astro_fadeInDownBig',
                esc_html__( 'Bottom to top - Move Up', 'js_composer' ) => 'bottom-to-top',
                esc_html__( 'Bottom to top - Bounce Up', 'js_composer' ) => 'astro_fadeInUpBig',
                esc_html__( 'Left to right', 'js_composer' ) => 'left-to-right',
                esc_html__( 'Left to right - Bounce in from left', 'js_composer' ) => 'astro_fadeInLeftBig',
                esc_html__( 'Right to left', 'js_composer' ) => 'right-to-left',
                esc_html__( 'Right to left - Bounce in from right', 'js_composer' ) => 'astro_fadeInRightBig',
            ),
            'description' => esc_html__( 'Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'js_composer' ),
            "weight" => "0",
        );
        $add_css_delay = array(
            "type" => "textfield",
            "heading" => esc_html__("Animation delay", "js_composer"),
            "param_name" => "css_delay",
            "value" => '0',
            "description" => "Animation delay (in miliseconds).",
            "weight" => "0",
            "dependency" => Array('element' => "css_animation", 'not_empty' => true)
        );

        /* Row Overrides ----------------------------------------------------- */
        vc_remove_param('vc_row', 'parallax_speed_video');
        vc_remove_param('vc_row', 'parallax_speed_bg');
        vc_remove_param('vc_row', 'columns_placement');
        vc_remove_param('vc_row', 'gap');
        vc_remove_param('vc_row', 'equal_height');
        vc_remove_param('vc_row', 'full_height');
        vc_remove_param('vc_row', 'video_bg');
        vc_remove_param('vc_row', 'content_placement');
        vc_remove_param('vc_row', 'video_bg_url');
        vc_remove_param('vc_row', 'video_bg_parallax');
        vc_remove_param('vc_row', 'full_width');
        vc_remove_param('vc_row', 'parallax');
        vc_remove_param('vc_row', 'parallax_image');
        vc_remove_param('vc_row', 'font_color');
        vc_remove_param('vc_row', 'el_class');
        vc_remove_param('vc_row', 'css');

        $composer_patterns = array();
        $composer_patterns["None"] = __('', "js_composer");
        if (is_admin()) {
          //Background Patterns Reader
          $composer_patterns_path=get_template_directory()."/images/patterns/";
            if ( is_dir( $composer_patterns_path ) ) :
              if ( $composer_patterns_dir = opendir( $composer_patterns_path ) ) :

                while ( ( $composer_patterns_file = readdir( $composer_patterns_dir ) ) !== false ) {

                  if( (stristr( $composer_patterns_file, '.png' ) !== false || stristr( $composer_patterns_file, '.jpg' ) !== false) &&  stristr( $composer_patterns_file, '_@2X')===false) {
                    $name = explode(".", $composer_patterns_file);
                    $name = str_replace('.'.end($name), '', $composer_patterns_file);
                    $composer_patterns[$name] = $composer_patterns_file;
                  }
                }
              endif;
            endif;
        }
        vc_add_param("vc_row", array(
            "type" => "dropdown",
            "heading" => __("Background Size", "js_composer"),
            "param_name" => "bk_type",
            "value" => array(__("Boxed look", "js_composer") => "boxed_look", __("Full width", "js_composer") => "full_width"),
            "description" => __("Full width should be only used on Pages with Sections", "js_composer")
        ));
        vc_add_param("vc_row", array(
            "type" => "dropdown",
            "heading" => __("Use normal margin on bottom?", "js_composer"),
            "param_name" => "margin_type",
            "value" => array(
              __('Yes', "js_composer") => "", 
              __('No', "js_composer") => "unmargined",),
            "description" => __("Useful to make this section sit on top of the footer", "js_composer")
        ));
        vc_add_param("vc_row", array(
           "type" => "colorpicker",
           "holder" => "div",
           "class" => "",
           "heading" => __("Background color"),
           "param_name" => "bk_color",
           "value" => __(""),
           "description" => __("Optional")
        ));
        vc_add_param("vc_row", array(
          "type" => "dropdown",
          "heading" => __("Background pattern", "js_composer"),
          "param_name" => "bk_pattern",
          "value" => $composer_patterns,
          "description" => __("Optional - Will override background color", "js_composer")
        ));
        vc_add_param("vc_row", array(
          "type" => "attach_image",
          "heading" => __("Background image", "js_composer"),
          "param_name" => "bk_image",
          "value" => "",
          "description" => __("Optional - Will override background pattern and color", "js_composer")
        ));
        vc_add_param("vc_row", array(
            "type" => "dropdown",
            "heading" => __("Background image position?", "js_composer"),
            "param_name" => "parallax",
            "value" => array(__('Normal display', "js_composer") =>'normal',
            __('Fixed postion', "js_composer") =>'fixed',
            __('Parallax effect', "js_composer") =>'parallel'),
            "description" => __("", "js_composer")
        ));
        vc_add_param("vc_row", array(
           "type" => "colorpicker",
           "holder" => "div",
           "class" => "",
           "heading" => __("Text color"),
           "param_name" => "text_color",
           "value" => __(""),
           "description" => __("Optional")
        ));
        vc_add_param("vc_row", array(
            "type" => "dropdown",
            "heading" => __("Text alignment", "js_composer"),
            "param_name" => "align",
            "value" => array(
              "Left",
              "Center",
              "Right",
            ),
            "description" => __("", "js_composer")
        ));
        vc_add_param("vc_row", $add_css_animation);
        vc_add_param("vc_row", $add_css_delay);
        vc_add_param("vc_row", array(
            "type" => "textfield",
            'heading' => __( 'Extra class name', 'js_composer' ),
            "param_name" => "el_class",
            "value"=> "",
            "description" => ""
        ));

        /* Inner Row Overrides ----------------------------------------------------- */
        vc_remove_param('vc_row_inner', 'content_placement');
        vc_remove_param('vc_row_inner', 'columns_placement');
        vc_remove_param('vc_row_inner', 'gap');
        vc_remove_param('vc_row_inner', 'equal_height');
        vc_remove_param('vc_row_inner', 'css');
        vc_remove_param('vc_row_inner', 'el_class');

        vc_add_param("vc_row_inner", $add_css_animation);
        vc_add_param("vc_row_inner", $add_css_delay);
        vc_add_param("vc_row_inner", array(
            "type" => "textfield",
            'heading' => __( 'Extra class name', 'js_composer' ),
            "param_name" => "el_class",
            "value"=> "",
            "description" => ""
        ));

        /* Column Overrides ----------------------------------------------------- */
        vc_remove_param('vc_column', 'font_color');
        vc_remove_param('vc_column', 'css');
        vc_remove_param('vc_column', 'width');
        vc_remove_param('vc_column', 'offset');

        /* Inner Column Overrides ----------------------------------------------------- */
        vc_remove_param('vc_column_inner', 'font_color');
        vc_remove_param('vc_column_inner', 'css');
        vc_remove_param('vc_column_inner', 'width');
        vc_remove_param('vc_column_inner', 'offset');

        /* Message Box Overrides ----------------------------------------------------- */
        vc_add_param("vc_message", array(
          "type" => "dropdown",
          "heading" => __("Message box type", "js_composer"),
          "param_name" => "color",
          "value" => array(
            __('Informational', "js_composer") => "alert-info", 
            __('Warning', "js_composer") => "alert-block", 
            __('Success', "js_composer") => "alert-success", 
            __('Error', "js_composer") => "alert-error",
          ),
          "weight" => "1",
          "description" => __("Select message type.", "js_composer")
        ));
        vc_add_param("vc_message", $add_css_animation);
        vc_add_param("vc_message", array(
            "type" => "textfield",
            'heading' => __( 'Extra class name', 'js_composer' ),
            "param_name" => "el_class",
            "value"=> "",
            "description" => ""
        ));
        /* Single Image Overrides ----------------------------------------------------- */
        vc_remove_param('vc_single_image', 'onclick');
        vc_remove_param('vc_single_image', 'img_link_target');
        vc_remove_param('vc_single_image', 'link');
        vc_remove_param('vc_single_image', 'style');
        vc_remove_param('vc_single_image', 'el_class');
        vc_remove_param('vc_single_image', 'css');
        vc_add_param("vc_single_image", array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'On click action', 'js_composer' ),
            'param_name' => 'onclick', // due to backward compatibility message_box_shape
            'value' => array(
                esc_html__( 'None', 'js_composer' ) => '',
                esc_html__( 'Open lightbox', 'js_composer' ) => 'img_link_large',
                esc_html__( 'Open custom link', 'js_composer' ) => 'custom_link',
            ),
            'description' => esc_html__( '', 'js_composer' ),
        ));
        vc_add_param("vc_single_image", array(
            'type' => 'href',
            'heading' => esc_html__( 'Image link', 'js_composer' ),
            'param_name' => 'link',
            'description' => esc_html__( 'Enter URL if you want this image to have a link (Note: parameters like "mailto:" are also accepted).', 'js_composer' ),
            'dependency' => array(
                'element' => 'onclick',
                'value' => 'custom_link',
            )
        ));
        vc_add_param("vc_single_image", array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Link Target', 'js_composer' ),
            'param_name' => 'img_link_target',
            'value' => $target_arr,
            'dependency' => array(
                'element' => 'onclick',
                'value' => array( 'custom_link' ),
            ),
        ));
        vc_add_param("vc_single_image", $add_css_animation);
        vc_add_param("vc_single_image", array(
            "type" => "textfield",
            'heading' => esc_html__( 'Extra class name', 'js_composer' ),
            "param_name" => "el_class",
            "value"=> "",
            "description" => "",
            "weight" => "0"
        ));

        vc_remove_param('vc_gallery', 'onclick');
        vc_remove_param('vc_gallery', 'css');
        //vc_remove_param('vc_gallery', 'border_width');
        vc_add_param("vc_gallery", array(
          'type' => 'dropdown',
          'heading' => __( 'On click', 'js_composer' ),
          'param_name' => 'onclick',
          'value' => array(
            __( 'Open lightbox', 'js_composer' ) => 'link_image',
            __( 'Do nothing', 'js_composer' ) => 'link_no',
            //__( 'Open custom link', 'js_composer' ) => 'custom_link'
          ),
          'description' => __( 'Define action for onclick event if needed.', 'js_composer' )
        ));

        /* Tour Overrides ---------------------------------------------------------- */
        vc_remove_param('vc_tta_tour', 'style');
        vc_remove_param('vc_tta_tour', 'shape');
        vc_remove_param('vc_tta_tour', 'color');
        vc_remove_param('vc_tta_tour', 'gap');
        vc_remove_param('vc_tta_tour', 'spacing');
        vc_remove_param('vc_tta_tour', 'pagination_style');
        vc_remove_param('vc_tta_tour', 'pagination_color');
        vc_remove_param('vc_tta_tour', 'css');
        vc_remove_param('vc_tta_tour', 'no_fill_content_area');
        //vc_remove_param('vc_tta_tour', 'tab_position');
        //vc_remove_param('vc_tta_tour', 'alignment');
        vc_remove_param('vc_tta_tour', 'controls_size');
        //vc_remove_param('vc_tta_tour', 'active_section');

        /* Progress Bar Overrides ---------------------------------------------------------- */
        vc_remove_param('vc_progress_bar', 'options');
        vc_remove_param('vc_progress_bar', 'el_class');
        vc_add_param("vc_progress_bar", array(
        "type" => "colorpicker",
        "heading" => __("Bars custom color", "js_composer"),
        "param_name" => "custombgcolor",
        "description" => __("Select custom color for bars.", "js_composer"),
        "dependency" => Array('element' => "bgcolor", 'value' => array('custom'))
        ));
        vc_add_param("vc_progress_bar", array(
        "type" => "colorpicker",
        "heading" => __("Bars custom background color", "js_composer"),
        "param_name" => "custombgcolor_back",
        "description" => __("Select custom background color for bars - leave blank for theme default value", "js_composer"),
        ));
        vc_add_param("vc_progress_bar", array(
            "type" => "textfield",
            "heading" => __('Bars bottom margin', 'js_composer'),
            "param_name" => "margin_bottom_2", 
            "value" => "40px",
            "description" => __("Value in px.", "js_composer")
        ));
        vc_add_param("vc_progress_bar", array(
        "type" => "textfield",
        "heading" => __("Extra class name", "js_composer"),
        "param_name" => "el_class",
        "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer")
        ));

        //SPACER
  function prkwp_spacer_func( $atts ) {
     extract( shortcode_atts( array(
        'size' => ''
     ), $atts ) );
   
     return do_shortcode('[pirenko_spacer size="'.$size.'"][/pirenko_spacer]');
  }
  add_shortcode( 'prkwp_spacer', 'prkwp_spacer_func' );

  wpb_map( array(
     "name" => __("Vertical Spacer","astro_lang"),
     "base" => "prkwp_spacer",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-toggle-small-expand",
     "category" => __('Content',"astro_lang"),
     "description" => __('Control vertical space between elements', 'js_composer'),
     "params" => array(
      array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Vertical size in pixels (use negative values to pull elements up)","astro_lang"),
           "param_name" => "size",
           "value" => "10",
           "description" => "This element creates a vertical space between adjacent elements."
        ),
     )
  ));

        //STYLED TITLE
  function prkwp_styled_title_func( $atts ) {
     extract( shortcode_atts( array(
        'prk_in' => '',
        'align' => '',
        'text_color' => '',
        'title_size' => '',
        'use_italic' => '',
        'show_lines' => '',
        'astro_show_line' => '',
        'unmargined' => ''
     ), $atts ) );
   
     return do_shortcode('[prk_styled_title align="'.strtolower($align).'" text_color="'.strtolower($text_color).'" unmargined="'.strtolower($unmargined).'" title_size="'.strtolower($title_size).'" astro_show_line="'.strtolower($astro_show_line).'" use_italic="'.strtolower($use_italic).'"]'.$prk_in.'[/prk_styled_title]');
  }
  add_shortcode( 'prkwp_styled_title', 'prkwp_styled_title_func' );

  wpb_map( array(
     "name" => __("Styled title","astro_lang"),
     "base" => "prkwp_styled_title",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-layer-shape-text",
     "category" => __('Content',"astro_lang"),
     "description" => __('Display theme like titles', 'js_composer'),
     "params" => array(
      array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Text","astro_lang"),
           "param_name" => "prk_in",
           "value" => "",
           "description" => ""
        ),
      array(
            "type" => "dropdown",
            "heading" => __("Alignment", "js_composer"),
            "param_name" => "align",
            "value" => array("Left","Center"),
            "description" => ""
        ),
      array(
           "type" => "colorpicker",
           "holder" => "div",
           "class" => "",
           "heading" => __("Color","astro_lang"),
           "param_name" => "text_color",
           "value" => "",
           "description" => __("Optional - If blank the theme default headings color will be used","astro_lang")
        ),
      array(
            "type" => "dropdown",
            "heading" => __("Title size", "js_composer"),
            "param_name" => "title_size",
            "value" => array("Large","Medium","Small"),
            "description" => ""
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Italic font style?", "js_composer"),
            "param_name" => "use_italic",
            "value" => array("No","Yes"),
            "description" => ""
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Show line under title?", "js_composer"),
            "param_name" => "astro_show_line",
            "value" => array("Yes","No"),
            "description" => ""
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Zero margin after title?", "js_composer"),
            "param_name" => "unmargined",
            "value" => array(__('No', "js_composer") => "",__('Yes', "js_composer") => "unmargined"),
            "description" => __("This is usefull for single big headings.", "js_composer")
        )      
     )
  ));
/* Separator (Divider)
---------------------------------------------------------- */
vc_map( array(
  "name"    => __("Separator", "js_composer"),
  "base"    => "prk_line",
  'icon'    => 'icon-wpb-ui-separator',
  "show_settings_on_create" => false,
  "category"  => __('Content', 'js_composer'),
  "description" => __('Horizontal separator line', 'js_composer'),
  "controls"  => 'popup_delete',
  "params" => array(
    array(
      "type" => "textfield",
      "heading" => __("Extra class name", "js_composer"),
      "param_name" => "el_class",
      "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer")
    )
    )
) );
//BLOCKQUOTE
  function bquote_func( $atts ) {
     extract( shortcode_atts( array(
        'prk_in' => '',
        'author' => '',
        'after_author' => '',
        'type' => ''
     ), $atts ) );
    if ($type=="") {
        $type="plain";
    }
     return do_shortcode("<div class='wpb_content_element'>[pirenko_blockquote author='{$author}' after_author='{$after_author}' type='{$type}']{$prk_in}[/pirenko_blockquote]</div>");
  }
  add_shortcode( 'bquote', 'bquote_func' );

  wpb_map( array(
     "name" => __("Blockquote","astro_lang"),
     "base" => "bquote",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-quote-prk",
     "category" => __('Content',"astro_lang"),
     "description" => __('Stylish quotes that stand out', 'js_composer'),
     "params" => array(
      array(
            "type" => "dropdown",
            "heading" => __("Blockquote type", "js_composer"),
            "param_name" => "type",
             "value" => array(
              __('Plain', "js_composer") => "plain", 
              __('Colored background', "js_composer") => "colored_background"
            ),
            "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Author","astro_lang"),
           "param_name" => "author",
           "value" => __("","astro_lang"),
           "description" => __("","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("After author text","astro_lang"),
           "param_name" => "after_author",
           "value" => __("","astro_lang"),
           "description" => __("Optional","astro_lang")
        ),
        array(
           "type" => "textarea",
           "holder" => "div",
           "class" => "",
           "heading" => __("Content","astro_lang"),
           "param_name" => "prk_in",
           "value" => __("","astro_lang"),
           "description" => __("","astro_lang")
        ),
     )
  ));

 //SERVICE
  function prkwp_service_func( $atts ) {
     extract( shortcode_atts( array(
        'prk_in' => '',
        'name' => '',
        'align' => '',
        'image' => '',
        'bk_color' => '',
        'link' => '',
        'serv_image' => '',
        'link_text' => ''
     ), $atts ) );
     if ($align=="center")
        $align="prk_service_center";
      else
        $align="prk_service_left";
    $image_attributes = wp_get_attachment_image_src( $serv_image,'full' );
     return do_shortcode('[prk_service name="'.$name.'" align="'.$align.'" image="'.$image.'" serv_image="'.$image_attributes[0].'" link="'.$link.'" bk_color="'.$bk_color.'" link_text="'.$link_text.'"]'.$prk_in.'[/prk_service]');
  }
  add_shortcode( 'prkwp_service', 'prkwp_service_func' );
  wpb_map( array(
     "name" => __("Service","astro_lang"),
     "base" => "prkwp_service",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-call-to-action",
     "category" => __('Content',"astro_lang"),
     "description" => __('Easy information blocks with images', 'js_composer'),
     "params" => array(
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Title","astro_lang"),
           "param_name" => "name",
           "value" => "",
           "description" => ""
        ),
        array(
          "type" => "attach_image",
          "heading" => __("Service image", "js_composer"),
          "param_name" => "serv_image",
          "value" => "",
          "description" => __("Select image from media library. Has priority over icon class value below.", "js_composer")
    ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Icon class","astro_lang"),
           "param_name" => "image",
           "value" => "",
           "description" => __("Example: icon-video. For a complete list open the icons_1.pdf located file inside the documentation folder.","astro_lang")
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Alignment", "js_composer"),
            "param_name" => "align",
            "value" => array(
              __('Left', "js_composer") => "left", 
              __('Center', "js_composer") => "center"
            ),
            "description" => ""
        ),
        array(
           "type" => "textarea",
           "holder" => "div",
           "class" => "",
           "heading" => __("Content","astro_lang"),
           "param_name" => "prk_in",
           "value" => "",
           "description" => ""
        ),
        array(
           "type" => "colorpicker",
           "holder" => "div",
           "class" => "",
           "heading" => __("Background color","astro_lang"),
           "param_name" => "bk_color",
           "value" => "",
           "description" => __("Optional","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("URL link","astro_lang"),
           "param_name" => "link",
           "value" => "",
           "description" => __("Optional","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("URL link text","astro_lang"),
           "param_name" => "link_text",
           "value" => "",
           "description" => __("Leave blank for theme default Read More text.","astro_lang")
        )
     )
  ) );

//THEME BUTTON
  function theme_button_func( $atts ) {
    extract( shortcode_atts( array(
        'prk_in' => '',
        'type' => '',
        'window' => '',
        'link' => '',
      ), $atts ) );
      if ($window=="No")
        $window="_self";
      else
        $window="_blank";
   
     return do_shortcode('[theme_button type="'.$type.'" link="'.$link.'" window="'.$window.'"]'.$prk_in.'[/theme_button]');
  }
  add_shortcode( 'prk_wp_theme_button', 'theme_button_func' );

  wpb_map( array(
     "name" => __("Theme Button","astro_lang"),
     "base" => "prk_wp_theme_button",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-ui-button",
     "category" => __('Content',"astro_lang"),
     "description" => __('Buttons with the theme default styling', 'js_composer'),
     //'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
     //'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
     "params" => array(
      array(
            "type" => "dropdown",
            "heading" => __("Button type", "js_composer"),
            "param_name" => "type",
             "value" => array(
              __('Large Theme Button', "js_composer") => "theme_button large", 
              __('Medium Theme Button', "js_composer") => "theme_button medium",
              __('Small Theme Button', "js_composer") => "theme_button small", 
              __('Tiny Theme Button', "js_composer") => "theme_button tiny",
              __('Large Theme Button - Inverted Colors', "js_composer") => "theme_button_inverted large", 
              __('Medium Theme Button - Inverted Colors', "js_composer") => "theme_button_inverted medium",
              __('Small Theme Button - Inverted Colors', "js_composer") => "theme_button_inverted small", 
              __('Tiny Theme Button - Inverted Colors', "js_composer") => "theme_button_inverted tiny",
            ),
            "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Button text","astro_lang"),
           "param_name" => "prk_in",
           "value" => __("","astro_lang"),
           "description" => __("","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Link","astro_lang"),
           "param_name" => "link",
           "value" => __("","astro_lang"),
           "description" => __("","astro_lang")
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Open link in a new window?", "js_composer"),
            "param_name" => "window",
            "value" => array("No","Yes"),
            "description" => __("", "js_composer","astro_lang")
        )
     )
  ));

//THEME SLIDER
  wpb_map( array(
     "name" => __("Theme slider","astro_lang"),
     "base" => "prk_slider",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-images-stack",
     "description" => __('Display theme slides using Flexslider', 'js_composer'),
     "category" => __('Content',"astro_lang"),
     "params" => array(
      array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Groups filter using slug(s) - comma separated ","astro_lang"),
           "param_name" => "category",
           "value" => "",
           "description" => __("Optional - leave blank for all","astro_lang")
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Autoplay slider?", "js_composer"),
            "param_name" => "autoplay",
            "value" => $yes_no_arr,
            "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Slider delay","astro_lang"),
           "param_name" => "delay",
           "value" => "",
           "description" => __("In miliseconds - If blank the theme default value will be used","astro_lang")
        )
     )
  ) );
  
/* Gallery/Slideshow
---------------------------------------------------------- */
vc_map( array(
  "name" => __("Theme Image Gallery", "js_composer"),
  "description" => __('Multiple images from Media Library', 'js_composer'),
  "base" => "pirenko_gallery",
  "icon" => "icon-wpb-images-stack",
  "category" => __('Content', 'js_composer'),
  "params" => array(
    array(
      "type" => "dropdown",
      "heading" => __("Gallery type", "js_composer"),
      "param_name" => "type",
      "value" => array(
        __("Masonry", "js_composer") => "masonry", 
        __("Grid (rectangles)", "js_composer") => "grid", 
        __("Grid (squares)", "js_composer") => "squares",
        ),
      "description" => __("Select grid type.", "js_composer")
    ),
    array(
       "type" => "textfield",
       "holder" => "div",
       "class" => "",
       "heading" => __("Thumbnails margin","astro_lang"),
       "param_name" => "thumbs_mg",
       "value" => "",
       "description" => __("Default value is 10","astro_lang")
    ),
    array(
            "type" => "dropdown",
            "heading" => __("Open lightbox when images are clicked?", "js_composer"),
            "param_name" => "clickable",
            "value" => $yes_no_arr,
            "description" => ""
        ),
    array(
      "type" => "attach_images",
      "heading" => __("Images", "js_composer"),
      "param_name" => "images",
      "value" => "",
      "description" => __("Select images from media library.", "js_composer")
    ),
    array(
      "type" => "textfield",
      "heading" => __("Extra class name", "js_composer"),
      "param_name" => "el_class",
      "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer")
    )
  )
) );
  
  //CAROUSEL
  function prkwp_carousel_func( $atts ) {
     extract( shortcode_atts( array(
        'images' => '',
        'title' => '',
     ), $atts ) );
    $images_output="";
    $arr=explode(",",$images);
    if (count($arr)>0) {
      foreach ($arr as $single) {
        $image_attributes = wp_get_attachment_image_src( $single,'full' );
        $images_output.='[prk_carousel_single path="'.$image_attributes[0].'"][/prk_carousel_single]';
      }
    }
    return do_shortcode('[prk_carousel title="'.$title.'"]'.$images_output.'[/prk_carousel]');
  }
  add_shortcode( 'prkwp_carousel', 'prkwp_carousel_func' );
  wpb_map( array(
     "name" => __("Images Carousel","astro_lang"),
     "base" => "prkwp_carousel",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-images-carousel",
     "description" => __('Animated carousel with images', 'js_composer'),
     "category" => __('Content',"astro_lang"),
     "params" => array(
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Title","astro_lang"),
           "param_name" => "title",
           "value" => __("","astro_lang"),
           "description" => __("","astro_lang")
        ),
        array(
          "type" => "attach_images",
          "heading" => __("Images", "js_composer"),
          "param_name" => "images",
          "value" => "",
          "description" => __("Select images from media library.", "js_composer")
    )
     )
  ));


  //PRICING TALBES
  function prkwp_price_table_func( $atts ) {
     extract( shortcode_atts( array(
        'prk_in' => '',
        'featured' => '',
        'header' => '',
        'color' => '',
        'price' => '',
        'under_price' => '',
        'button_label' => '',
        'button_link' => '',
     ), $atts ) );
    $lines_output="<ul>";
    $prk_tweaked = str_replace(", ", "prkwrdoff", $prk_in);
    $arr=explode(",",$prk_tweaked);
    if (count($arr)>0) 
    {
      foreach ($arr as $single) {
        $lines_output.='<li>'.str_replace("prkwrdoff", ", ",$single).'</li>';
      }
    }
    $lines_output.="</ul>";
     return do_shortcode('[prk_price_table header="'.$featured.'" featured="'.$header.'" color="'.$color.'" price="'.$price.'" under_price="'.$under_price.'" button_label="'.$button_label.'" button_link="'.$button_link.'"]'.$lines_output.'[/prk_price_table]');
  }
  add_shortcode( 'prkwp_price_table', 'prkwp_price_table_func' );
  
  wpb_map( array(
     "name" => __("Pricing table","astro_lang"),
     "base" => "prkwp_price_table",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-prk-table",
     "category" => __('Content',"astro_lang"),
     "description" => __('Information tables with multiple content fields', 'js_composer'),
     "params" => array(
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Title","astro_lang"),
           "param_name" => "featured",
           "value" => "",
           "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Header/featured text","astro_lang"),
           "param_name" => "header",
           "value" => "",
           "description" => __("Optional - Will be displayed under the title","astro_lang")
        ),
        array(
           "type" => "colorpicker",
           "holder" => "div",
           "class" => "",
           "heading" => __("Color","astro_lang"),
           "param_name" => "color",
           "value" => "",
           "description" => __("Optional - If blank the theme active color will be used","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Price text","astro_lang"),
           "param_name" => "price",
           "value" => "",
           "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Under price text","astro_lang"),
           "param_name" => "under_price",
           "value" => "",
           "description" => __("Example: per month","astro_lang")
        ),
        array(
           "type" => "exploded_textarea",
           "holder" => "div",
           "class" => "",
           "heading" => __("Description text","astro_lang"),
           "param_name" => "prk_in",
           "value" => "",
           "description" => __("Enter descriptions for this table here. Divide them with linebreaks (Enter).","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Button text","astro_lang"),
           "param_name" => "button_label",
           "value" => "",
           "description" => __("Leave blank if no button is needed","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Button URL","astro_lang"),
           "param_name" => "button_link",
           "value" => "",
           "description" => __("Leave blank if no button is needed","astro_lang")
        )
     )
  ) );

 //TEAM MEMBERS
  wpb_map( array(
     "name" => __("Team members","astro_lang"),
     "base" => "prk_members",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-prk-user",
     "description" => __('Show team members', 'js_composer'),
     "category" => __('Content',"astro_lang"),
     "params" => array(
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Teams filter using slug(s) - comma separated ","astro_lang"),
           "param_name" => "category",
           "value" => "",
           "description" => __("Optional - leave blank for all","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Number of members per column","astro_lang"),
           "param_name" => "columns",
           "value" => "3",
           "description" => ""
        )
     )
  ) );


  //LATEST PORTFOLIO
  wpb_map( array(
     "name" => __("Latest Portfolio","astro_lang"),
     "base" => "pirenko_last_portfolios",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-layerslider",
     "description" => __('Show portfolio entries', 'js_composer'),
     "category" => __('Content',"astro_lang"),
     "params" => array(
        array(
            "type" => "dropdown",
            "heading" => __("Block type?", "js_composer"),
            "param_name" => "layout_type_folio",
            "value" => array(__("Grid", "js_composer") => "grid", __("Masonry", "js_composer") => "masonry"),
            "description" => ""
          ),
          array(
            "type" => "dropdown",
            "heading" => __("Show skills information on each post?", "js_composer"),
            "param_name" => "astro_show_skills",
            "value" => $yes_no_arr,
            "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Skills filter using slug(s) - comma separated ","astro_lang"),
           "param_name" => "cat_filter",
           "value" => "",
           "description" => __("Optional - leave blank for all","astro_lang")
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Show filter above thumbnails?", "js_composer"),
            "param_name" => "show_filter",
            "value" => $yes_no_arr,
            "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Items number","astro_lang"),
           "param_name" => "items_number",
           "value" => "",
           "description" => __("Optional - default value is 9","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Columns number","astro_lang"),
           "param_name" => "cols_number",
           "value" => "3",
           "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Thumbnails margin","astro_lang"),
           "param_name" => "thumbs_mg",
           "value" => "",
           "description" => __("Default value is 10","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("View portfolio button text","astro_lang"),
           "param_name" => "button_label",
           "value" => "",
           "description" => __("Leave blank if no button is needed","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("View portfolio button URL","astro_lang"),
           "param_name" => "button_url",
           "value" => "",
           "description" => __("Leave blank if no button is needed","astro_lang")
        )
     )
  ) );
  
  //LATEST POSTS
  wpb_map( array(
     "name" => __("Latest Posts","astro_lang"),
     "base" => "pirenko_last_posts",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-vc_carousel",
     "description" => __('Show blog entries', 'js_composer'),
     "category" => __('Content',"astro_lang"),
     "params" => array(
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Category filter using slug(s) - comma separated ","astro_lang"),
           "param_name" => "cat_filter",
           "value" => "",
           "description" => __("Optional - leave blank for all","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Items number","astro_lang"),
           "param_name" => "items_number",
           "value" => "3",
           "description" => __("","astro_lang")
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Rows number","astro_lang"),
           "param_name" => "rows_number",
           "value" => "1",
           "description" => ""
        )
     )
  ) );

  //COMMENTS
  wpb_map( array(
     "name" => __("Comments","astro_lang"),
     "base" => "pirenko_comments",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-prk-comments",
     "description" => __('Display comments from users', 'js_composer'),
     "category" => __('Content',"astro_lang"),
     "params" => array(
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Title","astro_lang"),
           "param_name" => "title",
           "value" => "",
           "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Number of comments","astro_lang"),
           "param_name" => "items_number",
           "value" => "",
           "description" => ""
        )
     )
  ));

  //SITEMAP
  wpb_map( array(
     "name" => __("Sitemap","astro_lang"),
     "base" => "prk_sitemap",
     "class" => "astro_scodes_editor",
     "icon" => "icon-wpb-prk-sitemap",
     "description" => __('Complete sitemap with all post types', 'js_composer'),
     "category" => __('Content',"astro_lang"),
     "params" => array(
      array(
            "type" => "dropdown",
            "heading" => __("Show Pages?", "js_composer"),
            "param_name" => "show_pages",
            "value" => $yes_no_arr,
            "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Title for Pages","astro_lang"),
           "param_name" => "txt_pages",
           "value" => "",
           "description" => ""
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Show blog categories?", "js_composer"),
            "param_name" => "show_blog_cats",
            "value" => $yes_no_arr,
            "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Title for blog categories","astro_lang"),
           "param_name" => "txt_blog_cats",
           "value" => "",
           "description" => ""
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Show blog posts?", "js_composer"),
            "param_name" => "show_posts",
            "value" => $yes_no_arr,
            "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Title for blog posts","astro_lang"),
           "param_name" => "txt_posts",
           "value" => "",
           "description" => ""
        ),
        array(
            "type" => "dropdown",
            "heading" => __("Show portfolio posts?", "js_composer"),
            "param_name" => "show_port_posts",
            "value" => $yes_no_arr,
            "description" => ""
        ),
        array(
           "type" => "textfield",
           "holder" => "div",
           "class" => "",
           "heading" => __("Title for portfolio posts","astro_lang"),
           "param_name" => "txt_port_posts",
           "value" => "",
           "description" => ""
        )
     )
  ));

    }
}



