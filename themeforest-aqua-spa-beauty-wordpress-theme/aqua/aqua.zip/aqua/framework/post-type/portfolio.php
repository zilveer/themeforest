<?php
// Register Custom Post Type
function tb_add_post_type_portfolio() {
    // Register taxonomy
    $labels = array(
            'name'              => _x( 'Portfolio Category', 'taxonomy general name', 'jwsthemes' ),
            'singular_name'     => _x( 'Portfolio Category', 'taxonomy singular name', 'jwsthemes' ),
            'search_items'      => __( 'Search Portfolio Category', 'jwsthemes' ),
            'all_items'         => __( 'All Portfolio Category', 'jwsthemes' ),
            'parent_item'       => __( 'Parent Portfolio Category', 'jwsthemes' ),
            'parent_item_colon' => __( 'Parent Portfolio Category:', 'jwsthemes' ),
            'edit_item'         => __( 'Edit Portfolio Category', 'jwsthemes' ),
            'update_item'       => __( 'Update Portfolio Category', 'jwsthemes' ),
            'add_new_item'      => __( 'Add New Portfolio Category', 'jwsthemes' ),
            'new_item_name'     => __( 'New Portfolio Category Name', 'jwsthemes' ),
            'menu_name'         => __( 'Portfolio Category', 'jwsthemes' ),
    );

    $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'portfolio_category' ),
    );
    if(function_exists('custom_reg_taxonomy')) {
        custom_reg_taxonomy( 'portfolio_category', array( 'portfolio' ), $args );
    }
    //Register tags
    $labels = array(
            'name'              => _x( 'Portfolio Tag', 'taxonomy general name', 'jwsthemes' ),
            'singular_name'     => _x( 'Portfolio Tag', 'taxonomy singular name', 'jwsthemes' ),
            'search_items'      => __( 'Search Portfolio Tag', 'jwsthemes' ),
            'all_items'         => __( 'All Portfolio Tag', 'jwsthemes' ),
            'parent_item'       => __( 'Parent Portfolio Tag', 'jwsthemes' ),
            'parent_item_colon' => __( 'Parent Portfolio Tag:', 'jwsthemes' ),
            'edit_item'         => __( 'Edit Portfolio Tag', 'jwsthemes' ),
            'update_item'       => __( 'Update Portfolio Tag', 'jwsthemes' ),
            'add_new_item'      => __( 'Add New Portfolio Tag', 'jwsthemes' ),
            'new_item_name'     => __( 'New Portfolio Tag Name', 'jwsthemes' ),
            'menu_name'         => __( 'Portfolio Tag', 'jwsthemes' ),
    );

    $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'portfolio_tag' ),
    );
    
    if(function_exists('custom_reg_taxonomy')) {
        custom_reg_taxonomy( 'portfolio_tag', array( 'portfolio' ), $args );
    }
    
    //Register post type portfolio
    $labels = array(
            'name'                => _x( 'Portfolio', 'Post Type General Name', 'jwsthemes' ),
            'singular_name'       => _x( 'Portfolio Item', 'Post Type Singular Name', 'jwsthemes' ),
            'menu_name'           => __( 'Portfolio', 'jwsthemes' ),
            'parent_item_colon'   => __( 'Parent Item:', 'jwsthemes' ),
            'all_items'           => __( 'All Items', 'jwsthemes' ),
            'view_item'           => __( 'View Item', 'jwsthemes' ),
            'add_new_item'        => __( 'Add New Item', 'jwsthemes' ),
            'add_new'             => __( 'Add New', 'jwsthemes' ),
            'edit_item'           => __( 'Edit Item', 'jwsthemes' ),
            'update_item'         => __( 'Update Item', 'jwsthemes' ),
            'search_items'        => __( 'Search Item', 'jwsthemes' ),
            'not_found'           => __( 'Not found', 'jwsthemes' ),
            'not_found_in_trash'  => __( 'Not found in Trash', 'jwsthemes' ),
    );
    $args = array(
            'label'               => __( 'Portfolio', 'jwsthemes' ),
            'description'         => __( 'Portfolio Description', 'jwsthemes' ),
            'labels'              => $labels,
            'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', 'post-formats', ),
            'taxonomies'          => array( 'portfolio_category', 'portfolio_tag' ),
            'hierarchical'        => true,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'menu_icon'           => 'dashicons-welcome-view-site',
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'page',
    );
    
    if(function_exists('custom_reg_post_type')) {
        custom_reg_post_type( 'portfolio', $args );
    }
    
}

// Hook into the 'init' action
add_action( 'init', 'tb_add_post_type_portfolio', 0 );
