<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Restaurant Menu 2", "wish"),
    "description" => __("Restaurant Menu with dishes", 'wish'),
    "controls" => "full",
    "base" => "wish_restaurant_menu2",
    "as_parent" => array('only' => 'wish_restaurant_menu2_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/6XfI79C.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Heading", "wish"),
            "param_name" => "title",
            "description" => __("Staff Title and Position", "wish"),
            "value" => __("Restaurant Menu", 'wish'),
            "admin_label" => false,
        ), 

         array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Perfect food and drinks", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),


         /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("50", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#431110', //Default Red color
            "description" => __( "Choose the background color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Menu Item", "wish"),
    "base" => "wish_restaurant_menu2_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_restaurant_menu2'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(
        array(
            "type" => "dropdown",
            "heading" => __("Header section position", "wish"),
            "param_name" => "position",
            "description" => __("Position of header section (Left/Right).", "wish"),
            "value" => array( 
                              "Left"     => "left",
                              "Right"     => "right",
                            ),
            "std"       =>   12,
        ),
        array(
            "type" => "textfield",
            "heading" => __("Heading", "wish"),
            "param_name" => "title",
            "description" => __("Staff Title and Position", "wish"),
            "value" => __("Sandwich and toast", 'wish'),
            "admin_label" => false,
        ), 

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,    
        ),

        array(
            "type" => "textfield",
            "heading" => __("Name Of Dish 1", "wish"),
            "param_name" => "name_1",
            "description" => __("NAME OF DISH 1", "wish"),
            "value" => __("NAME OF DISH", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Dish 1 Details", 'wish'),
            "param_name" => "details_1",
            "value" => __("Lorem ipsum dolor", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Price Of Dish 1", "wish"),
            "param_name" => "price_1",
            "description" => __("PRICE OF DISH 1", "wish"),
            "value" => __("10:00", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Name Of Dish 2", "wish"),
            "param_name" => "name_2",
            "description" => __("NAME OF DISH 2", "wish"),
            "value" => __("NAME OF DISH", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Dish 2 Details", 'wish'),
            "param_name" => "details_2",
            "value" => __("Lorem ipsum dolor", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),
        array(
            "type" => "textfield",
            "heading" => __("Price Of Dish 2", "wish"),
            "param_name" => "price_2",
            "description" => __("PRICE OF DISH 2", "wish"),
            "value" => __("10:00", 'wish'),
            "admin_label" => false,
        ),
        
        array(
            "type" => "textfield",
            "heading" => __("Name Of Dish 3", "wish"),
            "param_name" => "name_3",
            "description" => __("NAME OF DISH 3", "wish"),
            "value" => __("NAME OF DISH", 'wish'),
            "admin_label" => false,
        ),

         array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Dish 3 Details", 'wish'),
            "param_name" => "details_3",
            "value" => __("Lorem ipsum dolor", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),

         array(
            "type" => "textfield",
            "heading" => __("Price Of Dish 3", "wish"),
            "param_name" => "price_3",
            "description" => __("PRICE OF DISH 3", "wish"),
            "value" => __("10:00", 'wish'),
            "admin_label" => false,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("24", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Name*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Name Text Font", "wish" ),
            "param_name" => "name_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Name Size", "wish"),
            "param_name" => "name_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Name Text Color", "wish" ),
            "param_name" => "name_color",
            "value" => '#CF6728 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("12", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#ABA899 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        /*Price*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Price Text Font", "wish" ),
            "param_name" => "price_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Price Size", "wish"),
            "param_name" => "price_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Price Text Color", "wish" ),
            "param_name" => "price_color",
            "value" => '#CF6728 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Restaurant_Menu2 extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title' => 'Restaurant Menu',
            'title_font'    => '',
            'title_size'    => '50',
            'title_color' => '#fff',

            'details' => 'Perfect food and drinks',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#fff',

            'bgcolor'   => '#431110'  
          ), $atts ) );

        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


      $output = "<div class='restaurant-menu-2'>
  <div class='row'>
        <div class='col-lg-12 padding'>
            <div class='title'>
                <div class='center'>
                    <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                    <p style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</p>
                </div>
            </div>
                    " . do_shortcode($content) . "
                
        </div>
  </div>
</div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Restaurant_Menu2_Single extends WPBakeryShortCode {
        static $count = 0;

        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'position' => 'left',
            
            'title' => 'Sandwich and toast',
            'title_font'    => '',
            'title_size'    => '24',
            'title_color' => '#fff',

            'image' => 'Image',
            'name_1' => 'NAME OF DISH',
            'details_1' => 'Lorem ipsum dolor',
            'price_1' => '10:00',
            'name_2' => 'NAME OF DISH',
            'details_2' => 'Lorem ipsum dolor',
            'price_2' => '10:00',
            'name_3' => 'NAME OF DISH',
            'details_3' => 'Lorem ipsum dolor',
            'price_3' => '10:00',

            'name_font' => '',
            'name_size' => '14',
            'name_color' => '#CF6728',

            'price_font'    => '',
            'price_size'    => '14',
            'price_color'   => '#CF6728',

            'details_font'  => '',
            'details_size'  => '12',
            'details_color' => '#ABA899',
          ), $atts ) );


        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        $decode_font = urldecode($name_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $name_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($price_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $price_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


          

          $img = wp_get_attachment_image_src( $image, array(360,220) );

          if($image == "Image"){
            $imgsrc = plugins_url('images/imgpsh_fullsize_distr.png', __FILE__);
            $img[0] = $imgsrc;
          }


          $var = self::$count%2;
          if ($var == 0) {
            $class_left = 'first';
            $class_right = 'second';
          }
          else{
            $class_left = 'second';
            $class_right = 'first';
          }
          

          if ($position == 'left') {
            $output = "<div class='col-md-6 col-sm-6 item {$position}'>
                      <div class='head-section {$class_left}'>
                        <div class='col-sm-12 heading'><h3 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h3></div>
                        <div class='col-sm-12 img'><img src='{$img[0]}'></div>
                      </div>
                      <div class='dishes'>
                          <div class='col-sm-12 clear'>
                            <div class='pull-left half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$name_font_family};font-size:{$name_size}px;color:{$name_color};'</h5>
                                <p class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details_1}</p>
                            </div>
                            <div class='pull-right price half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$price_font_family};font-size:{$price_size}px;color:{$price_color};'>{$price_1}</h5>
                            </div>
                          </div>
                          <div class='col-sm-12 clear'>
                            <div class='pull-left half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$name_font_family};font-size:{$name_size}px;color:{$name_color};'</h5>
                                <p class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details_2}</p>
                            </div>
                            <div class='pull-right price half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$price_font_family};font-size:{$price_size}px;color:{$price_color};'>{$price_2}</h5>
                            </div>
                          </div>
                          <div class='col-sm-12 clear'>
                            <div class='pull-left half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$name_font_family};font-size:{$name_size}px;color:{$name_color};'</h5>
                                <p class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details_3}</p>
                            </div>
                            <div class='pull-right price half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$price_font_family};font-size:{$price_size}px;color:{$price_color};'>{$price_3}</h5>
                            </div>
                          </div>
                      </div>
                    </div>";
          }
          else{
            $output = "<div class='col-md-6 col-sm-6 item {$position}'>
                      <div class='dishes'>
                          <div class='col-sm-12 clear'>
                            <div class='pull-left half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$name_font_family};font-size:{$name_size}px;color:{$name_color};'>{$name_1}</h5>
                                <p class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details_1}</p>
                            </div>
                            <div class='pull-right price half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$price_font_family};font-size:{$price_size}px;color:{$price_color};'>{$price_1}</h5>
                            </div>
                          </div>
                          <div class='col-sm-12 clear'>
                            <div class='pull-left half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$name_font_family};font-size:{$name_size}px;color:{$name_color};'>{$name_2}</h5>
                                <p class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details_2}</p>
                            </div>
                            <div class='pull-right price half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$price_font_family};font-size:{$price_size}px;color:{$price_color};'>{$price_2}</h5>
                            </div>
                          </div>
                          <div class='col-sm-12 clear'>
                            <div class='pull-left half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$name_font_family};font-size:{$name_size}px;color:{$name_color};'>{$name_3}</h5>
                                <p class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details_3}</p>
                            </div>
                            <div class='pull-right price half-width'>
                                <h5 class='animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$price_font_family};font-size:{$price_size}px;color:{$price_color};'>{$price_3}</h5>
                            </div>
                          </div>
                      </div>
                      <div class='head-section {$class_right}'>
                        <div class='col-sm-12 heading'><h3 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h3></div>
                        <div class='col-sm-12 img'><img src='{$img[0]}'></div>
                      </div>
                    </div>";
          }

          self::$count++;

          return $output;
          
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>