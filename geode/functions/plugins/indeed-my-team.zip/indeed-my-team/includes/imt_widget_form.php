<?php

if(!isset($instance) || count($instance)==0){
    $instance = imt_init_widget_arr();
}
?>
<script>
    var instance_no = '<?php echo $instance_no;?>';
</script>
<div class="widget_wrapp">
    <div class="border_bottom">
        <table>
            <tr>
                <td><b>Team:</b></td>
                        <?php
                                $args = array(
                                	'type'                     => 'team',
                                	'child_of'                 => 0,
                                	'parent'                   => '',
                                	'orderby'                  => 'name',
                                	'order'                    => 'ASC',
                                	'hide_empty'               => 1,
                                	'hierarchical'             => 1,
                                	'exclude'                  => '',
                                	'include'                  => '',
                                	'number'                   => '',
                                	'taxonomy'                 => 'team_cats',
                                	'pad_counts'               => false
                                );
                                $categories = get_categories( $args );
                    ?>
                    <td>
                        <select name="<?php echo $this->get_field_name( 'team' );?>">
                                <?php $selected = checkIfSelected($instance['team'], 'all', 'select'); ?>
                                        <option value="all" <?php echo $selected;?> >All</option>
                                <?php
                                if(isset($categories) && count($categories)>0){
                                    foreach($categories as $cat){
                                        $selected = checkIfSelected($instance['team'], $cat->slug, 'select');
                                        ?>
                                            <option value="<?php echo $cat->slug;?>" <?php echo $selected;?>><?php echo $cat->name;?></option>
                                        <?php
                                    }
                                }
                                ?>
                        </select>
                    </td>
            </tr>
            <tr>
                <td>
                    <b>Number of items:</b>
                </td>
                <td>
                    <input type="number" value="<?php echo $instance['limit'];?>" min="0" name="<?php echo $this->get_field_name( 'limit' );?>" style="width: 50px;"/>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <div class="space_b_divs"></div>
                </td>
            </tr>
            <tr>
                <td>
                    <b>Order By:</b>
                </td>
                <td>
                    <select name="<?php echo $this->get_field_name( 'order_by' );?>">
                            <?php $selected = checkIfSelected($instance['order_by'], 'date', 'select');?>
                        <option value="date" <?php echo $selected;?>>Date</option>
                            <?php $selected = checkIfSelected($instance['order_by'], 'name', 'select');?>
                        <option value="name" <?php echo $selected;?>>Name</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>
                    <b>Order Type:</b>
                </td>
                <td>
                    <select name="<?php echo $this->get_field_name( 'order' );?>">
                            <?php $selected = checkIfSelected($instance['order'], 'ASC', 'select');?>
                        <option value="ASC" <?php echo $selected;?> >ASC</option>
                            <?php $selected = checkIfSelected($instance['order'], 'DESC', 'select');?>
                        <option value="DESC" <?php echo $selected;?> >DESC</option>
                    </select>
                </td>
            </tr>
        </table>
    </div>

    <div class="border_bottom">
        <b>Custom Field To Show: </b>
            <div>
                <?php
                    $selected = '';
                    if(strpos($instance['show'], 'name')!==false) $selected = "checked='checked'";
                ?>
                <input type="checkbox" id="show_name_<?php echo $instance_no;?>" onClick="make_inputh_string(this, 'name', '#show_cf_list_<?php echo $instance_no;?>');" <?php echo $selected;?>/> Name
            </div>
            <div>
                <?php
                    $selected = '';
                    if(strpos($instance['show'], 'photo')!==false) $selected = "checked='checked'";
                ?>
                <input type="checkbox" id="show_photo_<?php echo $instance_no;?>" onClick="make_inputh_string(this, 'photo', '#show_cf_list_<?php echo $instance_no;?>');" <?php echo $selected;?>/> Photo
            </div>
            <div>
                <?php
                    $selected = '';
                    if(strpos($instance['show'], 'description')!==false) $selected = "checked='checked'";
                ?>
                <input type="checkbox" id="show_descript" onClick="make_inputh_string(this, 'description', '#show_cf_list_<?php echo $instance_no;?>');" <?php echo $selected;?> /> Description
            </div>
            <div class="space_b_divs"></div>
            <div>
                <?php
                    $selected = '';
                    if(strpos($instance['show'], 'job')!==false) $selected = "checked='checked'";
                ?>
                <input type="checkbox" id="show_job_<?php echo $instance_no;?>" onClick="make_inputh_string(this, 'job', '#show_cf_list_<?php echo $instance_no;?>');" <?php echo $selected;?> /> Job Title
            </div>
            <div>
                <?php
                    $selected = '';
                    if(strpos($instance['show'], 'email')!==false) $selected = "checked='checked'";
                ?>
                <input type="checkbox" id="show_email_<?php echo $instance_no;?>" onClick="make_inputh_string(this, 'email', '#show_cf_list_<?php echo $instance_no;?>');" <?php echo $selected;?> /> E-mail
            </div>
            <div>
                <?php
                    $selected = '';
                    if(strpos($instance['show'], 'location')!==false) $selected = "checked='checked'";
                ?>
                <input type="checkbox" id="show_location_<?php echo $instance_no;?>" onClick="make_inputh_string(this, 'location', '#show_cf_list_<?php echo $instance_no;?>');" <?php echo $selected;?> /> Location
            </div>
            <div>
                <?php
                    $selected = '';
                    if(strpos($instance['show'], 'tel')!==false) $selected = "checked='checked'";
                ?>
                <input type="checkbox" id="show_tel_<?php echo $instance_no;?>" onClick="make_inputh_string(this, 'tel', '#show_cf_list_<?php echo $instance_no;?>');" <?php echo $selected;?> /> Telephone
            </div>
            <div>
                <?php
                    $selected = '';
                    if(strpos($instance['show'], 'website')!==false) $selected = "checked='checked'";
                ?>
                <input type="checkbox" id="show_website_<?php echo $instance_no;?>" onClick="make_inputh_string(this, 'website', '#show_cf_list_<?php echo $instance_no;?>');" <?php echo $selected;?> /> Website
            </div>
            <div class="space_b_divs"></div>
            <div>
                <?php
                    $selected = '';
                    if(strpos($instance['show'], 'social_icon')!==false) $selected = "checked='checked'";
                ?>
                <input type="checkbox" id="show_social_icon_<?php echo $instance_no;?>" onClick="make_inputh_string(this, 'social_icon', '#show_cf_list_<?php echo $instance_no;?>');" <?php echo $selected;?> /> Social Icons
            </div>
            <div class="space_b_divs"></div>
            <div>
                <?php
                    $selected = '';
                    if(strpos($instance['show'], 'skills')!==false) $selected = "checked='checked'";
                ?>
                <input type="checkbox" id="show_skills_<?php echo $instance_no;?>" onClick="make_inputh_string(this, 'skills', '#show_cf_list_<?php echo $instance_no;?>');" <?php echo $selected;?> /> Skills
            </div>
            <input type="hidden" value="<?php echo $instance['show'];?>" name="<?php echo $this->get_field_name( 'show' );?>" id="show_cf_list_<?php echo $instance_no;?>" />
    </div>

    <div class="border_bottom">
        <table>
            <tr>
                <td><b>Theme:</b></td>
                <td>
                    <?php
                        $handle = opendir( $dir_path . 'themes' );
                        while (false !== ($entry = readdir($handle))) {
                            if( $entry!='.' && $entry!='..' ){
                                $arr_str = explode('_', $entry);
                                $themes_arr[$arr_str[1]] = $arr_str[0];
                            }
                        }
                        ksort($themes_arr);
                    ?>
                    <select id="theme" class="ict_select_field_m" name="<?php echo $this->get_field_name( 'theme' );?>" >
                    <?php
                        foreach($themes_arr as $key=>$theme){
                            $value = strtolower($theme) . '_' . $key;
                            $label = ucfirst($theme) . ' ' . $key;
                            $selected = checkIfSelected($instance['theme'], $value, 'select'); 
                            ?>
                            <option value="<?php echo $value;?>" <?php echo $selected;?> ><?php echo $label;?></option>
                            <?php
                        }
                    ?>
                    </select>
                </td>
            </tr>
                        <tr>
                             <td colspan="2">
                                <div class="space_b_divs"></div>
                             </td>
                        </tr>
            <tr>
                <td colspan="2">Select Color Scheme
                    <ul id="colors_ul" class="colors_ul">
                        <?php
                            $color_scheme = array('0a9fd8', '38cbcb', '27bebe', '0bb586', '94c523', '6a3da3', 'f1505b', 'ee3733', 'f36510', 'f8ba01');
                            $i = 0;
                            foreach($color_scheme as $color){
                                if( $i%5==0 ) echo "<div class='clear'></div>";
                                $class="color_scheme_item";
                                if($instance['color_scheme']==$color) $class = 'color_scheme_item-selected';
                                ?>
                                    <li class="<?php echo $class;?>" onClick="changeColorScheme(this, '<?php echo $color;?>', '#color_scheme_<?php echo $instance_no;?>');" style="background-color: #<?php echo $color;?>;"></li>
                                <?php
                                $i++;
                            }
                        ?>
                    </ul>
                    <input type="hidden" id="color_scheme_<?php echo $instance_no;?>" value="<?php echo $instance['color_scheme'];?>" name="<?php echo $this->get_field_name( 'color_scheme' );?>"/>
                    <div class="clear"></div>
                </td>
            </tr>
                        <tr>
                             <td colspan="2">
                                <div class="space_b_divs"></div>
                             </td>
                        </tr>
            <tr>
                <td>Number of Columns:</td>
                <td>
                    <select name="<?php echo $this->get_field_name( 'columns' );?>" >
                        <?php
                            for($i=1;$i<7;$i++){
                                $selected = checkIfSelected($instance['columns'], $i, 'select');
                                ?>
                                    <option value='<?php echo $i;?>' <?php echo $selected;?>><?php echo $i;?> columns</option>
                                <?php
                            }
                            ?>
                    </select>
                </td>
            </tr>
                        <tr>
                             <td colspan="2">
                                <div class="space_b_divs"></div>
                             </td>
                        </tr>
            <tr>
                <td>
                    <b>Show as Slider</b>
                </td>
                <td>
                    <?php $selected = checkIfSelected($instance['slider_set'], 1, 'checkbox');?>
                    <input type="checkbox" <?php echo $selected;?> onClick="check_and_h(this, '#slider_set_<?php echo $instance_no;?>');jQuery('#slider_options_<?php echo $instance_no;?>').toggle();" />
                    <input type="hidden" name="<?php echo $this->get_field_name( 'slider_set' );?>" value="<?php echo $instance['slider_set'];?>" id="slider_set_<?php echo $instance_no;?>" />
                </td>
            </tr>
       </table>
                <?php
                    $display = 'none';
                    if($instance['slider_set']==1) $display = 'block';
                ?>
            <div id="slider_options_<?php echo $instance_no;?>" style="display: <?php echo $display;?>">
                <table>
                        <tr>
                            <td>
                                Items per Slide:
                            </td>
                            <td>
                                <input type="number" min="1" id="items_per_slide_<?php echo $instance_no;?>" name="<?php echo $this->get_field_name( 'items_per_slide' );?>" value="<?php echo $instance['items_per_slide'];?>" style="width: 50px;"/>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                 Bullets
                            </td>
                            <td>
                                <?php
                                    $selected = '';
                                    if(strpos($instance['slide_opt'], 'bullets')!==false) $selected = "checked='checked'";
                                ?>
                                <input type="checkbox" <?php echo $selected;?> onClick="make_inputh_string(this, 'bullets', '#slide_opt_list_<?php echo $instance_no;?>');" />
                            </td>
                        </tr>

                        <tr>
                            <td>
                                Nav Button
                            </td>
                            <td>
                                <?php
                                    $selected = '';
                                    if(strpos($instance['slide_opt'], 'nav_button')!==false) $selected = "checked='checked'";
                                ?>
                                <input type="checkbox" <?php echo $selected;?> onClick="make_inputh_string(this, 'nav_button', '#slide_opt_list_<?php echo $instance_no;?>');"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Autoplay
                            </td>
                            <td>
                                <?php
                                    $selected = '';
                                    if(strpos($instance['slide_opt'], 'autoplay')!==false) $selected = "checked='checked'";
                                ?>
                                <input type="checkbox" <?php echo $selected;?> onClick="make_inputh_string(this, 'autoplay', '#slide_opt_list_<?php echo $instance_no;?>');"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Stop Hover
                            </td>
                            <td>
                                <?php
                                    $selected = '';
                                    if(strpos($instance['slide_opt'], 'stop_hover')!==false) $selected = "checked='checked'";
                                ?>
                                <input type="checkbox" <?php echo $selected;?> onClick="make_inputh_string(this, 'stop_hover', '#slide_opt_list_<?php echo $instance_no;?>');" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Speed
                            </td>
                            <td>
                                <input type="number" value="<?php echo $instance['slide_speed'];?>" name="<?php echo $this->get_field_name( 'slide_speed' );?>" class="ict_input_num_field" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Pagination Speed
                            </td>
                            <td>
                                <input type="number" value="<?php echo $instance['slide_pagination_speed'];?>" name="<?php echo $this->get_field_name( 'slide_pagination_speed' );?>" class="ict_input_num_field"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                 Responsive
                            </td>
                            <td>
                                <?php
                                    $selected = '';
                                    if(strpos($instance['slide_opt'], 'responsive')!==false) $selected = "checked='checked'";
                                ?>
                                <input type="checkbox" <?php echo $selected;?> onClick="make_inputh_string(this, 'responsive', '#slide_opt_list_<?php echo $instance_no;?>');"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                 Lazy Load
                            </td>
                            <td>
                                <?php
                                    $selected = '';
                                    if(strpos($instance['slide_opt'], 'lazy_load')!==false) $selected = "checked='checked'";
                                ?>
                                <input type="checkbox" <?php echo $selected;?> onClick="make_inputh_string(this, 'lazy_load', '#slide_opt_list_<?php echo $instance_no;?>');" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Lazy Effect
                            </td>
                            <td>
                                  <?php
                                    $selected = '';
                                    if(strpos($instance['slide_opt'], 'lazy_effect')!==false) $selected = "checked='checked'";
                                ?>
                                <input type="checkbox" <?php echo $selected;?> onClick="make_inputh_string(this, 'lazy_effect', '#slide_opt_list_<?php echo $instance_no;?>');" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                CSS3 Transition
                            </td>
                            <td>
                                <select name="<?php echo $this->get_field_name( 'slide_css_transition' );?>">
                                        <?php $selected = checkIfSelected($instance['slide_css_transition'], 'none', 'select');?>
                                    <option value="none" <?php echo $selected;?> >None</option>
                                        <?php $selected = checkIfSelected($instance['slide_css_transition'], 'fade', 'select');?>
                                    <option value="fade" <?php echo $selected;?> >fade</option>
                                        <?php $selected = checkIfSelected($instance['slide_css_transition'], 'backSlide', 'select');?>
                                    <option value="backSlide" <?php echo $selected;?> >backSlide</option>
                                        <?php $selected = checkIfSelected($instance['slide_css_transition'], 'goDown', 'select');?>
                                    <option value="goDown" <?php echo $selected;?> >goDown</option>
                                        <?php $selected = checkIfSelected($instance['slide_css_transition'], 'fadeUp', 'select');?>
                                    <option value="fadeUp" <?php echo $selected;?> >fadeUp</option>
                                </select>
                            </td>
                        </tr>
                </table>
                <input type="hidden" value="<?php echo $instance['slide_opt'];?>" name="<?php echo $this->get_field_name( 'slide_opt' );?>" id="slide_opt_list_<?php echo $instance_no;?>" />
            </div>
    </div>

    <div>
            <div>
                <?php $selected = checkIfSelected($instance['page_inside'], 1, 'checkbox');?>
                <input type="checkbox" <?php echo $selected;?> onClick="check_and_h(this, '#show_inside_page_<?php echo $instance_no;?>')" /> <b>Show Inside Page</b>
                <input type="hidden" value="<?php echo $instance['page_inside'];?>" name="<?php echo $this->get_field_name( 'page_inside' );?>" id="show_inside_page_<?php echo $instance_no;?>" />
            </div>
            <div>
                <b>Template</b>
                <select name="<?php echo $this->get_field_name( 'inside_template' );?>" style="max-width: 215px;">
                    <option value="default">Default Template</option>
                    <?php
                        $templates = get_page_templates();
                        if(isset($templates) && count($templates)>0){
                             foreach($templates as $template_name => $template_page){
                                $template_page = str_replace('.php', '', $template_page);
                                $selected = checkIfSelected($instance['inside_template'], $template_name, 'select');
                                ?>
                                    <option value="<?php echo $template_page;?>" <?php echo $selected;?> ><?php echo $template_name;?></option>
                                <?php
                             }
                        }
                    ?>
                </select>
            </div>
            <div>
                <span class="warning_grey_span">( If you want to use this options do not move theme files from their original location. )</span>
            </div>
    </div>
</div>