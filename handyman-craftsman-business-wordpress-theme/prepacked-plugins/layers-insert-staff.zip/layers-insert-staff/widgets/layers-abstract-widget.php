<?php
if (!class_exists('Layers_Widget')) {
    return;
}

if (!class_exists('TL_Layers_Abstract_Widget')) {


    /**
     * Class TL_Layers_Abstract_Widget
     */
    class TL_Layers_Abstract_Widget extends Layers_Widget
    {


        /**
         * Apply CSS to widget's heading section
         *
         * @param $widget_id
         * @param $widget
         */
        protected function _apply_widget_section_styling($widget_id, $widget)
        {
            // Set the background styling
            if (!empty($widget['design']['background']))
                $this->inline_css .= layers_inline_styles('#' . $widget_id, 'background', array('background' => $widget['design']['background']));

            // Set section title colors
            if (!empty($widget['design']['fonts']['color']))
                $this->inline_css .= layers_inline_styles('#' . $widget_id, 'color', array('selectors' => array('.section-title h3.heading'), 'color' => $widget['design']['fonts']['color']));

            // Set section Excerpt color
            if (!empty($widget['design']['fonts']['excerpt-color']))
                $this->inline_css .= layers_inline_styles('#' . $widget_id . ' .section-title div.excerpt{ color: ' . $widget['design']['fonts']['excerpt-color'] . '; color: rgba(' . apply_filters('tl/hex2rgba', $widget['design']['fonts']['excerpt-color'], 0.85, true) . ');}');
        }



        /**
         * Apply CSS to buttons in columns
         *
         * @param $widget_id
         * @param null $widget
         */
        protected function _apply_button_styling($widget_id, $widget = null)
        {
            $btn_css  = $btn_css_hover = array();
            $params   = $this->check_and_return($widget, 'design', 'buttons');
            $widget_id = '#' . $widget_id;
            $selector  = $widget_id . ' .list-grid .button';

            // Button regular state

            if(!empty($params['text-color'])){
                $btn_css['color'] = $params['text-color'];
            }
            if(!empty($params['background-color'])){
                $btn_css['background-color'] = $params['background-color'];
            }
            if(!empty($params['border-color'])){
                $btn_css['border-color'] = $params['border-color'];
            }
            if(isset($params['border-width']) && is_numeric($params['border-width'])){
                $btn_css['border-width'] = ((int) $params['border-width']) . 'px';
            }
            if(isset($params['border-radius']) && is_numeric($params['border-radius'])){
                $btn_css['border-radius'] = ((int) $params['border-radius']) . 'px';
            }
            $btn_css['border-style'] = 'solid';
            if(!empty($btn_css)){
                $this->inline_css .= layers_inline_styles(array('selectors' => array($selector), 'css' => $btn_css ));
            }


            // Button hover state

            if(!empty($params['text-color-hover']) ){
                $btn_css_hover['color'] = $params['text-color-hover'];
            }
            if(!empty($params['border-color-hover'])){
                $btn_css_hover['border-color'] = $params['border-color-hover'];
            }

            if(!empty($btn_css_hover)){
                $this->inline_css .= layers_inline_styles(array('selectors' => array($selector . ':hover'), 'css' => $btn_css_hover ));
            }

            if($anim = $this->check_and_return($widget, 'design', 'buttons', 'animation')){

                if(in_array($anim, array('hvr-fade', 'hvr-grow', 'hvr-shrink', 'hvr-float', 'hvr-wobble-horizontal', 'hvr-wobble-vertical'))){
                    $this->inline_css .= layers_inline_styles($widget_id , array('selectors' => array(' .grid .'.$anim.':hover', ' .grid .'.$anim.':focus', ' .grid .'.$anim.':active'),
                                                            'css' => array('background-color' => $this->check_and_return($widget, 'design', 'buttons', 'background-color-hover'))));
                }else{

                    $this->inline_css .= layers_inline_styles($widget_id, array('selectors' => array(' .grid .'.$anim . ':hover'), 'css' => array('background-color'=>'transparent')));
                    $this->inline_css .= layers_inline_styles( $widget_id, array( 'selectors' => array(' .grid .' . $anim . ':before' ),
                                                             'css' => array( 'background' => $this->check_and_return($widget, 'design', 'buttons', 'background-color-hover'))));
                }
            }else{
                $this->inline_css .= layers_inline_styles($widget_id, array('selectors' => array(' .grid .button:hover'),
                                                       'css' => array('background-color' => $this->check_and_return($widget, 'design', 'buttons', 'background-color-hover'))));
            }
        }


        /**
         * @param $widget
         * @param $map
         * @return array
         */
        public function prepare_inline_styles($widget, $map)
        {
            $css = array();
            foreach ($map as $prop => $v) {
                if (count($v) == 3 && $this->check_and_return($widget, $v[0], $v[1], $v[2])) {
                    $css[$prop] = $this->check_and_return($widget, $v[0], $v[1], $v[2]);

                } elseif (count($v) == 2 && $this->check_and_return($widget, $v[0], $v[1])) {
                    $css[$prop] = $this->check_and_return($widget, $v[0], $v[1]);
                } elseif (count($v) == 1 && $this->check_and_return($widget, $v[0])) {
                    $css[$prop] = $this->check_and_return($widget, $v[0]);
                }
            }
            return $css;
        }


        /**
         * @return string
         */
        public function widget_class()
        {
            return str_replace('_', '-', $this->widget_id) . '-widget';
        }


        /**
         * Standard Widget update method
         *
         * @param array $new_instance
         * @param array $old_instance
         * @return array
         */
        public function update($new_instance, $old_instance)
        {
            // Apply  filter to a widget data before save
            $new_instance = apply_filters('tl/layers/customizer/before_save_' . $this->widget_id, $new_instance, $old_instance);

            if (isset($this->checkboxes)) {
                foreach ($this->checkboxes as $cb) {
                    if (isset($old_instance[$cb])) {
                        $old_instance[$cb] = strip_tags($new_instance[$cb]);
                    }
                }
            }
            return $new_instance;
        }



        //Overwrites parent method
        public function custom_anchor( $widget = NULL ){
            if( NULL == $widget ) return;
            if( $this->check_and_return( $widget,  'design', 'advanced', 'anchor' ) ) { ?>
                <a name="<?php echo esc_attr( $this->check_and_return( $widget,  'design', 'advanced', 'anchor' ) ); ?>"></a>
            <?php }
        }



        public function get_theme_colors()
        {
            if(class_exists('\Handyman\Core\Colors')){
                $this->colors = \Handyman\Core\Colors::single();
            }else{
                $this->colors = null;
            }
        }


        /**
         * Resolve path to the asset script
         *
         * @param string $filename
         * @param bool $parent if TRUE get file from parent theme
         * @return string
         */
        public static function asset_path($filename, $parent = false, $nomin = false)
        {
            $plugin = \TL_Layers_Insert_Staff::single();
            return $plugin::assetPath($filename, $parent, $nomin);
        }
    }
}