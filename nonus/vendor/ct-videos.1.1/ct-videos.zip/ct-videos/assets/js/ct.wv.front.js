jQuery( function ( $ ) {


    //find and change thumbnails connected with videos in product gallery
    $(document).ready(function () {

        var videos = $('.ct-woovideo-gallery-videos').find('.ct-woovideo-video').addClass('ct-woovideo-hidden');

        var thumbs = $('.single-product .images, .single-product .thumbnailSlider').find('img');

        $.each(thumbs, function (thumbindex, thumbvalue) {

            var $link = $(this).attr('src');
            //remove height and width from url string
            var replaced = $link.replace(/-\d+[Xx]\d+\./, '.');

            $.each(videos, function (index, value) {

                var url = $(value).data('video');

                if (replaced == url) {

                    if ($(thumbvalue).parent("a").length) {
                        $(thumbvalue).parent().unbind('click.prettyphoto').addClass('ct-woovideo-gallery-thumbnail').attr('data-videorel', url).attr('data-rel', '').attr('href', '#').append('<span></span>');
                    }

                    else {
                        $(thumbvalue).parent().unbind('click.magnificpopup').unbind('click.prettyphoto');

                        $(thumbvalue).wrap(function () {
                            return "<a href='#' class='ct-woovideo-gallery-thumbnail' data-videorel='" + url + "'></a>";
                        });
                        $(thumbvalue).parent().append('<span></span>');
                    }


                }
            });

            if ($('.flexslider').length != 0) {
                $('.thumbnailSlider .slides').find('li a').addClass('woocommerce-main-image');
            }


        });

        //remove buttos if cloned
        var buttons = $('.single-product').find('.ct-woovideo-button');
        var button_hrefs = new Array;
        $.each(buttons, function(index, value){
            var href = $(this).attr('href');
            if ($.inArray(href, button_hrefs) !== -1) {
                $(this).remove();
            } else {
                button_hrefs.push(href);
            }
        });


    });


    //hide gallery video when other image or video clicked
    $('.images img, .thumbnailSlider img, .ct-woovideo-button, .ct-woovideo-close-video').click(function () {
        $(".ct-woovideo-gallery-videos .ct-woovideo-active").slideUp("fast", function () {
            $(".ct-woovideo-gallery-videos .ct-woovideo-active").detach().appendTo(".ct-woovideo-gallery-videos").removeClass('ct-woovideo-active').addClass('ct-woovideo-hidden').trigger('classHiddenAdded');
        });



    });

    //view video when gallery thumbnail clicked
    var li = $('.ct-woovideo-gallery-thumbnail').parent('li');
    console.log(li);

    $('.images, .thumbnailSlider').on( 'click', '.ct-woovideo-gallery-thumbnail', function(e){

        $( ".ct-woovideo-gallery-videos .ct-woovideo-active").slideUp("fast", function(){
            $( ".ct-woovideo-gallery-videos .ct-woovideo-active").detach().appendTo( ".ct-woovideo-gallery-videos" ).removeClass('ct-woovideo-active').addClass('ct-woovideo-hidden');
        });

        var image = $('.ct-woovideo-gallery-videos').find('.woocommerce-main-image');
        if ($(image).length == 0) {
            var image = $('.ct-woovideo-gallery-videos').find('.attachment-shop_single');
        }

        if(image.length > 0) {
            var gal_video = $('.images, .thumbnailSlider').find('.ct-woovideo-video');
            $(image).removeClass('hidden').detach();
            $(gal_video).removeClass('ct-woovideo-active').addClass('ct-woovideo-hidden').trigger('classHiddenAdded');
            $(gal_video).replaceWith(image);
            $(gal_video).appendTo( '.ct-woovideo-gallery-videos' ).trigger('classHiddenAdded');
            if (($(gal_video).hasClass('ct-woovideo-hidden')) && ($(gal_video).css('display') != 'none')) {
                $(gal_video).css('display', 'none');
            }
        }

        var thumbrel = $(this).data('videorel');

        var video =  $('.ct-woovideo-gallery-videos').find('.ct-woovideo-video[data-video=\"'+thumbrel+'\"]');

        $(video).show("slide", function(){
            $(video).removeClass('ct-woovideo-hidden').addClass('ct-woovideo-active').trigger('classHiddenAdded');
        });


        e.preventDefault();

    });

    //view video when popup button clicked
    $('.ct-woovideo-button').magnificPopup({
        type:'inline',
        midClick: true,
        closeBtnInside: false,
        callbacks: {
            open: function() {
                $('.mfp-wrap').addClass('ct-woovideo-active')
                    .siblings('.mfp-bg').addClass('ct-woovideo-active');

            },
            close: function() {
                $('.mfp-wrap').removeClass('ct-woovideo-active')
                    .siblings('.mfp-bg').removeClass('ct-woovideo-active')
                    .trigger('classHiddenAdded');
            }
        }
    });


    //make embedded videos responsive
    $('.ct-woovideo-video').fitVids();

    //autoplay function for vimeo api
    var ctWoovideoVimeoAutoplay = function(player, act) {
    if ($(player)[0].src.indexOf('?api=1&player_id=player') == -1) {
        $(player)[0].src += '?api=1&player_id=player';
    }
    var playerOrigin = '*';

    if (window.addEventListener) {
        window.addEventListener('message', onMessageReceived, false);
    }
    else {
        window.attachEvent('onmessage', onMessageReceived, false);
    }

    function onMessageReceived(event) {

        if (!(/^https?:\/\/player.vimeo.com/).test(event.origin)) {
            return false;
        }

        if (playerOrigin === '*') {
            playerOrigin = event.origin;
        }

        var data = JSON.parse(event.data);

        if (data.event == 'ready') {
            post(act);
        }
    }

    function post(action) {
        var data = {
            method: action
        };

        player[0].contentWindow.postMessage(data, playerOrigin);

    }

    };
    window.ctWoovideoVimeoAutoplay = ctWoovideoVimeoAutoplay;


    //remove autoplay when video is hidden
    $(document).on('classHiddenAdded', function(){

        var iframe_yt = $('.ct-woovideo-popup-video.mfp-hide iframe[src*="&autoplay=1"], .ct-woovideo-hidden iframe[src*="&autoplay=1"]');

        if ($(iframe_yt).length != 0) {
            var new_src_yt = iframe_yt.attr('src').replace('&autoplay=1','');
            iframe_yt.attr('src', new_src_yt);
        }

        var iframe_vimeo = $('.ct-woovideo-popup-video.mfp-hide iframe[src*="?api=1&player_id=player"], .ct-woovideo-hidden iframe[src*="?api=1&player_id=player"]');

        if ($(iframe_vimeo).length != 0) {
            ctWoovideoVimeoAutoplay(iframe_vimeo, 'unload');
            var new_src_vimeo = iframe_vimeo.attr('src').replace('?api=1&player_id=player','');
            iframe_vimeo.attr('src', '');
            iframe_vimeo.attr('src', new_src_vimeo);

        }






    });


});

