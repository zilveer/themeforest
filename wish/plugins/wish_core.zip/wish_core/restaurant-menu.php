<?php  
//Register "container" content element
vc_map( array(
    "name" => __("Restaurant Menu", "wish"),
    "description" => __("2 Column Resaurant Menu with parallax", 'wish'),
    "controls" => "full",
    "base" => "wish_restaurant_menu",
    "as_parent" => array('only' => 'wish_restaurant_menu_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/TgLqGnX.jpg",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(


        array(
            'type' => 'checkbox',
            'heading' => __( 'hide background color?', 'wish' ),
            "description" => __("hide background color of the container?", 'wish'),
            'param_name' => 'hide_bgcolor',
            'value' => array( __( '', 'wish' ) => true),
        ),


        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Menu Title", "wish"),
            "value" => __("Our Specials", 'wish'),
            "admin_label" => true,
        ),


        array(
            "type" => "textfield",
            "heading" => __("SubTitle", "wish"),
            "param_name" => "subtitle",
            "description" => __("Subtitle below the title", "wish"),
            "value" => __("Our Specials For Today", 'wish'),
            "admin_label" => true,
        ),


        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Image in the background", 'wish'),
            "param_name" => "image",
        ),


        array(
            "type" => "textfield",
            "heading" => __("Column 1 Title", "wish"),
            "param_name" => "col1_title",
            "description" => __("Title For The Left Column", "wish"),
            "value" => __("Appetizers", 'wish'),
            "admin_label" => false,
        ),


        array(
            "type" => "textfield",
            "heading" => __("Column 2 Title", "wish"),
            "param_name" => "col2_title",
            "description" => __("Title For The Right Column", "wish"),
            "value" => __("Quick & light Meals", 'wish'),
            "admin_label" => false,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("50", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        /*Subtitle*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Subtitle Text Font", "wish" ),
            "param_name" => "subtitle_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Subtitle Size", "wish"),
            "param_name" => "subtitle_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("16", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Subtitle Text Color", "wish" ),
            "param_name" => "subtitle_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),




        /*Column 1 Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Column 1 Title Text Font", "wish" ),
            "param_name" => "col1_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Column 1 Title Size", "wish"),
            "param_name" => "col1_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Column 1 Title Text Color", "wish" ),
            "param_name" => "col1_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),




        /*Column 2 Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Column 2 Title Text Font", "wish" ),
            "param_name" => "col2_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Column 2 Title Size", "wish"),
            "param_name" => "col2_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Column 2 Title Text Color", "wish" ),
            "param_name" => "col2_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Restaurant Menu Item", "wish"),
    "base" => "wish_restaurant_menu_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_restaurant_menu'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Item Title", "wish"),
            "value" => __("Ground Beef Burger", 'wish'),
            "admin_label" => true,
        ), 

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),


        array(
            "type" => "dropdown",
            "heading" => __("Column", "wish"),
            "param_name" => "col_position",
            "description" => __("Choose right or left column for the position", "wish"),
            "value" => array( 
                              "left"     => "left",
                              "right"     => "right",
                            ),
            "std"       =>   'left',
            "admin_label" => true,
        ),


        array(
            "type" => "textfield",
            "heading" => __("Price", "wish"),
            "param_name" => "price",
            "description" => __("Item price", "wish"),
            "value" => __("5.00", 'wish'),
            "admin_label" => false,
        ),

        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("16", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        /*Price*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Price Text Font", "wish" ),
            "param_name" => "price_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Price Size", "wish"),
            "param_name" => "price_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Price Text Color", "wish" ),
            "param_name" => "price_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


       
    )//ends params

));//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Restaurant_Menu extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'hide_bgcolor'  => '0',
        'title' => 'Our Specials',
        'title_font'    => '',
        'title_size'    => '50',
        'title_color' => '#000',

        'subtitle' => 'Our Specials For Today',
        'subtitle_font' => '',
        'subtitle_size' => '16',
        'subtitle_color' => '#000',

        'image'   => 'Image',
        'col1_title'  => 'Appetizers',
        'col1_font' => '',
        'col1_size' => '20',
        'col1_color' => '#000',

        'col2_title'  => 'Quick & light Meals',
        'col2_font' => '',
        'col2_size' => '20',
        'col2_color' => '#000'
      ), $atts ) );

        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        $decode_font = urldecode($subtitle_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $subtitle_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        $decode_font = urldecode($col1_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $col1_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($col2_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $col2_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

      $img = wp_get_attachment_image_src( $image, 'full' );

      if($image == "Image"){
        $imgsrc = plugins_url('images/restaurant.jpg', __FILE__);
        $img[0] = $imgsrc;
      }
     

    $pattern = get_shortcode_regex();
    if (   preg_match_all( '/'. $pattern .'/s', $content, $matches ) && array_key_exists( 2, $matches ) && in_array( 'wish_restaurant_menu_single', $matches[2] ) )
    {

    }

    $background_style = "";
    if ($hide_bgcolor == "1") {
        $background_style = "<style>
        .discover-menu .container {
            background: rgba(255, 255, 255, 0.08);
        }
      </style>";
    }

    //$matches[3] is parameters, explode by " "
    //$matches[0] are the shortcodes
    //print_r($matches[0][0]);


      $output = "
      {$background_style}
      <div class='parallax-1 discover-menu' style='background-image: url({$img[0]});'>
                    <div class='container'>
                        <div class='row'>
                            <div class='col-lg-12'>
                                <div class='header animated' data-animation='fadeInDown' data-animation-delay='100'>
                                    <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                                    <div class='links'><a href='#' style='font-family:{$subtitle_font_family};font-size:{$subtitle_size}px;color:{$subtitle_color};'>{$subtitle}</a></div>
                                </div>
                            </div>
                        </div>";

      $output .= "<div class='row discover-menu-carousel animated' data-animation='fadeInUp' data-animation-delay='400'>
                    <div class='col-lg-6'>
                        <h2 style='font-family:{$col1_font_family};font-size:{$col1_size}px;color:{$col1_color};'>{$col1_title}</h2>"; 
                                    
      //column 1 loop  
      foreach($matches[0] as $value){    
          
          $string_n = do_shortcode($value);  
          if( substr( $string_n, 0, 3 ) !== "   " ){
            $output .= do_shortcode($value);  
          }

       }                 

       $output .= "</div>
                    <div class='col-lg-6'>
                        <h2 style='font-family:{$col2_font_family};font-size:{$col2_size}px;color:{$col2_color};'>{$col2_title}</h2>";   

      //column 2 loop  
      foreach($matches[0] as $value){   

          $string_n = do_shortcode($value);  
          if( substr( $string_n, 0, 3 ) === "   " ){
            $output .= do_shortcode($value);  
          }

      }    

       //end                 
       $output .= "         </div>
                        </div>
                    </div>
                </div>";                  

      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Restaurant_Menu_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'title'   => 'Ground Beef Burger',
            'title_font'    => '',
            'title_size'    => '16',
            'title_color' => '#000',

            'details' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#000',

            'col_position'    => 'left',
            'price'         => '5.00',
            'price_font'    => '',
            'price_size'    => '14',
            'price_color'  => '#000'
          ), $atts ) );

        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($price_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $price_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        if($col_position == "left"){  
            $output = "<div class='menu-item'>
                                <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}<span class='price pull-right' style='font-family:{$price_font_family};font-size:{$price_size}px;color:{$price_color};'>{$price}</span></h1>
                                <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                            </div>"; 
        }else{

            $output = "   <div class='menu-item'>
                                <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}<span class='price pull-right' style='font-family:{$price_font_family};font-size:{$price_size}px;color:{$price_color};'>{$price}</span></h1>
                                <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                            </div>"; 


        }
        



          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>