<?php
class Wish_Hand_Testimonial{

        var $shortcode = 'wish_hand_testimonial';
        var $title = "Hand Written Testimonial";
        var $details = "Single Testimonial in hand written font";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link" => "http://i.imgur.com/vXkp7rl.png",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'wish'),
            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor
            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
            "params" => array(

                            array(
                                "type" => "textfield",
                                "heading" => __("Title", "wish"),
                                "param_name" => "title",
                                "admin_label" => true,
                                "description" => __("The Title.", "wish"),
                                "value" => __("We had such a good time here and will come back the next time im in town...", 'wish'),
                                "admin_label" => true,
                            ),
                            array(
                                "type" => "textfield",
                                "heading" => __("Subtitle", "wish"),
                                "param_name" => "subtitle",
                                "description" => __("", "wish"),
                                "value" => __("Jane Dough", 'wish'),
                                "admin_label" => false,
                            ),


                            array(
                                "type" => "attach_image",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Picture", 'wish'),
                                "param_name" => "pic",
                                "description" => __("The customer's picture", 'wish'),
                                "admin_label" => false,
                            ),

                            array(
                                "type" => "attach_image",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Picture", 'wish'),
                                "param_name" => "bg_image",
                                "description" => __("The background image", 'wish'),
                                "admin_label" => false,
                            ),


                            /*Title*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __("Title Text Font", "wish" ),
                                "param_name" => "title_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Title Size", "wish"),
                                "param_name" => "title_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("40", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __("Title Text Color", "wish" ),
                                "param_name" => "title_color",
                                "value" => '#a7781d ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),



                            /*Subtitle*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __("Subtitle Text Font", "wish" ),
                                "param_name" => "subtitle_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Subtitle Size", "wish"),
                                "param_name" => "subtitle_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("30", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __("Subtitle Text Color", "wish" ),
                                "param_name" => "subtitle_color",
                                "value" => '#ccc ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),




                    )

        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'         => 'We had such a good time here and will come back the next time we are in town...',
        'title_font'    => '',
        'title_size'    => '40',
        'title_color'   => '#a7781d',

        'subtitle'      => 'Jane Dough',
        'subtitle_font' => '',
        'subtitle_size' => '30',
        'subtitle_color'=> '#ccc',

        'pic'           => 'Image',
        'bg_image'      => 'Image',
      ), $atts ) );

        /*title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*subtitle*/
        $decode_font = urldecode($subtitle_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $subtitle_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

      $pic_img = wp_get_attachment_image_src( $pic, 'full' );
      $bg_image_img = wp_get_attachment_image_src( $bg_image, 'full' );

      if($pic == "Image"){
        $pic_img[0] = plugins_url('images/girl3.jpg', __FILE__);
      }

      if($bg_image == "Image"){
        $bg_image_img[0] = plugins_url('images/old_wood.jpg', __FILE__);
      }


      $output = "<div class='hand-testimonial' style='background-image:url($bg_image_img[0]);'>
                        <div class='container'>
                            <div class='row'>
                                <div class='col-md-10'>
                                    
                                        <h1 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                                        <h3 class='animated' data-animation='fadeInUp' data-animation-delay='300' style='font-family:{$subtitle_font_family};font-size:{$subtitle_size}px;color:{$subtitle_color};'>{$subtitle}</h3>
                                    
                                </div>    

                                <div class='col-md-2'>
                                    <div class='hand-testimonial-image'>
                                        <img src='{$pic_img[0]}' class='img-responsive'>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>";
      return $output;
    }

    /*
    Load plugin css and javascript files which you may need on front end of your site
    */
    public function loadCssAndJs() {
      //wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
      //wp_enqueue_style( 'vc_extend_style' );

      // If you need any javascript files on front end, here is how you can load them.
      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );
    }

    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }



}//end of class
?>