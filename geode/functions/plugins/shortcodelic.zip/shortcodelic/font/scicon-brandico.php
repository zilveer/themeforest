        <div class="the-icons span3" data-search="facebook"><i class="scicon-brandico-facebook"></i><span class="i-name">.scicon-brandico-facebook</span></div>
        <div class="the-icons span3" data-search="win8"><i class="scicon-brandico-win8"></i><span class="i-name">.scicon-brandico-win8</span></div>
        <div class="the-icons span3" data-search="twitter"><i class="scicon-brandico-twitter"></i><span class="i-name">.scicon-brandico-twitter</span></div>
        <div class="the-icons span3" data-search="twitter-bird"><i class="scicon-brandico-twitter-bird"></i><span class="i-name">.scicon-brandico-twitter-bird</span></div>
        <div class="the-icons span3" data-search="vimeo"><i class="scicon-brandico-vimeo"></i><span class="i-name">.scicon-brandico-vimeo</span></div>
        <div class="the-icons span3" data-search="vimeo-rect"><i class="scicon-brandico-vimeo-rect"></i><span class="i-name">.scicon-brandico-vimeo-rect</span></div>
        <div class="the-icons span3" data-search="tumblr"><i class="scicon-brandico-tumblr"></i><span class="i-name">.scicon-brandico-tumblr</span></div>
        <div class="the-icons span3" data-search="tumblr-rect"><i class="scicon-brandico-tumblr-rect"></i><span class="i-name">.scicon-brandico-tumblr-rect</span></div>
        <div class="the-icons span3" data-search="googleplus-rect"><i class="scicon-brandico-googleplus-rect"></i><span class="i-name">.scicon-brandico-googleplus-rect</span></div>
        <div class="the-icons span3" data-search="github-text"><i class="scicon-brandico-github-text"></i><span class="i-name">.scicon-brandico-github-text</span></div>
        <div class="the-icons span3" data-search="github"><i class="scicon-brandico-github"></i><span class="i-name">.scicon-brandico-github</span></div>
        <div class="the-icons span3" data-search="skype"><i class="scicon-brandico-skype"></i><span class="i-name">.scicon-brandico-skype</span></div>
        <div class="the-icons span3" data-search="icq"><i class="scicon-brandico-icq"></i><span class="i-name">.scicon-brandico-icq</span></div>
        <div class="the-icons span3" data-search="yandex"><i class="scicon-brandico-yandex"></i><span class="i-name">.scicon-brandico-yandex</span></div>
        <div class="the-icons span3" data-search="yandex-rect"><i class="scicon-brandico-yandex-rect"></i><span class="i-name">.scicon-brandico-yandex-rect</span></div>
        <div class="the-icons span3" data-search="vkontakte-rect"><i class="scicon-brandico-vkontakte-rect"></i><span class="i-name">.scicon-brandico-vkontakte-rect</span></div>
        <div class="the-icons span3" data-search="odnoklassniki"><i class="scicon-brandico-odnoklassniki"></i><span class="i-name">.scicon-brandico-odnoklassniki</span></div>
        <div class="the-icons span3" data-search="odnoklassniki-rect"><i class="scicon-brandico-odnoklassniki-rect"></i><span class="i-name">.scicon-brandico-odnoklassniki-rect</span></div>
        <div class="the-icons span3" data-search="friendfeed"><i class="scicon-brandico-friendfeed"></i><span class="i-name">.scicon-brandico-friendfeed</span></div>
        <div class="the-icons span3" data-search="facebook-rect"><i class="scicon-brandico-facebook-rect"></i><span class="i-name">.scicon-brandico-facebook-rect</span></div>
        <div class="the-icons span3" data-search="blogger"><i class="scicon-brandico-blogger"></i><span class="i-name">.scicon-brandico-blogger</span></div>
        <div class="the-icons span3" data-search="blogger-rect"><i class="scicon-brandico-blogger-rect"></i><span class="i-name">.scicon-brandico-blogger-rect</span></div>
        <div class="the-icons span3" data-search="deviantart"><i class="scicon-brandico-deviantart"></i><span class="i-name">.scicon-brandico-deviantart</span></div>
        <div class="the-icons span3" data-search="jabber"><i class="scicon-brandico-jabber"></i><span class="i-name">.scicon-brandico-jabber</span></div>
        <div class="the-icons span3" data-search="lastfm"><i class="scicon-brandico-lastfm"></i><span class="i-name">.scicon-brandico-lastfm</span></div>
        <div class="the-icons span3" data-search="lastfm-rect"><i class="scicon-brandico-lastfm-rect"></i><span class="i-name">.scicon-brandico-lastfm-rect</span></div>
        <div class="the-icons span3" data-search="linkedin"><i class="scicon-brandico-linkedin"></i><span class="i-name">.scicon-brandico-linkedin</span></div>
        <div class="the-icons span3" data-search="linkedin-rect"><i class="scicon-brandico-linkedin-rect"></i><span class="i-name">.scicon-brandico-linkedin-rect</span></div>
        <div class="the-icons span3" data-search="picasa"><i class="scicon-brandico-picasa"></i><span class="i-name">.scicon-brandico-picasa</span></div>
        <div class="the-icons span3" data-search="wordpress"><i class="scicon-brandico-wordpress"></i><span class="i-name">.scicon-brandico-wordpress</span></div>
        <div class="the-icons span3" data-search="instagram"><i class="scicon-brandico-instagram"></i><span class="i-name">.scicon-brandico-instagram</span></div>
        <div class="the-icons span3" data-search="instagram-filled"><i class="scicon-brandico-instagram-filled"></i><span class="i-name">.scicon-brandico-instagram-filled</span></div>
        <div class="the-icons span3" data-search="diigo"><i class="scicon-brandico-diigo"></i><span class="i-name">.scicon-brandico-diigo</span></div>
        <div class="the-icons span3" data-search="box"><i class="scicon-brandico-box"></i><span class="i-name">.scicon-brandico-box</span></div>
        <div class="the-icons span3" data-search="box-rect"><i class="scicon-brandico-box-rect"></i><span class="i-name">.scicon-brandico-box-rect</span></div>
        <div class="the-icons span3" data-search="tudou"><i class="scicon-brandico-tudou"></i><span class="i-name">.scicon-brandico-tudou</span></div>
        <div class="the-icons span3" data-search="youku"><i class="scicon-brandico-youku"></i><span class="i-name">.scicon-brandico-youku</span></div>
        <div class="the-icons span3" data-search="friendfeed-rect"><i class="scicon-brandico-friendfeed-rect"></i><span class="i-name">.scicon-brandico-friendfeed-rect</span></div>

<div class="clear"></div><hr>
<a href="https://github.com/fontello/brandico.font" target="_blank">https://github.com/fontello/brandico.font</a>
<div class="clear"></div><hr><br>