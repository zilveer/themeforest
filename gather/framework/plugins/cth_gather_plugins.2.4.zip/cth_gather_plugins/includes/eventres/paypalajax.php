<?php
if ( ! defined('ABSPATH') ) {
    die('Please do not load this file directly!');
}

//Search for coupon array key
function searchCouponId($id, $array) {
    foreach ($array as $key => $val) {
        if ($val['name'] === $id) {
           return $key;
        }
    }
    return false;
}

add_action( 'wp_ajax_nopriv_gather_event_paypal_registration', 'cththemes_gather_event_paypal_registration_callback' );
add_action( 'wp_ajax_gather_event_paypal_registration', 'cththemes_gather_event_paypal_registration_callback' );
function cththemes_gather_event_paypal_registration_callback() {
    global $wpdb;

    $register_new_user = false;

    
    
    //$error = '';
    $json = array();
    $json['success'] = 0;
    //$success = '';
    $nonce = $_POST['gather_event_paypal_registration_nonce'];
    
    if ( ! wp_verify_nonce( $nonce, 'gather_event_paypal_registration_action' ) )
        die ( '<p class="error">Security checked!, Cheatn huh?</p>' );

    // Post datas
    $res_post_datas = array();

    $res_post_datas['first_name'] = trim($_POST['first_name']);
    $res_post_datas['last_name'] = trim($_POST['last_name']);
    $res_post_datas['email'] = trim($_POST['email']);

    // for option prices
    $paypal_options = array();
    $paypal_options['on0'] = trim($_POST['on0']);
    $paypal_options['os0'] = trim($_POST['os0']);
    $prices_option = get_option('eventres_item_prices');
    
    if(!empty($prices_option)){
    	$op_in = 0;
    	foreach ($prices_option as $pr_arr) {
    		$paypal_options['option_select'.$op_in] = trim($pr_arr['name']);
    		$paypal_options['option_amount'.$op_in] = trim($pr_arr['value']);
    		if($paypal_options['os0'] == trim($pr_arr['name'])){
    			//for reservation meta data store
    			$res_post_datas['price'] = trim($pr_arr['value']);
    		}

    		$op_in++;
    	}
    }else{
    	$res_post_datas['price'] = '99';
    	$paypal_options['option_select0'] = 'Default Pass';
    	$paypal_options['option_amount0'] = '99';
    }

    //new discount
    $eventres_use_coupon = get_option('eventres_use_coupon','no' );
    if($eventres_use_coupon === 'yes'){
        $coupon_code = isset($_POST['coupon_code']) ? trim($_POST['coupon_code']) : '';
        if(!empty($coupon_code)){
            // Percent Discount
            $eventres_coupon_codes = get_option('eventres_coupon_codes', array() );
            $discount_rate = 0;
            if(!empty($eventres_coupon_codes)){
                //php 5.5+ only //http://stackoverflow.com/questions/6661530/php-multi-dimensional-array-search
                if(function_exists('array_column')){
                    $coupon_key = array_search($coupon_code, array_column($eventres_coupon_codes, 'name'), true);
                }else{
                    $coupon_key = searchCouponId($coupon_code, $eventres_coupon_codes);
                }
                if($coupon_key) {
                    $discount_rate = (float)$eventres_coupon_codes[$coupon_key]['value'];
                }
                
            }
            if($discount_rate > 0){
                $paypal_options['discount_rate'] = $discount_rate;
            }
            // Fixed Discount
            $eventres_coupon_codes_fixed = get_option('eventres_coupon_codes_fixed', array() );
            $discount_amount = 0;
            if(!empty($eventres_coupon_codes_fixed)){
                //php 5.5+ only //http://stackoverflow.com/questions/6661530/php-multi-dimensional-array-search
                if(function_exists('array_column')){
                    $coupon_key = array_search($coupon_code, array_column($eventres_coupon_codes_fixed, 'name'), true);
                }else{
                    $coupon_key = searchCouponId($coupon_code, $eventres_coupon_codes_fixed);
                }
                if($coupon_key) {
                    $discount_amount  = (float)$eventres_coupon_codes_fixed[$coupon_key]['value'];
                }
                
            }
            if($discount_amount  > 0){
                $paypal_options['discount_amount '] = $discount_amount ;
            }
            
        }
        
    }
    

    

    $res_post_datas['quantity'] = trim($_POST['item_quantity']);

    //$cth_captcha_code = esc_sql($_POST['cth_captcha_code']); 
    if( empty($res_post_datas['first_name'] ) ) {
        $json['message'] = __('First name is required.','cth-gather-plugins');
    }else if( empty( $res_post_datas['last_name'] ) ) {
        $json['message'] = __('Last name is required.','cth-gather-plugins');
    }else if( empty( $res_post_datas['email'] ) ) {
        $json['message'] = __('Email is required.','cth-gather-plugins');
    }else {

        /* event reservation datas */
        $auth_key = defined( 'AUTH_KEY' ) ? AUTH_KEY : '';
        $pur_key = strtolower( md5( $res_post_datas['email'] . date( 'Y-m-d H:i:s' ) . $auth_key . uniqid( 'gatherevent', true ) ) );  // Unique key

        $res_datas = array();
        if(isset($res_post_datas['first_name'])|| isset($res_post_datas['last_name'])){
            $res_datas['post_title'] = $res_post_datas['first_name'] .' '.$res_post_datas['last_name'];
        }else{
            $res_datas['post_title'] = $res_post_datas['email'];
        }
        
        //$res_datas['post_name'] = '';
        $res_datas['post_content'] = '';
        //$res_datas['post_author'] = '0';// default 0 for no author assigned
        $res_datas['post_status'] = 'publish';
        $res_datas['post_type'] = 'cth_eventres';

        $res_meta_datas = array();
        $res_meta_datas['pur_pass']     = trim($_POST['os0']);
        $res_meta_datas['pur_price']     = $res_post_datas['price'];
        $res_meta_datas['pur_quantity']     = $res_post_datas['quantity'];
        $res_meta_datas['pur_date']     = date( 'Y-m-d H:i:s', current_time( 'timestamp' ) );
        $res_meta_datas['pur_currency']     = get_option('eventres_currency' );

        $res_meta_datas['pur_key'] = $pur_key;
        $res_meta_datas['pur_custom'] = uniqid();
        $res_meta_datas['pur_gateway']     = 'Paypal Standard';
        $res_meta_datas['pur_status']     = 'Pending';

        
        $res_meta_datas['pur_fname'] = $res_post_datas['first_name'];
        $res_meta_datas['pur_lname'] = $res_post_datas['last_name'];
        $res_meta_datas['pur_email'] = $res_post_datas['email'];

        $res_id = wp_insert_post($res_datas ,true );
                    

        if (is_wp_error($res_id)) {
            $json['message'] = $res_id->get_error_message();
        }else{
            $eventres_add_fields            = get_option('eventres_add_fields','' );
            if(!empty($eventres_add_fields)){
                foreach ($eventres_add_fields as $key => $field) {
                    $field_name = str_replace(array(" ","-"), "_", $field['name']);
                    if(!isset($res_meta_datas[$field_name])){
                        $res_meta_datas[$field_name] = trim($_POST[$field_name]); 
                    }
                }
            }
            foreach ($res_meta_datas as $key => $value) {
                if ( !add_post_meta( $res_id, $key, $value , true ) ) {
                    $json['message'] = sprintf(__('Insert reservation %s data failure','cth-gather-plugins'),$key);
                    wp_send_json($json );
                }
            }


            // only send to paypal if the pending payment is created successfully
            $listener_url = get_permalink(get_option('eventres_success_page' ) );// trailingslashit( home_url() ).'?cth-listener=IPN';
            $cancel_url = get_permalink(get_option('eventres_cancelled_page' ) );// trailingslashit( home_url() ).'?cth-listener=IPN';
            $return_url = get_permalink(get_option('eventres_return_page' ) );

            // one time payment
            $eventres_test_mode = get_option('eventres_test_mode' );

            if( $eventres_test_mode ) {
                $paypal_redirect = 'https://www.sandbox.paypal.com/cgi-bin/webscr/?';
            } else {
                $paypal_redirect = 'https://www.paypal.com/cgi-bin/webscr/?';
            }
            $paypal_args = array(
                'cmd' => '_xclick',
                //'amount' => $res_post_datas['price'],
                'item_name' => get_option('eventres_item_name' ),
                'item_number' => $res_meta_datas['pur_custom'],
                'quantity' => $res_post_datas['quantity'],
                'currency_code' => get_option('eventres_currency'),
                'custom' => $res_id,
                'business' => get_option('eventres_paypal_email'),
                
                'email' => $res_post_datas['email'],
                'first_name'=>$res_post_datas['first_name'],
                'last_name'=>$res_post_datas['last_name'],
                
                'no_shipping' => '1',
                'no_note' => '1',
                
                 
                'charset' => 'UTF-8',
                
                'rm' => '2',//return method / 2: mean post
                'cancel_return'=>$cancel_url,
                'return' => $return_url,
                'notify_url' => $listener_url
            );
			// merge with $paypal_options array
			$paypal_args = array_merge($paypal_args, $paypal_options);
            $paypal_redirect .= http_build_query($paypal_args);


            $json['success']  = 1;    
            $json['message']  = $paypal_redirect;
        }   

        
    }
    // return proper result
    wp_send_json($json );
}
