$.fbuilder.categoryList[20]={
		title : "Form Controls with Datasource Connection",
		description : "<span style='color:#FF0000;'>List of controls to connect with an external data source: database, CSV file, users data, posts data, and taxonomies data. Only available in the <a href='http://wordpress.dwbooster.com/forms/calculated-fields-form#download' target='_blank'>Developer Version</a> of plugin</span>"
	};
