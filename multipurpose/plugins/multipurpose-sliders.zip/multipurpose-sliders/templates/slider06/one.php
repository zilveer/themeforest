      <article>
        <div class="img"><span class="img-border">%IMG%</span></div>
        <h3><a href="%LINK_URL%">%TITLE%</a></h3>
      </article>

