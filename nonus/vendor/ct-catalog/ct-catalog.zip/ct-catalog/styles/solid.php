<?php
/** Defaults */
//Colors
($btnBgClr=="")? $btnBgClr='#000':$btnBgClr=$btnBgClr;
($btnBgClrHover=="")? $btnBgClrHover='#222':$btnBgClrHover=$btnBgClrHover;
($btnTxtClr=="")? $btnTxtClr='#fff':$btnTxtClr=$btnTxtClr;

//Padding small
($btpTop=="")? $btpTopSmall='8':$btpTopSmall=$btpTop;
($btpRight=="")? $btpRightSmall='20':$btpRightSmall=$btpRight;
($btpBottom=="")? $btpBottomSmall='8':$btpBottomSmall=$btpBottom;
($btpLeft=="")? $btpLeftSmall='20':$btpLeftSmall=$btpLeft;

//Padding
($btpTop=="")? $btpTop='12':$btpTop=$btpTop;
($btpRight=="")? $btpRight='30':$btpRight=$btpRight;
($btpBottom=="")? $btpBottom='12':$btpBottom=$btpBottom;
($btpLeft=="")? $btpLeft='30':$btpLeft=$btpLeft;
?>

<style type="text/css">
    .ct-style-solid.<?php echo $value; ?> {
        background:<?php echo $btnBgClr; ?> !important;
        color: <?php echo $btnTxtClr; ?> !important;
        font-size: 14px !important;
        font-weight: bold !important;
        text-transform: uppercase !important;
        padding: <?php echo $btpTop; ?>px <?php echo $btpRight; ?>px <?php echo $btpBottom; ?>px <?php echo $btpLeft; ?>px !important;
        text-decoration: none !important;
        display: inline-block !important;

        -webkit-box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        -moz-box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -moz-border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -webkit-border-radius: <?php echo $btnRadiusValue; ?>px !important;

        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClr; ?> !important;
        margin: <?php echo $btmTop; ?>px <?php echo $btmRight; ?>px <?php echo $btmBottom; ?>px <?php echo $btmLeft; ?>px !important;
    }

    .ct-style-solid.small.<?php echo $value; ?> {
        font-size: 11px !important;
        padding: <?php echo $btpTopSmall; ?>px <?php echo $btpRightSmall; ?>px <?php echo $btpBottomSmall; ?>px <?php echo $btpLeftSmall; ?>px !important;
        display:block !important;
        text-align: center !important;
    }

    .ct-style-solid.<?php echo $value; ?>:hover, .solid.small.<?php echo $value; ?>:hover {
        background:<?php echo $btnBgClrHover; ?> !important;

        color: <?php echo $btnTxtClrHover; ?> !important;
        text-decoration: none !important;
        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClrHover; ?> !important;
    }
</style>