<?php
class WPBakeryShortCode_Mnky_Button extends WPBakeryShortCode {

}