<?php
vc_map(array(
	"name" => __("Service Box", 'jwsthemes'),
	"base" => "service_box",
	"category" => __('Aqua', 'jwsthemes'),
	"icon" => "tb-icon-for-vc",
	"params" => array(
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => __("Template", 'jwsthemes'),
			"param_name" => "tpl",
			"value" => array(
				"Template 1" => "tpl1",
				"Template 2" => "tpl2",
				"Template 3" => "tpl3",
				"Template 4" => "tpl4",
				"Template 5" => "tpl5",
			),
			"description" => __('Select template in this element.', 'jwsthemes')
		),
		array(
			"type" => "colorpicker",
			"class" => "",
			"heading" => __("Background", 'jwsthemes'),
			"param_name" => "tpl3_bg",
			"value" => "",
			"dependency" => array(
				"element"=>"tpl",
				"value"=>"tpl3"
			),
			"description" => __('Select background color in this element.', 'jwsthemes')
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => __("Template Style", 'jwsthemes'),
			"param_name" => "tpl1_style",
			"value" => array(
				"Image Left" => "img_left",
				"Image Right" => "img_right",
				"Image Top" => "img_top",
			),
			"dependency" => array(
				"element"=>"tpl",
				"value"=> array("tpl1")
			),
			"description" => __('Select template style in this element.', 'jwsthemes')
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Title", 'jwsthemes'),
			"param_name" => "title",
			"value" => "",
			"description" => __("Please, enter title in this element.", 'jwsthemes')
		),
		array(
			"type" => "attach_image",
			"class" => "",
			"heading" => __("Image", 'jwsthemes'),
			"param_name" => "image",
			"value" => "",
			"description" => __("Select box image in this element.", 'jwsthemes')
		),
		array(
			"type" => "textarea",
			"class" => "",
			"heading" => __("Description", 'jwsthemes'),
			"param_name" => "desc",
			"value" => "",
			"description" => __("Please, enter description in this element.", 'jwsthemes')
		),
		array(
			"type" => "colorpicker",
			"class" => "",
			"heading" => __("Description Background", 'jwsthemes'),
			"param_name" => "tpl1_desc_bg",
			"value" => "",
			"dependency" => array(
				"element"=>"tpl",
				"value"=>"tpl1"
			),
			"description" => __('Select background color for description.', 'jwsthemes')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Extra Link", 'jwsthemes'),
			"param_name" => "ex_link",
			"value" => "",
			"description" => __("Please, enter extra link in this element.", 'jwsthemes')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Extra Class", 'jwsthemes'),
			"param_name" => "el_class",
			"value" => "",
			"description" => __ ( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'jwsthemes' )
		),
	)
));
