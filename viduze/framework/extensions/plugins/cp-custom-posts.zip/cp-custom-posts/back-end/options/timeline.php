<?php

	/*
	*	CrunchPress file for Registering Custom Post Types
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		CrunchPress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) CrunchPress
	*	---------------------------------------------------------------------
	*	This file contains all of the necessary functions for the front-end and
	*	back-end to use. You can see the description of each function below.
	*	---------------------------------------------------------------------
	*/


 // Registering Timeline Custom Post Type
 add_action( 'init', 'create_timeline_item' );
	
 function create_timeline_item() {
    register_post_type( 'timeline_item',
        array(
            'labels' => array(
                'name' => 'Timeline',
                'singular_name' => 'Timeline',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Timeline',
                'edit' => 'Edit',
                'edit_item' => 'Edit Timeline',
                'new_item' => 'New Timeline',
                'view' => 'View',
                'view_item' => 'View Timeline',
                'search_items' => 'Search Timeline',
                'not_found' => 'No Timeline found',
                'not_found_in_trash' => 'No Timeline found in Trash',
                'parent' => 'Parent Timeline'
            ),
            'public' => true,
            'menu_position' => 15,
            'supports' => array( 'title', 'editor', 'thumbnail'),
            'taxonomies' => array( '' ),
			'show_in_nav_menus' => false,
            'has_archive' => true
        )
    );
 }

