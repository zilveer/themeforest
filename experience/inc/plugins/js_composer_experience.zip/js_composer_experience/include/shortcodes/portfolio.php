<?php 
if ( class_exists( 'WPBakeryShortCode' ) ) {

	class WPBakeryShortCode_experience_portfolio extends WPBakeryShortCode {
		
		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = null ) {
			
			global $post;
			
			$experience_vc_utilities = new jsComposerExperienceUtilities();
			
			$output = $css_class = $data_fill_screen = '';
			
			extract( shortcode_atts( array(
				'el_class'				=> '',
				'css'					=> '',
				'parallax'				=> '',
				'portfolio_category'	=> '',
				'fill_screen'			=> '',
				'number'				=> ''
			), $atts ) );
			
			$class = $this->getExtraClass( $el_class );			
			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );

			$output .= '<div class="section-content-wrapper'. esc_attr( $css_class ) .'">';
		
				// Number of posts
				if ( intval( $number ) > 0 ) {
					$number = $number;
				} else {
					$number = -1;
				}

				if ( $portfolio_category != "" ) {
					
					$query_args = array(
						'post_type' => array( 'portfolio' ),
						'tax_query' => array(
							array(
								'taxonomy'	=> 'portfolio_category',
								'field'		=> 'name',
								'terms'		=> esc_html( $portfolio_category )
							)
						),
						'posts_per_page' => intval( $number )
					);

				} else {
					
					$query_args = array(
						'post_type' => array( 'portfolio' ),
						'posts_per_page' => intval( $number )
					);

				}

				$portfolio_query = new WP_query( $query_args );
			
				if ( $portfolio_query->have_posts() ) :				
			
					while ( $portfolio_query->have_posts() ) :
					
						$portfolio_query->the_post();
						
						$parallax_image = $video_bg_url = $flexbox_class = '';
						$wrapper_attributes = array();
						$css_classes = array();

						$parallax_speed = '1.5'; // Maybe an option to toggle
						
						if ( has_post_thumbnail() ) {
							$background_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
							$background_image = $background_image[0];
							$parallax_image = $background_image;
						}
						
						if ( ! empty( $parallax ) )  {

							if ( get_post_meta( $post->ID, 'experience_portfolio_item_background_video', true ) != '' ) {
								$video_bg_url = get_post_meta( $post->ID, 'experience_portfolio_item_background_video', true );
							}

							$has_video_bg = ( ! empty( $video_bg_url ) && vc_extract_youtube_id( $video_bg_url ) );

							if ( $has_video_bg ) {
								$parallax_image = $video_bg_url;
								$css_classes[] = 'vc_video-bg-container';	
							}

							if ( ! empty( $parallax ) ) {
								$wrapper_attributes[] = 'data-vc-parallax="'. esc_attr( $parallax_speed ) .'"';
								$css_classes[] = 'vc_general vc_parallax vc_parallax-' . $parallax;
								$css_classes[] = 'js-vc_parallax-o-fixed';
							}

							if ( ! empty( $parallax_image ) ) {
								$wrapper_attributes[] = 'data-vc-parallax-image="' . esc_url( $parallax_image ) . '"';
							}
							if ( ! $parallax && $has_video_bg ) {
								$wrapper_attributes[] = 'data-vc-video-bg="' . esc_url( $video_bg_url ) . '"';
							}
							
						}
						
						// Set colour scheme
						if ( get_post_meta( $post->ID, 'experience_portfolio_item_preview_color_scheme', true ) != "" ) {		
							$css_classes[] = 'color-scheme-'. get_post_meta( $post->ID, 'experience_portfolio_item_preview_color_scheme', true );
						}

						// Set section header size
						if ( $fill_screen == 'true' ) {
							$flexbox_before = '<div class="exp_ie-flexbox-fixer"><div class="exp-full-height exp-flexbox exp-content-middle"><div class="exp-flexbox-inner">';
							$flexbox_after = '</div></div></div>';
						} 
						
						$output .= '<div class="section-header portfolio-item '. esc_attr( implode( ' ', $css_classes ) ) .'" '. implode( ' ', $wrapper_attributes ) .'>';
							
							$output .= $experience_vc_utilities->experienceGetBackground(
								$background_image,
								false,
								false,
								false, 
								false,
								false,
								false
							);							
							
							
							$output .= $flexbox_before;
							
								$output .= '<div class="section-header-content padding-h narrow-width">';
									
									if ( get_post_meta( $post->ID, 'experience_page_label', true ) != "" ) {										
										$output .= '<span class="heading-label">'. wp_kses( get_post_meta( $post->ID, 'experience_page_label', true ), array( 'img' => array( 'src' => array(), 'height' => array(), 'width' => array(), 'alt' => array() ) ) ) .'</span>';
									}
									
									$output .= '<h1 class="heading-title">'. $experience_vc_utilities->experienceResizeText( get_the_title() ) .'</h1>';
									
									$output .= '<a class="vc_btn3" href="'. get_the_permalink() .'">'. esc_html__( "See More", "js_composer_experience" ) .'</a>';
							
								$output .= '</div>';
							
							$output .= $flexbox_after;
							
						$output .= '</div>';
						
					endwhile;

				else :
					
					$output .= '<p>'. esc_html__( "There are no portfolio items to display.", "js_composer_experience" ).'</p>';
					
				endif;
				
				wp_reset_postdata();
				
			$output .= '</div>';
			
			return $output;
		
		}	

	}
	
}


/* --------- PORTFOLIO--------- */

vc_map( array(
	"base"			=> "experience_portfolio",
	"name"			=> esc_html__( "Portfolio", "js_composer_experience" ),
	"description"	=> esc_html__( "Portfolio created from existing Categories", "js_composer_experience" ),
	"class"			=> "",
	"params"		=> array(
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			"type"			=> "textfield",
			'admin_label'	=> true
		),
		
		// Portfolio Category
		array(
			"param_name"	=> "portfolio_category",
			"heading"		=> esc_html__( "Portfolio Category", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the name of the portfolio category to display in this portfolio.", "js_composer_experience" ),
			"type"			=> "textfield",
			'admin_label'	=> true
		),	
		
		// Parallax
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> esc_html__( 'Parallax', 'js_composer_experience' ),
			'param_name' 	=> 'parallax',
			'value' 		=> array(
				esc_html__( 'None', 'js_composer_experience' ) 	=> '',
				esc_html__( 'Simple', 'js_composer_experience' ) 	=> 'content-moving'
			),
			'description' 	=> esc_html__( 'Add parallax effect to portfolio item backgrounds.', 'js_composer_experience' ),			
		),
		
		// Number of Posts
		array(
			"param_name"	=> "number",
			"heading"		=> esc_html__( "Number of Posts", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the number of portfolio items to display. Leave blank to display all portfolio items in the specified category.", "js_composer_experience" ),
			"type"			=> "textfield"
		),
		
		// ----- CSS ----- //
		
		// CSS
		array(
			"param_name" => "css",
			"heading"	 => esc_html__( "CSS", "js_composer_experience" ),
			"type"		 => "css_editor",
			"group"		 => esc_html__( "Design options", "js_composer_experience" )
		)
		
	)
	
) );