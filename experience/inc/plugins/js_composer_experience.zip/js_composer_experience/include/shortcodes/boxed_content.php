<?php 
if ( class_exists( 'WPBakeryShortCode' ) ) {

	class WPBakeryShortCode_experience_boxed_content extends WPBakeryShortCode {		
		
		/**
		 * @param $atts - shortcode attributes
		 * @param @content - shortcode content
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = NULL ) {
		
			$output = $class_to_filter = $css_class = '';
		
			extract( shortcode_atts( array(
				'el_class' 			=> '',
				'css_animation'		=> '',
				'css'				=> ''		
			), $atts ) );
			
			$class_to_filter = $this->getCSSAnimation( $css_animation );
			$class_to_filter .= vc_shortcode_custom_css_class( $css, ' ' ) . $this->getExtraClass( $el_class );
			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );
			
			$output .= '<div class="boxed_content'. esc_attr( $css_class ) .'">';
				$output .= wpb_js_remove_wpautop( $content, true );
			$output .= '</div>';
		
			return $output;			
			
		}
	
	}
	
}
	

/* --------- BOXED CONTENT --------- */

vc_map( array(
	'base' 			=> 'experience_boxed_content',
	'name' 			=> esc_html__( 'Boxed Content', 'js_composer_experience' ),
	'category' 		=> esc_html__( 'Content', 'js_composer_experience' ),
	'description'	=> esc_html__( 'A simple bordered content box', 'js_composer_experience' ),
	'params' 		=> array(
		
		// Extra Class
		array(
			"param_name" 	=> "el_class",
			"heading" 		=> esc_html__( 'Extra class name', 'js_composer_experience' ),
			"description" 	=> esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'js_composer_experience' ),
			"type" 			=> "textfield"
		),
		
		// Content
		array(
			'param_name'	=> 'content',
			'heading'		=> esc_html__( 'Text', 'js_composer_experience' ),
			'type'			=> 'textarea_html',
			'holder'		=> 'div',
			'value'			=> '<p>'. esc_html__( 'Click edit button to change this text.', 'js_composer_experience' ) .'</p>'
		),
		
		// CSS Animation
		array(
			'param_name'	=> 'css_animation',
			'heading' 		=> esc_html__( 'CSS Animation', 'js_composer_experience' ),
			'description' 	=> esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'js_composer_experience' ),
			'type' 			=> 'dropdown',
			'value' 		=> array(
				esc_html__( 'None', 'js_composer_experience' )				=> '',
				esc_html__( 'Top to bottom', 'js_composer_experience' ) 	=> 'top-to-bottom',
				esc_html__( 'Bottom to top', 'js_composer_experience' ) 	=> 'bottom-to-top',
				esc_html__( 'Left to right', 'js_composer_experience' ) 	=> 'left-to-right',
				esc_html__( 'Right to left', 'js_composer_experience' ) 	=> 'right-to-left',
				esc_html__( 'Appear from center', 'js_composer_experience' ) => 'appear'
			),
			"admin_label" 	=> true
		),
		
		// CSS
		array(
			"param_name" => "css",
			"heading"	 => esc_html__( "CSS", "js_composer_experience" ),
			"type"		 => "css_editor",
			"group"		 => esc_html__( "Design options", "js_composer_experience" )
		)
		
	)
) );