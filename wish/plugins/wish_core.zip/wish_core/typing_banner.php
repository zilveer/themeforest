<?php  
//Register "container" content element
vc_map( array(
    "name" => __("Typing Banner", "wish"),
    "description" => __("Animated Typing Banner", 'wish'),
    "controls" => "full",
    "base" => "wish_typing_banner",
    "as_parent" => array('only' => 'wish_typing_banner_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/78VsxUO.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Background Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,
        ),

        /*Text*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Text Font", "wish" ),
            "param_name" => "text_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Text Size", "wish"),
            "param_name" => "text_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("40", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Text Color", "wish" ),
            "param_name" => "text_color",
            "value" => '#333333 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

          array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Highlight Text color", "wish" ),
            "param_name" => "high_color",
            "value" => '#DF4322',
            "description" => __( "Choose highlighted text color", "wish" ),
            "group"         => "Fonts & Colors",
            "admin_label" => false,
         ),

        array(
            "type" => "textfield",
            "heading" => __("Banner Height (in px)", "wish"),
            "param_name" => "height",
            "value" => __("650", 'wish'),
            "admin_label" => false,
        ), 




    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Animated Sentence", "wish"),
    "base" => "wish_typing_banner_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_typing_banner'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "textfield",
            "heading" => __("The Text", "wish"),
            "param_name" => "title",
            "description" => __("The animated text", "wish"),
            "value" => __("Are you satisfied with your current hosting provider?", 'wish'),
            "admin_label" => true,
        ), 

    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Typing_Banner extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'image'   => 'Image',
        'text_font' => '',
        'text_size' => '40',
        'text_color'  => '#333333',
        'high_color' => '#DF4322',
        'height'    => '650',
      ), $atts ) );

        $decode_font = urldecode($text_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $text_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

      $img = wp_get_attachment_image_src( $image, 'full' );

      if($image == "Image"){
        $img[0] = plugins_url('images/office.png', __FILE__);
      }

      wp_enqueue_script('wish-typed-js', plugins_url('assets/typed.js', __FILE__), array('jquery') );

      $input = rtrim(do_shortcode($content), "`");
      $text = explode( "`", $input);

      $str = "";

      foreach ($text as $key => $value) {
          $str .= "'{$value}', ";
      }

      $str = rtrim($str, ",");
     
      $output = "<div class='typing-banner' style='background-image:url({$img[0]});height:{$height}px;'>
                    <div class='row'>
                        <div class='typing-text'>
                              <h3 style='font-family:{$text_font_family};font-size:{$text_size}px;color:{$text_color};'></h3>
                        </div>      
                    </div>
                </div>

                <script>
                        jQuery(function(){
                            jQuery('.typing-banner h3').typed({
                                strings: [{$str}],
                                typeSpeed: 0,
                                loop: true,
                                typeSpeed: 20,
                                backDelay: 2000,
                            });
                        });

                </script>
                <style>
                .typing-text h3 span{color:{$high_color};}
                </style>
                ";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class
if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Typing_Banner_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'title'   => 'Are you satisfied with your current hosting provider?',
          ), $atts ) );
          
          $title = wish_line2Span($title);
          $output = "{$title}`";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>