<?php

/* ************************************************************************************** 
	Portfolio Post Type
************************************************************************************** */

add_action( 'init', 'swm_posttype_portfolio' );
if (!function_exists('swm_posttype_portfolio')) {
	function swm_posttype_portfolio() {	
		$labels = array(
			'name' => __( 'Portfolio', 'swmtranslate'),
			'singular_name' => __( 'Portfolio', 'swmtranslate'),
			'add_new' =>  __( 'Add New' , 'swmtranslate'),
			'add_new_item' => __('Add New Portfolio', 'swmtranslate'),
			'edit_item' => __('Edit Portfolio', 'swmtranslate'),
			'new_item' => __('New Portfolio Item', 'swmtranslate'),
			'view_item' => __('View Portfolio Item', 'swmtranslate'),
			'search_items' => __('Search Portfolio Items', 'swmtranslate'),
			'not_found' =>  __('No portfolio items found', 'swmtranslate'),
			'not_found_in_trash' => __('No portfolio items found in Trash', 'swmtranslate'),
			'parent_item_colon' => ''
		);
		  
		$args = array(
			'labels' => $labels,
			'public' => true,
			'exclude_from_search' => false,
			'publicly_queryable' => true,
			'rewrite' => array('slug' => 'portfolios'),
			'show_ui' => true, 
			'query_var' => true,
			'capability_type' => 'post',
			'hierarchical' => false,		
			'menu_position' => null,
			'supports' => array('title','editor','thumbnail','excerpt','comments')
		); 
		  
		register_post_type(__( 'portfolio' , 'swmtranslate'),$args);	
		
	}
}	
/* ------------------------------------------------------------------------------ */	

add_action( 'init', 'swm_posttype_portfolio_taxonomies', 0 );
if (!function_exists('swm_posttype_portfolio_taxonomies')) {
	function swm_posttype_portfolio_taxonomies(){
		
		register_taxonomy(__( "portfolio-categories" , 'swmtranslate'), 
			array(__( "portfolio" , 'swmtranslate'),), 
			array(
				"hierarchical" => true, 
				"query_var" => true,
				"rewrite" => array(
					'slug' => 'portfolio-categories', 
					'hierarchical' => true, 
					'with_front' => false )
			)); 
		
	}
}	
/* ------------------------------------------------------------------------------ */
 
add_filter("manage_edit-portfolio_columns", "swm_posttype_portfolio_edit_columns"); 
if (!function_exists('swm_posttype_portfolio_edit_columns')) {
	function swm_posttype_portfolio_edit_columns($columns){  
		$columns = array(  
			"cb" => "<input type=\"checkbox\" />",  
			"title" => __( 'Portfolio Item Title' , 'swmtranslate'),			
			"Category" => __( 'Category' , 'swmtranslate'),			
			"Image" => __( 'Image' , 'swmtranslate'),
			'date' => __( 'Date', 'swmtranslate')
		); 
		return $columns;  
	} 
}	
/* ------------------------------------------------------------------------------ */
	
add_action("manage_posts_custom_column",  "swm_posttype_portfolio_image_column");	
if (!function_exists('swm_posttype_portfolio_image_column')) {
	function swm_posttype_portfolio_image_column($column){  
		global $post;  
		switch ($column)  { 

			case 'Category':  
				echo wp_strip_all_tags( get_the_term_list($post->ID, 'portfolio-categories', '', ', ',''));  
				break;		
				
			case 'Image':  
				echo get_the_post_thumbnail($post->ID, array(80,80));  
				break;
		}  
	}
}
/* Edit "Featured Image" box text --------------------------------------------------- */

add_filter( 'gettext', 'portfolio_post_edit_change_text', 20, 3 );
if (!function_exists('portfolio_post_edit_change_text')) {
	function portfolio_post_edit_change_text( $translated_text, $text, $domain ) {
	    if( ( is_portfolio_admin_page() ) ) {
	        switch( $translated_text ) {
	        case 'Featured Image' :
	            $translated_text = __( 'Add Portfolio Image', 'circle-carousel' );
	        break;
	        case 'Set Featured Image' :
	            $translated_text = __( 'Set portfolio image', 'circle-carousel' );
	        break;
	        case 'Set featured image' :
	            $translated_text = __( 'Set portfolio image', 'circle-carousel' );
	        break;
	        case 'Remove featured image' :
	            $translated_text = __( 'Remove portfolio image', 'circle-carousel' );
	        break;
	        }
	    }
	    return $translated_text;
	}
}
if (!function_exists('is_portfolio_admin_page')) {
	function is_portfolio_admin_page() {
	    global $pagenow;

	    if( $pagenow == 'post-new.php' ) {
	        if( isset( $_GET['post_type'] ) && $_GET['post_type'] == 'portfolio' )
	            return true;
	    }

	    if( $pagenow == 'post.php' ) {
	        if( isset( $_GET['post'] ) && get_post_type( $_GET['post'] ) == 'portfolio' )
	            return true;
	    }
	    return false;
	}
}
if( defined( 'DOING_AJAX' ) && 'DOING_AJAX' ) {
    if( isset( $_POST['post_id'] ) && get_post_type( $_POST['post_id'] ) == 'portfolio' )
        return true;
}

