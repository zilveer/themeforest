<?php 
if ( class_exists( 'WPBakeryShortCode' ) ) {

	class WPBakeryShortCode_experience_custom_gallery extends WPBakeryShortCodesContainer {
		
		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = null ) {
			
			$output = $css = $css_class = $remove_spacing = '';
		
			extract( shortcode_atts( array(
				'el_class'			=> '',
				'remove_spacing'	=> '',
				'css'				=> ''
			), $atts ) );
			
			$class = $this->getExtraClass( $el_class );
			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );
			
			if ( $remove_spacing == 'true' ) {
				$remove_spacing = 'no-spacing ';
			} else {
				$remove_spacing = '';				
			}
			
			$output .= '<div class="gallery gallery-columns-4 '. esc_attr( $remove_spacing . $css_class ) .'">';
		
				$output .= wpb_js_remove_wpautop($content);
			
			$output .= '</div>';
			
			return $output;
		
		}
		
	}

	// ---------- MEDIA GALLERY ITEM ---------- //

	class WPBakeryShortCode_experience_custom_gallery_item extends WPBakeryShortCode {
		
		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = null ) {
	
			$output = $path_info = $url_info = $image_src = $thumbnail = $fancybox_class = $fancybox_data_type = '';
			
			extract( shortcode_atts( array(
				'title'		=> '',
				'image'		=> '',
				'url'		=> ''				
			), $atts ) );
			
			// Check if the URL is a valid video( MP4, WebM, YouTube, Vimeo, Dailymotion)
			if ( $url != '' ) {
			
				$url = vc_build_link( $url );
				
				// Detect lightbox content type
				$path_info = pathinfo( $url['url'] );
				$url_info = parse_url( $url['url'] );

				// MP4 / WEBM
				if (
					(
						isset( $path_info['extension'] )
						&& in_array( $path_info['extension'], array( 'mp4', 'webm' ) )
					)
					|| (
						isset( $url_info['host'] )
						&& ( 
							$url_info['host'] == 'www.youtube.com' || $url_info['host'] == 'youtube.com' || $url_info['host'] == 'youtu.be'
							|| $url_info['host'] == 'www.vimeo.com' || $url_info['host'] == 'vimeo.com'
							|| $url_info['host'] == 'www.dailymotion.com' || $url_info['host'] == 'dailymotion.com'
						)
					)
				) {
					
					$fancybox_class = 'class="fancybox"';
					$fancybox_data_type = 'data-fancybox-type="html"';
					
				}
				
			} else {
			
				$image_src = wp_get_attachment_image_src( $image, 'large' );
				$url['url'] = $image_src[0];
				$fancybox_class = 'class="fancybox"';
				$fancybox_data_type = 'data-fancybox-type="image"';
			
			}
			
			if ( $image != '' ) {
				$thumbnail = wp_get_attachment_image_src( $image, 'post-grid' );
				$thumbnail = $thumbnail[0];			
			}
			
			$output .= '<figure class="gallery-item">
							<div class="gallery-icon landscape">
								<a '. $fancybox_class .' href="'. esc_url( $url['url'] ) .'" target="'. esc_attr( $url['target'] ) .'" '. $fancybox_data_type .' data-fancybox-group="media-gallery">
									<img class="attachment-thumbnail" src="'. esc_url( $thumbnail ) .'" />
								</a>
							</div>
							<figcaption class="gallery-caption">
								<div class="wp-caption-content">';
									
									if ( $title != '' ) {
										$output .= '<h3>'. esc_html( $title ) .'</h3>';
									} else { 
										$output .= '<span class="view"></span>';
									}
								
								$output .= '</div>
							</figcaption>
						</figure>';
			
			return $output;
		
		}
		
	}
	
}

/* --------- MEDIA GALLERY --------- */

vc_map( array(
	"base"						=> "experience_custom_gallery",
	"name"						=> esc_html__( "Gallery Custom", "js_composer_experience" ),
	"description"				=> esc_html__( "Grid of images and/or videos", "js_composer_experience" ),
	"as_parent"					=> array( "only" => "experience_media_gallery_item" ),
	"content_element"			=> true,
	"show_settings_on_create"	=> false,
	"js_view"					=> "VcColumnView",
	"params"					=> array(
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			"type"			=> "textfield",
			'admin_label'	=> true
		),
		
		// CSS
		array(
			"param_name" => "css",
			"heading"	 => esc_html__( "CSS", "js_composer_experience" ),
			"type"		 => "css_editor",
			"group"		 => esc_html__( "Design options", "js_composer_experience" )
		)
		
	)

) );


/* --------- MEDIA GALLERY ITEM --------- */

vc_map( array(
	"base"				=> "experience_custom_gallery_item",
	"name"				=> esc_html__( "Gallery Item", "js_composer_experience" ),
	"description"		=> esc_html__( "Individual grid for media gallery grid.", "js_composer_experience" ),
	"as_child"			=> array( "only" => "experience_media_gallery" ),
	"params"			=> array(
		
		// Title
		array(
			"param_name"	=> "title",
			"heading"		=> esc_html__( "Title", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the gallery item title.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label"	=> true
		),
		
		// Image
		array(
			"param_name"	=> "image",
			"heading"		=> esc_html__( "Image", "js_composer_experience" ),
			"description"	=> esc_html__( "Select the gallery item image. This is used as the grid thumbnail for the gallery item as well as the link when no 'url' parameter is found.", "js_composer_experience" ),
			"type"			=> "attach_image",
			"admin_label"	=> true			
		),
		
		// URL
		array(
			"param_name"	=> "url",
			"heading"		=> esc_html__( "URL", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the URL this gallery item should link to. If left blank the gallery item image will be used. If a valid video path (MP4, WebM, YouTube, Vimeo or Dailymotion) is added the video player will be opened in a lightbox.", "js_composer_experience" ),
			"type"			=> "vc_link",
			"admin_label"	=> true
		)

	)

) );