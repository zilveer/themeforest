<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Pricing Table", "wish"),
    "description" => __("Pricing Table with Details", 'wish'),
    "controls" => "full",
    "base" => "wish_pricing_table",
    "as_parent" => array('only' => 'wish_pricing_table_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/4ohAiy3.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element

         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#fff', //Default Red color
            "description" => __( "Choose the background color", "wish" )
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Pricing Table Item", "wish"),
    "base" => "wish_pricing_table_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_pricing_table'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
                "type" => "textfield",
                "heading" => __("Package", "wish"),
                "param_name" => "package",
                "description" => __("The Package.", "wish"),
                "value" => __("PERSONAL", 'wish'),
                "admin_label" => true,
        ),


        /*Package*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Package Text Font", "wish" ),
            "param_name" => "package_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Package Size", "wish"),
            "param_name" => "package_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("22", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Package Text Color", "wish" ),
            "param_name" => "package_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        array(
                "type" => "textfield",
                "heading" => __("Price", "wish"),
                "param_name" => "price",
                "description" => __("The Price.", "wish"),
                "value" => __("19", 'wish'),
                "admin_label" => true,
        ),

        /*Price*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Price Text Font", "wish" ),
            "param_name" => "price_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Price Size", "wish"),
            "param_name" => "price_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("90", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Price Text Color", "wish" ),
            "param_name" => "price_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        array(
                "type" => "textfield",
                "heading" => __("Duration", "wish"),
                "param_name" => "duration",
                "description" => __("Duration.", "wish"),
                "value" => __("Per Month", 'wish'),
                "admin_label" => true,
        ),


        /*Duration*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Duration Text Font", "wish" ),
            "param_name" => "duration_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Duration Size", "wish"),
            "param_name" => "duration_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Duration Text Color", "wish" ),
            "param_name" => "duration_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),
        array(
                "type" => "textarea",
                "holder" => "div",
                "class" => "",
                "heading" => __("Details", 'wish'),
                "param_name" => "content",
                "value" => __("20 Pages, Galleries, and Blogs with 500 GB Bandwidth, 2 GB Storage, and 2 Contributors", 'wish'),
                "description" => __("Details", 'wish')
        ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("16", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        array(
                "type" => "textfield",
                "heading" => __("Field 1", "wish"),
                "param_name" => "field1",
                "description" => __("", "wish"),
                "value" => __("Fully Integrated E-Commerce", 'wish'),
                "admin_label" => true,
        ),

        array(
                "type" => "textfield",
                "heading" => __("Field 2", "wish"),
                "param_name" => "field2",
                "description" => __("", "wish"),
                "value" => __("Sell 5 Product & Accept Donations", 'wish'),
                "admin_label" => true,
        ),

        array(
                "type" => "textfield",
                "heading" => __("Field 3", "wish"),
                "param_name" => "field3",
                "description" => __("", "wish"),
                "value" => __("Mobile Website and Store", 'wish'),
                "admin_label" => true,
        ),
        array(
                "type" => "textfield",
                "heading" => __("Field 4", "wish"),
                "param_name" => "field4",
                "description" => __("", "wish"),
                "value" => __("Domain Custom FREE", 'wish'),
                "admin_label" => true,
        ),
        array(
                "type" => "textfield",
                "heading" => __("Field 5", "wish"),
                "param_name" => "field5",
                "description" => __("", "wish"),
                "value" => __("24/7 Support", 'wish'),
                "admin_label" => true,
        ),


        /*Fields*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Fields Text Font", "wish" ),
            "param_name" => "fields_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Fields Size", "wish"),
            "param_name" => "fields_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Fields Text Color", "wish" ),
            "param_name" => "fields_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        array(
            "type" => "vc_link",
             "holder" => "div",
             "class" => "",
             "heading" => __("Link To The Page", 'wish'),
             "param_name" => "link",
             "description" => __("The Link below the text", 'wish'),
             "admin_label" => false,
         ),

         array(
              "type" => "textfield",
              "heading" => __("Link Title", "wish"),
              "param_name" => "link_text",
              "description" => __("The Link Title", "wish"),
              "value" => __("Choose", 'wish'),
              "admin_label" => false,
         ),





    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Pricing_Table extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'bgcolor'   => '#fff',
          ), $atts ) );


      $output = "<div class='pricing-table'>
                    " . do_shortcode($content) . "
            </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Pricing_Table_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image'   => 'Image',
            
            'package'       => 'PERSONAL',
            'package_font'  => '',
            'package_size'  => '22',
            'package_color' => '#000',

            'price'       => '19',
            'price_font'  => '',
            'price_size'  => '90',
            'price_color' => '#000',

            'duration'        => 'Per Month',
            'duration_font'   => '',
            'duration_size'   => '14',
            'duration_color'  => '#000',

            'details'       => '20 Pages, Galleries, and Blogs with 500 GB Bandwidth, 2 GB Storage, and 2 Contributors',
            'details_font'  => '',
            'details_size'  => '16',
            'details_color' => '#000',

            'field1'  => 'Fully Integrated E-Commerce',
            'field2'  => 'Sell 5 Product & Accept Donations',
            'field3'  => 'Mobile Website and Store',
            'field4'  => 'Domain Custom FREE',
            'field5'  => '24/7 Support',

            'fields_font' => '',
            'fields_size' => '14',
            'fields_color'=> '#000',

            'link'      => '',
            'link_text' => 'Choose'


          ), $atts ) );

        /*Package*/
        $decode_font = urldecode($package_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $package_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*Price*/
        $decode_font = urldecode($price_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $price_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*Duration*/
        $decode_font = urldecode($duration_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $duration_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Fileds*/
        $decode_font = urldecode($fields_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $fields_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



        if($link == "||" || $link == "" ){
            
            $link_text = "Choose";
            $link_url = "#";
            $link_target = "";
            $link_string = "";

          }else{

            $link = vc_build_link($link); //parse the link
            $link_url = esc_url($link["url"]);
            $link_target = esc_attr($link["target"]);
            if ($link_text == "") {
                $link_string = "";
            }
            else{
                $link_string = "<div class='buttons'><a href='{$link_url}' class='nofill'>{$link_text}</a></div>";
            }

          }


          $output = "<div class='col-lg-4 col-md-4 price-block'>
                      <div class='row'>
                        <div class='col-lg-4 animated' data-animation='fadeInRight' data-animation-delay='300'>
                          <div class='info'>
                            <div class='package' style='font-family:{$package_font_family};font-size:{$package_size}px;color:{$package_color}'>{$package}</div>
                            <div class='price' style='font-family:{$price_font_family};font-size:{$price_size}px;color:{$price_color}'><span class='c-sign'>$</span>{$price}</div>
                            <div class='duration' style='font-family:{$duration_font_family};font-size:{$duration_size}px;color:{$duration_color}'>{$duration}</div>
                          </div>
                        </div>
                        <div class='col-lg-8 animated' data-animation='fadeInLeft' data-animation-delay='300'>
                          <div class='details'>
                            <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}</div>
                            <ul class='features'>
                              <li style='font-family:{$fields_font_family};font-size:{$fields_size}px;color:{$fields_color}'>{$field1}</li>
                              <li style='font-family:{$fields_font_family};font-size:{$fields_size}px;color:{$fields_color}'>{$field2}</li>
                              <li style='font-family:{$fields_font_family};font-size:{$fields_size}px;color:{$fields_color}'>{$field3}</li>
                              <li style='font-family:{$fields_font_family};font-size:{$fields_size}px;color:{$fields_color}'>{$field4}</li>
                              <li style='font-family:{$fields_font_family};font-size:{$fields_size}px;color:{$fields_color}'>{$field5}</li>
                            </ul>
                            {$link_string}
                          </div>
                        </div>
                      </div>
                    </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>