<?php
if( !defined('_MULTIPURPOSE_SHORTCODE')) die('Access denied');

// shortcode Divider
add_shortcode('divider','multipurpose_divider');

function multipurpose_divider($attr, $content = null) {
	extract(shortcode_atts(array('type' => false), $attr));
	$class = "d" . $type;
	if($type == 7) {
		$html = '<div class="divider ' . $class . '"><span class="text-box"><span class="line"></span><span class="text">' . $content . '</span></span></div>';
	} else {
		$html = '<div class="divider ' . $class . '"></div>';
	}
	return $html;
}

