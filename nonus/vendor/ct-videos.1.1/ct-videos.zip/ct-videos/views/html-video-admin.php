<?php
/**
 * Outputs a video admin panel
 * @author: createIT
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

do_action('ct_woovideo_admin_panel_metabox');

?>
<div class="ct-woovideo-woocommerce-video wc-metabox closed">
    <h3>
        <button type="button" class="ct-woovideo-remove-video button" rel="<?php echo esc_attr( $video['_id'] ); ?>"><?php esc_attr_e( 'Remove', 'ct-woovideo' ); ?></button>
        <div class="handlediv" title="<?php esc_attr_e( 'Click to toggle', 'ct-woovideo' ); ?>"></div>
        <strong><?php echo esc_html( $video['_title'] ); ?></strong>

        <input type="hidden" autocomplete="off" class="ct-woovideo-post-id" name="ct_woovideo_post_id[<?php echo esc_attr($loop); ?>]" value="<?php echo esc_attr( $video['_id'] ); ?>" />
        <input type="hidden" autocomplete="off" class="ct-woovideo-video-position" name="ct_woovideo_position[<?php echo esc_attr($loop); ?>]" value="<?php echo esc_attr($loop); ?>" />
    </h3>

    <div class="ct-woovideo-attributes wc-metabox-content">
        <div class="data">
            <p class="form-field">
                <label><?php esc_html_e( 'Video Title', 'ct-woovideo' ); ?></label>
                <input type="text" autocomplete="off" name="ct_woovideo_title[<?php echo esc_attr($loop); ?>]" value="<?php if ( !empty( $video['_title'] ) ) echo esc_attr( $video['_title']); ?>" class="ct-woovideo-input-video" />
            </p>
            <div class="ct-woovideo-video-settings">

                <div class="ct-woovideo-source">
                    <div class="ct-woovideo-external-url">
                        <p class="form-field<?php echo (get_option('wc_ct_woovideo_iframe_enabled') != 'on') ? ' hidden' : ''?>">
                            <label><?php esc_html_e( 'Generic iframe', 'ct-woovideo' ); ?></label>
                            <input type="text" autocomplete="off" size="5" name="ct_woovideo_iframe_url[<?php echo esc_attr($loop); ?>]" value="<?php if ( isset( $video['_iframe_url'] ) ) echo esc_url( $video['_iframe_url'] ); ?>" class="ct-woovideo-input-iframe" placeholder="<?php esc_html_e( 'Iframe URL', 'ct-woovideo' ); ?>"/>
                            <a class="tips" data-tip="<?php esc_attr_e( 'Enter a link for your iframe. Make sure that you use a trusted source.', 'ct-woovideo' ); ?>" href="#">[?]</a>
                        </p>
                        <p class="form-field">
                            <label><?php esc_html_e( 'Enter external video URL', 'ct-woovideo' ); ?></label>
                            <input type="text" autocomplete="off" size="5" name="ct_woovideo_external_video_url[<?php echo esc_attr($loop); ?>]" value="<?php if ( isset( $video['_external_url'] ) ) echo esc_url( $video['_external_url'] ); ?>" class="ct-woovideo-input-video" placeholder="<?php esc_html_e( 'Video URL', 'ct-woovideo' ); ?>" />
                            <a class="tips" data-tip="<?php esc_attr_e( 'Like Youtube or Vimeo', 'ct-woovideo' ); ?>" href="#">[?]</a>
                        </p>
                    </div>
                    <div class="ct-woovideo-upload-videos">
                        <p class="form-field ct-woovideo-upload-video">
                            <label><?php esc_html_e( 'Or upload a video', 'ct-woovideo' ); ?><a class="tips" data-tip="<?php esc_attr_e( 'Upload mp4 and at least one of two others to make sure it will play on every device', 'ct-woovideo' ); ?>" href="#">[?]</a></label>
                            <a href="#" class="button ct-woovideo-upload-video-button" rel="<?php echo esc_attr( $video['_id'] ); ?>"><?php esc_html_e( 'Upload .mp4 video', 'ct-woovideo' );?>
                                <input type="hidden" autocomplete="off" name="ct_upload_video_mp4_id[<?php echo esc_attr($loop); ?>]" class="ct-woovideo-upload-video-id" value="<?php echo esc_attr( $video['_upload_video_mp4_id'] ); ?>" />
                            </a>
                            <span class="ct-woovideo-upload-video-name">
                                <?php echo (!empty($video['_upload_video_mp4_name'] )) ? esc_html($video['_upload_video_mp4_name']) : ''?>
                            </span>
                            <input type="hidden" autocomplete="off" name="ct_upload_video_mp4_name[<?php echo esc_attr($loop); ?>]" class ="ct-woovideo-upload-video-name-input" value="<?php echo esc_attr( $video['_upload_video_mp4_name'])?>"/>
                            <a href="#" class="ct-woovideo-remove-uploaded-video-button <?php if(!empty($video['_upload_video_mp4_name'])) echo 'remove'?>" rel="<?php echo esc_attr( $video['_id'] ); ?>"></a>
                        </p>

                        <p class="form-field ct-woovideo-upload-video">
                            <a href="#" class="button ct-woovideo-upload-video-button" rel="<?php echo esc_attr( $video['_id'] ); ?>"><?php esc_html_e( 'Upload .webm video', 'ct-woovideo' );?>
                                <input type="hidden" autocomplete="off" name="ct_upload_video_webm_id[<?php echo esc_attr($loop); ?>]" class="ct-woovideo-upload-video-id" value="<?php echo esc_attr( $video['_upload_video_webm_id'] ); ?>" />
                            </a>
                            <span class="ct-woovideo-upload-video-name">
                                <?php echo (!empty($video['_upload_video_webm_name'])) ? esc_html($video['_upload_video_webm_name']) : '' ?>
                            </span>
                            <input type="hidden" autocomplete="off" name="ct_upload_video_webm_name[<?php echo esc_attr($loop); ?>]" class ="ct-woovideo-upload-video-name-input" value="<?php echo $video['_upload_video_webm_name']?>"/>
                            <a href="#" class="ct-woovideo-remove-uploaded-video-button <?php if(!empty($video['_upload_video_webm_name'])) echo 'remove'?>" rel="<?php echo esc_attr( $video['_id'] ); ?>"></a>
                        </p>

                        <p class="form-field ct-woovideo-upload-video">
                            <a href="#" class="button ct-woovideo-upload-video-button" rel="<?php echo esc_attr( $video['_id'] ); ?>"><?php esc_html_e( 'Upload .ogg video', 'ct-woovideo' );?>
                                <input type="hidden" autocomplete="off" name="ct_upload_video_ogg_id[<?php echo esc_attr($loop); ?>]" class="ct-woovideo-upload-video-id" value="<?php echo esc_attr( $video['_upload_video_ogg_id'] ); ?>" />
                            </a>
                            <span class="ct-woovideo-upload-video-name">
                                <?php echo (!empty($video['_upload_video_ogg_name'])) ? esc_html($video['_upload_video_ogg_name']) : ''?>
                            </span>
                            <input type="hidden" autocomplete="off" name="ct_upload_video_ogg_name[<?php echo esc_attr($loop); ?>]" class ="ct-woovideo-upload-video-name-input" value="<?php echo $video['_upload_video_ogg_name']?>"/>
                            <a href="#" class="ct-woovideo-remove-uploaded-video-button <?php if(!empty($video['_upload_video_ogg_name'])) echo 'remove'?>" rel="<?php echo esc_attr( $video['_id'] ); ?>"></a>
                        </p>
                    </div>
                </div>
                <div class="ct-woovideo-inline-video-settings">
                    <div class="ct-woovideo-video-location">
                        <div class="options_group ct-woovideo-main-location">
                            <p class="form-field">
                            <label><?php esc_html_e( 'Video location', 'ct-woovideo' ); ?> <a class="tips" data-tip="<?php esc_attr_e( 'Choose the location to display the video on the product page.', 'ct-woovideo' ); ?>" href="#">[?]</a></label>
                            <select class="ct-woovideo-select-location" name="ct_woovideo_location[<?php echo esc_attr($loop); ?>]" autocomplete="off">
                                <option value="tab" class="ct-woovideo-location-option" <?php selected( $video['_location'], 'tab' ); ?> ><?php esc_html_e("Tab", "ct-woovideo" );?></option>
                                <option value="image_gallery" class="ct-woovideo-location-option" <?php selected( $video['_location'], 'image_gallery' ); ?> rel="<?php echo esc_attr( $video['_id'] ); ?>"><?php esc_html_e("Image Gallery", "ct-woovideo" );?></option>
                                <option value="button" class="ct-woovideo-location-option" <?php selected( $video['_location'], 'button' ); ?>><?php esc_html_e("Popup Button", "ct-woovideo" );?></option>
                                <option value="shortcode" class="ct-woovideo-location-option" <?php selected( $video['_location'], 'shortcode' ); ?>><?php esc_html_e("Shortcode", "ct-woovideo" );?></option>
                            </select>
                            <button type="button" class="ct-woovideo-restore-video-defaults button" rel="<?php echo esc_attr( $video['_id'] ); ?>"><?php esc_html_e( 'Restore default video settings', 'ct-woovideo' ); ?></button><a class="tips" data-tip="<?php esc_attr_e( 'Set the defaults in WooCommerce -> Settings -> WooVideo -> Video default settings.', 'ct-woovideo' ); ?>" href="#">[?]</a>
                            </p>
                            <p class="ct-woovideo-shortcode-info <?php echo ($video['_location'] != 'shortcode') ? 'hidden' : '' ?>">
                                <?php esc_html_e( 'Paste this shortcode on your product page to display the video: ', 'ct-woovideo' )?><span class="ct-woovideo-shortcode"><?php echo (isset($video['_video_shortcode'])) ? $video['_video_shortcode'] : ''; ?></span>
                                <input type="hidden" class="ct-woovideo-shortcode-input" autocomplete="off" name="ct_woovideo_shortcode[<?php echo esc_attr($loop); ?>]" value="<?php echo (isset($video['_video_shortcode'])) ? $video['_video_shortcode'] : ''; ?>"/>
                            </p>
                            <p class="form-field ct-woovideo-gallery-location <?php echo ($video['_location'] != 'image_gallery') ? 'hidden' : '' ?>">
                                <label><?php esc_html_e( 'Gallery video location', 'ct-woovideo' ); ?> <a class="tips" data-tip="<?php esc_attr_e( 'Choose where the gallery videos will display.', 'ct-woovideo' ); ?>" href="#">[?]</a></label>
                                <select class="ct-woovideo-gallery-location" name="ct_woovideo_gallery_location[<?php echo esc_attr($loop); ?>]" autocomplete="off">
                                    <option value="above" class="ct-woovideo-gallery-location-option" <?php selected( $video['_gallery_location'], 'above' ); ?> ><?php esc_html_e("Above Gallery", "ct-woovideo" );?></option>
                                    <option value="in" class="ct-woovideo-gallery-location-option" <?php selected( $video['_gallery_location'], 'in' ); ?> ><?php esc_html_e("Instead of Main Image", "ct-woovideo" );?></option>
                                </select>
                            </p>
                            <p class="form-field"><label for="ct_woovideo_video_location_priority[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Location priority', 'ct-woovideo' ); ?><a class="tips" data-tip="<?php esc_attr_e( 'Set to zero for auto positioning', 'ct-woovideo' ); ?>" href="#">[?]</a></label>
                            <input type="number" autocomplete="off" name="ct_woovideo_video_location_priority[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_video_location_priority'] ) ) ? esc_attr( $video['_video_location_priority'] ) : '1'; ?>"/>
                            </p>

                        </div>

                    </div>

                    <p class="form-field">
                        <label for="ct_woovideo_video_class[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Add a custom video class', 'ct-woovideo' ); ?></label>
                        <input type="text" autocomplete="off" name="ct_woovideo_video_class[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_custom_video_class'] ) ) ? esc_attr( $video['_custom_video_class'] ) : ''; ?>"/>

                    </p>



                    <div class="ct-woovideo-video-player">

                        <p class="form-field">
                            <label for="ct_woovideo_player_height[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Video (max) height:', 'ct-woovideo' ); ?></label>
                            <input type="number" autocomplete="off" name="ct_woovideo_player_height[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_player_height'] ) ) ? esc_attr( $video['_player_height'] ) : '0'; ?>"/>
                            <a class="tips" data-tip="<?php esc_attr_e( 'Set to 0 for auto scaling', 'ct-woovideo' ); ?>" href="#">[?]</a>
                        </p>
                        <p class="form-field">
                            <label for="ct_woovideo_player_width[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Video (max) width:', 'ct-woovideo' ); ?></label>
                            <input type="number" autocomplete="off" name="ct_woovideo_player_width[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_player_width'] ) ) ? esc_attr( $video['_player_width'] ) : '0'; ?>"/>
                            <a class="tips" data-tip="<?php esc_attr_e( 'Set to 0 for auto scaling', 'ct-woovideo' ); ?>" href="#">[?]</a>
                        </p>
                    </div>
                    <p class="form-field ct-woovideo-video-autoplay">
                        <label for="ct_woovideo_video_autoplay[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Autoplay ', 'ct-woovideo' ); ?><a class="tips" data-tip="<?php esc_attr_e( 'Enable autoplay?', 'ct-woovideo' ); ?>" href="#">[?]</a></label>
                        <input type="checkbox" autocomplete="off" name="ct_woovideo_video_autoplay[<?php echo esc_attr($loop); ?>]" <?php checked( $video['_video_autoplay'] == 'on' ); ?>/>
                    </p>
                    <p class="form-field">
                        <label for="ct_woovideo_video_align[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Video align', 'ct-woovideo' ); ?></label>
                        <select name="ct_woovideo_video_align[<?php echo esc_attr($loop); ?>]">
                            <option value="none" <?php selected( $video['_video_align'], 'none' ); ?>><?php esc_html_e( 'None', 'ct-woovideo' ); ?></option>
                            <option value="left" <?php selected( $video['_video_align'], 'left' ); ?>><?php esc_html_e( 'Left', 'ct-woovideo' ); ?></option>
                            <option value="right" <?php selected( $video['_video_align'], 'right' ); ?>><?php esc_html_e( 'Right', 'ct-woovideo' ); ?></option>
                        </select>
                    </p>
                    <p class="form-field">
                        <label for="ct_woovideo_video_clearing[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Video clearing', 'ct-woovideo' ); ?><a class="tips" data-tip="<?php esc_attr_e( 'Allow floating elements on the sides of the video?', 'ct-woovideo' ); ?>" href="#">[?]</a></label>
                        <input type="checkbox" class ="ct-woovideo-video-clearing" autocomplete="off" name="ct_woovideo_video_clearing[<?php echo esc_attr($loop); ?>]" <?php checked( $video['_video_clearing'] == 'on' ); ?>/>
                    </p>

                    <div class="ct-woovideo-video-margins">
                        <p class="form-row form-row-full">
                                <label for="ct_woovideo_video_margin_left[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Margin left:', 'ct-woovideo' ); ?></label>
                                <input type="number" autocomplete="off" name="ct_woovideo_video_margin_left[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_video_margin_left'] ) ) ? esc_attr( $video['_video_margin_left'] ) : '0'; ?>"/>
                                <label for="ct_woovideo_video_margin_top[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Margin top:', 'ct-woovideo' ); ?></label>
                                <input type="number" autocomplete="off" name="ct_woovideo_video_margin_top[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_video_margin_top'] ) ) ? esc_attr( $video['_video_margin_top'] ) : '0'; ?>"/>
                                <label for="ct_woovideo_video_margin_right[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Margin right:', 'ct-woovideo' ); ?></label>
                                <input type="number" autocomplete="off" name="ct_woovideo_video_margin_right[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_video_margin_right'] ) ) ? esc_attr( $video['_video_margin_right'] ) : '0'; ?>"/>
                                <label for="ct_woovideo_video_margin_bottom[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Margin bottom:', 'ct-woovideo' ); ?></label>
                                <input type="number" autocomplete="off" name="ct_woovideo_video_margin_bottom[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_video_margin_bottom'] ) ) ? esc_attr( $video['_video_margin_bottom'] ) : '0'; ?>"/>
                        </p>
                    </div>
                    <div class="ct-woovideo-video-image">
                        <p class="form-field ct-woovideo-upload-image">
                            <label><?php esc_html_e( 'Upload a thumbnail', 'ct-woovideo' ); ?></label>
                            <a href="#" class="ct-woovideo-upload-image-button <?php if ( $video['_thumbnail_id'] > 0 ) echo 'remove'; ?>" rel="<?php echo esc_attr( $video['_id'] ); ?>"><img src="<?php if ( ! empty( $video['_image'] ) ) echo esc_attr( $video['_image'] ); else echo esc_attr( wc_placeholder_img_src() ); ?>" /><input type="hidden" autocomplete="off" name="ct_woovideo_thumbnail_id[<?php echo esc_attr($loop); ?>]" class="ct-woovideo-upload-image-id" value="<?php if(!empty($video['_thumbnail_id'])) echo esc_attr( $video['_thumbnail_id'] ); ?>" /></a>
                        </p>
                        <div style="clear:both"></div>
                        <div class="ct-woovideo-icon-settings <?php echo (!empty($video['_image'])) ? '' : 'hidden'; ?>">
                            <p class="form-row">
                                <label for="ct_woovideo_select_icon[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Select thumbnail icon', 'ct-woovideo' ); ?></label>
                                <label class="ct-woovideo-thumbnail-icon" for="ct-woovideo-select-icon1[<?php echo esc_attr($loop); ?>]"><input type="radio" autocomplete="off" name="ct_woovideo_select_icon[<?php echo esc_attr($loop); ?>]" id="ct-woovideo-select-icon1[<?php echo esc_attr($loop); ?>]" class="ct-woovideo-select-icon" value="file-video" <?php checked( $video['_thumbnail_icon'], 'file-video' ); ?>/><img src="<?php echo CT_WOOVIDEO_ASSETS ?>/images/file-video.png"/></label>
                                <label class="ct-woovideo-thumbnail-icon" for="ct-woovideo-select-icon2[<?php echo esc_attr($loop); ?>]"><input type="radio" autocomplete="off" name="ct_woovideo_select_icon[<?php echo esc_attr($loop); ?>]" id="ct-woovideo-select-icon2[<?php echo esc_attr($loop); ?>]" class="ct-woovideo-select-icon" value="film" <?php checked( $video['_thumbnail_icon'], 'film' ); ?>/><img src="<?php echo CT_WOOVIDEO_ASSETS ?>/images/film.png"/></label>
                                <label class="ct-woovideo-thumbnail-icon" for="ct-woovideo-select-icon3[<?php echo esc_attr($loop); ?>]"><input type="radio" autocomplete="off" name="ct_woovideo_select_icon[<?php echo esc_attr($loop); ?>]" id="ct-woovideo-select-icon3[<?php echo esc_attr($loop); ?>]" class="ct-woovideo-select-icon" value="play-circle" <?php checked( $video['_thumbnail_icon'], 'play-circle' ); ?>/><img src="<?php echo CT_WOOVIDEO_ASSETS ?>/images/play-circle.png"/></label>
                                <label class="ct-woovideo-thumbnail-icon" for="ct-woovideo-select-icon4[<?php echo esc_attr($loop); ?>]"><input type="radio" autocomplete="off" name="ct_woovideo_select_icon[<?php echo esc_attr($loop); ?>]" id="ct-woovideo-select-icon4[<?php echo esc_attr($loop); ?>]" class="ct-woovideo-select-icon" value="play-circle-o" <?php checked( $video['_thumbnail_icon'], 'play-circle-o' ); ?>/><img src="<?php echo CT_WOOVIDEO_ASSETS ?>/images/play-circle-o.png"/></label>
                                <label class="ct-woovideo-thumbnail-icon" for="ct-woovideo-select-icon5[<?php echo esc_attr($loop); ?>]"><input type="radio" autocomplete="off" name="ct_woovideo_select_icon[<?php echo esc_attr($loop); ?>]" id="ct-woovideo-select-icon5[<?php echo esc_attr($loop); ?>]" class="ct-woovideo-select-icon" value="video-camera" <?php checked( $video['_thumbnail_icon'], 'video-camera' ); ?>/><img src="<?php echo CT_WOOVIDEO_ASSETS ?>/images/video-camera.png"/></label>
                                <label class="ct-woovideo-thumbnail-icon" for="ct-woovideo-select-icon6[<?php echo esc_attr($loop); ?>]"><input type="radio" autocomplete="off" name="ct_woovideo_select_icon[<?php echo esc_attr($loop); ?>]" id="ct-woovideo-select-icon6[<?php echo esc_attr($loop); ?>]" class="ct-woovideo-select-icon" value="youtube-play" <?php checked( $video['_thumbnail_icon'], 'youtube-play' ); ?>/><img src="<?php echo CT_WOOVIDEO_ASSETS ?>/images/youtube-play.png"/></label>
                                <?php do_action('ct_woovideo_thumbnail_icons', $loop, $video, CT_WOOVIDEO_ASSETS);?>
                                <label class="ct-woovideo-thumbnail-icon" for="ct-woovideo-select-icon-last[<?php echo esc_attr($loop); ?>]"><input type="radio" autocomplete="off" name="ct_woovideo_select_icon[<?php echo esc_attr($loop); ?>]" id="ct-woovideo-select-icon-last[<?php echo esc_attr($loop); ?>]" class="ct-woovideo-select-icon" value="none" <?php checked( $video['_thumbnail_icon'], 'none' ); ?>/>None</label>
                            </p>
                            <p class="form-row form-row-full">
                                <label for="ct_woovideo_icon_size[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Icon size:', 'ct-woovideo' ); ?></label>
                                <input type="number" autocomplete="off" name="ct_woovideo_icon_size[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_icon_size'] ) ) ? esc_attr( $video['_icon_size'] ) : '0'; ?>"/>
                                <label><?php esc_html_e( 'Icon position in thumbnail:', 'ct-woovideo' ); ?></label>
                                <select class="ct-woovideo-icon-position" name="ct_woovideo_icon_position[<?php echo esc_attr($loop); ?>]" autocomplete="off">
                                    <option value="center" class="ct-woovideo-icon-position-option" <?php selected( $video['_icon_position'], 'center' ); ?> ><?php esc_html_e("Center", "ct-woovideo" );?></option>
                                    <option value="top_left" class="ct-woovideo-icon-position-option" <?php selected( $video['_icon_position'], 'top_left' ); ?> ><?php esc_html_e("Top left corner", "ct-woovideo" );?></option>
                                    <option value="top_right" class="ct-woovideo-icon-position-option" <?php selected( $video['_icon_position'], 'top_right' ); ?> ><?php esc_html_e("Top right corner", "ct-woovideo" );?></option>
                                    <option value="bottom_left" class="ct-woovideo-icon-position-option" <?php selected( $video['_icon_position'], 'bottom_left' ); ?>><?php esc_html_e("Bottom left corner", "ct-woovideo" );?></option>
                                    <option value="bottom_right" class="ct-woovideo-icon-position-option" <?php selected( $video['_icon_position'], 'bottom_right' ); ?>><?php esc_html_e("Bottom right corner", "ct-woovideo" );?></option>
                                </select>
                            </p>
                            <p class ="form-row form-row-full">
                                <label for="ct_woovideo_icon_opacity[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Icon opacity', 'ct-woovideo' ); ?></label>
                                <input autocomplete="off" type="range" min='0' max='10' step='1' name="ct_woovideo_icon_opacity[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_icon_opacity'] ) ) ? esc_attr( $video['_icon_opacity'] ) : '5'; ?>" />
                            </p>

                        </div>

                    </div>

                </div>

                <div class="ct-woovideo-button-settings<?php echo ($video['_location'] != 'button') ? ' hidden' : '' ?>">
                    <div class="ct-woovideo-button-location">
                        <p class="form-field">
                        <label><?php esc_html_e( 'Button Location', 'ct-woovideo' ); ?> <a class="tips" data-tip="<?php esc_attr_e( 'Choose the location to display the button on the product page.', 'ct-woovideo' ); ?>" href="#">[?]</a></label>
                        <select class="ct-woovideo-select-button-location" name="ct_woovideo_button_location[<?php echo esc_attr($loop); ?>]" autocomplete="off">
                            <option value="after_add_to_cart_button" class="ct-woovideo-button-location-option" <?php selected( $video['_button_location'], 'after_add_to_cart_button' ); ?> ><?php esc_html_e("After 'Add to Cart' Button", "ct-woovideo" );?></option>
                            <option value="after_product_info" class="ct-woovideo-button-location-option" <?php selected( $video['_button_location'], 'after_product_info' ); ?>><?php esc_html_e('After Product Info', "ct-woovideo" );?></option>
                            <option value="product_gallery" class="ct-woovideo-button-location-option" <?php selected( $video['_button_location'], 'product_gallery' ); ?> ><?php esc_html_e("Under the Product Gallery", "ct-woovideo" );?></option>
                            <option value="above_tabs" class="ct-woovideo-button-location-option" <?php selected( $video['_button_location'], 'above_tabs' ); ?>><?php esc_html_e("Above the Product Summary Tabs", "ct-woovideo" );?></option>
                            <option value="tab" class="ct-woovideo-button-location-option" <?php selected( $video['_button_location'], 'tab' ); ?>><?php esc_html_e("Inside the Videos tab", "ct-woovideo" );?></option>
                            <option value="shortcode" class="ct-woovideo-button-location-option" <?php selected( $video['_button_location'], 'shortcode' ); ?>><?php esc_html_e("Shortcode", "ct-woovideo" );?></option>
                        </select>
                        <button type="button" class="ct-woovideo-restore-button-defaults button" rel="<?php echo esc_attr( $video['_id'] ); ?>"><?php esc_html_e( 'Restore default button settings', 'ct-woovideo' ); ?></button><a class="tips" data-tip="<?php esc_attr_e( 'Set the defaults in WooCommerce -> Settings -> WooVideo -> Button default settings.', 'ct-woovideo' ); ?>" href="#">[?]</a>
                        </p>
                        <p class="ct-woovideo-button-shortcode-info <?php echo ($video['_button_location'] != 'shortcode') ? 'hidden' : '' ?>">
                            <?php esc_html_e( 'Paste this shortcode on your product page to display the popup button: ', 'ct-woovideo' )?><span class="ct-woovideo-button-shortcode"><?php echo (isset($video['_video_button_shortcode'])) ? esc_html($video['_video_button_shortcode']) : ''; ?></span>
                            <input type="hidden" class="ct-woovideo-button-shortcode-input" autocomplete="off" name="ct_woovideo_button_shortcode[<?php echo esc_attr($loop); ?>]" value="<?php echo (isset($video['_video_button_shortcode'])) ? esc_html($video['_video_button_shortcode']) : ''; ?>" />
                        </p>
                        <p class="form-field">
                        <label for="ct_woovideo_button_location_priority[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Location priority', 'ct-woovideo' ); ?><a class="tips" data-tip="<?php esc_attr_e( 'Set to zero for auto positioning', 'ct-woovideo' ); ?>" href="#">[?]</a></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_location_priority[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_location_priority'] ) ) ? esc_attr( $video['_button_location_priority'] ) : '1'; ?>"/>
                        </p>
                    </div>
                    <div>
                        <p class="form-field">
                            <label for="ct_woovideo_button_class[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Custom button class', 'ct-woovideo' ); ?></label>
                            <input type="text" autocomplete="off" name="ct_woovideo_button_class[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_custom_button_class'] ) ) ? esc_attr( $video['_custom_button_class'] ) : ''; ?>"/>
                        </p>
                        <p class ="form-field">
                            <label for="ct_woovideo_button_color[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Button color', 'ct-woovideo' ); ?></label>
                            <input class="ct-woovideo-color-picker" autocomplete="off" type="text" name="ct_woovideo_button_color[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_color'] ) ) ? esc_attr( $video['_button_color'] ) : ''; ?>" data-default-color="<?php echo (isset($video['_button_color'])) ? esc_attr($video['_button_color']) : ''; ?>"/>
                        </p>
                        <p class ="form-field">
                            <label for="ct_woovideo_button_text_color[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Button text color', 'ct-woovideo' ); ?></label>
                            <input class="ct-woovideo-color-picker" autocomplete="off" type="text" name="ct_woovideo_button_text_color[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_text_color'] ) ) ? esc_attr( $video['_button_text_color'] ) : ''; ?>" />
                        </p>
                        <p class="form-field ct-woovideo-button-label">
                            <label for="ct_woovideo_button_label[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Button label', 'ct-woovideo' ); ?></label>
                            <select name="ct_woovideo_button_label[<?php echo esc_attr($loop); ?>]">
                                <option value="title" <?php selected( $video['_button_label'], 'title' ); ?>><?php esc_html_e( 'Video Title', 'ct-woovideo' ); ?></option>
                                <option value="thumbnail" <?php selected( $video['_button_label'], 'thumbnail' ); ?>><?php esc_html_e( 'Thumbnail', 'ct-woovideo' ); ?></option>
                                <option value="custom" <?php selected( $video['_button_label'], 'custom' ); ?>><?php esc_html_e( 'Custom', 'ct-woovideo' ); ?></option>
                            </select>
                        </p>
                        <p class="form-field ct-woovideo-custom-button-label <?php echo ($video['_button_label'] != 'custom') ? 'hidden' : '' ?>">
                            <label for="ct_woovideo_custom_button_label[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Custom button label', 'ct-woovideo' ); ?></label>
                            <input type="text" autocomplete="off" name="ct_woovideo_custom_button_label[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_custom_button_label'] ) ) ? esc_attr( $video['_custom_button_label'] ) : ''; ?>"/>
                        </p>
                        <p class="form-field">
                            <label for="ct_woovideo_button_align[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Button align', 'ct-woovideo' ); ?></label>
                            <select name="ct_woovideo_button_align[<?php echo esc_attr($loop); ?>]">
                                <option value="left" <?php selected( $video['_button_align'], 'left' ); ?>><?php esc_html_e( 'Left', 'ct-woovideo' ); ?></option>
                                <option value="right" <?php selected( $video['_button_align'], 'right' ); ?>><?php esc_html_e( 'Right', 'ct-woovideo' ); ?></option>
                                <option value="none" <?php selected( $video['_button_align'], 'none' ); ?>><?php esc_html_e( 'None', 'ct-woovideo' ); ?></option>
                            </select>
                        </p>
                        <p class="form-field">
                            <label for="ct_woovideo_button_clearing[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Button clearing ', 'ct-woovideo' ); ?><a class="tips" data-tip="<?php esc_attr_e( 'Allow floating elements on the sides of the button?', 'ct-woovideo' ); ?>" href="#">[?]</a></label>
                            <input type="checkbox" autocomplete="off" name="ct_woovideo_button_clearing[<?php echo esc_attr($loop); ?>]" <?php checked( $video['_button_clearing'] == 'on' ); ?>/>
                        </p>
                    </div>
                    <div class="ct-woovideo-button-margins">
                        <p class="form-row form-row-full">
                        <label for="ct_woovideo_button_margin_left[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Margin left:', 'ct-woovideo' ); ?></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_margin_left[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_margin_left'] ) ) ? esc_attr( $video['_button_margin_left'] ) : '0'; ?>"/>
                        <label for="ct_woovideo_button_margin_top[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Margin top:', 'ct-woovideo' ); ?></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_margin_top[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_margin_top'] ) ) ? esc_attr( $video['_button_margin_top'] ) : '0'; ?>"/>
                        <label for="ct_woovideo_button_margin_right[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Margin right:', 'ct-woovideo' ); ?></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_margin_right[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_margin_right'] ) ) ? esc_attr( $video['_button_margin_right'] ) : '0'; ?>"/>
                        <label for="ct_woovideo_button_margin_bottom[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Margin bottom:', 'ct-woovideo' ); ?></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_margin_bottom[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_margin_bottom'] ) ) ? esc_attr( $video['_button_margin_bottom'] ) : '0'; ?>"/>
                        </p>
                    </div>
                    <div class="ct-woovideo-button-paddings<?php echo ($video['_button_label'] == 'thumbnail') ? ' hidden' : '' ?>">
                        <p class="form-row form-row-full">
                        <label for="ct_woovideo_button_padding_left[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Padding left:', 'ct-woovideo' ); ?></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_padding_left[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_padding_left'] ) ) ? esc_attr( $video['_button_padding_left'] ) : '0'; ?>"/>
                        <label for="ct_woovideo_button_padding_top[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Padding top:', 'ct-woovideo' ); ?></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_padding_top[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_padding_top'] ) ) ? esc_attr( $video['_button_padding_top'] ) : '0'; ?>"/>
                        <label for="ct_woovideo_button_padding_right[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Padding right:', 'ct-woovideo' ); ?></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_padding_right[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_padding_right'] ) ) ? esc_attr( $video['_button_padding_right'] ) : '0'; ?>"/>
                        <label for="ct_woovideo_button_padding_bottom[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Padding bottom:', 'ct-woovideo' ); ?></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_padding_bottom[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_padding_bottom'] ) ) ? esc_attr( $video['_button_padding_bottom'] ) : '0'; ?>"/>
                        </p>
                    </div>
                    <div class="ct-woovideo-button-dimentions<?php echo ($video['_button_label'] != 'thumbnail') ? ' hidden' : '' ?>">
                        <p class="form-field">
                        <label for="ct_woovideo_button_height[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Height:', 'ct-woovideo' ); ?></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_height[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_height'] ) ) ? esc_attr( $video['_button_height'] ) : '0'; ?>"/>
                        </p>
                        <p class="form-field">
                        <label for="ct_woovideo_button_width[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Width:', 'ct-woovideo' ); ?></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_width[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_width'] ) ) ? esc_attr( $video['_button_width'] ) : '0'; ?>"/>
                        </p>
                    </div>
                    <p class="form-field">
                        <label for="ct_woovideo_button_border_radius[<?php echo esc_attr($loop); ?>]"><?php esc_html_e( 'Border radius:', 'ct-woovideo' ); ?></label>
                        <input type="number" autocomplete="off" name="ct_woovideo_button_border_radius[<?php echo esc_attr($loop); ?>]" value="<?php echo ( isset( $video['_button_border_radius'] ) ) ? esc_attr( $video['_button_border_radius'] ) : '0'; ?>"/>
                    </p>
                </div>

            <?php do_action( 'ct_woovideo_after_video_attributes', $loop, $video ); ?>
            </div>
        </div>
    </div>
</div>
