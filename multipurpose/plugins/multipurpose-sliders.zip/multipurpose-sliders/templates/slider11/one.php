  <article>
    <div>
      <h3>%TITLE%</h3>
%CONTENT%
%LINK_TEMPLATE%
    </div>
    %IMG%
  </article>

