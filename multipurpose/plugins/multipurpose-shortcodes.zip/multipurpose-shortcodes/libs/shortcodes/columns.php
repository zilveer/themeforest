<?php
if( !defined('_MULTIPURPOSE_SHORTCODE')) die('Access denied');

// add shortcode for column
add_filter('the_content', "multipurpose_columns_replace", 9);
function multipurpose_columns_replace($content)
{
    $arr_content = explode('[columns', $content);
    $new_content = '';

    for($i = count($arr_content) - 1; $i > 0; $i--)
    {
        $new_content = '[columns'.$i.$arr_content[$i].$new_content;
        add_shortcode('columns'.$i, 'multipurpose_columns');
    }

    $new_content = $arr_content[0].$new_content;

    for($i = count($arr_content) - 1; $i > 0; $i--)
    {
        $arr1 = explode('[columns'.$i , $new_content, 2);
        $arr2 = explode('[/columns]' , $arr1[1], 2);
        $new_content = $arr1[0].'[columns'.$i.$arr2[0].'[/columns'.$i.']'.$arr2[1];
    }

    return $new_content;
}

add_shortcode('one_full','multipurpose_one_full');
add_shortcode('one_half','multipurpose_one_half');
add_shortcode('one_third','multipurpose_one_third');
add_shortcode('one_fourth','multipurpose_one_fourth');
add_shortcode('one_fifth','multipurpose_one_fifth');
add_shortcode('one_sixth','multipurpose_one_sixth');
add_shortcode('three_fourths','multipurpose_three_fourths');
add_shortcode('two_thirds','multipurpose_two_thirds');

function multipurpose_columns($atts, $content = null) {
    remove_all_filters('multipurpose_filters_column_class');
    $output_content = do_shortcode($content);
    $output = '';
    $output .= '<section class="columns';
    if (isset($atts['class']) && !empty($atts['class'])) {
		$output.= ' '.$atts['class'];
	}
    $output .= '">';
    $output .= $output_content;
    $output .= '</section>';

    return $output;
}

function motive_filter_article_tag($content) {
    return '<article '.$content.'</article>';
}

function motive_filter_article_div($content) {
    return '<div '.$content.'</div>';
}

function multipurpose_one_full($atts, $content = null) {
    remove_all_filters('motive_filters_article_tag');
    if (isset($atts['div']) && $atts['div'] == 'yes') 
            add_filter('motive_filters_article_tag', 'motive_filter_article_div', 10);
    else
            add_filter('motive_filters_article_tag', 'motive_filter_article_tag', 10);


    remove_all_filters('multipurpose_filters_team_class');
    remove_all_filters('multipurpose_filters_recent_posts_class');
    $output_content = do_shortcode($content);

    $output = '';
    $output .= 'class="col col1'.apply_filters('multipurpose_filters_team_class', '').apply_filters('multipurpose_filters_recent_posts_class', '');
	if (isset($atts['class']) && !empty($atts['class']))
		$output .= ' '.$atts['class'];
	$output .= '">';
	$output .= $output_content;
    $output_filter = apply_filters('motive_filters_article_tag', trim($output));
	return $output_filter;
}

function multipurpose_one_half($atts, $content = null) {
    remove_all_filters('motive_filters_article_tag');
    if (isset($atts['div']) && $atts['div'] == 'yes') 
            add_filter('motive_filters_article_tag', 'motive_filter_article_div', 10);
    else
            add_filter('motive_filters_article_tag', 'motive_filter_article_tag', 10);


    remove_all_filters('multipurpose_filters_team_class');
    remove_all_filters('multipurpose_filters_recent_posts_class');
    $output_content = do_shortcode($content);
    $output = '';	
    $output .= 'class="col col2'.apply_filters('multipurpose_filters_team_class', '').apply_filters('multipurpose_filters_recent_posts_class', '');
    if (isset($atts['class']) && !empty($atts['class']))
        $output .= ' '.$atts['class'];
    $output .= '">';
    $output .= $output_content;
    $output_filter = apply_filters('motive_filters_article_tag', trim($output));
    
    return $output_filter;
}

function multipurpose_one_third($atts, $content = null) {
    remove_all_filters('motive_filters_article_tag');
    if (isset($atts['div']) && $atts['div'] == 'yes') 
        add_filter('motive_filters_article_tag', 'motive_filter_article_div', 10);
    else
        add_filter('motive_filters_article_tag', 'motive_filter_article_tag', 10);


    $output = '';

    remove_all_filters('multipurpose_filters_team_class');
    remove_all_filters('multipurpose_filters_recent_posts_class');
    $output_content = do_shortcode($content);

    $output .= 'class="col col3'.apply_filters('multipurpose_filters_team_class', '').apply_filters('multipurpose_filters_recent_posts_class', '');
    if (isset($atts['class']) && !empty($atts['class']))
        $output .= ' '.$atts['class'];
    $output .= '">';
    $output .= $output_content;
    $output_filter = apply_filters('motive_filters_article_tag', trim($output));
    
    return $output_filter;
}

function multipurpose_one_fourth($atts, $content = null) {
    remove_all_filters('motive_filters_article_tag');
    if (isset($atts['div']) && $atts['div'] == 'yes') 
            add_filter('motive_filters_article_tag', 'motive_filter_article_div', 10);
    else
            add_filter('motive_filters_article_tag', 'motive_filter_article_tag', 10);


    $output = '';

    remove_all_filters('multipurpose_filters_team_class');
    remove_all_filters('multipurpose_filters_recent_posts_class');
    $output_content = do_shortcode($content);

    $output .= 'class="col col4'.apply_filters('multipurpose_filters_team_class', '').apply_filters('multipurpose_filters_recent_posts_class', '');
    if (isset($atts['class']) && !empty($atts['class']))
            $output .= ' '.$atts['class'];
    $output .= '">';
    $output .= $output_content;
    $output_filter = apply_filters('motive_filters_article_tag', trim($output));
    
    return $output_filter;
}

function multipurpose_one_fifth($atts, $content = null) {
    remove_all_filters('motive_filters_article_tag');
    if (isset($atts['div']) && $atts['div'] == 'yes') 
            add_filter('motive_filters_article_tag', 'motive_filter_article_div', 10);
    else
            add_filter('motive_filters_article_tag', 'motive_filter_article_tag', 10);


    $output = '';

    remove_all_filters('multipurpose_filters_team_class');
    remove_all_filters('multipurpose_filters_recent_posts_class');
    $output_content = do_shortcode($content);

    $output .= 'class="col col5'.apply_filters('multipurpose_filters_team_class', '').apply_filters('multipurpose_filters_recent_posts_class', '');
    if (isset($atts['class']) && !empty($atts['class']))
            $output .= ' '.$atts['class'];
    $output .= '">';
    $output .= $output_content;
    $output_filter = apply_filters('motive_filters_article_tag', trim($output));
    
    return $output_filter;
}

function multipurpose_one_sixth($atts, $content = null) {
    remove_all_filters('motive_filters_article_tag');
    if (isset($atts['div']) && $atts['div'] == 'yes') 
            add_filter('motive_filters_article_tag', 'motive_filter_article_div', 10);
    else
            add_filter('motive_filters_article_tag', 'motive_filter_article_tag', 10);


    $output = '';

    remove_all_filters('multipurpose_filters_team_class');
    remove_all_filters('multipurpose_filters_recent_posts_class');
    $output_content = do_shortcode($content);

    $output .= 'class="col col6'.apply_filters('multipurpose_filters_team_class', '').apply_filters('multipurpose_filters_recent_posts_class', '');
    if (isset($atts['class']) && !empty($atts['class']))
            $output .= ' '.$atts['class'];
    $output .= '">';
    $output .= $output_content;
    $output_filter = apply_filters('motive_filters_article_tag', trim($output));
    
    return $output_filter;
}

function multipurpose_three_fourths($atts, $content = null) {
    remove_all_filters('motive_filters_article_tag');
    if (isset($atts['div']) && $atts['div'] == 'yes') 
            add_filter('motive_filters_article_tag', 'motive_filter_article_div', 10);
    else
            add_filter('motive_filters_article_tag', 'motive_filter_article_tag', 10);


    $output = '';

    remove_all_filters('multipurpose_filters_team_class');
    remove_all_filters('multipurpose_filters_recent_posts_class');
    $output_content = do_shortcode($content);

    $output .= 'class="col col34'.apply_filters('multipurpose_filters_team_class', '').apply_filters('multipurpose_filters_recent_posts_class', '');
    if (isset($atts['class']) && !empty($atts['class']))
            $output .= ' '.$atts['class'];
    $output .= '">';
    $output .= $output_content;
    
    $output_filter = apply_filters('motive_filters_article_tag', trim($output));
    
    return $output_filter;
}

function multipurpose_two_thirds($atts, $content = null) {
    remove_all_filters('motive_filters_article_tag');
    if (isset($atts['div']) && $atts['div'] == 'yes') 
            add_filter('motive_filters_article_tag', 'motive_filter_article_div', 10);
    else
            add_filter('motive_filters_article_tag', 'motive_filter_article_tag', 10);


    $output = '';

    remove_all_filters('multipurpose_filters_team_class');
    remove_all_filters('multipurpose_filters_recent_posts_class');
    $output_content = do_shortcode($content);

    $output .= 'class="col col23'.apply_filters('multipurpose_filters_team_class', '').apply_filters('multipurpose_filters_recent_posts_class', '');
    if (isset($atts['class']) && !empty($atts['class']))
            $output .= ' '.$atts['class'];
    $output .= '">';
    $output .= $output_content;

    $output_filter = apply_filters('motive_filters_article_tag', trim($output));
    
    return $output_filter;
}