/* Awesome Fonts button */
jQuery(function($) {
    "use strict";

    /**
     * 1 - Sortable items
     */

    $( document ).on( 'layers-interface-init', '.widget, .layers-accordions', function( e ){
        // 'this' is the widget
        var $that = $(this);


        // Related to TL Post Grid Widget
        tl_post_widget_draggable( $that );

        $(".tl-select-cpt").on("change", function(e){
            reset_lists($that);
        });
    });


    // Update Column name in administration panel
    $(document).on('change', '.tl-select-post-item', function(e){
        var $this = $(this);

        var tl_base_id     = $this.parents('.widget-inside > .form').find('input[name="id_base"]').val();
        var tl_widget_id   = $this.parents('.widget-inside > .form').find('input[name="widget-id"]').val();
        var tl_column_guid = $this.parents('.layers-accordion-item').data('guid');

        // Change text box value according to selection
        if($this.val()){
            $("#widget-" + tl_widget_id + '-columns-' + tl_column_guid + '-title').val($.trim($this.find("option:selected").text()));
            $this.parents(".layers-accordion-item").find(".layers-accordion-title .layers-detail").html(':' + $.trim($this.find("option:selected").text()));
        }else{
            $("#widget-" + tl_widget_id + '-columns-' + tl_column_guid + '-title').val("");
            $this.parents(".layers-accordion-item").find(".layers-accordion-title .layers-detail").html(': ');
        }
    });


    /* -------------------------- Expand icons button ---------------------------- */

    // Loading Awesome fonts
    $("body").on("click", ".expand-icons", function(e){
        e.preventDefault();

        var $this = $(this);
        var family = 'awesome';

        if($this.hasClass('themify')){
            family = 'themify';
        }else if($this.hasClass('all-icons')){
            family = 'all';
        }

        $.ajax({
            method: "POST",
            url: ajaxurl,
            dataType:'html',
            data: {"action": "load_icons", "family": family},
            success: function(data, status){
                var html = data;
                $this.after(data);
                var selected = $this.parent().next().find("input").val();
                if(selected){
                    $(".tl-icon-container li[data-icon='" + selected + "']").addClass("selected");
                }
            }
        });
    });

    $("body").on("click", ".tl-icon-container li", function(e){
        var $this  = $(this);
        var hidden = $this.parent().parent().next().find("input[type='hidden']");
        $(".tl-icon-container li").removeClass("selected");
        $this.addClass('selected');
        hidden.val($this.data("icon"));
        hidden.change();
    });

    // Loading themify icons






    /**
     * 2 - Column Removal & Additions
     */


    /**
     * 3 - Module Title Update
     */





    /**
     *  4 - TL Post Widget Staff
     */

    /**
     *
     * @param $element_s
     */
    function tl_post_widget_draggable($element_s){

        $element_s.find( 'ul[id^="tl_post_list_"]' ).each(function(){

            var $that = $(this);
            var $available_items = $that.find(".available-items");
            var parent_id = "#" + $that.attr("id");

            var $first_sort = {"a":true, "header":true, "body":true, "footer":true, "media":true};

            $available_items.sortable({
                connectWith: parent_id + " ul.droptrue",
                helper: function (e, li) {
                    this.copyHelper = li.clone().insertAfter(li);
                    $(this).data('copied', false);
                    return  li.clone();;
                },
                stop: function (event, ui) {
                    var copied = $(this).data('copied');
                    if (!copied) {
                        this.copyHelper.remove();
                    }
                    this.copyHelper = null;
                },
                start:function(event, ui){
                    if ($first_sort.a){  // Call a refresh on ui-sortable on drag of first element.
                        $( this ).sortable( "refreshPositions" );
                        $first_sort.a = false;
                    }
                }
            });

            // Sort between grids
            $that.find("ul.droptrue").sortable({
                connectWith: parent_id + " ul.droptrue",
                receive:function(event, ui){
                   _update_grids_fields(ui.item.parent());
                    ui.sender.data('copied', true);
                    if(!ui.sender.hasClass('droptrue')){
                        // this item is received from available list. Bind an event element
                        bindRemoveItem(ui.item.find('a.remove-btn'));
                    }else{
                        // update senders list
                        _update_grids_fields(ui.sender);
                    }
                },
                remove: function(event, ui){
                    //_update_grids_fields(ui.item.parent());
                },
                update: function( event, ui ) {
                    _update_grids_fields(ui.item.parent());
                },
                create: function(event, ui){
                    bindRemoveItem($(this).find('li a.remove-btn'));
                },
                start: function(){
                    if($first_sort[$(this).data("position")]){
                        $first_sort[$(this).data("position")] = false;
                        $(this).sortable("refreshPositions");
                    }
                }
            });

            $available_items.disableSelection();
            $that.find("ul.droptrue").disableSelection();
        });
    }



    function bindRemoveItem(a){

        if(a.length == 0) return;
        if(!Array.isArray(a)){
            a = [a];
        }

        $.each(a, function(){
            $(this).on("click", function(e){
                e.preventDefault();
                var list = $(this).parent().parent();
                $(this).parent().remove(); // li
                _update_grids_fields(list);
            });
        });
    }


    /**
     *
     * @param grid
     * @private
     */
    function _update_grids_fields(grid){

        grid.each(function(){
            var $that = $(this);
            var footer_grid = $that.sortable("toArray", {attribute :"data-item"});
            var $field      = $that.parents(".layers-accordion-item").find('input[id*="'+$that.data("position")+'_items"]');

            $field.val(JSON.stringify(footer_grid));
            $field.change();
        });
    }


    /**
     * Return all fields to Available fields
     */
    function reset_lists(parent){

        var widget_id = parent.attr("id");
        $("#"+widget_id+".droptrue li").remove();

        $("#"+widget_id+"input[name*='header_items']").val('');
        $("#"+widget_id+"input[name*='media_items']").val('');
        $("#"+widget_id+"input[name*='body_items']").val('');
        $("#"+widget_id+"input[name*='footer_items']").val('');

        $("#"+widget_id+"input[name*='header_items']").change();
        $("#"+widget_id+"input[name*='media_items']").change();
        $("#"+widget_id+"input[name*='body_items']").change();
        $("#"+widget_id+"input[name*='footer_items']").change();
    }

}(jQuery));