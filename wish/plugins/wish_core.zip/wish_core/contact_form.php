<?php  
// Plain Hero, no images and stuff
class Wish_Contact_Form {

        var $shortcode = 'wish_contact_form';
        var $title = "Contact Form";
        var $details = "Contact Form7 Form";
        var $forms = array();
        //var $path = "/templates/rating_hero.php";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );

        $this->forms = getAllContactForm7();
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );



        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link" => "http://i.imgur.com/Uu5FvxM.png",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'wish'),
            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor
            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
            "params" => array(
                                        // fields for tab 1
                                        array(
                                            "type" => "textfield",
                                            "heading" => __("Title", "wish"),
                                            "param_name" => "title",
                                            "description" => __("The Title", "wish"),
                                            "value" => __("Contact Us", 'wish'),
                                            "admin_label" => true,
                                        ), 
                                        array(
                                            "type" => "textfield",
                                            "heading" => __("Details", "wish"),
                                            "param_name" => "details",
                                            "description" => __("Details under the title", "wish"),
                                            "value" => __("Pre-Order now and get a free gift.", 'wish'),
                                            "admin_label" => false,
                                        ),


                                        array(
                                            "type" => "dropdown",
                                            "heading" => __("Contact Form 7", "wish"),
                                            "param_name" => "contact",
                                            "description" => __("Choose a contact form", "wish"),
                                            "value" => $this->forms,
                                            "admin_label" => false,
                                        ),
 


                                        array(
                                            "type" => "dropdown",
                                            "heading" => __("Select Form", "wish"),
                                            "param_name" => "select_form",
                                            "description" => __("Contact From", "wish"),
                                            "value" => array( 
                                                              "1"     => "Make an Appointment",
                                                              "2"     => "Make a Reservation",
                                                              "3"     => "Use The Above Form",
                                                            ),
                                            "std"		=> "3",
                                        ),


                                        /*Title*/
                                        array(
                                            "type" => "google_fonts",
                                            "class" => "",
                                            "heading" => __( "Title Text Font", "wish" ),
                                            "param_name" => "title_font",
                                            "value" => '', //Default Red color
                                            "description" => __( "Choose Font", "wish" ),
                                            "group"   => "Fonts & Colors",
                                            'settings' => array(
                                                 'fields'=>array(
                                                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                               )
                                            )       
                                        ),


                                        array(
                                            "type" => "wish_number",
                                            "heading" => __("Title Font Size", "wish"),
                                            "param_name" => "title_size",
                                            "description" => __("Font size in px", "wish"),
                                            "value" => __("70", 'wish'),
                                            "admin_label" => true,
                                            "group"       => "Fonts & Colors",
                                        ),

                                          array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Title Font Color", "wish" ),
                                            "param_name" => "title_color",
                                            "value" => '#000',
                                            "group"   => "Fonts & Colors",
                                         ),

                                        /*Details*/
                                        array(
                                            "type" => "google_fonts",
                                            "class" => "",
                                            "heading" => __( "Details Text Font", "wish" ),
                                            "param_name" => "details_font",
                                            "value" => '', //Default Red color
                                            "description" => __( "Choose Font", "wish" ),
                                            "group"   => "Fonts & Colors",
                                            'settings' => array(
                                                 'fields'=>array(
                                                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                               )
                                            )       
                                        ),


                                        array(
                                            "type" => "wish_number",
                                            "heading" => __("Details Font Size", "wish"),
                                            "param_name" => "details_size",
                                            "description" => __("Font size in px", "wish"),
                                            "value" => __("22", 'wish'),
                                            "admin_label" => true,
                                            "group"       => "Fonts & Colors",
                                        ),

                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Details Font Color", "wish" ),
                                            "param_name" => "details_color",
                                            "value" => '#333333',
                                            "group"   => "Fonts & Colors",
                                        ),


                                        array(
                                            "type" => "colorpicker",
                                            "class" => "",
                                            "heading" => __( "Background Color", "wish" ),
                                            "param_name" => "bgcolor",
                                            "value" => '#ffffff',
                                            "description" => __( "Choose background color", "wish" ),
                                            "group"   => "Fonts & Colors",
                                            "admin_label" => false,
                                        ),





                    )
        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'             => 'Contact Us',
        'title_font'        => '',
        'title_size'        => '70',
        'title_color'       => '#000',

        'contact'           => '',
        'image'             => 'Image',
        'details'           => 'Pre-Order now and get a free gift.',
        'details_font'      => '',
        'details_size'      => '22',
        'details_color'		=> '#333333', 

        'bgcolor'           => '#fff',
        'select_form'       => '',
      ), $atts ) );
     // $content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content


      /*Title*/
    $decode_font = urldecode($title_font);
    $decode_font = explode('|', $decode_font);
    $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
    preg_match("/family=(.*):/", $font_string, $output_array);
    $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

    wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

    /*Details*/
    $decode_font = urldecode($details_font);
    $decode_font = explode('|', $decode_font);
    $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
    preg_match("/family=(.*):/", $font_string, $output_array);
    $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

    wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );
      

          $imgsrc = wp_get_attachment_image_src( $image, 'full' );
    
          if($image == "Image"){
            $imgsrc[0] = plugins_url('images/contact.jpg', __FILE__);
          }

      $form = do_shortcode("[contact-form-7 id='{$contact}' title='Contact form 1']");    

      if ($select_form == "Make an Appointment") {
          $output = "<div class='make-appointment'>
                        <div class='container'>
                            <div class='row'>
                                <h3>Leave Appointment</h3>
                                <div class='col-lg-4'>
                                    <input type='text' class='form-control' id='fname' placeholder='First Name'>
                                    <input type='text' class='form-control' id='lname' placeholder='Last Name'>                        
                                </div>
                                <div class='col-lg-4'>
                                    <input type='text' class='form-control' id='cell' placeholder='Cell Number'>
                                    <input type='email' class='form-control' id='email' placeholder='Enter email'>                        
                                </div>
                                <div class='col-lg-4'>
                                    <input type='text' class='form-control' id='message1' placeholder='Message'>
                                    <input type='text' class='form-control' id='message2' placeholder='Message'>                        
                                </div>
                                <div class='col-lg-12'><input type='button' value='Appoint Now'></div>
                            </div>
                        </div>
                    </div>
          ";   
            }else
            if($select_form == "Make a Reservation"){
                $output = "<div class='welcome-form'>
                                <div class='container'>
                                    <div class='row'>
                                        <div class='col-lg-12'>
                                            <h1 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>
                                            <div class='description animated' data-animation='fadeInUp' data-animation-delay='500' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}</div>
                                        </div>
                                    </div>
                                    <div class='row form'>
                                        <div class='col-lg-4 animated' data-animation='fadeInUp' data-animation-delay='600'><input type='text' class='form-control' id='1' placeholder='First Name'></div>
                                        <div class='col-lg-4 animated' data-animation='fadeInUp' data-animation-delay='800'><input type='text' class='form-control' id='2' placeholder='First Name'></div>
                                        <div class='col-lg-4 animated' data-animation='fadeInUp' data-animation-delay='1000'><input type='text' class='form-control' id='3' placeholder='First Name'></div>
                                        <div class='col-lg-12'>
                                            <div class='buttons animated' data-animation='fadeInUp' data-animation-delay='1200'><a href='' class='fill'>Book a Table</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                ";
            }
            else{

            $output = "<div class='wish-contact-form' style='background-color:{$bgcolor}'>
                        <div class='container wish-contact-from'>
                            <div class='row'>
                                <div class='col-lg-8 col-lg-offset-2'>
                                    <div class='info'>
                                        <h3 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h3>
                                        <div class='herotext animated' data-animation-delay='300' data-animation='fadeInUp' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>
                                            {$details}
                                        </div>
                                        <div class='row form'>
                                        {$form}
                                        </div>
                                    </div>
                                </div>
                                <div class='col-lg-12'></div>
                            </div>
                        </div>
                    </div>";

        }
          return $output;
    }

    /*
    Load plugin css and javascript files which you may need on front end of your site
    */
    public function loadCssAndJs() {
      wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
      wp_enqueue_style( 'vc_extend_style' );

      // If you need any javascript files on front end, here is how you can load them.
      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );
    }

    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }


    public function outputTitleTrue( $title ) {
        return '<h4 class="wpb_element_title">' . __( $title, 'js_composer' ) . ' ' . $this->settings( 'logo' ) . '</h4>';
    }





}//end of class
?>