<div class="blog_posts blog_posts_<?php echo esc_attr($sc_atts->columns);?>" data-columns="<?php echo esc_attr($sc_atts->columns);?>" data-output="<?php echo esc_attr($sc_atts->output);?>">
	<?php

	$args = array( 'posts_per_page' => isset($sc_atts->posts_per_page) ? (int)$sc_atts->posts_per_page : 10  );
	$args['paged'] = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

	$GLOBALS['dtbaker_blog_post_column_override'] = isset($sc_atts->columns) ? (int)$sc_atts->columns : 2;
	$GLOBALS['dtbaker_blog_post_output_override'] = isset($sc_atts->output) ? $sc_atts->output : 'summary';

	// the query
	$the_query = new WP_Query( $args );

	if ( $the_query->have_posts() ) : ?>

		<?php //dtbaker_content_nav( 'nav-above' );
		do_action('dtbaker_blog_posts_before');
		?>
		<div id="the-loop" class="dtbaker-blog-posts">
			<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

				<?php get_template_part( 'content', get_post_format() ); ?>

			<?php endwhile; ?>
		</div>

		<div class="clear"></div>
		<?php //dtbaker_content_nav( 'nav-below' );
		do_action('dtbaker_blog_posts_after');
		?>

	<?php endif;
	wp_reset_postdata();
	?>

</div>