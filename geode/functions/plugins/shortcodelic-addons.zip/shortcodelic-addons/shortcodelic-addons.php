<?php 
/*
Plugin Name: Shortcodelic Addons
Plugin URI: http://www.pixedelic.com/plugins/shortcodelic
Description: It works with Shortcodelic only
Version: 0.0.9
Author: Manuel Masia | Pixedelic.com
Author URI: http://www.pixedelic.com
License: GPL2
*/

define( 'SHORTCODELICADD_PATH', plugin_dir_path( __FILE__ ) );
define( 'SHORTCODELICADD_URL', plugin_dir_url( __FILE__ ) );
define( 'SHORTCODELICADD_NAME', plugin_basename( __FILE__ ) );

if (version_compare(PHP_VERSION, '5.3.0', '<'))
	require_once( SHORTCODELICADD_PATH . 'lib/functions.5.2.php' );
else
	require_once( SHORTCODELICADD_PATH . 'lib/functions.php' );

register_activation_hook( __FILE__, array( 'ShortCodelicAdd', 'activate' ) );
register_uninstall_hook( __FILE__, array( 'ShortCodelicAdd', 'uninstall' ) );

ShortCodelicAdd::get_instance();