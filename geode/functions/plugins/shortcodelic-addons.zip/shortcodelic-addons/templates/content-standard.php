<?php
/**
 * @package WordPress
 * @subpackage ShortcodelicAddons
 * @since 1.0
 */
?>

<?php 
	global $active_gridder;

	$classes[] = '';
	$columns = 1;
	$archive = false;
	if ( is_post_type_archive( 'portfolio' ) || is_tax( 'portfolio_category' ) || is_tax('portfolio_tag') ) {
		$archive = true;
		$classes[] = apply_filters('geode_fx_onscroll','');
		$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
		$t_id = $term->term_id;
		$term_meta = get_option( "taxonomy_$t_id" );
		$template = esc_attr( $term_meta['template'] );
		$masonry = (strpos($template,'masonry') !== false) ? '-masonry' : '';
		$columns = esc_attr( $term_meta['columns'] );
		$classes[] = apply_filters('geode_fx_onscroll','');
	}

	?>

	<article id="post-<?php the_ID(); ?>" <?php post_class($classes); ?>>
		<div class="entry-content">
			<?php if ( !isset($active_gridder) || $active_gridder!=true ) { ?>
				<div class="row">
					<div class="row-inside">
			<?php } ?>

            <?php if ( has_post_thumbnail() ) {
                the_post_thumbnail(apply_filters('scadd_'.$columns.$masonry.'_columns_th','full'));
			} ?>

			<?php if ( $archive ) { ?>
				<span class="sc-bg-hover">
					<?php
						echo '<h4 class="sc-title">'.get_the_title().'</h4>';
						
						$thumb_id = get_post_thumbnail_id(get_the_id());
						$postTh = wp_get_attachment_image_src( $thumb_id, 'full' );
					?>
					<a href="<?php the_permalink(); ?>" class="sc-goto sc-iconaction"><i class="scicon-awesome-link"></i></a>
					<a href="<?php echo $postTh[0]; ?>" class="sc-enlarge sc-iconaction"><i class="scicon-awesome-plus"></i></a>
			<?php } else {
				the_content();
			} ?>

			<?php if ( $archive ) { ?>
				</span><!-- .sc-bg-hover -->
			<?php } ?>
			<?php if ( !isset($active_gridder) || $active_gridder!=true ) { ?>
					</div><!-- .row-inside -->
				</div><!-- .row -->
			<?php } ?>
		</div><!-- .entry-content -->

		<?php if ( !$archive ) { ?>
			<footer class="entry-meta row">
				<div class="row-inside">
					<?php edit_post_link( __( 'Edit', 'twentytwelve' ), '<span class="edit-link">', '</span>' ); ?>
				</div><!-- .row-inside -->
			</footer><!-- .entry-meta -->
		<?php } ?>
	</article>
