<?php  /*IJAZ AHMAD*/

//Register "container" content element

vc_map( array(

    "name" => __("Funfacts", "wish"),

    "description" => __("Funfacts with Image and Name", 'wish'),

    "controls" => "full",

    "base" => "wish_funfacts",

    "as_parent" => array('only' => 'wish_funfact_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)

    "content_element" => true,

    "link"  => "http://i.imgur.com/oCIOBdG.png",

    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),

    "show_settings_on_create" => true,

    "category" => __('Wish Components', 'wish'),

    "js_view" => 'VcColumnView',

    "params" => array(



        // add params same as with any other content element

        array(

            "type" => "textfield",

            "heading" => __("Heading", "wish"),

            "param_name" => "title",

            "description" => __("title", "wish"),

            "value" => __("Funfacts", 'wish'),

            "admin_label" => false,

        ), 



        array(

            "type" => "google_fonts",

            "class" => "",

            "heading" => __( "Title Text Font", "wish" ),

            "param_name" => "title_font",

            "value" => '', //Default Red color

            "description" => __( "Choose Font", "wish" ),

            "group"   => "Fonts & Colors",

            'settings' => array(

                 'fields'=>array(

                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

               )

            )       

        ),





        array(

            "type" => "wish_number",

            "heading" => __("Title Size", "wish"),

            "param_name" => "title_size",

            "description" => __("Font size in px", "wish"),

            "value" => __("20", 'wish'),

            "admin_label" => true,

            "group"       => "Fonts & Colors",

        ),



        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __( "Title Text Color", "wish" ),

            "param_name" => "title_color",

            "value" => '#000', //Default Black color

            "description" => __( "Choose text color", "wish" ),

            "group"         => "Fonts & Colors",

         ),



         array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __( "Background Color", "wish" ),

            "param_name" => "bgcolor",

            "value" => '#ffffff', //Default Red color

            "description" => __( "Choose background color", "wish" ),

            "group"         => "Fonts & Colors",

         ),





    ),



));//ends vc_map



//////////////child elements

vc_map( array(

    "name" => __("Funfact", "wish"),

    "base" => "wish_funfact_single",

    "content_element" => true,

    "as_child" => array('only' => 'wish_funfacts'), // Use only|except attributes to limit parent (separate multiple values with comma)

    "params" => array(



        array(

            "type" => "attach_image",

            "holder" => "div",

            "class" => "",

            "heading" => __("The Image", 'wish'),

            "param_name" => "image",

            "admin_label" => false,    

        ),



        array(

            "type" => "textfield",

            "heading" => __("Count", "wish"),

            "param_name" => "count",

            "description" => __("Funfact Count", "wish"),

            "value" => __("500", 'wish'),

            "admin_label" => false,

        ),



        array(

            "type" => "textfield",

            "heading" => __("Name", "wish"),

            "param_name" => "name",

            "description" => __("Funfact Name", "wish"),

            "value" => __("Cup Of Coffees", 'wish'),

            "admin_label" => false,

        ),





         array(

            "type" => "google_fonts",

            "class" => "",

            "heading" => __( "Count Text Font", "wish" ),

            "param_name" => "count_font",

            "value" => '', //Default Red color

            "description" => __( "Choose Font", "wish" ),

            "group"   => "Fonts & Colors",

            'settings' => array(

                 'fields'=>array(

                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

               )

            )       

        ),





        array(

            "type" => "wish_number",

            "heading" => __("Count Font Size", "wish"),

            "param_name" => "count_size",

            "description" => __("Font size in px", "wish"),

            "value" => __("42", 'wish'),

            "admin_label" => true,

            "group"       => "Fonts & Colors",

        ),



        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __( "Count Text Color", "wish" ),

            "param_name" => "count_color",

            "value" => '#000', //Default Black color

            "description" => __( "Choose text color", "wish" ),

            "group"         => "Fonts & Colors",

         ),





        array(

            "type" => "google_fonts",

            "class" => "",

            "heading" => __( "Name Text Font", "wish" ),

            "param_name" => "name_font",

            "value" => '', //Default Red color

            "description" => __( "Choose Font", "wish" ),

            "group"   => "Fonts & Colors",

            'settings' => array(

                 'fields'=>array(

                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

               )

            )       

        ),





        array(

            "type" => "wish_number",

            "heading" => __("Name Size", "wish"),

            "param_name" => "name_size",

            "description" => __("Font size in px", "wish"),

            "value" => __("14", 'wish'),

            "admin_label" => true,

            "group"       => "Fonts & Colors",

        ),



        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __( "Name Text Color", "wish" ),

            "param_name" => "name_color",

            "value" => '#838383', //Default Black color

            "description" => __( "Choose text color", "wish" ),

            "group"         => "Fonts & Colors",

         ),















    )//ends params



) );//ends vc_map







////////////////////////////////////Starts container class

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {

    class WPBakeryShortCode_Wish_funfacts extends WPBakeryShortCodesContainer {



    public function content( $atts, $content = null ) {



          extract( shortcode_atts( array(

            'title'      => 'Funfacts',

            'title_font' => '',

            'title_size' => '20',

            'title_color'   => '#000',

            'bgcolor'    => '#fff'

          ), $atts ) );



          /*Title*/

        $decode_font = urldecode($title_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";


        preg_match("/family=(.*):(.*),(.*)/", $font_string, $output_array2);
        
        $title_font_weight = array_key_exists(3, $output_array2) ? $output_array2[3] : "400"; 


        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );





      $output = "<div class='container fun-facts' style='background-color:{$bgcolor};'>

            <h1 class='animated fadeInUp visible' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>

            <div class='row'>

                    " . do_shortcode($content) . "

                

            </div>

            </div>";

      

      return $output;

    }





    }//end of container class

} //end if



///////////////////////////////////////////ends container class





if ( class_exists( 'WPBakeryShortCode' ) ) {

class WPBakeryShortCode_Wish_funfact_Single extends WPBakeryShortCode {





        public function content( $atts, $content = null ) {

        

          extract( shortcode_atts( array(

            'image'   => 'Image',

            'name' => 'Cup Of Coffees',

            'name_font' => '',

            'name_size' => '14',

            'name_color' => '#838383',



            'count' => '256',

            'count_font' => '',

            'count_size' => '42',

            'count_color' => '#000',



          ), $atts ) );





          /*Name*/

        $decode_font = urldecode($name_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $name_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



        /*Count*/

        $decode_font = urldecode($count_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $count_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );







          $img = wp_get_attachment_image_src( $image, 'full' );



          if($image == "Image"){

            $imgsrc = plugins_url('images/cup.jpg', __FILE__);

            $img[0] = $imgsrc;

          }



          $output = "<div class='col-lg-3 col-md-6 col-sm-6 animated flipInX visible' data-animation='flipInX' data-animation-delay='100'>

                    <div class='icon'><img src='{$img[0]}' width='40' height='40' alt=''></div>

                    <div class='count' style='font-family:{$count_font_family};font-size:{$count_size}px;color:{$count_color}'>{$count}</div>

                    <div class='caption' style='font-family:{$name_font_family};font-size:{$name_size}px;color:{$name_color}'>{$name}</div>

                </div>";



          return $output;

        }





}//end class



} //end if



/////////////////////////////////////////////////////////////////////////////////////////////



?>