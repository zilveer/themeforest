<?php
class WPBakeryShortCode_Mnky_Progress_Bar extends WPBakeryShortCode {

}