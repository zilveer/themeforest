<?php
require_once 'socials.php';
require_once 'new-tabs.php';
require_once 'opentime.php';
require_once 'recent-work.php';
require_once 'list-icon.php';
require_once 'post-list.php';
require_once 'mini-cart.php';
require_once 'woo-ordering.php';
