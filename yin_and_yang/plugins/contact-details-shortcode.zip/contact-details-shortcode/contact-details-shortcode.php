<?php 
/**
 * @wordpress-plugin
 * Plugin Name: Contact Details Shortcode
 * Description: Adds a shortcode to display your contact details and location in a visually attractive way. 
 * Version:     1.0.0
 * Author:      OnionEye
 * Author URI:  http://themeforest.net/user/onioneye
 * Text Domain: yinandyangcontactdetails
 * License:     GPL-2.0+
 * License URI: http://www.opensource.org/licenses/gpl-license.php
 */

/**
 * Load the plugin's styles 
 */
function onioneye_add_shortcode_styles(){
    wp_enqueue_style( 'contact-details-style', plugins_url('contact-details-style.css', __FILE__), 'all');
}

add_action('wp_enqueue_scripts', 'onioneye_add_shortcode_styles');

/**
 * Output the shortcode's HTML
 */ 
function onioneye_contact_info($atts) {
	
	extract(shortcode_atts(array(
		'name' => '',
		'address' => '',
		'city' => '',
		'state' => '',
		'zip' => '',
		'phone' => '',
		'email' => '',
	), $atts));
	
	return '<!-- START .contact-info-shortcode -->' .
		   '<ul class="contact-info-shortcode">' . 
				'<li class="contact-info location">' . $name . 
					'<span class="street-address">' . $address . '</span>' .
					'<span class="city-zip">' . $city . ' ' . $zip . '</span>' . 
					'<span class="state">' . $state . '</span>' . 
				'</li>' .
				'<li class="contact-info telephone">' . $phone . '</li>' .
				'<li class="contact-info my-mail">' . $email . '</li>' .
		   '</ul>' .
		   '<!-- END .contact-info-shortcode -->';	   
}

add_shortcode('contact_info', 'onioneye_contact_info');

?>