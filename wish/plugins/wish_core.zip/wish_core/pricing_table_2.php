<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Pricing Table 2", "wish"),
    "description" => __("Pricing Table with Details", 'wish'),
    "controls" => "full",
    "base" => "wish_pricing_table2",
    "as_parent" => array('only' => 'wish_pricing_table2_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/YgN4U9b.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
                "type" => "textfield",
                "heading" => __("Title", "wish"),
                "param_name" => "title",
                "description" => __("The Title.", "wish"),
                "value" => __("", 'wish'),
                "admin_label" => true,
        ),

        array(
                "type" => "textfield",
                "heading" => __("Price", "wish"),
                "param_name" => "price",
                "description" => __("The Price.", "wish"),
                "value" => __("", 'wish'),
                "admin_label" => true,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("22", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Price*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Price Text Font", "wish" ),
            "param_name" => "price_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Price Size", "wish"),
            "param_name" => "price_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("22", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Price Text Color", "wish" ),
            "param_name" => "price_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        array(
            "type" => "vc_link",
             "holder" => "div",
             "class" => "",
             "heading" => __("Link To The Page", 'wish'),
             "param_name" => "link",
             "description" => __("The Link below the text", 'wish'),
             "admin_label" => false,
         ),

         array(
              "type" => "textfield",
              "heading" => __("Link Title", "wish"),
              "param_name" => "link_text",
              "description" => __("The Link Title", "wish"),
              "value" => __("Choose", 'wish'),
              "admin_label" => false,
         ),
         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#fff', //Default Red color
            "description" => __( "Choose the background color", "wish" )
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Add item", "wish"),
    "base" => "wish_pricing_table2_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_pricing_table2'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
                "type" => "textfield",
                "heading" => __("Title", "wish"),
                "param_name" => "title",
                "description" => __("The Package.", "wish"),
                "value" => __("PERSONAL", 'wish'),
                "admin_label" => true,
        ),

        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("22", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        /*Background*/
         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#fff',
            "description" => __( "Choose the background color", "wish" ),
            "admin_label" => false,
            "group"        => "Fonts & Colors",
        ),


        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Gradient Color 1", "wish" ),
            "param_name" => "bgcolor1",
            "value" => '#fff', //Default Red color
            "description" => __( "Choose background gradient color 1", "wish" ),
            "admin_label" => false,
            "group"        => "Fonts & Colors",
        ), 

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Gradient Color 2", "wish" ),
            "param_name" => "bgcolor2",
            "value" => '#eee', //Default Red color
            "description" => __( "Choose background gradient color 2", "wish" ),
            "admin_label" => false,
            "group"        => "Fonts & Colors",
        ),





    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Pricing_Table2 extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title'         => 'Enterprise',
            'title_font'    => '',
            'title_size'    => '',
            'title_color'   => '',

            'price'         => '59',
            'price_font'    => '',
            'price_size'    => '',
            'price_color'   => '',

            'link'      => '',
            'link_text' => 'SIGNUP',

            'bgcolor'   => '#fff',
            'bgcolor1'  => '#fff',
            'bgcolor2'  => '#eee'
          ), $atts ) );

        /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*Price*/
        $decode_font = urldecode($price_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $price_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



          if($link == "||" || $link == "" ){
            
            $link_text = "Choose";
            $link_url = "#";
            $link_target = "";
            $link_string = "";

          }else{

            $link = vc_build_link($link); //parse the link
            $link_url = esc_url($link["url"]);
            $link_target = esc_attr($link["target"]);
            if ($link_text == "") {
                $link_string = "";
            }
            else{
                $link_string = "<div class='buttons'><a href='{$link_url}' class='nofill'>{$link_text}</a></div>";
            }

          }


      $output = "
      <style>
        .wish-pricing-table h3 {
                background-color: {$bgcolor2};
                background-image: -moz-linear-gradient({$bgcolor1},{$bgcolor2});
                background-image: -webkit-gradient(linear, left top, left bottom, from({$bgcolor1}), to({$bgcolor2}));
                background-image: -webkit-linear-gradient({$bgcolor1}, {$bgcolor2});
                background-image: -o-linear-gradient({$bgcolor1}, {$bgcolor2});
                background-image: -ms-linear-gradient({$bgcolor1}, {$bgcolor2});
                background-image: linear-gradient({$bgcolor1}, {$bgcolor2});
            }
        }
      </style>
      <div class='wish-pricing-table'>
    <div class='plan'>
        <h3 style:'font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}
        <span style:'font-family:{$price_font_family};font-size:{$price_size}px;color:{$price_color}'>".'$'."{$price}</span></h3>
        {$link_string}        
        <ul>
                    " . do_shortcode($content) . "
            </ul> 
    </div>
</div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Pricing_Table2_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'title'       => 'PERSONAL',
            'title_font'  => '',
            'title_size'  => '22',
            'title_color' => '#000'
          ), $atts ) );

          $title = wish_line2Bold($title);

        /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


          $output = "<li style:'font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</li>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>