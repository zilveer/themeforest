<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Work Process 2", "wish"),
    "description" => __("Work Process 2 with icon and details", 'wish'),
    "controls" => "full",
    "base" => "wish_work_process_2",
    "as_parent" => array('only' => 'wish_work_process_2_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/VN7NA9S.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Top Title", "wish"),
            "value" => __("How We Operate", 'wish'),
            "admin_label" => true,
        ),

        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Font Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("30", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Font color", "wish" ),
            "param_name" => "title_color",
            "value" => '#df4322', //Default color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),



        array(
            "type" => "textfield",
            "heading" => __("SubTitle", "wish"),
            "param_name" => "subtitle",
            "description" => __("The SubTitle", "wish"),
            "value" => __("take a general look at the process that we use.", 'wish'),
            "admin_label" => true,
        ),

        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "SubTitle Text Font", "wish" ),
            "param_name" => "subtitle_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("SubTitle Font Size", "wish"),
            "param_name" => "subtitle_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("60", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "SubTitle Font color", "wish" ),
            "param_name" => "subtitle_color",
            "value" => '#000', //Default color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),




        
        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#fff', //Default Red color
            "description" => __( "Choose background color", "wish" )
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Process", "wish"),
    "base" => "wish_work_process_2_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_work_process_2'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(


        array(
            "type" => "wish_fontawesome_param",
            "holder" => "div",
            "class" => "",
            "heading" => __("Custom Icon", 'wish'),
            "param_name" => "icon",
            "value" => __("fa-file-text-o", 'wish'),
            "description" => __("Get Font Awesome Icons Code Here: <a target='_blank' href='http://fortawesome.github.io/Font-Awesome/cheatsheet/'>Link</a>, New icons may not work. Leave blank if you want to use the above icon.", 'wish'),
            "admin_label" => false,
        ),
         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Icon color", "wish" ),
            "param_name" => "icon_color",
            "value" => '#43b572', 
            "description" => __( "Choose color of icon", "wish" ),
            "group"   => "Fonts & Colors",
         ),

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Top Title", "wish"),
            "value" => __("Discover", 'wish'),
            "admin_label" => true,
        ),

        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Font Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("16", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Font color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000', //Default color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),



     

         array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("We’ve been doing this a long time, and we still love the challenge of mastering new techniques. Being at the leading edge lets us take clients.", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Font Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Font color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000', //Default Red color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),
      

    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Work_Process_2 extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title'         => 'How We Operate',
            'title_font'    => '',
            'title_size'    => '30',
            'title_color'   => '#df4322',

            'subtitle'         => 'take a general look at the process that we use.',
            'subtitle_font'    => '',
            'subtitle_size'    => '60',
            'subtitle_color'   => '#000',

            'bgcolor'   => '#fff'  
          ), $atts ) );


        /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*Details*/
        $decode_font = urldecode($subtitle_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $subtitle_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


      $output = "<div class='team-icons style='background-color:{$bgcolor}'>
            <div class='container team-icons'>
                <div class='row'>
                    <div class='col-lg-12'>
                        <h3 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h3>
                        <h1 class='animated' data-animation='fadeInUp' data-animation-delay='400' style='font-family:{$subtitle_font_family};font-size:{$subtitle_size}px;color:{$subtitle_color}'>{$subtitle}</h1>
                    </div>
                </div>
                <div class='row'>
                    " . do_shortcode($content) . "
            </div>
            </div>
        </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Work_Process_2_Single extends WPBakeryShortCode {

        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'icon'          => 'fa-file-text-o',
            'icon_color'    => '#43b572',

            'title'         => 'Discover',
            'title_font'    => '',
            'title_size'    => '16',
            'title_color'   => '#000',

            'details'       => 'We’ve been doing this a long time, and we still love the challenge of mastering new techniques. Being at the leading edge lets us take clients.',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#000',
          ), $atts ) );

          /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );
          
          $output = "<div class='col-lg-3'>
                        <div class='block'>
                            <div class='icon animated' data-animation='flipInX' data-animation-delay='500' style='color:{$icon_color}'><i class='fa {$icon}'></i></div>
                            <h3 class='animated' data-animation='fadeInDown' data-animation-delay='500' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h3>
                            <div class='description animated' data-animation='fadeInUp' data-animation-delay='600' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}</div>
                        </div>
                    </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>