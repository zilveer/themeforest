**2015-08-19** v1.0.1
	* Refactoring for WP 4.3
**2015-09-09** v1.0.2
	* Service widget title fix
	* Portfolio widget title fix
**2015-09-12** v1.0.3
    * Renamed language files
    * English file updated
**2015-09-25** v1.1.0
    * Added color picker for section excerpts in all Themelaboratory widgets
    * Added Promotional Widget for Layers
    * Added Team Widget for Layers
    * Added new Custom Post Type "Team"
**2015-10-07** v1.1.1
    * Portfolio Widget fix. Category was printed twice instead of once.
    * Translation updated
**2015-10-19** v1.3.0
    * Added new Layers widget (TL Post)
**2016-02-18** v1.4.3
    * Added better control for buttons in following Layers Widgets (TL Content, TL Post Grid, TL Portfolio, TL Promotional)
    * TL Content - Darken Background options works now
    * Php code refactoring. Fixing compatibility issues with PHP 5.3 (still need testing)
**2016-02-20** v1.4.4
    * Bugfix. In some use cases the plugin was preventing the theme to be deactivate(switched).
**2016-05-17** v1.5.0
    * Compatibility fixes
**2016-05-26** v1.5.0.1
    * CSS Fixes. Mostly IE related.
**2016-06-06** v1.5.1
    * Improvement. TL Promotional widget. Call to action button can be aligned to left/right
    * Bugfix. Column removal button enabled in several widgets
    * Bugfix. TL Post Widget. Drag&Drop does not work.
    