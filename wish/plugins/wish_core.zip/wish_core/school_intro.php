<?php  
//Register "container" content element
//imgur image
vc_map( array(
    "name" => __("School Intro", "wish"),
    "description" => __("The intro section in the school section below the slider", 'wish'),
    "controls" => "full",
    "base" => "wish_school_intro",
    "as_parent" => array('only' => 'wish_school_intro_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/15IOCrx.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(
                        array(
                            "type" => "attach_image",
                            "holder" => "div",
                            "class" => "",
                            "heading" => __("The Image below the intro boxes", 'wish'),
                            "param_name" => "image",
                            "admin_label" => false,
                        ), 

                    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Intro Element", "wish"),
    "base" => "wish_school_intro_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_school_intro'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,
        ), 

        array(
            "type" => "wish_fontawesome_param",
            "holder" => "div",
            "class" => "",
            "heading" => __("Fontawesome Icon", 'wish'),
            "param_name" => "icon",
            "value" => __("fa-book", 'wish'),
            "description" => __("Get Font Awesome Icons Code Here: <a target='_blank' href='http://fortawesome.github.io/Font-Awesome/cheatsheet/'>Link</a>, New icons may not work. Leave blank if you want to use the above icon.", 'wish'),
            "admin_label" => false,
        ), 

        array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("Link To A Page", 'wish'),
            "param_name" => "link",
            "description" => __("The Link To A Page.", 'wish'),
            "admin_label" => false,
        ), 


      array(
        "type" => "colorpicker",
        "class" => "",
        "heading" => __( "Box Background color", "wish" ),
        "param_name" => "bgcolor",
        "value" => '#009EDB', //Default Red color
        "description" => __( "Choose the background color of the box", "wish" ),
        "admin_label" => false,
        ),

       
    )//ends params

));//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_School_Intro extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'image'   => 'Image',
      ), $atts ));


          $img = wp_get_attachment_image_src( $image, 'full' );
    
          if($image == "Image"){
            $imgsrc = plugins_url('images/school_strip.png', __FILE__);
            $img[0] = $imgsrc;
          }


      $output = "<div class='container home-intro'>
                    <div class='row'>
                  " . do_shortcode($content) . "        
                        <div class='col-lg-12 s-icons animated' data-animation='fadeInUp' data-animation-delay='2000'><img src='{$img[0]}' class='img-responsive center-block' alt=''></div>
                    </div>
                </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_School_Intro_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image'   => 'Image',
            'link' => '',
            'icon'    => 'fa-book',
            'bgcolor'   => '#009EDB',
          ), $atts ) );



          if($link == "" || $link == "||"){

             $link_text = "Read More";
             $link_url = "#";
             $link_target = "";

          }else{

              $link = vc_build_link($link); //parse the link
              $link_url = esc_url($link["url"]);
              $link_target = esc_attr($link["target"]);
              $link_text = esc_attr($link["title"]);

          }


          $img = wp_get_attachment_image_src( $image, array(263,349) );
    
          if($image == "Image"){
            $imgsrc = plugins_url('images/girl.jpg', __FILE__);
            $img[0] = $imgsrc;
          }        



          $output = "<div class='col-lg-3 col-md-3'>
                        <div class='block animated' data-animation='fadeInUp' data-animation-delay='100'>
                            <div class='picture'><img src='{$img[0]}' class='img-responsive' alt=''></div>
                            <div class='icon bg1' style='background-color:{$bgcolor};'><i class='fa {$icon}'></i></div>
                            <div class='btn center-block'><a href='{$link_url}' target='{$link_target}' class='fill'>{$link_text}</a></div>
                        </div>
                    </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>