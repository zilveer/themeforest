<?php 
if ( class_exists( 'WPBakeryShortCode' ) ) {

	class WPBakeryShortCode_experience_google_map extends WPBakeryShortCode {

		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = null ) {
			
			$output = $css_class = $pin = '';
		
			extract( shortcode_atts( array(
				'el_class'		=> '',
				'api_key'		=> '',
				'address'		=> '40.748432,-73.985632',
				'zoom'			=> '14',
				'hue'			=> '',
				'saturation'	=> '',
				'simplify'		=> '',
				'custom_pin'	=> '',
				'css'			=> ''
			), $atts ) );
			
			if ( '' != $api_key ) {
			
				$attributes = array();
				
				// API KEY
				$attributes[] = 'data-map-api="'. esc_attr( $api_key ) .'"';
			
				// Address
				if ( $address != '' ) {
					$attributes[] = 'data-map-latlng="'. esc_attr( $address ) .'"';
				}
				
				// Zoom
				if ( $zoom != '' ) {
					$attributes[] = 'data-map-zoom="'. esc_attr( $zoom ) .'"';
				}
				
				// Hue
				if ( $hue != '' ) {
					$attributes[] = 'data-map-hue="'. esc_attr( $hue ) .'"';
				}
				
				// Saturation
				if ( $saturation != '' ) {
					$attributes[] = 'data-map-saturation="'. esc_attr( $saturation ) .'"';
				}
				
				// Simplify
				if ( $simplify == 'true' ) {
					$attributes[] = 'data-map-simplify="true"';
				}			
				
				// Custom Pin
				if ( $custom_pin != "" ) {
					
					$pin = wp_get_attachment_image_src( $custom_pin, 'full' );
					$attributes[] = 'data-map-pin="'. esc_url( $pin[0] ) .'" ';
					$attributes[] = 'data-map-pin-width="'. esc_attr( $pin[1] ) .'" ';
					$attributes[] = 'data-map-pin-height="'. esc_attr( $pin[2] ) .'" ';
					
				}
				
				$class = $this->getExtraClass( $el_class );			
				$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );
				
				$rand = rand(0,10000);			
				
				// Map Canvas
				$output .= '<div id="map-canvas-'. $rand .'" class="exp-google-map google-map-canvas'. esc_attr( $css_class ) .'"'. implode( ' ', $attributes ) .'></div>';

			
			} else {
				
				$output = 'Error: Google Maps API key not entered.';
				
			}
			
			return $output;
			
		}

	}
	
}


/* --------- GOOGLE MAP --------- */

vc_map( array(
	"base"						=> "experience_google_map",
	"name"						=> esc_html__( "Google Map", "js_composer_experience" ),
	"description"				=> esc_html__( "Embed a customizable Google map", "js_composer_experience" ),
	"params"					=> array(
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			"type"			=> "textfield",
			'admin_label'	=> true
		),
		
		// Google Map API Key
		array(
			"param_name"	=> "api_key",
			"heading"		=> esc_html__( "Google Maps API Key", "js_composer_experience" ),
			"description"	=> wp_kses( __( "Enter your Google Maps API key. To get an API key refer to the <strong>Get an API key</strong> section <a href='https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key'>here</a>. The <strong>Google Maps JavaScript API</strong> must be enabled. You can find it listed <a href='https://console.developers.google.com/apis/library'>here</a>.", "js_composer_experience" ), array( 'br' => array(), 'a' => array( 'href' => array(), 'title' => array() ), 'strong' => array() ) ),
			"type"			=> "textfield"
		),
		
		// Address
		array(
			"param_name"	=> "address",
			"heading"		=> esc_html__( "Lat, Lng", "js_composer_experience" ),
			"description"	=> wp_kses( __( "Map marker coordinates (lat,lng). Comma separated latitude and longitude coordinates for the map marker. To get a locations coordinates refer to the <strong>Get the coordinates of a place</strong> section of <a href='https://support.google.com/maps/answer/18539?hl=en&ref_topic=3092444'>this page</a>.", "js_composer_experience" ), 
								array(
									'strong'	=> array(), 
									'a'			=> array( 
										'href'		=> array(), 
										'title'		=> array() 
									)
								)
							),
			"type"			=> "textfield",
			'admin_label' 	=> true			
		),
		
		// Zoom
		array(
			"param_name"	=> "zoom",			
			"heading"		=> esc_html__( "Zoom", "js_composer_experience" ),
			"description"	=> esc_html__( "Set the map zoom amount.", "js_composer_experience" ),
			"type"			=> "dropdown",
			'value'			=> array(
				'0'	=> '0',
				'1'	=> '1',
				'2'	=> '2',
				'3'	=> '3',
				'4'	=> '4',
				'5'	=> '5',
				'6'	=> '6',
				'7'	=> '7',
				'8'	=> '8',
				'9'	=> '9',
				'10' => '10',
				'11' => '11',
				'12' => '12',
				'13' => '13',
				'14' => '14',
				'15' => '15',
				'16' => '16',
				'17' => '17',
				'18' => '18',
				'19' => '19'
			)
		),
		
		// Map Hue
		array(
			"param_name"	=> "hue",
			"heading"		=> esc_html__( "Hue", "js_composer_experience" ),
			"description"	=> esc_html__( "Set map hue.", "js_composer_experience" ),
			"type"			=> "colorpicker"
		),
		
		// Saturation
		array(
			"param_name"	=> "saturation",
			"heading"		=> esc_html__( "Saturation", "js_composer_experience" ),
			"description"	=> esc_html__( "Set map colour saturation amount (-100 to 100).", "js_composer_experience" ),
			"type"			=> "textfield",
			'value'			=> '0'
		),
		
		// Simplify
		array(
			"param_name"	=> "simplify",
			"heading"		=> esc_html__( "Simplify", "js_composer_experience" ),
			"description"	=> esc_html__( "Simplify map detail.", "js_composer_experience" ),
			"type"			=> "checkbox",
			'value'			=> true
		),
		
		// Custom Map Pin
		array(
			"param_name"	=> "custom_pin",
			"heading"		=> esc_html__( "Custom Pin", "js_composer_experience" ),
			"description"	=> esc_html__( "Select a custom map pin.", "js_composer_experience" ),
			"type"			=> "attach_image"
		),
		
		// CSS
		array(
			"param_name" => "css",
			"heading"	 => esc_html__( "CSS", "js_composer_experience" ),
			"type"		 => "css_editor",
			"group"		 => esc_html__( "Design options", "js_composer_experience" )
		)
		
	)

) );