<?php

if(!function_exists('edgtcore_is_theme_installed')) {
    /**
     * Function that checks if Edge theme is installed
     * @return bool whether theme is installed or not
     */
    function edgtcore_is_theme_installed() {
        return defined('EDGE_ROOT');
    }
}