<?php
vc_map(array(
	"name" => __("Images Slider", 'jwsthemes'),
	"base" => "image_slider",
	"category" => __('Aqua', 'jwsthemes'),
	"icon" => "tb-icon-for-vc",
	"params" => array(
		array(
			"type" => "attach_images",
			"class" => "",
			"heading" => __("Images", 'jwsthemes'),
			"param_name" => "images",
			"value" => "",
			"description" => __("Select box images in this element.", 'jwsthemes')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Extra Link", 'jwsthemes'),
			"param_name" => "ex_link",
			"value" => "",
			"description" => __("Please, enter extra link in this element.", 'jwsthemes')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Extra Class", 'jwsthemes'),
			"param_name" => "el_class",
			"value" => "",
			"description" => __ ( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'jwsthemes' )
		),
	)
));
