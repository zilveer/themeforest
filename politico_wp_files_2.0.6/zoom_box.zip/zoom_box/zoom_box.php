<?php
/*
Plugin Name: Zoom Box
Description: Responsive image overlay with full screen viewing feature.
Author: THE MOLITOR
Version: 1.0.2
Author URI: http://themolitor.com
*/

function zoom_box_style() { ?>

<style>
/*--ZOOM BOX--*/
#zoomBox.loading:before {background-image: url('<?php echo plugins_url( 'loading.gif' , __FILE__ ); ?>');}
</style>

<?php } 
//LOAD STYLE IN HEADER
add_action('wp_head', 'zoom_box_style');

//ENQUEUE STYLE + SCRIPT
function zoom_box_scripts() {
	wp_enqueue_style( 'zoomBox', plugins_url( 'zoom_box.css' , __FILE__ ) );
	wp_enqueue_script('zoomBox', plugins_url( 'zoom_box.js' , __FILE__ ), array('jquery'),false,true );
}
add_action( 'wp_enqueue_scripts', 'zoom_box_scripts' );
?>