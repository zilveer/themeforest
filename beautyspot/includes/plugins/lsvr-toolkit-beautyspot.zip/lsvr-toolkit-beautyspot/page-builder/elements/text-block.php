<?php

vc_map_update( 'vc_column_text', array(
	'weight' => 1010,
));

?>