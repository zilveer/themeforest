<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// shortcode Social
add_shortcode('social_icons','multipurpose_social_icons');
add_shortcode('social','multipurpose_social');

function multipurpose_social_icons($atts,$content = null) {
    $output = '<section class="social">';
    if(!empty($atts["name"])) {
        $output .= '<h3><span>'.$atts["name"].'</span></h3>';
    }
    $output .= '<ul>'.do_shortcode($content).'</ul>';
    $output .= '</section>';
    return $output;
}

function multipurpose_social($atts, $content = null) {
    $output = '';
    if(isset($atts["link"])) {
        if ($atts["link"] != 'Link') {
            $link = $atts["link"];
        } else {
            $link = '#';
        }
        $output = '<li><a href="'.$link.'" class="'.strtolower($atts["type"]).'">'.do_shortcode($content).'</a></li>';
    }
    return $output;
}