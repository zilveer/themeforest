<?php 
	/* Registration  ---------------------------------------------*/
	
	add_shortcode('registration', 'jx_ievent_registration');
	
	function jx_ievent_registration($atts, $content = null) { 
		extract(shortcode_atts(array(
		
			'title' => '',
			'option_1' => 'Classic,VIP,Organizer',
			'option_2' => 'One Day,Two Days,Thress Days'
		
		), $atts)); 
		 
		
		
		global $alert_stat;
		//initial variables
		//initial variables
		$out=''; 
		$headers='';
		$id = rand(0,100);
		
		$option_sep='';
		$option_list='';
		$option_list_2='';
		
		$i=0;
		
		$option_sep=explode(",", $option_1);
		
		foreach($option_sep as $option_comma){
					
			$option_list .='<option value="'.strtolower($option_comma).'">'.ucfirst($option_comma).'</option>';  
			$i++;
		
		}
		
		
		$option_sep_2=explode(",", $option_2);
		
		foreach($option_sep_2 as $option_comma_2){
					
			$option_list_2 .='<option value="'.strtolower($option_comma_2).'">'.ucfirst($option_comma_2).'</option>';  
			$i++;
		
		}
		
		
		//function code
			
			$out ='
			<div class="jx-ievent-ticket-form jx-ievent-half-width left">
			<h1>'.esc_html__('GET YOUR TICKETS','ievent').'</h1>
			
			<form action="'.esc_url( $_SERVER['REQUEST_URI'] ).'" id="regForm" method="post"  class="toggle-disabled">
			<div class="jx-ievent-ticket-first-name">
			<input type="text" id="name-contactform-'.$id.'" name="tab_reg_name" placeholder="'.esc_html__('Full Name','ievent').'" class="jx-ievent-form-text" data-validation="required"/>
			<!-- First Name Textbox -->
			</div>
			<div class="jx-ievent-ticket-email">
			<input type="text" id="email-contactform-'.$id.'" name="tab_reg_email" placeholder="'.esc_html__('Email Address','ievent').'" class="jx-ievent-form-text" data-validation="email" data-validation="required"/>
			<!-- Email Name Textbox -->
			</div>
			
			<div class="jx-ievent-ticket-phone">
			<input type="text" id="subject-contactform-'.$id.'" name="tab_reg_phone" placeholder="'.esc_html__('Phone Number','ievent').'" class="jx-ievent-form-text" data-validation="required"/>
			<!-- Phone Textbox -->
			</div>
			
			<div class="row-1">
			
			<div class="jx-ievent-ticket-type">
				<select name="tab_reg_ticket_type" class="select-box">
				  '.$option_list.'
				</select>
			</div>
			
			<div class="jx-ievent-ticket-valid">
				<select name="tab_reg_ticket_valid" class="select-box">
				  '.$option_list_2.'
				</select>
			</div>
			
			</div> 
			
			<input type="submit" id="submit-register-'.$id.'" name="submit-register-'.$id.'" class="jx-ievent-form-btn jx-ievent-btn-default" value="'.esc_html__('REGISTER NOW','ievent').'" />
			<!-- Submit Button -->
			'.wp_nonce_field( 'add-user', 'add-nonce' ).'<!-- a little security to process on submission -->
	        <input name="action" type="hidden" id="action" value="submit-register-'.$id.'" />                       
			
				<div class="jx-preload">
					<div class="jx-load-spinner">
					  <div class="rect1"></div>
					  <div class="rect2"></div>
					  <div class="rect3"></div>
					  <div class="rect4"></div>
					  <div class="rect5"></div>
					</div>
				</div>
								
			</form>
			</div>
			<!-- EOF Ticket Form -->
			';
			
			
		$out .="<script type='text/javascript'>                 	
                    	jQuery('form#regForm').on( 'submit', function( event ) {
						    event.preventDefault();
							event.stopImmediatePropagation();
						    jQuery('.jx-ievent-alert').empty();
							jQuery('.jx-ievent-alert').removeClass('hide');
							jQuery('.jx-ievent-alert').removeClass('show');
							jQuery('.jx-ievent-alert').removeClass('success');
							jQuery('.jx-preload',this).addClass('show');
							var data = {
									action: 'submit_form',
									data: jQuery(this).serialize()
								};
							jQuery.post(ajaxurl, data, function(response) {
								console.log(response);
								if(response.success){
									jQuery('.jx-preload').removeClass('show')									
									jQuery('.jx-ievent-alert').addClass('success');
									jQuery('.jx-ievent-alert').addClass('show');
									jQuery('.jx-ievent-alert').append(response.success);
									jQuery('.jx-ievent-alert').addClass('hide');
									jQuery( 'form' ).each(function(){this.reset();});
								}
								
							},'json');
						
						});
                    </script>";		
		//return output
		return $out;
	}
	
	
	//Visual Composer
	
	
	add_shortcode('vc_registration_box', 'jx_vc_ievent_registration');
	
	function jx_vc_ievent_registration($atts, $content = null) { 
		extract(shortcode_atts(array(
		
			'title' => '',
			'option_1' => 'Classic,VIP,Organizer',
			'option_2' => 'One Day,Two Days,Thress Days'
		
		), $atts)); 
		 
		
		
		global $alert_stat;
		//initial variables
		//initial variables
		$out=''; 
		$headers='';
		$id = rand(0,100);
		
		$option_sep='';
		$option_list='';
		$option_list_2='';
		
		$i=0;
		
		$option_sep=explode(",", $option_1);
		
		foreach($option_sep as $option_comma){
					
			$option_list .='<option value="'.strtolower($option_comma).'">'.ucfirst($option_comma).'</option>';  
			$i++;
		
		}
		
		
		$option_sep_2=explode(",", $option_2);
		
		foreach($option_sep_2 as $option_comma_2){
					
			$option_list_2 .='<option value="'.strtolower($option_comma_2).'">'.ucfirst($option_comma_2).'</option>';  
			$i++;
		
		}
		
		
		//function code
			
			$out ='
			<div class="jx-ievent-ticket-form">
			<h1>'.esc_html__('GET YOUR TICKETS','ievent').'</h1>
			
			<form action="'.esc_url( $_SERVER['REQUEST_URI'] ).'" id="regForm" method="post"  class="toggle-disabled">
			<div class="jx-ievent-ticket-first-name">
			<input type="text" id="name-contactform-'.$id.'" name="tab_reg_name" placeholder="'.esc_html__('Full Name','ievent').'" class="jx-ievent-form-text" data-validation="required"/>
			<!-- First Name Textbox -->
			</div>
			<div class="jx-ievent-ticket-email">
			<input type="text" id="email-contactform-'.$id.'" name="tab_reg_email" placeholder="'.esc_html__('Email Address','ievent').'" class="jx-ievent-form-text" data-validation="email" data-validation="required"/>
			<!-- Email Name Textbox -->
			</div>
			
			<div class="jx-ievent-ticket-phone">
			<input type="text" id="subject-contactform-'.$id.'" name="tab_reg_phone" placeholder="'.esc_html__('Phone Number','ievent').'" class="jx-ievent-form-text" data-validation="required"/>
			<!-- Phone Textbox -->
			</div>
			
			<div class="row-1">
			
			<div class="jx-ievent-ticket-type">
				<select name="tab_reg_ticket_type" class="select-box">
				  '.$option_list.'
				</select>
			</div>
			
			<div class="jx-ievent-ticket-valid">
				<select name="tab_reg_ticket_valid" class="select-box">
				  '.$option_list_2.'
				</select>
			</div>
			
			</div> 
			
			<input type="submit" id="submit-register-'.$id.'" name="submit-register-'.$id.'" class="jx-ievent-form-btn jx-ievent-btn-default" value="'.esc_html__('REGISTER NOW','ievent').'" />
			<!-- Submit Button -->
			'.wp_nonce_field( 'add-user', 'add-nonce' ).'<!-- a little security to process on submission -->
	        <input name="action" type="hidden" id="action" value="submit-register-'.$id.'" />                       
			
				<div class="jx-preload">
					<div class="jx-load-spinner">
					  <div class="rect1"></div>
					  <div class="rect2"></div>
					  <div class="rect3"></div>
					  <div class="rect4"></div>
					  <div class="rect5"></div>
					</div>
				</div>
								
			</form>
			</div>
			<!-- EOF Ticket Form -->
			';
			
			
		$out .="<script type='text/javascript'>                 	
                    	jQuery('form#regForm').on( 'submit', function( event ) {
						    event.preventDefault();
							event.stopImmediatePropagation();
						    jQuery('.jx-ievent-alert').empty();
							jQuery('.jx-ievent-alert').removeClass('hide');
							jQuery('.jx-ievent-alert').removeClass('show');
							jQuery('.jx-ievent-alert').removeClass('success');
							jQuery('.jx-preload',this).addClass('show');
							var data = {
									action: 'submit_form',
									data: jQuery(this).serialize()
								};
							jQuery.post(ajaxurl, data, function(response) {
								console.log(response);
								if(response.success){
									jQuery('.jx-preload').removeClass('show')									
									jQuery('.jx-ievent-alert').addClass('success');
									jQuery('.jx-ievent-alert').addClass('show');
									jQuery('.jx-ievent-alert').append(response.success);
									jQuery('.jx-ievent-alert').addClass('hide');
									jQuery( 'form' ).each(function(){this.reset();});
								}
								
							},'json');
						
						});
                    </script>";		
		//return output
		return $out;
	}
	
	
	add_action( 'vc_before_init', 'vc_registration' );
	
	
	function vc_registration() {	
		vc_map(array(
      "name" => esc_html__( "Registration", "TEXT_DOMAIN" ),
      "base" => "vc_registration_box",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_register.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Registration Form','TEXT_DOMAIN'),
      "params" => array(
		 		 
		 
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Options#1", "TEXT_DOMAIN" ),
            "param_name" => "option_1",
			"value" => "Classic,Vip,Organizer", //Default Counter Up Text
            "description" => esc_html__( "Add your Option Here", "TEXT_DOMAIN" )
         ),
		 
       array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Options#2", "TEXT_DOMAIN" ),
            "param_name" => "option_2",
			"value" => "One Day,Tow days,Three Days", //Default Counter Up Text
            "description" => esc_html__( "Add your Option Here", "TEXT_DOMAIN" )
         )
		 
      )
   )); 
	}
?>