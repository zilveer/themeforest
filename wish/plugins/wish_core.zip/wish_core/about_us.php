<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("About Us", "wish"),
    "description" => __("About us With Text and details", 'wish'),
    "controls" => "full",
    "base" => "wish_about_us",
    "as_parent" => array('only' => 'wish_about_us_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link" => "http://i.imgur.com/3eyhqMo.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("The Main Title", "wish"),
            "value" => __("Say Hello", 'wish'),
            "admin_label" => true,
        ),

        array(
            "type" => "textfield",
            "heading" => __("SubTitle", "wish"),
            "param_name" => "subtitle",
            "description" => __("The SubTitle", "wish"),
            "value" => __("we are a bunch of UX strategists having a lot of fun together", 'wish'),
            "admin_label" => true,
        ),
        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.", 'wish'),
            "admin_label" => false,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("30", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#df4322 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        /*SubTitle*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "SubTitle Text Font", "wish" ),
            "param_name" => "subtitle_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("SubTitle Size", "wish"),
            "param_name" => "subtitle_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("40", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "SubTitle Text Color", "wish" ),
            "param_name" => "subtitle_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("16", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#fff', 
            "description" => __( "Choose background color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Tab", "wish"),
    "base" => "wish_about_us_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_about_us'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(
        
        array(
            "type" => "wish_fontawesome_param",
            "heading" => __("The Icon", "wish"),
            "param_name" => "icon",
            "description" => __("The Icon code from Font Awesome", "wish"),
            "value" => __("fa-clock-o", 'wish'),
            "admin_label" => false,
        ),
        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Icon color", "wish" ),
            "param_name" => "icon_color",
            "value" => '#df4322', //Default Red color
            "description" => __( "Choose icon color", "wish" ),
            "group"     => 'Fonts & Colors'
            
         ),

        array(
            "type" => "textfield",
            "heading" => __("Tab Title", "wish"),
            "param_name" => "title",
            "description" => __("The Title Of The Tab", "wish"),
            "value" => __("plug and play", 'wish'),
            "admin_label" => true,
        ), 

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("WordPress is our preferred open source tool for fast, simple publishing and modifying of content", 'wish'),
            "admin_label" => false,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),




       
    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_About_Us extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'         => 'Say Hello',
        'title_font'    => '',
        'title_size'    => '30',
        'title_color'   => '#df4322',

        'subtitle'      => 'we are a bunch of UX strategists having a lot of fun together',
        'subtitle_font' => '',
        'subtitle_size' => '40',
        'subtitle_color'=> '#000',

        'details'       => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.',
        'details_font'  => '',
        'details_size'  => '16',
        'details_color' => '#000',
        'bgcolor'       => '#fff'
      ), $atts ) );


      /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*SubTitle*/
        $decode_font = urldecode($subtitle_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $subtitle_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



      $output = "<div class='row intro-2' style='background-color:{$bgcolor}'>
                <div class='col-lg-6'>
                    <h3 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h3>
                    <h1 class='animated' data-animation='fadeInUp' data-animation-delay='300' style='font-family:{$subtitle_font_family};font-size:{$subtitle_size}px;color:{$subtitle_color}'>{$subtitle}</h1>
                    <div class='description animated' data-animation='fadeInUp' data-animation-delay='500' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}</div>
                </div>
                <div class='col-lg-6 icons'>
                    <div class='row'>
                        " . do_shortcode($content) . "
                    </div>
                </div>
            </div>
      ";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_About_Us_Single extends WPBakeryShortCode {

        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'icon'          => 'fa-clock-o',
            'icon_color'    => '#df4322',

            'title'         => 'plug and play',
            'title_font'    => '',
            'title_size'    => '20',
            'title_color'   => '#000',

            'details'       => 'WordPress is our preferred open source tool for fast, simple publishing and modifying of content',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#000',
          ), $atts ) );


          /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );
         
            
            $output = "
            <div class='col-lg-6'>
                            <div class='icon animated' data-animation='fadeInUp' data-animation-delay='100' style='color:{$icon_color}'><i class='fa {$icon}'></i></div>
                            <h1 class='animated' data-animation='fadeInUp' data-animation-delay='400' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>
                            <div class='description animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}</div>
                        </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>