var rules = {
            first_name: "required",
            last_name: "required",
            email: {
                required: true,
                email: true
            },
            os0: "required",
            item_price: "required",
            quantity: "required",
            agree: "required"
        };
var add_fields_validate = eventres_ajax.add_fields_validate ? eventres_ajax.add_fields_validate : {};
jQuery.each(add_fields_validate, function(key, value) {
    rules[key] = value;
});
jQuery("#paypal-regn").validate({
    rules: rules,
    messages: {
        first_name: eventres_ajax.msg_fname,
        last_name: eventres_ajax.msg_lname,
        email: eventres_ajax.msg_email,
        os0: eventres_ajax.msg_pass,
        item_price: "Choose your Pass",
        quantity: eventres_ajax.msg_seats,
        agree: eventres_ajax.msg_agree
    },
    submitHandler: function(form) {
        jQuery("#reserve-btn").attr("disabled", true);
        jQuery('#eventreg_msg').css('display','none');
        ajaxEventReg(form);
    }
});

function ajaxEventReg(form){
    contents = jQuery(form).serialize();
    contents += '&action=gather_event_paypal_registration';
    jQuery.post( eventres_ajax.url, contents, function( data ){
        if(data.success == 1){
            window.location = data.message;
        }else{
            jQuery('#eventreg_msg').html(data.message).css('display','block');
            jQuery("#reserve-btn").attr("disabled", false);
        }
    }, 'json');
}