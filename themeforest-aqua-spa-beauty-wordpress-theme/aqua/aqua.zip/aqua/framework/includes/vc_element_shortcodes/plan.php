<?php

add_action('init', 'tb_plan_integrateWithVC');

function tb_plan_integrateWithVC() {
    vc_map(array(
        "name" => __("Plan", 'jwsthemes'),
        "base" => "tb_plan",
        "class" => "tb_plan",
        "category" => __('Aqua', 'jwsthemes'),
        "icon" => "tb-icon-for-vc",
        "params" => array(
            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => __("Name", 'jwsthemes'),
                "param_name" => "name",
                "value" => "",
                "description" => __("Name.", 'jwsthemes')
            ),
			array(
                "type" => "attach_image",
                "class" => "",
                "heading" => __("Image", 'jwsthemes'),
                "param_name" => "img",
                "value" => "",
                "description" => __("Image.", 'jwsthemes')
            ),
            array(
                "type" => "checkbox",
                "class" => "",
                "heading" => __("Featured", 'jwsthemes'),
                "param_name" => "featured",
                "value" => array (
                    __ ( "Yes, please", 'jwsthemes' ) => true
                ),
                "description" => __("Featured.", 'jwsthemes')
            ),            
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Price", 'jwsthemes'),
                "param_name" => "price",
                "value" => "",
                "description" => __("Price.", 'jwsthemes')
            ),
			array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Currency", 'jwsthemes'),
                "param_name" => "currency",
                "value" => "",
                "description" => __("Currency.", 'jwsthemes')
            ),
			array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Unit", 'jwsthemes'),
                "param_name" => "unit",
                "value" => "",
                "description" => __("Unit.", 'jwsthemes')
            ),
            array(
                "type" => "textarea_html",
                "class" => "",
                "heading" => __("Content", 'jwsthemes'),
                "param_name" => "content",
                "value" => "",
                "description" => __("Content.", 'jwsthemes')
            ),
			array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Lable Button", 'jwsthemes'),
                "param_name" => "btn_label",
                "value" => "",
                "description" => __("Lable Button.", 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Url", 'jwsthemes'),
                "param_name" => "url",
                "value" => "#",
                "description" => __("Url.", 'jwsthemes')
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Target", 'jwsthemes'),
                "param_name" => "target",
                "value" => array (
                    "_self" => "_self",
                    "_blank" => "_blank",
                ),
                "description" => __("Target.", 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Extra Class", 'jwsthemes'),
                "param_name" => "el_class",
                "value" => "",
                "description" => __ ( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'jwsthemes' )
            ),
        )
    ));
}
