<?php
global $header_widget, $widget_id;
?>
<div id="<?php echo esc_attr($widget_id)?>" <?php layers_wrapper_class( 'title_container', 'title-container layers-tl-header-widget' ); ?>>
    <?php do_action('layers_before_header_page_title'); ?>
    <div class="title text-center">
        <?php

        if( isset( $widget[ 'title' ] ) && '' != $widget[ 'title' ] ) { ?>
            <?php do_action('layers_before_title_heading'); ?>
            <h3 class="heading"><?php echo $widget[ 'title' ]; ?></h3>
            <?php do_action('layers_after_title_heading'); ?>
        <?php } // if isset $title

        if(!isset($widget['hide_breadcrumbs'])){
            /**
             * Display Breadcrumbs
             */
            ob_start();
            layers_bread_crumbs('nav', 'bread-crumbs', '/');
            $bread = ob_get_contents();

            if(isset($widget['exclude_home'])){
                $bread = preg_replace('/(.+?)(<li>.*?<\/li>.*?<li>\/<\/li>)(.+)/is', '$1$3', $bread);
            }

            $bread = str_replace('>/<', '><i class="l-close"></i><', $bread);
            ob_end_clean();
            echo $bread;
        }
        ?>
    </div>
    <?php do_action('layers_after_header_page_title'); ?>
    <?php if(!isset($widget['hide_navigation'])): ?>
    <div class="widget widget_nav_menu">
        <?php
            $menu = !empty($widget['navigation_menu']) ? $widget['navigation_menu'] : LAYERS_THEME_SLUG . '-primary';
            wp_nav_menu(array('theme_location' => $menu,
                                'menu_class'     => 'menu',
                                'fallback_cb' => '\Handyman\Front\tl_layers_menu_fallback')) ?>
    </div>
    <?php endif; ?>
</div>