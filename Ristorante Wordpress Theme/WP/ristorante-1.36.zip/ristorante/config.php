[config]
dashboard = enabled
website_settings = enabled
branding = enabled
skins = enabled
backup = enabled
wysiwyg = enabled
