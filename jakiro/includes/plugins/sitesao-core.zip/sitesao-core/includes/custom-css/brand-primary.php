<?php 
$brand_primary = dh_format_color(dh_get_theme_option('brand-primary','#fe6367'));
$brand_primary = apply_filters('dh_brand_primary', $brand_primary);
if($brand_primary === '#fe6367'){
	return '';
}
$darken_10_brand_primary = darken(dh_format_color($brand_primary),'10%');
$darken_12_brand_primary = darken(dh_format_color($brand_primary),'12%');
?>
a:hover,
a:focus {
  color: <?php echo dh_print_string($brand_primary) ?>;
  text-decoration: none;
}
.fade-loading i {
  background: none repeat scroll 0 0 <?php echo dh_print_string($brand_primary) ?>;
}
.text-primary {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.bg-primary {
  background-color: <?php echo dh_print_string($brand_primary) ?>;
}
::selection {
  background: <?php echo dh_print_string($brand_primary) ?>;
}
::-moz-selection {
  background: <?php echo dh_print_string($brand_primary) ?>;
}
.btn-primary {
  background-color: <?php echo dh_print_string($brand_primary) ?>;
  border-color: <?php echo dh_print_string($brand_primary) ?>;
}
.btn-primary-outline {
  border: 2px solid <?php echo dh_print_string($brand_primary) ?>;
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.btn-primary-outline:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
  border-color: <?php echo dh_print_string($brand_primary) ?>;
}
.dropdown-menu > .active > a,
.dropdown-menu > .active > a:hover {
  background-color: <?php echo dh_print_string($brand_primary) ?>;
}
@media (min-width: 992px) {
  .header-type-classic .underline:after,
  .header-type-default .underline:after {
    background: <?php echo dh_print_string($brand_primary) ?>;
  }
}
.navbar-default .navbar-nav > li > a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.navbar-default .navbar-nav .open > a {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.navbar-default .navbar-nav > .current-menu-ancestor > a,
.navbar-default .navbar-nav > .current-menu-parent > a,
.navbar-default .navbar-nav > .current-menu-ancestor > a:hover,
.navbar-default .navbar-nav > .current-menu-parent > a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
@media (max-width: 991px) {
  .navbar-default .navbar-nav .open .dropdown-menu > li > a {
    color: #1e1e1e;
  }
}
@media (min-width: 992px) {
  .primary-nav > .megamenu > .dropdown-menu > li .dropdown-menu a:hover {
    color: <?php echo dh_print_string($brand_primary) ?>;
  }
   .primary-nav .dropdown-menu a:hover {
    color: <?php echo dh_print_string($brand_primary) ?>;
  }
  .header-type-default .primary-nav > li > a .navicon {
    color: <?php echo dh_print_string($brand_primary) ?>;
  }
}
.primary-nav .dropdown-menu .open > a {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.primary-nav > li.current-menu-parent > a,
.primary-nav > li.current-menu-parent > a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.navbar-search .search-form-wrap.show-popup .searchform:before {
  background: <?php echo dh_print_string($brand_primary) ?>;
}
.cart-icon-mobile span {
  background: none repeat scroll 0 0 <?php echo dh_print_string($brand_primary) ?>;
}
.breadcrumb > li a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.mejs-controls .mejs-time-rail .mejs-time-current {
  background: <?php echo dh_print_string($brand_primary) ?> !important;
}
.mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-current {
  background: <?php echo dh_print_string($brand_primary) ?> !important;
}
.ajax-modal-result a,
.user-modal-result a {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
a[data-toggle="popover"],
a[data-toggle="tooltip"] {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.caroufredsel .caroufredsel-wrap .caroufredsel-next:hover,
.caroufredsel .caroufredsel-wrap .caroufredsel-prev:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.footer-widget .social-widget-wrap a:hover i {
  color: <?php echo dh_print_string($brand_primary) ?> !important;
}
.footer-widget a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.footer .footer-info a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.entry-format {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.sticky .entry-title:before {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.entry-meta a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.post-navigation a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.author-info .author-social a:hover {
  background: <?php echo dh_print_string($brand_primary) ?>;
}
.comment-author a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.comment-reply-link {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
#wp-calendar > tbody > tr > td > a {
  background: <?php echo dh_print_string($brand_primary) ?>;
}
.recent-tweets ul li a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.posts-thumbnail-content .posts-thumbnail-meta > span a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.posts-thumbnail-content > a:hover,
.posts-thumbnail-content > h4:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.posts-thumbnail-content > h4 a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.masonry-filter .filter-action.filter-action-center > ul li a.selected {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.masonry-filter .filter-action > ul li a.selected {
  color: <?php echo dh_print_string($brand_primary) ?>;
  border-bottom-color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce #payment #place_order {
  background: <?php echo dh_print_string($brand_primary) ?> !important;
  border-color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce span.out_of_stock {
  background: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce ul.products li.product .shop-loop-quickview a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce ul.products li.product .yith-wcwl-add-to-wishlist .add_to_wishlist:hover:before {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce ul.products li.product .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistaddedbrowse a:hover:before,
.woocommerce ul.products li.product .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistexistsbrowse a:hover:before {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce ul.products li.product .product_title a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce ul.products li.product figcaption .product_title a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce ul.products li.product figcaption .shop-loop-product-info .info-meta .loop-add-to-cart a {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce p.stars a.star-1:hover:after,
.woocommerce p.stars a.star-1.active:after {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce p.stars a.star-2:hover:after,
.woocommerce p.stars a.star-2.active:after {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce p.stars a.star-3:hover:after,
.woocommerce p.stars a.star-3.active:after {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce p.stars a.star-4:hover:after,
.woocommerce p.stars a.star-4.active:after {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce p.stars a.star-5:hover:after,
.woocommerce p.stars a.star-5.active:after {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce ul.cart_list li a:hover,
.woocommerce ul.product_list_widget li a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce.dhwc_widget_brands ul.product-brands li ul.children li a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce.widget_product_categories ul.product-categories li ul.children li a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce.widget_product_search form:before {
  background: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce .widget_shopping_cart .buttons .button.checkout {
  background-color: <?php echo dh_print_string($brand_primary) ?>;
  border-color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce .cart-collaterals .shipping_calculator .button {
  background-color: <?php echo dh_print_string($brand_primary) ?>;
  border-color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce .cart-collaterals .cart_totals .checkout-button {
  background-color: <?php echo dh_print_string($brand_primary) ?>;
  border-color: <?php echo dh_print_string($brand_primary) ?>;
}
.woocommerce .cart-collaterals .cart_totals .order-total .amount {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.minicart-icon span {
  background: none repeat scroll 0 0 <?php echo dh_print_string($brand_primary) ?>;
}
.minicart .minicart-body .cart-product .cart-product-title a:hover {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.product-slider-title.color-primary .el-heading {
  color: <?php echo dh_print_string($brand_primary) ?>;
}
.product-slider-title.color-primary .el-heading:before {
  border-color: <?php echo dh_print_string($brand_primary) ?>;
}
<?php //10%?>
a.text-primary:hover {
  color: <?php echo dh_print_string($darken_10_brand_primary)?>;
}
a.bg-primary:hover {
  background-color: <?php echo dh_print_string($darken_10_brand_primary)?>;
}
.btn-primary:hover,
.btn-primary:focus,
.btn-primary:active,
.btn-primary.active {
  border-color: <?php echo dh_print_string($darken_10_brand_primary)?>;
  -webkit-box-shadow: 0 0 0 2px <?php echo dh_print_string($darken_10_brand_primary)?> inset;
  box-shadow: 0 0 0 2px <?php echo dh_print_string($darken_10_brand_primary)?> inset;
}
a[data-toggle="popover"]:hover,
a[data-toggle="tooltip"]:hover {
  color: <?php echo dh_print_string($darken_10_brand_primary)?>;
}
.woocommerce #payment #place_order:hover,
.woocommerce #payment #place_order:focus,
.woocommerce #payment #place_order:active,
.woocommerce #payment #place_order.active {
  border-color: <?php echo dh_print_string($darken_10_brand_primary)?>;
  -webkit-box-shadow: 0 0 0 2px <?php echo dh_print_string($darken_10_brand_primary)?> inset;
  box-shadow: 0 0 0 2px <?php echo dh_print_string($darken_10_brand_primary)?> inset;
}
.woocommerce .widget_shopping_cart .buttons .button.checkout:hover,
.woocommerce .widget_shopping_cart .buttons .button.checkout:focus,
.woocommerce .widget_shopping_cart .buttons .button.checkout:active,
.woocommerce .widget_shopping_cart .buttons .button.checkout.active {
  border-color: <?php echo dh_print_string($darken_10_brand_primary)?>;
  -webkit-box-shadow: 0 0 0 2px <?php echo dh_print_string($darken_10_brand_primary)?> inset;
  box-shadow: 0 0 0 2px <?php echo dh_print_string($darken_10_brand_primary)?> inset;
}
.woocommerce .cart-collaterals .shipping_calculator .button:hover,
.woocommerce .cart-collaterals .shipping_calculator .button:focus,
.woocommerce .cart-collaterals .shipping_calculator .button:active,
.woocommerce .cart-collaterals .shipping_calculator .button.active {
  border-color: <?php echo dh_print_string($darken_10_brand_primary)?>;
  -webkit-box-shadow: 0 0 0 2px <?php echo dh_print_string($darken_10_brand_primary)?> inset;
  box-shadow: 0 0 0 2px <?php echo dh_print_string($darken_10_brand_primary)?> inset;
}
.woocommerce .cart-collaterals .cart_totals .checkout-button:hover,
.woocommerce .cart-collaterals .cart_totals .checkout-button:focus,
.woocommerce .cart-collaterals .cart_totals .checkout-button:active,
.woocommerce .cart-collaterals .cart_totals .checkout-button.active {
  border-color: <?php echo dh_print_string($darken_10_brand_primary)?>;
  -webkit-box-shadow: 0 0 0 2px <?php echo dh_print_string($darken_10_brand_primary)?> inset;
  box-shadow: 0 0 0 2px <?php echo dh_print_string($darken_10_brand_primary)?> inset;
}