<?php
/**
 * Layers Portfolio Widget
 *
 * This file is used to register and display the Layers - Portfolio widget.
 *
 * @package Layers
 * @since Layers 1.0.0
 */

if(!class_exists('TL_Layers_Abstract_Widget')){ return; }

if (!class_exists('TL_Layers_Portfolio_Widget')) {
    class TL_Layers_Portfolio_Widget extends TL_Layers_Abstract_Widget
    {
        /**
         *  Widget construction
         */
        public function __construct()
        {
            /**
             * Widget variables
             *
             * @param    string $widget_title Widget title
             * @param    string $widget_id Widget slug for use as an ID/classname
             * @param    string $post_type (optional) Post type for use in widget options
             * @param    string $taxonomy (optional) Taxonomy slug for use as an ID/classname
             * @param    array $checkboxes (optional) Array of checkbox names to be saved in this widget. Don't forget these please!
             */
            $this->widget_title = __('TL Portfolio', 'layerswp');
            $this->widget_id = 'tl_portfolio';
            $this->post_type = 'tl_portfolio';
            $this->taxonomy = 'tl_portfolio_category';
            $this->checkboxes = array(
                'show_filters',
                'hide_empty_filters',
                'show_media',
                'show_titles',
                'show_excerpts',
                'show_categories',
                'show_call_to_action'
            ); // @TODO: Try make this more dynamic, or leave a different note reminding users to change this if they add/remove checkboxes


            /* Widget settings. */
            $widget_ops = array('classname' => 'obox-layers-' . $this->widget_id . '-widget', 'description' => __('This widget is used to display your ', 'layerswp') . $this->widget_title . '.');

            /* Widget control settings. */
            $control_ops = array('width' => LAYERS_WIDGET_WIDTH_SMALL, 'height' => NULL, 'id_base' => LAYERS_THEME_SLUG . '-widget-' . $this->widget_id);

            /* Create the widget. */
            parent::__construct(LAYERS_THEME_SLUG . '-widget-' . $this->widget_id, $this->widget_title, $widget_ops, $control_ops);

            /* Setup Widget Defaults */
            $this->defaults = array(
                'title' => __('Recent Work', TL_INSERT_STAFF_SLUG),
                'excerpt' => __('Stay up to date with all our latest work. Only the best quality makes it onto our blog!', TL_INSERT_STAFF_SLUG),
                'text_style' => 'overlay', //'regular',
                'show_filters' => 'on',
                'hide_empty_filters' => 'on',
                'show_media' => 'on',
                'show_titles' => 'on',
                'show_excerpts' => 'on',
                'show_categories' => 'on',
                'excerpt_length' => 200,
                'show_call_to_action' => 'on',
                'num_post' => -1,
                'design' => array(
                    'layout' => 'layout-boxed',
                    'imageratios' => 'image-landscape',
                    'liststyle' => 'list-grid',
                    'columns' => '4',
                    'gutter' => null,
                    'background' => array(
                        'position' => 'center',
                        'repeat' => 'no-repeat'
                    ),
                    'fonts' => array(
                        'align' => 'text-center',
                        'size'  => 'medium',
                        'color' => NULL,
                        'excerpt-color' => NULL,
                        'shadow' => NULL
                    ),
                    'buttons' => array(
                        'label' => null,
                        'border-radius' => '50px',
                        'border-width' => '1px',
                        'buttons-size' => 'small',
                    )
                )
            );

            /* Add Filters */
            $this->_addFilters();

            $this->get_theme_colors();
        }



        /**
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        {
            $this->backup_inline_css();

            // Turn $args array into variables.
            extract($args);

            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            // Add scripts when needed
            $this->enqueue_scripts();

            //
            $this->_set_default_colors($widget_id, $widget);

            if (isset($widget['design']['columns'])) {
                $col_count = str_ireplace('columns-', '', $widget['design']['columns']);
                $span_class = 'span-' . (12 / $col_count);
            } else {
                $col_count = 3;
                $span_class = 'span-4';
            }

            if($this->check_and_return($widget, 'show_filters') && $this->check_and_return($widget, 'design', 'gutter') == 'on'){
                $span_class = 'x' . $span_class;
            }

            $this->inline_css .= layers_inline_styles('#' . $widget_id, 'background', array('selectors' => array('.thumbnail:not(.with-overlay) .thumbnail-body'),
                                                                       'background' => array('color' => $this->check_and_return($widget, 'design', 'column-background-color'))));

            // Apply Section Styling
            $this->_apply_widget_section_styling($widget_id, $widget);

            $this->_apply_button_styling($widget_id, $widget);

            // Set Image Sizes
            if (isset($widget['design']['imageratios'])) {
                // Translate Image Ratio
                $image_ratio = layers_translate_image_ratios($widget['design']['imageratios']);

                if ('layout-boxed' == $this->check_and_return($widget, 'design', 'layout') && $col_count > 2) {
                    $use_image_ratio = $image_ratio . '-medium';
                } elseif ('layout-boxed' != $this->check_and_return($widget, 'design', 'layout') && $col_count > 3) {
                    $use_image_ratio = $image_ratio . '-medium';
                } else {
                    $use_image_ratio = $image_ratio . '-large';
                }
            } else {
                $use_image_ratio = 'large';
            }

            $query_args['post_type'] = $this->post_type;
            $query_args['posts_per_page'] = (isset($widget['num_post']) && $widget['num_post']!='') ? $widget['num_post'] : -1;
            if (isset($widget['order'])) {
                $decode_order = json_decode($widget['order'], true);
                if (is_array($decode_order)) {
                    foreach ($decode_order as $key => $value) {
                        $query_args[$key] = $value;
                    }
                }
            }

            $term_args = array('hide_empty' => (isset($widget['hide_empty_filters']) && $widget['hide_empty_filters'] != ''));

            $terms = get_terms($this->taxonomy, $term_args);

            // Do the WP_Query
            $post_query = new WP_Query($query_args);

            // Set the meta to display
            global $layers_post_meta_to_display;
            $layers_post_meta_to_display = array();
            if (isset($widget['show_categories'])) $layers_post_meta_to_display[] = 'categories';
            /**
             * Generate the widget container class
             */
            $widget_container_class = array();
            $widget_container_class[] = $this->widget_class();// 'tl-portfolio-widget';
            $widget_container_class[] = 'widget content-vertical-massive';
            $widget_container_class[] = $this->check_and_return($widget, 'design', 'advanced', 'customclass');
            $widget_container_class[] = $this->get_widget_spacing_class($widget);
            $widget_container_class = implode(' ', apply_filters('layers_'.$this->widget_id.'_widget_container_class', $widget_container_class, $this, $widget)); ?>

            <div class=" <?php echo esc_attr($widget_container_class); ?>" id="<?php echo esc_attr($widget_id); ?>">
                <?php echo $this->custom_anchor( $widget ); ?>
                <?php do_action( 'layers_before_'.$this->widget_id.'_widget_inner', $this, $widget ); ?>
                <?php if ('' != $this->check_and_return($widget, 'title') || '' != $this->check_and_return($widget, 'excerpt')) { ?>
                    <div class="container clearfix">
                        <?php
                        /**
                         * Generate the Section Title Classes
                         */
                        $section_title_class = array();
                        $section_title_class[] = 'section-title clearfix';
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'size');
                        $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'align');

                        //@TBD
                        $section_title_class[] = ($this->check_and_return($widget, 'design', 'background', 'color') && 'dark' == tl_layers_is_light_or_dark_recalculated($this->check_and_return($widget, 'design', 'background', 'color')) ? 'invert' : '');
                        $section_title_class = implode(' ', $section_title_class);

                        ?>
                        <div class="<?php echo esc_attr($section_title_class); ?>">
                            <?php if ('' != $widget['title']) { ?>
                                <h3 class="heading">
                                    <?php echo apply_filters('tl_colorize_title_' . $this->widget_id, $widget['title']); ?>
                                </h3>
                            <?php } ?>
                            <?php if ('' != $widget['excerpt']) { ?>
                                <div class="excerpt"><?php echo $widget['excerpt']; ?></div>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>

                <!-- HEADER SECTION END -->
                <?php //if (isset($widget['show_filters'])) : ?>
                    <div class="<?php echo esc_attr($this->get_widget_layout_class($widget)); ?> filters-wrapper <?php echo (isset($widget['show_filters']) ? '' : 'hidden') ?>">
                        <ul class="filters hidden-xs">
                            <li><a data-filter=""><?php _e('All', TL_INSERT_STAFF_SLUG); ?></a></li>
                            <li class="devider"><i class="l-close"></i></li>
                            <?php foreach ($terms as $i => $t): ?>
                                <li><a data-filter=".<?php echo esc_attr($t->slug); ?>"><?php echo esc_html($t->name); ?></a></li>
                                <?php if (count($terms) > $i + 1): ?>
                                    <li class="devider"><i class="l-close"></i></li>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </ul>

                        <div class="select-filters-wrapper visible-xs">
                            <div class="selected" data-filter=""><?php _e('All', TL_INSERT_STAFF_SLUG); ?></div>
                            <ul class="portfolio-selector hidden">
                                <li data-filter=""><?php _e('All', TL_INSERT_STAFF_SLUG); ?></li>
                                <?php foreach ($terms as $i => $t): ?>
                                    <li data-filter="<?php echo esc_attr($t->slug); ?>"><?php echo esc_html($t->name); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <!-- FILTERS END -->
                <?php //endif; ?>

                <div id="<?php echo esc_attr('swipper-' . $this->id)?>" class="<?php echo (('on' == $this->check_and_return($widget, 'design', 'gutter')) ? 'has-gutter' : '');?> <?php echo (isset($widget['show_filters']) ? 'isotope-container':'');?> list-grid <?php echo esc_attr($this->get_widget_layout_class($widget)); ?>">

                    <?php if ($post_query->have_posts()) { ?>
                        <div class="swiper-wrapper">
                        <?php while ($post_query->have_posts()) {
                            $post_query->the_post();

                                /**
                                 * Set Individual Column CSS
                                 */
                                $post_column_class = array();
                                $post_column_class[] = 'layers-masonry-column thumbnail'; //swiper-slide
                                $post_column_class[] = 'column' . ('on' != $this->check_and_return($widget, 'design', 'gutter') ? '-flush' : '');
                                $post_column_class[] = $span_class;
                                $post_column_class[] = ('overlay' == $this->check_and_return($widget, 'text_style') ? 'with-overlay' : '');
                                $post_column_class[] = ('' != $this->check_and_return($widget, 'design', 'column-background-color') && 'dark' == tl_layers_is_light_or_dark_recalculated($this->check_and_return($widget, 'design', 'column-background-color')) ? 'invert' : '');

                                // Filter classes

                                $post_terms = get_the_terms(get_the_ID(), 'tl_portfolio_category');

                                if($post_terms){
                                    foreach ($post_terms as $t) {
                                        $post_column_class[] = $t->slug;
                                    }
                                }

                                $post_column_class = implode(' ', $post_column_class);
                                ?>
                                <article class="<?php echo esc_attr($post_column_class); ?>" data-cols="<?php echo esc_attr($col_count); ?>">
                                    <?php // Layers Featured Media
                                    if (isset($widget['show_media'])) {
                                        echo layers_post_featured_media(
                                            array(
                                                'postid' => get_the_ID(),
                                                'wrap_class' => 'thumbnail-media' . ((isset($column['design']['imageratios']) && 'image-round' == $column['design']['imageratios']) ? ' image-rounded' : ''),
                                                'size' => $use_image_ratio,
                                                'hide_href' => true
                                            )
                                        );
                                    } // if Show Media ?>
                                    <?php if (isset($widget['show_titles']) || isset($widget['show_excerpts'])) { ?>
                                        <div class="thumbnail-body">
                                            <div class="overlay">
                                                <?php if (isset($widget['show_titles'])) { ?>
                                                    <header class="article-title">
                                                        <h4 class="heading"><a class="ajax-popup-link" data-title="<?php echo get_the_title_rss(); ?>" data-id="<?php the_ID(); ?>" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                    </header>
                                                <?php } ?>
                                                <?php if (isset($widget['show_categories'])) { ?>
                                                    <?php tl_layers_post_meta(get_the_ID(),
                                                        $layers_post_meta_to_display,
                                                        'footer',
                                                        'meta-info ' . ('' != $this->check_and_return($widget, 'design', 'column-background-color') &&
                                                        'dark' == tl_layers_is_light_or_dark_recalculated($this->check_and_return($widget, 'design', 'column-background-color')) ? 'invert' : ''));
                                                    ?>
                                                <?php } ?>
                                                <?php
                                                    if (isset($widget['show_excerpts']) && !isset($widget['show_filters'])) {
                                                        if (isset($widget['excerpt_length']) && '' == $widget['excerpt_length']) {
                                                            echo '<div class="excerpt">';
                                                            the_content();
                                                            echo '</div>';
                                                        } else if (isset($widget['excerpt_length']) && 0 != $widget['excerpt_length'] && strlen(get_the_excerpt()) > $widget['excerpt_length']) {
                                                            echo '<div class="excerpt">' . substr(get_the_excerpt(), 0, $widget['excerpt_length']) . '&#8230;</div>';
                                                        } else if ('' != get_the_excerpt()) {
                                                            echo '<div class="excerpt">' . get_the_excerpt() . '</div>';
                                                        }
                                                    }

                                                $btn_classes   = array();
                                                $btn_classes[] = 'button';
                                                $btn_classes[] = 'ajax-popup-link';
                                                $btn_classes[] = isset($widget['popup']) ? 'ajax-popup-link' : '';
                                                $btn_classes[] = 'btn-' . $this->check_and_return($widget, 'design', 'buttons', 'buttons-size');
                                                $btn_classes[] = $this->check_and_return($widget, 'design', 'buttons', 'animation');
                                                //$btn_classes[] = $this->check_and_return($widget, 'design', 'buttons', 'label') ? '' : 'plus';
                                                $btn_classes = implode(' ', $btn_classes);

                                                $link_label = !empty($widget['design']['buttons']['label']) ? esc_html($widget['design']['buttons']['label']) : '<i class="icon-ti-plus"></i>'

                                                ?>
                                                <?php if (isset($widget['show_call_to_action'])) { ?>
                                                    <a data-title="<?php echo get_the_title_rss(); ?>" data-id="<?php the_ID(); ?>" href="<?php the_permalink(); ?>"
                                                       class="<?php echo esc_attr($btn_classes); ?>"><?php echo $link_label; ?></a>
                                                <?php } // show call to action ?>
                                            </div>
                                        </div>
                                    <?php } // if show titles || show excerpt ?>
                                </article>
                        <?php }; // while have_posts ?>
                        </div>
                    <?php }; // if have_posts
                    ?>
                </div>
                <div class="swiper-pagination visible-xs"></div>
                <?php

                // Reset WP_Query
                wp_reset_postdata();

                do_action( 'layers_after_' . $this->id . '_widget_inner', $this, $widget );

                // Print the Inline Styles for this Widget
                $this->print_inline_css();

                // Apply the advanced widget styling
                $this->apply_widget_advanced_styling($widget_id, $widget);
                ?>
            </div>
        <?php }




        /**
         * @param array $instance
         * @return string|void
         */
        public function form($instance)
        {
            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            if(TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_start('tl_sanitize_output');

            $this->design_bar(
                'side', // CSS Class Name
                array(
                    'name' => $this->get_layers_field_name('design'),
                    'id' => $this->get_layers_field_id('design'),
                ), // Widget Object
                $widget, // Widget Values
                apply_filters('layers_' . $this->widget_id . '_widget_design_bar_components', array(
                    'layout',
                    'fonts',
                    'display' => array(
                        'icon-css' => 'icon-display',
                        'label' => __('Display', TL_INSERT_STAFF_SLUG),
                        'elements' => array(
                            'text_style' => array(
                                'type' => 'select',
                                'name' => $this->get_layers_field_name('text_style'),
                                'id' => $this->get_layers_field_id('text_style'),
                                'value' => (isset($widget['text_style'])) ? $widget['text_style'] : NULL,
                                'label' => __('Title &amp; Excerpt Position', TL_INSERT_STAFF_SLUG),
                                'options' => array(
                                    'regular' => __('Regular', TL_INSERT_STAFF_SLUG),
                                    'overlay' => __('Overlay', TL_INSERT_STAFF_SLUG)
                                )
                            ),
                            'show_filters' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('show_filters'),
                                'id' => $this->get_layers_field_id('show_filters'),
                                'value' => (isset($widget['show_filters'])) ? $widget['show_filters'] : NULL,
                                'label' => __('Show Filters', TL_INSERT_STAFF_SLUG)
                            ),
                            'hide_empty_filters' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('hide_empty_filters'),
                                'id' => $this->get_layers_field_id('hide_empty_filters'),
                                'value' => (isset($widget['hide_empty_filters'])) ? $widget['hide_empty_filters'] : NULL,
                                'label' => __('Hide Empty Filters', TL_INSERT_STAFF_SLUG)
                            ),
                            'show_media' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('show_media'),
                                'id' => $this->get_layers_field_id('show_media'),
                                'value' => (isset($widget['show_media'])) ? $widget['show_media'] : NULL,
                                'label' => __('Show Featured Images', TL_INSERT_STAFF_SLUG)
                            ),
                            'show_titles' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('show_titles'),
                                'id' => $this->get_layers_field_id('show_titles'),
                                'value' => (isset($widget['show_titles'])) ? $widget['show_titles'] : NULL,
                                'label' => __('Show  Post Titles', TL_INSERT_STAFF_SLUG)
                            ),
                            'show_excerpts' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('show_excerpts'),
                                'id' => $this->get_layers_field_id('show_excerpts'),
                                'value' => (isset($widget['show_excerpts'])) ? $widget['show_excerpts'] : NULL,
                                'label' => __('Show Post Excerpts', TL_INSERT_STAFF_SLUG)
                            ),
                            'excerpt_length' => array(
                                'type' => 'number',
                                'name' => $this->get_layers_field_name('excerpt_length'),
                                'id' => $this->get_layers_field_id('excerpt_length'),
                                'min' => 0,
                                'max' => 10000,
                                'value' => (isset($widget['excerpt_length'])) ? $widget['excerpt_length'] : NULL,
                                'label' => __('Excerpts Length', TL_INSERT_STAFF_SLUG)
                            ),
                            'show_categories' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('show_categories'),
                                'id' => $this->get_layers_field_id('show_categories'),
                                'value' => (isset($widget['show_categories'])) ? $widget['show_categories'] : NULL,
                                'label' => __('Show Tags', TL_INSERT_STAFF_SLUG),
                            ),
                            'show_call_to_action' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('show_call_to_action'),
                                'id' => $this->get_layers_field_id('show_call_to_action'),
                                'value' => (isset($widget['show_call_to_action'])) ? $widget['show_call_to_action'] : NULL,
                                'label' => __('Show "Read More" Buttons', TL_INSERT_STAFF_SLUG)
                            ),
                        )
                    ),
                    'columns',
                    'buttons',
                    'imageratios',
                    'background',
                    'advanced'
                ))
            ); ?>
            <div class="layers-container-large">
                <?php $this->form_elements()->header(array(
                    'title' => __('Portfolio', TL_INSERT_STAFF_SLUG),
                    'icon_class' => 'post'));
                ?>
                <section class="layers-accordion-section layers-content">
                    <div class="layers-row layers-push-bottom">
                        <p class="layers-form-item">
                            <?php echo $this->form_elements()->input( array(
                                    'type' => 'text',
                                    'name' => $this->get_layers_field_name('title'),
                                    'id' => $this->get_layers_field_id('title'),
                                    'placeholder' => __('Enter title here', TL_INSERT_STAFF_SLUG),
                                    'value' => (isset($widget['title'])) ? $widget['title'] : NULL,
                                    'class' => 'layers-text layers-large'
                                )
                            ); ?>
                        </p>
                        <p class="layers-form-item">
                            <?php echo $this->form_elements()->input( array(
                                    'type' => 'rte',
                                    'name' => $this->get_layers_field_name('excerpt'),
                                    'id' => $this->get_layers_field_id('excerpt'),
                                    'placeholder' => __('Short Excerpt', TL_INSERT_STAFF_SLUG),
                                    'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                    'class' => 'layers-textarea layers-large'
                                )
                            ); ?>
                        </p>
                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('order')); ?>"><?php echo __('Sort by', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(array(
                                    'type' => 'select',
                                    'name' => $this->get_layers_field_name('order'),
                                    'id' => $this->get_layers_field_id('order'),
                                    'value' => (isset($widget['order'])) ? $widget['order'] : NULL,
                                    'options' => $this->form_elements()->get_sort_options()
                                )
                            ); ?>
                        </p>
                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('num_post')); ?>"><?php echo __('Number of items', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(array(
                                    'type' => 'number',
                                    'name' => $this->get_layers_field_name('num_post'),
                                    'id' => $this->get_layers_field_id('num_post'),
                                    'value' => (isset($widget['num_post'])) ? $widget['num_post'] : NULL,
                                    'min' => -1,
                                    'max' => 100,
                                    'step' => 1,
                                )
                            ); ?>
                            <small class="layers-small-note"><?php _e('Set to -1 to list all items', TL_INSERT_STAFF_SLUG)?></small>
                        </p>
                    </div>
                </section>
            </div>
        <?php
            if(TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_end_flush();
        } // Form



        protected function _addFilters()
        {
            add_filter('tl_colorize_title_' . $this->widget_id, 'tl_colorize_title', 10, 2);
            add_filter('tl/layers/background_component/' . $this->widget_id . '/args', array($this, 'customizeBackgroundComponent'), 10, 4);
            add_filter('tl/layers/fonts_component/' . $this->widget_id . '/args'     , array($this, 'customizeFontsComponent'), 10, 4);
            add_filter('tl/layers/buttons_component/' . $this->widget_id . '/args'   , array($this, 'customizeButtonsComponent'), 10, 4);
        }


        /**
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeFontsComponent($args, $position, $widget, $values)
        {
            if($position == 'side'){

                //Add at the beggining of the array
                $args['elements'] = array('fonts-title-heading' => array('type'  => 'layers-heading', 'label' => 'Title Options')) + $args['elements'];


                // this goes to the all widgets
                $args['elements']['fonts-excerpt-heading'] = array(
                    'type'  => 'layers-heading',
                    'label' => 'Excerpt Options',
                );

                $args['elements']['fonts-excerpt-color'] = array(
                    'type'  => 'color',
                    'label' => 'Excerpt Color',
                    'name'  => $widget['name'].'[fonts][excerpt-color]',
                    'id'    => $widget['id'] . '-fonts-excerpt-color',
                    'value' => isset($values['fonts']['excerpt-color']) ? $values['fonts']['excerpt-color'] : null,
                );
            }
            return $args;
        }



        public function customizeBackgroundComponent($args, $position, $widget, $values)
        {
            if($position == 'side'){
                unset($args['elements']['background-darken']);
            }
            return $args;
        }



        public function customizeButtonsComponent($args, $position, $widget, $values)
        {
            if($position == 'side'){
                //unset($args['elements']['buttons-size']);
                unset($args['elements']['buttons-align']);
            }
            return $args;
        }



        public function enqueue_scripts()
        {
            wp_enqueue_script(LAYERS_THEME_SLUG . '-slider-js', get_template_directory_uri() . '/core/widgets/js/swiper.js',array('jquery'), LAYERS_VERSION ); // Slider
            wp_enqueue_style(LAYERS_THEME_SLUG . '-slider', get_template_directory_uri() . '/core/widgets/css/swiper.css', array(), LAYERS_VERSION ); // Slider

            // Portfolio carousel
            //wp_enqueue_script(TL_INSERT_STAFF_SLUG . 'tl-slider-js', $plugin::assetPath('js/jquery.tl-swiper.js', false, true), array(LAYERS_THEME_SLUG . '-slider-js'), TL_INSERT_STAFF_VER, true);
            wp_enqueue_script(TL_INSERT_STAFF_SLUG . 'tl-portfolio-filter', parent::asset_path('js/jquery.tl-portfolio-filter.js', false, true), array('jquery'), TL_INSERT_STAFF_VER, true);
        }



        /**
         * @param $widget_id
         * @param $widget
         */
        private function _set_default_colors($widget_id, $widget)
        {
            //$colors = \Handyman\Core\Colors::single();

            if($this->colors){
                $this->inline_css .= layers_inline_styles(array(
                    'selectors' => array('.tl-portfolio-widget .filters-wrapper'),
                    'css' => array('background-color' => $this->colors->get('_secondary'))
                ));
                $this->inline_css .= layers_inline_styles(array(
                    'selectors' => array('.tl-portfolio-widget .filters-wrapper ul.filters li a:hover', '.tl-portfolio-widget .filters-wrapper ul.filters li a.active'),
                    'css' => array('color' => $this->colors->get('_primary'))));

                // Portfolio Widget BG
                $this->inline_css .= layers_inline_styles(array( 'selectors' => array( '.' . $this->widget_class()), 'css' => array('background-color' => $this->colors->get('_primary'))));

                if($this->check_and_return($widget, 'design', 'buttons', 'text-color-hover')){
                    $this->inline_css .= layers_inline_styles('#' . $widget_id . ' .with-overlay .button:hover:after{ color:' . $this->check_and_return($widget, 'design', 'buttons', 'text-color-hover') . ';}');
                }else{
                    $this->inline_css .= layers_inline_styles('.'.$this->widget_class() . ' .with-overlay .button:hover:after{ color:' . $this->colors->get('_secondary') . ';}');
                }

                $this->inline_css .= layers_inline_styles('@media (max-width: 768px){
                                        .select-filters-wrapper,.'.$this->widget_class().' .with-overlay .button{ background-color: ' . $this->colors->get('_secondary') . ';}
                                        .select-filters-wrapper .selected{ color: ' . $this->colors->get('_primary') . ';}
                                        .'.$this->widget_class().' .with-overlay .button:after{ color:#fff;}
                                  }');
            }
        }
    } // Class

    // Add our function to the widgets_init hook.
    register_widget("TL_Layers_Portfolio_Widget");
}