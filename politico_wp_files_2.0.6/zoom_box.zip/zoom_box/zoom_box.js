jQuery.noConflict(); jQuery(document).ready(function(){

	var theBody = jQuery('body');
	
	//////////////////////////
	//ASSIGN ZOOM BOX ELEMENTS
	//////////////////////////
	function assignZoomBox(){
		jQuery(".gallery-icon a[href$='jpeg'],.gallery-icon a[href$='jpg'],.gallery-icon a[href$='png'],.gallery-icon a[href$='gif']").attr({rel: "zoomBox[gallery]"});
		jQuery("a[href$='jpeg'],a[href$='jpg'],a[href$='png'],a[href$='gif']").siblings("a[href$='jpg'],a[href$='png'],a[href$='gif']").attr({rel: "zoomBox[gallery]"});
		jQuery("a[href$='jpeg'],a[href$='jpg'],a[href$='png'],a[href$='gif']").each(function(){
			if(jQuery(this).attr('rel') != 'zoomBox[gallery]'){
				jQuery(this).attr({rel: "zoomBox"});
			}
		});
	}
	//RUN SCRIPT
	assignZoomBox();
	//RUN SCRIPT AFTER AJAX
	jQuery(document).ajaxComplete(function() {
		assignZoomBox();
	});
	
	
	//////////////
	//SINGLE CLICK
	//////////////
	jQuery(document).on('click',"a[rel='zoomBox']",function(){
		
		//CREATE BOX
		if(!jQuery('#zoomBox').length > 0){
			theBody.addClass('zoombox-open').prepend('<div id="zoomBox" class="singleBox zoomIn"><div id="imgBox"></div><div id="closeBox">×</div><div id="titleBox"></div></div>');
		}
		
		//VAR SETUP
		var zoomBox = jQuery('#zoomBox'),
			imgBox = jQuery('#imgBox'),
			titleBox = jQuery('#titleBox'),
			thisLink = jQuery(this),
			imgURL = thisLink.attr('href'),
			imgTitle = thisLink.children().attr('alt');
			
		//ADD LOADING
		zoomBox.addClass('loading').stop(true,true).fadeIn(500);
		
		//LOAD IMAGE
		jQuery('<img/>').attr('src', imgURL).load(function() {
   			jQuery(this).remove();
   			zoomBox.removeClass('loading');
   			imgBox.css({backgroundImage:"url("+imgURL+")"});
   			titleBox.html(imgTitle);
		});
		
		return false;
	});
		
	///////////////
	//GALLERY CLICK
	///////////////
	jQuery(document).on('click',"a[rel='zoomBox[gallery]']",function(){
		
		//CREATE BOX
		if(!jQuery('#zoomBox').length > 0){
			theBody.addClass('zoombox-open').prepend('<div id="zoomBox" class="zoomIn"><div id="imgBox"></div><div id="closeBox">×</div><div id="nextBox" class="boxNav">&rarr;</div><div id="prevBox" class="boxNav">&larr;</div><div id="titleBox"></div></div>');
		}
		
		//VAR SETUP
		var zoomBox = jQuery('#zoomBox'),
			imgBox = jQuery('#imgBox'),
			titleBox = jQuery('#titleBox'),
			allBoxes = jQuery('a[rel="zoomBox[gallery]"]'),
			selectedBox = jQuery('.selectedBox'),
			selectedIndex = allBoxes.index(jQuery(this)) + 1,
			lastIndex = allBoxes.index(allBoxes.filter(":last")) + 1,
			thisLink = jQuery(this),
			imgURL = thisLink.attr('href'),
			imgTitle = thisLink.children().attr('alt');
		
		//ADD LOADING
		zoomBox.addClass('loading').stop(true,true).fadeIn(500);
		
		//ASSIGN SELECTED
		selectedBox.removeClass('selectedBox');
		thisLink.addClass('selectedBox');
		
		//LOAD IMAGE
		jQuery('<img/>').attr('src', imgURL).load(function() {
   			jQuery(this).remove();
   			zoomBox.removeClass('loading');
   			//HIDE/CHANGE/SHOW IMAGE
			imgBox.stop(true,true).fadeOut(150,function(){
   				imgBox.css({backgroundImage:"url("+imgURL+")"}).stop(true,true).fadeIn(150);
   			});
   			titleBox.html(imgTitle+"<span>"+selectedIndex+" / "+lastIndex+"</span>");
		});
		
		return false;
	});
	
	//////////
	//NEXT BOX
	//////////
	jQuery(document).on('click','#nextBox',function(){
		var selectedBox = jQuery('.selectedBox'),
			allBoxes = jQuery('a[rel="zoomBox[gallery]"]'),
			selectedIndex = allBoxes.index(selectedBox),
			nextImg = allBoxes.eq(selectedIndex + 1);
			
		if(nextImg.length > 0){
			nextImg.click();
		} else {
			allBoxes.filter(":first").click();
		}
			
		return false;
	});
	
	//////////
	//PREV BOX
	//////////
	jQuery(document).on('click','#prevBox',function(){
		var selectedBox = jQuery('.selectedBox'),
			allBoxes = jQuery('a[rel="zoomBox[gallery]"]'),
			selectedIndex = allBoxes.index(selectedBox),
			prevImg = allBoxes.eq(selectedIndex - 1);
			
		if(prevImg.length > 0){
			prevImg.click();
		} else {
			allBoxes.filter(":last").click();
		}
			
		return false;
	});
	
	//////////
	//ZOOM BOX
	//////////
	jQuery(document).on('click','#imgBox',function(){
		jQuery('#zoomBox').toggleClass('zoomOut');
	});	
	
	///////////
	//CLOSE BOX
	///////////
	jQuery(document).on('click','#closeBox',function(){
		theBody.removeClass('zoombox-open');
		
		jQuery('#zoomBox').fadeOut(300,function(){
			jQuery(this).remove();
		});
		
		jQuery('.selectedBox').removeClass('selectedBox');
		
		return false;
	});
	
	////////////
	//KEYS PRESS
	////////////
	jQuery(document).keydown(function(e){
		//LEFT KEY
		if (e.keyCode == 37 && jQuery('#zoomBox').length > 0) {jQuery('#zoomBox #prevBox').click(); return false;}
		//UP KEY
		if (e.keyCode == 38 && jQuery('#zoomBox').length > 0) {jQuery('#zoomBox #nextBox').click(); return false;}
		//RIGHT KEY
		if (e.keyCode == 39 && jQuery('#zoomBox').length > 0) {jQuery('#zoomBox #nextBox').click(); return false;}
   		//DOWN KEY
		if (e.keyCode == 40 && jQuery('#zoomBox').length > 0) {jQuery('#zoomBox #prevBox').click(); return false;}
		//SPACEBAR
		if (e.keyCode == 32 && jQuery('#zoomBox').length > 0) {jQuery('#zoomBox #imgBox').click(); return false;}
		//ENTER
		if (e.keyCode == 13 && jQuery('#zoomBox').length > 0) {jQuery('#zoomBox #imgBox').click(); return false;}
		//ESCAPE
		if (e.keyCode == 27 && jQuery('#zoomBox').length > 0) {jQuery('#zoomBox #closeBox').click(); return false;}
	});

});