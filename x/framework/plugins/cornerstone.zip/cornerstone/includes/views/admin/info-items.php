<!-- <div class="tco-row">
  <div class="tco-column">
    <div class="tco-box">
      <header class="tco-box-header">
        <h2 class="tco-box-title">About</h2>
      </header>
      <div class="tco-box-content tco-pan">

        <dl class="tco-accordion">
          <dt class="tco-accordion-toggle">Allowed Post Types</dt>
          <dd class="tco-accordion-panel">
            <div class="tco-accordion-panel-inner">Cornerstone works great with posts and pages - <strong>especially in X</strong>. We're unable to guarantee it will be compatible with other post types.</div>
          </dd>
          <dt class="tco-accordion-toggle">Permissions</dt>
          <dd class="tco-accordion-panel">
            <div class="tco-accordion-panel-inner">This option will grant permission for accessing cornerstone.</div></dd>
          <dt class="tco-accordion-toggle">Enable Legacy Font Classes</dt>
          <dd class="tco-accordion-panel">
            <div class="tco-accordion-panel-inner">X no longer provides the <strong>.x-icon*</strong> classes. This was done for performance reasons. If you need these classes, you can enable them again with this setting.</div>
          </dd>
        </dl>

      </div>
    </div>
  </div>
</div>

</div> -->