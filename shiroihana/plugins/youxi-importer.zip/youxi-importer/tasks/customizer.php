<?php

function youxi_importer_handle_customizer( $data ) {

	$data = wp_parse_args( $data, array(
		'data' => '', 
		'type' => 'theme_mod', 
		'key'  => ''
	));

	try {

		$options = unserialize( $data['data'] );

		if( is_array( $options ) ) {
			if( 'theme_mod' == $data['type'] ) {
				set_theme_mod( $data['key'], $options );
			} else {
				update_option( $data['key'], $options );
			}
		} else {
			return new WP_Error( 'customizer_options_invalid_data', esc_html__( 'The supplied customizer options data is invalid.', 'youxi' ) );	
		}

	} catch( Exception $e ) {
		return new WP_Error( 'customizer_options_unknown_error', $e->getMessage() );
	}

	return esc_html__( 'Customizer options successfully imported.', 'youxi' );
}
