<?php
/**
 * Ajax handlers
 */

/*add_action('wp_ajax_nopriv_load_awesome_icons', 'load_awesome_icons');
add_action('wp_ajax_load_awesome_icons'       , 'load_awesome_icons');

add_action('wp_ajax_nopriv_load_themify_icons', 'load_themify_icons');
add_action('wp_ajax_load_themify_icons'       , 'load_themify_icons');*/

add_action('wp_ajax_nopriv_load_icons', 'load_icons');
add_action('wp_ajax_load_icons', 'load_icons');


function load_icons()
{

    $family = isset($_REQUEST['family']) ? trim($_REQUEST['family']) : 'all';

    include_once(TL_INSERT_STAFF_DIR . 'widgets/awesome-icons.php');
    global $awesome_icons;

    include_once(TL_INSERT_STAFF_DIR . 'widgets/icons.php');
    global $tl_icons;

    $html = '<div class="tl-icon-container"><ul>';
    $html .= '<li style="font-size: 10px;" data-icon="">' . __('None', TL_INSERT_STAFF_SLUG) . '</li>';

    if ($family == 'awesome') {
        foreach ($awesome_icons as $icon) {
            $html .= '<li data-icon="fa ' . $icon . '"><i class="fa ' . esc_attr($icon) . '"></i></li>';
        }
    } elseif ($family == 'themify') {
        foreach ($tl_icons as $icon) {
            $html .= '<li data-icon="icon-' . $icon . '"><i class="' . esc_attr('icon-' . $icon) . '"></i></li>';
        }
    } else {
        foreach ($awesome_icons as $icon) {
            $html .= '<li data-icon="fa ' . $icon . '"><i class="fa ' . esc_attr($icon) . '"></i></li>';
        }
        foreach ($tl_icons as $icon) {
            $html .= '<li data-icon="icon-' . $icon . '"><i class="' . esc_attr('icon-' . $icon) . '"></i></li>';
        }
    }

    $html .= '</ul></div>';
    die($html);
}


function load_awesome_icons()
{
    $html = '<div class="tl-icon-container"><ul>';
    $html .= '<li style="font-size: 10px;" data-icon="">' . __('None', TL_INSERT_STAFF_SLUG) . '</li>';
    foreach ($awesome_icons as $icon) {
        $html .= '<li data-icon="fa ' . $icon . '"><i class="fa ' . esc_attr($icon) . '"></i></li>';
    }
    $html .= '</ul></div>';
    die($html);
}

function load_themify_icons()
{
    include_once(TL_INSERT_STAFF_DIR . 'widgets/icons.php');
    global $tl_icons;

    $html = '<div class="tl-icon-container"><ul>';
    $html .= '<li style="font-size: 10px;" data-icon="">' . __('None', TL_INSERT_STAFF_SLUG) . '</li>';
    foreach ($tl_icons as $icon) {
        $html .= '<li data-icon="icon-' . $icon . '"><i class="' . esc_attr('icon-' . $icon) . '"></i></li>';
    }
    $html .= '</ul></div>';
    die($html);
}


/**
 * Add new column for Custom Layers Widget
 */
//add_action('wp_ajax_layers_team_widget_actions'      , 'layers_tl_widget_actions');
//add_action('wp_ajax_layers_service_widget_actions'   , 'layers_tl_widget_actions');
//add_action('wp_ajax_layers_pricetable_widget_actions', 'layers_tl_widget_actions');
//add_action('wp_ajax_layers_tl_content_widget_actions', 'layers_tl_widget_actions');

//add_action( 'wp_ajax_layers_widget_new_repeater_item', array( $this, 'widget_new_repeater_item' ) );

function layers_tl_widget_actions()
{
    if (!check_ajax_referer('layers-widget-actions', 'nonce', false)) die('You threw a Nonce exception'); // Nonce

    if ($_POST['action'] == 'layers_service_widget_actions') {
        $widget = new TL_Layers_Services_Widget();
    } elseif ($_POST['action'] == 'layers_pricetable_widget_actions') {
        $widget = new TL_Layers_Pricetable_Widget();
    } elseif ($_POST['action'] == 'layers_team_widget_actions') {
        $widget = new TL_Layers_Team_Widget();
    } else {
        $widget = new TL_Layers_Content_Widget();
    }

    if ('add' == $_POST['widget_action']) {

        // Get the previous element's column data
        parse_str(
            urldecode(stripslashes($_POST['instance'])),
            $data
        );

        // Get the previous element's column data
        if (isset($data['widget-' . $_POST['id_base']]) && isset($_POST['last_guid']) && is_numeric($_POST['last_guid'])) {
            $instance = $data['widget-' . $_POST['id_base']][$_POST['number']]['columns'][$_POST['last_guid']];
        } else {
            $instance = NULL;
        }

        $widget->column_item(array('id_base' => $_POST['id_base'], 'number' => $_POST['number']), NULL, $instance);
    }
    die();
}