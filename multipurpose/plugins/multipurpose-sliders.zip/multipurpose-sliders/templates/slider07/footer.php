  </div>
  <div class="controls">
    <ul class="slider-titles">
%THUMBNAILS_LIST%
    </ul>
    <p>%FOOTER_BUTTON% %FOOTER_LINK_MORE%</p>
  </div>
</div></div></section>
