(function($) {
  "use strict";
  
	$(function(){
		$('#submitfrm').click(function(){
			parent.tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_dropcap textcolor="'+jQuery('#textcolor').val()+'"  bgcolor="'+jQuery('#bgcolor').val()+'"]'+ parent.tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_dropcap]');
			parent.tb_remove()
		});
	})
	
	$(document).ready(function($){
        $('#bgcolor').iris({
            hide: false,
            palettes: ['#16A085', '#27AE60', '#2980B9', '#8E44AD', '#2C3E50', '#F39C12', '#D35400', '#C0392B', '#BDC3C7', '#7F8C8D'],
			change: function(event, ui) {
				// event = standard jQuery event, produced by whichever control was changed.
				// ui = standard jQuery UI object, with a color member containing a Color.js object
			
				// change the headline color
				$("#textchange").css( 'background-color', ui.color.toString());
			}
        });
		
		
		$('#textcolor').iris({
            hide: false,
            palettes: ['#16A085', '#27AE60', '#2980B9', '#8E44AD', '#2C3E50', '#F39C12', '#D35400', '#C0392B', '#BDC3C7', '#7F8C8D'],
			change: function(event, ui) {
				// event = standard jQuery event, produced by whichever control was changed.
				// ui = standard jQuery UI object, with a color member containing a Color.js object
			
				// change the headline color
				$("#textchange").css( 'color', ui.color.toString());
			}
        });
    });
	
})(jQuery); 

