<?php
if( !defined('_MULTIPURPOSE_SHORTCODE')) die('Access denied');

require_once(_MULTIPURPOSE_SHORTCODE_PLUGIN_LIBS_PATH.'add_button.php');
require_once _MULTIPURPOSE_SHORTCODE_PLUGIN_LIBS_PATH.'helpers.php';

if(is_dir(_MULTIPURPOSE_SHORTCODE_PLUGIN_SHORTCODES_PATH))
{
    if ($handle = opendir(_MULTIPURPOSE_SHORTCODE_PLUGIN_SHORTCODES_PATH)) {
        while (false !== ($file = readdir($handle)))
        {
            if ($file != "." && $file != ".." && strtolower(substr($file, strrpos($file, '.') + 1)) == 'php')
            {
                $shortcode_file = _MULTIPURPOSE_SHORTCODE_PLUGIN_SHORTCODES_PATH.$file;
                if(file_exists($shortcode_file))
                {
                    require_once($shortcode_file);
                }
            }
        }
        
        closedir($handle);
    }
}