<?php

$swm_sample_image = plugin_dir_url( __FILE__ ) . 'images/';
$swm_google_map_sample = $swm_sample_image . 'google_map_link.jpg';
$swm_google_map_img = '<img src="'.$swm_google_map_sample.'" alt="Google map screenshot" />';

function swm_one_to_final_number ( $final_number, $all = true, $default = false, $start_number = 1 ) {
	if($all) {
		$count_number['-1'] = 'All';
	}

	if($default) {
		$count_number[''] = 'Default';
	}

	foreach(range($start_number, $final_number) as $number) {
		$count_number[$number] = $number;
	}

	return $count_number;
}

// Fontawesome icons list
$fontAwesomeFile = '';
$fontStyleCode = '/\.(fa-(?:\w+(?:-)?)+):before\s+{\s*content:\s*"(.+)";\s+}/';
$fontAwesomeFilePath = SWM_PLUGIN_DIR . 'fonts/font-awesome.css';

if ( file_exists($fontAwesomeFilePath) ) {	
	$fontAwesomeFile = file_get_contents($fontAwesomeFilePath);
}

preg_match_all($fontStyleCode,$fontAwesomeFile, $matches, PREG_SET_ORDER);

$font_icons = array();

foreach($matches as $match){
	$font_icons[$match[1]] = $match[2];
}

$column_position = array(
	'type' => 'select',
	'label' => __('Column Position', 'swmtranslate'),
	'desc' => __('Select "First" if this column is first ( left column )', 'swmtranslate'),
	'options' => array(
	'other' => '',
	'first' => __('First Column', 'swmtranslate')						
	)
);


/* ************************************************************************************** 
     COLUMNS
************************************************************************************** */

$swm_shortcodes['animatedcolumn'] = array(
	'params' => array(),
	'shortcode' => ' {{child_shortcode}} ', // as there is no wrapper shortcode
	'popup_title' => __('Columns', 'swmtranslate'),
	'no_preview' => true,
	
	// child shortcode is clonable & sortable
	'child_shortcode' => array(
		'params' => array(
			'column' => array(
				'type' => 'select',
				'label' => __('Column Width', 'swmtranslate'),
				'desc' => __('Select the width of the column.', 'swmtranslate'),
				'options' => array(
					'swm_one_third' => __('One Third', 'swmtranslate'),					
					'swm_two_third' => __('Two Third', 'swmtranslate'),					
					'swm_one_half' => __('One Half', 'swmtranslate'),					
					'swm_one_fourth' => __('One Fourth', 'swmtranslate'),					
					'swm_three_fourth' => __('Three Fourth', 'swmtranslate'),
					'swm_one_fifth' => __('One Fifth', 'swmtranslate'),					
					'swm_four_fifth' => __('Four Fifth', 'swmtranslate'),					
					'swm_one_sixth' => __('One Sixth', 'swmtranslate'),					
					'swm_five_sixth' => __('Five Sixth', 'swmtranslate'),					
				)
			),
			'position' => array(
				'type' => 'select',
				'label' => __('Column Position', 'swmtranslate'),
				'desc' => __('If this is first column in row then select "First" from above dropdown menu.', 'swmtranslate'),
				'options' => array(
					'other' => __('Other', 'swmtranslate'),					
					'first' => __('First', 'swmtranslate')										
				)
			),
			'animation_style' => array(
				'type' => 'select',
				'label' => __('Animation Style', 'swmtranslate'),
				'desc' => __('Select column animation style', 'swmtranslate'),
				'options' => array(
					'none' => __('None', 'swmtranslate'),
					'move_left_to_right' => __('Move Left to Right', 'swmtranslate'),					
					'move_right_to_left' => __('Move Right to Left', 'swmtranslate'),					
					'move_top_to_bottom' => __('Move Top to Bottom', 'swmtranslate'),					
					'move_bottom_to_top' => __('Move Bottom to Top', 'swmtranslate'),					
					'swm_center_expand' => __('Expand from Center', 'swmtranslate')									
				)
			),
			'content' => array(
				'std' => 'Add colulmn content here',
				'type' => 'textarea',
				'label' => __('Column Content', 'swmtranslate'),
				'desc' => __('Add the column content.', 'swmtranslate'),
			)
		),
		'shortcode' => '[{{column}} position="{{position}}" animation_style="{{animation_style}}"] {{content}} [/{{column}}] ',
		'clone_button' => __('Add New Column', 'swmtranslate')
	)
);

/* ************************************************************************************** 
   HORIZONTAL MENU
************************************************************************************** */

$swm_shortcodes['horizontalmenu'] = array(         
        'params' => array(
            'text1' => array(
                'std' => __('Tab 1 Text', 'swmtranslate'),
                'type' => 'text',
                'label' => __('Tab 1 Text', 'swmtranslate'),
                'desc' => '',
            ),
            'link1' => array(
			'std' => '#',
			'type' => 'text',
			'label' => __('Tab 1 link', 'swmtranslate'),
			'desc' => '',
			),
			'text2' => array(
                'std' => __('Tab 2 Text', 'swmtranslate'),
                'type' => 'text',
                'label' => __('Tab 2 Text', 'swmtranslate'),
                'desc' => '',
            ),
            'link2' => array(
			'std' => '#',
			'type' => 'text',
			'label' => __('Tab 2 link', 'swmtranslate'),
			'desc' => '',
			),
			'text3' => array(
                'std' => __('Tab 3 Text', 'swmtranslate'),
                'type' => 'text',
                'label' => __('Tab 3 Text', 'swmtranslate'),
                'desc' => '',
            ),
            'link3' => array(
			'std' => '#',
			'type' => 'text',
			'label' => __('Tab 3 link', 'swmtranslate'),
			'desc' => '',
			),
			'text4' => array(
                'std' => __('Tab 4 Text', 'swmtranslate'),
                'type' => 'text',
                'label' => __('Tab 4 Text', 'swmtranslate'),
                'desc' => '',
            ),
            'link4' => array(
			'std' => '#',
			'type' => 'text',
			'label' => __('Tab 4 link', 'swmtranslate'),
			'desc' => '',
			)
        ),
        'shortcode' => '[horizontal_tab]
[menu_tab text="{{text1}}" link="{{link1}}" active="true"]
[menu_tab text="{{text2}}" link="{{link2}}"]
[menu_tab text="{{text3}}" link="{{link3}}"]
[menu_tab text="{{text4}}" link="{{link4}}" ]
[/horizontal_tab]',        
		'no_preview' => true, 
		'popup_title' => __('Horizontal Menu', 'swmtranslate')   
);


/* **************************************************************************************
   IMAGE SLIDER
************************************************************************************** */

$swm_shortcodes['imageslider'] = array(
    'params' => array(
    	'animation_type' => array(
			'type' => 'select',
			'label' => __('Animation Type', 'swmtranslate'),
			'desc' => '',
			'options' => array(					
				'fade' => __('Fade', 'swmtranslate'),
				'slide' => __('Slide', 'swmtranslate')												
			)
		),
		'auto_play' => array(
			'type' => 'select',
			'label' => __('Auto Play', 'swmtranslate'),
			'desc' => '',
			'options' => array(					
				'true' => __('Yes', 'swmtranslate'),
				'false' => __('No', 'swmtranslate')												
			)
		),
		'bullet_navigation' => array(
			'type' => 'select',
			'label' => __('Display Bullet Navigation', 'swmtranslate'),
			'desc' => '',
			'options' => array(					
				'true' => __('Yes', 'swmtranslate'),
				'false' => __('No', 'swmtranslate')												
			)
		),
		'arrow_navigation' => array(
			'type' => 'select',
			'label' => __('Display Arrow Navigation', 'swmtranslate'),
			'desc' => '',
			'options' => array(					
				'true' => __('Yes', 'swmtranslate'),
				'false' => __('No', 'swmtranslate')												
			)
		),
		'slide_interval' => array(
			'type' => 'text',
			'label' => __('Slideshow Speed', 'swmtranslate'),
			'desc' => __('Intreval between two slides. 1000=1 second, 5000= 5 second', 'swmtranslate'),
			'std' => '5000'		
		)
    ),
    'no_preview' => true,
    'shortcode' => '[swm_image_slider animation_type="{{animation_type}}" auto_play="{{auto_play}}" bullet_navigation="{{bullet_navigation}}" arrow_navigation="{{arrow_navigation}}" slide_interval="{{slide_interval}}"] {{child_shortcode}} [/swm_image_slider]',
    'popup_title' => __('Image Slider', 'swmtranslate'),
    
    'child_shortcode' => array(
        'params' => array(
            'src' => array(
				'type' => 'upload',
				'label' => __('Image', 'swmtranslate'),
				'desc' => __('Maximum image width : 940px, height size is flexible.', 'swmtranslate')				
			),
			'link' => array(
				'type' => 'text',
				'label' => __('Link on Image', 'swmtranslate'),
				'desc' => __('Add link to open page or post by click on image', 'swmtranslate'),
				'std' => '#'
			)
			                      
        ),        
        'shortcode' => '[swm_image_slide src="{{src}}" link="{{link}}" alt=""]',
		'no_preview' => true, 
        'clone_button' => __('Add Another Slide', 'swmtranslate')
    )
);

/* ************************************************************************************** 
  RECENT POSTS
************************************************************************************** */

$recent_posts_cat = array(
	'type' => 'text',
	'label' => __('Categories', 'swmtranslate'),
	'desc' => __('If you want to display specific category(ies) recent posts only, then add Category IDs with comma seperated (e.g. 1,2,3) or <strong>Leave it blank for default.</strong>', 'swmtranslate'),
	'std' => ''		
);
$recent_posts_exclude= array(
	'type' => 'text',
	'label' => __('Exclude Categories', 'swmtranslate'),
	'desc' => __('add post categories IDs with comma seperate to exclude from post list', 'swmtranslate'),
	'std' => ''		
);
$recent_posts_desc_limit = array(
	'type' => 'text',
	'label' => __('Description Limit', 'swmtranslate'),
	'desc' => __('Number of characters to display in summery text', 'swmtranslate'),
	'std' => '150'
);
$recent_posts_read_more_text = array(
	'type' => 'text',
	'label' => __('Read More Link Text', 'swmtranslate'),
	'desc' => __('Leave it blank to hide "Read More" link', 'swmtranslate'),
	'std' => 'Read more'
);
$recent_posts_post_limit = array(
	'type' => 'text',
	'label' => __('Post Limit', 'swmtranslate'),
	'desc' => __('Number of posts to display', 'swmtranslate'),
	'std' => '2'
);

// Recent Posts Tiny

$swm_shortcodes['recentpoststiny'] = array(
	'params' => array(
		'post_limit' => $recent_posts_post_limit, 			
		'cat'  => $recent_posts_cat,
		'exclude' => $recent_posts_exclude
	),
	'shortcode' => '[recent_posts_tiny post_limit="{{post_limit}}" cat="{{cat}}" exclude="{{exclude}}"]',
	'no_preview' => true, 
	'popup_title' => __('Recent Posts', 'swmtranslate')
);

// Recent Posts Full

$swm_shortcodes['recentpostsfull'] = array(
	'params' => array(
		'column' => array(
			'type' => 'select',
			'label' => __('Display Column', 'swmtranslate'),
			'desc' => __('Select display column for recent posts', 'swmtranslate'),
			'std' => '3',
			'options' => array(
				'2' => __('2 Column', 'swmtranslate'),
				'3' => __('3 Column', 'swmtranslate'),
				'4' => __('4 Column', 'swmtranslate')								
			)
		),
		'display_posts' => $recent_posts_post_limit,
		'desc_limit' => $recent_posts_desc_limit,
		'read_more_text' => $recent_posts_read_more_text,
		'date_comments' => array(
			'type' => 'select',
			'label' => __('Display Date and Comments', 'swmtranslate'),
			'desc' => '',
			'std' => '3',
			'options' => array(
				'true' => __('Yes', 'swmtranslate'),
				'false' => __('No', 'swmtranslate')								
			)
		),
		'cat'  => $recent_posts_cat,
		'exclude' => $recent_posts_exclude
	),
	'shortcode' => '[recent_posts_full column="{{column}}" display_posts="{{display_posts}}" desc_limit="{{desc_limit}}" read_more_text="{{read_more_text}}" date_comments="{{date_comments}}" cat="{{cat}}" exclude="{{exclude}}"]',
	'no_preview' => true, 
	'popup_title' => __('Recent Posts', 'swmtranslate')
);

// Recent Posts Square Style

$swm_shortcodes['recentpostssquare'] = array(
	'params' => array(
		'post_limit' => $recent_posts_post_limit, 
		'desc_limit' => $recent_posts_desc_limit,			
		'cat'  => $recent_posts_cat,
		'exclude' => $recent_posts_exclude
	),
	'shortcode' => '[recent_posts_square post_limit="{{post_limit}}" desc_limit="{{desc_limit}}" cat="{{cat}}" exclude="{{exclude}}"]',
	'no_preview' => true, 
	'popup_title' => __('Recent Posts', 'swmtranslate')
);

/* ************************************************************************************** 
   LATEST EVENTS FULL
************************************************************************************** */

$swm_shortcodes['upcomingeventsfull'] = array(
	'params' => array(		
		'display_posts' => $recent_posts_post_limit,
		'desc_limit' => $recent_posts_desc_limit,
		'event_type' => array(
			'type' => 'select',
			'label' => __('Event Type', 'swmtranslate'),
			'desc' => '',
			'options' => array(					
				'upcoming' => __('Upcoming', 'swmtranslate'),
				'past' => __('Past', 'swmtranslate')												
			)
		),
		'read_more_text' => $recent_posts_read_more_text
	),
	'shortcode' => '[upcoming_events_full display_posts="{{display_posts}}" desc_limit="{{desc_limit}}" event_type="{{event_type}}" read_more_text="{{read_more_text}}" ]',
	'no_preview' => true, 
	'popup_title' => __('Recent Events', 'swmtranslate')
);

/* ************************************************************************************** 
   LATEST CAUSE
************************************************************************************** */

$swm_shortcodes['recentcausefull'] = array(
	'params' => array(		
		'display_posts' => $recent_posts_post_limit,
		'desc_limit' => $recent_posts_desc_limit,
		'read_more_text' => $recent_posts_read_more_text,
		'exclude' => $recent_posts_exclude
	),
	'shortcode' => '[recent_cause display_posts="{{display_posts}}" desc_limit="{{desc_limit}}" read_more_text="{{read_more_text}}" exclude="{{exclude}}" ]',
	'no_preview' => true, 
	'popup_title' => __('Recent Cause', 'swmtranslate')
);

/* ************************************************************************************** 
   LATEST SERMONS
************************************************************************************** */


$swm_shortcodes['recentsermonsfull'] = array(
	'params' => array(		
		'display_posts' => $recent_posts_post_limit,
		'desc_limit' => $recent_posts_desc_limit,
		'read_more_text' => $recent_posts_read_more_text,
		'exclude' => $recent_posts_exclude
	),
	'shortcode' => '[recent_sermons display_posts="{{display_posts}}" desc_limit="{{desc_limit}}" read_more_text="{{read_more_text}}" exclude="{{exclude}}" ]',
	'no_preview' => true, 
	'popup_title' => __('Recent Sermons', 'swmtranslate')
);

/* ************************************************************************************** 
	TESTIMONIALS
************************************************************************************** */

$swm_shortcodes['testimonials'] = array(
	'params' => array(
		'display_testimonials' => array(
			'type' => 'text',
			'label' => __('Number of Testimonials', 'swmtranslate'),
			'desc' => __('Enter number to display testimonials', 'swmtranslate'),
			'std' => '3'		
		),
		'columns' => array(
			'type' => 'select',
			'label' => __('Display Column', 'swmtranslate'),
			'desc' => '',
			'std' => '3',
			'options' => array(
				'1' => __('1 Column', 'swmtranslate'),
				'2' => __('2 Column', 'swmtranslate'),				
				'3' => __('3 Column', 'swmtranslate'),		
				'4' => __('4 Column', 'swmtranslate')			
			)
		),		
		'client_img' => array(
			'type' => 'select',
			'label' => __('Client Image', 'swmtranslate'),
			'desc' => '',
			'options' => array(
				'true' => __('Display Client Image', 'swmtranslate'),				
				'false' => __('Hide Client Image', 'swmtranslate')				
			)
		),
		'exclude' => array(
			'type' => 'text',
			'label' => __('Exclude Categories', 'swmtranslate'),
			'desc' => __('add testimonials categories IDs with comma seperate to exclude from display', 'swmtranslate'),
			'std' => ''		
		),
		'infotext' => array(
			'type' => 'infotext',
			'label' => __('Note', 'swmtranslate'),
			'desc' => '',
			'std' => __('Add Testimonials from left sidebar menu Testimonials > Add New ', 'swmtranslate')
		)
	),
	'shortcode' => '[swm_testimonials display_testimonials="{{display_testimonials}}" columns="{{columns}}" client_img="{{client_img}}" exclude="{{exclude}}"]',
	'no_preview' => true,
	'popup_title' => __('Testimonials', 'swmtranslate')
);


/* ************************************************************************************** 
	TESTIMONIALS SLIDER
************************************************************************************** */

$swm_shortcodes['testimonialsslider'] = array(
	'params' => array(		
		'client_img' => array(
			'type' => 'select',
			'label' => __('Client Image', 'swmtranslate'),
			'desc' => '',
			'options' => array(
				'true' => __('Display Client Image', 'swmtranslate'),				
				'false' => __('Hide Client Image', 'swmtranslate')				
			)
		),
		'animation_type' => array(
			'type' => 'select',
			'label' => __('Animation Type', 'swmtranslate'),
			'desc' => '',
			'options' => array(					
				'fade' => __('Fade', 'swmtranslate'),
				'horizontal' => __('Horizontal', 'swmtranslate'),												
				'vertical' => __('Vertical', 'swmtranslate'),
			)
		),		
		'slide_interval' => array(
			'type' => 'text',
			'label' => __('Slideshow Speed', 'swmtranslate'),
			'desc' => __('Intreval between two slides. 1000=1 second, 5000= 5 second', 'swmtranslate'),
			'std' => '5000'		
		),
		'slide_limit' => array(
			'type' => 'text',
			'label' => __('Slide Limit', 'swmtranslate'),
			'desc' => __('Enter number to display testimonials slides in slideshows', 'swmtranslate'),
			'std' => '3'		
		)
	),	
	'shortcode' => '[swm_testimonials_slider client_img="{{client_img}}" animation_type="{{animation_type}}" slide_interval="{{slide_interval}}" slide_limit="{{slide_limit}}"]',
	'no_preview' => true,
	'popup_title' => __('Testimonials Slider', 'swmtranslate')
);

/* ************************************************************************************** 
   VIDEO
************************************************************************************** */

$swm_shortcodes['video'] = array(
	'params' => array(
		'source' => array(
			'type' => 'text',
			'label' => __('Video URL', 'swmtranslate'),
			'desc' => __('Enter embed YouTube/Vimeo video URL.<br />Use sample URLs and replace video ids in  sample URL<br /> YouTube : http://www.youtube.com/embed/sn1GG20V_m8 <br />Vimeo: http://player.vimeo.com/video/30955798 <br /> ', 'swmtranslate'),
			'std' => 'http://www.youtube.com/embed/sn1GG20V_m8'
		)		
	),
	'shortcode' => '[swm_video source="{{source}}" ]',
	'no_preview' => true, 
	'popup_title' => __('Video', 'swmtranslate')
);

/* ************************************************************************************** 
	SUPPORT TEAM
************************************************************************************** */

$swm_shortcodes['supportteam'] = array(
	'params' => array(
		'image_src' => array(
			'type' => 'upload',
			'label' => __('Team Member Image', 'swmtranslate'),
			'desc' => __('Size - 99px width and 93px height', 'swmtranslate')
			
		),
		'name' => array(
			'type' => 'text',
			'label' => __('Name', 'swmtranslate'),
			'desc' => '',
			'std' => __('John Doe', 'swmtranslate')
		),
		'position' => array(
			'type' => 'text',
			'label' => __('Position', 'swmtranslate'),
			'desc' => '',
			'std' => __('Project Manager', 'swmtranslate')
		),		
		'email' => array(
			'type' => 'text',
			'label' => __('Email Id', 'swmtranslate'),
			'desc' => '',
			'std' => __('info@yourdomain.com', 'swmtranslate')
		),	
		'phone' => array(
			'type' => 'text',
			'label' => __('Phone No.', 'swmtranslate'),
			'desc' => '',
			'std' => '880-654-3210'
		)		
		
	),
	'shortcode' => '[support_team image_src="{{image_src}}" name="{{name}}" position="{{position}}" email="{{email}}" phone="{{phone}}" ]',
	'no_preview' => true, 
	'popup_title' => __('Support Team', 'swmtranslate')
);

/* ************************************************************************************** 
	TOOLTIPS
************************************************************************************** */

$swm_shortcodes['tooltip'] = array(
	'params' => array(
		'position' => array(
			'type' => 'select',
			'label' => __('Tooltip Position', 'swmtranslate'),
			'desc' => __('Select tooltip display position', 'swmtranslate'),
			'options' => array(
				'tipUp' => __('Up', 'swmtranslate'),
				'tipDown' => __('Down', 'swmtranslate'),	
				'tipLeft' => __('Left', 'swmtranslate'),
				'tipRight' => __('Right', 'swmtranslate')
			)
		),
		'tooltip_text' => array(
			'std' => __('Exmaple of tooltip text', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Tooltip Text', 'swmtranslate'),
			'desc' => __('Enter text which you want to display in tooltip', 'swmtranslate'),
		),
		'content' => array(
			'std' => __('Tooltip', 'swmtranslate'),
			'type' => 'text',
			'label' => __('Content', 'swmtranslate'),
			'desc' => ''
		)
		
	),
	'shortcode' => '[swm_tooltip position="{{position}}" tooltip_text="{{tooltip_text}}"] {{content}} [/swm_tooltip]',
	'no_preview' => true, 
	'popup_title' => __('Tooltips', 'swmtranslate')
);

/* ************************************************************************************** 
    MAP
************************************************************************************** */

$swm_shortcodes['googlemap'] = array(
	'params' => array(		
		'height' => array(
                'std' => '300',
                'type' => 'text',
                'label' => __('Google Map Height', 'swmtranslate'),
                'desc' => '',
            ),
		'src' => array(
                'std' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.313975261218!2d-74.00583600840093!3d40.71110418241921!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sin!4v1440259795109',
                'type' => 'text',
                'label' => __('Google Map Link', 'swmtranslate'),
                'desc' => __( '<a href="https://www.youtube.com/watch?v=HjZHkEWTCYg" target="_blank">Video tutorial to get google map embed code</a>', 'swmtranslate' ),
            )		
	),
	'shortcode' => '[google_map height="{{height}}" src="{{src}}"] ',
	'no_preview' => true, 
	'popup_title' => __('Google Map ', 'swmtranslate')
);

/* ************************************************************************************** 
   SOCIAL MEDIA
************************************************************************************** */

$swm_shortcodes['socialmedia'] = array(
	'params' => array(),
    'no_preview' => true,
    'shortcode' => '[social_media_icons] {{child_shortcode}} [/social_media_icons]',
    'popup_title' => __('Social Media Icons', 'swmtranslate'),
    
    'child_shortcode' => array(
        'params' => array(            
			 'icon_name' => array(
				'type' => 'text',
				'label' => __('Social Media Icon', 'swmtranslate'),
				'desc' => __('You can refer social media icon from this page :<a href="http://fortawesome.github.io/Font-Awesome/icons/#brand" target="_blank">FontAwesome</a>', 'swmtranslate'),				
				'std' => 'fa-twitter'
			),	
            'link' => array(
			'type' => 'text',
			'label' => __('Link', 'swmtranslate'),
			'desc' => '',
			'std' => '#'
			),
        ),
        'shortcode' => '[{{icon_name}} link="{{link}}"]',
		'no_preview' => true, 
        'clone_button' => __('Add Another Icon', 'swmtranslate')
    )
);

/* ************************************************************************************** 
  TEAM MEMBER
************************************************************************************** */

$swm_shortcodes['teammember'] = array(
	'params' => array(		
		'image_src' => array(
			'type' => 'upload',
			'label' => __('Team Member Photo', 'swmtranslate'),
			'desc' => __('Upload team member image - size: 689 x 689 ( height size is flexible)', 'swmtranslate')			
		),
		'name' => array(
			'type' => 'text',
			'label' => __('Name', 'swmtranslate'),
			'desc' => '',
			'std' => __('John Doe', 'swmtranslate')
		),
		'position' => array(
			'type' => 'text',
			'label' => __('Position', 'swmtranslate'),
			'desc' => '',
			'std' => __('Project Manager', 'swmtranslate')
		),		
		'content' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __('Team Member Info', 'swmtranslate'),
			'desc' => __('if Team Member Style is "Team Member with Large Text"  then add text otherwise leave it blank.', 'swmtranslate'),
		),		
		'column' => array(
			'type' => 'select',
			'label' => __('Display Column', 'swmtranslate'),
			'desc' => '',
			'std' => '',
			'options' => array(				
				'swm_one_half' => __('2 Column', 'swmtranslate'),
				'swm_one_third' => __('3 Column', 'swmtranslate'),
				'swm_one_fourth' => __('4 Column', 'swmtranslate'),
				'swm_one_fifth' => __('5 Column', 'swmtranslate'),
				'swm_one_sixth' => __('6 Column', 'swmtranslate')													
			)
		),
		'column_position' => $column_position
	),
	'shortcode' => '[team_member image_src="{{image_src}}" name="{{name}}" position="{{position}}" column="{{column}}" column_position="{{column_position}}"] {{content}} [/team_member]',
	'no_preview' => true, 
	'popup_title' => __('Team Member', 'swmtranslate')
);

/* ************************************************************************************** 
  	IMAGE FRAME WITH ALIGNMENT
************************************************************************************** */

$swm_shortcodes['image'] = array(	
	'params' => array(
		'src' => array(
			'type' => 'upload',
			'label' => __('Image', 'swmtranslate'),
			'desc' => ''			
		),		
		'link' => array(
			'type' => 'text',
			'label' => __('Link on Image', 'swmtranslate'),
			'desc' => __('If you want to add lightbox property on this image then give full size image path in above box.', 'swmtranslate'),
			'std' => '#'
		),
		'align' => array(
			'type' => 'select',
			'label' => __('Image Alignment', 'swmtranslate'),
			'desc' => __('Select column as per images size.', 'swmtranslate'),
			'options' => array(
				'left' => __('Left Align', 'swmtranslate'),
				'right' => __('Right Align', 'swmtranslate'),
				'center' => __('Center Align', 'swmtranslate')											
			)
		),				
		'alt' => array(
			'type' => 'text',
			'label' => __('Image Alternate Text', 'swmtranslate'),
			'desc' => '',
			'std' => ''
		),		
		'title' => array(
			'type' => 'text',
			'label' => __('Image Title Text', 'swmtranslate'),
			'desc' => '',
			'std' => ''
		)		
	),
	'shortcode' => '[swm_image src="{{src}}" align="{{align}}" link="{{link}}" alt="{{alt}}" title="{{title}}"]',
	'no_preview' => true, 
	'popup_title' => __('Image', 'swmtranslate')
);

/* ************************************************************************************** 
 	PROMOTION BOX
************************************************************************************** */

$swm_shortcodes['promotionbox'] = array(
	'params' => array(
		'button_text' => array(
			'type' => 'text',
			'label' => __('Button Text', 'swmtranslate'),
			'desc' => __('If you want to hide button then leave this field blank', 'swmtranslate'),
			'std' => __('Signup Now!', 'swmtranslate')
		),
		'button_link' => array(
			'type' => 'text',
			'label' => __('Button Link', 'swmtranslate'),
			'desc' => '',
			'std' => '#'
		),		
		'content' => array(
			'std' => __('This is title text of promotion box', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Promotion Text', 'swmtranslate'),
			'desc' => __('Add the promotion text', 'swmtranslate'),
		),
		'title_text_color' => array(
			'type' => 'color',
			'label' => __('Title Text Color', 'swmtranslate'),
			'desc' => '',
			'std' => '#575757'
		),
		'title_text_size' => array(
				'type' => 'select',
				'label' => __('Title Text Size', 'swmtranslate'),
				'desc' => '',
				'std' => '22',
				'options' => swm_one_to_final_number( 72, false, false )
		),
		'sub_text' => array(
			'std' => __('this is sub line promo text', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Sub Text', 'swmtranslate'),
			'desc' => __('Add the subline promotext', 'swmtranslate'),
		),
		'sub_text_color' => array(
			'type' => 'color',
			'label' => __('Sub Text Color', 'swmtranslate'),
			'desc' => '',
			'std' => '#575757'
		),		
		'sub_text_size' => array(
				'type' => 'select',
				'label' => __('Sub Text Size', 'swmtranslate'),
				'desc' => '',
				'std' => '13',
				'options' => swm_one_to_final_number( 36, false, false )
		),		
		'border' => array(
			'type' => 'select',
			'label' => __('Display Border Around Box', 'swmtranslate'),
			'desc' => '',
			'options' => array(
				'true' => __('Yes', 'swmtranslate'),
				'false' => __('No', 'swmtranslate')		
			)
		),

	),
	'shortcode' => '[swm_promotion_box button_text="{{button_text}}" button_link="{{button_link}}" title_text_color="{{title_text_color}}" title_text_size="{{title_text_size}}" sub_text="{{sub_text}}" sub_text_color="{{sub_text_color}}" sub_text_size="{{sub_text_size}}" border="{{border}}" ] {{content}} [/swm_promotion_box]',
	'no_preview' => true,
	'popup_title' => __('Promo Box', 'swmtranslate')
);

/* ************************************************************************************** 
   PRICING TABLES
************************************************************************************** */

$swm_shortcodes['tables'] = array(
	'params' => array(
		'table_column' => array(
			'type' => 'select',
			'label' => __('Table Column', 'swmtranslate'),
			'desc' => '',
			'options' => array(
				'2' => __('Two Column Table', 'swmtranslate'),
				'3' => __('Three Column Table', 'swmtranslate'),	
				'4' => __('Four Column Table', 'swmtranslate')				
			)
		),
		'title' => array(
			'type' => 'text',
			'label' => __('Table Title', 'swmtranslate'),
			'desc' => '',
			'std' => __('Title Here', 'swmtranslate')
		),		
		'price' => array(
			'type' => 'text',
			'label' => __('Price', 'swmtranslate'),
			'desc' => '',
			'std' => '$19'
		),
		'price_sub_text' => array(
			'type' => 'text',
			'label' => __('Price Sub Text', 'swmtranslate'),
			'desc' => '',
			'std' => 'per month'
		),	
		'button_background' => array(
			'type' => 'color',
			'label' => __('Button Background Color', 'swmtranslate'),
			'desc' => '',
			'std' => '#575757'
		),
		'button_text_color' => array(
			'type' => 'color',
			'label' => __('Button Text Color', 'swmtranslate'),
			'desc' => '',
			'std' => '#FFFFFF'
		),
		'button_text' => array(
			'type' => 'text',
			'label' => __('Button Text', 'swmtranslate'),
			'desc' => '',
			'std' => __('Buy Now!', 'swmtranslate')
		),
		'button_link' => array(
			'type' => 'text',
			'label' => __('Button Link', 'swmtranslate'),
			'desc' => '',
			'std' => '#'
		),	
		'table_position' => array(
			'type' => 'select',
			'label' => __('Table Position', 'swmtranslate'),
			'desc' => __('Select Table position. First,middle or last position.', 'swmtranslate'),
			'options' => array(
				'other' => __('Middle', 'swmtranslate'),		
				'first' => __('First Position', 'swmtranslate'),
				'last' => __('Last Position', 'swmtranslate')
			)
		),		
		'popular_plan' => array(
			'type' => 'select',
			'label' => __('Popular Plan', 'swmtranslate'),
			'desc' => __('Select "Yes" if this table has most popular plan. It will display large than other tables.', 'swmtranslate'),
			'options' => array(
				'false' => __('No', 'swmtranslate'),
				'true' => __('Yes', 'swmtranslate')				
			)
		),	
		
		'content' => array(
			'std' => '
<ul>
<li> Table Item One </li>
<li> Table Item Two </li>
<li> Table Item Three </li>
</ul>',
			'type' => 'textarea',
			'label' => __('Table Content', 'swmtranslate'),
			'desc' => __('Add the table content in list format.', 'swmtranslate'),
		)
		
	),
	'shortcode' => '[pricing_table column="{{table_column}}" title="{{title}}" price="{{price}}" price_sub_text="{{price_sub_text}}" button_background="{{button_background}}" button_text_color="{{button_text_color}}"  button_text="{{button_text}}" button_link="{{button_link}}" table_position="{{table_position}}" popular_plan="{{popular_plan}}"] {{content}} [/pricing_table]',
	'no_preview' => true,
	'popup_title' => __('Pricing Table', 'swmtranslate')
);

/* ************************************************************************************** 
   BUTTONS
************************************************************************************** */

$swm_shortcodes['button'] = array(
	'params' => array(
		'button_color' => array(
			'type' => 'color',
			'label' => __('Button Color', 'swmtranslate'),
			'desc' => '',
			'std' => '#575757'
		),
		'font_color' => array(
			'type' => 'color',
			'label' => __('Font Color', 'swmtranslate'),
			'desc' => '',
			'std' => '#FFFFFF'
		),
		'size' => array(
			'type' => 'select',
			'label' => __('Button Size', 'swmtranslate'),			
			'options' => array(				
				'tiny' => __('Tiny', 'swmtranslate'),
				'small' => __('Small', 'swmtranslate'),
				'medium' => __('Medium', 'swmtranslate'),
				'large' => __('Large', 'swmtranslate'),
				'xlarge' => __('X Large', 'swmtranslate')																	
			)
		),
		'shape' => array(
			'type' => 'select',
			'label' => __('Button Shape', 'swmtranslate'),
			'desc' => '',
			'options' => array(
				'square' => __('Square', 'swmtranslate'),	
				'round' => __('Round', 'swmtranslate'),
				'capsule' => __('Capsule', 'swmtranslate')
			)
		),
		'button_style' => array(
			'type' => 'select',
			'label' => __('Button Style', 'swmtranslate'),
			'desc' => '',
			'options' => array(
				'button_standard' => __('Standard', 'swmtranslate'),	
				'button_outline' => __('Outline - Transparent Background', 'swmtranslate')				
			)
		),	
		'button_3d' => array(
			'type' => 'select',
			'label' => __('3D Effect', 'swmtranslate'),			
			'options' => array(				
				'false' => __('No', 'swmtranslate'),
				'true' => __('Yes', 'swmtranslate')																										
			)
		),	
		'content' => array(
			'std' => __('Read more', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Button Text', 'swmtranslate'),
			'desc' => __('Add the button text. If you want to add icon before button text then use simple shortcode <br/>[fa_icon icon="fa-star"]<br />Icon Referce Website : <a href="http://fortawesome.github.io/Font-Awesome/icons/" target="_blank">Font Awesome</a>', 'swmtranslate')
		),
		'link' => array(
			'type' => 'text',
			'label' => __('Button Link', 'swmtranslate'),
			'desc' => '',
			'std' => '#'
		),
		'target' => array(
			'type' => 'select',
			'label' => __('Link Target', 'swmtranslate'),
			'desc' => __('Select display size of button', 'swmtranslate'),
			'options' => array(				
				'_self' => __('Open page in same window', 'swmtranslate'),
				'_blank' => __('Open page in new window', 'swmtranslate')																						
			)
		),
		'text_shadow' => array(
			'type' => 'select',
			'label' => __('Text Shadow Color', 'swmtranslate'),			
			'options' => array(				
				'dark' => __('Dark', 'swmtranslate'),
				'light' => __('Light', 'swmtranslate'),
				'none' => __('No Shadow', 'swmtranslate')																				
			)
		),
		
	),
	'shortcode' => '[swm_button button_color="{{button_color}}" font_color="{{font_color}}" size="{{size}}" shape="{{shape}}"  button_style="{{button_style}}" button_3d="{{button_3d}}" link="{{link}}" target="{{target}}" text_shadow="{{text_shadow}}" ] {{content}} [/swm_button]',
	'no_preview' => true, 
	'popup_title' => __('Button', 'swmtranslate')
);

/* ************************************************************************************** 
    TABS
************************************************************************************** */

$swm_shortcodes['tabs'] = array(         
        'params' => array(
            'style' => array(
				'type' => 'select',
				'label' => __('Tabs Style', 'swmtranslate'),
				'desc' => '',
				'options' => array(
					'tabs_horizontal' => __('Horizontal Tabs', 'swmtranslate'),
					'tabs_vertical' => __('Vertical Tabs', 'swmtranslate')							
					)
			),
            'title1' => array(
                'std' => __('Tab 1', 'swmtranslate'),
                'type' => 'text',
                'label' => __('Tab 1 Title', 'swmtranslate'),
                'desc' => '',
            ),
            'content1' => array(
			'std' => __('tab description here', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Tab 1 Description', 'swmtranslate'),
			'desc' => '',
			),
			'title2' => array(
                'std' => __('Tab 2', 'swmtranslate'),
                'type' => 'text',
                'label' => __('Tab 2 Title', 'swmtranslate'),
                'desc' => '',
            ),
            'content2' => array(
			'std' => __('tab description here', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Tab 2 Description', 'swmtranslate'),
			'desc' => '',
			),
			'title3' => array(
                'std' => __('Tab 3', 'swmtranslate'),
                'type' => 'text',
                'label' => __('Tab 3 Title', 'swmtranslate'),
                'desc' => '',
            ),
            'content3' => array(
			'std' => __('tab description here', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Tab 3 Description', 'swmtranslate'),
			'desc' => '',
			),
			'title4' => array(
                'std' => __('Tab 4', 'swmtranslate'),
                'type' => 'text',
                'label' => __('Tab 4 Title', 'swmtranslate'),
                'desc' => '',
            ),
            'content4' => array(
			'std' => __('tab description here', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Tab 4 Description', 'swmtranslate'),
			'desc' => '',
			)
        ),
        'shortcode' => '[swm_tabs style="{{style}}" title="{{title1}},{{title2}},{{title3}},{{title4}}"] 
[tab_container] 
[tab tabno="1"] {{content1}} [/tab] 
[tab tabno="2"] {{content2}} [/tab] 
[tab tabno="3"] {{content3}} [/tab] 
[tab tabno="4"] {{content4}} [/tab] 
[/tab_container] 
[/swm_tabs]',        
		'no_preview' => true, 
		'popup_title' => __('Tabs', 'swmtranslate')   
);

/* ************************************************************************************** 
    TOOGLE CONTENT
************************************************************************************** */

$swm_shortcodes['toggle'] = array(
	'params' => array(			
		'status' => array(
			'type' => 'select',
			'label' => __('Toogle Status', 'swmtranslate'),
			'desc' => '',
			'options' => array(
				'closed' => __('Close', 'swmtranslate'),
				'open' => __('Open', 'swmtranslate')							
			)
		),
		'icon' => array(
				'type' => 'fonticon',
				'label' => __('Icon', 'swmtranslate'),
				'desc' => __('Select and Deselect icon by click on icon', 'swmtranslate'),				
				'options' => $font_icons
		),
		'title' => array(
			'type' => 'text',
			'label' => __('Toggle Content Title', 'swmtranslate'),
			'desc' => __('Add the title that will go above the toggle content', 'swmtranslate'),
			'std' => __('Title', 'swmtranslate')
		),
		'content' => array(
			'std' => __(' [p] Insert toggle content here [/p]  ', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Toggle Content', 'swmtranslate'),
			'desc' => __('Add the toggle content. If you are adding more than one line then you can remove [p]...[/p] shortcode because wordpress will automatically add paragraph tag for all next lines.', 'swmtranslate'),
		)
		
	),
	'shortcode' => '[swm_toggle status="{{status}}" title="{{title}}" icon="{{icon}}"] {{content}} [/swm_toggle]',
	'no_preview' => true, 
	'popup_title' => __('Toggle Simple', 'swmtranslate')
);

$swm_shortcodes['toggleaccordion'] = array(
	'params' => array(),
    'no_preview' => true,
    'shortcode' => '[swm_toggle_accordion_container] {{child_shortcode}} [/swm_toggle_accordion_container]',
    'popup_title' => __('Toggle Accordion', 'swmtranslate'),
    
    'child_shortcode' => array(
        'params' => array(
		'icon' => array(
				'type' => 'fonticon',
				'label' => __('Icon', 'swmtranslate'),
				'desc' => __('Select and Deselect icon by click on icon', 'swmtranslate'),				
				'options' => $font_icons
		),
		'title' => array(
			'type' => 'text',
			'label' => __('Toggle Content Title', 'swmtranslate'),
			'desc' => __('Add the title that will go above the toggle content', 'swmtranslate'),
			'std' => __('Title', 'swmtranslate')
		),
		'content' => array(
			'std' => __(' [p] Insert toggle content here [/p]  ', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Toggle Content', 'swmtranslate'),
			'desc' => __('Add the toggle content. If you are adding more than one line then you can remove [p]...[/p] shortcode because wordpress will automatically add paragraph tag for all next lines.', 'swmtranslate'),
		)
		
	),
    'shortcode' => '[swm_toggle_accordion title="{{title}}" icon="{{icon}}"] {{content}} [/swm_toggle_accordion]',
	'no_preview' => true, 
    'clone_button' => __('Add Another Item', 'swmtranslate')
    )
);


/* ************************************************************************************** 
    BLOCK QUOTE
************************************************************************************** */

$swm_shortcodes['blockquote'] = array(
	'params' => array(		
		'content' => array(
			'std' => __('This is sample text for blockquote', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Quote Text', 'swmtranslate'),
			'desc' => __('Add the quote text', 'swmtranslate'),
		)		
	),
	'shortcode' => '[blockquote] {{content}} [/blockquote]',
	'no_preview' => true, 
	'popup_title' => __('Quote', 'swmtranslate')
);


/* ************************************************************************************** 
    PULL QUOTES
************************************************************************************** */

$swm_shortcodes['pullquote'] = array(
	'params' => array(
		'style' => array(
			'type' => 'select',
			'label' => __('Quote Style', 'swmtranslate'),
			'desc' => __('Select quote style', 'swmtranslate'),
			'options' => array(
				'pullquote_left' => __('Pull Quote Left', 'swmtranslate'),
				'pullquote_right' => __('Pull Quote Right', 'swmtranslate')										
			)
		),
		'content' => array(
			'std' => __('This is sample text', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Quote Text', 'swmtranslate'),
			'desc' => __('Add the quote text', 'swmtranslate'),
		)				
	),
	'shortcode' => '[{{style}} ] {{content}} [/{{style}}]',
	'no_preview' => true, 
	'popup_title' => __('Quote', 'swmtranslate')
);

/* ************************************************************************************** 
    LIST STYLES
************************************************************************************** */

$swm_shortcodes['textlist'] = array(
	'params' => array(
		'style' => array(
			'type' => 'select',
			'label' => __('Ordered List Style', 'swmtranslate'),
			'desc' => __('Select list style', 'swmtranslate'),
			'options' => array(					
				'steps_with_circle' => __('Steps with circle icons style', 'swmtranslate'),
				'steps_with_box' => __('Steps with Box style', 'swmtranslate'),
				'list_lower_roman' => __('Lower Roman', 'swmtranslate'),
				'list_upper_roman' => __('Upper Roman', 'swmtranslate'),
				'list_lower_alpha' => __('Lower Alpha', 'swmtranslate'),
				'list_upper_alpha' => __('Upper Alpha', 'swmtranslate')											
			)
		),
		'content' => array(
			'std' => '
<ol>
<li> Item One </li>
<li> Item Two </li>
<li> Item Three </li>
</ol>',
			'type' => 'textarea',
			'label' => __('List Content', 'swmtranslate'),
			'desc' => '',
		)		
	),
	'shortcode' => '[{{style}}] {{content}} [/{{style}}]',
	'no_preview' => true,
	'popup_title' => __('List', 'swmtranslate')
);


/* ************************************************************************************** 
    INFO BOXES
************************************************************************************** */

$swm_shortcodes['infoboxes'] = array(
	'params' => array(
		'style' => array(
			'type' => 'select',
			'label' => __('Info Box Style', 'swmtranslate'),
			'desc' => __('Select info box style', 'swmtranslate'),
			'options' => array(
				'info' => __('Info', 'swmtranslate'),
				'success' => __('Success', 'swmtranslate'),
				'error' => __('Error', 'swmtranslate'),
				'warning' => __('Warning', 'swmtranslate'),
				'download' => __('Download', 'swmtranslate'),
				'note' => __('Note', 'swmtranslate')				
			)
		),
		'content' => array(
			'std' => __('Sample text', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Info Box Text', 'swmtranslate'),
			'desc' => __('Add the info box text', 'swmtranslate'),
		)
		
	),
	'shortcode' => '[{{style}}] {{content}} [/{{style}}]',
	'no_preview' => true, 
	'popup_title' => __('Info Box', 'swmtranslate')
);

/* **************************************************************************************
   LIST ICONS
************************************************************************************** */

$swm_shortcodes['iconlist'] = array(
	'params' => array(),
    'no_preview' => true,
    'shortcode' => '[icon_list] {{child_shortcode}} [/icon_list]',
    'popup_title' => __('List Icons', 'swmtranslate'),
    
    'child_shortcode' => array(
        'params' => array(
            'icon_name' => array(
				'type' => 'fonticon',
				'label' => __('Icon', 'swmtranslate'),
				'desc' => __('Select and Deselect icon by click on icon', 'swmtranslate'),				
				'options' => $font_icons
			),
			'content' => array(
                'std' => 'list item details here',
                'type' => 'textarea',
                'label' => __('List Content', 'swmtranslate'),
                'desc' => '',
            ), 
        ),
        'shortcode' => '[swm_list_icon icon_name="{{icon_name}}"]{{content}}[/swm_list_icon]',
		'no_preview' => true, 
        'clone_button' => __('Add Another Item', 'swmtranslate')
    )
);

/* **************************************************************************************
   ICON
************************************************************************************** */

$swm_shortcodes['icon'] = array(
	'params' => array(
		'infotext' => array(
			'type' => 'infotext',
			'label' => __('Note', 'swmtranslate'),
			'desc' => '',
			'std' => __('If you want to display icon without any format then you can use simple shortcode <br /> [fa_icon icon="fa-star"] ', 'swmtranslate')
		),
		'icon_name' => array(
			'type' => 'fonticon',
			'label' => __('Icon', 'swmtranslate'),
			'desc' => __('Select and Deselect icon by click on icon', 'swmtranslate'),
			'options' => $font_icons
		),
		'icon_color' => array(
			'type' => 'color',
			'label' => __('Icon Color', 'swmtranslate'),
			'desc' => '',
			'std' => '#606060'
		),		
		'icon_size' => array(
			'type' => 'select',
			'label' => __('Icon Size', 'swmtranslate'),
			'desc' => '',
			'options' => array(
				'tiny' => __('Tiny', 'swmtranslate'),
				'small' => __('Small', 'swmtranslate'),
				'medium' => __('Medium', 'swmtranslate'),
				'large' => __('Large', 'swmtranslate'),
				'xlarge' => __('xlarge', 'swmtranslate')							
			)
		),
		'icon_style' => array(
			'type' => 'select',
			'label' => __('Icon Style', 'swmtranslate'),
			'desc' => '',
			'options' => array(
				'default' => __('Default', 'swmtranslate'),
				'square' => __('Icon with Square Shape', 'swmtranslate'),
				'circle' => __('Icon with Circle Shape', 'swmtranslate')						
			)
		),
		'icon_bg_color' => array(
			'type' => 'color',
			'label' => __('Icon Background', 'swmtranslate'),
			'desc' => __('If "Icon Style" drodown is selected "Icon with Square or Circle Shape" then enter icon background color', 'swmtranslate'),
			'std' => '#FFFFFF'
		),
		'icon_border' => array(
			'type' => 'select',
			'label' => __('Display Icon Border', 'swmtranslate'),
			'desc' => __('If "Icon Style" drodown is selected "Icon with Square or Circle Shape" then you can add border on square or circle shape', 'swmtranslate'),
			'options' => array(
				'false' => __('No', 'swmtranslate'),
				'true' => __('Yes', 'swmtranslate')				
			)
		),
		'border_color' => array(
			'type' => 'color',
			'label' => __('Border Color', 'swmtranslate'),
			'desc' => __('If "Display Icon Border" drodown is selected "Yes" then enter icon border color', 'swmtranslate'),
			'std' => '#FFFFFF'
		),
		'link' => array(
			'type' => 'text',
			'label' => __('Link', 'swmtranslate'),
			'desc' => __('Enter full url to create clickable icon', 'swmtranslate'),
			'std' => ''
		),	
		'margin' => array(
			'type' => 'select',
			'label' => __('Margin', 'swmtranslate'),
			'desc' => __('Set margin around icon.', 'swmtranslate'),
			'std' => '0',
			'options' => swm_one_to_final_number( 50, false, false, 0 )
		),
		'rotate' => array(
			'type' => 'select',
			'label' => __('Rotate Icon', 'swmtranslate'),			
			'options' => array(
				'false' => __('No', 'swmtranslate'),
				'true' => __('Yes', 'swmtranslate')				
			)
		),	
		'animation_style' => array(
			'type' => 'select',
			'label' => __('Animation Style', 'swmtranslate'),
			'desc' => __('Select icon animation style', 'swmtranslate'),
			'options' => array(
				'none' => __('None', 'swmtranslate'),
				'swm_center_expand' => __('Expand from Center', 'swmtranslate'),
				'move_left_to_right' => __('Move Left to Right', 'swmtranslate'),					
				'move_right_to_left' => __('Move Right to Left', 'swmtranslate'),					
				'move_top_to_bottom' => __('Move Top to Bottom', 'swmtranslate'),					
				'move_bottom_to_top' => __('Move Bottom to Top', 'swmtranslate')
			)
		)
	),
	'shortcode' => '[swm_icon icon_name="{{icon_name}}" icon_color="{{icon_color}}" icon_size="{{icon_size}}" icon_style="{{icon_style}}" icon_bg_color="{{icon_bg_color}}" icon_border="{{icon_border}}" border_color="{{border_color}}" link="{{link}}" margin="{{margin}}" rotate="{{rotate}}" animation_style="{{animation_style}}" ]',
	'no_preview' => true, 
	'popup_title' => __('Icon', 'swmtranslate')
);

/* **************************************************************************************
   GAP
************************************************************************************** */

$swm_shortcodes['gap'] = array(
	'params' => array(		
		'size' => array(
			'type' => 'text',
			'label' => __('Size', 'swmtranslate'),
			'desc' => __('Enter gap size in pixels, ems, or percentages ( Example: 30px, 3em or 3% ).', 'swmtranslate'),
			'std' => '30px'
		)			
	),
	'shortcode' => '[gap size="{{size}}"]',
	'no_preview' => true, 
	'popup_title' => __('Gap', 'swmtranslate')
);

/* **************************************************************************************
   COUNTER BOXES
************************************************************************************** */

$swm_shortcodes['counterboxes'] = array(
	'params' => array(),
    'no_preview' => true,
    'shortcode' => '[swm_counter_boxes] {{child_shortcode}} [/swm_counter_boxes]',
    'popup_title' => __('Counter Box', 'swmtranslate'),
    
    'child_shortcode' => array(
        'params' => array(
            'box_bg_color' => array(
				'type' => 'color',
				'label' => __('Box Background Color', 'swmtranslate'),
				'desc' => '',
				'std' => '#FFFFFF'
			),
			'font_color' => array(
				'type' => 'color',
				'label' => __('Font Color', 'swmtranslate'),
				'desc' => '',
				'std' => '#606060'
			),
			'icon' => array(
				'type' => 'fonticon',
				'label' => __('Icon', 'swmtranslate'),
				'desc' => __('Select and Deselect icon by click on icon', 'swmtranslate'),
				'options' => $font_icons
			),
			'icon_bg_color' => array(
				'type' => 'color',
				'label' => __('Icon Background Color', 'swmtranslate'),
				'desc' => '',
				'std' => '#606060'
			),
			'icon_color' => array(
				'type' => 'color',
				'label' => __('Icon Color', 'swmtranslate'),
				'desc' => '',
				'std' => '#FFFFFF'
			),
			'counter_number' => array(
				'type' => 'text',
				'label' => __('Counter Number', 'swmtranslate'),
				'desc' => __('Counter will animated above numter', 'swmtranslate'),
				'std' => '1000'
			),
			'unit' => array(
				'type' => 'text',
				'label' => __('Unit', 'swmtranslate'),
				'desc' => __('Enter the unit for the counter number ( Example %, $, + ).', 'swmtranslate'),
				'std' => ''
			),
			'unit_position' => array(
				'type' => 'select',
				'label' => __('Unit Position', 'swmtranslate'),
				'desc' => '',
				'options' => array(
					'before_number' => __('Before Number', 'swmtranslate'),
					'after_number' => __('After Number', 'swmtranslate')					
				)
			),
			'speed' => array(
				'type' => 'text',
				'label' => __('Animation Speed', 'swmtranslate'),
				'desc' => __('Add animation speed in miliseconds ( Example 1000 = 1 second, 5000 = 5 second. )', 'swmtranslate'),
				'std' => '2000'
			),
			'column' => array(
				'type' => 'select',
				'label' => __('Columln', 'swmtranslate'),
				'desc' => __('Select counter box display column', 'swmtranslate'),
				'options' => array(
					'2' => __('2', 'swmtranslate'),
					'3' => __('3', 'swmtranslate'),
					'4' => __('4', 'swmtranslate'),
					'5' => __('5', 'swmtranslate')					
				)
			),
			'content' => array(
			'std' => __('description text', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Small Description text', 'swmtranslate'),
			'desc' => '',
		)	            
        ),
        'shortcode' => '[swm_counter_box box_bg_color="{{box_bg_color}}" font_color="{{font_color}}" icon="{{icon}}" icon_bg_color="{{icon_bg_color}}" icon_color="{{icon_color}}" counter_number="{{counter_number}}" unit="{{unit}}" unit_position="{{unit_position}}" speed="{{speed}}" column="{{column}}"]{{content}}[/swm_counter_box]',
		'no_preview' => true, 
        'clone_button' => __('Add Another Item', 'swmtranslate')
    )
);

/* **************************************************************************************
   PROGRESS BAR
************************************************************************************** */

$swm_shortcodes['progressbars'] = array(
	'params' => array(),
    'no_preview' => true,
    'shortcode' => '{{child_shortcode}}',
    'popup_title' => __('Progress Bar', 'swmtranslate'),
    
    'child_shortcode' => array(
        'params' => array(
            'percentage' => array(
				'type' => 'select',
				'label' => __('Percentage', 'swmtranslate'),
				'desc' => '',
				'std' => '80',
				'options' => swm_one_to_final_number( 100, false, false )
			),
			'title_text' => array(
				'type' => 'text',
				'label' => __('Title Text', 'swmtranslate'),
				'desc' => '',
				'std' => 'Skill Name'
			),
			'background' => array(
				'type' => 'color',
				'label' => __('Background Color', 'swmtranslate'),
				'desc' => '',
				'std' => '#606060'
			)			            
        ),
        'shortcode' => '[progress_bar percentage="{{percentage}}" title_text="{{title_text}}" background="{{background}}"]',
		'no_preview' => true, 
        'clone_button' => __('Add Another Item', 'swmtranslate')
    )
);

/* **************************************************************************************
   COUNTER CIRCLES
************************************************************************************** */

$swm_shortcodes['countercircles'] = array(
	'params' => array(),
    'no_preview' => true,
    'shortcode' => '[counter_circles] {{child_shortcode}} [/counter_circles]',
    'popup_title' => __('Counter Circles', 'swmtranslate'),
    
    'child_shortcode' => array(
        'params' => array(
            'percentage' => array(
				'type' => 'select',
				'label' => __('Percentage', 'swmtranslate'),
				'desc' => '',
				'std' => '80',
				'options' => swm_one_to_final_number( 100, false, false )
			),
            'bar_color' => array(
				'type' => 'color',
				'label' => __('Bar Color', 'swmtranslate'),
				'desc' => '',
				'std' => '#CCCCCC'
			),
			'track_color' => array(
				'type' => 'color',
				'label' => __('Track Color', 'swmtranslate'),
				'desc' => '',
				'std' => '#606060'
			),
			'track_line_width' => array(
				'type' => 'text',
				'label' => __('Track Line Width', 'swmtranslate'),
				'desc' => __('Enter circle line width in number', 'swmtranslate'),
				'std' => '10'
			),
			'size' => array(
				'type' => 'text',
				'label' => __('Circle Size', 'swmtranslate'),
				'desc' => __('Enter circle size in number', 'swmtranslate'),
				'std' => '220',				
			),
			'speed' => array(
				'type' => 'text',
				'label' => __('Animation Speed', 'swmtranslate'),
				'desc' => __('Add animation speed in miliseconds ( Example 1000 = 1 second, 5000 = 5 second. )', 'swmtranslate'),
				'std' => '2000'
			),
			'content' => array(
			'std' => __('Mytext', 'swmtranslate'),
			'type' => 'text',
			'label' => __('Circle Text', 'swmtranslate'),
			'desc' => __('This text will display inside animated circle', 'swmtranslate'),
			),  
			'circle_text_size' => array(
				'type' => 'select',
				'label' => __('Circle Text Size', 'swmtranslate'),
				'desc' => '',
				'std' => '30',
				'options' => swm_one_to_final_number( 100, false, false )
			),
			'desc_text' => array(
				'type' => 'text',
				'label' => __('Description Text', 'swmtranslate'),
				'desc' => __('This text will display below circle', 'swmtranslate'),
				'std' => __('Description here', 'swmtranslate'),
			),
			'desc_text_size' => array(
				'type' => 'select',
				'label' => __('Description Text Size', 'swmtranslate'),
				'desc' => '',
				'std' => '30',
				'options' => swm_one_to_final_number( 100, false, false )
			)			         
        ),
        'shortcode' => '[counter_circle percentage="{{percentage}}" bar_color="{{bar_color}}" track_color="{{track_color}}" track_line_width="{{track_line_width}}" size="{{size}}" speed="{{speed}}" circle_text_size="{{circle_text_size}}" desc_text="{{desc_text}}" desc_text_size="{{desc_text_size}}"]{{content}}[/counter_circle]',
		'no_preview' => true, 
        'clone_button' => __('Add Another Item', 'swmtranslate')
    )
);

/* **************************************************************************************
   FULL WIDTH SECTION
************************************************************************************** */

$swm_shortcodes['fullwidthsection'] = array(
	'params' => array(		
		'background_color' => array(
			'type' => 'color',
			'label' => __('Background Color', 'swmtranslate'),
			'desc' => __('Set section backgorund color', 'swmtranslate'),
			'std' => '#ffffff'
		),	
		'background_image' => array(
			'type' => 'upload',
			'label' => __('Background Image', 'swmtranslate'),
			'desc' => __('Upload background image', 'swmtranslate')			
		),
		'background_repeat' => array(
			'type' => 'select',
			'label' => __('Background Repeat', 'swmtranslate'),
			'desc' => '',
			'std' => 'repeat',
			'options' => array(
				'repeat'    => __( 'Repeat', 'swmtranslate' ),
		        'no-repeat' => __( 'No Repeat', 'swmtranslate' ),
		        'repeat-x'  => __( 'Repeat X', 'swmtranslate' ),
		        'repeat-y'  => __( 'Repeat Y', 'swmtranslate' )  										
			)
		),	
		'background_position' => array(
			'type' => 'select',
			'label' => __('Background Position', 'swmtranslate'),
			'desc' => '',
			'std' => 'center-top',
			'options' => array(
				"left-top"      => __( 'Left Top', 'swmtranslate' ),
		        "left-center"   => __( 'Left Center', 'swmtranslate' ),
		        "left-bottom"   => __( 'Left Bottom', 'swmtranslate' ),
		        "right-top"     => __( 'Right Top', 'swmtranslate' ),
		        "right-center"  => __( 'Right Center', 'swmtranslate' ),
		        "right-bottom"  => __( 'Right Bottom', 'swmtranslate' ),
		        "center-top"    => __( 'Center Top', 'swmtranslate' ),
		        "center-center" => __( 'Center Center', 'swmtranslate' ),
		        "center-bottom" => __( 'Center Bottom', 'swmtranslate' ) 										
			)
		),	
		'background_attachment' => array(
			'type' => 'select',
			'label' => __('Background Attachment', 'swmtranslate'),
			'desc' => '',
			'std' => 'fixed',
			'options' => array(
				'scroll'    => __( 'Scroll', 'swmtranslate' ),
       			'fixed' => __( 'Fixed', 'swmtranslate' )  									
			)
		),	
		'background_stretch' => array(
			'type' => 'select',
			'label' => __('100% Background Image Width', 'swmtranslate'),
			'desc' => '',
			'std' => 'false',
			'options' => array(
				'false'    => __( 'No', 'swmtranslate' ),
       			'true' => __( 'Yes', 'swmtranslate' )  									
			)
		),	
		'parallax_effect' => array(
			'type' => 'select',
			'label' => __('Enable Parallax Scrolling', 'swmtranslate'),
			'desc' => __('<a href="http://www.ianlunn.co.uk/plugins/jquery-parallax/" target="_blank">Click here</a> to know more about Parallax Scrolling', 'swmtranslate'),
			'std' => 'false',
			'options' => array(
				'true' => __( 'Yes', 'swmtranslate' ),
				'false'    => __( 'No', 'swmtranslate' )       			  									
			)
		),
		'parallax_speed' => array(
			'type' => 'text',
			'label' => __('Parallax Scrolling Speed', 'swmtranslate'),
			'desc' => __('Enter background image scrolling speed value in number between -10.0 to 10.0. <br />Minus value will scroll background image down. <br /> ( Example 1.5, 2.0, -4.5, 2.5 )  ', 'swmtranslate'),
			'std' => '2.5'
		),
		'border_width' => array(
			'type' => 'select',
			'label' => __('Border Width', 'swmtranslate'),	
			'desc' => __('If you want to make section with border then set border width and then set top and/or bottom border colors', 'swmtranslate'),		
			'std' => '0',
			'options' => swm_one_to_final_number( 10, false, false, 0 )
		),	
		'border_top_color' => array(
			'type' => 'color',
			'label' => __('Top Border Color', 'swmtranslate'),
			'std' => ''
		),
		'border_bottom_color' => array(
			'type' => 'color',
			'label' => __('Bottom Border Color', 'swmtranslate'),			
			'std' => ''
		),
		'arrow_direction' => array(
			'type' => 'select',
			'label' => __('Arrow Direction', 'swmtranslate'),
			'desc' => __('If you want to make section with top or bottom direction arrow then select from above drop down.', 'swmtranslate'),
			'std' => 'fixed',
			'options' => array(
				'none'    => __( 'Hide Arrow', 'swmtranslate' ),
				'top'    => __( 'Display Arrow Top', 'swmtranslate' ),
       			'bottom' => __( 'Display Arrow Bottom', 'swmtranslate' )								
			)
		),
		'arrow_color' => array(
			'type' => 'color',
			'label' => __('Arrow Color', 'swmtranslate'),			
			'std' => ''
		),
		'padding_top' => array(
			'type' => 'text',
			'label' => __('Padding Top', 'swmtranslate'),
			'desc' => __('Enter section padding top value in pixels or em. ( Example 20px, 2em )', 'swmtranslate'),
			'std' => '40px'
		),
		'padding_bottom' => array(
			'type' => 'text',
			'label' => __('Padding Bottom', 'swmtranslate'),
			'desc' => __('Enter section padding bottom value in pixels or em. ( Example 20px, 2em )', 'swmtranslate'),
			'std' => '40px'
		),		
		'font_color' => array(
			'type' => 'color',
			'label' => __('Section Font Color', 'swmtranslate'),			
			'std' => '#606060'
		),
		'section_id' => array(
			'type' => 'text',
			'label' => __('Section ID (optional)', 'swmtranslate'),
			'desc' => __('Enter unique ID to style this section with custom CSS style.', 'swmtranslate'),
			'std' => ''
		),
		'content' => array(
			'std' => __('Add section content here', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Section Content', 'swmtranslate'),
			'desc' => ''
		)			
	),
	'shortcode' => '[swm_section background_color="{{background_color}}" background_image="{{background_image}}" background_repeat="{{background_repeat}}" background_position="{{background_position}}" background_attachment="{{background_attachment}}" background_stretch="{{background_stretch}}" parallax_effect="{{parallax_effect}}" parallax_speed="{{parallax_speed}}" padding_top="{{padding_top}}" padding_bottom="{{padding_bottom}}" font_color="{{font_color}}" border_top_color="{{border_top_color}}" border_bottom_color="{{border_bottom_color}}" border_width="{{border_width}}" arrow_direction="{{arrow_direction}}" arrow_color="{{arrow_color}}" section_id="{{section_id}}" ]{{content}}[/swm_section]',
	'no_preview' => true, 
	'popup_title' => __('Full Width Section for "Page"', 'swmtranslate')
);

/* **************************************************************************************
   SECTION TITLE
************************************************************************************** */

$swm_shortcodes['sectiontitle'] = array(
	'params' => array(		
		'section_background' => array(
			'type' => 'color',
			'label' => __('Section Background Color', 'swmtranslate'),
			'desc' => __('Set section backgorund color', 'swmtranslate'),
			'std' => '#dddddd'
		),
		'title_background' => array(
			'type' => 'color',
			'label' => __('Title Background Color', 'swmtranslate'),
			'desc' => __('Set title backgorund color', 'swmtranslate'),
			'std' => '#444444'
		),	
		'font_color' => array(
			'type' => 'color',
			'label' => __('Font Color', 'swmtranslate'),
			'desc' => __('Set title text color', 'swmtranslate'),
			'std' => '#ffffff'
		),	
		'font_weight' => array(
			'type' => 'select',
			'label' => __('Font Weight', 'swmtranslate'),
			'desc' => '',
			'std' => 'repeat',
			'options' => array(
				'normal'    => __( 'Normal', 'swmtranslate' ),
		        'bold' => __( 'Bold', 'swmtranslate' ) 										
			)
		),	
		'content' => array(
			'std' => __('Title Text Here', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Section Title', 'swmtranslate'),
			'desc' => ''
		),
		'section_id' => array(
			'type' => 'text',
			'label' => __('Section ID (optional)', 'swmtranslate'),
			'desc' => __('Enter unique ID to style this section with custom CSS style.', 'swmtranslate'),
			'std' => ''
		)	
	),
	'shortcode' => '[swm_section_title section_background="{{section_background}}" title_background="{{title_background}}" font_color="{{font_color}}" font_weight="{{font_weight}}" section_id="{{section_id}}" ]{{content}}[/swm_section_title]',
	'no_preview' => true, 
	'popup_title' => __('Full Width Section for "Page"', 'swmtranslate')
);

/* **************************************************************************************
   FANCY HEADING
************************************************************************************** */

$swm_shortcodes['fancyheading'] = array(
	'params' => array(		
		'background' => array(
			'type' => 'color',
			'label' => __('Background Color', 'swmtranslate'),
			'desc' => __('Set title section background color', 'swmtranslate'),
			'std' => '#ffffff'
		),
		'border_color' => array(
			'type' => 'color',
			'label' => __('Border Color', 'swmtranslate'),
			'desc' => __('Set title top and bottom border color', 'swmtranslate'),
			'std' => '#dddddd'
		),
		'border_width' => array(
				'type' => 'select',
				'label' => __('Border Width', 'swmtranslate'),
				'desc' => __('Set title top and bottom border width', 'swmtranslate'),
				'desc' => '',
				'std' => '1',
				'options' => swm_one_to_final_number( 10, false, false )
		),	
		'font_size' => array(
				'type' => 'select',
				'label' => __('Font Size', 'swmtranslate'),
				'desc' => '',
				'std' => '20',
				'options' => swm_one_to_final_number( 100, false, false )
		),	
		'font_weight' => array(
			'type' => 'select',
			'label' => __('Font Weight', 'swmtranslate'),
			'desc' => '',
			'std' => 'repeat',
			'options' => array(
				'normal'    => __( 'Normal', 'swmtranslate' ),
		        'bold' => __( 'Bold', 'swmtranslate' ) 										
			)
		),
		'text_align' => array(
			'type' => 'select',
			'label' => __('Text Align', 'swmtranslate'),
			'desc' => '',
			'std' => 'repeat',
			'options' => array(
				'center'    => __( 'Center', 'swmtranslate' ),
		        'left' => __( 'Left', 'swmtranslate' ),
		        'right' => __( 'Right', 'swmtranslate' ) 										
			)
		),	
		'content' => array(
			'std' => __('Title Text Here', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Section Title', 'swmtranslate'),
			'desc' => ''
		),
		'section_id' => array(
			'type' => 'text',
			'label' => __('Section ID (optional)', 'swmtranslate'),
			'desc' => __('Enter unique ID to style heading section with custom CSS style.', 'swmtranslate'),
			'std' => ''
		)	
	),
	'shortcode' => '[swm_fancy_heading border_color="{{border_color}}" background="{{background}}" border_width="{{border_width}}" font_size="{{font_size}}" font_weight="{{font_weight}}" text_align="{{text_align}}" section_id="{{section_id}}" ]{{content}}[/swm_fancy_heading]',
	'no_preview' => true, 
	'popup_title' => __('FANCY HEADING', 'swmtranslate')
);

/* **************************************************************************************
   DOTTED LINE HEADING
************************************************************************************** */

$swm_shortcodes['dotlineheading'] = array(
	'params' => array(
		'font_size' => array(
				'type' => 'select',
				'label' => __('Font Size', 'swmtranslate'),
				'desc' => '',
				'std' => '20',
				'options' => swm_one_to_final_number( 100, false, false )
		),
		'text_align' => array(
			'type' => 'select',
			'label' => __('Text Align', 'swmtranslate'),
			'desc' => '',
			'std' => 'repeat',
			'options' => array(
				'center'    => __( 'Center', 'swmtranslate' ),
		        'left' => __( 'Left', 'swmtranslate' ),
		        'right' => __( 'Right', 'swmtranslate' ) 										
			)
		),
		'margin_bottom' => array(
				'type' => 'select',
				'label' => __('Margin Bottom', 'swmtranslate'),
				'desc' => __('Space between heading and bottom section content', 'swmtranslate'),
				'desc' => '',
				'std' => '20',
				'options' => swm_one_to_final_number( 100, false, false )
		),	
		'content' => array(
			'std' => __('Title Text Here', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Section Title', 'swmtranslate'),
			'desc' => ''
		),
		'section_id' => array(
			'type' => 'text',
			'label' => __('Section ID (optional)', 'swmtranslate'),
			'desc' => __('Enter unique ID to style heading section with custom CSS style.', 'swmtranslate'),
			'std' => ''
		)	
	),
	'shortcode' => '[swm_dotline_heading font_size="{{font_size}}" text_align="{{text_align}}" margin_bottom="{{margin_bottom}}" section_id="{{section_id}}" ]{{content}}[/swm_dotline_heading]',
	'no_preview' => true, 
	'popup_title' => __('DOT LINE HEADING', 'swmtranslate')
);

/* **************************************************************************************
   The Event Calendar - Upcoming Events
************************************************************************************** */

$swm_shortcodes['upcomingevents'] = array(
	'params' => array(		
		'post_limit' => array(
			'type' => 'text',
			'label' => __('Post Limit', 'swmtranslate'),
			'desc' => __('Number of posts to display', 'swmtranslate'),
			'std' => '4'
		),
		'desc_limit' => $recent_posts_desc_limit,
			
	),
	'shortcode' => '[swm_upcoming_events post_limit="{{post_limit}}" desc_limit="{{desc_limit}}"]',
	'no_preview' => true, 
	'popup_title' => __('Upcoming Events', 'swmtranslate')
);

/* ************************************************************************************** 
    DROPCAPS
************************************************************************************** */

$swm_shortcodes['dropcaps'] = array(
	'params' => array(		
		'style' => array(
			'type' => 'select',
			'label' => __('Dropcap Style', 'swmtranslate'),
			'desc' => __('Select dropcaps style', 'swmtranslate'),
			'options' => array(				
				'light' => __('Light', 'swmtranslate'),
				'dark' => __('Dark', 'swmtranslate')				
			)
		),	
		'content' => array(
			'std' => __('A', 'swmtranslate'),
			'type' => 'text',
			'label' => __('Dropcap Text', 'swmtranslate'),
			'desc' => __('Add the dropcap text', 'swmtranslate'),
		)
		
	),
	'shortcode' => '[swm_dropcap style="{{style}}"] {{content}} [/swm_dropcap]',
	'no_preview' => true, 
	'popup_title' => __('Dropcaps', 'swmtranslate')
);

/* ************************************************************************************** 
    FONT
************************************************************************************** */

$swm_shortcodes['font'] = array(
	'params' => array(		
		'color' => array(
			'type' => 'color',
			'label' => __('Font Color', 'swmtranslate'),			
			'std' => ''
		),
		'size' => array(
			'type' => 'select',
			'label' => __('Font Size', 'swmtranslate'),			
			'std' => '22',
			'options' => swm_one_to_final_number( 200, false, false, 10 )
		),	
		'line_height' => array(
			'type' => 'select',
			'label' => __('Font Line Height', 'swmtranslate'),			
			'std' => '22',
			'options' => swm_one_to_final_number( 200, false, false, 10 )
		),		
		'weight' => array(
			'type' => 'select',
			'label' => __('Font Weight', 'swmtranslate'),			
			'options' => array(				
				'normal' => __('Normal', 'swmtranslate'),
				'bold' => __('Bold', 'swmtranslate')				
			)
		),	
		'content' => array(
			'std' => __('Your Text Here', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Description Text', 'swmtranslate')
		)
		
	),
	'shortcode' => '[swm_font weight="{{weight}}" size="{{size}}" color="{{color}}" line_height="{{line_height}}"] {{content}} [/swm_font]',
	'no_preview' => true, 
	'popup_title' => __('Font', 'swmtranslate')
);

/* ************************************************************************************** 
    TOP DONORS
************************************************************************************** */

$swm_shortcodes['topdonors'] = array(
	'params' => array(),
    'no_preview' => true,
    'shortcode' => '{{child_shortcode}}',
    'popup_title' => __('Top Donors', 'swmtranslate'),
    
    'child_shortcode' => array(
        'params' => array(
            'src' => array(
				'type' => 'upload',
				'label' => __('Donor Image', 'swmtranslate'),
				'desc' => __('Image size : 115 x 115', 'swmtranslate')				
			),
			'name' => array(
				'type' => 'text',
				'label' => __('Donor Name', 'swmtranslate'),
				'std' => 'John Doe'
			),
			'position' => array(
				'type' => 'text',
				'label' => __('Donor Position', 'swmtranslate'),
				'std' => 'Business man'
			),
			'amount' => array(
				'type' => 'text',
				'label' => __('Donated Amount', 'swmtranslate'),
				'std' => '$5000'
			)		         
        ),
        'shortcode' => '[top_donors src="{{src}}" name="{{name}}" position="{{position}}" amount="{{amount}}"]',
		'no_preview' => true, 
        'clone_button' => __('Add Another Donor', 'swmtranslate')
    )
);

/* ************************************************************************************** 
    NEXT EVENT COUNTER
************************************************************************************** */

$swm_shortcodes['eventcounter'] = array(
	'params' => array(		
		'event_name' => array(
				'type' => 'text',
				'label' => __('Event Name', 'swmtranslate'),
				'std' => 'God is Great'
		),
		'event_time' => array(
				'type' => 'text',
				'label' => __('Event Time', 'swmtranslate'),
				'std' => 'Tuesday - 8:00 am',
				'desc' => __('You can enter time or date with any format like Tuesday 8:00 am or 15th January 2015. ', 'swmtranslate')
		),
		'event_venue' => array(
				'type' => 'text',
				'label' => __('Event Venue', 'swmtranslate'),
				'std' => 'Cross Road Park'
		),
		'content' => array(
			'std' => __('Your Text Here', 'swmtranslate'),
			'type' => 'textarea',
			'label' => __('Event Short Details', 'swmtranslate')
		),
		'event_date' => array(
				'type' => 'text',
				'label' => __('Event Date', 'swmtranslate'),
				'std' => '1 january 2016',
				'desc' => __('Enter given date as per this example: <br/><strong>1 january 2016</strong> ( date day in number, month as lowercase text and year as number )<br/> any other format will not work, only enter date as per above format', 'swmtranslate')
		),
		'event_hours' => array(
				'type' => 'text',
				'label' => __('Event Hours', 'swmtranslate'),
				'std' => '10:15:00',
				'desc' => __('Enter hours as hh:mm:ss -> <strong>12:30:00</strong> <br/> any other format will not work, only enter hours as per above format', 'swmtranslate')
		)
		
	),
	'shortcode' => '[event_counter event_name="{{event_name}}" event_time="{{event_time}}" event_venue="{{event_venue}}" event_date="{{event_date}}" event_hours="{{event_hours}}"] {{content}} [/event_counter]',
	'no_preview' => true, 
	'popup_title' => __('Next Event Counter', 'swmtranslate')
);

/* ************************************************************************************** 
   LOGO SLIDER
************************************************************************************** */

$swm_shortcodes['logoslider'] = array(
    'params' => array(
		'auto_slide' => array(
				'type' => 'select',
				'label' => __('Auto Slide', 'swmtranslate'),
				'desc' => __('If you want to rotate slides auto then select yes', 'swmtranslate'),
				'options' => array(
					'true' => __('Yes', 'swmtranslate'),
					'false' => __('No', 'swmtranslate')														
			)		         
		),
		'slider_speed' => array(
                'std' => '7000',
                'type' => 'text',
                'label' => __('Slider Speed', 'swmtranslate'),
                'desc' => __('Intreval between two slides. 1000=1 second, 5000= 5 second', 'swmtranslate'),
        ),
        'display_logos' => array(
                'std' => '20',
                'type' => 'text',
                'label' => __('Number of Logos', 'swmtranslate'),
                'desc' => __('Enter number to display logos in slider ', 'swmtranslate'),
        ),
        'lightbox' => array(
				'type' => 'select',
				'label' => __('Lightbox', 'swmtranslate'),
				'desc' => __('Select event you want after click on thumbnail', 'swmtranslate'),
				'options' => array(
					'true' => __('Display Large Image In Lightbox', 'swmtranslate'),
					'false' => __('Disable Lightbox and Go to link page', 'swmtranslate')														
				)		         
		),
		'infotextdevices' => array(
			'type' => 'infotext',
			'label' => __('Responsive', 'swmtranslate'),
			'desc' => '',
			'std' => __('Display logo as per screen resolution ( Enter only number )', 'swmtranslate')
		),
		'large_screen' => array(
                'std' => '7',
                'type' => 'text',
                'label' => __('Display Logos in Large Screen', 'swmtranslate'),
                'desc' => __('Enter number to display above 1200px resolution', 'swmtranslate'),
        ),
        'laptop' => array(
                'std' => '6',
                'type' => 'text',
                'label' => __('Display Logos in Laptop', 'swmtranslate'),
                'desc' => __('Enter number to display between 980px to 1199px resolution', 'swmtranslate'),
        ),
        'ipad_vertical' => array(
                'std' => '4',
                'type' => 'text',
                'label' => __('Display Logos in iPad Vertical', 'swmtranslate'),
                'desc' => __('Enter number to display between768px to 979px resolution', 'swmtranslate'),
        ),
        'iphone_horizontal' => array(
                'std' => '3',
                'type' => 'text',
                'label' => __('Display Logos in iPhone Horizontal', 'swmtranslate'),
                'desc' => __('Enter number to display between 480px to 767px resolution', 'swmtranslate'),
        ),
        'iphone_vertical' => array(
                'std' => '2',
                'type' => 'text',
                'label' => __('Display Logos in iPhone Vertical', 'swmtranslate'),
                'desc' => __('Enter number to display between 0px to 479px resolution', 'swmtranslate'),
        ),
		'infotext' => array(
			'type' => 'infotext',
			'label' => __('Note', 'swmtranslate'),
			'desc' => '',
			'std' => __('Upload logo images from left sidebar menu Logos > Add New ', 'swmtranslate')
		)
	),
    	
    'no_preview' => true,
    'shortcode' => '[logo_slider auto_slide="{{auto_slide}}" slider_speed="{{slider_speed}}" display_logos="{{display_logos}}" lightbox="{{lightbox}}" large_screen="{{large_screen}}" laptop="{{laptop}}" ipad_vertical="{{ipad_vertical}}" iphone_horizontal="{{iphone_horizontal}}" iphone_vertical="{{iphone_vertical}}"]',
    'popup_title' => __('Insert Logo Slider  Shortcode', 'swmtranslate'),  
   
);


/* ************************************************************************************** 
   RECENT WORKS
************************************************************************************** */

$swm_shortcodes['recentwork'] = array(
    'params' => array(
    	'display_posts' => $recent_posts_post_limit,		
		'column' => array(
			'type' => 'select',
			'label' => __('Display Column', 'swmtranslate'),
			'desc' => __('Select display column for recent work items', 'swmtranslate'),
			'std' => '3',
			'options' => array(
				'2' => __('2 Column', 'swmtranslate'),
				'3' => __('3 Column', 'swmtranslate'),
				'4' => __('4 Column', 'swmtranslate')								
			)
		),
		'lightbox' => array(
				'type' => 'select',
				'label' => __('Lightbox', 'swmtranslate'),
				'desc' => __('Select event you want after click on thumbnail', 'swmtranslate'),
				'options' => array(
					'true' => __('Display Large Image In Lightbox', 'swmtranslate'),
					'false' => __('Disable Lightbox and Go to link page', 'swmtranslate')														
				)		         
		),
		'title_section' => array(
				'type' => 'select',
				'label' => __('Display Portfolio Title/Excerpt Section', 'swmtranslate'),			
				'options' => array(
					'true' => __('Yes', 'swmtranslate'),
					'false' => __('No', 'swmtranslate')														
			)		         
		),
		'title_link' => array(
				'type' => 'select',
				'label' => __('Add link on Portfolio Title Text', 'swmtranslate'),			
				'options' => array(
					'true' => __('Yes', 'swmtranslate'),
					'false' => __('No', 'swmtranslate')														
			)		         
		),
		'title_font_size' => array(
			'type' => 'select',
			'label' => __('Title Font Size', 'swmtranslate'),			
			'std' => '16',
			'options' => swm_one_to_final_number( 50, false, false, 10 )
		),	
		'title_font_weight' => array(
			'type' => 'select',
			'label' => __('Title Font Weight', 'swmtranslate'),			
			'options' => array(				
				'normal' => __('Normal', 'swmtranslate'),
				'bold' => __('Bold', 'swmtranslate')				
			)
		),
		'excerpt_type' => array(
			'type' => 'select',
			'label' => __('Display Excerpt Type', 'swmtranslate'),			
			'options' => array(				
				'text' => __('Display Summery Text', 'swmtranslate'),
				'category' => __('Display Category Names', 'swmtranslate'),
				'false' => __('Hide Excerpt Content', 'swmtranslate'),			
			)
		),
		'excerpt_font_size' => array(
			'type' => 'select',
			'label' => __('Excerpt Font Size', 'swmtranslate'),			
			'std' => '16',
			'options' => swm_one_to_final_number( 30, false, false, 10 )
		), 
		'desc_limit' => $recent_posts_desc_limit,  
		'read_more_text' => $recent_posts_read_more_text,   
		'exclude' => $recent_posts_exclude, 
		'infotext' => array(
			'type' => 'infotext',
			'label' => __('Note:', 'swmtranslate'),
			'desc' => '',
			'std' => __('Upload recent work items from left sidebar menu Portfolio > Add New ', 'swmtranslate')
		)
	),
    	
    'no_preview' => true,
    'shortcode' => '[recent_work display_posts="{{display_posts}}" column="{{column}}" lightbox="{{lightbox}}" title_section="{{title_section}}" title_link="{{title_link}}" title_font_size="{{title_font_size}}" title_font_weight="{{title_font_weight}}" excerpt_type="{{excerpt_type}}" excerpt_font_size="{{excerpt_font_size}}" desc_limit="{{desc_limit}}" read_more_text="{{read_more_text}}" exclude="{{exclude}}" ]',
    'popup_title' => __('Insert Recent Work Shortcode', 'swmtranslate'),    
   
);

?>