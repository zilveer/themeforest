<?php
// Register Custom Post Type
function tb_add_post_type_client() {
    // Register taxonomy
    $labels = array(
            'name'              => _x( 'Client Category', 'taxonomy general name', 'jwsthemes' ),
            'singular_name'     => _x( 'Client Category', 'taxonomy singular name', 'jwsthemes' ),
            'search_items'      => __( 'Search Client Category', 'jwsthemes' ),
            'all_items'         => __( 'All Client Category', 'jwsthemes' ),
            'parent_item'       => __( 'Parent Client Category', 'jwsthemes' ),
            'parent_item_colon' => __( 'Parent Client Category:', 'jwsthemes' ),
            'edit_item'         => __( 'Edit Client Category', 'jwsthemes' ),
            'update_item'       => __( 'Update Client Category', 'jwsthemes' ),
            'add_new_item'      => __( 'Add New Client Category', 'jwsthemes' ),
            'new_item_name'     => __( 'New Client Category Name', 'jwsthemes' ),
            'menu_name'         => __( 'Client Category', 'jwsthemes' ),
    );

    $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'client_category' ),
    );
    if(function_exists('custom_reg_taxonomy')) {
        custom_reg_taxonomy( 'client_category', array( 'client' ), $args );
    }
    //Register tags
    $labels = array(
            'name'              => _x( 'Client Tag', 'taxonomy general name', 'jwsthemes' ),
            'singular_name'     => _x( 'Client Tag', 'taxonomy singular name', 'jwsthemes' ),
            'search_items'      => __( 'Search Client Tag', 'jwsthemes' ),
            'all_items'         => __( 'All Client Tag', 'jwsthemes' ),
            'parent_item'       => __( 'Parent Client Tag', 'jwsthemes' ),
            'parent_item_colon' => __( 'Parent Client Tag:', 'jwsthemes' ),
            'edit_item'         => __( 'Edit Client Tag', 'jwsthemes' ),
            'update_item'       => __( 'Update Client Tag', 'jwsthemes' ),
            'add_new_item'      => __( 'Add New Client Tag', 'jwsthemes' ),
            'new_item_name'     => __( 'New Client Tag Name', 'jwsthemes' ),
            'menu_name'         => __( 'Client Tag', 'jwsthemes' ),
    );

    $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'client_tag' ),
    );
    
    if(function_exists('custom_reg_taxonomy')) {
        custom_reg_taxonomy( 'client_tag', array( 'client' ), $args );
    }
    
    //Register post type Client
    $labels = array(
            'name'                => _x( 'Client', 'Post Type General Name', 'jwsthemes' ),
            'singular_name'       => _x( 'Client Item', 'Post Type Singular Name', 'jwsthemes' ),
            'menu_name'           => __( 'Client', 'jwsthemes' ),
            'parent_item_colon'   => __( 'Parent Item:', 'jwsthemes' ),
            'all_items'           => __( 'All Items', 'jwsthemes' ),
            'view_item'           => __( 'View Item', 'jwsthemes' ),
            'add_new_item'        => __( 'Add New Item', 'jwsthemes' ),
            'add_new'             => __( 'Add New', 'jwsthemes' ),
            'edit_item'           => __( 'Edit Item', 'jwsthemes' ),
            'update_item'         => __( 'Update Item', 'jwsthemes' ),
            'search_items'        => __( 'Search Item', 'jwsthemes' ),
            'not_found'           => __( 'Not found', 'jwsthemes' ),
            'not_found_in_trash'  => __( 'Not found in Trash', 'jwsthemes' ),
    );
    $args = array(
            'label'               => __( 'Client', 'jwsthemes' ),
            'description'         => __( 'Client Description', 'jwsthemes' ),
            'labels'              => $labels,
            'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', 'post-formats', ),
            'taxonomies'          => array( 'client_category', 'client_tag' ),
            'hierarchical'        => true,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'menu_icon'           => 'dashicons-networking',
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'page',
    );
    
    if(function_exists('custom_reg_post_type')) {
        custom_reg_post_type( 'client', $args );
    }
    
}

// Hook into the 'init' action
add_action( 'init', 'tb_add_post_type_client', 0 );
