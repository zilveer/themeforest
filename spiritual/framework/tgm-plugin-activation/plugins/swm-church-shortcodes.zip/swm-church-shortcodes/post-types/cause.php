<?php

/* ************************************************************************************** 
	Cause Post Type
************************************************************************************** */

add_action( 'init', 'swm_posttype_cause' );
if (!function_exists('swm_posttype_cause')) {
	function swm_posttype_cause() {	
		$labels = array(
			'name' => __( 'Cause', 'swmtranslate'),
			'singular_name' => __( 'Cause', 'swmtranslate'),
			'add_new' =>  __( 'Add New' , 'swmtranslate'),
			'add_new_item' => __('Add New Cause', 'swmtranslate'),
			'edit_item' => __('Edit Cause', 'swmtranslate'),
			'new_item' => __('New Cause Item', 'swmtranslate'),
			'view_item' => __('View Cause Item', 'swmtranslate'),
			'search_items' => __('Search Cause Items', 'swmtranslate'),
			'not_found' =>  __('No cause items found', 'swmtranslate'),
			'not_found_in_trash' => __('No cause items found in Trash', 'swmtranslate'),
			'parent_item_colon' => ''
		);
		  
		$args = array(
			'labels' => $labels,
			'public' => true,
			'exclude_from_search' => false,
			'publicly_queryable' => true,
			'rewrite' => array('slug' => 'the-cause'),
			'show_ui' => true, 
			'query_var' => true,
			'capability_type' => 'post',
			'hierarchical' => false,		
			'menu_position' => null,
			'supports' => array('title','editor','thumbnail','excerpt','comments')
		); 
		  
		register_post_type(__( 'cause' , 'swmtranslate'),$args);	
		
	}
}	
/* ------------------------------------------------------------------------------ */	

add_action( 'init', 'swm_posttype_cause_taxonomies', 0 );
if (!function_exists('swm_posttype_cause_taxonomies')) {
	function swm_posttype_cause_taxonomies(){
		
		register_taxonomy(__( "cause-categories" , 'swmtranslate'), 
			array(__( "cause" , 'swmtranslate'),), 
			array(
				"hierarchical" => true, 
				"query_var" => true,
				"rewrite" => array(
					'slug' => 'cause-categories', 
					'hierarchical' => true, 
					'with_front' => false )
			)); 
		
	}
}	
/* ------------------------------------------------------------------------------ */
 
add_filter("manage_edit-cause_columns", "swm_posttype_cause_edit_columns"); 
if (!function_exists('swm_posttype_cause_edit_columns')) {
	function swm_posttype_cause_edit_columns($columns){  
		$columns = array(  
			"cb" => "<input type=\"checkbox\" />",  
			"title" => __( 'Cause Item Title' , 'swmtranslate'),			
			"Category" => __( 'Category' , 'swmtranslate'),			
			"Image" => __( 'Image' , 'swmtranslate'),
			'date' => __( 'Date', 'swmtranslate')
		); 
		return $columns;  
	} 
}	
/* ------------------------------------------------------------------------------ */
	
add_action("manage_posts_custom_column",  "swm_posttype_cause_image_column");	
if (!function_exists('swm_posttype_cause_image_column')) {
	function swm_posttype_cause_image_column($column){  
		global $post;  
		switch ($column)  { 

			case 'Category':  
				echo wp_strip_all_tags( get_the_term_list($post->ID, 'cause-categories', '', ', ',''));  
				break;		
				
			
		}  
	}
}
/* Edit "Featured Image" box text --------------------------------------------------- */

add_filter( 'gettext', 'cause_post_edit_change_text', 20, 3 );
if (!function_exists('cause_post_edit_change_text')) {
	function cause_post_edit_change_text( $translated_text, $text, $domain ) {
	    if( ( is_cause_admin_page() ) ) {
	        switch( $translated_text ) {
	        case 'Featured Image' :
	            $translated_text = __( 'Add Cause Image', 'circle-carousel' );
	        break;
	        case 'Set Featured Image' :
	            $translated_text = __( 'Set cause image', 'circle-carousel' );
	        break;
	        case 'Set featured image' :
	            $translated_text = __( 'Set cause image', 'circle-carousel' );
	        break;
	        case 'Remove featured image' :
	            $translated_text = __( 'Remove cause image', 'circle-carousel' );
	        break;
	        }
	    }
	    return $translated_text;
	}
}
if (!function_exists('is_cause_admin_page')) {
	function is_cause_admin_page() {
	    global $pagenow;

	    if( $pagenow == 'post-new.php' ) {
	        if( isset( $_GET['post_type'] ) && $_GET['post_type'] == 'cause' )
	            return true;
	    }

	    if( $pagenow == 'post.php' ) {
	        if( isset( $_GET['post'] ) && get_post_type( $_GET['post'] ) == 'cause' )
	            return true;
	    }
	    return false;
	}
}
if( defined( 'DOING_AJAX' ) && 'DOING_AJAX' ) {
    if( isset( $_POST['post_id'] ) && get_post_type( $_POST['post_id'] ) == 'cause' )
        return true;
}

