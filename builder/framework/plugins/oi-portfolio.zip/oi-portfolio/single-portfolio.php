<?php get_header(); ?>
<?php global $oi_options; ?>
<div class="container">
<div class="this_page oi_page_holder">
	<div class="oi_sinle_portfolio_holder">
        <div class="oi_portfolio_page_holder">
        <?php
        if ( have_posts() ) : while ( have_posts() ) : the_post();
        do_shortcode(the_content()); 
		?>
		<div class="oi_port_nav">
			<?php previous_post_link('%link', '<i class="fa fa-long-arrow-left fa-fw"></i>', false); ?>   <a href="<?php echo $oi_options['oi_portfolio_link']; ?>"><i class="fa fa-th-large fa-fw"></i></a> <?php next_post_link('%link', '<i class="fa fa-long-arrow-right fa-fw"></i>', false); ?>
        </div>
		<?php
        endwhile; endif;?>
        </div>
    </div>
</div>
</div>
<?php get_footer(); ?>