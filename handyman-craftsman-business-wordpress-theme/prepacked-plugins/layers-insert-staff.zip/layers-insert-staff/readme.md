Custom Hooks:

tl/layers/customizer/before_save_{widget_id} - before saving layers customizer options
tl/filter_array/                 - filters array by keys