<?php

add_filter( 'rwmb_meta_boxes', 'swm_register_custom_posttypes_metaboxes' );

/**
 * Register meta boxes
 *
 * @return void
 */
function swm_register_custom_posttypes_metaboxes( $meta_boxes )
{
	
	$prefix = 'swm_';

	
	// Portfolio Options

	$meta_boxes[] = array(		
		'id' => 'swm-portfolio-metabox',	
		'title' => __('Portfolio Options', 'swmtranslate'),				
		'pages' => array( 'portfolio' ),		
		'context' => 'normal',		
		'priority' => 'high',
		'autosave' => true,		
		'fields' => array(	
			array(
				"name" => __('Project Type', 'swmtranslate'),				
				"id" => "{$prefix}portfolio_project_type",
				"std" => "default",
				"type" => "select",				
				"options" => array(		
					"image" => __('Image', 'swmtranslate'),
					"video" => __('Video', 'swmtranslate')							
				),				
			),					
			array( 
				'name' => __('Add YouTube/Vimeo Video URL', 'swmtranslate'),				
				'id' => "{$prefix}portfolio_video",
				'std' => '',			
				"type" => "text",
				'desc' => __('Example: http://vimeo.com/59519518', 'swmtranslate'),
			)			
		)
	);

	// Testimonials Options
	
	$meta_boxes[] = array(		
		'id' => 'swm-testimonials-metabox',	
		'title' => __('Testimonials Options', 'swmtranslate'),				
		'pages' => array( 'testimonials' ),		
		'context' => 'normal',		
		'priority' => 'high',
		'autosave' => true,		
		'fields' => array(	
			array( 
				'name' => __('Client Details (optional)', 'swmtranslate'),	
				'desc' => __('Client designation, city or country name etc. ', 'swmtranslate'),			
				'id' => "{$prefix}client_details",
				'std' => '',			
				"type" => "text"
			),					
			array( 
				'name' => __('Website URL (optional)', 'swmtranslate'),	
				'desc' => __('Client website FULL PATH URL. <br />Example: http://www.loremips.com', 'swmtranslate'),
				'id' => "{$prefix}website_url",
				'std' => '',			
				"type" => "text"
			)				
		)
	);

	// Logos Options

	$meta_boxes[] = array(		
		'id' => 'swm-logos-metabox',	
		'title' => __('Logo Options', 'swmtranslate'),				
		'pages' => array( 'logos' ),		
		'context' => 'normal',		
		'priority' => 'high',
		'autosave' => true,		
		'fields' => array(	
			array( 
				'name' => __('Client Website URL (optional)', 'swmtranslate'),	
				'desc' => __('Enter client website URl or leave it blank', 'swmtranslate'),			
				'id' => "{$prefix}client_logo_url",
				'std' => '',			
				"type" => "text"
			)					
		)
	);

	// Cause Options

	$meta_boxes[] = array(		
		'id' => 'swm-cause-metabox',	
		'title' => __('Cause Options', 'swmtranslate'),				
		'pages' => array( 'cause' ),		
		'context' => 'normal',		
		'priority' => 'high',
		'autosave' => true,		
		'fields' => array(	
			array( 
				'name' => __('Raised Amount', 'swmtranslate'),		
				'id' => "{$prefix}cause_raised_amount",
				'std' => '',			
				"type" => "text"
			),
			array( 
				'name' => __('Goal Amount', 'swmtranslate'),		
				'id' => "{$prefix}cause_goal_amount",
				'std' => '',			
				"type" => "text"
			),
			array( 
				'name' => __('Number of Donors', 'swmtranslate'),		
				'id' => "{$prefix}cause_total_donors",
				'std' => '',			
				"type" => "text"
			)
		)
	);

	// Sermons Options

	$meta_boxes[] = array(		
		'id' => 'swm-sermons-metabox',	
		'title' => __('Sermons Options', 'swmtranslate'),				
		'pages' => array( 'sermons' ),		
		'context' => 'normal',		
		'priority' => 'high',
		'autosave' => true,		
		'fields' => array(
			array( "name" => __('Add YouTube/Vimeo video embed or embedded code','swmtranslate'),
					"id" => "{$prefix}sermons_video",
					"type" => "textarea",
					'my_class' => 'swm_divider_line',
					"std" => ''
			),	
			array( 
				'name' => __('MP3 Audio File URL', 'swmtranslate'),		
				'id' => "{$prefix}sermons_audio",
				'std' => '',			
				"type" => "text"
			),
			array( 
				'name' => __('PDF File URL', 'swmtranslate'),
				'desc' => __('You can also add MP3 or any page URL', 'swmtranslate'),
				'id' => "{$prefix}sermons_pdf",
				'std' => '',			
				"type" => "text"
			),
			array( 
				'name' => __('Any Other URL', 'swmtranslate'),	
				'desc' => __('You can MP3, any page or file URL', 'swmtranslate'),	
				'id' => "{$prefix}sermons_text",
				'std' => '',			
				"type" => "text"
			)
		)
	);

	return $meta_boxes;
}