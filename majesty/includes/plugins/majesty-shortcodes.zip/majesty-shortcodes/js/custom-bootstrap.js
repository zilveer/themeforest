( function($) {
	"use strict";

	/*$("[data-thumb=tooltip]").tooltip();
	//Tabs
	$('#myTab a, .nav-tabs a, .nav-tabs2 a').click(function (e) {
	  e.preventDefault() 
	  $(this).tab('show');
	});
	
	//Carousal
	$('.carousel').carousel();
	//Alert
	$(".alert").alert();
	//Popovers
	$("[data-thumb=popover]").popover();
	//Dropdown Toggle
	$('.dropdown-toggle').dropdown();
	//Modal
	$('#myModal').modal('hide');*/
})(jQuery);