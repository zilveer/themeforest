<?php 
	/* Contact Us  ---------------------------------------------*/
	add_shortcode('contact_us', 'jx_ievent_contact_us');
	
	function jx_ievent_contact_us($atts, $content = null) { 
		extract(shortcode_atts(array(
		
		'email' => ''
		
		), $atts)); 
		
		
		global $ievent_data;
		
		$site_key = $ievent_data['site_key']; 
		
		$headers='';
		$status='';
		$status_class='';
		$id = rand(0,100);
		
		$path= get_template_directory_uri().'/inc/google_captcha.php';
		 				
		//If the form is submitted
		if(isset($_POST['submit-contact'])) {
			
			//Subject field is not required
			$subject = trim($_POST['subject']);
			
			$name    = sanitize_text_field( $_POST["contact_name"] );
			$email   = sanitize_email( $_POST["email"] );
			$subject = sanitize_text_field( $_POST["subject"] );
			$message = esc_textarea( $_POST["msg"] );			
		
			//If there is no error, send the email
			$emailTo = get_option( 'admin_email' ); //Put your own email address here 
			$body = __('Name:', 'expobiz')." $name \n\n"; 
			$body .= __('Email:', 'expobiz')." $email \n\n"; 
			$body .= __('Subject:', 'expobiz')." $subject \n\n"; 
			$body .= __('Message:', 'expobiz')."\n $message"; 
			$headers= 'Reply-To: ' . $name . ' <' . $email . '>' . "\r\n"; 
			
			if ( wp_mail($emailTo, $subject, $body, $headers) ) {
				$status= esc_html__('Thanks for contacting me, expect a response soon.','ievent');
				$status_class="jx-ievent-success";
			} else {
				$status = esc_html__('An unexpected error occurred','ievent');
				$status_class="jx-ievent-error";
			}
		
		}
		
		$out ='
		<div class="jx-ievent-contact-form">
			
			<div class="jx-ievent-status-message '.$status_class.'">'.$status.'</div>
			<form action="#" method="post" id="contactform">
				<div class="row-1">
					<div class="contact-full-name">
						<input type="text" id="full-name-contact" name="contact_name" placeholder="'.esc_html__('Full Name','ievent').'" class="jx-ievent-form-text" data-validation-length="min3"/>
						<!-- First Name Textbox -->
					</div>
					<div class="contact-email">
						<input type="text" id="email-contact" name="email" placeholder="'.esc_html__('Email Address','ievent').'" class="jx-ievent-form-text" data-validation-length="email" data-validation="required"/>
						<!-- Email Name Textbox -->
					</div>
				</div>
				
				<div class="row-1">
					<div class="contact-subject">
						<input type="text" id="subject" name="subject" placeholder="'.esc_html__('Subject','ievent').'" class="jx-ievent-form-text" />
						<!-- Subject Textbox -->
					</div>
				</div>
				
				<div class="row-1">
					<div class="contact-message mb20">
						<textarea id="message" name="msg" class="jx-ievent-form-textarea" rows="5" cols="30" placeholder="'.esc_html__('Enter Your Message Here...','ievent').'" data-validation-length="min3"></textarea>
						<!-- Message Box -->
					</div> <br>
					<div class="g-recaptcha mb20" data-sitekey= "'.$site_key.'"></div> 
					<br>
					<div class="contact-submit">
						<input type="submit" id="submit-contact-'.$id.'" name="submit-contact" class="jx-ievent-submit" value="'.esc_html__('Send','ievent').'" />
						<!-- Submit Button -->
					</div>
				</div> 
			</form>
		</div>
		'; 
		
		$out .="<script type='text/javascript'>		
				
			jQuery('#submit-contact-$id').click(function(e){
			  var data_2;
				jQuery.ajax({
							type: 'POST',
							url: '$path',
							data: jQuery('#contactform').serialize(),
							async:false,
							success: function(data) {
							if(data.nocaptcha==='true'){
								data_2=1;
								}else if(data.spam==='true')
								  {
								data_2=1;
								  }
								else
								  {
								data_2=0;
								  }
							}
						});
						if(data_2!=0){
						  e.preventDefault();
						  if(data_2==1){
							alert('Please check the captcha');
						  }else{
							alert('Please Dont spam');
						  }
						}else
						  {
							
							jQuery.validate({
								showErrorDialogs : true
							});
							
							//jQuery('#contactform').submit
						  }
			  });
			</script>";
			
		
		//return output
		return $out;
	}
	
	
	
	
	
		//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_contact_us' );
	
	
	function vc_contact_us() {	
		vc_map(array(
      "name" => esc_html__( "Contact Us", "TEXT_DOMAIN" ),
      "base" => "contact_us",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_contact-us.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Add Contact Us','ievent'),
      "params" => array(
		 		 
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Email", "TEXT_DOMAIN" ),
            "param_name" => "email",
			"value" => "youremail@example.com", 
            "description" => esc_html__( "Type Email here", "TEXT_DOMAIN" )
         )
		 
      )
   )); 
	}
	
	
	
	//Contact Info Box
	add_shortcode('contact_infobox', 'jx_ievent_contact_infobox');
	
	function jx_ievent_contact_infobox($atts, $content = null) { 
		extract(shortcode_atts(array(
		'icon' => '',
		'title' => '',
		'address' => '',
		'contact' => '',
		'email' => '',		
		), $atts)); 
		
		$out='';
		
		$out='<div class="jx-ievent-contact-info">';
			
		if ($icon):
		$out .='<div class="jx-icon"><i class="fa '.$icon.'"></i></div>';
		endif;
		
		$out .='<div class="jx-info">
				<div class="jx-title">
					<h2>'.$title.'</h2>
					<div class="jx-bottom-border"></div>
				</div>
				<div class="jx-contact-detail">
					<div class="address">'.$address.'</div>
					<div class="contact">'.$contact.'</div>
					<div class="email">'.$email.'</div>				
				</div>
			</div>
		</div>';
		
		
		//return output
		return $out;
		
	}
	
	
	
	
		//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_contact_infobox' );
	
	
	function vc_contact_infobox() {	
		vc_map(array(
      "name" => esc_html__( "Contact Infobox", "TEXT_DOMAIN" ),
      "base" => "contact_infobox",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_speaker.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Add Contact Infobox','TEXT_DOMAIN'),
      "params" => array(
		 		 
        array(
				'type' => 'iconpicker',
				'heading' => __( 'Icon', 'TEXT_DOMAIN' ),
				'param_name' => 'icon',
				'settings' => array(
				'emptyIcon' => false, // default true, display an "EMPTY" icon?
				'type' => 'linecons',
				'iconsPerPage' => 200, // default 100, how many icons per/page to display
				),
				'description' => __( 'Select icon from library.', 'TEXT_DOMAIN' ),
				'save_always' => true
			),
		 
		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Title", "TEXT_DOMAIN" ),
            "param_name" => "title",
			"value" => "My Title", 
            "description" => esc_html__( "Type Your Title Here", "TEXT_DOMAIN" )
         ),
		 
		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Address", "TEXT_DOMAIN" ),
            "param_name" => "address",
			"value" => "34 Road Matral", 
            "description" => esc_html__( "Type Your Address ", "TEXT_DOMAIN" )
         ),

		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Contact", "TEXT_DOMAIN" ),
            "param_name" => "contact",
			"value" => "Rosfelt, Madness", 
            "description" => esc_html__( "Type Your Address ", "TEXT_DOMAIN" )
         ),

		array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Email", "TEXT_DOMAIN" ),
            "param_name" => "email",
			"value" => "youremail@example.com", 
            "description" => esc_html__( "Type Your Email Address ", "TEXT_DOMAIN" )
         )


		 		 

      )
   )); 
	}
	
	
	
?>