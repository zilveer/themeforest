<?php
/**
* Plugin Name: Event Station Theme: Post Types
* Plugin URI: http://themeforest.net/user/gloriatheme
* Description: Event Station theme post types
* Version: 1.0
* Author: Gloria Theme
* Author URI: http://gloriatheme.com/
*/

/*--------------- SCHEDULE START ---------------*/
if ( ! function_exists('schedule') ) {
	function schedule() {
		$labels = array(
			'name' => _x( 'Schedule', 'Post Type General Name', 'eventstation' ),
			'singular_name' => _x( 'schedule', 'Post Type Singular Name', 'eventstation' ),
			'menu_name' => esc_html__( 'Schedule', 'eventstation' ),
			'parent_item_colon' => esc_html__( 'Parent Schedule:', 'eventstation' ),
			'all_items' => esc_html__( 'All Schedule', 'eventstation' ),
			'view_item' => esc_html__( 'View Schedule', 'eventstation' ),
			'add_new_item' => esc_html__( 'Add New Schedule Item', 'eventstation' ),
			'add_new' => esc_html__( 'Add New Schedule', 'eventstation' ),
			'edit_item' => esc_html__( 'Edit Schedule', 'eventstation' ),
			'update_item' => esc_html__( 'Update Schedule', 'eventstation' ),
			'search_items' => esc_html__( 'Search Schedule', 'eventstation' ),
			'not_found' => esc_html__( 'Not Schedule found', 'eventstation' ),
			'not_found_in_trash' => esc_html__( 'Not Schedule found in Trash', 'eventstation' ),
		);
		$args = array(
			'label' => esc_html__( 'Schedule', 'eventstation' ),
			'description' => esc_html__( 'Schedule post type description.', 'eventstation' ),
			'labels' => $labels,
			'supports' => array( 'title', ),
			'hierarchical' => false,
			'public' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'show_in_nav_menus' => true,
			'show_in_admin_bar' => false,
			'menu_position' => 20,
			'menu_icon' => 'dashicons-groups',
			'can_export' => true,
			'has_archive' => true,
			'exclude_from_search' => true,
			'publicly_queryable' => true,
			'capability_type' => 'post',
		);
		register_post_type( 'schedule', $args );
	}
	add_action( 'init', 'schedule', 0 );
}

if ( ! function_exists( 'schedule_days' ) ) {
	function schedule_days() {

		$labels = array(
			'name' => _x( 'Days', 'Days General Name', 'eventstation' ),
			'singular_name' => _x( 'Days', 'Days Singular Name', 'eventstation' ),
			'menu_name' => esc_html__( 'Days', 'eventstation' ),
			'all_items' => esc_html__( 'All Items', 'eventstation' ),
			'parent_item' => esc_html__( 'Parent Item', 'eventstation' ),
			'parent_item_colon' => esc_html__( 'Parent Item:', 'eventstation' ),
			'new_item_name' => esc_html__( 'New Item Name', 'eventstation' ),
			'add_new_item' => esc_html__( 'Add New Item', 'eventstation' ),
			'edit_item' => esc_html__( 'Edit Item', 'eventstation' ),
			'update_item' => esc_html__( 'Update Item', 'eventstation' ),
			'separate_items_with_commas' => esc_html__( 'Separate items with commas', 'eventstation' ),
			'search_items' => esc_html__( 'Search Items', 'eventstation' ),
			'add_or_remove_items' => esc_html__( 'Add or remove items', 'eventstation' ),
			'choose_from_most_used' => esc_html__( 'Choose from the most used items', 'eventstation' ),
			'not_found' => esc_html__( 'Not Found', 'eventstation' ),
		);
		$args = array(
			'labels' => $labels,
			'hierarchical' => true,
			'public' => true,
			'show_ui' => true,
			'show_admin_column' => true,
			'show_in_nav_menus' => true,
			'show_tagcloud' => true
		);
		register_taxonomy( 'schedule_days', array( 'schedule' ), $args );

	}
	add_action( 'init', 'schedule_days', 0 );
}
/*--------------- SCHEDULE END ---------------*/