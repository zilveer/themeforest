<?php  
//Register "container" content element
vc_map( array(
    "name" => __("About Us Carousel", "wish"),
    "description" => __("About Us Carousel", 'wish'),
    "controls" => "full",
    "base" => "wish_about_carousel",
    "as_parent" => array('only' => 'wish_about_carousel_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link" => "http://i.imgur.com/n6iwqyb.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
                            array(
                                    "type" => "textfield",
                                    "heading" => __("Title", "wish"),
                                    "param_name" => "title",
                                    "description" => __("The Title.", "wish"),
                                    "value" => __("we build", 'wish'),
                                    "admin_label" => true,
                            ),

                            array(
                                "type" => "textarea",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Details", 'wish'),
                                "param_name" => "content",
                                "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
                                "description" => __("Details", 'wish')
                            ),

                             /*Title*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __( "Title Text Font", "wish" ),
                                "param_name" => "title_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Title Size", "wish"),
                                "param_name" => "title_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("70", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Title Text Color", "wish" ),
                                "param_name" => "title_color",
                                "value" => '#fff ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),


                            /*Details*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __( "Details Text Font", "wish" ),
                                "param_name" => "details_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Details Size", "wish"),
                                "param_name" => "details_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("14", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Details Text Color", "wish" ),
                                "param_name" => "details_color",
                                "value" => '#000 ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),




    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("About Us Image", "wish"),
    "base" => "wish_about_carousel_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_about_carousel'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

                            array(
                                "type" => "attach_image",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Carousel Image", 'wish'),
                                "param_name" => "image",
                                "description" => __("The Carousel Images in the left Side.", 'wish'),
                                "value" => "Image",
                            ),


       
    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_About_Carousel extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'         => 'we build',
        'title_font'    => '',
        'title_size'    => '70',
        'title_color'   => '#fff',

        'details'       => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.',
        'details_font'  => '',
        'details_size'  => '14',
        'details_color' => '#000'
      ), $atts ) );

        /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

      $output = "<div id='about-us' class='container we-build-1'>
                        <div class='row'>
                            <div class='col-lg-5 animated' data-animation='fadeInUp' data-animation-delay='100'>
                                <div class='we-build-carousel'>

                                    ".do_shortcode($content)."
                                    
                                </div>
                            </div>
                            <div class='col-lg-7'>
                                <div class='intro-1'>
                                    <h1 class='animated' data-animation='fadeInDown' data-animation-delay='300' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                                    <div class='description animated' data-animation='fadeInUp' data-animation-delay='600' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                                </div>
                            </div>
                        </div>
                </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_About_Carousel_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image'   => 'Image',
          ), $atts ) );
       

         $imgsrc = wp_get_attachment_image_src( $image, array(458,458) );
    
          if($image == "Image"){
            $imgsrc[0] = plugins_url('images/guy.jpg', __FILE__);
          }


          $output = "<div class='picture'><img src='{$imgsrc[0]}' class='img-responsive' alt='About Us'></div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>