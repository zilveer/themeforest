<style id="cornerstone-page-style"><?php echo $this->page_style; ?></style>
