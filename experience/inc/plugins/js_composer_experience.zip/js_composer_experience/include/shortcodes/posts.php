<?php 
if ( class_exists( 'WPBakeryShortCode' ) ) {

	class WPBakeryShortCode_experience_posts extends WPBakeryShortCode {
		
		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		 
		protected function content( $atts, $content = null ) {
			
			$output = '';
			
			extract( shortcode_atts( array(			
				'number'	=> '3',
				'category'	=> '',
				'tag'		=> ''
			), $atts ) );
			
			$query_args = array(
				'post_type'				=> 'post',
				'posts_per_page'		=> intval( $number ),
				'category_name'			=> esc_html( $category ),
				'tag'					=> esc_html( $tag ),
				'ignore_sticky_posts'	=> 1
			);			
			
			$postslist = new WP_query( $query_args );
			
			if ( $postslist->have_posts() ) {
			
				$output .= '<div class="posts-list">';
				
					while ( $postslist->have_posts() ) : $postslist->the_post();
					
						global $post;
						
						$output .= '<article>';
						
							$output .= '<h3><a href="'. get_permalink() .'">'. get_the_title() .'</a></h3>';
							$output .= '<span class="post-date"><time datetime="'. get_the_time( 'c' ) .'">'. get_the_date() .'</time>';
						
						$output .= '</article>';
						
					endwhile;	
					
				$output .= '</div>';
				
				wp_reset_postdata();
				
				return $output;
			
			}
		
		}
		
	}
	
}

/* --------- POSTS --------- */
	
vc_map( array(
	"base"			=> "experience_posts",
	"name"			=> esc_html__( "Posts List", "js_composer_experience" ),
	"description"	=> esc_html__( "Display a list of latest posts.", "js_composer_experience" ),
	"class"			=> "",	
	"params"		=> array(
		
		// Number
		array(
			"param_name"	=> "number",
			"heading"		=> esc_html__( "Number of posts", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the number of posts to display.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label" => true
		),
		
		// Category
		array(
			"param_name"	=> "category",
			"heading"		=> esc_html__( "Category", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the post category slug to show. Leave blank to show all latest posts. Separate each category slug with a comma.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label" => true
		),
		
		// Tag
		array(
			"param_name"	=> "tag",
			"heading"		=> esc_html__( "Tag", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the post tag slug to show. Separate each tag slug with a comma.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label" => true
		),
	
	)
	
) );