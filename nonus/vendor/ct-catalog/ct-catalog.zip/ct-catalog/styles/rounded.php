<?php
/** Defaults */
//Colors
($btnBgClr=="")? $btnBgClr='#4BB0EC':$btnBgClr=$btnBgClr;
($btnBgClrHover=="")? $btnBgClrHover='#2ca3e9':$btnBgClrHover=$btnBgClrHover;
($btnTxtClr=="")? $btnTxtClr='#fff':$btnTxtClr=$btnTxtClr;

//Border
($btnRadiusValue=="")? $btnRadiusValue='100':$btnRadiusValue=$btnRadiusValue;

//Padding small
($btpTop=="")? $btpTopSmall='7':$btpTopSmall=$btpTop;
($btpRight=="")? $btpRightSmall='15':$btpRightSmall=$btpRight;
($btpBottom=="")? $btpBottomSmall='7':$btpBottomSmall=$btpBottom;
($btpLeft=="")? $btpLeftSmall='15':$btpLeftSmall=$btpLeft;

//Padding
($btpTop=="")? $btpTop='10':$btpTop=$btpTop;
($btpRight=="")? $btpRight='20':$btpRight=$btpRight;
($btpBottom=="")? $btpBottom='10':$btpBottom=$btpBottom;
($btpLeft=="")? $btpLeft='20':$btpLeft=$btpLeft;
?>

<style type="text/css">
    .ct-style-rounded.<?php echo $value; ?> {
        background:<?php echo $btnBgClr; ?> !important;
        border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -moz-border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -webkit-border-radius: <?php echo $btnRadiusValue; ?>px !important;
        font-weight: bold !important;
        color: <?php echo $btnTxtClr; ?> !important;
        padding: <?php echo $btpTop; ?>px <?php echo $btpRight; ?>px <?php echo $btpBottom; ?>px <?php echo $btpLeft; ?>px !important;
        text-decoration: none !important;
        display: inline-block !important;

        -webkit-box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        -moz-box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        margin: <?php echo $btmTop; ?>px <?php echo $btmRight; ?>px <?php echo $btmBottom; ?>px <?php echo $btmLeft; ?>px !important;
    }

    .ct-style-rounded.small.<?php echo $value; ?> {
        font-size: 12px !important;
        padding: <?php echo $btpTopSmall; ?>px <?php echo $btpRightSmall; ?>px <?php echo $btpBottomSmall; ?>px <?php echo $btpLeftSmall; ?>px !important;
        display:block !important;
        text-align: center !important;
    }

    .ct-style-rounded.<?php echo $value; ?>:hover, .rounded.small.<?php echo $value; ?>:hover {
        background:<?php echo $btnBgClrHover; ?> !important;

        color: <?php echo $btnTxtClrHover; ?> !important;
        text-decoration: none !important;
        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClrHover; ?> !important;
    }
</style>