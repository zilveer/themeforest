<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// shortcode for button
add_shortcode('button', 'multipurpose_button');

function multipurpose_button($attr, $content = "") {
	
	extract(shortcode_atts(array('color' => 'orange', 'size' => 'large', 'link' => '#', 'open_in_new_window' => '', 'icon' => ''), $attr));
	
	$html = '<a href="'.$link.'" class="btn';
	if($color) { $html .= ' '.$color; }
	if($size != 'small' ) { $html .= ' '.$size; }
	$html .= '"';
	if($open_in_new_window == 'yes') { $html .= ' target="_blank"'; }
	$html .= '>';
	if($icon) { $html .= '<i class="fa '.$icon.'"></i>'; }
	$html .= $content . '</a>';
	 
	return $html;
}
