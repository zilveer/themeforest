<?php

//Register "container" content element

vc_map( array(

    "name" => __("Custom Project Portfolio", "wish"),

    "description" => __("Maonry Portfolio With Categories filters", 'wish'),

    "controls" => "full",

    "base" => "wish_custom_project_portfolio",

    "as_parent" => array('only' => 'wish_custom_project_portfolio_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)

    "content_element" => true,

    "link" => "http://i.imgur.com/mdDyGgx.png",

    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),

    "show_settings_on_create" => true,

    "category" => __('Wish Components', 'wish'),

    "js_view" => 'VcColumnView',

    "params" => array(



        // add params same as with any other content element

        array(

            "type" => "textfield",

            "heading" => __("Title", "wish"),

            "param_name" => "title",

            "description" => __("Title", "wish"),

            "value" => __("Projects", 'wish'),

            "admin_label" => true,

        ), 



        /*Title*/

        array(

            "type" => "google_fonts",

            "class" => "",

            "heading" => __("Title Text Font", "wish" ),

            "param_name" => "title_font",

            "value" => '', //Default Red color

            "description" => __( "Choose Font", "wish" ),

            "group"   => "Fonts & Colors",

            'settings' => array(

                 'fields'=>array(

                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

               )

            )       

        ),





        array(

            "type" => "wish_number",

            "heading" => __("Title Size", "wish"),

            "param_name" => "title_size",

            "description" => __("Font size in px", "wish"),

            "value" => __("40", 'wish'),

            "admin_label" => true,

            "group"       => "Fonts & Colors",

        ),



        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __("Title Text Color", "wish" ),

            "param_name" => "title_color",

            "value" => '#1ca55f ', //Default Black color

            "description" => __( "Choose text color", "wish" ),

            "group"         => "Fonts & Colors",

         ),



       



         array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __( "Background Color", "wish" ),

            "param_name" => "bgcolor",

            "value" => '#f4f4f4',

            "description" => __( "Choose background color", "wish" ),

            "group"         => "Fonts & Colors",

            "admin_label" => false,

         ),





         array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __( "Theme Color", "wish" ),

            "param_name" => "hover_color",

            "value" => '#1ca55f',

            "description" => __( "Choose theme color", "wish" ),

            "group"         => "Fonts & Colors",

            "admin_label" => false,

         ),



    ),



));//ends vc_map



//////////////child elements

vc_map( array(

    "name" => __("Portfolio Image", "wish"),

    "base" => "wish_custom_project_portfolio_single",

    "content_element" => true,

    "as_child" => array('only' => 'wish_custom_project_portfolio'), // Use only|except attributes to limit parent (separate multiple values with comma)

    "params" => array(



        array(

            "type" => "attach_image",

            "holder" => "div",

            "class" => "",

            "heading" => __("The Image", 'wish'),

            "param_name" => "image",

            "admin_label" => false,    

        ),



        array(

            "type" => "textfield",

            "heading" => __("Title", "wish"),

            "param_name" => "title",

            "description" => __("Image Title", "wish"),

            "value" => __("Design", 'wish'),

            "admin_label" => true,

        ),



        array(

            "type" => "vc_link",

            "holder" => "div",

            "class" => "",

            "heading" => __("Link To The Page", 'wish'),

            "param_name" => "link",

            "description" => __("The Link To The Appointment page.", 'wish'),

            "admin_label" => false,

        ),



        array(

            "type" => "textfield",

            "heading" => __("Link Title", "wish"),

            "param_name" => "link_text",

            "description" => __("Title of the link", "wish"),

            "value" => __("Discover", 'wish'),

            "admin_label" => false,

        ),







        /*Title*/

        array(

            "type" => "google_fonts",

            "class" => "",

            "heading" => __("Title Text Font", "wish" ),

            "param_name" => "title_font",

            "value" => '', //Default Red color

            "description" => __( "Choose Font", "wish" ),

            "group"   => "Fonts & Colors",

            'settings' => array(

                 'fields'=>array(

                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

               )

            )       

        ),





        array(

            "type" => "wish_number",

            "heading" => __("Title Size", "wish"),

            "param_name" => "title_size",

            "description" => __("Font size in px", "wish"),

            "value" => __("18", 'wish'),

            "admin_label" => true,

            "group"       => "Fonts & Colors",

        ),



        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __("Title Text Color", "wish" ),

            "param_name" => "title_color",

            "value" => '#000 ', //Default Black color

            "description" => __( "Choose text color", "wish" ),

            "group"         => "Fonts & Colors",

         ),







    )//ends params



) );//ends vc_map







////////////////////////////////////Starts container class

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {

    class WPBakeryShortCode_Wish_Custom_Project_Portfolio extends WPBakeryShortCodesContainer {



    public function content( $atts, $content = null ) {



          extract( shortcode_atts( array(

            'title' => 'Projects',

            'title_font'  => '',

            'title_size'  => '30',

            'title_color' => '#1ca55f',



            'bgcolor'   => '#f4f4f4',

            'hover_color' => '#1ca55f',

          ), $atts ) );



          /*title*/

        $decode_font = urldecode($title_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );





         wp_enqueue_script('wish-isotope-portfolio', plugins_url('assets/isotope/jquery.isotope.min.js', __FILE__), array('jquery') );

         wp_enqueue_script('wish-isotope-portfolio-masonry', plugins_url('assets/isotope/custom-isotope-masonry2.js', __FILE__), array('jquery') );

        





      $output = "

      <style>

        #portfolio-mansory .picture{

            background-color: {$hover_color};

        }

        .picture-overlay .icons > :first-child .icon a{

            color: {$hover_color};

        }

        .featured-projects .buttons a.fill{

            background-color: {$hover_color};

            border: 2px solid {$hover_color};

        }



        .featured-projects .buttons a.fill:hover {

            background-color: transparent;

            color: {$hover_color};

            border: 2px solid {$hover_color};

        }

      </style>

      <div id='featured-project-page' class='featured-projects' style='background-color:{$bgcolor}'>

            <div class='container-fluid'>

                <div class='row'>

                    <div class='col-lg-12'>

                        <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>

                    </div>

                </div>

            </div>

            <!-- Portfolio Thumbs Starts -->

            <div id='portfolio-mansory' class='animated isotope' data-animation='fadeInUp' data-animation-delay='100' style='position: relative; overflow: hidden; height: 1154px;'>



                      ".do_shortcode($content)."





                      </div>

                    </div>";

      

      return $output;

    }





    }//end of container class

} //end if



///////////////////////////////////////////ends container class





if ( class_exists( 'WPBakeryShortCode' ) ) {

class WPBakeryShortCode_Wish_Custom_Project_Portfolio_Single extends WPBakeryShortCode {





        public function content( $atts, $content = null ) {

        

          extract( shortcode_atts( array(

            'image'   => 'Image',

            'title' => 'web',

            'title_font'  => '',

            'title_size'  => '18',

            'title_color' => '#000',

            'link'          => '#',

            'link_text'     => 'Discover'

          ), $atts ) );



          /*title*/

        $decode_font = urldecode($title_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



          $img = wp_get_attachment_image_src( $image, array(404,515));





          if($image == "Image"){

            $imgsrc = plugins_url('images/9.jpg', __FILE__);

            $img[0] = $imgsrc;



          }



          if($link == "||" || $link == "" ){

            

            $link_text = "Discover";

            $link_url = "#";

            $link_target = "";

            $link_String="";



          }else{



            $link = vc_build_link($link); //parse the link

            $link_url = esc_url($link["url"]);

            $link_target = esc_attr($link["target"]);


            $link_String="<div class='buttons'><a target='{$link_target}' href='{$link_url}' class='fill'>{$link_text}</a></div>";

            if ($link_text == "") {

                $link_String = "";

            }



          }







          $output = "<figure class='item isotope-item'>

                    <div class='box'>

                        <div class='picture'><img src='{$img[0]}' class='img-responsive' alt=''></div>

                        <div class='info'>

                            <div class='caption' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</div>

                            {$link_String}

                        </div>

                    </div>

                    <div class='clearfix'></div>

                </figure>";



          return $output;

        }





}//end class



} //end if



/////////////////////////////////////////////////////////////////////////////////////////////



?>