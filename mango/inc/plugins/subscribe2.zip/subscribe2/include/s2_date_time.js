// Version 1.0 - original version
jQuery( document ).ready(function() {
    jQuery( '#s2datepicker' ).datepicker({
        dateFormat : 'MM d, yy'
    });
});