<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

/* other helper functions */

//Shortcode Empty Paragraph fix and remove <br /> between shortcodes
function multipurpose_shortcode_empty_paragraph_fix($content) {
    $array = array(
        '<p>[' => '[',
        ']</p>' => ']',
        ']<br />' => ']'
    );

    $content = strtr($content, $array);
    return $content;
}

//Remove e.g. from values
function multipurpose_arrangement_shortcode_value($value) {
    return preg_replace('/^e.g.\s*/', '', $value);
}

function multipurpose_arrangement_shortcode_arr_value(&$value) {
    $value = preg_replace('/^e.g.\s*/', '', $value);
}

add_filter('the_content', 'multipurpose_shortcode_empty_paragraph_fix');
