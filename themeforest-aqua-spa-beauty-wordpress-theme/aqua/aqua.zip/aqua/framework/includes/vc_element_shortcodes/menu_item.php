<?php

add_action('init', 'menu_item_integrateWithVC');

function menu_item_integrateWithVC() {
    vc_map(array(
        "name" => __("Menu Item", 'jwsthemes'),
        "base" => "menu_item",
        "class" => "menu-item",
        "category" => __('Aqua', 'jwsthemes'),
        "icon" => "tb-icon-for-vc",
        "params" => array(
            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => __("Title", 'jwsthemes'),
                "param_name" => "title",
                "value" => "",
                "description" => __("Title menu item.", 'jwsthemes')
            ),
			array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => __("Price", 'jwsthemes'),
                "param_name" => "price",
                "value" => "",
                "description" => __("Price menu item.", 'jwsthemes')
            ),
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Animation", 'jwsthemes'),
                "param_name" => "animation",
                "value" => array(
                    "No" => "",
                    "Top to bottom" => "top-to-bottom",
                    "Bottom to top" => "bottom-to-top",
                    "Left to right" => "left-to-right",
                    "Right to left" => "right-to-left",
                    "Appear from center" => "appear"
                ),
                "description" => __("Animation", 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Extra Class", 'jwsthemes'),
                "param_name" => "el_class",
                "value" => "",
                "description" => __ ( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'jwsthemes' )
            ),
        )
    ));
}
