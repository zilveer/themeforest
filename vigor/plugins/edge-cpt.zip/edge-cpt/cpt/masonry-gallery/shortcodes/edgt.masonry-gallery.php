<?php

class EdgtMasonryGallery {
    public function __construct() {
        add_shortcode('no_masonry_gallery', array($this, 'render'));
        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function vcMap() {
        if(function_exists('vc_map')) {
            vc_map( array(
                "name" => "Masonry Gallery",
                "base" => "no_masonry_gallery",
                "category" => 'by EDGE',
                "icon" => "icon-wpb-masonry-gallery",
                "allowed_container_element" => 'vc_row',
                "params" => array(
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => "Category",
                        "param_name" => "category",
                        "value" => "",
                        "description" => "Category Slug (leave empty for all)"
                    ),
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => "Number",
                        "param_name" => "number",
                        "value" => "",
                        "description" => "Number of Masonry Gallery Items"
                    ),
                    array(
                        "type" => "dropdown",
                        "holder" => "div",
                        "class" => "",
                        "heading" => "Order",
                        "param_name" => "order",
                        "value" => array(
                            "DESC" => "DESC",
                            "ASC" => "ASC"
                        ),
                        'save_always' => true,
                        "description" => ""
                    ),
                    array(
                        "type" => "colorpicker",
                        "holder" => "div",
                        "heading" => "Triangle Color",
                        "param_name" => "triangle_color",
                        "description" => "Choose color of triangle showing on hover"
                    )
                )
            ));
        }
    }

    public function render($atts, $content = null) {
        global $edgtIconCollections;

        $default_args = array(
            'category' => '',
            'number' => -1,
            'order' => 'DESC',
            'triangle_color' => ''
        );

        extract(shortcode_atts($default_args, $atts));

        $html = '';

        /* Query for items */
        $query_args = array(
            'post_type' => 'masonry_gallery',
            'orderby' => 'date',
            'order' => $order,
            'posts_per_page' => $number
        );

        if ($category != "") {
            $query_args['masonry_gallery_category'] = $category;
        }
        $query = new WP_Query( $query_args );

        switch ($number) {
            case 1:
                $item_number_class = 'one_column';
            break;
            case 2:
                $item_number_class = 'two_columns';
            break;
            case 3:
                $item_number_class = 'three_columns';
            break;
            default:
                $item_number_class = '';
            break;  
        }

        $html .= '<div class="masonry_gallery_holder '.$item_number_class.'"><div class="grid-sizer"></div>';

        if ($query->have_posts()) :
            while ( $query->have_posts() ) : $query->the_post();

                $item_type = '';
                $item_class = '';
                $item_text = '';
                $item_link = '';
                $item_button_label = '';
                $item_icon = '';
                $item_link_target = '_self';

                if (get_post_meta(get_the_ID(), 'edgt_masonry_gallery_item_type', true) !== '') {
                    $item_type = get_post_meta(get_the_ID(), 'edgt_masonry_gallery_item_type', true);
                }
                if (get_post_meta(get_the_ID(), 'edgt_masonry_gallery_item_size', true) !== '') {
                    $item_class = get_post_meta(get_the_ID(), 'edgt_masonry_gallery_item_size', true);
                }
                if (get_post_meta(get_the_ID(), 'edgt_masonry_gallery_item_text', true) !== '') {
                    $item_text = get_post_meta(get_the_ID(), 'edgt_masonry_gallery_item_text', true);
                }
                if (get_post_meta(get_the_ID(), 'edgt_masonry_gallery_item_link', true) !== '') {
                    $item_link = get_post_meta(get_the_ID(), 'edgt_masonry_gallery_item_link', true);
                }
                if (get_post_meta(get_the_ID(), 'edgt_masonry_gallery_item_link_target', true) !== '') {
                    $item_link_target = get_post_meta(get_the_ID(), 'edgt_masonry_gallery_item_link_target', true);
                }

                switch ($item_class) {
                    case 'square_big':
                        $gallery_thumb_size = 'portfolio_masonry_large';
                        break;
                    case 'square_small':
                        $gallery_thumb_size = 'portfolio-square';
                        break;
                    case 'rectangle_portrait':
                        $gallery_thumb_size = 'portfolio_masonry_tall';
                        break;
                    case 'rectangle_landscape':
                        $gallery_thumb_size = 'portfolio_masonry_wide';
                        break;
                    default:
                        $gallery_thumb_size = 'portfolio-square';
                        break;
                }

                $html .= '<article id="'.get_the_ID().'" class="masonry_gallery_item ' . esc_attr($item_class) . ' ' .esc_attr($item_type). '">';

                switch($item_type) {
                    case 'with_button':

                        //With Button Type
                        if (get_post_meta(get_the_ID(), 'edgt_masonry_gallery_button_label', true) !== '') {
                            $item_button_label = get_post_meta(get_the_ID(), 'edgt_masonry_gallery_button_label', true);
                        }

                        if (has_post_thumbnail()) {
                            $html .= '<div class = "masonry_gallery_image_holder">';
                            $html .= get_the_post_thumbnail(get_the_ID(),$gallery_thumb_size);
                            $html .= '</div>';
                        }

                        $html .= '<div class="masonry_gallery_item_outer"><div class="masonry_gallery_item_inner"><div class="masonry_gallery_item_content">';

                        $html .= '<h3>' . get_the_title() . '</h3>';
                        $html .= '<p class="masonry_gallery_item_text">' . esc_html($item_text) . '</p>';

                        if ($item_link !== '' && $item_button_label !== '') {
                            $html .= '<a href="'.esc_url($item_link).'" class="qbutton masonry_gallery_item_button" target="'.esc_attr($item_link_target).'">'.$item_button_label.'</a>';
                        }

                        $html .= '</div></div></div>';

                        break;

                    case 'with_icon':

                        //With Icon Type
                        if ($item_link !== '') {
                            $html .= '<a href="'.esc_url($item_link).'" target="'.esc_attr($item_link_target).'">';
                        }

                        if (has_post_thumbnail()) {
                            $html .= '<div class = "masonry_gallery_image_holder">';
                            $html .= get_the_post_thumbnail(get_the_ID(),$gallery_thumb_size);
                            $html .= '</div>';
                        }

                        $html .= '<div class="masonry_gallery_item_outer"><div class="masonry_gallery_item_inner"><div class="masonry_gallery_item_content">';

                        //Get icon pack
                        if (get_post_meta(get_the_ID(), "edgt_masonry_gallery_item_with_icon_icon_pack", true) != ''){

                            $item_icon_pack = get_post_meta(get_the_ID(), "edgt_masonry_gallery_item_with_icon_icon_pack", true);

                            $icon_collection_obj = $edgtIconCollections->getIconCollection($item_icon_pack);

                            //Get icon pack param
                            $item_icon_param = $icon_collection_obj->param;

                            //Get icon
                            if (get_post_meta(get_the_ID(), "edgt_masonry_gallery_item_with_icon_".$item_icon_param, true) !== '') {
                                $item_icon = get_post_meta(get_the_ID(), "edgt_masonry_gallery_item_with_icon_".$item_icon_param, true);
                            }

                            //Render icon
                            if (method_exists($icon_collection_obj, 'render')) {
                                $html .= '<div class="masonry_gallery_item_icon">'.$icon_collection_obj->render($item_icon).'</div>';
                            }

                        }

                        $html .= '<h3>' . get_the_title() . '</h3>';
                        $html .= '<p class="masonry_gallery_item_text">' . esc_html($item_text) . '</p>';


                        $html .= '</div></div></div>';

                        if ($item_link !== '') {
                            $html .= '</a>';
                        }
                        break;

                    case 'standard':

                        //Only image
                        if ($item_link !== '') {
                            $html .= '<a href="'.esc_url($item_link).'" target="'.esc_attr($item_link_target).'">';
                        }

                        if (has_post_thumbnail()) {
                            $html .= '<div class = "masonry_gallery_image_holder">';
                            $html .= get_the_post_thumbnail(get_the_ID(),$gallery_thumb_size);
                            $html .= '</div>';
                        }


                        $triangle_style = "";
                        if ($triangle_color !== "") {
                            $triangle_style .= 'border-top-color:' . esc_attr($triangle_color) . ';';
                        }

                        $html .= '<div class="masonry_gallery_item_outer">';

                        $html .= '<div class="masonry_gallery_triangle_holder"><div class = "masonry_gallery_triangle" ' . edgt_get_inline_style($triangle_style) . '></div></div>';

                        $html .= '<div class="masonry_gallery_item_inner">';

                        $html .= '<div class="masonry_gallery_item_content">';

                        $html .= '<h3>' . get_the_title() . '</h3>';


                        $html .= '</div></div></div>';

                        if ($item_link !== '') {
                            $html .= '</a>';
                        }
                        break;
                }

                $html .= '</article>';

            endwhile;
        else:
            $html .= __('Sorry, no posts matched your criteria.', 'edgt_cpt');
        endif;

        $html .= '</div>';

        return $html;
    }
}

new EdgtMasonryGallery();