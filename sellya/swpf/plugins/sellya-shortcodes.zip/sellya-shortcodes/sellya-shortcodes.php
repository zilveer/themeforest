<?php
/**
 * Plugin Name: Sellya Shortcodes
 * 
 * Description: Sellya Shortcodes plugin for wordpress
 * Version: 1.0
 * Author: Smartdatasoft
 * Author URI: http://www.smartdatasoft.com/
 * Requires at least: 3.5
 * Tested up to: 3.6
 *
 * Text Domain: sellya
 * Domain Path: /i18n/languages/
 *
 * @package Sellya
 * @category Core
 * @author Smartdatasoft
 */
 
function sellya_shortcodes_activation() {
	
	
}
register_activation_hook(__FILE__, 'sellya_shortcodes_activation');

function sellya_shortcodes_deactivation() {
	
}

register_deactivation_hook(__FILE__, 'sellya_shortcodes_deactivation');

if(!class_exists('SellyaShortcodes')):
	
	class SellyaShortcodes{
		
		public static $plugindir, $pluginurl;
		
		function __construct(){
			
			SellyaShortcodes::$plugindir = dirname(__FILE__);
			
			SellyaShortcodes::$pluginurl = plugins_url('',__FILE__);
			
			add_action( 'admin_enqueue_scripts', array($this,'load_sellya_shortcodes_admin_scripts') );
					
			add_action( 'init', array($this,'sellya_shortcode_button') );
			
			add_action( 'wp_enqueue_scripts', array($this,'load_sellya_shortcodes_scripts'), 50 );
			
					
		}
		
		function load_sellya_shortcodes_admin_scripts(){
			
			wp_enqueue_script('jquery');
			
		}
		

		function sellya_shortcode_button() {
		
			if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') )
		
				return;
		
			// Add only in Rich Editor mode
		
			if ( get_user_option('rich_editing') == 'true') {
		
				add_filter("mce_external_plugins", array($this,"sellya_add_shortcode_tinymce_plugin"));
		
				add_filter('mce_buttons', array($this,'sellya_register_shortcode_button'));
		
			}
		
		}
		
		/**
		
		 * Register the TinyMCE Shortcode Button
		
		 */
		
		function sellya_register_shortcode_button($buttons) {
		
			array_push($buttons, "|", "sellyashortcodes");
		
			return $buttons;
		
		}
		
		/**
		
		 * Load the TinyMCE plugin: shortcode_plugin.js
		
		 */
		
		function sellya_add_shortcode_tinymce_plugin($plugin_array) {	
		
		   $plugin_array['sellyashortcodes'] = SellyaShortcodes::$pluginurl . '/assets/js/shortcode_plugin.js';
		
		   return $plugin_array;
		
		}

		function load_sellya_shortcodes_scripts(){
			
			wp_enqueue_style( 'sellya-shortcodes', SellyaShortcodes::$pluginurl . '/assets/css/shortcode-styles.css', '', '1.0' );
			
			wp_enqueue_script(array('jquery-ui-accordion','jquery-ui-tabs'), '', array('jquery','jquery-ui-core'));
			
			wp_enqueue_script('sellya-defaults', SellyaShortcodes::$pluginurl . '/assets/js/default.js', array('jquery'), '1.0',true);
			
		}
	
	}
	

	$SellyaShortcodes = new SellyaShortcodes();
			
	require_once( SellyaShortcodes::$plugindir . "/lib/shortcodes.php" );
	
endif;


?>