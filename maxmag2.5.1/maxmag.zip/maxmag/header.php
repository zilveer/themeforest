<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<?php if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) { ?>
<?php $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'post-thumb' ); ?>
<meta property="og:image" content="<?php echo $thumb['0']; ?>" />
<?php } ?>

<title><?php wp_title( '-', true, 'right' ); ?></title>

<!--[if IE]>
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/iecss.css" />
<![endif]-->
<?php if(get_option('mm_favicon')) { ?><link rel="shortcut icon" href="<?php echo get_option('mm_favicon'); ?>" /><?php } ?>
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>

<?php $analytics = get_option('mm_tracking'); if ($analytics) { echo stripslashes($analytics); } ?>

<?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>

<div id="site">
	<div id="top-wrapper">
		<div id="top-nav-wrapper">
			<div id="top-nav">
				<div id="top-menu">
					<?php wp_nav_menu(array('theme_location' => 'secondary-menu')); ?>
				</div><!--top-menu-->
				<div id="search-wrapper">
					<?php get_search_form(); ?>
				</div><!--search wrapper-->
			</div><!--top-nav-->
		</div><!--top-nav-wrapper-->
		<?php if(get_option('mm_leader_ad')) { ?>
		<div id="leader-wrapper">
			<div id="leaderboard">	
				<div id="leader-left">
					<?php echo get_option('mm_leader_ad'); ?>
				</div><!--leader-left-->
			</div><!--leaderboard-->
		</div><!--leader-wrapper-->
		<?php } ?>
	</div><!--top-wrapper-->
	<div id="nav">
		<div id="main-nav-wrapper">
			<div id="main-nav">
				<?php wp_nav_menu(array('theme_location' => 'main-menu')); ?>
			</div><!--main-nav-->
			<?php include_once( ABSPATH . 'wp-admin/includes/plugin.php' ); ?>
			<?php if (is_plugin_active('menufication/menufication.php')) { ?>
			<?php } else { ?>
				<div id="nav-mobi">
					<?php wp_nav_menu(array( 'theme_location' => 'main-menu', 'items_wrap' => '<select><option value="#">Menu</option>%3$s</select>', 'walker' => new select_menu_walker() )); ?>
				</div><!--nav-mobi-->
			<?php } ?>
		</div><!--main-nav-wrapper-->
	</div><!--nav-->
	<div id="wrapper">
		<?php if(get_option('mm_wall_ad')) { ?>
		<div id="wallpaper">
			<?php if(get_option('mm_wall_url')) { ?>
			<a href="<?php echo get_option('mm_wall_url'); ?>" class="wallpaper-link"></a>
			<?php } ?>
		</div><!--wallpaper-->
		<?php } ?>
		<div id="inner-wrapper">
			<div id="content">
				<div id="main-header-wrapper">
					<div id="header">
						<div id="logo" itemscope itemtype="http://schema.org/Organization">
							<?php if(get_option('mm_logo')) { ?>
							<a itemprop="url" href="<?php echo home_url(); ?>"><img itemprop="logo" src="<?php echo get_option('mm_logo'); ?>" alt="<?php bloginfo( 'name' ); ?>" /></a>
							<?php } else { ?>
							<a itemprop="url" href="<?php echo home_url(); ?>"><img itemprop="logo" src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="<?php bloginfo( 'name' ); ?>" /></a>
							<?php } ?>
						</div><!--logo-->
					</div><!--header-->
				</div><!--main-header-wrapper-->
				<div id="content-top">
					<div id="ticker">
						<span class="ticker-heading"><?php _e( "Don't Miss", 'mvp-text' ); ?></span>
						<ul class="ticker-list">
							<?php $recent = new WP_Query(array( 'tag' => get_option('mm_ticker_tags'), 'showposts' => get_option('mm_ticker_num') )); while($recent->have_posts()) : $recent->the_post();?>
							<li><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></li>
							<?php endwhile; ?>
						</ul>
					</div><!--ticker-->
					<div id="content-social">
							<ul>
							<?php if(get_option('mm_facebook')) { ?>
							<li><a href="http://www.facebook.com/<?php echo get_option('mm_facebook'); ?>" alt="Facebook" class="fb-but" target="_blank"></a></li><?php } ?>
							<?php if(get_option('mm_twitter')) { ?><li><a href="http://www.twitter.com/<?php echo get_option('mm_twitter'); ?>" alt="Twitter" class="twitter-but" target="_blank"></a></li><?php } ?>
							<?php if(get_option('mm_pinterest')) { ?><li><a href="http://www.pinterest.com/<?php echo get_option('mm_pinterest'); ?>" alt="Pinterest" class="pinterest-but" target="_blank"></a></li><?php } ?>
							<?php if(get_option('mm_instagram')) { ?><li><a href="http://www.instagram.com/<?php echo get_option('mm_instagram'); ?>" alt="Instagram" class="instagram-but" target="_blank"></a></li><?php } ?>
							<?php if(get_option('mm_google')) { ?><li><a href="<?php echo get_option('mm_google'); ?>" alt="Google Plus" class="google-but" target="_blank"></a></li><?php } ?>
							<?php if(get_option('mm_youtube')) { ?><li><a href="http://www.youtube.com/user/<?php echo get_option('mm_youtube'); ?>" alt="YouTube" class="youtube-but" target="_blank"></a></li><?php } ?>
							<?php if(get_option('mm_linkedin')) { ?><li><a href="http://www.linkedin.com/company/<?php echo get_option('mm_linkedin'); ?>" alt="Linkedin" class="linkedin-but" target="_blank"></a></li><?php } ?>
							<li><a href="<?php bloginfo('rss_url'); ?>" alt="RSS Feed" class="rss-but"></a></li>
						</ul>
					</div><!--content-social-->
				</div><!--content-top-->