<?php
	$yes_no = array(
				__("Yes", "mango_core")=>"yes",
				__("No", "mango_core")=>"no"
    );
	add_action( "init", "mango_vc_shortcodes" );
	function mango_vc_shortcodes() {
				global $yes_no;
				vc_map( array(
							"name" => __("Button", "mango_core"),
							"base" => "mango_button",
							"class" => "wpb_mango",
							"category" => __("Mango", "mango_core"),
							"params" => array(
											array(
												"type" => "dropdown",            
												"class" => "",
												"heading" => __("Button Type", "mango_core"),
												"param_name" => "button_type",
												"admin_label" => true,
												"value" => array(
												__("Button", "mango_core") => "button",
												__("link", "mango_core") => "link"
												)
											),
											
											array(
													"type" => "href",            
													"class" => "",
													"heading" => __("Button Link", "mango_core"),
													"param_name" => "btn_link",
													"value" => "",
													"dependency" => array(
													"element"=>"button_type",
													"value" => "link"
													)
												),
												array(
													"type" => "dropdown",            
													"class" => "",
													"heading" => __("Button Size", "mango_core"),
													"param_name" => "btn_size",
													"value" => array(
													__("Extra Small", "mango_core") => "xs",
													__("Small", "mango_core") => "sm",
													__("Medium", "mango_core") => "md",
													__("Learge", "mango_core") => "lg"
													)
												),
												array(
													"type" => "dropdown",            
													"class" => "",
													"heading" => __("Button Min Width", "mango_core"),
													"param_name" => "btn_min_width",
													"value" => array(
																	__("Extra Small", "mango_core") => "xs",
																	__("Small", "mango_core") => "sm",
																	__("Medium", "mango_core") => "md",
																	__("Large", "mango_core") => "lg"
															)
													),
												array(
													"type" => "dropdown",            
													"class" => "",
													"heading" => __("Button Style", "mango_core"),
													"param_name" => "btn_style",
													"value" => array(
													__("White", "mango_core") => "white",
													__("Theme Default", "mango_core") => "custom"
													)
												),
												array(
													"type" => "textfield",            
													"class" => "",
													"heading" => __("Button Text", "mango_core"),
													"param_name" => "content",
													"value" => ""
												),
												
												array(
													"type" => "dropdown",
													"class" => "",
													"heading" => __("Open Link In", "mango_core"),
													"param_name" => "btn_target",
													"value" => array(
													__("New Window", "mango_core") => "_blank",
													__("Same Window", "mango_core") => "_self"
													),
													"dependency" => array(
													"element"=>"button_type",
													"value" => "link"
													)
												)
		)
   )
);

  $taxonomy = 'product_cat';
  $orderby = 'name';       // name , id
  $show_count = 0;         // 1 for yes, 0 for no
  $pad_counts = 0;         // 1 for yes, 0 for no
  $hierarchical = 1;       // 1 for yes, 0 for no
  $title = '';
  $empty = 0;
  $args = array (
  'taxonomy' => $taxonomy,
  'orderby' => $orderby,
  'show_count' => $show_count,
  'pad_counts' => $pad_counts,
  'hierarchical' => $hierarchical,
  'title_li' => $title,
  'hide_empty' => $empty
  );
if ( class_exists( 'WooCommerce' ) ) {
   $all_categories = get_categories ( $args );
	$product = array ();
	foreach ( $all_categories as $key => $value ){
	
		$product[$value->name]=$value->name; 

	}
}
	
  vc_map( array(
  "name" => __("Woo Product Slider", "mango_core"),
  "base" => "mango_woo_product",
  "class" => "wpb_mango",
  "category" => __("Mango", "mango_core"),
  "params" => array(
     array(
        "type" => "dropdown",            
        "class" => "",
        "heading" => __("Style", "mango_core"),
        "param_name" => "product_style",
        "admin_label" => true,
        "value" => array(
        __("Style 1", "mango_core") => "style1",
        __("Style 2", "mango_core") => "style2"
        ),
     ),
     array(
      "type" => "textfield",            
      "class" => "",
      "heading" => __("How Much Product To Show", "mango_core"),
      "param_name" => "show_product",
      "value" => "-1"
     ),
	 /*
     array (
      "type" => "checkbox",
      "holder" => "div",
      "class" => "",
      "heading" => __ ( "Filter By Category", 'mango_core' ),
      "param_name" => "product_cats",
	  "value" => $product
      ),
      */
     array(
        "type" => "dropdown",            
        "class" => "",
        "heading" => __("Show Per Column", "mango_core"),
        "param_name" => "post_per_column_style1",
        "value" => array(
        __("1 Per Column", "mango_core") => 1,
        __("2 Per Column", "mango_core") => 2,
        __("3 Per Column", "mango_core") => 3,
        __("4 Per Column", "mango_core") => 4,
        __("5 Per Column", "mango_core") => 5,
	    __("6 Per Column", "mango_core") => 6,
        ),

        "dependency" => array(
         "element"=>"product_style",
         "value" => "style1"
        )
     ),
     array(
        "type" => "dropdown",            
        "class" => "",
        "heading" => __("Show Per Column For Desktop", "mango_core"),
        "param_name" => "per_column_desktop",
        "value" => array(
        __("1 Per Column", "mango_core") => 1,
        __("2 Per Column", "mango_core") => 2,
        __("3 Per Column", "mango_core") => 3,
        __("4 Per Column", "mango_core") => 4,
        __("5 Per Column", "mango_core") => 5,
		__("6 Per Column", "mango_core") => 6,
        ),

        "dependency" => array(
        "element"=>"product_style",
        "value" => "style2"
        )
     ),
	 
	 array(
     "type" => "dropdown",            
     "class" => "",
     "heading" => __("Text Align", "mango_core"),		
	"param_name" => "textalign",
    "value" => array(
	     __("Text Center", "mango_core") => '',
         __("Text Left", "mango_core") => 'text-left',  
        ),
        "dependency" => array(
        "element"=>"product_style",
         "value" => "style2"
        )
     ),
     array(
        "type" => "dropdown",            
        "class" => "",
        "heading" => __("Show Category With Products", "mango_core"),
        "param_name" => "show_cat",
        "value" => $yes_no
     ),
     array(
        "type" => "dropdown",            
        "class" => "",
        "heading" => __("Show Rating With Products", "mango_core"),
        "param_name" => "show_rating",
        "value" => $yes_no
     ),
	  array(
        "type" => "dropdown",            
        "class" => "",
        "heading" => __("Select Type", "mango_core"),
        "param_name" => "selecttype",
        "value" => array(
       __("New Arrival", "mango_core") => 'default',
       __("Popular", "mango_core") => 'selling',
       __("Featured", "mango_core") => 'featured',
     )),
     array(
        "type" => "dropdown",            
        "class" => "",
        "heading" => __("Show Price With Products", "mango_core"),
        "param_name" => "show_price",
        "value" => $yes_no
     )
	)
	)
	);

		
// Mango Flipbook
vc_map ( array (
    "name" => __ ( "Mango Flipbook", 'mango_core' ),
    "base" => "mango_flipbook",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "admin_enqueue_css" => array ( plugins_url ( 'assets/vc_extend_admin.css', __FILE__ ) ), // This will load css file in the VC backend editor
    "params" => array (
      
        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title", 'mango_core' ),
            "param_name" => "title"
        ),

		 array(
        "type" => "dropdown",            
        "class" => "",
        "heading" => __("Select Title Alignment", "mango_core"),
        "param_name" => "select_alignment",
        "value" => array(
        __("left", "mango_core") ,
        __("center", "mango_core"), 
        __("right", "mango_core") 
        
        )
     ),
   
    array (
            "type" => "number",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Product Number", 'mango_core' ),
            "param_name" => "number",
			"value" => "2"
    ),
    /*
    array(
      "type" => "dropdown",
      "holder" => "div",
      "class" => "",
      "heading" => __ ( "Filter By Category", 'mango_core' ),
      "param_name" => "product_cats",
	 "value" => $product
      
    ),
    */
    )
)
 );

}

// include vc custom row for mango section
require_once("mango_custom_row.php");
?>