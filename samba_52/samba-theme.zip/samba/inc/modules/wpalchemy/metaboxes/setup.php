<?php
include_once (TEMPLATEPATH . '/inc/modules/wpalchemy/MetaBox.php');
/* eof */