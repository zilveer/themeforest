<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

function multipurpose_products_slider($attr, $content = null) {
	extract(shortcode_atts(array('cat' => false), $attr));

	global $woocommerce_loop;
	if($cat) {
		$args = array(
			'post_type' => 'product',
			'post_status' => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page' => 12,
			'tax_query' => array(
			    array(
			      'taxonomy' => 'product_cat',
			      'field' => 'id',
			      'terms' => $cat
			    )
			)
		);
	} else {
		$args = array(
			'post_type' => 'product',
			'post_status' => 'publish',
			'ignore_sticky_posts' => 1
		);
	}

	$products = new WP_Query($args);
	
	ob_start();
    if ( $products->have_posts() ) : ?>     
	    <section class="columns related-products content-slider">
			<h2 class="underline"><span><?php _e('Products', 'multipurpose'); ?></span></h2>
			<div class="slider-box"><div>
				<?php while ( $products->have_posts() ) : $products->the_post(); ?><?php woocommerce_get_template_part( 'content', 'product-slider-item' ); ?><?php endwhile; // end of the loop. ?>
			</div></div>
		</section>
    <?php endif;
    wp_reset_postdata();

    return ob_get_clean();
}

function multipurpose_woocommerce_shortcodes() {
	add_shortcode('products_slider', 'multipurpose_products_slider');
}

add_action( 'init', 'multipurpose_woocommerce_shortcodes');