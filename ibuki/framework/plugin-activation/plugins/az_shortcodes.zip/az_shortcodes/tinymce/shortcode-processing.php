<?php

/*-----------------------------------------------------------------------------------*/
/*	Elements
/*-----------------------------------------------------------------------------------*/

// Blank Divider
function az_blank_divider_sh($atts, $content = null) {  
    extract(shortcode_atts(array("height_value" => '', "class" => ''), $atts));
	
	if($class)
	$class = ' '.esc_attr($class);
	
	$height_value = ' style="height: '.$height_value.'px;"';
	
	return '<div class="blank_divider'.$class.'"'.$height_value.'></div>';
}
add_shortcode('az_blank_divider_sh', 'az_blank_divider_sh');

// Divider
function az_divider_sh($atts, $content = null) {  
    extract(shortcode_atts(array("div_style" => '', "div_type" => '', "custom_color" => '', "class" => '', "margin_top_value" => '', "margin_bottom_value" => ''), $atts));
	
	if($class)
	$class = ' '.esc_attr($class);
	
	if ( $div_style=="short") { $div_style = ' short'; }
	
	if(!empty($margin_top_value)) { $margin_top_value = 'margin-top: '.$margin_top_value.'px;'; }
	if(!empty($margin_bottom_value)) { $margin_bottom_value = 'margin-bottom: '.$margin_bottom_value.'px;'; }
	if(!empty($custom_color)) { $custom_color = 'border-color: '.$custom_color.''; }
	
	return '<div class="divider'.$class.' '.$div_style.' '.$div_type.'" style="'.$margin_top_value.$margin_bottom_value.$custom_color.'"></div>';
}
add_shortcode('az_divider_sh', 'az_divider_sh');

// Accordion
function az_accordions($atts, $content = null){
	return '<div class="accordions">'.do_shortcode( $content ).'</div>';
}

add_shortcode('az_accordion_section', 'az_accordions');

function az_accordion($atts, $content){
	extract(shortcode_atts(array( 'title' => '%d', 'id' => '%d'), $atts));
	
	return '<div class="accordion"><h3>'. $title .'</h3><div class="accordion-content"><p>' . do_shortcode($content) . '</p></div></div>';
}

add_shortcode( 'accordion', 'az_accordion' );

// Toggle
function az_toggles($atts, $content = null){
	return '<div class="toggles">'.do_shortcode( $content ).'</div>';
}

add_shortcode('az_toggle_section', 'az_toggles');

function az_toggle($atts, $content){
	extract(shortcode_atts(array( 'title' => '%d', 'id' => '%d'), $atts));
	
	return '<div class="toggle"><h3>'. $title .'</h3><div class="toggle-content"><p>' . do_shortcode($content) . '</p></div></div>';
}

add_shortcode( 'toggle', 'az_toggle' );

// Tabs
function az_tabs($atts, $content = null){

	$tab_id = uniqid();

	$return = '<div class="tabbable"><ul id="myTab-'.$tab_id.'" class="nav nav-tabs nav-justified">';
	$GLOBALS['tabs'] = 'nav';
	$return .= wpb_js_remove_wpautop($content);
	$return .= '</ul>';
	$GLOBALS['tabs'] = 'content';
	$return .= '<div class="tab-content">';
	$return .= wpb_js_remove_wpautop($content, true);
	$return .= '</div>';
	$return .= '</div>';

	return $return;
}
add_shortcode('az_tab_section', 'az_tabs');


function az_tab($atts, $content){
	extract(shortcode_atts(array( 'title' => '%d'), $atts));
	if($GLOBALS['tabs'] == 'nav'){
		$tab_id = uniqid();
		$return = '<li><a href="#tab-'.$tab_id.'" data-toggle="tab">'.($title).'</a></li>';
	}
	else{
		$return = '<div class="tab-pane fade in"><p>'.do_shortcode( $content ).'</p></div>';
	}
	return $return;
}

add_shortcode( 'tab', 'az_tab' );

// Testimonial Slider
function az_testimonials($atts, $content = null){
	$return = '
		<div class="az-testimonials flexslider">
			<div class="az-testimonials-container">
				<div class="testimonial">
					<ul class="slides">'.wpb_js_remove_wpautop($content).'</ul>
				</div>
			</div>
		</div>
	';

	return $return;	
}
add_shortcode('az_testimonial_section', 'az_testimonials');

function az_testimonial($atts, $content){
	extract(shortcode_atts(array( 'image' => '%d', 'title' => '%d', 'id' => '%d'), $atts));
	
	if(!empty($image)) {
		$img_output = '<img class="az-testimonial-image" src="'.$image.'" alt="'.$title.'" />';
	} else {
		$img_output = '';
	}

	$return = '<li> 
					'.$img_output.'
					<p class="az-testimonial-quote">'.$content.'</p>
					<span class="az-testimonial-source">'.$title.'</span>
			   </li>';
	return $return;
}
add_shortcode( 'testimonial', 'az_testimonial' );

// Alert Box
function az_alert($atts, $content = null) {  
    extract(shortcode_atts(array("mode" => 'standard', "class" => ''), $atts));
	
	if($class)
	$class = ' '.esc_attr($class);
	
	switch ($mode) {
		case 'standard' :
			$alert_mode = '<div class="alert alert-standard fade in'.$class.'"><a class="close" href="#" data-dismiss="alert"><i class="font-icon-cross"></i></a>'. do_shortcode($content) .'</div>';
			break;
		case 'warning' :
			$alert_mode = '<div class="alert fade in'.$class.'"><a class="close" href="#" data-dismiss="alert"><i class="font-icon-cross"></i></a>'. do_shortcode($content) .'</div>';
			break;
		case 'error' :
			$alert_mode = '<div class="alert alert-error fade in'.$class.'"><a class="close" href="#" data-dismiss="alert"><i class="font-icon-cross"></i></a>'. do_shortcode($content) .'</div>';
			break;
		case 'info' :
			$alert_mode = '<div class="alert alert-info fade in'.$class.'"><a class="close" href="#" data-dismiss="alert"><i class="font-icon-cross"></i></a>'. do_shortcode($content) .'</div>';
			break;
		case 'success' :
			$alert_mode = '<div class="alert alert-success fade in'.$class.'"><a class="close" href="#" data-dismiss="alert"><i class="font-icon-cross"></i></a>'. do_shortcode($content) .'</div>';
			break;	
	}
    return $alert_mode;
}
add_shortcode('az_alert_box_sh', 'az_alert');

// Tootltip
function az_tooltip($atts, $content = null) {  
    extract(shortcode_atts(array("mode" => 'top', "text" => 'Tooltip'), $atts));
	
	switch ($mode) {
		case 'top' :
			$tooltip_mode = '<a href="#" data-toggle="tooltip" data-original-title="'.$text.'" data-placement="top">'. do_shortcode($content) .'</a>';
			break;
		case 'left' :
			$tooltip_mode = '<a href="#" data-toggle="tooltip" data-original-title="'.$text.'" data-placement="left">'. do_shortcode($content) .'</a>';
			break;
		case 'right' :
			$tooltip_mode = '<a href="#" data-toggle="tooltip" data-original-title="'.$text.'" data-placement="right">'. do_shortcode($content) .'</a>';
			break;
		case 'bottom' :
			$tooltip_mode = '<a href="#" data-toggle="tooltip" data-original-title="'.$text.'" data-placement="bottom">'. do_shortcode($content) .'</a>';
			break;
	}
    return $tooltip_mode;
}
add_shortcode('az_tooltip', 'az_tooltip');

// Highlights
function az_highlight($atts, $content = null) {  
    extract(shortcode_atts(array("mode" => 'color-text'), $atts));
	
	switch ($mode) {
		case 'color-text' :
			$highlight_mode = '<span class="color-text">'. do_shortcode($content) .'</span>';
			break;
		case 'highlight-text' :
			$highlight_mode = '<span class="highlight-text">'. do_shortcode($content) .'</span>';
			break;
	}
    return $highlight_mode;
}
add_shortcode('az_highlight', 'az_highlight');

// DropCaps
function az_dropcap($atts, $content = null) {  
    extract(shortcode_atts(array("mode" => 'dropcap-normal'), $atts));
	
	switch ($mode) {
		case 'dropcap-normal' :
			$dropcap_mode = '<p><span class="dropcap">'. do_shortcode($content) .'</span>';
			break;
		case 'dropcap-color' :
			$dropcap_mode = '<p><span class="dropcap-color">'. do_shortcode($content) .'</span>';
			break;
	}
    return $dropcap_mode;
}
add_shortcode('az_dropcap', 'az_dropcap');

// Lightbox Image
/*
function az_lightbox_image_sh($atts, $content = null) {  
    extract(shortcode_atts(array('image_url' => '', 'image_popup_url' => '', 'thumb_width' => '', 'gallery_name' => '', 'class' => ''), $atts));
		
	if($class)
	$class = ' '.esc_attr($class);
	
	$output = null;
	
	$thumb_widht_to = (!empty($thumb_width) ? ' style="width: '.$thumb_width.'px; display: table-cell;"' : '');
	$thumb_display_to = (!empty($thumb_width) ? ' style="display: inline-block;"' : '');
	$thumb_width_img = (!empty($thumb_width) ? ' width='.$thumb_width.' ' : '');
	
	$fancy_gallery = (!empty($gallery_name) ? ' data-fancybox-group="'.$gallery_name.'" ' : '');

	$alt = ( get_post_meta($image_url, '_wp_attachment_image_alt', true) ) ? get_post_meta($image_url, '_wp_attachment_image_alt', true) : 'Insert Alt Text';

	$customFancyImg = (!empty($image_popup_url)) ? $image_popup_url : $image_url;
	
	$output .= '<div class="lightbox'.$class.'" '.$thumb_display_to.'>';
	$output .= '<a class="fancy-wrap fancybox-thumb" title="'.$alt.'" href="'.$customFancyImg.'" '.$fancy_gallery.$thumb_widht_to.'>';
	$output .= '<span class="overlay-bg-fancy"><i class="lightbox-icon fancy-image"></i></span>';
	$output .= '<img class="img-full-responsive" alt="'.$alt.'" src="'.$image_url.'" '.$thumb_width_img.' />';
	$output .= '</a>';
	$output .= '</div>';

	return $output;
	 
}
add_shortcode('az_lightbox_image_sh', 'az_lightbox_image_sh');
*/

// Lightbox Video
/*
function az_lightbox_video_sh($atts, $content = null) {  
    extract(shortcode_atts(array('image_url' => '', 'thumb_width' => '', 'link_url' => '', 'title' => '', 'gallery_name' => '', 'class' => ''), $atts));
		
	if($class)
	$class = ' '.esc_attr($class);
	
	$output = null;
	
	$thumb_widht_to = (!empty($thumb_width) ? ' style="width: '.$thumb_width.'px; display: table-cell;"' : '');
	$thumb_display_to = (!empty($thumb_width) ? ' style="display: inline-block;"' : '');
	$thumb_width_img = (!empty($thumb_width) ? ' width='.$thumb_width.' ' : '');
	
	$fancy_gallery = (!empty($gallery_name) ? ' data-fancybox-group="'.$gallery_name.'" ' : '');
			
	$output .= '<div class="lightbox'.$class.'" '.$thumb_display_to.'>';
	$output .= '<a class="fancy-wrap fancybox-media" title="'.$title.'" href="'.$link_url.'" '.$fancy_gallery.$thumb_widht_to.'>';
	$output .= '<span class="overlay-bg-fancy"><i class="lightbox-icon fancy-video"></i></span>';
	$output .= '<img class="img-full-responsive" alt="'.$title.'" src="'.$image_url.'" '.$thumb_width_img.' />';
	$output .= '</a>';
	$output .= '</div>';

	return $output;
	 
}
add_shortcode('az_lightbox_video_sh', 'az_lightbox_video_sh');
*/

// Button
/*
function az_button_sh($atts, $content = null) {  
    extract(shortcode_atts(array("buttonlabel" => '', "buttonalign" => '', "buttonlink" => '', "target" => '', "buttonsize" => '', "custom_color" => '', "inverted" => false, "icons" => '', "class" => ''), $atts));
	
	if($class)
	$class = ' '.esc_attr($class);
	
	$output = null;
	
	if ( $target == 'same' || $target == '_self' ) { $target = ''; }
	if ( $target != '' ) { $target = ' target="'.$target.'"'; }
	
	$icon_to = (!empty($icons) ? '<i class="'.$icons.'"></i>'  : '');
	
	$inverted_to = '';
	$buttonclass = null;
	if ($inverted==true) {
		$inverted_to = ' inverted';
		if( !empty($custom_color)) {
			$custom_color = ' style="background-color: '.$custom_color.'; border-color: '.$custom_color.';"';
			$buttonclass = ' custom-button-color'; 
		}
	} else {
		if( !empty($custom_color)) {
			$custom_color = ' style="background-color: '.$custom_color.'; border-color: '.$custom_color.';"';
			$buttonclass = ' custom-button-color'; 
		}
	}
	
	if($buttonalign=="noalign") {
		$output .= '<a class="button-main '.$buttonsize.$inverted_to.$buttonclass.$class.'"'.$custom_color.' href="'.$buttonlink.'"'.$target.'>'.$icon_to.$buttonlabel.'</a>';
	} else {
		$output .= '<div class="position-btn '.$buttonalign.'"><a class="button-main '.$buttonsize.$inverted_to.$buttonclass.$class.'"'.$custom_color.' href="'.$buttonlink.'"'.$target.'>'.$icon_to.$buttonlabel.'</a></div>';
	}
	
	return $output;
}
add_shortcode('az_button_sh', 'az_button_sh');
*/

// Icons
/*
function az_icon_sh($atts, $content = null) {  
    extract(shortcode_atts(array("iconsize" => '', "iconalign" => '', "iconlink" => '', "target" => '', "custom_color" => '', "icons" => '', "class" => ''), $atts));
	
	if($class)
	$class = ' '.esc_attr($class);

	if ( $target == 'same' || $target == '_self' ) { $target = ''; }
	if ( $target != '' ) { $target = ' target="'.$target.'"'; }
	
	$output = null;
	$icon_custom_value = null;

	if (!empty($custom_color) && !empty($iconsize)) { $icon_custom_value = ' style="color:'.$custom_color.'; font-size:'.$iconsize.'px;"'; }
	else if (!empty($iconsize)) { $icon_custom_value = ' style="font-size:'.$iconsize.'px;"'; }

	$icon_output = $icons;

	if (!empty($iconlink)) {
		$output .= '<a class="icon-sh" href="'.$iconlink.'" '.$target.'>';
		$output .= '<span class="icon-shortcode"><i class="'.$icon_output.' '.$iconalign.$class.'"'.$icon_custom_value.'></i></span>';
		$output .= '</a>';
	} else {
		$output .= '<span class="icon-shortcode"><i class="'.$icon_output.' '.$iconalign.$class.'"'.$icon_custom_value.'></i></span>';
	}

	return $output;
}
add_shortcode('az_icon_sh', 'az_icon_sh');
*/

// Social Share Buttons
/*
function az_social_share_sh($atts, $content = null) {
	extract(shortcode_atts(array("facebook" => 'false', "twitter" => 'false', "google_plus" => 'false', "pinterest" => 'false'), $atts));  
    
    global $post;
    $buttons = null;

	$buttons .= '<div class="az-social-share">';
	
	if($facebook == 'true'){
    	$buttons .= '<a href="#" id="share-facebook" class="share-btn">Facebook</a>';
    }
	
	if($twitter == 'true'){
    	$buttons .= '<a href="#" id="share-twitter" class="share-btn">Twitter</a>';
    }
	
	if($google_plus == 'true'){
    	$buttons .= '<a href="#" id="share-google" class="share-btn">Google +</a>';
    }

	if($pinterest == 'true'){
		$buttons .= '<a href="#" id="share-pinterest" class="share-btn">Pinterest</a>';
    }
	
	$buttons .= '</div>';
	
    return $buttons;
}
add_shortcode('az_social_share', 'az_social_share_sh');
*/

// Revolution Slider
function az_rev_slider( $atts, $content = null ) {
    extract(shortcode_atts(array("class" => '', "alias" => ''), $atts));
	
	$rev_markup = null;
	
	if($class)
	$class = ' '.esc_attr($class);

	$rev_markup .= '<div class="revolution_slider_container'.$class.'">';
	$rev_markup .= do_shortcode('[rev_slider '.$alias.']');
	$rev_markup .= '</div>';
	
	return $rev_markup;
}
add_shortcode('az_rev_slider', 'az_rev_slider');

// Video Embed
function az_shortcode_video_embed( $atts, $content = null ) {
    extract(shortcode_atts(array("class" => '', "link" => ''), $atts));
	
	$video_embed_markup = null;
	
	if($class)
	$class = ' '.esc_attr($class);
	
	if ( $link == '' ) { return null; }
	
	global $wp_embed;
    $embed = $wp_embed->run_shortcode('[embed]'.$link.'[/embed]');

	$video_embed_markup .= '<div class="videoWrapper'.$class.'">' . $embed . '</div>';
	
	return $video_embed_markup;
}
add_shortcode('az_video_embed', 'az_shortcode_video_embed');


// Video Self Hosted
function az_shortcode_video($atts, $content = null) {
	extract(shortcode_atts(array("class" => '', "title" => 'Title', 'webm_url' => null, 'mp4_url' => null, 'ogv_url' => null, 'image_url' => null), $atts));  
	$video_markup = null;
		
		if($class)
		$class = ' '.esc_attr($class);
	
		$id = rand();
		$id = $id*rand(1,50);
		
		$video_markup .= '<div class="video-container'.$class.'">
						    <video id="video-'.$id.'" class="video-js vjs-default-skin" preload="auto" style="width:100%; height:100%;" poster="'. $image_url .'">';
					 			if(!empty($webm_url)) { $video_markup .= '<source type="video/webm" src="'.$webm_url.'">'; }
                                if(!empty($mp4_url)) { $video_markup .= '<source type="video/mp4" src="'.$mp4_url.'">'; }
                                if(!empty($ogv_url)) { $video_markup .= '<source type="video/ogg" src="'.$ogv_url.'">'; }
		$video_markup .= '  </video>
						  </div>';
	
    return $video_markup;
	
}

add_shortcode('az_video', 'az_shortcode_video');

// Audio Self Hosted
function az_shortcode_audio($atts, $content = null) {
	extract(shortcode_atts(array("class" => '', "title" => 'Title', 'mp3_url' => null), $atts));  
	$audio_markup = null;
	
	$id = rand();
	$id = $id*rand(1,50);
	
	$audio_markup .= 
		'<div class="audio-container'.$class.'">
			<div id="audio-'.$id.'">
				<audio style="width:100%; height:30px;" class="audio-js" controls="control" preload src="'. $mp3_url .'"></audio>
			</div>
		</div>';
	
    return $audio_markup;
}

add_shortcode('az_audio', 'az_shortcode_audio');

?>