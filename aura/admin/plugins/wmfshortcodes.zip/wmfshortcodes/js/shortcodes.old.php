<?php header('Content-type: text/javascript');?>
<?php //Setup location of WordPress
$absolute_path = __FILE__;
$path_to_file = explode( 'wp-content', $absolute_path );
$path_to_wp = $path_to_file[0];
//Access WordPress
require_once( $path_to_wp.'/wp-load.php' );
?>
//Mobile Detect
(function() {
    tinymce.create('tinymce.plugins.webbushort_mdetect', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_mdetect':
                var c = cm.createSplitButton('webbushort_mdetect', {
                    title : '<?php echo __('Mobile Detect','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px"><label><?php echo __('Select Option','wmft2d') ?><br/>\
						<select name="dtype">\
                        <option value="notphone"><?php echo __('Only Show Desktops & Tablets','wmft2d') ?></option>\
                        <option value="nottablet"><?php echo __('Only Show Desktops & Phones','wmft2d') ?></option>\
                        <option value="notmobile"><?php echo __('Only Show Desktops','wmft2d') ?></option>\
                        <option value="phone"><?php echo __('Only Show Phones','wmft2d') ?></option>\
                        <option value="tablet"><?php echo __('Only Show Tablets','wmft2d') ?></option>\
                        <option value="mobile"><?php echo __('Only Show Phones & Tablets','wmft2d') ?></option>\
                        <option value="ios"><?php echo __('Only Show iOS Devices','wmft2d') ?></option>\
                        <option value="android"><?php echo __('Only Show Android Devices','wmft2d') ?></option>\
                        <option value="wm"><?php echo __('Only Show WM Devices','wmft2d') ?></option>\
                        <option value="iPhone"><?php echo __('Only Show iPhone','wmft2d') ?></option>\
                        <option value="iPad"><?php echo __('Only Show iPad','wmft2d') ?></option>\
                        <option value="Samsung"><?php echo __('Only Show Samsung','wmft2d') ?></option>\
                        <option value="BlackBerry"><?php echo __('Only Show BlackBerry','wmft2d') ?></option>\
                        </select></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
									var dtype = $menu.find('select[name=dtype]').val();
									if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
									 tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_detect type="'+dtype+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_detect]');
									}else{
									 tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_detect type="'+dtype+'"]<?php echo __('Code goes here...','wmft2d') ?>[/wmf_detect]'); 
									}
					
					
                                    
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                    m.add({title : '<?php echo __('Mobile Detect','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_mdetect', tinymce.plugins.webbushort_mdetect);
})();


//Seperator
(function() {
    tinymce.create('tinymce.plugins.webbushort_sp', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_sp':
                var c = cm.createSplitButton('webbushort_sp', {
                    title : '<?php echo __('Seperator','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px"><label><?php echo __('Align','wmft2d') ?><br/>\
						<select name="align">\
                        <option value="left"><?php echo __('Left','wmft2d') ?></option>\
                        <option value="center"><?php echo __('Center','wmft2d') ?></option>\
						<option value="right"><?php echo __('Right','wmft2d') ?></option>\
                        </select></label>\
                        <label><?php echo __('Size','wmft2d') ?><br/>\
						<input type="text" size="6" id="size" name="size" value="16" onclick="this.select()" /></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
									var title = $menu.find('input[name=title]').val();
									var align = $menu.find('select[name=align]').val();
                                    var size = $menu.find('input[name=size]').val();
									if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
									 tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_sp align="'+align.toLowerCase()+'" size="'+size.toLowerCase()+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_sp]');
									}else{
									 tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_sp align="'+align.toLowerCase()+'" size="'+size.toLowerCase()+'"]<?php echo __('Title(Optional)','wmft2d') ?>[/wmf_sp]'); 
									}
					
					
                                    
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                    m.add({title : '<?php echo __('Seperator','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_sp', tinymce.plugins.webbushort_sp);
})();


// FontIcon
(function() {
    tinymce.create('tinymce.plugins.webbushort_fonticon', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_fonticon':
                var c = cm.createSplitButton('webbushort_fonticon', {
                    title : '<?php echo __('Font Icon','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px"><label><?php echo __('BG Color','wmft2d') ?><br/>\
                        <input type="text" maxlength="6" size="6" id="colorpickerField1" name="colorpickerField1" value="#000000" onclick="this.select()" /></label>\
						<label><?php echo __('Size','wmft2d') ?><br/>\
                        <input type="text" maxlength="6" size="6" id="size" name="size" value="24" onclick="this.select()" /></label>\
						<label><?php echo __('Icon Name','wmft2d') ?><br/>\
                        <input type="text" size="6" id="icon" name="icon" value="icon-heart" onclick="this.select()" /></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                    var colorpickerField1 = $menu.find('input[name=colorpickerField1]').val();
									var size = $menu.find('input[name=size]').val();
									var icon = $menu.find('input[name=icon]').val();
									tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_fonticon color="'+colorpickerField1.toLowerCase()+'" size="'+size.toLowerCase()+'" icon="'+icon.toLowerCase()+'"][/wmf_fonticon]'); 
									
					
					
                                    
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                    m.add({title : '<?php echo __('Font Icon','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_fonticon', tinymce.plugins.webbushort_fonticon);
})();


// Dropcap
(function() {
    tinymce.create('tinymce.plugins.webbushort_dropcap', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_dropcap':
                var c = cm.createButton('webbushort_dropcap', {
                    title : '<?php echo __('Dropcap Config','wmft2d') ?>',
                    onclick : function() {
                        tb_show('<?php echo __('Dropcap Config','wmft2d') ?>', '../wp-content/plugins/wmfshortcodes/js/dropcap.html?TB_iframe=true'); 
						(function($) {
 						 "use strict";
							var TB_WIDTH = 490,
								TB_HEIGHT = 370; 
							$("#TB_window").animate({
								marginLeft: '-' + parseInt((TB_WIDTH / 2), 10) + 'px',
								width: TB_WIDTH + 'px',
								height: TB_HEIGHT + 'px',
								
							});
							
							$("#TB_window iframe").animate({
								width: TB_WIDTH + 'px',
								height: TB_HEIGHT + 'px',
							});
						})(jQuery); 
                    }
                });

                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_dropcap', tinymce.plugins.webbushort_dropcap);
})();


// Highlight
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.webbushort_highlight', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_highlight':
                var c = cm.createButton('webbushort_highlight', {
                    title : '<?php echo __('Highlight Color','wmft2d') ?>',
                    onclick : function() {
                        tb_show('<?php echo __('Highlight Color','wmft2d') ?>', '../wp-content/plugins/wmfshortcodes/js/highlight.html?TB_iframe=true'); 
						(function($) {
 						 "use strict";
							var TB_WIDTH = 490,
								TB_HEIGHT = 340; // set the new width and height dimensions here..
							$("#TB_window").animate({
								marginLeft: '-' + parseInt((TB_WIDTH / 2), 10) + 'px',
								width: TB_WIDTH + 'px',
								height: TB_HEIGHT + 'px',
								
							});
							
							$("#TB_window iframe").animate({
								width: TB_WIDTH + 'px',
								height: TB_HEIGHT + 'px',
							});
						})(jQuery); 
                    }
                });

        
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_highlight', tinymce.plugins.webbushort_highlight);
})();


//Notifications
(function() {
    tinymce.create('tinymce.plugins.webbushort_notifications', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_notifications':
                var c = cm.createSplitButton('webbushort_notifications', {
                    title : '<?php echo __('Notifications','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px"><label><?php echo __('Color','wmft2d') ?><br/>\
                        <select name="style">\
                        <option value="wmfalert-info" selected> <?php echo __('Light Blue','wmft2d') ?></option>\
                        <option value="wmfalert-success"> <?php echo __('Green','wmft2d') ?></option>\
                        <option value="wmfalert-warning"> <?php echo __('Yellow','wmft2d') ?></option>\
                        <option value="wmfalert-danger"> <?php echo __('Red','wmft2d') ?></option>\
                        </select></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                    var style = $menu.find('select[name=style]').val();
									
									if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
									 tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_notify style="'+style.toLowerCase()+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_notify]');
									}else{
									 tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_notify style="'+style.toLowerCase()+'"]<?php echo __('Alert text goes here.','wmft2d') ?>[/wmf_notify]'); 
									}
					
					
                                    
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                    m.add({title : '<?php echo __('Notifications','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_notifications', tinymce.plugins.webbushort_notifications);
})();


// Collapse
(function() {
	"use strict";
    tinymce.create('tinymce.plugins.webbushort_collapse', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_collapse':
                var c = cm.createSplitButton('webbushort_collapse', {
                    title : '<?php echo __('Collapse','wmft2d') ?>',
                    onclick : function() {
					
                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
                        <label><?php echo __('Number of items','wmft2d') ?><br />\
                        <input type="text" name="itemnum" value="2" onclick="this.select()"  /></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                
                                var shortcode = '[wmf_toggles]<br class="ws"/>';
                                var num = $menu.find('input[name=itemnum]').val();
								var i;
                                    for(i=0;i<num;i++){
                                        shortcode += '[wmf_toggle title="Title"]';
                                        shortcode += '<?php echo __('Collapse content goes here.','wmft2d') ?>';
                                        shortcode += '[/wmf_toggle]<br class="ws"/>';
                                    }

                                shortcode+= '[/wmf_toggles]';

                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

					m.add({title : '<?php echo __('Collapse','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_collapse', tinymce.plugins.webbushort_collapse);
})();


// Tabs
(function() {
	"use strict";
    tinymce.create('tinymce.plugins.webbushort_tabs', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_tabs':
                var c = cm.createSplitButton('webbushort_tabs', {
                    title : '<?php echo __('Tabs','wmft2d') ?>',
                    onclick : function() {
					
                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
                        <label><?php echo __('Number of tab','wmft2d') ?><br />\
                        <input type="text" name="tabnum" value="2" onclick="this.select()"  /></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                
                                var shortcode = '[wmf_tabs]<br class="ws"/>';
                                var num = $menu.find('input[name=tabnum]').val();
								var k;
                                    for(k=0;k<num;k++){
                                        shortcode += '[wmf_tab title="Title"]';
                                        shortcode += '<?php echo __('Tab content goes here.','wmft2d') ?>';
                                        shortcode += '[/wmf_tab]<br class="ws"/>';
                                    }

                                shortcode+= '[/wmf_tabs]';

                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
					m.add({title : '<?php echo __('Tabs','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_tabs', tinymce.plugins.webbushort_tabs);
})();


//Buttons
(function() {
    tinymce.create('tinymce.plugins.webbushort_button', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_button':
                var c = cm.createSplitButton('webbushort_button', {
                    title : '<?php echo __('Buttons','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Button Text','wmft2d') ?><br />\
                        <input type="text" name="btext" value="<?php echo __('Button','wmft2d') ?>" onclick="this.select()" /></label>\
                        <label><?php echo __('URL','wmft2d') ?><br />\
                        <input type="text" name="link" value="#" onclick="this.select()" /></label>\
						<label><?php echo __('Size','wmft2d') ?><br/>\
                        <select name="size">\
                        <option value="wmfbtn-xs"><?php echo __('Mini','wmft2d') ?></option>\
                        <option value="wmfbtn-sm"><?php echo __('Small','wmft2d') ?></option>\
                        <option value="normal" selected><?php echo __('Normal','wmft2d') ?></option>\
                        <option value="wmfbtn-lg"><?php echo __('Large','wmft2d') ?></option>\
                        </select></label>\
                        <label><?php echo __('Types','wmft2d') ?><br/>\
                        <select name="type">\
                        <option value="wmfbtn-primary"> <?php echo __('Blue','wmft2d') ?></option>\
                        <option value="wmfbtn-info" selected> <?php echo __('Light Blue','wmft2d') ?></option>\
                        <option value="wmfbtn-success"> <?php echo __('Green','wmft2d') ?></option>\
                        <option value="wmfbtn-warning"> <?php echo __('Yellow','wmft2d') ?></option>\
                        <option value="wmfbtn-danger"> <?php echo __('Red','wmft2d') ?></option>\
                        <option value="wmfbtn-default"> <?php echo __('Transparent','wmft2d') ?></option>\
						<option value="wmfbtn-link"> <?php echo __('Link','wmft2d') ?></option>\
                        </select>\
						<label><?php echo __('Target','wmft2d') ?><br/>\
						<select name="target">\
						<option value="" selected> <?php echo __('Select','wmft2d') ?></option>\
                        <option value="_self"> _self</option>\
                        <option value="_blank"> _blank</option>\
                        <option value="_parent"> _parent</option>\
                        </select>\
						</label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                    var size = $menu.find('select[name=size]').val();
                                    var type = $menu.find('select[name=type]').val();
									var target = $menu.find('select[name=target]').val();
									var btext = $menu.find('input[name=btext]').val();
                                    var link = $menu.find('input[name=link]').val();
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_button size="'+size.toLowerCase()+'" color="'+type.toLowerCase()+'" target="'+target+'" url="'+link+'"]'+btext+'[/wmf_button]');
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
                    m.add({title : '<?php echo __('Buttons','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_button', tinymce.plugins.webbushort_button);
})();


//Buttong
(function() {
    tinymce.create('tinymce.plugins.webbushort_buttong', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_buttong':
                var c = cm.createSplitButton('webbushort_buttong', {
                    title : '<?php echo __('Button Group','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px"><label>Align<br/>\
                        <select name="align">\
                        <option value="left"><?php echo __('Left','wmft2d') ?></option>\
                        <option value="right"><?php echo __('Right','wmft2d') ?></option>\
                        <option value="center" selected><?php echo __('Center','wmft2d') ?></option>\
                        </select></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                    var align = $menu.find('select[name=align]').val();
									
									if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
									 tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_buttong align="'+align.toLowerCase()+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_buttong]');
									}else{
									 tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_buttong align="'+align.toLowerCase()+'"]<?php echo __('Button codes goes here.','wmft2d') ?>[/wmf_buttong]'); 
									}
					
					
                                    
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                    m.add({title : '<?php echo __('Button Group','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_buttong', tinymce.plugins.webbushort_buttong);
})();


//Labels & Badges
(function() {
    tinymce.create('tinymce.plugins.webbushort_lb', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_lb':
                var c = cm.createSplitButton('webbushort_lb', {
                    title : '<?php echo __('Labels & Badges','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Color','wmft2d') ?><br/>\
						<select name="color">\
                        <option value="default"><?php echo __('Grey','wmft2d') ?></option>\
                        <option value="primary"><?php echo __('Blue','wmft2d') ?></option>\
						<option value="success"><?php echo __('Green','wmft2d') ?></option>\
						<option value="info"><?php echo __('Light Blue','wmft2d') ?></option>\
						<option value="warning"><?php echo __('Yellow','wmft2d') ?></option>\
						<option value="danger"><?php echo __('Red','wmft2d') ?></option>\
                        </select>\
						<label><?php echo __('Type','wmft2d') ?><br/>\
						<select name="type">\
                        <option value="wmfbadge"><?php echo __('Badge','wmft2d') ?></option>\
                        <option value="label"><?php echo __('Label','wmft2d') ?></option>\
                        </select></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                    var color = $menu.find('select[name=color]').val();
									var type = $menu.find('select[name=type]').val();
									if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
									 tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_lb color="'+color.toLowerCase()+'" type="'+type.toLowerCase()+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_lb]');
									}else{
									 tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_lb color="'+color.toLowerCase()+'" type="'+type.toLowerCase()+'"]<?php echo __('Text goes here.','wmft2d') ?>[/wmf_lb]'); 
									}
					
					
                                    
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                    m.add({title : '<?php echo __('Labels & Badges','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_lb', tinymce.plugins.webbushort_lb);
})();


// Table
(function() {
    tinymce.create('tinymce.plugins.webbushort_table', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_table':
                var c = cm.createSplitButton('webbushort_table', {
                    title : '<?php echo __('Table','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px"><label><?php echo __('Type','wmft2d') ?><br/>\
                        <select name="type">\
                        <option value="striped"><?php echo __('Striped','wmft2d') ?></option>\
						<option value="bordered"><?php echo __('Bordered','wmft2d') ?></option>\
						<option value="hover"><?php echo __('Striped with Hover Effect','wmft2d') ?></option>\
						<option value="condensed"><?php echo __('Condensed','wmft2d') ?></option>\
                        </select></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                    var type = $menu.find('select[name=type]').val();
									
									 tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_table type="'+type.toLowerCase()+'" cols="#,First Name, Last Name, Username" data="1, Filip, Stefansson, filipstefansson, 2, Victor, Meyer, Pudge, 3, Mans, Ketola-Backe, mossboll"][/wmf_table]'); 
									
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                    m.add({title : '<?php echo __('Table','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_table', tinymce.plugins.webbushort_table);
})();


//Grid
(function() {
    tinymce.create('tinymce.plugins.webbushort_cl', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_cl':
                var c = cm.createSplitButton('webbushort_cl', {
                    title : '<?php echo __('Columns','wmft2d') ?>',
                    onclick : function() {
                    }
                });
				
                c.onRenderMenu.add(function(c, m) {
					m.add({title : '<?php echo __('Bootstrap Grid System','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);
                    m.add({title : '<img src="../wp-content/plugins/wmfshortcodes/js/icons/col9.png" style="vertical-align:middle;width:97px;height:16px;">  1/6 Columns', onclick : function() {
                        tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, '[wmf_row class="row"]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="1"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]' );
                    }});
					m.add({title : '<img src="../wp-content/plugins/wmfshortcodes/js/icons/col8.png" style="vertical-align:middle;" alt="">  3/4 - 1/4  <?php echo __('Columns','wmft2d') ?>', onclick : function() {
                        tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, '[wmf_row]<br class="ws"/>[wmf_col cls="9"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]' );
                    }});
					m.add({title : '<img src="../wp-content/plugins/wmfshortcodes/js/icons/col7.png" style="vertical-align:middle;" alt="">  1/4 - 3/4  <?php echo __('Columns','wmft2d') ?>', onclick : function() {
                        tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, '[wmf_row]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="9"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]' );
                    }});
					m.add({title : '<img src="../wp-content/plugins/wmfshortcodes/js/icons/col6.png" style="vertical-align:middle;" alt="">  2/3 - 1/3  <?php echo __('Columns','wmft2d') ?>', onclick : function() {
                        tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, '[wmf_row]<br class="ws"/>[wmf_col cls="8"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="4"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]' );
                    }});
					m.add({title : '<img src="../wp-content/plugins/wmfshortcodes/js/icons/col5.png" style="vertical-align:middle;" alt="">  1/3 - 2/3  <?php echo __('Columns','wmft2d') ?>', onclick : function() {
                        tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, '[wmf_row]<br class="ws"/>[wmf_col cls="4"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="8"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]' );
                    }});
					m.add({title : '<img src="../wp-content/plugins/wmfshortcodes/js/icons/col4.png" style="vertical-align:middle;" alt="">  4 <?php echo __('Columns','wmft2d') ?>', onclick : function() {
                        tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, '[wmf_row]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="3"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]' );
                    }});
                    m.add({title : '<img src="../wp-content/plugins/wmfshortcodes/js/icons/col3.png" style="vertical-align:middle;" alt="">  3 <?php echo __('Columns','wmft2d') ?>', onclick : function() {
                        tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, '[wmf_row]<br class="ws"/>[wmf_col cls="4" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="4" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="4" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]' );
                    }});
                    m.add({title : '<img src="../wp-content/plugins/wmfshortcodes/js/icons/col2.png" style="vertical-align:middle; width:97px;height:16px;" alt="">  2 <?php echo __('Columns','wmft2d') ?>', onclick : function() {
                        tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, '[wmf_row]<br class="ws"/>[wmf_col cls="6" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[wmf_col cls="6" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]' );
                    }}); 
                    m.add({title : '<img src="../wp-content/plugins/wmfshortcodes/js/icons/col1.png" style="vertical-align:middle;" alt="">  <?php echo __('Full Width','wmft2d') ?>', onclick : function() {
                        tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, '[wmf_row]<br class="ws"/>[wmf_col cls="12" mobile="off"]<?php echo __('Text or Code goes here...','wmft2d') ?>[/wmf_col]<br class="ws"/>[/wmf_row]' );
                    }});  
					
                });

                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_cl', tinymce.plugins.webbushort_cl);
})();


//Maps
(function() {
    tinymce.create('tinymce.plugins.webbushort_maps', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_maps':
                var c = cm.createSplitButton('webbushort_maps', {
                    title : '<?php echo __('Google Map','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Lat','wmft2d') ?><br />\
                        <input type="text" name="lat" value="38.428971" onclick="this.select()" /></label>\
						<label><?php echo __('Lng','wmft2d') ?><br />\
                        <input type="text" name="lng" value="27.134342" onclick="this.select()" /></label>\
						<label><?php echo __('Zoom','wmft2d') ?><br />\
                        <input type="text" name="zoom" value="14" onclick="this.select()" /></label>\
						<label><?php echo __('Height','wmft2d') ?><br />\
                        <input type="text" name="height" value="150" onclick="this.select()" /></label>\
						<label><?php echo __('Map Type','wmft2d') ?><br/>\
                        <select name="type">\
                        <option value="m" selected><?php echo __('ROADMAP','wmft2d') ?></option>\
                        <option value="k"><?php echo __('SATELLITE','wmft2d') ?></option>\
                        <option value="h"><?php echo __('HYBRID','wmft2d') ?></option>\
                        <option value="p"><?php echo __('TERRAIN','wmft2d') ?></option>\
                        </select></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                    var type = $menu.find('select[name=type]').val();
									var lat = $menu.find('input[name=lat]').val();
									var lng = $menu.find('input[name=lng]').val();
									var zoom = $menu.find('input[name=zoom]').val();
									var height = $menu.find('input[name=height]').val();
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_maps height="'+height+'" type="'+type+'" lat="'+lat+'" lng="'+lng+'" zoom="'+zoom+'"][/wmf_maps]');
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
                    m.add({title : '<?php echo __('Google Map','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_maps', tinymce.plugins.webbushort_maps);
})();


//Video
(function() {
    tinymce.create('tinymce.plugins.webbushort_video', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_video':
                var c = cm.createSplitButton('webbushort_video', {
                    title : '<?php echo __('Videos','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Video ID','wmft2d') ?><br />\
                        <input type="text" name="id" value="rMltoD1jCGI" onclick="this.select()" /></label>\
						<label><?php echo __('Width','wmft2d') ?><br />\
                        <input type="text" name="w" value="600" onclick="this.select()" /></label>\
						<label><?php echo __('Height','wmft2d') ?><br />\
                        <input type="text" name="h" value="430" onclick="this.select()" /></label>\
						<label><?php echo __('Site','wmft2d') ?><br/>\
                        <select name="type">\
                        <option value="youtube" selected>Youtube</option>\
                        <option value="vimeo">Vimeo</option>\
                        <option value="dailymotion">Dailymotion</option>\
                        <option value="yahoo">Yahoo</option>\
						<option value="bliptv">Bliptv</option>\
						<option value="veoh">Veoh</option>\
						<option value="viddler">Viddler</option>\
                        </select></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                    var type = $menu.find('select[name=type]').val();
									var w = $menu.find('input[name=w]').val();
									var h = $menu.find('input[name=h]').val();
									var id = $menu.find('input[name=id]').val();
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_video h="'+h+'" w="'+w+'" type="'+type+'" id="'+id+'"][/wmf_video]');
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
                    m.add({title : '<?php echo __('Videos','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_video', tinymce.plugins.webbushort_video);
})();


//Twitter
(function() {
    tinymce.create('tinymce.plugins.webbushort_twitter', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_twitter':
                var c = cm.createSplitButton('webbushort_twitter', {
                    title : '<?php echo __('Twitter Feeds','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Twitter Username','wmft2d') ?><br />\
                        <input type="text" name="tu" value="webbudesign" onclick="this.select()" /></label>\
						<label><?php echo __('Tweet Limit','wmft2d') ?><br />\
                        <input type="text" name="tn" value="3" onclick="this.select()" /></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
									var tu = $menu.find('input[name=tu]').val();
									var tn = $menu.find('input[name=tn]').val();
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_twitter user="'+tu+'" numb="'+tn+'"][/wmf_twitter]');
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
                    m.add({title : '<?php echo __('Twitter Feeds','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_twitter', tinymce.plugins.webbushort_twitter);
})();


//Progress Bar
(function() {
    tinymce.create('tinymce.plugins.webbushort_progress', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_progress':
                var c = cm.createSplitButton('webbushort_progress', {
                    title : '<?php echo __('Progress Bar','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('% Progress','wmft2d') ?><br />\
                        <input type="text" name="value" value="10" onclick="this.select()" /></label>\
                        <label><?php echo __('Color','wmft2d') ?><br/>\
                        <select name="color">\
                        <option value=""> <?php echo __('Blue','wmft2d') ?></option>\
                        <option value="progress-bar-info" selected> <?php echo __('Light Blue','wmft2d') ?></option>\
                        <option value="progress-bar-success"> <?php echo __('Green','wmft2d') ?></option>\
                        <option value="progress-bar-warning"> <?php echo __('Yellow','wmft2d') ?></option>\
                        <option value="progress-bar-danger"> <?php echo __('Red','wmft2d') ?></option>\
                        </select>\
						<label><?php echo __('Type','wmft2d') ?><br/>\
						<select name="type">\
						<option value="" selected> <?php echo __('Normal','wmft2d') ?></option>\
                        <option value="progress-striped "> <?php echo __('Striped','wmft2d') ?></option>\
                        <option value="progress-striped active"> <?php echo __('Striped Active','wmft2d') ?></option>\
                        </select>\
						</label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                    var type = $menu.find('select[name=type]').val();
									var color = $menu.find('select[name=color]').val();
									var value = $menu.find('input[name=value]').val();
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_prg value="'+value.toLowerCase()+'" color="'+color.toLowerCase()+'" type="'+type.toLowerCase()+'"][/wmf_prg]');
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
                    m.add({title : '<?php echo __('Progress Bar','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_progress', tinymce.plugins.webbushort_progress);
})();


//Services
(function() {
    tinymce.create('tinymce.plugins.webbushort_services', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_services':
                var c = cm.createSplitButton('webbushort_services', {
                    title : '<?php echo __('Services','wmft2d') ?>',
                    onclick : function() {

                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding: 0 10px 10px">\
						<label><?php echo __('Title','wmft2d') ?><br />\
                        <input type="text" name="title" value="<?php echo __('Title','wmft2d') ?>" onclick="this.select()" /></label>\
                        <label><?php echo __('Icon','wmft2d') ?><br />\
                        <input type="text" name="icon" value="<?php echo __('icon-heart','wmft2d') ?>" onclick="this.select()" /></label>\
                        <label><?php echo __('URL','wmft2d') ?><br />\
                        <input type="text" name="link" value="#" onclick="this.select()" /></label>\
						<label><?php echo __('Target','wmft2d') ?><br/>\
						<select name="target">\
						<option value="" selected> <?php echo __('Select','wmft2d') ?></option>\
                        <option value="_self"> _self</option>\
                        <option value="_blank"> _blank</option>\
                        <option value="_parent"> _parent</option>\
                        </select>\
						</label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
									var target = $menu.find('select[name=target]').val();
									var title = $menu.find('input[name=title]').val();
                                    var icon = $menu.find('input[name=icon]').val();
                                    var link = $menu.find('input[name=link]').val();
                                   
                                    
                                    if(tinyMCE.activeEditor.selection.getContent({format : 'text'}) != ''){
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_services title="'+title+'" icon="'+icon+'" target="'+target+'" link="'+link+'"]'+ tinyMCE.activeEditor.selection.getContent({format : 'source'})+'[/wmf_services]');
									}else{
									tinymce.activeEditor.execCommand('mceInsertContent',false,'[wmf_services title="'+title+'" icon="'+icon+'" target="'+target+'" link="'+link+'"]<?php echo __('Content goes here...','wmft2d') ?>[/wmf_services]');
									}
                                    
                                    
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
                    m.add({title : '<?php echo __('Services','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_services', tinymce.plugins.webbushort_services);
})();

// Padding
(function() {
	"use strict";
    tinymce.create('tinymce.plugins.webbushort_padding', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'webbushort_padding':
                var c = cm.createSplitButton('webbushort_padding', {
                    title : '<?php echo __('Padding','wmft2d') ?>',
                    onclick : function() {
					
                    }
                });
                

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
                        <label><?php echo __('Padding Size','wmft2d') ?><br />\
                        <input type="text" name="size" value="20" onclick="this.select()"  /></label>\
                        </div>');

                        jQuery('<input type="button" class="button" value="<?php echo __('Insert','wmft2d') ?>" />').appendTo($menu)
                                .click(function(){
                                
                                var shortcode = '';
                                var size = $menu.find('input[name=size]').val();
								
                                    shortcode += '[wmf_pad size="'+size+'"]';
                                    shortcode += '';
                                    shortcode += '[/wmf_pad]<br class="ws"/>';

                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

					m.add({title : '<?php echo __('Padding','wmft2d') ?>', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('webbushort_padding', tinymce.plugins.webbushort_padding);
})();