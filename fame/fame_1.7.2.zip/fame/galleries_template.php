<?php
/**
Template Name: Galleries list
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

get_template_part( 'galleries-list' );