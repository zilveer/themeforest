scnShortcodeMeta = {
	attributes : [
			{
				label : "Height",
				id : "height",
				help : "Select height to have space",
				controlType : "select-control",
				selectValues : [ '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70' ],
				defaultValue : '20',
				defaultText : '20'
			},	
			 ],
			 
	customMakeShortcode : function(b) {
		var height = b.height;
		var g = "";
		height = ' height ="'+height+'"';
		g += "[dt_sc_margin " + height + " /]";
		return g;
	}
			 
};