<?php
if(!defined('ABSPATH')) exit;

/**
 * Class EdgeCPT
 *
 * @package Edge Core
 *
 * This class is used to register custom post types and taxonomies. It is a singletone class and main method
 * is registerCPT
 * It registers:
 * - portfolio
 * - portfolio category
 * - testimonials
 * - testimonials category
 * - carousels
 * - carousels category
 * - sliders
 * - sliders category
 */
class EdgeCPT {
    private static $instance;

    /**
     * Private constructor so this class can't instantiated multiple times
     */
    private function __construct() {}

    /**
     * Method that returns instance of current class
     * @return EdgeCPT
     */
    public static function getInstance() {
        if(self::$instance == null) {
            return new self();
        }

        return self::$instance;
    }

    /**
     * Method that registers all CPTs
     *
     * @see EdgeCPT::registerPortfolio
     * @see EdgeCPT::registerTestimonials
     * @see EdgeCPT::registerCarousels
     * @see EdgeCPT::registerEdgtSlider
     */
    public function registerCPT() {
        $this->registerPortfolio();
        $this->registerTestimonials();
        $this->registerCarousels();
        $this->registerEdgtSlider();
        $this->registerMasonryGallery();
    }

    /**
     * Method that registers portfolio CPT and portfolio category taxonomy
     */
    public function registerPortfolio() {
        global $edgt_options;

        $slug = 'portfolio_page';
        if(is_array($edgt_options) && isset($edgt_options['portfolio_single_slug']) &&
            $edgt_options['portfolio_single_slug'] !== '') {
            $slug = $edgt_options['portfolio_single_slug'];
        }

        register_post_type( 'portfolio_page',
            array(
                'labels' => array(
                    'name' => __( 'Portfolio','edgt_cpt' ),
                    'singular_name' => __( 'Portfolio Item','edgt_cpt' ),
                    'add_item' => __('New Portfolio Item','edgt_cpt'),
                    'add_new_item' => __('Add New Portfolio Item','edgt_cpt'),
                    'edit_item' => __('Edit Portfolio Item','edgt_cpt')
                ),
                'public' => true,
                'has_archive' => true,
                'rewrite' => array('slug' => $slug),
                'menu_position' => 4,
                'menu_icon'	=> 'dashicons-screenoptions',
                'show_ui' => true,
                'supports' => array('author', 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'comments')
            )
        );

        $labels = array(
            'name' => __( 'Portfolio Categories', 'edgt_cpt' ),
            'singular_name' => __( 'Portfolio Category', 'edgt_cpt' ),
            'search_items' =>  __( 'Search Portfolio Categories','edgt_cpt' ),
            'all_items' => __( 'All Portfolio Categories','edgt_cpt' ),
            'parent_item' => __( 'Parent Portfolio Category','edgt_cpt' ),
            'parent_item_colon' => __( 'Parent Portfolio Category:','edgt_cpt' ),
            'edit_item' => __( 'Edit Portfolio Category','edgt_cpt' ),
            'update_item' => __( 'Update Portfolio Category','edgt_cpt' ),
            'add_new_item' => __( 'Add New Portfolio Category','edgt_cpt' ),
            'new_item_name' => __( 'New Portfolio Category Name','edgt_cpt' ),
            'menu_name' => __( 'Portfolio Categories','edgt_cpt' ),
        );

        register_taxonomy('portfolio_category', array('portfolio_page'), array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'query_var' => true,
            'rewrite' => array( 'slug' => 'portfolio-category' ),
        ));

        $labels = array(
            'name' => __( 'Portfolio Tags', 'edgt_cpt' ),
            'singular_name' => __( 'Portfolio Tag', 'edgt_cpt' ),
            'search_items' =>  __( 'Search Portfolio Tags','edgt_cpt' ),
            'all_items' => __( 'All Portfolio Tags','edgt_cpt' ),
            'parent_item' => __( 'Parent Portfolio Tag','edgt_cpt' ),
            'parent_item_colon' => __( 'Parent Portfolio Tags:','edgt_cpt' ),
            'edit_item' => __( 'Edit Portfolio Tag','edgt_cpt' ),
            'update_item' => __( 'Update Portfolio Tag','edgt_cpt' ),
            'add_new_item' => __( 'Add New Portfolio Tag','edgt_cpt' ),
            'new_item_name' => __( 'New Portfolio Tag Name','edgt_cpt' ),
            'menu_name' => __( 'Portfolio Tags','edgt_cpt' ),
        );

        register_taxonomy('portfolio_tag',array('portfolio_page'), array(
            'hierarchical' => false,
            'labels' => $labels,
            'show_ui' => true,
            'query_var' => true,
            'rewrite' => array( 'slug' => 'portfolio-tag' ),
        ));
    }

    /**
     * Method that registers testimonials CPT and testimonials category taxonomy
     */
    public function registerTestimonials() {
        register_post_type('testimonials',
            array(
                'labels' 		=> array(
                    'name' 				=> __('Testimonials','edgt_cpt' ),
                    'singular_name' 	=> __('Testimonial','edgt_cpt' ),
                    'add_item'			=> __('New Testimonial','edgt_cpt'),
                    'add_new_item' 		=> __('Add New Testimonial','edgt_cpt'),
                    'edit_item' 		=> __('Edit Testimonial','edgt_cpt')
                ),
                'public'		=>	false,
                'show_in_menu'	=>	true,
                'rewrite' 		=> 	array('slug' => 'testimonials'),
                'menu_position' => 	4,
                'menu_icon'		=> 'dashicons-format-quote',
                'show_ui'		=>	true,
                'has_archive'	=>	false,
                'hierarchical'	=>	false,
                'supports'		=>	array('title', 'thumbnail')
            )
        );

        $labels = array(
            'name' => __( 'Testimonials Categories', 'edgt_cpt' ),
            'singular_name' => __( 'Testimonial Category', 'edgt_cpt' ),
            'search_items' =>  __( 'Search Testimonials Categories','edgt_cpt' ),
            'all_items' => __( 'All Testimonials Categories','edgt_cpt' ),
            'parent_item' => __( 'Parent Testimonial Category','edgt_cpt' ),
            'parent_item_colon' => __( 'Parent Testimonial Category:','edgt_cpt' ),
            'edit_item' => __( 'Edit Testimonials Category','edgt_cpt' ),
            'update_item' => __( 'Update Testimonials Category','edgt_cpt' ),
            'add_new_item' => __( 'Add New Testimonials Category','edgt_cpt' ),
            'new_item_name' => __( 'New Testimonials Category Name','edgt_cpt' ),
            'menu_name' => __( 'Testimonials Categories','edgt_cpt' ),
        );

        register_taxonomy('testimonials_category',array('testimonials'), array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'query_var' => true,
            'show_admin_column' => true,
            'rewrite' => array( 'slug' => 'testimonials-category' ),
        ));
    }

    /**
     * Method that registers carousel item CPT and carousel taxonomy
     */
    public function registerCarousels() {
        register_post_type('carousels',
            array(
                'labels'    => array(
                    'name'        => __('Edge Carousel','edgt_cpt' ),
                    'menu_name' => __('Edge Carousel','edgt_cpt' ),
                    'all_items' => __('Carousel Items','edgt_cpt' ),
                    'add_new' =>  __('Add New Carousel Item','edgt_cpt'),
                    'singular_name'   => __('Carousel Item','edgt_cpt' ),
                    'add_item'      => __('New Carousel Item','edgt_cpt'),
                    'add_new_item'    => __('Add New Carousel Item','edgt_cpt'),
                    'edit_item'     => __('Edit Carousel Item','edgt_cpt')
                ),
                'public'    =>  false,
                'show_in_menu'  =>  true,
                'rewrite'     =>  array('slug' => 'carousels'),
                'menu_position' =>  4,
                'menu_icon'	=> 'dashicons-image-flip-horizontal',
                'show_ui'   =>  true,
                'has_archive' =>  false,
                'hierarchical'  =>  false,
                'supports'    =>  array('title','page-attributes'),
            )
        );

        $labels = array(
            'name' => __( 'Carousels', 'edgt_cpt' ),
            'singular_name' => __( 'Carousel', 'edgt_cpt' ),
            'search_items' =>  __( 'Search Carousels','edgt_cpt' ),
            'all_items' => __( 'All Carousels','edgt_cpt' ),
            'parent_item' => __( 'Parent Carousel','edgt_cpt' ),
            'parent_item_colon' => __( 'Parent Carousel:','edgt_cpt' ),
            'edit_item' => __( 'Edit Carousel','edgt_cpt' ),
            'update_item' => __( 'Update Carousel','edgt_cpt' ),
            'add_new_item' => __( 'Add New Carousel','edgt_cpt' ),
            'new_item_name' => __( 'New Carousel Name','edgt_cpt' ),
            'menu_name' => __( 'Carousels','edgt_cpt' ),
        );

        register_taxonomy('carousels_category',array('carousels'), array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'query_var' => true,
            'show_admin_column' => true,
            'rewrite' => array( 'slug' => 'carousels-category' ),
        ));
    }

    /**
     * Method that registers slide CPT and slider taxonomy
     */
    public function registerEdgtSlider() {
;        register_post_type('slides',
            array(
                'labels' 		=> array(
                    'name' 				=> __('Edge Slider','edgt_cpt' ),
                    'menu_name'	=> __('Edge Slider','edgt_cpt' ),
                    'all_items'	=> __('Slides','edgt_cpt' ),
                    'add_new' =>  __('Add New Slide','edgt_cpt'),
                    'singular_name' 	=> __('Slide','edgt_cpt' ),
                    'add_item'			=> __('New Slide','edgt_cpt'),
                    'add_new_item' 		=> __('Add New Slide','edgt_cpt'),
                    'edit_item' 		=> __('Edit Slide','edgt_cpt')
                ),
                'public'		=>	false,
                'show_in_menu'	=>	true,
                'rewrite' 		=> 	array('slug' => 'slides'),
                'menu_position' => 	4,
                'menu_icon'		=> 'dashicons-images-alt2',
                'show_ui'		=>	true,
                'has_archive'	=>	false,
                'hierarchical'	=>	false,
                'supports'		=>	array('title', 'thumbnail', 'page-attributes'),
            )
        );

        $labels = array(
            'name' => __( 'Sliders', 'edgt_cpt' ),
            'singular_name' => __( 'Slider', 'edgt_cpt' ),
            'search_items' =>  __( 'Search Sliders','edgt_cpt' ),
            'all_items' => __( 'All Sliders','edgt_cpt' ),
            'parent_item' => __( 'Parent Slider','edgt_cpt' ),
            'parent_item_colon' => __( 'Parent Slider:','edgt_cpt' ),
            'edit_item' => __( 'Edit Slider','edgt_cpt' ),
            'update_item' => __( 'Update Slider','edgt_cpt' ),
            'add_new_item' => __( 'Add New Slider','edgt_cpt' ),
            'new_item_name' => __( 'New Slider Name','edgt_cpt' ),
            'menu_name' => __( 'Sliders','edgt_cpt' ),
        );

        register_taxonomy('slides_category',array('slides'), array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'query_var' => true,
            'show_admin_column' => true,
            'rewrite' => array( 'slug' => 'slides-category' ),
        ));
    }

    public function registerMasonryGallery() {
        register_post_type('masonry_gallery',
            array(
                'labels' 		=> array(
                    'name' 				=> __('Masonry Gallery','edgt_cpt' ),
                    'all_items'			=> __('Masonry Gallery Items','edgt_cpt'),
                    'singular_name' 	=> __('Masonry Gallery Item','edgt_cpt' ),
                    'add_item'			=> __('New Masonry Gallery Item','edgt_cpt'),
                    'add_new_item' 		=> __('Add New Masonry Gallery Item','edgt_cpt'),
                    'edit_item' 		=> __('Edit Masonry Gallery Item','edgt_cpt')
                ),
                'public'		=>	false,
                'show_in_menu'	=>	true,
                'rewrite' 		=> 	array('slug' => 'masonry_gallery'),
                'menu_position' => 	20,
                'menu_icon'			=> 'dashicons-schedule',
                'show_ui'		=>	true,
                'has_archive'	=>	false,
                'hierarchical'	=>	false,
                'supports'		=>	array('title', 'thumbnail')
            )
        );

        $labels = array(
            'name' => __( 'Masonry Gallery Categories', 'edgt_cpt' ),
            'singular_name' => __( 'Masonry Gallery Category', 'edgt_cpt' ),
            'search_items' =>  __( 'Search Masonry Gallery Categories','edgt_cpt' ),
            'all_items' => __( 'All Masonry Gallery Categories','edgt_cpt' ),
            'parent_item' => __( 'Parent Masonry Gallery Category','edgt_cpt' ),
            'parent_item_colon' => __( 'Parent Masonry Gallery Category:','edgt_cpt' ),
            'edit_item' => __( 'Edit Masonry Gallery Category','edgt_cpt' ),
            'update_item' => __( 'Update Masonry Gallery Category','edgt_cpt' ),
            'add_new_item' => __( 'Add New Masonry Gallery Category','edgt_cpt' ),
            'new_item_name' => __( 'New Masonry Gallery Category Name','edgt_cpt' ),
            'menu_name' => __( 'Masonry Gallery Categories','edgt_cpt' ),
        );

        register_taxonomy('masonry_gallery_category',array('masonry_gallery'), array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'query_var' => true,
            'show_admin_column' => true,
            'rewrite' => array( 'slug' => 'masonry-gallery-category' ),
        ));
    }
}

//Hook EdgeCPT::registerCPT method to init action
add_action('init', array(EdgeCPT::getInstance(), 'registerCPT'), 0);