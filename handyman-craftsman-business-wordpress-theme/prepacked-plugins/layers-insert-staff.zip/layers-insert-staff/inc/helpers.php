<?php
/**
 * @package LayersInsertStaff
 * @since 1.0.0
 */


// Filter array by provided array keys
add_filter('tl/filter_array'     , 'tl_filter_array', 10, 2);
add_filter('tl/tl_colorize_title', 'tl_colorize_title', 10, 2);
add_filter('tl/themify_filter'   , 'tl_themify_filter', 10, 1);



function tl_themify_filter($str){

    if(strpos($str, 'ti-') === 0){
        $str = 'icon-' . $str;
    }
    return $str;
}


function tl_sanitize_output($input){

    $buffer = preg_replace(
        array(
            '/\>[^\S ]+/s', //strip whitespaces after tags, except space
            '/[^\S ]+\</s', //strip whitespaces before tags, except space
            '/(\s)+/s'  // shorten multiple whitespace sequences
        ),
        array(
            '>',
            '<',
            '\\1'
        ),
        $input
    );
    return $buffer;
}


if(!function_exists('tl_get_abstract')){
    function tl_get_abstract($content, $num = 20, $echo = true){
        //Strip all tags
        $retval = $content;
        $array  = explode(' ', $content);

        if (count($array) <= $num) {
            $retval = $content;
        }
        else {
            array_splice($array, $num);
            $retval = implode(' ', $array) .  '...';
        }

        if($echo)
            echo esc_html($retval);
        else
            return $retval;
    }
}


if (!function_exists('tl_colorize_title')) {

    function tl_colorize_title($title, $color = '')
    {
        $title = trim($title);
        $parts = explode(' ', $title);
        $n     = count($parts);

        if ($n < 2) {
            return esc_html($title);
        } else {

            foreach($parts as $ii => $p){
                $parts[$ii] = esc_html($p);
            }

            $color = isset($color) && $color != '' ? 'style="color:' . esc_attr($color) . '"' : '';
            $parts[$n - 1] = '<span ' . $color . '>' . $parts[$n - 1] . '</span>';
            return implode(' ', $parts);
        }
    }
}


if (!function_exists('tl_layers_is_light_or_dark_recalculated')) {

    function tl_layers_is_light_or_dark_recalculated($color, $brightness_cont = 175)
    {
        if (FALSE === strpos($color, '#')) {
            // Not a color
            return NULL;
        }

        $hex = str_replace('#', '', $color);

        $c_r = hexdec(substr($hex, 0, 2));
        $c_g = hexdec(substr($hex, 2, 2));
        $c_b = hexdec(substr($hex, 4, 2));

        $brightness = (($c_r * 299) + ($c_g * 587) + ($c_b * 114)) / 1000;
        return ($brightness > $brightness_cont) ? 'light' : 'dark';
    }
}


/**
 * @param string $key
 * @param int|null $post_id
 * @param bool $single
 *
 * @return array|string
 */
if (!function_exists('tl_get_metadata')) {

    function tl_get_metadata($post_id = null, $key = '', $single = true)
    {
        if (!$post_id) {
            global $post;
            $post_id = $post->ID;
        }
        $meta = get_metadata('post', $post_id, $key, $single);

        if ($single && $key == '') {
            $tmp = array();
            foreach ($meta as $i => $v) {
                $tmp[$i] = isset($v[0]) ? $v[0] : $v;
            }
            $meta = $tmp;
        }
        return $meta;
    }
}


/**
 *
 * @param array $args
 * @return \WP_Query
 */
if (!function_exists('tl_get_posts_query')) {

    function tl_get_posts_query($args = array())
    {
        $defaults = array(
            'force_no_custom_order' => true,
            'orderby' => 'menu_order',
            'order' => 'ASC',
            'post_type' => 'post',
            'post_status' => 'publish',
            'lang' => '', // polylang, ingore language filter
            'suppress_filters' => 1, // wpml, ignore language filter
            'posts_per_page' => -1,
        );

        $args = wp_parse_args($args, $defaults);
        $query = new \WP_Query($args);
        return $query;
    }
}


/**
 * Return list of posts
 *
 * @param array $args
 * @param bool $extended
 * @return array|\WP_Query
 */
if (!function_exists('tl_get_posts')) {

    function tl_get_posts($args = array(), $extended = false)
    {
        $data = array();
        $defaults = array('post_type' => 'post',
                    'order' => 'ASC',
                    'orderby' => 'title',
                    'post_status' => 'publish',
                    'posts_per_page' => -1);

        $args = wp_parse_args($args, $defaults);
        $posts = get_posts($args);

        if (!empty($posts)) {

            if (!$extended) {
                foreach ($posts as $p) {
                    $data[$p->ID] = $p->post_title;
                }
            } else {
                $data = $posts;
            }
        }
        wp_reset_postdata();
        return $data;
    }
}


if(!function_exists('tl_array_to_css')){

    function tl_array_to_css($selector, $array){
        $css = '';
        foreach($array as $propery => $v){
            $css .= $propery . ':' . $v .';';
        }
        return $selector . '{' . $css .'}';
    }
}


/**
 * Return pages
 *
 * @param array $args
 * @param bool $extended
 * @return array|\WP_Query
 */
if (!function_exists('tl_get_pages')) {

    function tl_get_pages($args = array(), $extended = false)
    {
        $args['post_type'] = 'page';
        $data = tl_get_posts($args, $extended);
        return $data;
    }
}


if (!function_exists('tl_layers_post_meta')) {

    /**
     * Return post meta data
     *
     * @param null $post_id
     * @param null $display
     * @param string $wrapper
     * @param string $wrapper_class
     */
    function tl_layers_post_meta($post_id = NULL, $display = NULL, $wrapper = 'footer', $wrapper_class = 'meta-info')
    {
        // If there is no post ID specified, use the current post, does not affect post author, yet.
        if (NULL == $post_id) {
            global $post;
            $post_id = $post->ID;
        }
        // If there are no items to display, return nothing
        if (!is_array($display)) $display = array('date', 'author', 'categories', 'tags', 'comment-num');

        foreach ($display as $meta) {

            switch ($meta) {
                case 'date' :
                    $meta_to_display[] = '<span class="meta-item meta-date"><i class="fa fa-calendar"></i> ' . get_the_time(get_option('date_format'), $post_id) . '</span>';
                    break;
                case 'author' :
                    $meta_to_display[] = '<span class="meta-item meta-author"><i class="fa fa-user"></i> ' . layers_get_the_author($post_id) . '</span>';
                    break;
                case 'categories' :

                    $categories = '';
                    // Use different terms for different post types
                    if ('post' == get_post_type($post_id)) {
                        $the_categories = get_the_category($post_id);
                    } elseif ('tl_portfolio' == get_post_type($post_id)) {
                        $the_categories = get_the_terms($post_id, 'tl_portfolio_category');
                    } else {
                        $the_categories = FALSE;
                    }

                    // If there are no categories, skip to the next case
                    if (!$the_categories) continue;

                    foreach ($the_categories as $category) {
                        $categories[] = ' <a href="' . get_category_link($category->term_id) . '" title="' . esc_attr(sprintf(__("View all posts in %s", LAYERS_THEME_SLUG), $category->name)) . '">' . $category->name . '</a>';
                    }
                    $meta_to_display[] = '<span class="meta-item meta-category"><i class="fa fa-tag"></i> ' . implode(', ', $categories) . '</span>';
                    break;

                case 'tags' :
                    $tags = '';

                    if ('post' == get_post_type($post_id)) {
                        $the_tags = get_the_tags($post_id);
                    } elseif ('portfolio' == get_post_type($post_id)) { // @todo fix this
                        $the_tags = get_the_terms($post_id, 'portfolio-tag');
                    } else {
                        $the_tags = FALSE;
                    }

                    // If there are no tags, skip to the next case
                    if (!$the_tags) continue;

                    foreach ($the_tags as $tag) {
                        $tags[] = ' <a href="' . get_category_link($tag->term_id) . '" title="' . esc_attr(sprintf(__("View all posts tagged %s", LAYERS_THEME_SLUG), $tag->name)) . '">' . $tag->name . '</a>';
                    }
                    $meta_to_display[] = '<span class="meta-item meta-tags"><i class="fa fa-tags"></i> ' . implode(', ', $tags) . '</span>';
                    break;

                case 'comment-num' :
                    $num = get_comments_number($post_id);
                    $meta_to_display[] = '<span class=" meta-item meta-commnent-num"><i class="fa fa-comments-o"></i>&nbsp;' . $num . '</span>';
                    break;

            } // switch meta
        } // foreach $display

        if (!empty($meta_to_display)) {
            echo '<' . $wrapper . (('' != $wrapper_class) ? ' class="' . $wrapper_class . '"' : NULL) . '>';
            echo '<p>';
            echo implode(' ', $meta_to_display);
            echo '</p>';
            echo '</' . $wrapper . '>';
        }
    }
} // layers_post_meta


if (!function_exists('tl_layers_get_feature_media')) {

    /**
     * Feature Image / Video Generator
     *
     * @param null $post_id
     * @param string $size
     * @param null $video
     * @param $force_img
     * @param $force_vid
     * @return null|string
     */
    function tl_layers_get_feature_media($post_id, $size = 'medium', $video = NULL, $force_img = false, $force_vid=false, $use_pretty_photo = true)
    {
        if(is_array($size)){
            $image_dimensions['width']  = $size[0];
            $image_dimensions['height'] = $size[1];
            $image_dimensions['crop']   = true;
        }else{
            $image_dimensions = layers_get_image_sizes($size);
        }

        $attachment_id = get_post_thumbnail_id($post_id);

        // Check for an image
        if (NULL != $attachment_id && '' != $attachment_id) {

            if($use_pretty_photo){
                $large_image_url = wp_get_attachment_image_src($attachment_id, "large");
                $large_image_url = $large_image_url[0];
                $use_pretty_photo = ' class="pretty-photo"';
            }else{
                $use_pretty_photo = '';
                $large_image_url ='#';
            }
            $use_image = '<a href="' . esc_url($large_image_url) . '" ' . $use_pretty_photo.'>' . get_the_post_thumbnail($post_id, $size) . '</a>';
        }

        // Check for a video
        if (NULL != $video && '' != $video) {
                $embed_code = '[embed width="' . $image_dimensions['width'] . '"]' . $video . '[/embed]';
            $wp_embed = new \WP_Embed();
            $use_video = $wp_embed->run_shortcode($embed_code);
            $use_video = str_replace('frameborder="0"' ,'', $use_video);
        }

        if($force_img && isset($use_image)){
            $media = $use_image;
        }elseif($force_vid && isset($use_video)){
            $media = $use_video;
        }else{
            if(isset($use_image)){
                $media = $use_image;
            }else{
                return null;
            }
        }

        $media_output = do_action('layers_before_feature_media') . $media . do_action('layers_after_feature_media');
        return $media_output;
    }
}


if (!function_exists('tl_post_featured_media')) {
    /**
     * Wrapper function for @see tl_layers_get_feature_media()
     *
     * @param array $args
     * @return mixed|void
     */
    function tl_post_featured_media($args = array()){

        global $post;

        $defaults = array(
            'post_id'     => $post->ID,
            'wrap'        => 'div',
            'wrap_class'  => 'thumbnail',
            'size'        => 'medium',
            'force_img'   => false,
            'force_vid'   => false,
            'use_pretty_photo'   => true
        );

        $args = wp_parse_args( $args, $defaults );
        extract( $args, EXTR_SKIP );

        // Get video
        $post_meta = get_post_meta( $post_id, 'layers', true );
        $video     = isset($post_meta['video-url']) && $post_meta['video-url']!='' ? $post_meta['video-url'] : null;
        $output    = '';

        $featured_media = tl_layers_get_feature_media($post_id, $size, $video, $force_img, $force_vid, $use_pretty_photo );

        if( NULL != $featured_media ){
            $output .= $featured_media;
        }

        if( '' != $wrap && $featured_media != null ) {
            $output = '<'.$wrap. ( '' != $wrap_class ? ' class="' . $wrap_class . '"' : '' ) . '>' . $output . '</' . $wrap . '>';
        }
        return apply_filters('layers_post_featured_media', $output);
    }
}


/**
 * Filter an array
 *
 * @param $filter
 * @param $data
 * @return array
 */
if (!function_exists('tl_filter_array')) {
    function tl_filter_array($filter, $data)
    {

        $filtered = array();
        foreach ($filter as $f) {
            if (isset($data[$f])) {
                $filtered[$f] = $data[$f];
            }
        }
        return $filtered;
    }
}



if(!function_exists('tl_get_registered_post_types')){

    /**
     * Returns all registered post types excetp some buildin posts (attachment , revision, nav_menu_item )
     *
     * Applies filter "tl/filter_post_types". Filters all fields that are not imporatnt for us
     *
     * @return array
     */
    function tl_get_registered_post_types($apply_filter=true)
    {
        $to_remove  = array('attachment', 'revision', 'nav_menu_item', 'product', 'product_variation', 'shop_order', 'shop_order_refund','shop_coupon','shop_webhook','wpcf7_contact_form');
        $post_types = get_post_types(array('_builtin' => false), 'objects', 'and');

        if($apply_filter){
            foreach($post_types as $k => $v){
                if(in_array($k, $to_remove)){
                    unset($post_types[$k]);
                }
            }
        }
        return apply_filters('tl/filter_post_types', $post_types);
    }
}


if(!function_exists('tl_apply_button_styles')){

    /**
     * @param $selectors
     * @param $params
     *
     * keys:
     *  text-color, background-color, border-color
     *  text-color-hover, background-color-hover, border-color-hover
     *
     */
    function tl_inline_button_styles($selectors, $params){

        $button       = array();
        $button_hover = array();

        if(!empty($params['text-color'])){
            $button['color'] = $params['text-color'];
        }
        if(!empty($params['background-color'])){
            $button['background-color'] = $params['background-color'];
        }
        if(!empty($params['border-color'])){
            $button['border-color'] = $params['border-color'];
        }
        if(isset($params['border-width']) && is_numeric($params['border-width'])){
            $button['border-width'] = ((int) $params['border-width']) . 'px';
        }
        if(isset($params['border-radius']) && is_numeric($params['border-radius'])){
            $button['border-radius'] = ((int) $params['border-radius']) . 'px';
        }
        if($button){
            layers_inline_styles(array('selectors' => $selectors, 'css' => $button ));
        }

        // Hover

        foreach($selectors as $k => $v){
            $selectors[$k] = $v . ':hover';
        }
        if(!empty($params['text-color-hover']) ){
            $button_hover['color'] = $params['text-color-hover'];
        }
        if(!empty($params['background-color-hover'])){
            $button_hover['background-color'] = $params['background-color-hover'];
        }
        if(!empty($params['border-color-hover'])){
            $button_hover['border-color'] = $params['border-color-hover'];
        }

        if($button_hover){
            layers_inline_styles(array('selectors' => $selectors, 'css' => $button_hover ));
        }
    }
}