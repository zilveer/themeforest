<?php
/*
Plugin Name: Youxi Importer
Plugin URI: http://www.themeforest.net/user/nagaemas
Description: This plugin helps importing theme demo content from a WordPress Importer XML file. The plugin is also able to import front page displays, active nav menus and widgets. Uses code from the official WordPress importer plugin and Steven Gliebe's widget importer & exporter plugin.
Version: 1.0
Author: YouxiThemes
Author URI: http://www.themeforest.net/user/nagaemas
License: Envato Marketplace Licence

Changelog:
1.0
- Initial release
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Hi there!  I\'m just a plugin, not much I can do when called directly.' );
}

define( 'YOUXI_IMPORTER_VERSION', '1.0' );

define( 'YOUXI_IMPORTER_DIR', plugin_dir_path( __FILE__ ) );

define( 'YOUXI_IMPORTER_URL', plugin_dir_url( __FILE__ ) );

define( 'YOUXI_IMPORTER_LANG_DIR', dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

class Youxi_Demo_Importer {

	private $page_hook;

	private $importers = array();

	public function __construct() {

		add_action( 'admin_menu', array( $this, 'admin_menu' ) );

		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );

		add_action( 'wp_ajax_youxi_import_demo', array( $this, 'wp_ajax_handle_import' ) );
	}

	public function admin_menu() {

		$this->page_hook = add_management_page(
			esc_html__( 'Youxi Demo Content Importer', 'youxi' ), esc_html__( 'Youxi Importer', 'youxi' ), 
			'import', 'youxi-importer', array( $this, 'importer_page_callback' )
		);
	}

	public function admin_enqueue_scripts( $hook ) {

		if( $hook != $this->page_hook ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_style( 'youxi-demo-importer', trailingslashit( YOUXI_IMPORTER_URL ) . "assets/css/youxi.demo-importer.css", array(), '0.1' );

		wp_enqueue_script( 'ajax-queue', trailingslashit( YOUXI_IMPORTER_URL ) . "assets/plugins/ajaxqueue/jquery.ajaxQueue{$suffix}.js", array( 'jquery' ), '0.1.2', true );
		wp_enqueue_script( 'youxi-demo-importer', trailingslashit( YOUXI_IMPORTER_URL ) . "assets/js/youxi.demo-importer{$suffix}.js", array( 'ajax-queue' ), '0.1', true );

		wp_localize_script( 'youxi-demo-importer', '_demoImporterSettings', $this->get_import_settings() );
	}

	public function wp_ajax_error( $error ) {

		if( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
			wp_send_json_error( compact( 'error' ) );
		} else {
			wp_die( '-1' );
		}
	}

	public function wp_ajax_handle_import() {

		if( ! isset( $_POST['task'] ) ) {
			$this->wp_ajax_error( esc_html__( 'Invalid request.', 'youxi' ) );
		}

		$task = wp_parse_args( $_POST['task'], array( 'task_id' => '', 'demo_id' => '' ) );

		$available_demos = $this->get_available_demos();
		if( ! array_key_exists( $task['demo_id'], $available_demos ) ) {
			$this->wp_ajax_error( esc_html__( 'Invalid demo content requested.', 'youxi' ) );
		}

		if( ! in_array( $task['task_id'], array_keys( $this->get_import_tasks() ) ) ) {
			$this->wp_ajax_error( esc_html__( 'Invalid import task.', 'youxi' ) );
		}

		check_ajax_referer( 'import_demo_' . $task['demo_id'] );

		// Everything OK, let's do the job
		$result = $this->do_import( $task );
		if( ! is_wp_error( $result ) ) {

			// We have imported something, let's remember that
			if( ! add_option( '_youxi_demo_importer_has_import', true, '', 'no' ) ) {
				update_option( '_youxi_demo_importer_has_import', true );
			}

			// Return the result whatever it is
			wp_send_json_success( compact( 'result' ) );

		} else {
			$this->wp_ajax_error( $result->get_error_message() );
		}
	}

	public function do_import( $task ) {

		$available_demos = $this->get_available_demos();
		extract( wp_parse_args( $task, array( 'task_id' => '', 'demo_id' => '' ) ), EXTR_SKIP );

		if( isset( $available_demos[ $demo_id ] ) ) {

			$current_demo = $available_demos[ $demo_id ];

			if( isset( $current_demo['content'][ $task_id ] ) ) {

				$handler = $this->get_import_handler( $task_id );
				if( is_callable( $handler ) ) {
					return call_user_func( $handler, $current_demo['content'][ $task_id ] );
				} else {
					return new WP_Error( 'importer_invalid_task', sprintf( esc_html__( 'The handler for the task %s is invalid.', 'youxi' ), $task_id ) );
				}
			}
		}
	}

	public function get_available_demos() {
		return apply_filters( 'youxi_importer_demos', array() );
	}

	public function get_import_tasks() {
		return apply_filters( 'youxi_importer_tasks', array(
			'wp' => array(
				'status'  => esc_html__( 'Importing posts, pages, comments, custom fields, categories, and tags.', 'youxi' ), 
				'handler' => 'youxi_importer_handle_wp_xml'
			), 
			'theme-options' => array(
				'status'  => esc_html__( 'Importing theme options', 'youxi' ), 
				'handler' => 'youxi_importer_handle_ot'
			), 
			'customizer-options' => array(
				'status'  => esc_html__( 'Importing customizer options', 'youxi' ), 
				'handler' => 'youxi_importer_handle_customizer'
			), 
			'widgets' => array(
				'status'  => esc_html__( 'Importing widgets', 'youxi' ), 
				'handler' => 'youxi_importer_handle_widgets'
			), 
			'frontpage_displays' => array(
				'status'  => esc_html__( 'Importing front page options', 'youxi' ), 
				'handler' => 'youxi_importer_handle_frontpage_displays'
			), 
			'nav_menu_locations' => array(
				'status'  => esc_html__( 'Importing nav menu locations', 'youxi' ), 
				'handler' => 'youxi_importer_handle_nav_menu'
			)
		));
	}

	public function get_import_handler( $id ) {
		$tasks = $this->get_import_tasks();
		if( isset( $tasks[ $id ], $tasks[ $id ]['handler'] ) ) {
			return $tasks[ $id ]['handler'];
		}
	}

	public function get_import_settings() {
		return apply_filters( 'youxi_importer_settings', array(
			'ajaxUrl'                  => admin_url( 'admin-ajax.php' ), 
			'ajaxAction'               => 'youxi_import_demo', 
			'importTasks'              => $this->get_import_tasks(), 
			'successMessage'           => esc_html__( 'Import Completed Successfully', 'youxi' ), 
			'failureMessage'           => esc_html__( 'Import Completed with {count} Failure(s)', 'youxi' ), 
			'hasPreviousImportMessage' => esc_html__( 'You have previously imported a demo content, are you sure you want to import again?', 'youxi' ), 
			'beforeUnloadMessage'      => esc_html__( 'You haven\'t finishid importing the demo content. If you leave now, the demo content will not be imported.', 'youxi' ), 
			'importFinishTimeout'      => 2000, 
			'importDebug'              => defined( 'WP_DEBUG' ) && WP_DEBUG, 
			'hasPreviousImport'        => get_option( '_youxi_demo_importer_has_import', false )
		));
	}

	public function importer_page_callback() {
		?>
		<div class="wrap demo-importer">

			<h1><?php esc_html_e( 'Youxi Demo Content Importer', 'youxi' ) ?></h1>

			<?php if( $available_demos = $this->get_available_demos() ): ?>

			<div class="theme-browser demo-browser rendered">

				<div class="themes demos">

					<?php foreach( $available_demos as $id => $args ):
						$args = wp_parse_args( $args, array(
							'screenshot' => '', 
							'name' => ''
						));
					?>

					<div class="theme demo-content active" tabindex="0" data-demo-id="<?php echo esc_attr( $id ) ?>" data-wp-nonce="<?php echo esc_attr( wp_create_nonce( 'import_demo_' . $id ) ); ?>">

						<div class="theme-screenshot demo-screenshot">
							<img src="<?php echo esc_url( $args['screenshot'] ) ?>" alt="<?php echo esc_attr( $args['name'] ) ?>">
						</div>

						<span class="more-details"></span>

						<h3 class="theme-name demo-name"><?php echo esc_html( $args['name'] ) ?></h3>

						<div class="theme-actions demo-actions">
							<button type="button" class="button button-primary"><?php esc_html_e( 'Import', 'youxi' ) ?></button>
						</div>

					</div>

					<?php endforeach; ?>

				</div>

				<br class="clear">

			</div>

			<?php else:
				echo '<div class="error settings-error"><p>' . esc_html__( 'There are no available demo content to import.', 'youxi' ) . '</p></div>';
			endif;
			?>
		</div>
		<?php
	}
}


function youxi_importer_init() {

	/* Load Language File */
	load_plugin_textdomain( 'youxi', false, YOUXI_IMPORTER_LANG_DIR );

	require trailingslashit( YOUXI_IMPORTER_DIR ) . 'tasks/customizer.php';
	require trailingslashit( YOUXI_IMPORTER_DIR ) . 'tasks/frontpage-displays.php';
	require trailingslashit( YOUXI_IMPORTER_DIR ) . 'tasks/nav-menu.php';
	require trailingslashit( YOUXI_IMPORTER_DIR ) . 'tasks/option-tree.php';
	require trailingslashit( YOUXI_IMPORTER_DIR ) . 'tasks/widgets.php';
	require trailingslashit( YOUXI_IMPORTER_DIR ) . 'tasks/wordpress-xml.php';

	new Youxi_Demo_Importer();
}
add_action( 'plugins_loaded', 'youxi_importer_init' );
