    </div>
    <form action="%PATH%send-header-form.php" method="post">
%CONTENT%
      <input type="hidden" name="iworks_slider_email" value="%EMAIL%" />
      <p class="input"><input name="shc-name" id="shc-name" placeholder="%Name%"></p>
      <p class="input"><input name="shc-lastname" id="shc-lastname" placeholder="%Last Name%"></p>
      <p class="input"><input name="shc-email" id="shc-email" placeholder="%Email%"></p>
      <p class="input"><input name="shc-phone" id="shc-phone" placeholder="%Phone%"></p>
      <p class="textarea"><textarea name="shc-message" id="shc-message" placeholder="%Message%" rows="5" cols="20"></textarea></p>
      <p class="submit"><button name="send" type="submit" value="submit">%Submit%</button></p>
    </form>
  </div>
</section>
