<?php

global $custom_meta_team;


$custom_meta_team[] = array("label" => "Possition",
    "desc" => "",
    "id" => "_team_possition",
    "std" => "",
    "type" => "text");


$custom_meta_team[] = array("label" => "Photo",
    "desc" => "",
    "id" => "_team_photo",
    "std" => "",
    "type" => "simplemediapicker");



$custom_meta_team[] = array("label" => "E-mail",
    "desc" => "",
    "id" => "_team_mail",
    "std" => "",
    "type" => "text");

//SOCIAL==========================


$custom_meta_team[] = array("label" => "Facebook url",
    "desc" => "",
    "id" => "_team_fb",
    "std" => "",
    "type" => "text");

$custom_meta_team[] = array("label" => "Twitter url",
    "desc" => "",
    "id" => "_team_tw",
    "std" => "",
    "type" => "text");

$custom_meta_team[] = array("label" => "Google+ url",
    "desc" => "",
    "id" => "_team_gp",
    "std" => "",
    "type" => "text");

$custom_meta_team[] = array("label" => "Linkedin url",
    "desc" => "",
    "id" => "_team_lin",
    "std" => "",
    "type" => "text");

$custom_meta_team[] = array("label" => "Blogger url",
    "desc" => "",
    "id" => "_team_bl",
    "std" => "",
    "type" => "text");


?>
