jQuery(document).ready(function(){
	jQuery('.mango_bootstrap_slider div.item:first').addClass('active');
});