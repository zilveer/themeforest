function ict_preview(){
    jQuery('#preview').html('');
    jQuery("#preview").html('<div style="background:#fff;width: 100%;text-align:center;"><img src="'+window.dir_url+'files/images/loading.gif" class=""/></div>');

    var show = new Array();
      if(jQuery('#show_name').is(":checked")) show.push('name');
      if(jQuery('#show_photo').is(":checked")) show.push('photo');
      if(jQuery('#show_descript').is(":checked")) show.push('description');
      if(jQuery('#show_job').is(":checked")) show.push('job');
      if(jQuery('#show_email').is(":checked")) show.push('email');
      if(jQuery('#show_location').is(":checked")) show.push('location');
      if(jQuery('#show_tel').is(":checked")) show.push('tel');
      if(jQuery('#show_website').is(":checked")) show.push('website');
      if(jQuery('#show_social_icon').is(":checked")) show.push('social_icon');
      if(jQuery('#show_skills').is(":checked")) show.push('skills');
    var show_str = show.join(',');

    var slide_opt = new Array();
        if(jQuery('#bullets').is(":checked")) slide_opt.push('bullets');
        if(jQuery('#nav_button').is(":checked")) slide_opt.push('nav_button');
        if(jQuery('#autoplay').is(":checked")) slide_opt.push('autoplay');
        if(jQuery('#stop_hover').is(":checked")) slide_opt.push('stop_hover');
        if(jQuery('#lazy_load').is(":checked")) slide_opt.push('lazy_load');
        if(jQuery('#responsive').is(":checked")) slide_opt.push('responsive');
        if(jQuery('#lazy_effect').is(":checked")) slide_opt.push('lazy_effect');
    var slide_opt_str = slide_opt.join(',');

    var value = {
        team : jQuery("#team").val(),
        order_by : jQuery("#order_by").val(),
        order : jQuery("#order").val(),
        limit : jQuery('#limit').val(),
        inside_template : jQuery('#inside_template').val(),
        theme : jQuery('#theme').val(),
        color_scheme : jQuery('#color_scheme').val(),
        show : show_str,
        columns : jQuery('#columns_num').val(),
        items_per_slide : jQuery('#items_per_slide').val(),
        slide_opt : slide_opt_str,
        slide_speed : jQuery('#speed').val(),
        slide_pagination_speed : jQuery('#pagination_speed').val(),
        slide_css_transition : jQuery('#slide_css_transition').val()
    };
    if(jQuery('#page_inside').is(":checked")) value.page_inside = 1;
    else value.page_inside = 0;
    if(jQuery('#slider_set').is(":checked")) value.slider_set = 1;
    else value.slider_set = 0;

    //loading data
    jQuery.get(dir_url+"includes/imt_view.php", value, function(data) {
        jQuery("#preview").html(data);
     });
     //update shortcode
     ict_update_shortcode(value);
     console.log(value.color_scheme);
}

function ict_update_shortcode(value){
    // CREATE SHORTCODE
    var str = "[indeed-my-team ";
    str += "team='"+value.team+"' ";
    str += "order_by='"+value.order_by+"' ";
    str += "order='"+value.order+"' ";
    str += "limit='"+value.limit+"' ";
    str += "show='"+value.show+"' ";
    str += "page_inside='"+value.page_inside+"' ";
    str += "inside_template='"+value.inside_template+"' ";
    str += "theme='"+value.theme+"' ";
    str += "color_scheme='"+value.color_scheme+"' ";
    str += "slider_set='"+value.slider_set+"' ";
    str += "columns='"+value.columns+"' ";
    str += "items_per_slide='"+value.items_per_slide+"' ";
    str += "slide_opt='"+value.slide_opt+"' ";
    str += "slide_speed='"+value.slide_speed+"' ";
    str += "slide_pagination_speed='"+value.slide_pagination_speed+"' ";
    str += "slide_css_transition='"+value.slide_css_transition+"' ";
    str += "]";
    jQuery('.the_shortcode').html(str);
    jQuery(".php_code").html('&lt;?php echo do_shortcode("'+str+'");?&gt;');
}

//widget funcs
function make_inputh_string(divCheck, showValue, hidden_input_id){
    str = jQuery(hidden_input_id).val();
    if(str!='') show_arr = str.split(',');
    else show_arr = new Array();
    if(jQuery(divCheck).is(':checked')){
        show_arr.push(showValue);
    }else{
        var index = show_arr.indexOf(showValue);
        show_arr.splice(index, 1);
    }
    str = show_arr.join(',');
    jQuery(hidden_input_id).val(str);
}

function check_and_h(from, where) {
	if (jQuery(from).is(":checked")) {
		jQuery(where).val(1);
	} else {
		jQuery(where).val(0);
	}
}

function checkandShow(checkID, targetID, display_type){
    if(jQuery(checkID).is(':checked')){
      jQuery(targetID).css('display', display_type);
    }else jQuery(targetID).css('display', 'none');
}
function checkandModfCss(checkID, targetID, cssAttr, cssValue_true, cssValue_false){
    if(jQuery(checkID).is(':checked')){
      jQuery(targetID).css(cssAttr, cssValue_true);
    }else jQuery(targetID).css(cssAttr, cssValue_false);
}

function changeColorScheme(id, value, where ){
    jQuery('#colors_ul li').each(function(){
        jQuery(this).attr('class', 'color_scheme_item');
    });
    jQuery(id).attr('class', 'color_scheme_item-selected');
    jQuery(where).val(value);
}