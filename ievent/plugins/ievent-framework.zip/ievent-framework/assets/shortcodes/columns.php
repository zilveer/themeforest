<?php 

	/* Row  ---------------------------------------------*/
	
	add_shortcode('row', 'jx_ievent_row');
	
	function jx_ievent_row($atts, $content = null) { 
		extract(shortcode_atts(array(
			'class'=>''
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		
		//function code
			
			$out ='
			<div class="row">
				'.do_shortcode($content).'
			</div>
			';
			

		//return output
		return $out;
	}
	
	
	/* Ten Columns  ---------------------------------------------*/
	
	add_shortcode('ten_columns', 'jx_ievent_ten_columns');
	
	function jx_ievent_ten_columns($atts, $content = null) { 
		extract(shortcode_atts(array(
			'class'=>''
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		
		//function code
			
			$out ='
			<div class="ten columns '.$class.'">
				'.do_shortcode($content).'
			</div>
			';
			

		//return output
		return $out;
	}
	
	/* Eight Columns  ---------------------------------------------*/
	
	add_shortcode('eight_columns', 'jx_ievent_eight_columns');
	
	function jx_ievent_eight_columns($atts, $content = null) { 
		extract(shortcode_atts(array(
			'class'=>''
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		
		//function code
			
			$out ='
			<div class="eight columns '.$class.'">
				'.do_shortcode($content).'
			</div>
			';
			

		//return output
		return $out;
	}
	
	/* Six Columns  ---------------------------------------------*/
	
	add_shortcode('six_columns', 'jx_ievent_six_columns');
	
	function jx_ievent_six_columns($atts, $content = null) { 
		extract(shortcode_atts(array(
			'class'=>''
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		
		//function code
			
			$out ='
			<div class="six columns '.$class.'">
				'.do_shortcode($content).'
			</div>
			';
			

		//return output
		return $out;
	}


	/* Four Columns  ---------------------------------------------*/
	
	add_shortcode('four_columns', 'jx_ievent_four_columns');
	
	function jx_ievent_four_columns($atts, $content = null) { 
		extract(shortcode_atts(array(
			'class'=>''
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		
		//function code
			
			$out ='
			<div class="four columns '.$class.'">
				'.do_shortcode($content).'
			</div>
			';
			

		//return output
		return $out;
	}


	/* Four Columns  ---------------------------------------------*/
	
	add_shortcode('third_columns', 'jx_ievent_third_columns');
	
	function jx_ievent_third_columns($atts, $content = null) { 
		extract(shortcode_atts(array(
			'class'=>''
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		
		
		//function code
			
			$out ='
			<div class="one-third columns '.$class.'">
				'.do_shortcode($content).'
			</div>
			';
			

		//return output
		return $out;
	}



?>