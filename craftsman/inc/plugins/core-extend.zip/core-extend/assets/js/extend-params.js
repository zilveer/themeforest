(function($) {
	"use strict";
	
	$('.mnky_preview input[type=radio]').click(function() {
		var selected = $('.mnky_preview input:checked').val();
		$('#mnky_selected_preview').val(selected);
	});

})(jQuery);