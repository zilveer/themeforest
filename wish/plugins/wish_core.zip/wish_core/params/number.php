<?php  
// fontawesome param type for visual composer
vc_add_shortcode_param( 'wish_number', 'wish_number_param_define' );
function wish_number_param_define( $settings, $value ) {


   return '<div class="wish_number_param">'
             .'<input name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput wish_number_input ' .
             esc_attr( $settings['param_name'] ) . ' ' .
             esc_attr( $settings['type'] ) . '_field" type="number" value="' . esc_attr( $value ) . '" />
           </div>
			'; // This is html markup that will be outputted in content elements edit form
}




?>