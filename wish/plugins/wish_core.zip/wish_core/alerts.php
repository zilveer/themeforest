<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Alerts", "wish"),
    "description" => __("Alerts", 'wish'),
    "controls" => "full",
    "base" => "wish_alerts",
    "as_parent" => array('only' => 'wish_alerts_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link" => "http://i.imgur.com/UDvh5w4.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("", "wish"),
            "value" => __("Alerts", 'wish'),
            "admin_label" => false,
        ),
    
        array(
            "type" => "textfield",
            "heading" => __("Subtitle", "wish"),
            "param_name" => "subtitle",
            "description" => __("", "wish"),
            "value" => __("Bootstrap Alerts", 'wish'),
            "admin_label" => false,
        ),

         /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("40", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        /*Subtitle*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Subtitle Text Font", "wish" ),
            "param_name" => "subtitle_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Subtitle Size", "wish"),
            "param_name" => "subtitle_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("22", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Subtitle Text Color", "wish" ),
            "param_name" => "subtitle_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#FFFFFF', //Default Red color
            "description" => __( "Choose the background color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("alert", "wish"),
    "base" => "wish_alerts_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_alerts'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "dropdown",
            "heading" => __("Alert Type", "wish"),
            "param_name" => "alert_type",
            "description" => __("Alert Type", "wish"),
            "value" => array( 
                            "Well done"  => "success",
                            "Heads up" => "info",
                            "Warning" => "warning",
                            "Oh snap" => "danger",
                            ),
            "std"       =>   5,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("", "wish"),
            "value" => __("Well done!", 'wish'),
            "admin_label" => false,
        ),
    
        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("You successfully read this important alert message.", 'wish'),
            "description" => __("The details below the title", 'wish'),
            "admin_label" => false,
        ),

        /*Text*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Text Font", "wish" ),
            "param_name" => "text_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Text Size", "wish"),
            "param_name" => "text_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Text Color", "wish" ),
            "param_name" => "text_color",
            "value" => '#3c763d ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Alerts extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title'         => 'Alerts',
            'title_font'    => '',
            'title_size'    => '40',
            'title_color'   => '#000',

            'subtitle'          => 'Bootstrap Alerts',
            'subtitle_font'     => '',
            'subtitle_size'     => '20',
            'subtitle_color'    => '#000',
            'bgcolor'           => '#fff'  
          ), $atts ) );

        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        $decode_font = urldecode($subtitle_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $subtitle_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


      $output = "<div class='alerts' style='background-color:{$bgcolor}'>
                <div class='container'>
                <div class='row category-caption'>
                    <div class='col-lg-12'>
                        <h1 class='heading' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                    </div>
                </div>
                <div class='row'>
                    <div class='col-lg-12'>
                        <h1 class='heading2' style='font-family:{$subtitle_font_family};font-size:{$subtitle_size}px;color:{$subtitle_color};'>{$subtitle}</h1>
                    " . do_shortcode($content) . "
                
            </div>
            </div>
                </div>
            </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Alerts_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'title'   => 'Well done!',
            'details' => 'You successfully read this important alert message.',
            'text_font'     => '',
            'text_size'     => '14',
            'text_color'    => '#3c763d',
            'alert_type' => '',
          ), $atts ) );

        $decode_font = urldecode($text_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $text_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

            $output = "<div class='alert alert-{$alert_type}' style='font-family:{$text_font_family};font-size:{$text_size}px;color:{$text_color};'>
                                <i class='icon-gift'></i><strong>{$title}</strong>{$details}
                            </div>";
            return $output;
        }

}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>