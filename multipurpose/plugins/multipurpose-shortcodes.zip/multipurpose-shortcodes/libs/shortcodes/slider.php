<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');
// shortcode Sliders

add_shortcode('slider', 'multipurpose_slider');
add_shortcode('slide', 'multipurpose_slide');
add_shortcode('slide_content', 'multipurpose_slide_content');

function multipurpose_slider($atts, $content = null) {
    $output = '<section class="portfolio-slider slider">';
    $output .= do_shortcode($content);
    $output .= '</section>';
    return $output;
}

function multipurpose_slide($atts, $content = null) {
    $output = '<article>';
    if (!empty($atts['image_url']) && $atts['image_url'] != 'Image url') {
        $output .= '<img src="' . $atts["image_url"] . '" alt="' . $atts['image_alt'] . '">';
    }
    $output .= '<div><h3>' . $atts["title"] . '</h3>' . do_shortcode($content) . '
            </div>
    </article>';
    return $output;
}

function multipurpose_slide_content($atts, $content = null) {
    $output = '<p>'.$content.'</p>';
    return $output;
}
