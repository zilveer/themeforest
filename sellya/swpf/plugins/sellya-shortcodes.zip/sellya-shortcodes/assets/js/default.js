/**
 *	@package Default.js
 *	@desc shortcodes jquery lib
 *	Developed by Smart Data soft team
 *
 */
 
(function($){
	
	$.fn.sellya_js = function(opts){
		
		var options = $.extend({
			
			accordionElem : $('.accordion'),
			
			tabsElem : $('.sellya_tabs'),
			
			toggleElem : $('.toggle-box h2.trigger'),
			
		}, opts );
		
		
		options.accordionElem.accordion({collapsible:true,active:false,heightStyle:"content"});
		
		options.tabsElem.tabs();
		
		options.toggleElem.toggle(function(){
			
			h2 = $(this);
			
			h2.addClass('active');
			
			h2.next('.toggle_container').slideDown(300);
			
		},function(){
			
			h2 = $(this);
			
			h2.removeClass('active');
			
			h2.next('.toggle_container').slideUp(300);
			
			
		});
		
		
	};
	
	
}(jQuery));
 

jQuery.fn.sellya_js();