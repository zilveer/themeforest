<?php
/**
 * Display videos
 * @author: createIT
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class ctWooVideoDisplay
{

    public function __construct()
    {
        add_action('woocommerce_before_shop_loop', array($this, 'renderListVideo'), 1);
        add_action('woocommerce_before_single_product', array($this, 'displayVideos'));

        //register shortcodes
        add_shortcode('ct_woovideo', array($this, 'renderVideoShortcode'));
        add_shortcode('ct_woovideo_button', array($this, 'renderButtonShortcode'));
    }

    /**
     * Get videos location and trigger functions in proper hooks
     */

    public function displayVideos(){


        //get the videos
        $videos = $this->getVideos();

        if ($videos) {
            foreach ($videos as $video) {

                $gal_loc = $video['_gallery_location'];

                //get video location
                switch ($video['_location']) {
                    case 'tab':
                        if ($video['_video_url']) {
                            add_filter('woocommerce_product_tabs', array($this, 'addVideoTab'), (!empty($video['_video_location_priority']) ? esc_attr($video['_video_location_priority']) : 100));
                        }
                        break;
                    case 'image_gallery':
                        add_action('woocommerce_before_single_product', array($this, 'displayVideoInGallery'), (!empty($video['_video_location_priority']) ? esc_attr($video['_video_location_priority']) : 100));
                        add_action( 'wp_footer', array($this, 'renderStyleThumbnailIcons'), 1000 );
                        if ($gal_loc == 'in') {
                            add_action( 'wp_footer', array($this, 'renderInGalleryScript'), 1000 );
                        }
                        break;
                    case 'button':
                        add_action( 'woocommerce_before_single_product', array($this, 'inputPopupVideos'), (!empty($video['_video_location_priority']) ? esc_attr($video['_video_location_priority']) : 100) );
                        switch ($video['_button_location']){
                            case 'after_add_to_cart_button':
                                add_action('woocommerce_after_add_to_cart_button', array($this, 'renderButtonAfterCart'), (!empty($video['_button_location_priority']) ? esc_attr($video['_button_location_priority']) : 100));
                                break;
                            case 'after_product_info':
                                add_action('woocommerce_short_description', array($this, 'renderButtonAfterInfo'),(!empty($video['_button_location_priority']) ? esc_attr($video['_button_location_priority']) : 100));
                                break;
                            case 'product_gallery':
                                add_action('woocommerce_product_thumbnails', array($this, 'renderButtonInGallery'), (!empty($video['_button_location_priority']) ? esc_attr($video['_button_location_priority']) : 100));
                                break;
                            case 'above_tabs':
                                add_action('woocommerce_single_product_summary', array($this, 'renderButtonAboveTabs'), (!empty($video['_button_location_priority']) ? esc_attr($video['_button_location_priority']) : 100));
                                break;
                            case 'tab':
                                if ($video['_video_url']) {
                                    add_filter('woocommerce_product_tabs', array($this, 'addVideoTab'), (!empty($video['_button_location_priority']) ? esc_attr($video['_button_location_priority']) : 100));
                                }
                                break;
                            case 'shortcode':
                                break;
                        };
                        add_action('wp_footer', array($this, 'overlayColor'));
                        break;
                    case 'shortcode' :

                        break;
                }

            }
        }

    }

    /**
     * Get videos metadata
     * @return mixed
     */

    protected function getVideos(){

        $post_id = get_the_ID();

        if (is_product()) {
            $videos = get_post_meta($post_id, '_ct_woovideo_videos', true);

        } elseif (is_shop() || is_product_category() || is_product_tag() | is_product_taxonomy()) {

            $video = array();

            $video['_image_url'] = '';
            $video['_video_clearing'] = '';
            $video['_location'] = 'list';
            $video['_video_class'] = get_option('wc_ct_woovideo_list_video_class');
            $video['_video_autoplay'] = get_option('wc_ct_woovideo_list_video_autoplay');
            $video['_global_id'] = 'list';
            $video['_video_align'] = '';
            $video['_video_margin_left'] = get_option('wc_ct_woovideo_list_video_margin_left');
            $video['_video_margin_top'] = get_option('wc_ct_woovideo_list_video_margin_top');
            $video['_video_margin_right'] = get_option('wc_ct_woovideo_list_video_margin_right');
            $video['_video_margin_bottom'] = get_option('wc_ct_woovideo_list_video_margin_bottom');
            $video['_external_url'] = get_option('wc_ct_woovideo_list_video_external_url');
            $video['_iframe_url'] = get_option('wc_ct_woovideo_list_iframe_url');
            $video['_player_height'] = get_option('wc_ct_woovideo_list_player_height');
            $video['_player_width'] = get_option('wc_ct_woovideo_list_player_width');
            $video['_upload_video_mp4_url'] = get_option('wc_ct_woovideo_list_video_mp4_url');
            $video['_upload_video_webm_url'] = get_option('wc_ct_woovideo_list_video_webm_url');
            $video['_upload_video_ogg_url'] = get_option('wc_ct_woovideo_list_video_ogg_url');

            if (!empty($video['_external_url'])) {
                $video['_video_url'] = true;
            }

            if (!empty($video['_iframe_url'])) {
                $video['_video_url'] = true;
            }

            if (!empty($video['_upload_video_mp4_url'])) {
                $video['_upload_video_mp4_url'] = wp_get_attachment_url($video['_upload_video_mp4_url']);
                $type = wp_check_filetype($video['_upload_video_mp4_url']);
                if ($type['type'] != 'video/mp4') {
                    $video['_upload_video_mp4_url'] = null;
                } else {
                    $video['_video_url'] = true;
                }
            }
            if (!empty($video['_upload_video_webm_url'])) {
                $video['_upload_video_webm_url'] = wp_get_attachment_url($video['_upload_video_webm_url']);
                $type = wp_check_filetype($video['_upload_video_webm_url']);
                if ($type['type'] != 'video/webm') {
                    $video['_upload_video_webm_url'] = null;
                } else {
                    $video['_video_url'] = true;
                }
            }
            if (!empty($video['_upload_video_ogg_url'])) {
                $video['_upload_video_ogg_url'] = wp_get_attachment_url($video['_upload_video_ogg_url']);
                $type = wp_check_filetype($video['_upload_video_ogg_url']);
                if ($type['type'] != 'video/ogg') {
                    $video['_upload_video_ogg_url'] = null;
                } else {
                    $video['_video_url'] = true;
                }
            }

            $videos = array (
                0 => $video,
            );

        }
        return $videos;
    }

    /**
     * Display video html
     * @param $video
     * @return string
     */

    protected function displayVideo($video)
    {

        $iframe_enabled = get_option('wc_ct_woovideo_iframe_enabled');

        if ($video['_video_autoplay'] == 'on') {
            add_action('wp_footer', array($this, 'renderAutoplayScript'), 1000);
        }

        $display = (($video['_location'] != 'shortcode') ? '<div ' : '<span ');
        $display .= ' class="ct-woovideo-video ' . (!empty($video['_video_class']) ? ' ' . esc_attr($video['_video_class']) : '') . '"';
        $display .= ' id="ct-woovideo-video-' . esc_attr($video['_global_id']) . '" ';
        $display .= ' data-video="' . $video['_image_url'] . '"';

        $styles = apply_filters('ct_woovideo_video_styles', array(
            'float' => (!empty($video['_video_align'])) ? esc_attr($video['_video_align']) : '',
            'margin-left' => (!empty($video['_video_margin_left'])) ? esc_attr($video['_video_margin_left']) . 'px' : '',
            'margin-top' => (!empty($video['_video_margin_top'])) ? esc_attr($video['_video_margin_top']) . 'px' : '',
            'margin-right' => (!empty($video['_video_margin_right'])) ? esc_attr($video['_video_margin_right']) . 'px' : '',
            'margin-bottom' => (!empty($video['_video_margin_bottom'])) ? esc_attr($video['_video_margin_bottom']) . 'px' : '',
            'max-width' => (!empty($video['_player_width'])) ? esc_attr($video['_player_width']) . 'px' : '',
            'max-height' => (!empty($video['_player_height'])) ? esc_attr($video['_player_height']) . 'px' : '',
        ));

        $style = '';

        if (!empty($styles)) {
            foreach ($styles as $key => $value) {
                if (!empty($value)) {
                    $style .= $key . ':' . $value . ';';
                }
            }

            if (!empty($style)) {
                $display .= 'style ="';
                $display .= $style;
                $display .= '"';
            }

        }

        $display .= '>';

        if (!empty($video['_external_url'])) {

            $args = array(
                'height' => !empty($video['_player_height']) ? $video['_player_height'] : 0,
                'width' => !empty($video['_player_width']) ? $video['_player_width'] : 0,
            );
            $embed_code = wp_oembed_get(esc_url($video['_external_url']), $args);
            $display .= $embed_code;

        } elseif (!empty($video['_iframe_url']) && $iframe_enabled == 'on'){

            $display .= apply_filters('ct_woovideo_generic_iframe', '<iframe class="ct-woovideo-generic-iframe" src="' . $video['_iframe_url'] . '"' . (!empty($video['_player_width']) ? 'width="' . $video['_player_width'] . '" ' : '') . (!empty($video['_player_height']) ? 'height="' . $video['_player_height'] . '" ' : '') . ' class="ct-woovideo-generic-iframe"></iframe>');

        } elseif (!empty($video['_upload_video_mp4_url']) || !empty($video['_upload_video_webm_url']) || !empty($video['_upload_video_ogg_url'])) {

            $display .= '<video controls preload="auto" ';

            $display .= 'class=""';
            if (!empty($video['_player_width'])) {
                $display .= ' width="' . esc_attr($video['_player_width']) . '"';
            }
            if (!empty($video['_player_height'])) {

                $display .= ' height="' . esc_attr($video['_player_height']) . '"';
            }

            $display .= '>';

            if (!empty($video['_upload_video_mp4_url'])) $display .= '<source src="' . esc_url($video['_upload_video_mp4_url']) . '" type="video/mp4"/>';
            if (!empty($video['_upload_video_webm_url'])) $display .= '<source src="' . esc_url($video['_upload_video_webm_url']) . '" type="video/webm"/>';
            if (!empty($video['_upload_video_ogg_url'])) $display .= '<source src="' . esc_url($video['_upload_video_ogg_url']) . '" type="video/ogg"/>';
            $display .= '</video>';
        }

        if ($video['_location'] == 'image_gallery') {
            $display .= '<a href="#" class="ct-woovideo-close-video"></a>';
        }

        $display .= (($video['_location'] != 'shortcode') ? '</div>' : '</span>' );

        if ($video['_video_clearing'] == 'on') {
            $display .= '<div class="clearfix"></div>';
        }

        return apply_filters('ct_woovideo_display_video', $display);
    }

    /**
     * Display popup button html
     * @param $video
     * @return mixed|void
     */

    protected function displayButton($video){

        if ($video['_button_label'] == 'title'){
            $label = esc_html($video['_title']);
        } elseif ($video['_button_label'] == 'custom') {
            $label = esc_html($video['_custom_button_label']);
        } elseif (($video['_button_label'] == 'thumbnail')&&(!empty($video['_image']))) {
            add_action( 'wp_footer', array($this, 'renderStyleThumbnailIcons'), 1000 );
            $background_url = esc_url($video['_image']);
            $label = '';
            $height = !empty($video['_button_height']) ? esc_attr($video['_button_height']) : '';
            $width = !empty($video['_button_width']) ? esc_attr($video['_button_width']) : '';
        } else {
            $label = esc_html($video['_title']);
            $background_url = '';
        }

        $display ='';

        $display .= '<a href="#ct-woovideo-video-' . $video['_global_id'] . '"';
        $display .= ' class="ct-woovideo-button button' . (!empty($video['_button_class']) ? ' ' . esc_attr($video['_button_class']) : '') . '"';
        $display .= ' rel="' . esc_attr($video['_id']) . '"';

        $styles = apply_filters('ct_woovideo_button_styles', array(
            'float' => (!empty($video['_button_align'])) ? esc_attr($video['_button_align']) : '',
            'margin-left' => (!empty($video['_button_margin_left'])) ? esc_attr($video['_button_margin_left']) . 'px' : '',
            'margin-top' => (!empty($video['_button_margin_top'])) ? esc_attr($video['_button_margin_top']) . 'px' : '',
            'margin-right' => (!empty($video['_button_margin_right'])) ? esc_attr($video['_button_margin_right']) . 'px' : '',
            'margin-bottom' => (!empty($video['_button_margin_bottom'])) ? esc_attr($video['_button_margin_bottom']) . 'px' : '',
            'padding-left' => (!empty($video['_button_padding_left'])) ? esc_attr($video['_button_padding_left']) . 'px' : '',
            'padding-top' => (!empty($video['_button_padding_top'])) ? esc_attr($video['_button_padding_top']) . 'px' : '',
            'padding-right' => (!empty($video['_button_padding_right'])) ? esc_attr($video['_button_padding_right']) . 'px' : '',
            'padding-bottom' => (!empty($video['_button_padding_bottom'])) ? esc_attr($video['_button_padding_bottom']) . 'px' : '',
            'border-radius' => (!empty($video['_button_border_radius'])) ? esc_attr($video['_button_border_radius']) . 'px' : '',
            'background' => (!empty($video['_button_color'])) ? esc_attr($video['_button_color']) : '',
            'border-color' => (!empty($video['_button_color'])) ? esc_attr($video['_button_color']) : '',
            'color' => (!empty($video['_button_text_color'])) ? esc_attr($video['_button_text_color']) : '',
        ));

        if(!empty($background_url)) {

            $styles['background-image'] = "url('" .  esc_url($background_url) . "')";
            $styles['background-size'] = 'cover';
            $styles['background-repeat'] = 'no-repeat';
            $styles['display'] = 'block';
            $styles['height'] = absint($height) . 'px';
            $styles['width'] = absint($width) . 'px';
            $styles['padding-left'] = 0;
            $styles['padding-top'] = 0;
            $styles['padding-right'] = 0;
            $styles['padding-bottom'] = 0;
        }

        $style = '';

        if (!empty($styles)) {
            foreach ($styles as $key => $value) {
                if (!empty($value)){
                    $style .= $key . ':' . $value . ';';
                }
            }

            if (!empty($style)) {
                $display .= 'style ="';
                $display .= $style;
                $display .= '"';
            }

        }

        if (($video['_button_label'] == 'thumbnail')&&(!empty($video['_image']))) {
            $display .= '>' . $label . '<span></span></a>';
        } else {
            $display .= '>' . $label . '</a>';
        }

        if ($video['_button_clearing'] == 'on') {
            $display .= '<div class="clearfix"></div>';
        }

        return apply_filters('ct_woovideo_display_button', $display);
    }

    /**
     * Display video on top of the products list
     */

    public function renderListVideo(){

        $videos = $this->getVideos();
        $video = $videos[0];

        if (!empty($video['_upload_video_mp4_url']) || !empty ($video['_upload_video_webm_url']) || !empty($video['_upload_video_ogg_url']) || !empty($video['_external_url']) || !empty($video['_iframe_url'])) {

            if ($video['_video_autoplay'] == 'on') {
                add_action( 'wp_footer', array($this, 'renderAutoplayScript'), 1000 );
            }

            echo $this->displayVideo($video);

        } else {
            return;
        }
    }

    /**
     * Add 'Videos' to product tabs
     * @param $tabs
     * @return mixed
     */

    public function addVideoTab($tabs)
    {

        $tabs['videos'] = array(
            'title' => __( 'Videos', 'ct-woovideo' ),
            'priority' => 1,
            'callback' => array($this, 'renderVideoTabContent')
        );
        return $tabs;

    }

    /**
     * Render videos and buttons in 'Videos' product tab
     */

    public function renderVideoTabContent(){

        $videos = $this->getVideos();

        foreach ($videos as $video) {
            if ($video['_video_url']) {
                if ($video['_location'] == 'tab') {

                    echo $this->displayVideo($video);
                }
                if ($video['_location'] == 'button') {
                    if ($video['_button_location'] == 'tab') {
                        echo $this->displayButton($video);
                    }
                }
            }
        }
    }

    /**
     * Input videos to page for Magnific Popup
     */

    public function inputPopupVideos()
    {
        $videos = $this->getVideos();

        foreach ($videos as $video) {
            if ($video['_video_url']) {
                if ($video['_location'] == 'button') {
                    echo '<div class="ct-woovideo-popup-video mfp-hide">';
                    echo $this->displayVideo($video);
                    echo '</div>';
                }
            }
        }
    }

    /**
     * Render button after 'add to cart' button
     */

    public function renderButtonAfterCart(){

        $videos = $this->getVideos();

        foreach ($videos as $video) {
            if ($video['_video_url']) {
                if ($video['_location'] == 'button') {
                    if ($video['_button_location'] == 'after_add_to_cart_button') {
                        echo $this->displayButton($video);
                    }
                }
            }
        }
    }

    /**
     * Render button after product info
     */

    public function renderButtonAfterInfo(){

        $videos = $this->getVideos();

        foreach ($videos as $video) {
            if ($video['_video_url']) {
                if ($video['_location'] == 'button') {
                    if ($video['_button_location'] == 'after_product_info') {
                        echo $this->displayButton($video);
                    }
                }
            }
        }
    }

    /**
     * Render button under product galley
     */

    public function renderButtonInGallery() {

    $videos = $this->getVideos();


        foreach ($videos as $video) {
            if ($video['_video_url']) {
                if ($video['_location'] == 'button') {
                    if ($video['_button_location'] == 'product_gallery') {
                        echo $this->displayButton($video);
                    }
                }
            }
        }
    }

    /**
     * Render button above product tabs
     */

    public function renderButtonAboveTabs(){
        $videos = $this->getVideos();

        foreach ($videos as $video) {
            if ($video['_video_url']) {
                if ($video['_location'] == 'button') {
                    if ($video['_button_location'] == 'above_tabs') {
                        echo $this->displayButton($video);
                    }
                }
            }
        }
    }

    /**
     * Render button from shortcode
     * @param $atts
     * @return mixed|void
     */

    public function renderButtonShortcode($atts){
        $a = shortcode_atts(array(
            'id' => null,
        ), $atts);

        $videos = $this->getVideos();

        foreach ($videos as $video) {

            if ($video['_video_url']) {
                if ($video['_location'] == 'button') {
                    if ($video['_button_location'] == 'shortcode') {
                        if ($video['_id'] == $a['id']) {

                        return $this->displayButton($video);
                        }
                    }
                }
            }
        }
    }

    /**
     * Render video from shortcode
     * @param $atts
     * @return string
     */

    public function renderVideoShortcode($atts){
        $a = shortcode_atts(array(
            'id' => null,
        ), $atts);

        $videos = $this->getVideos();

        foreach ($videos as $video) {
            if ($video['_video_url']) {
                if ($video['_location'] == 'shortcode') {
                    if ($video['_id'] == $a['id']) {

                        return $this->displayVideo($video);
                    }
                }
            }
        }
    }

    /**
     * Render video in product gallery
     */

    public function displayVideoInGallery(){

        $videos = $this->getVideos();

        global $product;
        $attachment_ids = $product->get_gallery_attachment_ids();

        $classes = apply_filters('ct_woovideo_gallery_videos', array());
        if (!empty($classes)) {
            $classes = implode(' ', $classes);
        }
        $gallery_videos = '<div class="ct-woovideo-gallery-videos' . ((!empty($classes)) ? ' ' . esc_attr($classes) : '') . '">';

        echo $gallery_videos;

        foreach ($attachment_ids as $attachment_id) {
            $image_link = wp_get_attachment_url($attachment_id);

            foreach ($videos as $video) {
                if($video['_video_url']){

                    if (($video['_thumbnail_id'] == $attachment_id) && ($video['_location'] == 'image_gallery')) {

                        if ($video['_image_url'] == $image_link) {

                            echo $this->displayVideo($video);
                        }
                    }
                }
            }
        }

        echo '</div>';

    }

    /**
     * Get overlay color for Magnific Popup
     */

    public function overlayColor(){
         echo '<style>.mfp-bg.ct-woovideo-active{background:' . esc_attr(get_option('wc_ct_woovideo_overlay_color')) . ';}</style>';
    }

    /**
     * Render thumbnail icons
     */

    public function renderStyleThumbnailIcons() {

        $videos = $this->getVideos();

        global $product;
        $attachment_ids = $product->get_gallery_attachment_ids();

        foreach ($videos as $video) {

            $selector = null;

            if ($video['_video_url']) {

                if ($video['_location'] == 'image_gallery') {

                    foreach ($attachment_ids as $attachment_id) {

                        $image_link = wp_get_attachment_url($attachment_id);

                        if (($video['_thumbnail_id'] == $attachment_id)) {

                            if ($video['_image_url'] == $image_link) {

                                if ($video['_thumbnail_icon'] != 'none') {

                                    $selector = '.ct-woovideo-gallery-thumbnail[data-videorel="' . $image_link . '"] span';

                                }
                            }
                        }
                    }
                }
                 elseif ($video['_location'] == 'button') {

                    if (($video['_button_label'] == 'thumbnail')&&(!empty($video['_image']))) {

                        if ($video['_thumbnail_icon'] != 'none') {

                            $selector = '.ct-woovideo-button[rel="' . esc_attr($video['_id']) . '"] span';
                        }
                    }
                }

                if (!empty($selector)) {

                    $display = '';

                    $styles = apply_filters('ct_woovideo_icon_styles', array(
                        'position' => 'absolute',
                        'background-image' => (!empty($video['_icon_url']) ? 'url("' . $video['_icon_url'] . '")' : '') ,
                        'background-size' => 'contain',
                        'background-repeat' => 'no-repeat',
                        'opacity' => (!empty($video['_icon_opacity']) ? ('0.' . esc_attr($video['_icon_opacity'])) : '0'),
                        'display' => 'block',
                        'z-index' => '1',
                        'width' => (!empty($video['_icon_size']) ? (esc_attr($video['_icon_size']) . '%') : '0'),
                        'height' => (!empty($video['_icon_size']) ? (esc_attr($video['_icon_size']) . '%') : '0'),
                    ));

                    if ($video['_icon_opacity'] == 10) {
                        $styles['opacity'] = '1';
                    }


                    if ($video['_icon_position'] == 'top_left') {
                        $styles['top'] = '5%';
                        $styles['left'] = '5%';
                    }
                    elseif ($video['_icon_position'] == 'top_right') {
                        $styles['top'] = '5%';
                        $styles['right'] = '5%';
                    }
                    elseif ($video['_icon_position'] == 'bottom_left') {
                        $styles['bottom'] = '5%';
                        $styles['left'] = '5%';
                    }
                    elseif ($video['_icon_position'] == 'bottom_right') {
                        $styles['bottom'] = '5%';
                        $styles['right'] = '5%';
                    } else {
                        $styles['top'] = '50%';
                        $styles['left'] = '50%';
                        $styles['margin-left'] = (!empty($video['_icon_size']) ? ('-' . esc_attr($video['_icon_size'])/2 . '%') : '');
                        $styles['margin-top'] = (!empty($video['_icon_size']) ? ('-' . esc_attr($video['_icon_size'])/2 . '%') : '');
                    }

                    if (!empty($styles)) {

                        $style = '';


                        foreach ($styles as $key => $value) {
                            if (!empty($value)){
                                $style .= $key . ':' . $value . ';';
                            }
                        }

                        if (!empty($style)) {
                            $display .= '<style>' . $selector . '{';
                            $display .= $style;
                            $display .= '}</style>';
                        }
                        echo $display;
                    }
                }
            }
        }
    }

    /**
     * Javascript to display video in featured image window
     */

    public function renderInGalleryScript()
    {
        $videos = $this->getVideos();

        if(!empty($videos)) {
            $script = '<script>jQuery( function ( $ ) {';

            $script .= "$('.images, .thumbnailSlider').on( 'click', '";

            foreach ($videos as $video) {
                if (!empty($video['_video_url'])) {
                    if ($video['_location']=='image_gallery') {
                        if ($video['_gallery_location']=='in') {

                            $script .= " .ct-woovideo-gallery-thumbnail[data-videorel=\"" . $video['_image_url'] . "\"],";

                        }
                    }
                }
            }

            $script = rtrim($script, ',');

            $script .= "', function(e){

                 e.preventDefault();
                 var active_video = $(document).find('.ct-woovideo-active').data('video');
                 var this_button = $(this).data('videorel');
                 if (this_button == active_video) {
                     return;
                 }

                var image = $('.ct-woovideo-gallery-videos').find('.woocommerce-main-image');

                if ($(image).length == 0) {
                     var image = $('.ct-woovideo-gallery-videos').find('.attachment-shop_single');
                }

                $(image).removeClass('hidden').detach();

                var active_video = $( '.images, .thumbnailSlider')
                    .find('.ct-woovideo-active').removeClass('ct-woovideo-active')
                    .addClass('ct-woovideo-hidden')
                    .replaceWith(image);
                $(active_video).appendTo( '.ct-woovideo-gallery-videos' )
                    .trigger('classHiddenAdded');

                 if (($(active_video).hasClass('ct-woovideo-hidden')) && ($(active_video).css('display') != 'none')) {
                    $(active_video).css('display', 'none');
                 }

                  var thumbrel = $(this).data('videorel');

                  var video =  $('.ct-woovideo-gallery-videos').find('.ct-woovideo-video[data-video=\"'+thumbrel+'\"]');

                  var gal_video = $(video).detach();
                  var image = $('.woocommerce-main-image[data-videorel=\"' + thumbrel + '\"]');
                  if ($(image).length == 0) {
                     var image = $('.images').find('.attachment-shop_single');
                     console.log(image);
                  }
                  $(image).replaceWith(gal_video);
                  $(image).appendTo( '.ct-woovideo-gallery-videos' ).addClass('hidden');

               });

               $('.images img, .thumbnailSlider img, .ct-woovideo-button').click(function () {

                   var image = $('.ct-woovideo-gallery-videos').find('.woocommerce-main-image');
                   if ($(image).length == 0) {
                     var image = $('.ct-woovideo-gallery-videos').find('.attachment-shop_single');
                   }
                   var gal_video = $('.images, .thumbnailSlider').find('.ct-woovideo-video');
                   $(image).removeClass('hidden').detach();
                   $(gal_video).removeClass('ct-woovideo-active').addClass('ct-woovideo-hidden').trigger('classHiddenAdded');
                   $(gal_video).replaceWith(image);
                   $(gal_video).appendTo( '.ct-woovideo-gallery-videos' );
                   if (($(gal_video).hasClass('ct-woovideo-hidden')) && ($(gal_video).css('display') != 'none')) {
                    $(gal_video).css('display', 'none');
                   }

                });
            ";

            $script .= '});</script>';
            echo $script;
        }
    }

    /**
     * Javascript to handle autoplay
     */

    public function renderAutoplayScript() {

        $videos = $this->getVideos();

        $script = '<script>jQuery( function ( $ ) {';

        foreach ($videos as $video) {

            if (!empty($video['_video_url'])) {

                if ($video['_video_autoplay']=='on') {

                    if (!empty($video['_external_url'])) {

                        //autoplay for youtube videos

                        if( $this->isYoutube($video['_external_url']) ) {

                            if ($video['_location']=='image_gallery') {
                                $script .= "

                                $('.images, .thumbnailSlider').on('click', '.ct-woovideo-gallery-thumbnail[data-videorel=\"" . $video['_image_url'] . "\"]', function(){

                                   var iframe = $('.ct-woovideo-video[data-video=\"" . $video['_image_url'] . "\"] iframe');

                                    if (iframe[0].src.indexOf('&autoplay=1') == -1) {
                                            iframe[0].src += '&autoplay=1';

                                        }

                                });
                            ";
                            } elseif ($video['_location']=='button') {
                                $script .= "
                                    $('.single-product').on('click', '.ct-woovideo-button[href=\"#ct-woovideo-video-" . $video['_global_id'] . "\"]', function(){

                                        var iframe = $('.ct-woovideo-video[id=\"ct-woovideo-video-" . $video['_global_id'] . "\"] iframe');

                                        if (iframe[0].src.indexOf('&autoplay=1') == -1) {
                                            iframe[0].src += '&autoplay=1';
                                        }
                                    });
                                ";
                            }  elseif ($video['_location']=='tab') {

                                $script .= "

                                    $('a[href=\"#tab-videos\"]').click( function(){

                                        var iframe = $('.ct-woovideo-video[id=\"ct-woovideo-video-" . $video['_global_id'] . "\"] iframe');

                                        if (iframe[0].src.indexOf('&autoplay=1') == -1) {
                                            iframe[0].src += '&autoplay=1';
                                        }
                                    });
                                ";
                            } elseif ($video['_location']=='list') {
                                $script .= "$('#ct-woovideo-video-list iframe')[0].src += '&autoplay=1';";
                            } else {

                                $script .= "$('.ct-woovideo-video[id=\"ct-woovideo-video-" . $video['_global_id'] . "\"] iframe')[0].src += '&autoplay=1';";
                            }

                        } elseif ($this->isVimeo($video['_external_url'])) {

                            //autoplay for vimeo

                            $script .= "
                            ";

                            if ($video['_location']=='image_gallery') {
                                $script .= "

                                $('.images, .thumbnailSlider').on('click', '.ct-woovideo-gallery-thumbnail[data-videorel=\"" . $video['_image_url'] . "\"]', function(){

                                    var player = $('.ct-woovideo-video[data-video=\"" . $video['_image_url'] . "\"] iframe');

                                    ctWoovideoVimeoAutoplay(player, 'play');
                                });
                            ";
                            } elseif ($video['_location']=='button') {
                                $script .= "
                                    $('.single-product').on('click', '.ct-woovideo-button[href=\"#ct-woovideo-video-" . $video['_global_id'] . "\"]', function(){

                                        var player = $('.ct-woovideo-video[id=\"ct-woovideo-video-" . $video['_global_id'] . "\"] iframe');

                                        ctWoovideoVimeoAutoplay(player, 'play');
                                    });
                                ";
                            }  elseif ($video['_location']=='tab') {

                                $script .= "

                                    $('a[href=\"#tab-videos\"]').click( function(){

                                        var player = $('.ct-woovideo-video[id=\"ct-woovideo-video-" . $video['_global_id'] . "\"] iframe');

                                        ctWoovideoVimeoAutoplay(player, 'play');
                                    });
                                ";
                            } elseif ($video['_location']=='list') {

                                $script .= "var player = $('#ct-woovideo-video-list iframe');
                                ctWoovideoVimeoAutoplay(player, 'play');";


                            } else {

                                $script .= "var player = $('.ct-woovideo-video[id=\"ct-woovideo-video-" . $video['_global_id'] . "\"] iframe');
                                ctWoovideoVimeoAutoplay(player, 'play');";
                            }

                        }
                    } elseif ((!empty($video['_upload_video_mp4_url']) || !empty($video['_upload_video_webm_url']) || !empty($video['_upload_video_ogg_url'])) && empty($video['_external_url'])) {

                        //autoplay for html5 uploaded videos

                            if ($video['_location']=='image_gallery') {
                                $script .= "

                                $('.images, .thumbnailSlider').on('click', '.ct-woovideo-gallery-thumbnail[data-videorel=\"" . $video['_image_url'] . "\"]', function(){

                                    $('.ct-woovideo-video[data-video=\"" . $video['_image_url'] . "\"] video').get(0).play();
                                });
                            ";
                            } elseif ($video['_location']=='button') {
                                $script .= "
                                    $('.single-product').on('click', '.ct-woovideo-button[href=\"#ct-woovideo-video-" . $video['_global_id'] . "\"]', function(){

                                        $('.ct-woovideo-video[id=\"ct-woovideo-video-" . $video['_global_id'] . "\"] video').get(0).play();
                                    });
                                ";
                            }  elseif ($video['_location']=='tab') {

                                $script .= "

                                    $('a[href=\"#tab-videos\"]').click( function(){

                                        $('.ct-woovideo-video[id=\"ct-woovideo-video-" . $video['_global_id'] . "\"] video').get(0).play();
                                    });
                                ";
                            } elseif ($video['_location']=='list') {

                                $script .= "$('#ct-woovideo-video-list video').get(0).play();";

                            } else {

                                $script .= "$('.ct-woovideo-video[id=\"ct-woovideo-video-" . $video['_global_id'] . "\"] video').get(0).play();";
                            }
                    }
                }
            }
        }

        $script .= '});</script>';
        echo $script;
    }

    /**
     * Check if the link is from Youtube
     * @param $url
     * @return bool
     */

    protected function isYoutube($url) {
        if( preg_match( '/^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/' , $url ) ) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Check if the link is from Vimeo
     * @param $url
     * @return bool
     */

    protected function isVimeo($url) {
        if( preg_match( '/https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/' , $url ) ) {
            return true;
        } else {
            return false;
        }
    }
}

new ctWooVideoDisplay();






