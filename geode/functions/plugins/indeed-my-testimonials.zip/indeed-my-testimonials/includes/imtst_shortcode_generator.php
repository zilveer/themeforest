<?php





$shortcode_arr = imtst_init_plugin_arr();





?>





<script>





var dir_url = '<?php echo $dir_url;?>';





jQuery(document).ready(function(){





    imtst_preview();





});





</script>





<div id="main">





<div class="ict_wrap">





<div>





    <h1>Shortcode Generator</h1>





     <div>





        <div class="box-title">





            <h3><i class="icon-cogs"></i>Settings</h3>





            <div class="actions pointer">





			    <a onclick="jQuery('#the_shc_settings').slideToggle();" class="btn btn-mini content-slideUp">





                    <i class="icon-angle-down"></i>





                </a>





			</div>





            <div class="clear"></div>





        </div>











         <div id="the_shc_settings" class="ict_settings_wrapp">





            <div class="ict_column column_one">





                    <h4>Display Entrires:</h4>





                        <table>





                            <tr>





                                <td>





                                    Group:





                                </td>





                                <td>





                                    <select id="group" onClick="imtst_preview();" class="ict_select_field_vl">





                                            <?php $selected = imtst_checkIfSelected($shortcode_arr['group'], 'all', 'select');?>





                                        <option value="all" <?php echo $selected;?>>All</option>





                                         <?php





                                            $args = array('taxonomy'=>'testimonial_groups',





                                                            'type'=>'testimonials');





                                            $cats = get_categories($args);





                                            foreach($cats as $cat){





                                                $selected = imtst_checkIfSelected($shortcode_arr['group'], $cat->slug, 'select');





                                                ?>





                                              <option value="<?php echo $cat->slug;?>" <?php echo $selected;?> ><?php echo $cat->name;?></option>





                                                <?php





                                            }





                                         ?>





                                    </select>





                                </td>





                            </tr>





                            <tr>





                                <td>





                                    Number Of Entries:





                                </td>





                                <td>





                                    <input type="number" min="1" max="" id="limit" value="<?php echo $shortcode_arr['limit'];?>" onChange="imtst_preview();" onKeyup="imtst_preview();" class="ict_input_num_field"/>





                                </td>





                            </tr>





                            <tr>





                                 <td colspan="2">





                                    <div class="spacewp_b_divs"></div>





                                 </td>





                            </tr>





                            <tr>





                                <td>





                                    Order By:





                                </td>





                                <td>





                                    <select id="order_by" onClick="imtst_preview();" class="ict_select_field_vl">





                                            <?php $selected = imtst_checkIfSelected($shortcode_arr['order_by'], 'date', 'select');?>





                                        <option value="date" <?php echo $selected;?>>Date</option>





                                            <?php $selected = imtst_checkIfSelected($shortcode_arr['order_by'], 'name', 'select');?>





                                        <option value="name" <?php echo $selected;?>>Name</option>





                                    </select>





                                </td>





                            </tr>





                            <tr>





                                <td>





                                    Order Type:





                                </td>





                                <td>





                                    <select id="order" onClick="imtst_preview();" class="ict_select_field_vl">





                                            <?php $selected = imtst_checkIfSelected($shortcode_arr['order'], 'ASC', 'select');?>





                                        <option value="ASC" <?php echo $selected;?> >ASC</option>





                                            <?php $selected = imtst_checkIfSelected($shortcode_arr['order'], 'DESC', 'select');?>





                                        <option value="DESC" <?php echo $selected;?> >DESC</option>





                                    </select>





                                </td>





                            </tr>





                            <tr>





                                 <td colspan="2">





                                    <div class="spacewp_b_divs"></div>





                                 </td>





                            </tr>





                            <tr>





                                <td>





                                    Show Inside Page





                                </td>





                                <td>





                                    <?php $selected = imtst_checkIfSelected($shortcode_arr['page_inside'], 1, 'checkbox');?>





                                    <input type="checkbox" <?php echo $selected;?> id="page_inside" onClick="imtst_preview();"/>





                                </td>





                            </tr>





                            <tr>


                                <td>


                                    Template


                                </td>


                                <td>


                                        <select id="inside_template" onChange="imtst_preview();" class="mddl_select_tag">


                                            <option value="default">Default Template</option>


                                            <?php


                                                $templates = get_page_templates();


                                                if(isset($templates) && count($templates)>0){


                                                     foreach($templates as $template_name => $template_page){


                                                        $template_page = str_replace('.php', '', $template_page);


                                                        $selected = imtst_checkIfSelected($shortcode_arr['inside_template'], $template_page, 'select');


                                                        ?>


                                                            <option value="<?php echo $template_page;?>" <?php echo $selected;?> ><?php echo $template_name;?></option>


                                                        <?php


                                                     }


                                                }


                                            ?>


                                        </select>


                                </td>


                            </tr>





                            <tr>





                                <td colspan="2">





                                    <span class="warning_grey_span">( If you want to use this options do not move theme files from their original location. )</span>





                                </td>





                            </tr>





                    </table>





            </div><!--end of column one-->











            <div class="ict_column column_two">





                  <h4>Entry Information:</h4>





                      <div>





                          <?php $selected = imtst_checkIfSelected($shortcode_arr['name'], 1, 'checkbox');?>





                          <input type="checkbox" <?php echo $selected;?> id="show_name" onClick="imtst_preview();"/> Client Name





                      </div>





                      <div>





                          <?php $selected = imtst_checkIfSelected($shortcode_arr['quote'], 1, 'checkbox');?>





                          <input type="checkbox" <?php echo $selected;?> id="show_quote" onClick="imtst_preview();"/> Quote





                      </div>





                      <div>





                          <?php $selected = imtst_checkIfSelected($shortcode_arr['image'], 1, 'checkbox');?>





                          <input type="checkbox" <?php echo $selected;?> id="show_image" onClick="imtst_preview();" /> Client Image





                      </div>





                      <div class="space_b_divs"></div>





                      <div>





                          <?php $selected = imtst_checkIfSelected($shortcode_arr['job'], 1, 'checkbox');?>





                          <input type="checkbox" <?php echo $selected;?> id="show_job" onClick="imtst_preview();"/> Client Job





                      </div>





                      <div>





                          <?php $selected = imtst_checkIfSelected($shortcode_arr['client_url'], 1, 'checkbox');?>





                          <input type="checkbox" <?php echo $selected;?> id="show_client_url" onClick="imtst_preview();"/> Client URL





                      </div>





                      <div class="space_b_divs"></div>





                      <div>





                          <?php $selected = imtst_checkIfSelected($shortcode_arr['company'], 1, 'checkbox');?>





                          <input type="checkbox" <?php echo $selected;?> id="show_company" onClick="imtst_preview();"/> Company





                      </div>





                      <div>





                          <?php $selected = imtst_checkIfSelected($shortcode_arr['company_url'], 1, 'checkbox');?>





                          <input type="checkbox" <?php echo $selected;?> id="show_company_url" onClick="imtst_preview();"/> Company URL





                      </div>





                      <div class="space_b_divs"></div>





                      <div>





                          <?php $selected = imtst_checkIfSelected($shortcode_arr['stars'], 1, 'checkbox');?>





                          <input type="checkbox" <?php echo $selected;?> id="show_stars" onClick="imtst_preview();"/> Stars





                      </div>





                      <div class="space_b_divs"></div>





                      <div>





                          <?php $selected = imtst_checkIfSelected($shortcode_arr['date'], 1, 'checkbox');?>





                          <input type="checkbox" <?php echo $selected;?> id="show_date" onClick="imtst_preview();"/> Date





                      </div>





            </div><!--end of column_two-->











             <div class="ict_column column_three">





                <h4>Theme:</h4>





                    <table>





                        <tr>





                            <td>Select Theme</td>





                            <td>





                                  <?php





                                        $handle = opendir( $dir_path . 'themes' );





                                        while (false !== ($entry = readdir($handle))) {





                                            if( $entry!='.' && $entry!='..' ){





                                                $arr_str = explode('_', $entry);





                                                $themes_arr[$arr_str[1]] = $arr_str[0];





                                            }





                                        }





                                        ksort($themes_arr);





                                  ?>





                                <select id="theme" onChange="imtst_preview();" class="ict_select_field_m">





                                <?php





                                        foreach($themes_arr as $key=>$theme){





                                               $selected = imtst_checkIfSelected($shortcode_arr['theme'], $theme, 'select');





                                               $value = strtolower($theme) . '_' . $key;





                                               $label = ucfirst($theme) . ' ' . $key;





                                               ?>





                                               <option value="<?php echo $value;?>" <?php echo $selected;?> ><?php echo $label;?></option>





                                               <?php





                                        }





                                  ?>





                                </select>





                            </td>





                        </tr>





                        <tr>





                            <td>Color Scheme</td>





                            <td>





                            <ul id="colors_ul" class="colors_ul">





                                <?php





                                    $color_scheme = array('0a9fd8', '38cbcb', '27bebe', '0bb586', '94c523', '6a3da3', 'f1505b', 'ee3733', 'f36510', 'f8ba01');





                                    $i = 0;





                                    foreach($color_scheme as $color){





                                        if( $i==5 ) echo "<div class='clear'></div>";





                                        ?>





                                            <li class="color_scheme_item" onClick="changeColorScheme(this, '<?php echo $color;?>', '#color_scheme');imtst_preview();" style="background-color: #<?php echo $color;?>;"></li>





                                        <?php





                                        $i++;





                                    }





                                ?>





                            </ul>





                            <input type="hidden" id="color_scheme" value="<?php echo $shortcode_arr['color_scheme'];?>" />





                            <div class="clear"></div>





                            </td>





                        </tr>





						<tr>





                             <td colspan="2">





                             </td>





                        </tr>





                        <tr>





                            <td>Number of Columns:</td>





                            <td>





                                <select id="columns_num" onChange="imtst_preview();" class="ict_select_field_m">





                                    <?php





                                        for($i=1;$i<7;$i++){





                                            $selected = imtst_checkIfSelected($shortcode_arr['columns'], $i, 'select');





                                            ?>





                                                <option value='<?php echo $i;?>' <?php echo $selected;?>><?php echo $i;?> columns</option>





                                            <?php





                                        }





                                    ?>





                                </select>





                            </td>





                        </tr>





                        <tr>





                             <td colspan="2">





                                <div class="spacewp_b_divs"></div>





                             </td>





                        </tr>





                    </table>





             </div><!--end of column three-->





               <div class="ict_column column_four">





                  <div>





                        <?php $selected = imtst_checkIfSelected($shortcode_arr['slider_set'], 1, 'checkbox');?>





                        <input type="checkbox" <?php echo $selected;?> id="slider_set" onClick="checkandModfCss(this, '#slider_options', 'opacity', 1, '0.5');imtst_preview();"/> Show as Slider





                  </div>





                  <div style="opacity:0.5" id="slider_options" >





                      <table>





                          <tr>





                              <td>Items per Slide:</td>





                              <td>





                                  <input type="number" min="1" id="items_per_slide" onChange="imtst_preview();" onKeyup="imtst_preview();" value="<?php echo $shortcode_arr['items_per_slide'];?>" class="ict_input_num_field"/>





                              </td>





                          </tr>





                          <tr>





                              <td colspan="2">





                                  <?php $selected = imtst_checkIfSelected($shortcode_arr['bullets'], 1, 'checkbox');?>





                                  <input type="checkbox" <?php echo $selected;?> id="bullets" onClick="imtst_preview();"/> Bullets





                              </td>





                          </tr>











                          <tr>





                              <td colspan="2">





                                  <?php $selected = imtst_checkIfSelected($shortcode_arr['nav_button'], 1, 'checkbox');?>





                                  <input type="checkbox" <?php echo $selected;?> id="nav_button" onClick="imtst_preview();"/> Nav Button





                              </td>





                          </tr>





                          <tr>





                              <td colspan="2">





                                  <?php $selected = imtst_checkIfSelected($shortcode_arr['autoplay'], 1, 'checkbox');?>





                                  <input type="checkbox" <?php echo $selected;?> id="autoplay" onClick="imtst_preview();"/> Autoplay





                              </td>





                          </tr>





                          <tr>





                              <td colspan="2">





                                  <?php $selected = imtst_checkIfSelected($shortcode_arr['stop_hover'], 1, 'checkbox');?>





                                  <input type="checkbox" <?php echo $selected;?> id="stop_hover" onClick="imtst_preview();"/> Stop Hover





                              </td>





                          </tr>





                          <tr>





                              <td>





                                  Speed





                              </td>





                              <td>





                                  <input type="number" value="<?php echo $shortcode_arr['speed'];?>" id="speed" onChange="imtst_preview();" onKeyup="imtst_preview();" class="ict_input_num_field" />





                              </td>





                          </tr>





                          <tr>





                              <td>





                                  Pagination Speed





                              </td>





                              <td>





                                  <input type="number" value="<?php echo $shortcode_arr['pagination_speed'];?>" id="pagination_speed" onChange="imtst_preview();" onKeyup="imtst_preview();" class="ict_input_num_field"/>





                              </td>





                          </tr>





                          <tr>





                              <td colspan="2">





                                  <?php $selected = imtst_checkIfSelected($shortcode_arr['responsive'], 1, 'checkbox');?>





                                  <input type="checkbox" <?php echo $selected;?> id="responsive" onClick="imtst_preview();"/> Responsive





                              </td>





                          </tr>





                          <tr>





                              <td colspan="2">





                                  <?php $selected = imtst_checkIfSelected($shortcode_arr['lazy_load'], 1, 'checkbox');?>





                                  <input type="checkbox" <?php echo $selected;?> id="lazy_load" onClick="imtst_preview();"/> Lazy Load





                              </td>





                          </tr>





                          <tr>





                              <td colspan="2">





                                  <?php $selected = imtst_checkIfSelected($shortcode_arr['lazy_effect'], 1, 'checkbox');?>





                                  <input type="checkbox" <?php echo $selected;?> id="lazy_effect" onClick="imtst_preview();"/> Lazy Effect





                              </td>





                          </tr>





                          <tr>





                              <td>





                                  CSS3 Transition





                              </td>





                              <td>





                                  <select id="slide_css_transition" onChange="imtst_preview();">





                                          <?php $selected = imtst_checkIfSelected($shortcode_arr['slide_css_transition'], 'none', 'select');?>





                                      <option value="none" <?php echo $selected;?> >None</option>





                                          <?php $selected = imtst_checkIfSelected($shortcode_arr['slide_css_transition'], 'fade', 'select');?>





                                      <option value="fade" <?php echo $selected;?> >fade</option>





                                          <?php $selected = imtst_checkIfSelected($shortcode_arr['slide_css_transition'], 'backSlide', 'select');?>





                                      <option value="backSlide" <?php echo $selected;?> >backSlide</option>





                                          <?php $selected = imtst_checkIfSelected($shortcode_arr['slide_css_transition'], 'goDown', 'select');?>





                                      <option value="goDown" <?php echo $selected;?> >goDown</option>





                                          <?php $selected = imtst_checkIfSelected($shortcode_arr['slide_css_transition'], 'fadeUp', 'select');?>





                                      <option value="fadeUp" <?php echo $selected;?> >fadeUp</option>





                                  </select>





                              </td>





                          </tr>





                      </table>





                  </div>





               </div> <!--end of column four-->





             <div class="clear"></div>





        </div><!--end of display entrires -->





    </div>





</div>











    <div class="shortcode_wrapp">





        <div class="content_shortcode">





            <div>





                <span style="font-weight:bolder; color: #333; font-style:italic; font-size:11px;">ShortCode : </span>





                <span class="the_shortcode"></span>





            </div>





            <div style="margin-top:10px;">





                <span style="font-weight:bolder; color: #333; font-style:italic; font-size:11px;">PHP Code: </span>





                <span class="php_code"></span>





            </div>





        </div>





    </div>











<div class="ict_preview_wrapp">





    <div class="box_title">





        <h2><i class="icon-eyes"></i>Preview</h2>





            <div class="actions_preview pointer">





			    <a onclick="jQuery('#preview').slideToggle();" class="btn btn-mini content-slideUp">





                    <i class="icon-angle-down"></i>





                </a>





			</div>





        <div class="clear"></div>





    </div>





    <div id="preview" class="ict_preview"></div>





</div>





<div style="clear:both;"></div>











</div>





</div>





<script>





    dir_url = '<?php echo $dir_url;?>';





</script>