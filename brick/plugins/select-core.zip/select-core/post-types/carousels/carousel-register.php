<?php
namespace QodeCore\CPT\Carousels;

use QodeCore\Lib;

/**
 * Class CarouselRegister
 * @package QodeCore\CPT\Carousels
 */
class CarouselRegister implements Lib\PostTypeInterface {
    /**
     * @var string
     */
    private $base;
    /**
     * @var string
     */
    private $taxBase;

    public function __construct() {
        $this->base = 'carousels';
        $this->taxBase = 'carousels_category';
    }

    /**
     * @return string
     */
    public function getBase() {
        return $this->base;
    }

    /**
     * Registers custom post type with WordPress
     */
    public function register() {
        $this->registerPostType();
        $this->registerTax();
    }

    /**
     * Registers custom post type with WordPress
     */
    private function registerPostType() {
        global $qodeFramework;

        $menuPosition = 5;
        $menuIcon = 'dashicons-admin-post';
        if(qode_core_theme_installed()) {
            $menuPosition = $qodeFramework->getSkin()->getMenuItemPosition('carousel');
            $menuIcon = $qodeFramework->getSkin()->getMenuIcon('carousel');
        }

        register_post_type($this->base,
            array(
                'labels'    => array(
                    'name'        => __('Select Carousel','qode_core' ),
                    'menu_name' => __('Select Carousel','qode_core' ),
                    'all_items' => __('Carousel Items','qode_core' ),
                    'add_new' =>  __('Add New Carousel Item','qode_core'),
                    'singular_name'   => __('Carousel Item','qode_core' ),
                    'add_item'      => __('New Carousel Item','qode_core'),
                    'add_new_item'    => __('Add New Carousel Item','qode_core'),
                    'edit_item'     => __('Edit Carousel Item','qode_core')
                ),
                'public'    =>  false,
                'show_in_menu'  =>  true,
                'rewrite'     =>  array('slug' => 'carousels'),
                'menu_position' =>  $menuPosition,
                'show_ui'   =>  true,
                'has_archive' =>  false,
                'hierarchical'  =>  false,
                'supports'    =>  array('title','page-attributes'),
                'menu_icon'  =>  $menuIcon
            )
        );
    }

    /**
     * Registers custom taxonomy with WordPress
     */
    private function registerTax() {
        $labels = array(
            'name' => __( 'Carousels', 'taxonomy general name' ),
            'singular_name' => __( 'Carousel', 'taxonomy singular name' ),
            'search_items' =>  __( 'Search Carousels','qode_core' ),
            'all_items' => __( 'All Carousels','qode_core' ),
            'parent_item' => __( 'Parent Carousel','qode_core' ),
            'parent_item_colon' => __( 'Parent Carousel:','qode_core' ),
            'edit_item' => __( 'Edit Carousel','qode_core' ),
            'update_item' => __( 'Update Carousel','qode_core' ),
            'add_new_item' => __( 'Add New Carousel','qode_core' ),
            'new_item_name' => __( 'New Carousel Name','qode_core' ),
            'menu_name' => __( 'Carousels','qode_core' ),
        );

        register_taxonomy($this->taxBase, array($this->base), array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'query_var' => true,
            'show_admin_column' => true,
            'rewrite' => array( 'slug' => 'carousels-category' ),
        ));
    }

}