<?php

/*-----------------------------------------------------------------------------------*/
/*	Clear p and br for our shortcodes
/*-----------------------------------------------------------------------------------*/
add_filter("the_content", "the_content_filter");
 
function the_content_filter($content) {
 
	// array of custom shortcodes requiring the fix 
	$block = join("|",array("wmf_pad","wmf_services","wmf_prg","wmf_sp","wmf_tab","wmf_fonticon","wmf_dropcap","wmf_highlight","wmf_toggle","wmf_toggles","wmf_tab","wmf_tabs","wmf_button","wmf_notify","wmf_lb","wmf_table","wmf_maps","wmf_video","wmf_maps","wmf_twitter","wmf_row","wmf_col"));
 
	// opening tag
	$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
		
	// closing tag
	$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
 
	return $rep;
 
}

/*-----------------------------------------------------------------------------------*/
/*	Padding Shortcodes
/*-----------------------------------------------------------------------------------*/
	
	add_shortcode('wmf_pad', 'webbu_shortcodes_padding_shortcode');
	function webbu_shortcodes_padding_shortcode( $atts, $content = null ) { 
		$atts = shortcode_atts( 
			array(
				'size' => ''
			), $atts); 
				
		$output =  '<div style="height:'.$atts['size'].'px;display:block;width:100%"></div>'; 
		
		return $output;
	}
/*-----------------------------------------------------------------------------------*/
/*	Services Shortcodes
/*-----------------------------------------------------------------------------------*/
	
	add_shortcode('wmf_services', 'webbu_shortcodes_services_shortcode');
	function webbu_shortcodes_services_shortcode( $atts, $content = null ) { 
		$atts = shortcode_atts( 
			array(
				'title' => '',
				'icon' => '',
				'link' => '',
				'target' => ''
			), $atts); 
				
		$output =  '<div class="wmf_services_class"><a href="'.$atts['link'].'" target="'.$atts['target'].'" class="wmf_icon_class"><i class="'.$atts['icon'].'"></i></a><a href="'.$atts['link'].'" target="'.$atts['target'].'"><h3>'.$atts['title'].'</h3></a><p>'.$content.'</p></div>'; 
		
		return $output;
	}
	
/*-----------------------------------------------------------------------------------*/
/*	Progress Bar Shortcodes
/*-----------------------------------------------------------------------------------*/
	
	add_shortcode('wmf_prg', 'webbu_shortcodes_progress_shortcode');
	function webbu_shortcodes_progress_shortcode( $atts, $content = null ) { 
		$atts = shortcode_atts( 
			array(
				'value' => '0',
				'color' => '',
				'type' => '',
			), $atts); 
		
		$output = '<div class="progress '.$atts['type'].'">
				<div class="progress-bar '.$atts['color'].'" role="progressbar" aria-valuenow="'.$atts['value'].'" aria-valuemin="0" aria-valuemax="100" style="width: '.$atts['value'].'%;"></div>
				</div>';  
		
		return $output;
	}

/*-----------------------------------------------------------------------------------*/
/*	Seperator
/*-----------------------------------------------------------------------------------*/
	
	function webbushort_sp( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'align' => '',
			'size' => '16'
	    ), $atts));
		
	   if($align != ''){
	   	   $output = '<div class="wmf_separator separator_'.$align.' "><div style="font-size:'.$size.'px">' . do_shortcode($content) . '</div></div>';
	   }else{
		   $output = '<div class="wmf_separator"><div>' . do_shortcode($content) . '</div></div>';
	   }
	   
	   return $output;
	}
	add_shortcode('wmf_sp', 'webbushort_sp');

/*-----------------------------------------------------------------------------------*/
/*	Fonticon Shortcodes
/*-----------------------------------------------------------------------------------*/
	
	add_shortcode('wmf_fonticon', 'webbu_shortcodes_fonticon_shortcode');
	function webbu_shortcodes_fonticon_shortcode($atts, $content = null) {
		$output = '';
		$output .= '<i class="icon '.$atts['icon'].'" style="font-size:'.$atts['size'].'px; color:'.$atts['color'].' ;"></i>';
	
		return $output;
	}

/*-----------------------------------------------------------------------------------*/
/*	Dropcap Shortcodes
/*-----------------------------------------------------------------------------------*/
	
	add_shortcode('wmf_dropcap', 'webbu_shortcodes_dropcap_shortcode');
	function webbu_shortcodes_dropcap_shortcode( $atts, $content = null ) { 
		$atts = shortcode_atts(
			array(
				'bgcolor' => '#bc0000',
				'textcolor' => '#ffffff',
			), $atts); 
		
		return '<span class="wmf_dropcap" style="background-color:'.$atts['bgcolor'].'; color:'.$atts['textcolor'].';">' .do_shortcode($content). '</span>';  
		
	}
	
/*-----------------------------------------------------------------------------------*/
/*	Hightlight Shortcodes
/*-----------------------------------------------------------------------------------*/
	
	add_shortcode('wmf_highlight', 'webbu_shortcodes_highlight_shortcode');
	function webbu_shortcodes_highlight_shortcode($atts, $content = null) {
		$atts = shortcode_atts(
			array(
				'bgcolor' => '#bc0000',
				'textcolor' => '#ffffff',
			), $atts);
			
			return '<span style="background-color:'.$atts['bgcolor'].'; color:'.$atts['textcolor'].';">' .do_shortcode($content). '</span>';
	}
	
/*-----------------------------------------------------------------------------------*/
/*	Accordion Shortcodes
/*-----------------------------------------------------------------------------------*/
	add_shortcode('wmf_toggle', 'webbushort_collapse'); 
	function webbushort_collapsibles( $atts, $content = null ) {
	
		if( isset($GLOBALS['collapsibles_count']) ){$GLOBALS['collapsibles_count']++;}else{$GLOBALS['collapsibles_count'] = 0;}
		
		$defaults = array();
		extract( shortcode_atts( $defaults, $atts ) );
		
		preg_match_all( '/collapse title="([^\"]+)"/i', $content, $matches, PREG_OFFSET_CAPTURE );
		
		$tab_titles = array();
		
		if( isset($matches[1]) ){ $tab_titles = $matches[1]; }
		  $output = '';
		  //$output .= '<div class="wmfaccordion" id="accordion_' . $GLOBALS['collapsibles_count'] . '">';
		  $output .= '<div class="panel-group" id="accordion_' . $GLOBALS['collapsibles_count'] . '">';
		  $output .= do_shortcode( $content );
		  $output .= '</div>';
		  $output .= '</div>';
		  
		  $output = preg_replace(']<br class="ws" \/>]', '', $output, -1);
		  
		return $output;
	}
	
	add_shortcode('wmf_toggles', 'webbushort_collapsibles');  
	function webbushort_collapse( $atts, $content = null ) {
	
		if( !isset($GLOBALS['current_collapse']) ){$GLOBALS['current_collapse'] = 0;}else{$GLOBALS['current_collapse']++;}
		
		$defaults = array( 'title' => 'Tab', 'state' => '');
		extract( shortcode_atts( $defaults, $atts ) );
		
		if (!empty($state)) 
		
		  $state = 'in';
		
		$output = '
		
		<div class="panel panel-default">
		  <div class="wmfaccordion-heading">
			<a class="wmfaccordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion_' . $GLOBALS['collapsibles_count'] . '" href="#collapse_' . $GLOBALS['current_collapse'] . '"> <i class="icon-caret-up"></i> ' . $title . '</a>
		  </div>
		  <div id="collapse_' . $GLOBALS['current_collapse'] . '" class="wmfaccordion-body wmfcollapse ' . $state . '">
			<div class="wmfaccordion-inner">' . do_shortcode($content) . '</div>
		  </div>
		</div>';
		
		return $output;
	
	}
	 
/*-----------------------------------------------------------------------------------*/
/*	Tabs Shortcodes
/*-----------------------------------------------------------------------------------*/

	function webbushort_tabs( $atts, $content = null ) {
	
		if(isset($GLOBALS['tabs_count'])){$GLOBALS['tabs_count']++;}else{$GLOBALS['tabs_count'] = 0;}
	
		$defaults = array();
	
		extract( shortcode_atts( $defaults, $atts ) );
	
		preg_match_all( '/tab title="([^\"]+)"/i', $content, $matches, PREG_OFFSET_CAPTURE );
	
		$tab_titles = array();
	
		if( isset($matches[1]) ){ $tab_titles = $matches[1]; }
	
		$output = '';
	
		if( count($tab_titles) ){
	
		  $output .= '<ul class="wmfnav wmfnav-tabs" id="custom-tabs-'. rand(1, 100) .'">';
	
		  $i = 0;
	
		  foreach( $tab_titles as $tab ){
	
			if($i == 0){$output .= '<li class="active">';}else{$output .= '<li>';}
		  
			if( isset($GLOBALS['tabs_count']) ){$GLOBALS['tabs_count']++;}else{$GLOBALS['tabs_count'] = 0;}
			
			$output .= '<a href="#custom-tab-' . $GLOBALS['tabs_count'] . '"  data-toggle="tab">' .$tab[0] . '</a></li>';
	
			$i++;
	
		  }
			$GLOBALS['tabs_count'] = 0;
			$output .= '</ul>';
			$output .= '<div class="wmftab-content">';
			$output .= do_shortcode( $content );
			$output .= '</div>';
	
		}else{
			
			$output .= do_shortcode( $content );
			
		}
		
		$output = preg_replace(']<br class="ws" \/>]', '', $output, -1);
		return $output;
		
	 }
	
	add_shortcode('wmf_tabs', 'webbushort_tabs');
	
	
	function webbushort_tab( $atts, $content = null ) {
		if( !isset($GLOBALS['current_tabs']) ) {
	
		  $GLOBALS['current_tabs'] = $GLOBALS['tabs_count'];
		  $state = 'active';
	
		} else {
	
		  if( $GLOBALS['current_tabs'] == $GLOBALS['tabs_count'] ) {$state = '';}else{$GLOBALS['current_tabs'] = $GLOBALS['tabs_count'];}
		  $state = '';
		}
	
		$defaults = array( 'title' => 'Tab');
	
		extract( shortcode_atts( $defaults, $atts ) );
	
		if( isset($GLOBALS['tabs_count']) or $GLOBALS['tabs_count'] == 0 ){$GLOBALS['tabs_count']++;}else{$GLOBALS['tabs_count'] = 0;}
	
		$deger = '<div id="custom-tab-' . $GLOBALS['tabs_count'] . '" class="wmftab-pane ' . $state . '">'. do_shortcode( $content ) .'</div>';
		$deger = str_replace("<p>", "", $deger);
		$deger = str_replace("</p>", "", $deger);
		return $deger;
	}
	
	add_shortcode('wmf_tab', 'webbushort_tab');	
	
/*-----------------------------------------------------------------------------------*/
/*	Button Group Shortcodes
/*-----------------------------------------------------------------------------------*/  
	
	function webbushort_buttong( $atts, $content = null ) {
      extract(shortcode_atts(array(
	  'align' => ''
      ), $atts));

      return '<div class="wmfbtn-toolbar '.$align.'"><div class="wmfbtn-group">' . do_shortcode( $content ) . '</div></div>';
    }
	add_shortcode('wmf_buttong', 'webbushort_buttong');

/*-----------------------------------------------------------------------------------*/
/*	Buttons Shortcodes
/*-----------------------------------------------------------------------------------*/

	function webbushort_button( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'url' => '#',
			'target' => '_self',
			'color' => '',
			'size' => 'wmfbtn-sm'
	    ), $atts));
		
	   if($color == "normal"){
		   return '<a target="'.$target.'" class="wmfbtn '.$size.'" href="'.$url.'">' . do_shortcode($content) . '</a>';
	   }elseif($color == "normal" and $size == "normal"){
		   return '<a target="'.$target.'" class="wmfbtn" href="'.$url.'">' . do_shortcode($content) . '</a>';   
	   }elseif($size == "normal"){
		   return '<a target="'.$target.'" class="wmfbtn '.$color.'" href="'.$url.'">' . do_shortcode($content) . '</a>';
	   }else{
		   return '<a target="'.$target.'" class="wmfbtn '.$color.' '.$size.'" href="'.$url.'">' . do_shortcode($content) . '</a>';   
	   }
		
	}
	add_shortcode('wmf_button', 'webbushort_button');
	
/*-----------------------------------------------------------------------------------*/ 
/*	Notifications
/*-----------------------------------------------------------------------------------*/

	function webbushort_notifications( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'style'   => 'wmfalert-info'
	    ), $atts));
		
	   return '<div class="wmfalert '.$style.'"><button type="button" class="close" data-dismiss="wmfalert"><i class="icon-remove-sign"></i></button>' . do_shortcode($content) . '</div>';
	}
	add_shortcode('wmf_notify', 'webbushort_notifications');


/*-----------------------------------------------------------------------------------*/
/*	Badges & Labels
/*-----------------------------------------------------------------------------------*/

	function webbushort_lb( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'color' => 'default',
			'type' => 'wmfbadge'
	    ), $atts));
	   
	   $output = '<span class="'.$type.' '.$type.'-'.$color.'">' . do_shortcode($content) . '</span>';
	   
	   return $output;
	}
	add_shortcode('wmf_lb', 'webbushort_lb');

/*-----------------------------------------------------------------------------------*/
/*	Table Shortcodes
/*-----------------------------------------------------------------------------------*/
  
	function webbushort_table( $atts ) {
		extract( shortcode_atts( array(
		  'cols' => 'none',
		  'data' => 'none',
		  'type' => 'type'
		), $atts ) );
		$cols = explode(',',$cols);
		$data = explode(',',$data);
		$total = count($cols);
		$output = '';
		$output .= '<table class="wmftable wmftable-'. $type .' table-bordered"><tr>';
		foreach($cols as $col):
		  $output .= '<th>'.$col.'</th>';
		endforeach;
		$output .= '</tr><tr>';
		$counter = 1;
		foreach($data as $datum):
		  $output .= '<td>'.$datum.'</td>';
		  if($counter%$total==0):
			  $output .= '</tr>';
		  endif;
		  $counter++;
		endforeach;
		  $output .= '</table>';
		return $output;
	}
	
	add_shortcode('wmf_table', 'webbushort_table');
  

/*-----------------------------------------------------------------------------------*/
/*	Google Map
/*-----------------------------------------------------------------------------------*/
	
	function webbushort_maps( $atts ) {
      extract(shortcode_atts(array(
        "lat" => '',
		"lng" => '',
		"zoom" => '',
		"type" => '',
		"height" => ''
      ), $atts));
	  
	  $output = '<iframe width="100%" height="'.$height.'" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?q='.$lat.','.$lng.'&amp;mrt=websearch&amp;view=map&amp;z='.$zoom.'&amp;t='.$type.'&amp;output=embed&amp;iwloc=near"></iframe>';
	  
	  return $output;
    }
	add_shortcode('wmf_maps', 'webbushort_maps');
	

/*-----------------------------------------------------------------------------------*/
/*	Videos
/*-----------------------------------------------------------------------------------*/
	
	function webbushort_video($atts, $content=null) {
		extract(
			shortcode_atts(array(
				'type' => '',
				'id' => '',
				'w' => '',
				'h' => ''
			), $atts)
		);
		$site = $type;
		
		if($w == ''){$w=600;};if($h == ''){$h=370;};if($site == ''){$site='youtube';}
		
		if ( $site == "youtube" ) { $src = 'http://www.youtube-nocookie.com/embed/'.$id; }
		else if ( $site == "vimeo" ) { $src = 'http://player.vimeo.com/video/'.$id; }
		else if ( $site == "dailymotion" ) { $src = 'http://www.dailymotion.com/embed/video/'.$id; }
		else if ( $site == "yahoo" ) { $src = 'http://d.yimg.com/nl/vyc/site/player.html#vid='.$id; }
		else if ( $site == "bliptv" ) { $src = 'http://a.blip.tv/scripts/shoggplayer.html#file=http://blip.tv/rss/flash/'.$id; }
		else if ( $site == "veoh" ) { $src = 'http://www.veoh.com/static/swf/veoh/SPL.swf?videoAutoPlay=0&permalinkId='.$id; }
		else if ( $site == "viddler" ) { $src = 'http://www.viddler.com/simple/'.$id; }
		else{$src = 'http://www.youtube-nocookie.com/embed/'.$id;}
		
		if ( $id != '' ) {
			return '<div class="videoWrapper"><iframe width="'.$w.'" height="'.$h.'" src="'.$src.'" frameborder="0" allowfullscreen class="iframe-'.$site.'"></iframe></div>';
		}
	}
	add_shortcode('wmf_video','webbushort_video');	
	

/*-----------------------------------------------------------------------------------*/
/*	Twitter Page
/*-----------------------------------------------------------------------------------*/
	
	function webbushort_twitter( $atts ) {
      extract(shortcode_atts(array(
        "user" => '',
		"numb" => ''
      ), $atts));
	  
	  
	  $twitterpage= '
	  <!-- Twitter page begin -->
	  <script src="'.WE_PLUGIN_JS_URL.'twitter.php?tu='.$user.'&tn='.$numb.'"></script>
	  <script type="text/javascript">
		jQuery(function () {
			JQTWEET.loadTweets();
		});		
		</script>
	  <div style=" padding-bottom:10px;">
	  <a href="https://twitter.com/'.$user.'" class="twitter-follow-button twfbtn" data-show-count="false"><i class="icon-twitter" style="font-size:14px;color:#3CF"></i> Follow @'.$user.'</a>
	  </div>
    <!-- Follow end -->
                        
    <!-- Twitter Begin -->
    <div id="jstwitter">
    </div>
    <!-- Twitter End -->';
	  
	  return $twitterpage;
    }
	add_shortcode('wmf_twitter', 'webbushort_twitter');



/*-----------------------------------------------------------------------------------*/
/*	Bootstrap 3 Mobile First Columns
/*-----------------------------------------------------------------------------------*/

	function wmf_row( $atts, $content = null ) {
	   
	   $output = preg_replace(']<br class="ws" \/>]', '', $content, -1);
	   $output =  '<div class="wmffcontainer"><div class="wmffrow">' . do_shortcode($output) . '</div></div>';
	   
	   
	   return $output;
	}
	add_shortcode('wmf_row', 'wmf_row');
	
	function wmf_col( $atts, $content = null ) {
		extract(shortcode_atts(array(
				'cls' => '1',
				'mobile' => 'off',
				'demo' => '0'
			), $atts));
			
	   
	   $output = preg_replace(']<br class="ws" \/>]', '', $content, -1);
	   
	   if($demo == 1){
		   if($mobile == 'off'){
			$output = '<div class="wmffcol-lg-'.$cls.'"><div style="background-color:#ccc;width:100%">' . do_shortcode($output) . '</div></div>';
		   }elseif($mobile == 'on'){
			$output = '<div class="col-'.$cls.' wmffcol-xs-'.$cls.' wmffcol-sm-'.$cls.' wmffcol-md-'.$cls.' wmffcol-lg-'.$cls.'"><div style="background-color:#ccc;width:100%">' . do_shortcode($output) . '</div></div>';
		   }else{
			$output = '<div class="wmffcol-lg-'.$cls.'"><div style="background-color:#ccc;width:100%">' . do_shortcode($output) . '</div></div>';
		   }
	   }else{
	   	   if($mobile == 'off'){
			$output = '<div class="wmffcol-lg-'.$cls.'">' . do_shortcode($output) . '</div>';
		   }elseif($mobile == 'on'){
			$output = '<div class="col-'.$cls.' wmffcol-xs-'.$cls.' wmffcol-sm-'.$cls.' wmffcol-md-'.$cls.' wmffcol-lg-'.$cls.'">' . do_shortcode($output) . '</div>';
		   }else{
			$output = '<div class="wmffcol-lg-'.$cls.'">' . do_shortcode($output) . '</div>';
		   }
	   
	   }

	   return $output;
	}
	add_shortcode('wmf_col', 'wmf_col');

/*-----------------------------------------------------------------------------------*/
/*	Mobile Detection Shortcodes
/*-----------------------------------------------------------------------------------*/	
	
	
	add_shortcode('wmf_detect', 'webbushort_mdetect');
	function webbushort_mdetect( $atts, $content = null ) {extract(shortcode_atts(array("type" => ''), $atts));
		
		global $wmf_mobiledetect;
		if(empty($wmf_mobiledetect)){
			require_once('mobile-detect.php');
			$wmf_mobiledetect = new Mobile_Detect();
		}
		
		
		switch( $type )
		   {
			  case 'notphone':
				 //shortcode which shows content on desktops or tablets
				 if( ! $wmf_mobiledetect->isMobile() || $wmf_mobiledetect->isTablet() ) return do_shortcode($content);
				 break;
			  case 'nottablet':
			  	//shortcode which shows content on desktops or phones
				if( ! $wmf_mobiledetect->isTablet() ) return do_shortcode($content);
				break;
			  case 'notmobile':
			  	//shortcode which shows content on desktops only
				if( ! $wmf_mobiledetect->isMobile() && ! $wmf_mobiledetect->isTablet() ) return do_shortcode($content);
			  	break;
			  case 'phone':
			  	//shortcode which shows content on phones only
				if( $wmf_mobiledetect->isMobile() && ! $wmf_mobiledetect->isTablet() ) return do_shortcode($content);
			  	break;
			  case 'tablet':
			  	//shortcode which shows content on Tablets only
				if( $wmf_mobiledetect->isTablet() ) return do_shortcode($content);
			  	break;
			  case 'mobile':
			  	//shortcode which shows content on phones or tablets but not deskkop
				if( $wmf_mobiledetect->isMobile() || $wmf_mobiledetect->isTablet() ) return do_shortcode($content);
			  	break;
			  case 'ios':
			  	//shortcode which shows content on iOS devices only
				if( $wmf_mobiledetect->isiOS() ) return do_shortcode($content);
			  	break;
			  case 'iPhone':
			  	//shortcode which shows content on iPhone's only
				if( $wmf_mobiledetect->isiPhone() ) return do_shortcode($content);
			  	break;
			  case 'iPad':
			  	//shortcode which shows content on iPad's only
				if( $wmf_mobiledetect->isiPad() ) return do_shortcode($content);
			  	break;
			  case 'android':
			  	//shortcode which shows content on Android devices only
				if( $wmf_mobiledetect->isAndroidOS() ) return do_shortcode($content);
			  	break;
			  case 'wm':
			  	//shortcode which shows content on Windows Mobile devices only
				if( $wmf_mobiledetect->isWindowsMobileOS() ) return do_shortcode($content);
			  	break;
			  case 'Samsung':
			  	//shortcode which shows content on iPhone's only
				if( $wmf_mobiledetect->isSamsung() ) return do_shortcode($content);
			  	break;
			  case 'BlackBerry':
			  	//shortcode which shows content on iPhone's only
				if( $wmf_mobiledetect->isBlackBerryOS() ) return do_shortcode($content);
			  	break;
		   }
	  
	}
	
// init shortcodes	
add_action('init', 'webbu_shortcodes_add_button');
function webbu_shortcodes_add_button() {  
   if ( current_user_can('edit_posts') || current_user_can('edit_pages') )  
   {  
     add_filter('mce_external_plugins', 'webbu_shortcodes_plugins');  
     add_filter('mce_buttons_3', 'webbu_shortcodes_add_buttons'); 
	  
   }  
}  

function webbu_shortcodes_add_buttons($buttons) {  
   array_push(
   $buttons, 
   "|", 
   "webbushort_cl", 
   "webbushort_mdetect",
   "webbushort_dropcap", 
   "webbushort_highlight",
   "webbushort_notifications", 
   "webbushort_lb", 
   "webbushort_sp",
   "webbushort_fonticon", 
   "webbushort_collapse",
   "webbushort_tabs",
   "webbushort_button",
   "webbushort_buttong",
   "webbushort_maps",
   "webbushort_table",
   "webbushort_video",
   "webbushort_twitter",
   "webbushort_progress",
   "webbushort_padding",
   "webbushort_services"
   ); 
   return $buttons;  
}  

function webbu_shortcodes_plugins($shortcode_arr) {  
   if ( floatval(get_bloginfo('version')) >= 3.9){
	   $shortcode_arr['webbushort_cl'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_mdetect'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_dropcap'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_highlight'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_fonticon'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_collapse'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_tabs'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_button'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_buttong'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_notifications'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_lb'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_sp'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_maps'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_table'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_video'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_twitter'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_progress'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_services'] = WE_PLUGIN_JS_URL.'shortcodes.php';
	   $shortcode_arr['webbushort_padding'] = WE_PLUGIN_JS_URL.'shortcodes.php';
   }else{
	   $shortcode_arr['webbushort_cl'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_mdetect'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_dropcap'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_highlight'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_fonticon'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_collapse'] = WE_PLUGIN_JS_URL.'shortcodes.old.php'; 
	   $shortcode_arr['webbushort_tabs'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_button'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_buttong'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_notifications'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_lb'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_sp'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_maps'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_table'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_video'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_twitter'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_progress'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_services'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
	   $shortcode_arr['webbushort_padding'] = WE_PLUGIN_JS_URL.'shortcodes.old.php';
   }
   return $shortcode_arr;  
}
?>