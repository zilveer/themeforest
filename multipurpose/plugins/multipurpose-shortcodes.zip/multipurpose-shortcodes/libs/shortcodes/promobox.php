<?php

if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// shortcode Promobox
add_shortcode('promobox', 'multipurpose_promobox');

function multipurpose_promobox($atts, $content = null) {
    
    $link = '#';
    if (isset($atts['button_link']) && $atts['button_link'] != 'Button link') {
        $link = $atts['button_link'];
    }

    $output = '<section class="hp-intro">';
    $output .= '<p class="slogan">' . $atts["slogan"] . '</p>';
    $output .= '<p class="cta"><a href="' . $link . '" class="button">' . $atts["button_text"] . '</a></p></section>	';
    return $output;
}
