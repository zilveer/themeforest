<?php
require_once 'class.abstract-post-type.php';
/**
 * Class TL_Services_Post_Type
 */
if (!class_exists('TL_Services_Post_Type')) {
    class TL_Services_Post_Type extends TL_Abstract_Post_Type
    {

        public function __construct()
        {
            parent::__construct(
                array(
                    'post_type_name' => 'tl_services',
                    'singular' => 'Service',
                    'plural' => 'Services',
                    'slug' => 'tl_service'
                ),
                array(
                    'public' => true,
                    'exclude_from_search' => false,
                    'publicly_queryable' => true,
                    'show_ui' => true,
                    'menu_position' => 20,
                    'capability_type' => 'post',
                    'hierarchical' => false,
                    'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
                    'can_export' => true,
                    'has_archive' => false,
                    'taxonomies' => array('post_tag')
                )
            );

            // Alter placeholder value on add new post item screen
            add_filter('enter_title_here', array($this, 'changeDefaultTitle'));

            // Add Template locations
            //add_filter('layers_template_locations', [$this, 'addTemplateLocations']);
        }


        /**
         *
         * @param $title
         * @return string|void
         */
        public function changeDefaultTitle($title)
        {
            $screen = get_current_screen();
            if ($this->slug == $screen->post_type) {
                $title = __('Enter Service Name', $this->textdomain);
            }
            return $title;
        }


        /**
         * Add Template Locations
         *
         * @param $template_locations
         * @return array
         */
        public function addTemplateLocations($template_locations)
        {
            $template_locations[] = TL_INSERT_STAFF_DIR . 'post-types/templates';
            return $template_locations;
        }
    }
}

// Register CPT
new TL_Services_Post_Type();