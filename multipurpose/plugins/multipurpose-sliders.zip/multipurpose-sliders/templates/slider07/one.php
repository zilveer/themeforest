    <article>
      %IMG%
      <div>%CONTENT%</div>
    </article>

