<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Hosting Packages", "wish"),
    "description" => __("Hosting Packages with Image Name and Links", 'wish'),
    "controls" => "full",
    "base" => "wish_hosting_packages",
    "as_parent" => array('only' => 'wish_hosting_packages_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/fQ3NR2j.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Hosting Title and Position", "wish"),
            "value" => __("CHOOSE YOUR HOSTING TODAY", 'wish'),
            "admin_label" => false,
        ), 

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Donec vestibulum justo a diam ultricies pellentesque.</br>Quisque mattis diam vel lacus tincidunt elementum sed vitae adipiscing turpis. Aenean ligula nibh", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),

        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', 
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("50", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#FFFFFF', 
            "description" => __( "Choose the background color", "wish" ),
            "group"         => "Fonts & Colors",
        ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Package", "wish"),
    "base" => "wish_hosting_packages_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_hosting_packages'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,    
        ),

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("The Title", "wish"),
            "value" => __("Professional", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Price", "wish"),
            "param_name" => "price",
            "description" => __("The Price", "wish"),
            "value" => __("$20.99", 'wish'),
            "admin_label" => false,
        ),


        array(
            "type" => "textfield",
            "heading" => __("Bandwidth", "wish"),
            "param_name" => "bandwidth",
            "description" => __("The Bandwidth", "wish"),
            "value" => __("Bandwidth 100GB", 'wish'),
            "admin_label" => false,
        ),

         array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Optimal forStart-ups, Newbies, Devs, Designers", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),
       
        
        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', 
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("32", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#fff', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        /*Price*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Price Text Font", "wish" ),
            "param_name" => "price_font",
            "value" => '', 
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Price Size", "wish"),
            "param_name" => "price_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("26", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Price Text Color", "wish" ),
            "param_name" => "price_color",
            "value" => '#fff', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        /*Bandwidth*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Bandwidth Text Font", "wish" ),
            "param_name" => "bandwidth_font",
            "value" => '', 
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Bandwidth Size", "wish"),
            "param_name" => "bandwidth_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("18", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Bandwidth Text Color", "wish" ),
            "param_name" => "bandwidth_color",
            "value" => '#fff', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Box Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#282828', 
            "description" => __( "Choose Background color of the Box", "wish" ),
            "group"         => "Fonts & Colors",
        ),


    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Hosting_Packages extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title'         => 'CHOOSE YOUR HOSTING TODAY',
            'title_font'    => '',
            'title_size'    => '50',
            'title_color'   => '#000',

            'details'       =>  'Donec vestibulum justo a diam ultricies pellentesque.</br>Quisque mattis diam vel lacus tincidunt elementum sed vitae adipiscing turpis. Aenean ligula nibh',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' =>  '#000',

            'bgcolor'       => '#fff'  
          ), $atts ) );

        /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


      $output = "<div class='container hosting-packages'>
            <div class='row'>
                <div class='col-lg-12'>
                    <h1 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>
                    <div class='description animated' data-animation='fadeInUp' data-animation-delay='500' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}
                    </div>
                </div>
            </div>
            <div class='row'>
                    " . do_shortcode($content) . "
                
            </div>
        </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Hosting_Packages_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image'             => 'Image',

            'title'             => 'Professional',
            'title_font'        => '',
            'title_size'        => '32',
            'title_color'       => '#fff',

            // 'link'           => '#',
            // 'link_text'      => 'Make an Appointment',
            'price'             => '$20.99',
            'price_font'        => '',
            'price_size'        => '26',
            'price_color'       => '#fff',

            'bandwidth'         => 'Bandwidth 100GB',
            'bandwidth_font'    => '',
            'bandwidth_size'    => '18',
            'bandwidth_color'   => '#fff',

            'details'           => 'Optimal forStart-ups, Newbies, Devs, Designers',
            'details_font'      => '',
            'details_size'      => '14',
            'details_color'     => '#000',

            'bgcolor'           => '#282828'
          ), $atts ) );

        
        /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Price*/
        $decode_font = urldecode($price_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $price_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Bandwidth*/
        $decode_font = urldecode($bandwidth_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $bandwidth_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

          $img = wp_get_attachment_image_src( $image, array(360,389) );

          if($image == "Image"){
            $imgsrc = plugins_url('images/1 (2).jpg', __FILE__);
            $img[0] = $imgsrc;
          }

          // if($link == "||" || $link == "" ){
            
          //   $link_text = "Make an Appointment";
          //   $link_url = "#";
          //   $link_target = "";
          //   $link_String="";

          // }else{

          //   $link = vc_build_link($link); //parse the link
          //   $link_url = esc_url($link["url"]);
          //   $link_target = esc_attr($link["target"]);
          //   $link_String="<div class='link'><a href='{$link_url}' target='{$link_target}'>{$link_text}</a></div>";
          //   if ($link_text == "") {
          //       $link_String = "";
          //   }

          // }


          $output = "
          <div class='col-lg-4 col-md-4 col-sm-4 box animated' data-animation='fadeInUp' data-animation-delay='800'>
                    <div class='picture'><img src='{$img[0]}' class='img-responsive' alt=''></div>
                    <div class='info' style='background-color:{$bgcolor}'>
                        <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>
                        <div class='price' style='font-family:{$price_font_family};font-size:{$price_size}px;color:{$price_color}'>{$price}</div>
                        <div class='bandwidth' style='font-family:{$bandwidth_font_family};font-size:{$bandwidth_size}px;color:{$bandwidth_color}'>{$bandwidth}</div>
                    </div>
                    <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}</div>
                </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>