<?php 
$e_tag = get_post_meta($post->ID, 'oi_tag', 1);
$p_tag = "";
if  ($e_tag !='All'){
$p_tag = get_term_by('name', $e_tag, 'portfolio-tags');
};
	global $wp_query;
	$paged = get_query_var('paged') ? get_query_var('paged') : 1;
	if($p_tag !=''){
	$args = array(
		'post_type' 		=> 'portfolio',
		'posts_per_page' 	=> get_post_meta($post->ID, 'port-count', true),
		'post_status' 		=> 'publish',
		'orderby' 			=> 'date',
		'order' 			=> 'DESC',
		'paged' 			=> $paged,
		'tax_query' => array(
			array(
				'taxonomy' => 'portfolio-tags',
				'terms'    => $p_tag->term_id,
			),
		),
	);}else{
		$args = array(
		'post_type' 		=> 'portfolio',
		'posts_per_page' 	=> get_post_meta($post->ID, 'port-count', true),
		'post_status' 		=> 'publish',
		'orderby' 			=> 'date',
		'order' 			=> 'DESC',
		'paged' 			=> $paged,
	);
		}
	$wp_query = new WP_Query($args);
?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	
    <?php
		$catt = get_the_terms( $post->ID, 'portfolio-category' );
		if (isset($catt) && ($catt!='')){
			$slugg = '';
			$slug = ''; 
			foreach($catt  as $vallue=>$key){
				$slugg .= strtolower($key->slug) . " ";
				$slug  .= ''.$key->name.', ';
			}
			
		};
	?>
    
	<?php $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '') ?>
    <?php $thumb_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '') ?>
	 	<?php
        	if (get_post_meta($post->ID, 'oi_th', 1) == 'portfolio-squre'){ $col='col-md-6'; $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'wall-portfolio-squrex2');};
			if (get_post_meta($post->ID, 'oi_th', 1) == 'portfolio-squrex2'){ $col='col-md-6'; $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'wall-portfolio-squrex2');};
			if (get_post_meta($post->ID, 'oi_th', 1) == 'portfolio-wide'){ $col='col-md-6'; $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'wall-portfolio-squrex2');};
			if (get_post_meta($post->ID, 'oi_th', 1) == 'portfolio-long'){ $col='col-md-6'; $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'wall-portfolio-squrex2');};
		?>
		<div class="oi_strange_portfolio_item <?php echo esc_attr($col);?> <?php echo esc_attr($slugg)?>">
            <div class="oi_vc_potrfolio">
            	<a href="<?php the_permalink($post->ID)?>">
            	<img class="img-responsive" src="<?php echo esc_url($large_image_url[0]); ?>" alt="" />
                <div class="oi_vc_port_mask"  style="background:<?php echo get_post_meta($post->ID, 'port-bg', true); ?>">
                    <div class="text-center">
                        <h3 class="oi_sub_legend" style="color:<?php echo get_post_meta($post->ID, 'port-text-color', true); ?>"><?php the_title();?></h3>
                        <div class="oi_vc_port_cat" style="color:<?php echo get_post_meta($post->ID, 'port-text-color', true); ?>"><?php echo esc_attr(substr($slug, '0', '-2'));?></div>
                        <div class="oi_vc_sep" style="background:<?php echo get_post_meta($post->ID, 'port-text-color', true); ?>"></div>
                    </div>
                </div>
                </a>
            </div>
        </div>
        
<?php endwhile; endif; ?>
