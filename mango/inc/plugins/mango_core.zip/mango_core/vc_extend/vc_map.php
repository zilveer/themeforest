<?php
$cats = get_categories ();
$post_cats = array ();
foreach ( $cats as $key => $value ) {
    $post_cats[ $value->name ] = $value->term_id;
}




$taxonomy = 'product_cat';
$orderby = 'name';       // name , id
$show_count = 0;         // 1 for yes, 0 for no
$pad_counts = 0;         // 1 for yes, 0 for no
$hierarchical = 1;       // 1 for yes, 0 for no
 $title = '';
$empty = 0;
$parent=0;
$args = array (
    'taxonomy' => $taxonomy,
    'orderby' => $orderby,
    'show_count' => $show_count,
    'pad_counts' => $pad_counts,
    'hierarchical' => $hierarchical,
    'title_li' => $title,
    'hide_empty' => $empty,
	'parent' => $parent
);
if ( class_exists( 'WooCommerce' ) ) {
$woo_product = get_categories ( $args );
$product = array ();
foreach ( $woo_product as $key => $value ) {
	$product[0]="Select Categories";
    $product[ $value->name ] = $value->name;
	
}
}



$taxonomy = 'category';
$orderby = 'name';       // name , id
$show_count = 0;         // 1 for yes, 0 for no
$pad_counts = 0;         // 1 for yes, 0 for no
$hierarchical = 1;       // 1 for yes, 0 for no
 $title = '';
$empty = 0;
$parent=0;
$args = array (
    'taxonomy' => $taxonomy,
    'orderby' => $orderby,
    'show_count' => $show_count,
    'pad_counts' => $pad_counts,
    'hierarchical' => $hierarchical,
    'title_li' => $title,
    'hide_empty' => $empty,
	'parent' => $parent
);

$post_cat = get_categories ( $args );
$post = array ();
foreach ( $post_cat as $key => $value ) {
	$post[0]="Select Categories";
    $post[ $value->name ] = $value->name;
	
}



$taxonomy = 'faq-category';
$orderby = 'name';       // name , id
$show_count = 0;         // 1 for yes, 0 for no
$pad_counts = 0;         // 1 for yes, 0 for no
$hierarchical = 1;       // 1 for yes, 0 for no
 $title = '';
$empty = 0;
$parent=0;
$args = array (
    'taxonomy' => $taxonomy,
    'orderby' => $orderby,
    'show_count' => $show_count,
    'pad_counts' => $pad_counts,
    'hierarchical' => $hierarchical,
    'title_li' => $title,
    'hide_empty' => $empty,
	'parent' => $parent
);

$faq_cat = get_categories ( $args );
$faq = array ();
foreach ( $faq_cat as $key => $value ) {
	$faq[0]="Select Categories";
    $faq[ $value->name ] = $value->name;
	
}



$yes_no = array (
    __ ( "Yes", "mango_core" ) => "yes",
    __ ( "No", "mango_core" ) => "no"
);

// Mango Categories
vc_map ( array (
    "name" => __ ( "Mango Categories", 'mango_core' ),
    "base" => "mango_category",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango' ),
    "admin_enqueue_css" => array ( plugins_url ( 'assets/vc_extend_admin.css', __FILE__ ) ), // This will load css file in the VC backend editor
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Categories Image", 'mango_core' ),
            "param_name" => "img_active"

        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title", 'mango_core' ),
            "param_name" => "title"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Sub Title", 'mango_core' ),
            "param_name" => "sub_title"
        ),


        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Button Text", 'mango_core' ),
            "param_name" => "button_text",
            "description" => __ ( "Text on the button.", 'mango_core' )
        ),

        array (

            'type' => 'href',
            'heading' => __ ( 'URL (Link)', 'mango_core' ),
            'param_name' => 'button_link',
            'description' => __('Button link.', 'mango_core')
        ),
    )
) );


// Mango Banner
vc_map ( array (
    "name" => __ ( "Mango Banner ", 'mango_core' ),
    "base" => "mango_banner",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Banner Image", 'mango_core' ),
            "param_name" => "img_active",
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title", 'mango_core' ),
            "param_name" => "title"
        ),

        array (
            "type" => "dropdown",
            "heading" => __ ( "Font Select", "mango_core" ),
            "param_name" => "mango_font",
            "value" => array (
                __ ( "Font Normal", "mango_core" ) => 'classy',
                __ ( "Font Medium", "mango_core" ) => 'mini',
                __ ( "Font Bold", "mango_core" ) => 'banner-color',
            ),
            "description" => __ ( "Select Grade", "mango_core" )
        ),
        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Sub Title", 'mango_core' ),
            "param_name" => "sub_title"
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Button Text", 'mango_core' ),
            "param_name" => "button_text",
            "description" => __ ( "Text on the button.", 'mango_core' )
        ),

        array (
            'type' => 'href',
            'heading' => __ ( 'URL (Link)', 'mango_core' ),
            'param_name' => 'button_link',
            'description' => __ ( 'Button link.', 'mango_core' )
        ),
    )
) );

// Mango Blogs
vc_map ( array (
    "name" => __ ( "Mango Blog", 'mango_core' ),
    "base" => "mango_blog",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading"
        ),


        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Blog Image", 'mango_core' ),
            "param_name" => "img_active",
        ),


        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description"
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Button Text", 'mango_core' ),
            "param_name" => "button_text",
            "description" => __ ( "Text on the button.", 'mango_core' )
        ),

        array (
            'type' => 'href',
            'heading' => __ ( 'URL (Link)', 'mango_core' ),
            'param_name' => 'button_link',
            'description' => __ ( 'Button link.', 'mango_core' )
        ),
    )

) );


// Latest Posts

vc_map ( array (
    "name" => __ ( "Mango Latest Posts", 'mango_core' ),
    "base" => "latest_posts",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title", 'mango_core' ),
            "param_name" => "heading",
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Show more posts text", 'mango_core' ),
            "param_name" => "text",
        ),

        array (

            "type" => "href",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Text Link", 'mango_core' ),
            "param_name" => "link",
        ),


        array (

            "type" => "number",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "No of Posts", 'mango_core' ),
            "param_name" => "no_of_posts",
            "value" => "5",
            "description" => __ ( "Left empty means all posts", 'mango_core' )
        ),

        array (
            "type" => "dropdown",
            "class" => "",
            "heading" => __ ( "Show Per Column", "mango_core" ),
            "param_name" => "post_per_column",
            "value" => array (
                __ ( "6 Per Column", "mango_core" ) => 6,
                __ ( "5 Per Column", "mango_core" ) => 5,
                __ ( "4 Per Column", "mango_core" ) => 4,
                __ ( "3 Per Column", "mango_core" ) => 3,
                __ ( "2 Per Column", "mango_core" ) => 2,
                __ ( "1 Per Column", "mango_core" ) => 1,
            ),
        ),

        array (
            "type" => "checkbox",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Filter By Category", 'mango_core' ),
            "param_name" => "post_cats",
            "value" => $post_cats
        ),
    )
) );

//Mango  clients
vc_map ( array (
    "name" => __ ( "Mango Clients", 'mango_core' ),
    "base" => "mango_clients",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading",
            "value" => __ ( "Clients", 'mango_core' )
        ),

        array (
            "type" => "number",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "No: Of Client Logo", 'mango_core' ),
            "param_name" => "no_of_posts",
            "value" => "2"
        ),

        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Style", 'mango_core' ),
            "param_name" => "style_select",
            "value" => array (
                __ ( "Select Style", "mango_core" ) => '',
                __ ( "Style 1", "mango_core" ) => 'style1',
                __ ( "Style 2", "mango_core" ) => 'style2',
            )
        ),
    )

) );


//Mango  clients Carosil

vc_map ( array (
    "name" => __ ( "Mango Client Carousel", 'mango_core' ),
    "base" => "mango_client_carosil",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading",
        ),
    )
) );


//Mango  Testimonials
vc_map ( array (
    "name" => __ ( "Mango Testimonials", 'mango_core' ),
    "base" => "mango_testimonials",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading",
            "value" => __ ( "Testimonials", 'mango_core' )
        ),

        array (
            "type" => "number",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "No: Of Testimonials", 'mango_core' ),
            "param_name" => "no_of_posts",
            "value" => "2"
        ),
    )

) );


//Mango  Shipping
vc_map ( array (
    "name" => __ ( "Mango Shipping", 'mango_core' ),
    "base" => "mango_shipping",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Shipping Image", 'mango_core' ),
            "param_name" => "img_active",
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading"
        ),

        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description"
        ),

        array (
            "type" => "dropdown",
            "heading" => __ ( "Color Select", "mango_core" ),
            "param_name" => "color",
            "value" => array (
                __ ( "Select Style", "mango_core" ) => '',
                __ ( "Dark", "mango_core" ) => 'dark',
                __ ( "Custom", "mango_core" ) => 'custom last',
            )
        ),
    )
) );


// Mango Category 1
vc_map ( array (
    "name" => __ ( "Mango Category 1", 'mango_core' ),
    "base" => "mango_category_fix",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
           "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Category Image", 'mango_core' ),
            "param_name" => "img_active",
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title", 'mango_core' ),
            "param_name" => "title"
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Sub Title", 'mango_core' ),
            "param_name" => "sub_title"
        ),


        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description"
        ),
    )
) );

// Mango Category 2
vc_map ( array (
    "name" => __ ( "Mango Category 2", 'mango_core' ),
    "base" => "mango_category_side",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Category Image", 'mango_core' ),
            "param_name" => "img_active",
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title 1", 'mango_core' ),
            "param_name" => "title1"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title 2", 'mango_core' ),
            "param_name" => "title2"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Price", 'mango_core' ),
            "param_name" => "price"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Button Text", 'mango_core' ),
            "param_name" => "button_text",
            "description" => __ ( "Text on the button.", 'mango_core' )
        ),

        array (
            'type' => 'href',
            'heading' => __ ( 'URL (Link)', 'mango_core' ),
            'param_name' => 'button_link',
            'description' => __ ( 'Button link.', 'mango_core' )
        ),

    )
) );


// Mango Banner Long
vc_map ( array (
    "name" => __ ( "Mango Banner Long", 'mango_core' ),
    "base" => "mango_banner_long",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Long Banner Image", 'mango_core' ),
            "param_name" => "img_active",
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title", 'mango_core' ),
            "param_name" => "title"
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Price", 'mango_core' ),
            "param_name" => "price"
        ),


        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description"
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Button Text", 'mango_core' ),
            "param_name" => "button_text",
            "description" => __ ( "Text on the button.", 'mango_core' )
        ),

        array (
            'type' => 'href',
            'heading' => __ ( 'URL (Link)', 'mango_core' ),
            'param_name' => 'button_link',
            'description' => __ ( 'Button link.', 'mango_core' )
        ),
    )
) );

// Mango Promated Categories

vc_map ( array (
    "name" => __ ( "Mango Promoted Categories", 'mango_core' ),
    "base" => "mango_promated_categories",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Long Banner Image", 'mango_core' ),
            "param_name" => "img_active",
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title", 'mango_core' ),
            "param_name" => "heading"
        ),


        array (
            "type" => "number",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Number", 'mango_core' ),
            "param_name" => "number_cat",
            "value" => "2"
        ),


        array (
           "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Category", 'mango_core' ),
            "param_name" => "category_select",
            "value" => array (
                __ ( "Select category", "mango_core" ) => '',
                __ ( "Select Post category", "mango_core" ) => 'category',
                __ ( "Select Woocommerce Categories", "mango_core" ) => 'product_cat',
                __ ( "Select FAQ'S Categories", "mango_core" ) => 'faq-category',
            )
        ),
    )
) );


// Mango Categories List

vc_map ( array (
    "name" => __ ( "Mango Categories List", 'mango_core' ),
    "base" => "mango_categories_list",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Categories List Image", 'mango_core' ),
            "param_name" => "img_active",
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title", 'mango_core' ),
            "param_name" => "heading"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Sub Title", 'mango_core' ),
            "param_name" => "sub_title"
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Big Title ", 'mango_core' ),
            "param_name" => "big_title"
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Button Text", 'mango_core' ),
            "param_name" => "button_text",
            "description" => __ ( "Text on the button.", 'mango_core' )

        ),

        array (
            'type' => 'href',
            'heading' => __ ( 'URL (Link)', 'mango_core' ),
            'param_name' => 'button_link',
            'description' => __ ( 'Button link.', 'mango_core' )
        ),


        array (
            "type" => "number",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Number", 'mango_core' ),
            "param_name" => "number_cat",
            "value" => "2"
        ),


        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Category", 'mango_core' ),
            "param_name" => "category_select",
            "value" => array (
                __ ( "Select category", "mango_core" ) => '',
                __ ( "Select Post category", "mango_core" ) => 'category',
                __ ( "Select Woocommerce Categories", "mango_core" ) => 'product_cat',
                __ ( "Select FAQ'S Categories", "mango_core" ) => 'faq-category',
            )
        ),
		
		/*
	    array(
        "type" => "dropdown",            
        "class" => "",
        "heading" => __("Woocommerce Parent Categories", "mango_core"),
        "param_name" => "woocommerce_parent_categories",
        "value" => $product,

        "dependency" => array(
         "element"=>"category_select",
         "value" => "product_cat"
        )
     ),
	 */
	 	
	    array(
        "type" => "dropdown",            
        "class" => "",
        "heading" => __("Post Parent Categories", "mango_core"),
        "param_name" => "post_parent_categories",
        "value" => $post,

        "dependency" => array(
         "element"=>"category_select",
         "value" => "category"
        )
     ),
		
		
		 array(
        "type" => "dropdown",            
        "class" => "",
        "heading" => __("Faqs Parent Categories", "mango_core"),
        "param_name" => "faqs_parent_categories",
        "value" => $faq,

        "dependency" => array(
         "element"=>"category_select",
         "value" => "faq-category"
        )
     ),
    )
) );


// Mango Banner Vine
vc_map ( array (
    "name" => __ ( "Mango Banner Vine", 'mango_core' ),
    "base" => "mango_banner_vine",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Banner Image", 'mango_core' ),
            "param_name" => "img_active",
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title", 'mango_core' ),
            "param_name" => "title"
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Sub Title", 'mango_core' ),
            "param_name" => "sub_title"
        ),

        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description"
        ),


        array (
            "type" => "href",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Url (Link)", 'mango_core' ),
            "param_name" => "link"
        ),
    )
) );

// Mango discount Box

vc_map ( array (
    "name" => __ ( "Mango Discount Box", 'mango_core' ),
    "base" => "mango_discount_box",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
           "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title", 'mango_core' ),
            "param_name" => "title"
        ),


        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title Color", 'mango_core' ),
            "param_name" => "title_color",
            "value" => array (
                __ ( "Theme Option", "mango_core" ) => '',
                __ ( "Select Color", "mango_core" ) => '',
                __ ( "Warning", "mango_core" ) => 'warning',
                __ ( "Primary", "mango_core" ) => 'primary',
                __ ( "Success", "mango_core" ) => 'success',
            )
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Sub Title", 'mango_core' ),
            "param_name" => "sub_title"
        ),

        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Badge Text", 'mango_core' ),
            "param_name" => "badge"
        ),

        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Badge Color", 'mango_core' ),
            "param_name" => "badge_color",
            "value" => array (
                __ ( "Select Color", "mango_core" ) => '',
                __ ( "Yellow", "mango_core" ) => 'yellow',
                __ ( "Red", "mango_core" ) => 'red',
                __ ( "Blue", "mango_core" ) => 'blue',
            )
        ),
    )
) );

// Mango Category Box

vc_map ( array (
    "name" => __ ( "Mango Category Box", 'mango_core' ),
    "base" => "mango_category_box",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Category Box Image", 'mango_core' ),
            "param_name" => "img_active"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading"
        ),

        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description"
        ),


        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Category", 'mango_core' ),
            "param_name" => "category_select",
            "value" => array (
                __ ( "Select category", "mango_core" ) => '',
                __ ( "Select Post category", "mango_core" ) => 'category',
                __ ( "Select Woocommerce Categories", "mango_core" ) => 'product_cat',
                __ ( "Select FAQ'S Categories", "mango_core" ) => 'faq-category',
            )
        ),


        array (
            "type" => "number",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Number", 'mango_core' ),
            "param_name" => "number_cat",
            "value" => "2"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Badge Text", 'mango_core' ),
            "param_name" => "badge"
        ),


        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Badge Color", 'mango_core' ),
            "param_name" => "badge_color",
            "value" => array (
                __ ( "Select Color", "mango_core" ) => '',
                __ ( "Yellow", "mango_core" ) => 'yellow',
                __ ( "Red", "mango_core" ) => 'red',
                __ ( "Blue", "mango_core" ) => 'blue',
            )
        ),
    )
) );


// Mango Vertical Category
vc_map ( array (
    "name" => __ ( "Mango Vertical Category ", 'mango_core' ),
    "base" => "mango_vertical_categories",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Vertical  Category  Image", 'mango_core' ),
            "param_name" => "img_active"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading"
        ),


        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Category", 'mango_core' ),
            "param_name" => "category_select",
            "value" => array (
                __ ( "Select category", "mango_core" ) => '',
                __ ( "Select Post category", "mango_core" ) => 'category',
                __ ( "Select Woocommerce Categories", "mango_core" ) => 'product_cat',
                __ ( "Select FAQ'S Categories", "mango_core" ) => 'faq-category',
            )

        ),

        array (
            "type" => "number",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Number", 'mango_core' ),
            "param_name" => "number_cat",
            "value" => "2"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Badge Text", 'mango_core' ),
            "param_name" => "badge"
        ),

        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Badge Color", 'mango_core' ),
            "param_name" => "badge_color",
            "value" => array (
                __ ( "Select Color", "mango_core" ) => '',
                __ ( "Yellow", "mango_core" ) => 'yellow',
                __ ( "Red", "mango_core" ) => 'red',
                __ ( "Blue", "mango_core" ) => 'blue',
            )
        ),

    )
) );

// Mango Vertical Banner
vc_map ( array (
    "name" => __ ( "Mango Vertical Banner", 'mango_core' ),
    "base" => "mango_vertical_banner",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Mango Vertical Image", 'mango_core' ),
            "param_name" => "img_active"
        ),
        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Title", 'mango_core' ),
            "param_name" => "title"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Sub Title", 'mango_core' ),
            "param_name" => "sub_title"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Button Text", 'mango_core' ),
            "param_name" => "button_text",
            "description" => __ ( "Text on the button.", 'mango_core' )
        ),

        array (
            'type' => 'href',
            'heading' => __ ( 'URL (Link)', 'mango_core' ),
            'param_name' => 'button_link',
            'description' => __ ( 'Button link.', 'mango_core' )
        ),
    )
) );

// Mango Newsletter

vc_map ( array (
    "name" => __ ( "Mango Newsletter", 'mango_core' ),
    "base" => "mango_newsletter",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading"
        ),

        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description",
        ),

        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Form", 'mango_core' ),
            "param_name" => "select_form",
            "value" => array (
                __ ( "Select Form", "mango_core" ) => '',
                __ ( "Newletter", "mango_core" ) => 'newletter',
            )
        )
    )
) );


// Mango Store

vc_map ( array (
    "name" => __ ( "Mango Store", 'mango_core' ),
    "base" => "mango_store",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Background Image", 'mango_core' ),
            "param_name" => "img_active"
        ),


        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading"
        ),

        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description",
        ),

        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Form", 'mango_core' ),
            "param_name" => "select_form",
            "value" => array (
                __ ( "Select Form", "mango_core" ) => '',
                __ ( "Newletter", "mango_core" ) => 'newletter',
            )
        )
    )
) );

// Mango Login
vc_map ( array (
    "name" => __ ( "Mango Login", 'mango_core' ),
    "base" => "mango_login",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "textfield",
            "holder" => "div",
           "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading"
        ),

        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description"
        ),


        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Form", 'mango_core' ),
            "param_name" => "select_form",
            "value" => array (
                __ ( "Select Form", "mango_core" ) => '',
                __ ( "Login", "mango_core" ) => 'login',
            )
        ),
    )
) );

// Mango Registration
vc_map ( array (
    "name" => __ ( "Mango Registration Form", 'mango_core' ),
    "base" => "mango_registration",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading"
        ),

        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Description", 'mango_core' ),
            "param_name" => "description"
        ),

        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Form", 'mango_core' ),
            "param_name" => "select_form",
            "value" => array (
                __ ( "Select Form", "mango_core" ) => '',
                __ ( "Registration", "mango_core" ) => 'registration',
            )
        ),
    )
) );


/// Mango Slider
vc_map ( array (
    "name" => __ ( "Mango Bootstrap Slider", "mango_core" ),
    "base" => "mango_bootstrap_slider",
    "category" => __ ( 'Mango', 'mango_core' ),
    "class" => "wpb_mango",
    "as_parent" => array ( 'only' => 'mango_add_bootstrap_slider' ),
    "content_element" => true,
    "show_settings_on_create" => true,
    "params" => array (
       array (
            'type' => 'textfield',
            'heading' => __ ( 'Extra class name', 'mango_core' ),
            'param_name' => 'el_class',
            'description' => __ ( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'mango_core' ),
        ),

        array (
           'type' => 'textfield',
            'heading' => __ ( 'Heading', 'mango_core' ),
           'param_name' => 'heading',
        ),
    ),
) );

vc_map ( array (
    "name" => __ ( "Add Slider", 'mango_core' ),
    "base" => "mango_add_bootstrap_slider",
    "content_element" => true,
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "as_child" => array ( 'only' => 'mango_bootstrap_slider' ),
    "params" => array (
        array (
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
           "heading" => __ ( "Slider Image", 'mango_core' ),
            "param_name" => "img_active"
        ),

        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Caption", 'mango_core' ),
            "param_name" => "caption"
        ),
    )
) );

// Mango Tooltips Button

vc_map ( array (
        "name" => __ ( "Mango Tooltips Button", "mango_core" ),
        "base" => "mango_tooltips_button",
        "class" => "wpb_mango",
        "category" => __ ( "Mango", "mango_core" ),
        "params" => array (
            array (
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => __ ( "Button Text", 'mango_core' ),
                "param_name" => "button_text"
            ),

            array (
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => __ ( "Select Button", 'mango_core' ),
                "param_name" => "button_color",
                "value" => array (
                    __ ( "Button Black", "mango_core" ) => 'custom',
                    __ ( "Button Red", "mango_core" ) => 'custom2',
                )
            ),

            array (
                "type" => "textarea",
                "holder" => "div",
                "class" => "",
                "heading" => __ ( "Data  Content", 'mango_core' ),
                "param_name" => "data_content"
            ),

            array (
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => __ ( "Button Placement", 'mango_core' ),
                "param_name" => "button_placement",
                "value" => array (
                    __ ( "Select One", "mango_core" ) => 'top',
                    __ ( "Top", "mango_core" ) => 'top',
                    __ ( "Left", "mango_core" ) => 'left',
                    __ ( "Bottom", "mango_core" ) => 'bottom',
                   __ ( "Right", "mango_core" ) => 'right',
                )
            ),
        )
    )
);

//Text Tooltip


vc_map ( array (

    "name" => __ ( "Mango Text Tooltip", 'mango_core' ),
    "base" => "mango_text_tooltip",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Content", 'mango_core' ),
            "param_name" => "tooldescription"
        ),

        array (
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Text for tooltip", 'mango_core' ),
            "param_name" => "toolbox",
            'description' => 'tooltipone,tooltip2'
        ),

        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Position", 'mango_core' ),
            "param_name" => "select_tool_dir",
            "value" => array (
                __ ( "Select One", "mango_core" ) => 'top',
                __ ( "Top", "mango_core" ) => 'top',
                __ ( "Left", "mango_core" ) => 'left',
                __ ( "Bottom", "mango_core" ) => 'bottom',
                __ ( "Right", "mango_core" ) => 'right',
            )
        ),
    )
) );

//Mango Portfolio

$taxonomy = 'portfolio-category';
$orderby = 'name';       // name , id
$show_count = 0;         // 1 for yes, 0 for no
$pad_counts = 0;         // 1 for yes, 0 for no
$hierarchical = 1;       // 1 for yes, 0 for no
 $title = '';
$empty = 0;
$args = array (
    'taxonomy' => $taxonomy,
    'orderby' => $orderby,
    'show_count' => $show_count,
    'pad_counts' => $pad_counts,
    'hierarchical' => $hierarchical,
    'title_li' => $title,
    'hide_empty' => $empty
);


$all_categories = get_categories ( $args );
$portfolio = array ();

foreach ( $all_categories as $key => $value ) {
    $portfolio[ $value->name ] = $value->name;
}

vc_map ( array (
    "name" => __ ( "Mango Portfolio", 'mango_core' ),
    "base" => "mango_portfolio",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (

        array (
            "type" => "number",
            "holder" => "div",
           "class" => "",
            "heading" => __ ( "Number Of Portfolio Show", 'mango_core' ),
            "param_name" => "number",
            "value" => 1
        ),


        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Categoriees ", 'mango_core' ),
            "param_name" => "portfolio_categories",
            "value" => $portfolio
        ),


        array (
            "type" => "checkbox",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Hide Title", 'mango_core' ),
            "param_name" => "hide_title",
            "value" => array (
                __ ( "YES", "mango_core" ) => 1,
            ),
        ),

        array (
            "type" => "checkbox",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Hide Category", 'mango_core' ),
            "param_name" => "hide_category",
            "value" => array (
                __ ( "YES", "mango_core" ) => 2,
            ),
        ),

        array (
            "type" => "checkbox",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Hide Description", 'mango_core' ),
            "param_name" => "hide_description",
            "value" => array (
                __ ( "YES", "mango_core" ) => 3,
            ),
        ),

        array (
            "type" => "checkbox",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Hide Read More Link", 'mango_core' ),
            "param_name" => "hide_link",
            "value" => array (
                __ ( "YES", "mango_core" ) => 4,
            ),
        ),

        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Styles", 'mango_core' ),
            "param_name" => "style",
            "value" => array (
                __ ( "Select One", "mango_core" ) => '',
                __ ( "Style 1", "mango_core" ) => 'style1',
                __ ( "Style 2", "mango_core" ) => 'style2',
                __ ( "Style 3", "mango_core" ) => 'style3',
            )
        ),
    )
) );

// Mango Simple Category
vc_map ( array (
    "name" => __ ( "Mango Simple Category ", 'mango_core' ),
    "base" => "mango_single_categories",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (
        array (
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading"
        ),

        array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Category", 'mango_core' ),
            "param_name" => "category_select",
            "value" => array (
                __ ( "Select One", "mango_core" ) => '',
                __ ( "Select Post category", "mango_core" ) => 'category',
                __ ( "Select Woocommerce Categories", "mango_core" ) => 'product_cat',
                __ ( "Select FAQ'S Categories", "mango_core" ) => 'faq-category',
            )
        ),

        array (
            "type" => "number",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Number", 'mango_core' ),
            "param_name" => "number_cat",
            "value" => "2"
        ),
    )
) );



//Mango Member



vc_map ( array (
    "name" => __ ( "Mango Members", 'mango_core' ),
    "base" => "mango_member",
    "class" => "wpb_mango",
    "category" => __ ( 'Mango', 'mango_core' ),
    "params" => array (

      
		array (
            "type" => "textfield",
            "holder" => "div",
           "class" => "",
            "heading" => __ ( "Heading", 'mango_core' ),
            "param_name" => "heading",
        ),
		
		array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Heading alignment", 'mango_core' ),
            "param_name" => "style",
            "value" => array (
                __ ( "Select One", "mango_core" ) => '',
                __ ( "Left", "mango_core" ) => 'left',
                __ ( "Center", "mango_core" ) => 'center',
                __ ( "Right", "mango_core" ) => 'right',
            )
        ),

		array (
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => __ ( "Select Columns", 'mango_core' ),
            "param_name" => "colmns",
            "value" => array (
                __ ( "4 Per Column", "mango_core" ) => 4,
                __ ( "3 Per Column", "mango_core" ) => 3,
                __ ( "2 Per Column", "mango_core" ) => 2,
                __ ( "1 Per Column", "mango_core" ) => 1,
            ),
        ),
       


    )
) );
// Mango Feature  Product
?>