<?php

if(!class_exists('SDS_WC_cat')):

	class SDS_WC_cat{
	
		var $data, $sortdata;
		
		public static $sds_wc_cat_page;
	
		function __construct(){
			
			$this->data = json_decode(get_option('sds_wc_saved_conf'),TRUE);	
			            
			$this->sortdata = $this->data;
			
			if(!empty($this->sortdata)):
				
				usort($this->sortdata, array($this,'reorder'));
			
			endif;
			          
		}
		
		function reorder($a, $b){
   
		   $asort = intval($a['sortorder']);
		   
		   $bsort = intval($b['sortorder']);
		   
		   if($asort == $bsort)
			   return 0;
		   
		   elseif($asort < $bsort)
			   return -1;
		   elseif($asort > $bsort)
			   return 1;

		}
                
		function enqueue_SDS_WC_cat_scripts(){
		
			wp_enqueue_script(array('jquery-ui-core','jquery-ui-tabs'),'',array('jquery'));			
			            
		}
		
		function register_SDS_WC_cat_admin_panel(){
			
			global $sds_wc_cat_page;
			
			$sds_wc_cat_page = add_submenu_page( 'edit.php?post_type=product', __('Latest Product by Category','sds' ) , __('Latest Product by Category','sds' ), 'manage_options', 'SDS-WC-category-manager', array($this,'SDS_WC_category_manager_callback'));
			
		
			add_action('load-'.$sds_wc_cat_page, array($this,'sds_wc_cat_add_help'));
			
		}
		
		function sds_wc_cat_add_help(){
			
			global $sds_wc_cat_page;
			
			$screen = get_current_screen();

			if ( $screen->id != $sds_wc_cat_page )
        		return;
			
			 $screen->add_help_tab( array(
				'id'	=> 'sds_help_tab',
				'title'	=> __('Latest Product by Category'),
				'content'	=> 'On first use, you should not see the view like the previous screenshot. It would say <em>Nothing have found. To add new item, click on <strong>Add New</strong> button.</em> </p>
<p>When you click <strong>Add New</strong> button under the table and beside the <strong>Save</strong> button, a new row will appear on the table that replace the <em>Nothing have found</em> row. New row has 6 fields in it, a shortcode notification and a remove button at the rightest column. <strong>Category</strong> dropdown field contains the product categories of woocommerce. <br />
  <br />
  
  
  <strong>Display as</strong> dropdown controls the display mode of the product grid either carousel or wall mode. <br />
  <br />
  
<strong>Subcategory settings</strong> dropdown field decides</p>
<blockquote>
  <p> 1. Products only from selected category, not from child categories, </p>
  <p>2. Products from selected category and child category in the same combination and </p>
  <p>3. Child categories of the selected category divided into tabs with their relevant products. </p>
</blockquote>
<p><strong>Limit</strong> field decides how many products will be shown. </p>
<p><strong>Status</strong> dropdown controls availability of the current setting on frontend. </p>
<p><strong>Sort Order</strong> field used to manage the ordering mechanism of each setting (all positive integer values without 0. 1 should come first in the hierarchy as well as on frontend and so on). </p>
<p><strong>Shortcode</strong> shows shortcode to access the current setting from frontend. </p>
<p>You can add as many configuration as you want. After finishing all job, click on <strong>Save</strong> button after the table to save the current configurations. When you again visit the page, you should see your saved configurations are there.',
			) );
			
			
		}
		
		
		function SDS_WC_category_manager_callback(){
			
			$this->save_SDS_WC_cat_conf();
			
			?>
            <script type="text/javascript">
            
			jQuery(function($){
			
				var output = '<?php $this->print_rows();?>';
			
				$('input.add-new-row').live('click',function(){
				
					if($('#catsettingtable tbody tr.no-sds-row').length > 0){
						$('#catsettingtable tbody tr.no-sds-row').remove();	
					}
				
					$('#catsettingtable tbody').append(output);
					
					var len = $('#catsettingtable tbody tr').length;
					
					$('#catsettingtable tbody tr:last-child td span.shortcode_id').html("[sds-wc-cat id='"+len+"']");					
					
				});
				
				$('.remove-row').live('click',function(){
					
					
					if(!confirm("Are you sure to remove?")) return false;
					
					tbody = $(this).parents('tbody');
					
					var index = $(this).parents('tr').index();
					
					$(this).parents('tr').remove();
					
					if(tbody.find('tr').length){
					
					for(i = index;i < tbody.find('tr').length; i++){
						
						var num = tbody.find('tr').eq(i).find('td span.shortcode_id').html();
						
						num = parseInt(num.match(/\d/));
						
						num = num - 1;
						
						tbody.find('tr').eq(i).find('td span.shortcode_id').html("[sds-wc-cat id='"+num+"']");
						
					}
					}
					
					if(tbody.find('tr').length < 1){
					
						tbody.html('<tr class="no-sds-row"><td colspan="7">Nothing have found. To add new item, click on <strong>Add New</strong> button.</td></tr>');
						
					}
				
				});
				
			});
            
            </script>
			<style type="text/css">
			
			.limit,.sortorder{
				width:50px;	
			}
			.catdropdown{
				max-width:100px;	
			}
			.subcatsetdropdown{
				width: 130px;				
			}
			#catsettingtable thead tr th, #catsettingtable tfoot tr th{
				padding-left:15px;		
			}			
			#catsettingtable tbody tr td{
				padding: 15px 0 15px 10px;	
			}
			
			
			
			</style>
			<div class="wrap nosubsub">
				<div id="icon-edit" class="icon32 icon32-posts-product">
					<br>
				</div>
				<h2><?php echo __('SDS Woocommerce Latest Product by Category Manager','sds');?></h2>
                <br />
                <?php
                if(isset($_GET['success'])):
				
					$message = '<div id="message" class="updated below-h2"><p>Saved.</p></div>'; 
				
					echo $message;
				
                endif;
                ?>
               
				<form action="<?php echo admin_url("edit.php?post_type=product&page=SDS-WC-category-manager");?>" method="post">
                <table id="catsettingtable" class="wp-list-table widefat fixed posts" border="1" cellpadding="12" cellspacing="0" align="left">
                	<thead>
                        <tr>
                            <th>Category</th>
                            <th>Display as</th>
                            <th>Subcategory settings</th>
                            <th>Limit</th>
                            <th>Status</th>
                            <th>Sort Order</th>
                            <th>Shortcode</th>
                            <th>&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody>
                    	<?php 
						if(!empty($this->sortdata)):
							foreach($this->sortdata as $k=>$data):
								
								$GLOBALS['counter'] = $k;
							
								$this->print_rows($data);
															
							endforeach;
						else:
						
						?>
                        <tr class="no-sds-row">
                        <td colspan="7">Nothing have found. To add new item, click on <strong>Add New</strong> button.</td>
                        </tr>
                        <?php	
						
						endif;
						?>                       
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Category</th>
                            <th>Display as</th>
                            <th>Subcategory settings</th>
                            <th>Limit</th>
                            <th>Status</th>
                            <th>Sort Order</th>
                            <th>Shortcode</th>
                            <th>&nbsp;</th>
                        </tr>
                    </tfoot>
                    
                </table>
                <br />                

				<div style="float:left; width:100%; margin-top:20px;"><input type="button" value="Add New" class="button-secondary add-new-row" />&nbsp;&nbsp;<input type="submit" value="Save" name="save-conf" class="button-primary" /></div>
                </form>
			</div>
			<?php    
				
		}
		
		function print_rows($data = array()){
			
			$catdropdown = isset($data['catdropdown']) ? $data['catdropdown'] : '';
			
			$displaydropdown = isset($data['displaydropdown']) ? $data['displaydropdown'] : '';
			
			$subcatsetdropdown = isset($data['subcatsetdropdown']) ? $data['subcatsetdropdown'] : '';
			
			$limit = isset($data['limit']) ? $data['limit'] : '';
			
			$statusdropdown = isset($data['statusdropdown']) ? $data['statusdropdown'] : '';
			
			$sortorder = isset($data['sortorder']) ? $data['sortorder'] : '';
			
			$counter = isset($GLOBALS['counter'])?$GLOBALS['counter']:0;
			
			?><tr><td><?php $this->get_sds_wc_fields('catdropdown',$catdropdown); ?></td><td><?php $this->get_sds_wc_fields('displaydropdown',$displaydropdown); ?></td><td><?php $this->get_sds_wc_fields('subcatsetdropdown',$subcatsetdropdown); ?></td><td><?php $this->get_sds_wc_fields('limit',$limit); ?></td><td><?php $this->get_sds_wc_fields('statusdropdown',$statusdropdown); ?></td><td><?php $this->get_sds_wc_fields('sortorder',$sortorder); ?></td><td><?php $this->get_sds_wc_fields('shortcode',$counter); ?></td><td><?php $this->get_sds_wc_fields(''); ?></td></tr><?php
			
		}
		
		
		function save_SDS_WC_cat_conf(){
			
			if(isset($_POST['save-conf'])):
			
				$data = array();
				
				if(isset($_POST['catdropdown'])):
				
					foreach($_POST['catdropdown'] as $key=>$catdropdown):
					
						$data[$key] = array();
						
						$data[$key]['catdropdown'] = $catdropdown;
						
						$data[$key]['displaydropdown'] = $_POST['displaydropdown'][$key];
						
						$data[$key]['subcatsetdropdown'] = $_POST['subcatsetdropdown'][$key];
						
						$data[$key]['statusdropdown'] = $_POST['statusdropdown'][$key];
						
						$data[$key]['sortorder'] = $_POST['sortorder'][$key];
						
						$data[$key]['limit'] = $_POST['limit'][$key];
						
					
					endforeach;
					
				
				endif;
				
				$json = json_encode($data);
				
				add_option('sds_wc_saved_conf',$json,'','yes') or update_option('sds_wc_saved_conf',$json);
				?>
                <script type="text/javascript">
                  
					window.location.href = '<?php echo admin_url("edit.php?post_type=product&page=SDS-WC-category-manager&success=true");?>';
				
				</script>
                <?php
			
			endif;
			
		}
		
		function get_sds_wc_fields($fieldtype, $data = ''){
			
			$selected = "";	
			
			switch($fieldtype):
			
				case 'catdropdown':
				
					$terms = $this->get_categories();
					
					echo "<select class=\"catdropdown\" name=\"catdropdown[]\">";
					
					if(!empty($terms)):					
					
					foreach($terms as $term):
					
						$selected = "";
						
						if(intval($data) == intval($term->term_id)):
							
							$selected = "selected=\"selected\"";
							
						endif;
						
						$title = '';
						
						$titlearray = array();
						
						$id = $term->parent;
						
						for(;;):
							
							$pr = get_term($id,'product_cat');
							
							if(!is_wp_error($pr)):
								$id = $pr->parent;
								$titlearray[] = $pr->name;
							endif;
							
							if($id == 0) break;
							
						endfor;
						
						if(!empty($titlearray)):
						
							$titlearray = array_reverse($titlearray);
						
							foreach($titlearray as $a):
							
								$title .= "$a &raquo; ";
							
							endforeach;
						
						endif;
						
						$title .= $term->name;
						
						echo "<option $selected value=\"$term->term_id\">".addslashes($title)."</option>";
					
					endforeach;
					
					endif;
					
					echo "</select>";
				
				break;
				
				case 'displaydropdown': 
				
					$selected = " selected=\"selected\"";
				
					echo "<select class=\"displaydropdown\" name=\"displaydropdown[]\"><option value=\"normal\"".($data == 'normal' ? $selected : '').">Normal</option><option value=\"carousel\"".($data == 'carousel' ? $selected : '').">Carousel</option></select>";
				
				break;
				
				case 'subcatsetdropdown': 
				
					$selected = " selected=\"selected\"";
				
					echo "<select class=\"subcatsetdropdown\" name=\"subcatsetdropdown[]\"><option value=\"0\"".($data == '0' ? $selected : '').">No subcategory products</option><option value=\"1\"".($data == '1' ? $selected : '').">Products from subcategories too</option><option value=\"2\"".($data == '2' ? $selected : '').">Tab style for each subcategory and its products</option></select>";
				
				break;
			
				case 'statusdropdown': 
				
					$selected = " selected=\"selected\"";
				
					echo "<select name=\"statusdropdown[]\"><option".($data == '1' ? $selected : '')." value=\"1\">Enabled</option><option".($data == '0' ? $selected : '')." value=\"0\">Disabled</option></select>";
				
				break;
				
				case 'sortorder': 
				
					$data = !empty($data) ? $data : 1;
				
					echo "<input type=\"text\" class=\"sortorder\" name=\"sortorder[]\" value=\"$data\" />";
				
				break;
				
				case 'limit':
				
					$data = !empty($data) ? $data : 4;
				
					echo "<input type=\"text\" class=\"limit\" name=\"limit[]\" value=\"$data\" />";
				
				break;
				
				case 'shortcode':
				
					echo "<span class=\"shortcode_id\">[sds-wc-cat id=\"".(int)($data+1)."\"]</span>";
				
					break;
				
				default:
				
					echo "<input type=\"button\" value=\"Remove\" class=\"button-secondary remove-row\" />";
				
				break;
				
			endswitch;
			
		}
		
		function get_categories(){
			
			global $wpdb;
			
			$res = $wpdb->get_results("select * from $wpdb->term_taxonomy tt left join $wpdb->terms t on tt.term_id = t.term_id where tt.taxonomy = 'product_cat'");
			
			if(!is_wp_error($res)) return $res;
				
			return false;
						
		}
		
	}

endif;
?>