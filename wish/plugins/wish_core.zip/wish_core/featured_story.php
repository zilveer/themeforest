<?php  
// Plain Hero, no images and stuff
class Wish_Featured_Story{

        var $shortcode = 'wish_featured_story';
        var $title = "Featured Story";
        var $details = "Story With an image on the left and text on the right";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link" => "http://i.imgur.com/asMlsmU.png",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'wish'),
            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor
            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
            "params" => array(

                            array(
                                    "type" => "textfield",
                                    "heading" => __("Title", "wish"),
                                    "param_name" => "title",
                                    "admin_label" => true,
                                    "description" => __("The Title.", "wish"),
                                    "value" => __("Our Story", 'wish'),
                                    "admin_label" => true,
                            ),

                            array(
                                "type" => "textarea",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Details", 'wish'),
                                "param_name" => "details",
                                "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
                                "description" => __("Text in Column 1 (left)", 'wish'),
                                "admin_label" => false,
                            ),


                            array(
                                "type" => "attach_image",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Image On The Left", 'wish'),
                                "param_name" => "image1",
                                "description" => __("The Image on the left Side.", 'wish'),
                                "admin_label" => false,
                            ),


                            array(
                                "type" => "vc_link",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Link To The Page", 'wish'),
                                "param_name" => "link",
                                "description" => __("The Link below the text", 'wish'),
                                "admin_label" => false,
                            ), 

                            array(
                                "type" => "textfield",
                                "heading" => __("Link Text", "wish"),
                                "param_name" => "link_text",
                                "description" => __("The Text in the above link, set it blank if you want to hide the link", "wish"),
                                "value" => __("Discover", 'wish'),
                                "admin_label" => false,
                            ),

                            array(
                                "type" => "dropdown",
                                "heading" => __("Image Position", "wish"),
                                "param_name" => "img_position",
                                "description" => __("Which side you want the image to show", "wish"),
                                "value" => array( 
                                                  "left"     => "left",
                                                  "right"     => "right",
                                                ),
                                "std"       =>   "left",
                            ),                            



                            /*Title*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __("Title Text Font", "wish" ),
                                "param_name" => "title_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Title Size", "wish"),
                                "param_name" => "title_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("60", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __("Title Text Color", "wish" ),
                                "param_name" => "title_color",
                                "value" => '#df4322 ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),

                            /*Details*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __("Details Text Font", "wish" ),
                                "param_name" => "details_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Details Size", "wish"),
                                "param_name" => "details_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("14", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __("Details Text Color", "wish" ),
                                "param_name" => "details_color",
                                "value" => '#000 ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),





                    )

        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'         => 'Our Story',
        'title_font'    => '',
        'title_size'    => '60',
        'title_color'   => '#df4322',

        'details'       => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.',
        'details_font'  => '',
        'details_size'  => '14',
        'details_color' => '#000',

        'image1'        => 'image1',
        'link'          => '#',
        'img_position'  => 'left',
        'link_text'     => ''
      ), $atts ) );

        /*title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


      $link = vc_build_link($link); //parse the link
      $link_url = $link["url"];
      $link_target = $link["target"];

      $link_string = "<div class='buttons animated' data-animation='flipInX' data-animation-delay='500'><a href='{$link_url}' class='fill'>{$link_text}</a></div>";
     
      if($link_text == ""){
        $link_string = "";
      }


      $imgsrc1 = wp_get_attachment_image_src( $image1, 'full' );

      if($image1 == "image1"){
        $imgsrc1[0] = plugins_url('images/clock1.jpg', __FILE__);
      }

      if($img_position == "left"){

          $output = "<div class='container-fluid featured-story'>
                        <div class='row'>

                            <div class='col-lg-6 picture animated' data-animation='fadeInUp' data-animation-delay='100'>
                                <img src='{$imgsrc1[0]}' class='img-responsive' alt='Our Story'>
                            </div>

                            <div class='col-lg-6'>
                                <h1 class='animated' data-animation='fadeInUp' data-animation-delay='300' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                                <div class='description animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                                {$link_string}
                            </div>


                        </div>
                    </div>";

       }else{

          $output = "<div class='container-fluid featured-story'>
                        <div class='row'>

                            <div class='col-lg-6'>
                                <h1 class='animated' data-animation='fadeInUp' data-animation-delay='300' style='color:{$title_color}'>{$title}</h1>
                                <div class='description animated' data-animation='fadeInUp' data-animation-delay='800' style='color:{$details_color}'>{$details}</div>
                                {$link_string}
                            </div>


                            <div class='col-lg-6 picture animated' data-animation='fadeInUp' data-animation-delay='100'>
                                <img src='{$imgsrc1[0]}' class='img-responsive' alt='Our Story'>
                            </div>

                        </div>
                    </div>";

       }      



      return $output;
    }

    /*
    Load plugin css and javascript files which you may need on front end of your site
    */
    public function loadCssAndJs() {
      //wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
      //wp_enqueue_style( 'vc_extend_style' );

      // If you need any javascript files on front end, here is how you can load them.
      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );
    }

    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }



}//end of class
?>