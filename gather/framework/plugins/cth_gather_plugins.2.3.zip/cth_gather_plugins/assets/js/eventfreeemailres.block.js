var rules = {
    first_name: "required",
    last_name: "required",
    email: {
        required: true,
        email: true
    },
    //os0: "required",
    //quantity: "required",
    agree: "required"
};
var add_fields_validate = eventres_ajax.add_fields_validate ? eventres_ajax.add_fields_validate : {};
// console.log(add_fields_validate);
jQuery.each(add_fields_validate, function(key, value) {
    rules[key] = value;
});
// console.log(rules);
jQuery("#email-registration-form").submit(function(e) {
    e.preventDefault();
}).validate({
    rules: rules,
    messages: {
        first_name: eventres_ajax.msg_fname,
        last_name: eventres_ajax.msg_lname,
        email: eventres_ajax.msg_email,
        os0: eventres_ajax.msg_pass,
        quantity: eventres_ajax.msg_seats,
        agree: eventres_ajax.msg_agree
    },
    submitHandler: function(form) {

        jQuery("#reserve-btn").attr("disabled", true);
        jQuery('#eventreg_msg').css('display','none');
        ajaxEmailEventReg(form);

    }
});
function ajaxEmailEventReg(form){
    var redirect = jQuery(form).data('redirect');
    var noredirect = false;
    // console.log(redirect);
    if (redirect == 'none' || redirect == "" || redirect == undefined) {
        noredirect = true;
    }
    // console.log(noredirect);
    jQuery('#eventreg_msg').fadeIn('slow').html(eventres_ajax.msg_wait);

    contents = jQuery(form).serialize();
    contents += '&action=gather_event_email_registration';

    jQuery.post( eventres_ajax.url, contents, function( data ){
        //jQuery('#eventreg_msg').html('').fadeOut('slow');
        //console.log(data);
        if(data.success == 1){
            //window.location = data.message;
            if (noredirect) {
                jQuery('#eventreg_msg').html(data.message).delay(5000).fadeOut('slow');
            } else {
                window.location.href = redirect;
            }
            //jQuery('#eventreg_msg').html(data.message).css('display','block');
        }else{
            jQuery('#eventreg_msg').html(data.message).delay(5000).fadeOut('slow');
            //jQuery('#eventreg_msg').html(data.message).css('display','block');
            jQuery("#reserve-btn").attr("disabled", false);
        }
    }, 'json');
}