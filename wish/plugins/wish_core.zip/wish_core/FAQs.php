<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("FAQs", "wish"),
    "description" => __("FAQs", 'wish'),
    "controls" => "full",
    "base" => "wish_faqs",
    "as_parent" => array('only' => 'wish_faqs_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/0dbSCh2.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "wish_fontawesome_param",
            "holder" => "div",
            "class" => "",
            "heading" => __("Custom Icon", 'wish'),
            "param_name" => "custom_icon",
            "value" => __("fa-clock-o", 'wish'),
            "description" => __("Get Font Awesome Icons Code Here: <a target='_blank' href='http://fortawesome.github.io/Font-Awesome/cheatsheet/'>Link</a>, New icons may not work. Leave blank if you want to use the above icon.", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Icon color", "wish" ),
            "param_name" => "icon_color",
            "value" => '#252525', //Default Red color
            "description" => __( "Choose color of icon", "wish" ),
            "group"       => "Fonts & Colors",
         ),
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Top Title", "wish"),
            "value" => __("EASY TO USE", 'wish'),
            "admin_label" => true,
        ), 

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("We enjoy working on the Services & Products we provide as much as you need them This help us in delivering your Goals easil", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("Link To The Page", 'wish'),
            "param_name" => "link",
            "description" => __("The Link below the text", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Link Title", "wish"),
            "param_name" => "link_text",
            "description" => __("The Link Title", "wish"),
            "value" => __("Buy Theme", 'wish'),
            "admin_label" => false,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#252525 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#252525 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Question", "wish"),
    "base" => "wish_faqs_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_faqs'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Top Title", "wish"),
            "value" => __("How to vertically align a tag", 'wish'),
            "admin_label" => true,
        ), 

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),
   

        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#252525 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#252525 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#fff', //Default Red color
            "description" => __( "Choose Background color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_FAQs extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'custom_icon' => 'fa-clock-o',
            'icon_color' => '#252525',
            
            'title' => 'EASY TO USE',
            'title_font'    => '',
            'title_size'    => '20',
            'title_color' => '#252525',

            'details' => 'We enjoy working on the Services & Products we provide as much as you need them This help us in delivering your Goals easil',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#252525',

            'link' => '',
            'link_text' => '',
            'bgcolor'   => '#fff'  
          ), $atts ) );

           /*title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


         /*details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

           if($link == "||" || $link == "" ){
            
            $link_text = "Buy Theme";
            $link_url = "#";
            $link_target = "";
            $link_String="";

          }else{

            $link = vc_build_link($link); //parse the link
            $link_url = esc_url($link["url"]);
            $link_target = esc_attr($link["target"]);
            $link_String="<div class='dark-sqr-buttons animated' data-animation='fadeInUp' data-animation-delay='1200' style='margin-top:40px'><a href='{$link_url}' class='fill'>{$link_text}</a></div>";
            if ($link_text == "") {
                $link_String = "";
            }

          }


      $output = "<div class='easy-to-use' style='color:{$bgcolor}'>
            <div class='container'>
                <div class='row'>
                    <!-- Column 1 Starts -->
                    <div class='col-lg-5'>
                        <div class='icon animated' data-animation='fadeInUp' data-animation-delay='100'><i class='fa {$custom_icon}' style='color:{$icon_color}'></i></div>
                        <h1 class='animated' data-animation='fadeInUp' data-animation-delay='400' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                        <div class='description animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                        {$link_String}
                    </div>
                    <!-- Column 1 Ends -->
                    <!-- Column 2 Starts -->
                    <div class='col-lg-6 col-lg-offset-1 accordion'>
                        <div class='panel-group' id='accordion' role='tablist' aria-multiselectable='true'>
                    " . do_shortcode($content) . "
                
            </div>
                    </div>
                    <!-- Column 2 Ends -->
                </div>
            </div>
        </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_FAQs_Single extends WPBakeryShortCode {
        static $count = 0;

        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'title' => ' How to vertically align a tag',
            'title_font'    => '',
            'title_size'    => '16',
            'title_color' => '#252525',

            'details' => 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson',
            'details_font'  => '',
            'details_size' => '14',
            'details_color' => '#252525'
          ), $atts ) );

          /*title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


         /*details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

          self::$count++;


          $var = self::$count;


          $output = "<div class='panel panel-default'>
                        <div class='panel-heading' role='tab' id='heading{$var}'>
                            <h4 class='panel-title animated' data-animation='fadeInUp' data-animation-delay='900'>
                                <a data-toggle='collapse' data-parent='#accordion' href='#collapse{$var}' aria-expanded='false' aria-controls='collapse{$var}' class='collapsed question' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>
                                {$title}
                                </a>
                            </h4>
                        </div>
                        <div id='collapse{$var}' class='panel-collapse collapse' role='tabpanel' aria-labelledby='heading{$var}' aria-expanded='false'>
                            <div class='panel-body answer' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>
                                {$details}
                            </div>
                        </div>
                    </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>