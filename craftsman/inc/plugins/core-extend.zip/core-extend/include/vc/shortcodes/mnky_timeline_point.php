<?php
$output = '';

	$accent_color = '#e74c3c';
	
	if ( function_exists( 'ot_get_option' ) ) {
	  $accent_color = ot_get_option('accent_color');
	}

	extract(shortcode_atts(array(
		'title' => 'First Event',
		'point_color' => $accent_color,
		'position' => '0',
		'el_class' => ''
	), $atts));
			
	$el_class = $this->getExtraClass($el_class);
	$animation_delay = $this->getExtraClass('mnky-timeline-event-'.$position);
	
	$css_class = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'mnky-timeline-event'.$animation_delay.$el_class, $this->settings['base']);

		
	$output .= '<div class="'.$css_class.'" style="left:'.$position.'%">';
	$output .= '<div class="mnky-event-title">'. $title .'</div>';
	$output .= '<div class="mnky-event-hook" style="background:'.$point_color.'"></div>';
	$output .= '<div class="mnky-event-description">'. wpb_js_remove_wpautop($content) .'</div>';
	$output .= '</div>';
	


echo $output;