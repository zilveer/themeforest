<?php 
if ( class_exists( 'WPBakeryShortCode' ) ) {

	class WPBakeryShortCode_experience_portfolio_custom extends WPBakeryShortCodesContainer {
		
		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = null ) {
		
			$output = $css_class = '';
			
			extract( shortcode_atts( array(
				'el_class'		=> '',
				'css'			=> '',
				'color'			=> '',
				'grid_width'	=> ''
			), $atts ) );
			
			$class = $this->getExtraClass( $el_class );			
			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );
			
			$output .= '<div class="section-content-wrapper '. esc_attr( $css_class .' '. $color ) .'">
				
				<div class="post-grid portfolio-grid clearfix '. esc_attr( $grid_width ) .'">';
				
					$output .= wpb_js_remove_wpautop( $content );
					
				$output .= '</div>
				
			</div>';
			
			return $output;
			
		}

	}


	// ---------- CUSTOM PORTFOLIO ITEM ---------- //

	class WPBakeryShortCode_experience_portfolio_custom_item extends WPBakeryShortCode {
		
		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		 
		protected function content( $atts, $content = null ) {		
			
			$experience_vc_utilities = new jsComposerExperienceUtilities();
			
			$output = $fancybox_class = $path_info = $url_info = $button_text = '';	
			
			extract( shortcode_atts( array(			
				'title'				=> '',
				'button'			=> '',
				'background_image'	=> '',
				'hide_title'		=> '',
				'link_type'			=> ''
			), $atts ) );			
			
			$output .= '<article class="post-grid-item" ontouchstart="">
				
				<div class="post-grid-item-image">';					
					
					// Background Image
					if ( $background_image != "" ) {						
						$background_image = wp_get_attachment_image_src( $background_image, 'post-grid' );
						$background_image = $background_image[0];
					} else {
						$background_image = false;
					}
					
					$output .= $experience_vc_utilities->experienceGetBackground(					
						$background_image,
						false,
						false,
						false, 
						false,
						false,
						false
					);
				
				$output .= '</div>';
				
				$output .= '<div class="post-grid-item-content">
					
					<span class="post-grid-item-content-bg"></span>
					
					<div class="holder">
					
						<div class="cont">';
							
							if ( $title != "" && $hide_title != 'true' ) {						
								$output .= '<h2>'. esc_html( $title ) .'</h2>';
							}
							
						$output .= '</div>
						
					</div>
				
					<div class="holder">
		
						<div class="cont">';
							
							if ( $button != "" && $button != "||" ) {
							
								$button = vc_build_link( $button );
								
								// Detect lightbox content type
								$path_info = pathinfo( $button['url'] );
								$url_info = parse_url( $button['url'] );

								// MP4 / WEBM
								if (
									(
										isset( $path_info['extension'] )
										&& in_array( $path_info['extension'], array( 'mp4', 'webm' ) )
									)
									|| (
										isset( $url_info['host'] )
										&& ( 
											$url_info['host'] == 'www.youtube.com' || $url_info['host'] == 'youtube.com' || $url_info['host'] == 'youtu.be'
											|| $url_info['host'] == 'www.vimeo.com' || $url_info['host'] == 'vimeo.com'
											|| $url_info['host'] == 'www.dailymotion.com' || $url_info['host'] == 'dailymotion.com'
										)
									)
								) {
									
									$fancybox_class = 'fancybox';

								}
								
								if ( $button['title'] !="" ) {
									$button_text = esc_html( $button['title'] );
								} else {
									$button_text = esc_html__( 'View', 'js_composer_experience' );
								}
								
								if ( $link_type == 'title' ) {
									$output .= '<a class="'. esc_attr( $fancybox_class ) .'" href="'. esc_url( $button['url'] ) .'" target="'. esc_attr( $button['target'] ) .'"><h2>'. esc_html( $title ) .'</h2></a>';
								} else {
									$output .= '<a class="vc_btn3 '. esc_attr( $fancybox_class ) .'" href="'. esc_url( $button['url'] ) .'" target="'. esc_attr( $button['target'] ) .'">'. $button_text .'</a>';
								}
							
							} else {
								
								// Output background image as link								
								if ( $link_type == 'title' ) {
									$output .= '<a class="fancybox" href="'. esc_url( $background_image ) .'" rel="bookmark" data-fancybox-type="image"><h2>'. esc_html( $title ) .'</h2></a>';
								} else {
									$output .= '<a class="vc_btn3 fancybox" href="'. esc_url( $background_image ) .'" rel="bookmark" data-fancybox-type="image">'. esc_html__( 'View', 'js_composer_experience' ) .'</a>';
								}
							}
							
						$output .= '</div>
						
					</div>
			
				</div>
				
			</article>';
			
			return $output;
			
		}
		
	}
	
}


/* --------- CUSTOM PORTFOLIO --------- */

vc_map( array(
	"base"						=> "experience_portfolio_custom",
	"name"						=> esc_html__( "Portfolio (Custom)", "js_composer_experience" ),
	"description"				=> esc_html__( "Portfolio created from custom grid items", "js_composer_experience" ),
	"content_element"			=> true,
	"as_parent"					=> array( "only" => "experience_portfolio_custom_item" ),
	"js_view"					=> "VcColumnView",
	"params"					=> array(
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"type"			=> "textfield",
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			'admin_label'	=> true
		),
		
		// ----- CSS ----- //
		
		// CSS
		array(
			"type"		 => "css_editor",
			"heading"	 => esc_html__( "CSS", "js_composer_experience" ),
			"param_name" => "css",
			"group"		 => esc_html__( "Design options", "js_composer_experience" )
		)

	)

) );


/* --------- CUSTOM PORTFOLIO ITEM --------- */

vc_map( array(
	"base"				=> "experience_portfolio_custom_item",
	"name"				=> esc_html__( "Custom Portfolio Item", "js_composer_experience" ),
	"as_child"			=> array( "only" => "experience_portfolio_custom" ),
	"params"			=> array(		
		
		// Title
		array(
			"param_name"	=> "title",
			"heading"		=> esc_html__( "Title", "js_composer_experience" ),
			"type"			=> "textfield",
			"description"	=> esc_html__( "Enter the portfolio item title.", "js_composer_experience" ),
			'admin_label' => true
		),
		
		// Button
		array(
			"param_name"	=> "button",
			"heading"		=> esc_html__( "Button URL", "js_composer_experience" ),
			"type"			=> "vc_link",
			"description"	=> esc_html__( "Enter the URL this portfolio item links to. Set the button text using the Link Text input field.", "js_composer_experience" ),
			'admin_label' => true			
		),
		
		// Hide Title
		array(
			"param_name"	=> "hide_title",
			"heading"		=> esc_html__( "Hide Title", "js_composer_experience" ),
			"description"	=> esc_html__( "Do not show the portfolio item title.", "js_composer_experience" ),
			"type"			=> "checkbox"
		),
		
		// Link Type
		array(
			"param_name"	=> "link_type",			
			"heading"		=> esc_html__( "Link Style", "js_composer_experience" ),
			"description"	=> esc_html__( "Choose the style of link shown on portfolio item.", "js_composer_experience" ),
			"type"			=> "dropdown",
			'value'			=> array(
				esc_html__( 'Button', "js_composer_experience" )	=> '',
				esc_html__( 'Title', "js_composer_experience" )	=> 'title'
			)
		),
		
		// ----- BACKGROUND ----- //
		
		// Background Image
		array(
			"param_name"	=> 'background_image',
			"heading"		=> esc_html__( 'Background Image', "js_composer_experience" ),
			"description"	=> esc_html__( "Select a background image for this row.", "js_composer_experience" ),
			"type"			=> 'attach_image',
			"group"			=> esc_html__( "Background", "js_composer_experience" ),
			"weight"		=> 900
		)

	)

) );