  <article>
    %IMG%
    <div>
      <h3>%TITLE%</h3>
%CONTENT%
      <p class="cta">%LINK_TEMPLATE% %LINK_MORE_TEMPLATE%</p>
    </div>
  </article>

