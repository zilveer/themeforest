<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Our Stats", "wish"),
    "description" => __("Our Stats with Image and Name", 'wish'),
    "controls" => "full",
    "base" => "wish_our_stats",
    "as_parent" => array('only' => 'wish_our_stats_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Title", "wish"),
            "value" => __("CHECKOUT OUR SKILLS !", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#363635', //Default color
            "description" => __( "Choose Title text color", "wish" )
        ),

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Lorem Ipsum är en utfyllnadstext från tryck- och förlagsindustrin. Lorem ipsum har varit standard ända.", 'wish'),
            "description" => __("Details", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#363635', //Default color
            "description" => __( "Choose details text color", "wish" )
        ),
        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Backgroung Image", 'wish'),
            "param_name" => "bgimage",
            "admin_label" => false,    
        ),


    ),

));//ends vc_map



//////////////child elements
vc_map( array(
    "name" => __("Stats", "wish"),
    "base" => "wish_our_stats_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_our_stats'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "textfield",
            "heading" => __("Count", "wish"),
            "param_name" => "count",
            "description" => __("Count", "wish"),
            "value" => __("15", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Count Text Color", "wish" ),
            "param_name" => "count_color",
            "value" => '#D96453', //Default color
            "description" => __( "Choose Count text color", "wish" )
        ),

        array(
            "type" => "textfield",
            "heading" => __("Name", "wish"),
            "param_name" => "name",
            "description" => __("Name", "wish"),
            "value" => __("Countries", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Name Text Color", "wish" ),
            "param_name" => "name_color",
            "value" => '#363635', //Default color
            "description" => __( "Choose Name text color", "wish" )
        ),
        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Lorem Ipsum is simply dummy text of the printing and typesetting industry.", 'wish'),
            "description" => __("Details", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#363635', //Default color
            "description" => __( "Choose details text color", "wish" )
        ),

        array(
            "type" => "textfield",
            "heading" => __("Pie Chart percentage", "wish"),
            "param_name" => "percent",
            "description" => __("Pie Chart Percentage", "wish"),
            "value" => __("85", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Pie Chart Name", "wish"),
            "param_name" => "pie_name",
            "description" => __("Pie Chart Name", "wish"),
            "value" => __("Marketing", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Name Text Color", "wish" ),
            "param_name" => "pie_name_color",
            "value" => '#363635', //Default color
            "description" => __( "Choose Name text color", "wish" )
        ),



    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Our_Stats extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title' => 'CHECKOUT OUR SKILLS !',
            'title_color' => '#363635',
            'details' => 'Lorem Ipsum är en utfyllnadstext från tryck- och förlagsindustrin. Lorem ipsum har varit standard ända',
            'details_color' => '#363635',
            'bgimage' => 'Image',
          ), $atts ) );


        $bgimg = wp_get_attachment_image_src( $bgimage, 'full' );

          if($bgimage == "Image"){
            $bgimgsrc = plugins_url('images/manhattan-336708_1280.jpg', __FILE__);
            $bgimg[0] = $bgimgsrc;
          }

        wp_enqueue_script('wish-easing', plugins_url('assets/jquery.easing.min.js', __FILE__), array('jquery') );
        wp_enqueue_script('wish-easypiechart', plugins_url('assets/jquery.easypiechart.min1.js', __FILE__), array('jquery') );


      $output = "
      <div class='our-stats' style='background-image:url({$bgimg[0]});'>
      <div class='banner-opacity'>
  <div class='container'>
    <div class='row col-lg-12'>
        <div class='row'>
          <div class='col-md-6'>
            <h3 style='color:{$title_color};'>{$title}</h3>
            <p style='color:{$title_color}'>{$details}</p>
          </div>
        </div>
        <div class='row'>
                    " . do_shortcode($content) . "
      </div>
    </div>
    </div>
  </div>
</div>
";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Our_Stats_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'count'   => '15',
            'count_color' => '#D96453',
            'name' => 'countries',
            'name_color' => '#363635',
            'details' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry',
            'details_color' => '#363635',
            'percent' => '85',
            'pie_name' => 'Marketing',
            'pie_name_color' => '#363635',
          ), $atts ) );


          $output = "<div class='col-md-3  animated' data-animation='fadeInUp' data-animation-delay='400'>
            <h2 style='color:{$count_color}'>{$count}</h2>
            <h5 style='color:{$name_color}'>{$name}</h5>
            <p class='description' style='color:{$details_color}'>{$details}</p>
            <div class='pie-chart .centered'>
              <span class='chart' data-percent='{$percent}'>
                <span class='percent'></span>%
              </span>
              <div class='title' style='color:{$pie_name_color}'>{$pie_name}</div>
            </div>
          </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>