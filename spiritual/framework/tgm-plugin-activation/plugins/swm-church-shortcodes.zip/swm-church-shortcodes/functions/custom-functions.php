<?php

if ( !function_exists( 'swm_short_title' ) ) {

	function swm_short_title($text, $limit) { 
	  $chars_limit = $limit;
	  $chars_text = strlen($text);
	  $text = $text." ";
	  $text = substr($text,0,$chars_limit);
	  $text = substr($text,0,strrpos($text,' '));
	 
	  if ($chars_text > $chars_limit)
	     { $text = $text."..."; } 
	     return $text;
	}

}

add_action( 'plugins_loaded', 'swm_polishortcodes_load_textdomain' );

function swm_polishortcodes_load_textdomain() {
  load_plugin_textdomain( 'poli-shortcodes', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}