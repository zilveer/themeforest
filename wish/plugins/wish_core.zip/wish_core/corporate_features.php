<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Corporate Features", "wish"),
    "description" => __("Corporate Features with Image and Name", 'wish'),
    "controls" => "full",
    "base" => "wish_corporate_feature",
    "as_parent" => array('only' => 'wish_corporate_feature_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link" => "http://i.imgur.com/5wYHSKd.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#ffffff', //Default color
            "description" => __( "Choose Background color", "wish" )
        ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Corporate Feature", "wish"),
    "base" => "wish_corporate_feature_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_corporate_feature'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,    
        ),

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Title", "wish"),
            "value" => __("RESPONSIVE DESIGN", 'wish'),
            "admin_label" => false,
        ),


        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Lorem Ipsum is simply dummy text of the printing and typesetting industry.", 'wish'),
            "description" => __("Details", 'wish'),
            "admin_label" => false,
        ),

        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("16", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#D96453 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#9B9C9D ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Corporate_Feature extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'bgcolor' => '#ffffff',
          ), $atts ) );


      $output = "<div class='corporate-feature' style='background-color:{$bgcolor}'>
                        <div class='container'>
                                    " . do_shortcode($content) . "
                  </div>
                </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Corporate_Feature_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image'   => 'Image',

            'title'         => 'RESPONSIVE DESIGN',
            'title_font'    => '',
            'title_size'    => '16',
            'title_color'   => '#333',

            'details'       => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#9B9C9D',
          ), $atts ) );

        /*title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


          $img = wp_get_attachment_image_src( $image, array(100,100) );

          if($image == "Image"){
            $imgsrc = plugins_url('images/responsive-icon.png', __FILE__);
            $img[0] = $imgsrc;
          }

          $output = "<div class='col-md-4 box'>
        <div class='centered'>
          <img src='{$img[0]}'>
        </div>
        <h5 class='text-center'><a href='#' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</a></h5>
        <p class='text-center small-text' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</p>
      </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>