			</div><!--container-->
		</div><!--inner-wrapper-->
	</div><!--wrapper-->
	<div id="footer-top-wrapper">
		<div id="footer-top">
			<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget Area')): endif; ?>
		</div><!--footer-top-->
	</div><!--footer-top-wrapper-->
	<div id="footer-bottom-wrapper">
		<div id="footer-bottom">
			<div id="footer-nav1">
				<?php wp_nav_menu(array('theme_location' => 'footer-menu')); ?>
			</div><!--footer-nav1-->
			<div id="copyright">
				<p><?php echo get_option('mm_copyright'); ?></p>
			</div><!--copyright-->
		</div><!--footer-bottom-->
	</div><!--footer-bottom-wrapper-->
</div><!--site-->

<?php wp_footer(); ?>

</body>
</html>