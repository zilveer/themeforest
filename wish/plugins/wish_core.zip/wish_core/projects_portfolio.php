<?php  
// Plain Hero, no images and stuff
class Wish_Projects_portfolio {

        var $shortcode = 'wish_projects_portfolio';
        var $title = "Projects Portfolio";
        var $details = "Shows Featured Projects as a Portfolio";
        //var $path = "/templates/rating_hero.php";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link"      => "http://i.imgur.com/dQgnBTz.jpg",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'wish'),
            "params" => array(


                            array(
                                    "type" => "textfield",
                                    "heading" => __("The Title", "wish"),
                                    "param_name" => "title",
                                    "admin_label" => true,
                                    "value" => __("recent work", 'wish'),
                            ),

                            array(
                                    "type" => "textfield",
                                    "heading" => __("The Subtitle", "wish"),
                                    "param_name" => "subtitle",
                                    "admin_label" => true,
                                    "description" => __("The Subtitle, with larger font than the title", "wish"),
                                    "value" => __("Portfolio", 'wish'),
                                    
                            ),



                            array(
                                "type" => "dropdown",
                                "heading" => __("Max Items", "wish"),
                                "param_name" => "max_items",
                                "description" => __("Maximum Number Of Portfolio Items to show.", "wish"),
                                "value" => array( 
                                                  "4"     => "4",
                                                  "5"     => "5",
                                                  "8"     => "8",
                                                  "10"     => "10",
                                                  "12"     => "12",
                                                  "16"     => "16",
                                                  "20"     => "20",
                                                ),
                                "std"       =>   8,
                            ),

                            array(
                                "type" => "dropdown",
                                "heading" => __("Number of Columns", "wish"),
                                "param_name" => "numcolumns",
                                "description" => __("Number of Columns", "wish"),
                                "value" => array( 
                                                  "2"     => "2",
                                                  "3"     => "3",
                                                  "4"     => "4",
                                                  "5"     => "5",
                                                ),
                                "std"       =>   12,
                            ),

                            /*Title*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __("Title Text Font", "wish" ),
                                "param_name" => "title_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Title Size", "wish"),
                                "param_name" => "title_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("30", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __("Title Text Color", "wish" ),
                                "param_name" => "title_color",
                                "value" => '#df4322 ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),



                            /*Subtitle*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __("Subtitle Text Font", "wish" ),
                                "param_name" => "subtitle_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Subtitle Size", "wish"),
                                "param_name" => "subtitle_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("70", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __("Subtitle Text Color", "wish" ),
                                "param_name" => "subtitle_color",
                                "value" => '#000 ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),



                            array(
                                    "type" => "colorpicker",
                                    "class" => "",
                                    "heading" => __( "Background Color", "wish" ),
                                    "param_name" => "bg_color",
                                    "value" => '#fff', //Default Black color
                                    "description" => __( "Choose text color", "wish" ),
                                    "group"         => "Fonts & Colors",
                            ),




                    )

        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'           => 'recent work',
        'title_font'      => '',
        'title_size'      => '30',
        'title_color'     => '#df4322',

        'subtitle'        => 'Portfolio',
        'subtitle_font'   => '',
        'subtitle_size'   => '70',
        'subtitle_color'  => '#000',

        'image'           => "Image",
        'numcolumns'      => '4',
        "max_items"       => "",
        'bg_color'        => '#fff',
      ), $atts ) );


      /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*SubTitle*/
        $decode_font = urldecode($subtitle_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $subtitle_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        wp_enqueue_script('wish-isotope-js', plugins_url('assets/isotope/jquery.isotope.min.js', __FILE__), array('jquery') );
        //wp_enqueue_script('wish-isotope-masonry', plugins_url('assets/isotope/custom-isotope-mansory.js', __FILE__), array('jquery') );
        //wp_enqueue_script('wish-isotope-4-columns', plugins_url('assets/isotope/custom-isotope-4-columns.js', __FILE__), array('jquery'), 1 );
        //wp_enqueue_script('wish-isotope-custom', plugins_url('assets/isotope/custom-isotope.js', __FILE__), array('jquery') );

        wp_register_script('wish-isotope-portfolio-masonry', plugins_url('assets/isotope/custom-isotope-mansory.js', __FILE__), array('jquery') );

        $num_cols = array( 'num_cols' => $numcolumns );
        wp_localize_script( 'wish-isotope-portfolio-masonry', 'wish_num_col', $num_cols );
         //wp_enqueue_script('wish-isotope-portfolio-masonry', plugins_url('assets/isotope/custom-isotope-mansory.js', __FILE__), array('jquery') );
        wp_enqueue_script('wish-isotope-portfolio-masonry');


        //in progress
        $args = array(
          'post_type' => 'wish_projects',
          'posts_per_page'  => $max_items,
        );

        $proj_query = new WP_Query( $args );


                $ctax = get_terms('projects_categories');
                $tarray = array();
                foreach($ctax as $tkey=>$tvalue){
                        $tarray[$tvalue->slug] =  $tvalue->name;
                }

                        


      $output = "<div id='portfolio' style='background-color:{$bg_color}'>
                    <div class='container'>
                        <div class='row header'>
                            <div class='col-lg-7'>
                                <h3 class='animated' data-animation='fadeInRight' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h3>
                                <h1 class='animated' data-animation='fadeInRight' data-animation-delay='400' style='font-family:{$subtitle_font_family};font-size:{$subtitle_size}px;color:{$subtitle_color}'>{$subtitle}</h1>
                            </div>
                            <div class='col-lg-5'>
                                <!-- Portfolio Nav Starts -->
                                <div id='options' class='animated' data-animation='fadeInRight' data-animation-delay='500'>
                                    <ul id='filters' class='option-set clearfix' data-option-key='filter'>
                                        <li>Filter:</li>
                                        <li><a href='#filter' data-option-value='*' class='selected'>All</a></li>";

                                        foreach($tarray as $key=>$value){
                                            $output .=  "<li><a href='#filter' data-option-value='.{$key}'>{$value}</a></li>";
                                         }


$output .=                           "</ul>
                                </div>
                                <!-- Portfolio Nav Ends -->
                            </div>
                        </div>
                        <div class='row'>
                            <div class='col-lg-12'>    
                                <div id='portfolio-mansory' class='animated' data-animation='fadeInUp' data-animation-delay='600'>";
                            
                                while ( $proj_query->have_posts() ) : $proj_query->the_post();  

                                       $pid =  get_the_ID();
                                       //echo get_post_meta(get_the_ID(), '_projects_mb_feature', TRUE);

                                       $thumbid = get_post_thumbnail_id( $pid );


                                       if ($numcolumns == 2) {
                                          $thumb = wp_get_attachment_image_src($thumbid, array(620,770));
                                        }
                                        else if($numcolumns == 3){
                                          $thumb = wp_get_attachment_image_src($thumbid, array(379,263));
                                        }
                                        elseif($numcolumns == 4){
                                          $thumb = wp_get_attachment_image_src($thumbid, array(284,179));
                                        }
                                        else{
                                          $thumb = wp_get_attachment_image_src($thumbid, array(227,157));
                                        }
                                       //$thumb = wp_get_attachment_image_src($thumbid, 'project-thumb');
                                       $thumb_tall = wp_get_attachment_image_src($thumbid, 'project-thumb-tall');
                                       $full = wp_get_attachment_image_src($thumbid, 'full');
                                       $terms = get_the_terms( $pid, 'projects_categories' ,  ' ' );

                                       $slg = "";
                                        if(!empty($terms)){ 
                                               foreach($terms as $slug){
                                                    $slg .= sanitize_html_class($slug->slug) . " ";
                                               }
                                        }


                                       $out_img = $full[0];
                                       $out_thumb = $thumb[0];
                                       $out_tall = $thumb_tall[0];

                                       if($out_img == ""){
                                            $out_img = plugins_url('images/projects/5.jpg', __FILE__);   
                                       }

                                       if($thumb_tall[0] == ""){
                                            $out_tall = plugins_url('images/projects/5.jpg', __FILE__);   
                                       }               

                                       if($thumb[0] == ""){
                                            $out_thumb = plugins_url('images/projects/5.jpg', __FILE__);   
                                       }

                                       $link = get_post_permalink();
                                       $title = get_the_title();                         

                                        $output .= "<figure class='hovereffect item {$slg}'>
                                                        <div class='picture'>
                                                            <img src='{$out_thumb}' alt=''/>                       
                                                            <!-- Picture Overlay Starts -->
                                                            <div class='picture-overlay'>
                                                                <div class='icons'>
                                                                    <div><span class='icon'><a href='{$link}'><i class='fa fa-link'></i></a></span><span class='icon'><a class='image-popup-vertical-fit' href='{$out_img}'><i class='fa fa-search'></i></a></span></div>
                                                                </div>
                                                            </div>
                                                            <!-- Picture Overlay Ends -->
                                                        </div>
                                                    </figure>";



                                endwhile;   
                                wp_reset_postdata();        


                     $output .=   "</div>
                                </div>
                            </div>    
                        </div>
                    </div>";

      return $output;
    }

    /*
    Load plugin css and javascript files which you may need on front end of your site
    */
    public function loadCssAndJs() {
      //wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
      //wp_enqueue_style( 'vc_extend_style' );

      // If you need any javascript files on front end, here is how you can load them.
      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );
    }

    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }



}//end of class
?>