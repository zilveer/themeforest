jQuery.noConflict();

/**************
	BUTTONS
**************/

function shortcodelicAddTinyMCEinit() {
	var DOM = tinymce.DOM;

	tinymce.init;

	tinymce.create('tinymce.plugins.ShortCodelicAdd', {
		mceTout : 0,
		init : function(ed, url) {
			var t = this,
				activeID = tinyMCE.activeEditor.id;


/* SCHORTCODELIC */
			ed.addButton('shortcodelic_video', {
				title : 'Shortcodelic video',
				icon: 'shortcodelic_video',
				onclick : function() {
					openVideoUploader(activeID);
				}
			});

			ed.addButton('shortcodelic_sidebars', {
				title : 'Shortcodelic sidebars',
				icon: 'shortcodelic_sidebars',
				onclick : function() {
					openSidebarSelector(activeID);
				}

			});

			ed.addButton('shortcodelic_portfolio', {
				title : 'Shortcodelic portfolio',
				icon: 'shortcodelic_portfolio',
				onclick : function() {
					openPortfolioSelector(activeID);
				}
			});

			ed.addButton('shortcodelic_posts', {
				title : 'Shortcodelic posts',
				icon: 'shortcodelic_posts',
				onclick : function() {
					openPostsSelector(activeID);
				}
			});

			ed.addButton('shortcodelic_extra', {
				type: 'menubutton',
				text: false,
				title : 'Shortcodelic extra shortcodes',
				icon: 'shortcodelic_extra',
				menu: [
					{ text: '[hr]', onclick: function() { tinyMCE.activeEditor.insertContent('[hr]'); } },
					{ text: '[hr-circled]', onclick: function() { tinyMCE.activeEditor.insertContent('[hr-circled]'); } },
					{ text: '[sc-searchform]', onclick: function() { tinyMCE.activeEditor.insertContent('[sc-searchform]'); } },
					{ text: '[shortcodelic-langswitcher]', onclick: function() { tinyMCE.activeEditor.insertContent('[shortcodelic-langswitcher]'); } }
				]
			});

		}

	});

	tinymce.PluginManager.add('shortcodelicadd', tinymce.plugins.ShortCodelicAdd);
}
(function() { shortcodelicAddTinyMCEinit(); })();
