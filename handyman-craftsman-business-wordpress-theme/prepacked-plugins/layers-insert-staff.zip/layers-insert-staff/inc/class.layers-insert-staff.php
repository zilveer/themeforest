<?php
require_once 'class.abstract-layers-extension.php';

/**
 * Layers Extension
 *
 * Extends Layers Content widget. It adds possibility do insert content of the post,
 * page or any other custom post type
 *
 * @package Layers
 * @since Layers 1.1.4
 */
class TL_Layers_Insert_Staff extends TL_Abstract_Layers_Extension
{

    /**
     * Register all required action & filters
     */
    protected function __construct()
    {
        // Called every time an activate plugin loads
        add_action('plugins_loaded', array($this, 'init'));

        // Deactivate plugin if all requirements are not met.
        //add_action('plugins_loaded', array($this, 'maybe_deactivate_plugin'));
        add_action('after_setup_theme', array($this, 'maybe_deactivate_plugin'));

        // Fired only once. When user activates the plugin!
        register_activation_hook(TL_INSERT_STAFF_FILE, array($this, 'activation'));
    }



    /**
     * Initialize all staff
     * @return void
     */
    public function init()
    {
        // Localization
        load_plugin_textdomain(TL_INSERT_STAFF_SLUG, false, TL_INSERT_STAFF_BASE . "/lang/");

        // Enqueue plugin scrips(css/js) for administration pages
        add_action('admin_enqueue_scripts', array($this, 'enqueueAdminAssets'));

        // Enqueue scripts for front pages
        add_action('wp_enqueue_scripts', array($this, 'enqueueAssets'), 99);

        // Add widgets
        add_action('widgets_init', array($this, 'registerWidgets'), 50);

        // Customize components from widgets
        add_filter('layerswp_font_component_args'         , array( $this, 'customize_sidebar_components' ), 10, 5);
        add_filter('layerswp_button_colors_component_args', array( $this, 'customize_sidebar_components' ), 10, 5);
        add_filter('layerswp_background_component_args'   , array( $this, 'customize_sidebar_components' ), 10, 5);
        add_filter('layerswp_custom_component_args'       , array( $this, 'customize_sidebar_components' ), 10, 5);
        add_filter('layerswp_featuredimage_component_args', array( $this, 'customize_sidebar_components' ), 10, 5);
        add_filter('layerswp_imageratios_component_args'  , array( $this, 'customize_sidebar_components' ), 10, 5);
        add_filter('layerswp_columns_component_args'      , array( $this, 'customize_sidebar_components' ), 10, 5);
        add_filter('layerswp_advanced_component_args'     , array( $this, 'customize_sidebar_components' ), 10, 5);
    }



    /**
     * Fires custom activation hook. We hooked System requirements checks to this hook.
     * Check Requirements class.
     */
    public function activation()
    {
        global $wp_rewrite;

        // Check Basic requirements
        if(!defined('TL_THEME_VER')){
            require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
            deactivate_plugins( plugin_basename( TL_INSERT_STAFF_FILE ) );
        }else{
            do_action(TL_INSERT_STAFF_SLUG . '_tl_activation');
            if($wp_rewrite){
                $wp_rewrite->flush_rules();
            }
        }
    }



    /**
     * Enqueue Admin Scripts & Styles for Customizer
     *
     * @return void
     */
    public function enqueueAdminAssets($hook)
    {
        wp_enqueue_script(TL_INSERT_STAFF_SLUG . '-admin', self::assetPath('js/admin.js'), array('jquery'), TL_INSERT_STAFF_VER, true);
        wp_enqueue_style(TL_INSERT_STAFF_SLUG . '-admin', self::assetPath('css/admin.css'), array(), TL_INSERT_STAFF_VER); // Admin CSS
        wp_enqueue_style('awesome-fonts', self::assetPath('css/font-awesome.css'), array(), TL_INSERT_STAFF_VER); // Admin CSS
    }



    /**
     * Enqueue all assets required by plugin
     */
    public function enqueueAssets()
    {
        wp_enqueue_script(TL_INSERT_STAFF_SLUG, self::assetPath('js/plugin.js'),
            array('jquery',
              TL_INSERT_STAFF_SLUG . 'tl-portfolio-filter',
              //TL_INSERT_STAFF_SLUG . 'tl-slider-js'
            ),TL_INSERT_STAFF_VER, true);

        wp_enqueue_style(TL_INSERT_STAFF_SLUG, self::assetPath('css/plugin.css'), false, TL_INSERT_STAFF_VER);
    }



    /**
     *  Reqister all widgets
     */
    public function registerWidgets()
    {
        if(class_exists('Layers_Widget')){
            include_once TL_INSERT_STAFF_DIR . 'widgets/layers-abstract-widget.php';
            include_once TL_INSERT_STAFF_DIR . 'widgets/layers-content-widget.php';
            include_once TL_INSERT_STAFF_DIR . 'widgets/layers-portfolio-widget.php';
            include_once TL_INSERT_STAFF_DIR . 'widgets/layers-service-widget.php';
            include_once TL_INSERT_STAFF_DIR . 'widgets/layers-blogtips-widget.php';
            include_once TL_INSERT_STAFF_DIR . 'widgets/layers-pricetable-widget.php';
            include_once TL_INSERT_STAFF_DIR . 'widgets/layers-promotional-widget.php';
            include_once TL_INSERT_STAFF_DIR . 'widgets/layers-team-widget.php';
            include_once TL_INSERT_STAFF_DIR . 'widgets/layers-post-widget.php';
            include_once TL_INSERT_STAFF_DIR . 'widgets/layers-header-widget.php';
        }

        // Regular widgets
        include_once TL_INSERT_STAFF_DIR . 'widgets/recent-tweets-widget.php';
        include_once TL_INSERT_STAFF_DIR . 'widgets/recent-posts-widget.php';
        include_once TL_INSERT_STAFF_DIR . 'widgets/tl-tag-widget.php';
    }


    /**
     *
     */
    public function unregisterWidgets()
    {
        global $wp_customize;

        //unregister_widget('Layers_Content_Widget');

        /*if ( isset( $wp_customize ) ) {
            unregister_widget('WP_Widget_Pages');
            unregister_widget('WP_Widget_Links');
            unregister_widget('WP_Widget_Search');
            unregister_widget('WP_Widget_Archives');
            unregister_widget('WP_Widget_Meta');
            unregister_widget('WP_Widget_Calendar');
            unregister_widget('WP_Widget_Categories');
            unregister_widget('WP_Widget_Recent_Posts');
            unregister_widget('WP_Widget_Recent_Comments');
            unregister_widget('WP_Widget_RSS');
            unregister_widget('WP_Widget_Tag_Cloud');
            unregister_widget('TL_Widget_Tag');
            unregister_widget('TL_Recent_Tweets');
            unregister_widget('TL_Recent_Posts');
        }*/
    }



    /**
     * Layers components customizations. Hook is called from Layers Widgets
     *
     * @param array $args
     * @param string $key  ( buttons|...|... )
     * @param string $type ( side|top )
     * @param array $widget
     * @param array $values
     * @return mixed|void
     */
    public function customize_sidebar_components($args, $key, $type, $widget, $values)
    {
        /**
         * Apply customizations to all components in custom widgets
         */
        $method = 'layers_' . $key . '_extension';
        if(method_exists($this, $method) && (strpos($widget['id'], 'tl_') !== false || strpos($widget['id'], 'blogtips') !== false)){
            $args = $this->{$method}($args, $type, $widget, $values);
        }

        /**
         * Applies to individual widgets
         */
        $args = apply_filters('tl/layers/' . $key . '_component/' . $this->_findWidgetId($widget['id']) . '/args', $args, $type, $widget, $values);
        return $args;
    }



    /**
     * Additions to Button Component in sidebar
     *
     * @param $args
     * @param $position
     * @param $widget
     * @param $values
     */
    public function layers_buttons_extension($args, $position, $widget, $values)
    {
        if($position == 'side'){

            // Change label
            $args['elements']['buttons-background-color']['label'] = __('Button Color', TL_INSERT_STAFF_SLUG);

            $before = array(
                'buttons-heading' => array(
                    'type' => 'layers-heading',
                    'label' => __('Item\'s Button Options', TL_INSERT_STAFF_SLUG),
                ),
                'buttons-label' => array(
                    'type' => 'text',
                    'label' => __('Button Label', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[buttons][label]',
                    'id' => $widget['id'] . '-buttons-label',
                    'value' => isset($values['buttons']['label']) ? $values['buttons']['label'] : null
                ),
                'buttons-align' => array(
                    'type' => 'select-icons',
                    'label' => __('Button Alignment', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[buttons][align]',
                    'id' => $widget['id'] . '-buttons-align',
                    'value' => isset($values['buttons']['align']) ? $values['buttons']['align'] : null,
                    'options' => array(
                        'text-left' => __('Left', TL_INSERT_STAFF_SLUG),
                        'text-center' => __('Center', TL_INSERT_STAFF_SLUG),
                        'text-right' => __('Right', TL_INSERT_STAFF_SLUG),
                    ),
                    'wrapper' => 'div',
                    'wrapper-class' => 'layers-icon-group'
                ),
            );

            $args['elements'] = $before + $args['elements'] + array(
                'buttons-background-color-hover' => array(
                    'type' => 'color',
                    'label' => __('Button Hover Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[buttons][background-color-hover]',
                    'id' => $widget['id'] . '-buttons-background-color-hover',
                    'value' => isset($values['buttons']['background-color-hover']) ? $values['buttons']['background-color-hover'] : null,
                ),
                'buttons-text-color' => array(
                    'type' => 'color',
                    'label' => __('Button Text Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[buttons][text-color]',
                    'id' => $widget['id'] . '-buttons-text-color',
                    'value' => isset($values['buttons']['text-color']) ? $values['buttons']['text-color'] : null,
                ),
                'buttons-text-color-hover' => array(
                    'type' => 'color',
                    'label' => __('Button Text Hover Color', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[buttons][text-color-hover]',
                    'id' => $widget['id'] . '-buttons-text-color-hover',
                    'value' => isset($values['buttons']['text-color-hover']) ? $values['buttons']['text-color-hover'] : null,
                ),
                'buttons-animation' => array(
                    'type' => 'select',
                    'label' => __('Button Animation', TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[buttons][animation]',
                    'id' => $widget['id'] . 'buttons-animation',
                    'value' => (isset($values['buttons']['animation'])) ? $values['buttons']['animation'] : NULL,
                    'options' => array(
                        '' => 'None',
                        'hvr-grow' => 'hvr-grow',
                        'hvr-shrink' => 'hvr-shrink',
                        'hvr-float' => 'hvr-float',
                        'hvr-wobble-horizontal' => 'hvr-wobble-horizontal',
                        'hvr-wobble-vertical' => 'hvr-wobble-vertical',
                        'hvr-fade' => 'hvr-fade',
                        'hvr-sweep-to-right'    => 'hvr-sweep-to-right',
                        'hvr-sweep-to-left'     => 'hvr-sweep-to-left',
                        'hvr-bounce-to-right'   => 'hvr-bounce-to-right',
                        'hvr-bounce-to-left'    => 'hvr-bounce-to-left',
                        'hvr-bounce-to-bottom'  => 'hvr-bounce-to-bottom',
                        'hvr-bounce-to-top'     => 'hvr-bounce-to-top',
                        'hvr-shutter-in-horizontal'  => 'hvr-shutter-in-horizontal',
                        'hvr-shutter-out-horizontal' => 'hvr-shutter-out-horizontal',
                    ),
                ),
                'buttons-borders-heading' => array(
                    'type' => 'layers-heading',
                    'label' => 'Button Borders',
                ),
                'buttons-border-radius' => array(
                    'type' => 'number',
                    'label' => 'Button Border Radius (px)',
                    'min' => 0,
                    'max' => 300,
                    'name' => $widget['name'] . '[buttons][border-radius]',
                    'id' => $widget['id'] . '-buttons-border-radius',
                    'value' => isset($values['buttons']['border-radius']) ? $values['buttons']['border-radius'] : null,
                ),
                'buttons-border-width' => array(
                    'type' => 'number',
                    'label' => 'Button Border Width (px)',
                    'min' => 0,
                    'max' => 20,
                    'name' => $widget['name'] . '[buttons][border-width]',
                    'id' => $widget['id'] . '-buttons-border-width',
                    'value' => isset($values['buttons']['border-width']) ? $values['buttons']['border-width'] : null,
                ),
                'buttons-border-color' => array(
                    'type' => 'color',
                    'label' => 'Button Border Color',
                    'name' => $widget['name'] . '[buttons][border-color]',
                    'id' => $widget['id'] . '-buttons-border-color',
                    'value' => isset($values['buttons']['border-color']) ? $values['buttons']['border-color'] : null,
                ),
                'buttons-border-color-hover' => array(
                    'type' => 'color',
                    'label' => 'Button Border Hover Color',
                    'name' => $widget['name'] . '[buttons][border-color-hover]',
                    'id' => $widget['id'] . '-buttons-border-color-hover',
                    'value' => isset($values['buttons']['border-color-hover']) ? $values['buttons']['border-color-hover'] : null,
                ),
            );
        }
        return $args;
    }



    /**
     * Additions to Text component
     *
     * @param $args
     * @param $position
     * @param $widget
     * @param $values
     * @return mixed
     */
    public function layers_fonts_extension($args, $position, $widget, $values){

        return $args;
    }


    public function layers_background_extension($args, $position, $widget, $values){return $args;}
    public function layers_display_extension($args, $position, $widget, $values){return $args;}
    public function layers_columns_extension($args, $position, $widget, $values){return $args;}
    public function layers_featuredimage_extension($args, $position, $widget, $values){return $args;}
    public function layers_imageratios_extension($args, $position, $widget, $values){return $args;}
    public function layers_advanced_extension($args, $position, $widget, $values){return $args;}



    /**
     * @param $str
     * @return string
     */
    protected function _findWidgetId($str)
    {
        $widget_type = str_replace('widget-layers-widget-', '', $str);
        return substr($widget_type, 0, strpos($widget_type, '-'));
    }


    /**
     * Resolve path to the asset script
     *
     * @param string $filename
     * @param bool $parent if TRUE get file from parent theme
     * @param bool $nomin
     * @return string
     */
    public static function assetPath($filename, $parent = false, $nomin = false)
    {
        $dist_url  = TL_INSERT_STAFF_URI . 'assets/';
        $dist_path = TL_INSERT_STAFF_DIR . 'assets/';
        $directory = dirname($filename) . '/';
        $file      = basename($filename);

        $file_parts = explode('.', $file);
        $ext        = $file_parts[count($file_parts)-1];
        $has_min_version = false;

        if($file_parts[count($file_parts)-2] != 'min'){
            $file_min = str_replace('.' . $ext, '.min.' . $ext, $file);

            if(file_exists($dist_path . $directory . $file_min)){
                $has_min_version = true;
            }
        }

        $is_development = defined('WP_ENV') && (WP_ENV == 'development');

        if (!$is_development && $has_min_version && !$nomin) {
            return $dist_url . $directory . $file_min;
        } else {
            return $dist_url . $directory . $file;
        }
    }



    /**
     *
     */
    public function maybe_deactivate_plugin()
    {
        /**
         * Check is the required theme present
         */
        if(!defined('TL_THEME_VER')){
            require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
            deactivate_plugins( plugin_basename( TL_INSERT_STAFF_FILE ) );
            add_action('admin_notices', array($this, 'layers_is_missing_notice'));
        }
    }



    public function layers_is_missing_notice()
    {
        echo '<div class="error" style="padding: 20px; font-size: 16px;">
                    <p>"Handyman Plugin" has deactivated itself because Handyman Wordpress Theme is no longer active.</p>
              </div>';
    }



    /**
     *
     */
    public function deactivation()
    {
        do_action(TL_INSERT_STAFF_SLUG . '_tl_deactivation');
    }
}