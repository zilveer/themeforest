<?php 
get_header();
echo '<h2>'.__('Not Found','themolitor').'</h2>';
get_footer(); 
?>