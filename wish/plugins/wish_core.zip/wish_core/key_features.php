<?php  
//Register "container" content element
vc_map( array(
    "name" => __("Wish Key Features", "wish"),
    "description" => __("Key Features Section", 'wish'),
    "controls" => "full",
    "base" => "wish_key_features",
    "as_parent" => array('only' => 'wish_single_key_feature'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/g9wYsqE.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Features Section Title", "wish"),
            "value" => __("Theme Key Features", 'wish'),
            "admin_label" => true,
        ), 
        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("30", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#df4322', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),
    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Feature", "wish"),
    "base" => "wish_single_key_feature",
    "content_element" => true,
    "as_child" => array('only' => 'wish_key_features'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(


        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Image Below Features", 'wish'),
            "param_name" => "image",
            "value" => "Image",
        ),

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Features Section Title", "wish"),
            "value" => __("Revolution Slider", 'wish'),
            "admin_label" => true,
        ), 

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Slider Revolution & LayerSlider plugins included we included excellent and easy to use slider plugins", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


       
    )//ends params
    
) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Key_Features extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'   => 'Theme Key Features',
        'title_font'  => '',
        'title_size'  => '30',
        'title_color' => '#df4322',
      ), $atts ) );
     
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

      $output = "<div class='container key-features'>
            <div class='row'>
                <h2 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h2>
                  " . do_shortcode($content) . "        
                    </div>
                </div>
                ";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Single_Key_Feature extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image' => 'Image',

            'title'   => 'Revolution Slider',
            'title_font'  => '',
            'title_size'  => '20',
            'title_color' => '#000',

            'details' => 'Slider Revolution & LayerSlider plugins included we included excellent and easy to use slider plugins',
            'details_font'  => '',
            'details_size' => '14',
            'details_color' => '#000'
          ), $atts ) );

        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        $img = wp_get_attachment_image_src( $image, array(32,40) );

      if($image == "Image"){
        $imgsrc = plugins_url('images/key_features.jpg', __FILE__);
        $img[0] = $imgsrc;
      }
          
          $output = "<div class='col-lg-3 col-md-3 col-sm-6 block'>
                        <div class='icon'><img src='{$img[0]}' alt=''></div>
                        <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                        <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                    </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>