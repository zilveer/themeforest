<?php

	/*	
	*	CrunchPress Portfolio Option File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		CrunchPress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) CrunchPress
	*	---------------------------------------------------------------------
	*	This file create and contains the portfolio post_type meta elements
	*	---------------------------------------------------------------------
	*/
	
	add_action( 'init', 'create_testimonial' );
	function create_testimonial() {
	
		$labels = array(
			'name' => _x('Testimonial', 'Testimonial General Name', 'crunchpress'),
			'singular_name' => _x('Testimonial Item', 'Testimonial Singular Name', 'crunchpress'),
			'add_new' => _x('Add New', 'Add New Testimonial Name', 'crunchpress'),
			'add_new_item' => __('Author Name', 'crunchpress'),
			'edit_item' => __('Author Name', 'crunchpress'),
			'new_item' => __('New Testimonial', 'crunchpress'),
			'view_item' => '',
			'search_items' => __('Search Testimonial', 'crunchpress'),
			'not_found' =>  __('Nothing found', 'crunchpress'),
			'not_found_in_trash' => __('Nothing found in Trash', 'crunchpress'),
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			//'menu_icon' => CP_PATH_URL . 'back-end/assets/images/portfolio-icon.png',
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_position' => 5,
			"show_in_nav_menus" => false,
			'exclude_from_search' => true,
			'supports' => array('title','editor','author','thumbnail','excerpt','comments')
		); 
		  
		register_post_type( 'testimonial' , $args);
		
		register_taxonomy(
			"testimonial-category", array("testimonial"), array(
				"hierarchical" => true, 
				"label" => "Testimonial Categories", 
				"singular_label" => "Testimonial Categories", 
				"show_in_nav_menus" => false,
				"rewrite" => true));
		register_taxonomy_for_object_type('testimonial-category', 'testimonial');
		
	}
	
?>