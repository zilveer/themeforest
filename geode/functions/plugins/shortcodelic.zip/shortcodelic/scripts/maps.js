jQuery(window).on("load shortcodelic_ev", function() {
    var it = 0;
    var shortcodelicMaps = function() {
        jQuery(".pix_maps:visible, .entry-header .pix_maps").not(".init").each(function() {
            var t = jQuery(this).addClass("init"),
                id = t.attr("data-id"),
                newID = id + "-it" + it,
                opts = t.data("opts");
            t.attr("id", newID);
            var w = parseFloat(opts.width) + "%",
                h = parseFloat(opts.height),
                coords = opts.coords.replace(/n/g, ""),
                maptype = opts.maptype != "HIDE" ? true : false,
                typepos = opts.maptype,
                pancontrol = opts.pancontrol != "HIDE" ? true : false,
                panpos = opts.pancontrol,
                zoomcontrol = opts.zoomcontrol != "HIDE" ? true : false,
                zoomcontrolsize = typeof opts.zoomcontrolsize !== "undefined" ? opts.zoomcontrolsize : "DEFAULT",
                zoompos = opts.zoomcontrol,
                scalecontrol = opts.scalecontrol != "HIDE" ? true : false,
                swcontrol = opts.swcontrol != "HIDE" ? true : false,
                swpos = opts.swcontrol,
                markers = opts.markers,
                styles = typeof eval("styles_" + opts.id) !== "undefined" ? eval("styles_" + opts.id) : false,
                map;
            it = it + 1;
            coords = coords.split(",");
            var mapWidth = function() {
                var e = t.width(),
                    n = typeof t.attr("data-height") != "undefined" ? t.attr("data-height") : e * h * .01,
                    r = typeof t.attr("data-width") != "undefined" ? t.attr("data-width") : r;
                t.css({
                    height: n,
                    width: r
                })
            };
            mapWidth();
            jQuery(window).on("resize", mapWidth);
            if (opts.type == "streetview") {
                map = GMaps.createPanorama({
                    el: newID,
                    lat: coords[0],
                    lng: coords[1],
                    scrollwheel: false,
                    panControlOptions: {
                        position: google.maps.ControlPosition[panpos]
                    },
                    zoomControlOptions: {
                        position: google.maps.ControlPosition[zoompos],
                        style: google.maps.ZoomControlStyle[zoomcontrolsize]
                    },
                    pov: {
                        heading: parseFloat(opts.heading),
                        pitch: parseFloat(opts.pitch),
                        zoom: Math.floor(parseFloat(opts.zoom) / 3) - 1
                    }
                })
            } else {
                map = new GMaps({
                    div: newID,
                    lat: coords[0],
                    lng: coords[1],
                    scrollwheel: false,
                    zoom: parseFloat(opts.zoom),
                    mapTypeId: opts.type,
                    mapTypeControl: maptype,
                    mapTypeControlOptions: {
                        position: google.maps.ControlPosition[typepos]
                    },
                    panControl: pancontrol,
                    panControlOptions: {
                        position: google.maps.ControlPosition[panpos]
                    },
                    zoomControl: zoomcontrol,
                    zoomControlOptions: {
                        position: google.maps.ControlPosition[zoompos],
                        style: google.maps.ZoomControlStyle[zoomcontrolsize]
                    },
                    scaleControl: scalecontrol,
                    streetViewControl: swcontrol,
                    streetViewControlOptions: {
                        position: google.maps.ControlPosition[swpos]
                    },
                    styles: styles
                });
                map.setCenter(coords[0], coords[1]);
                var viewMap = function() {
                    if (markers !== "" && typeof markers == "object" && t.data("scrolled") !== true) {
                        t.data("scrolled", true);
                        jQuery.each(markers, function(e, t) {
                            if (t !== "" && typeof t == "object") {
                                var n, r = t.delay !== "" && typeof t.delay !== "undefined" ? t.delay : 1,
                                    i = t.caption !== "" && typeof t.caption !== "undefined" ? {
                                        content: t.caption.replace(/\[apostrophe;\]/g, "'").replace(/\[quotes;\]/g, '"')
                                    } : false,
                                    s = t.fx !== "" && typeof t.fx !== "undefined" ? google.maps.Animation.DROP : "",
                                    o = t.coords !== "" && typeof t.coords !== "undefined" ? t.coords.replace(/n/g, "") : opts.coords.replace(/n/g, "");
                                o = o.split(",");
                                if (t.bg !== "" && typeof t.bg !== "undefined") {
                                    var u = new Image;
                                    u.onload = function() {
                                        var e = u.height,
                                            r = u.width;
                                        if (t.hdpi !== "" && typeof t.hdpi !== "undefined") {
                                            e = e / 2;
                                            r = r / 2
                                        }
                                        n = new google.maps.MarkerImage(t.bg, null, null, null, new google.maps.Size(r, e));
                                        map.addMarker({
                                            lat: o[0],
                                            lng: o[1],
                                            icon: n,
                                            animation: s,
                                            infoWindow: i
                                        })
                                    };
                                    u.src = t.bg
                                } else {
                                    var a = setTimeout(function() {
                                        map.addMarker({
                                            lat: o[0],
                                            lng: o[1],
                                            animation: s,
                                            infoWindow: i
                                        })
                                    }, r)
                                }
                            }
                        })
                    }
                };
                t.shortcodelicScrolledIntoView().on("scrolledin", function() {
                    viewMap()
                });
                if (opts.start !== "" && typeof opts.start !== "undefined" && opts.end !== "" && typeof opts.end !== "undefined") {
                    var start = opts.start.replace(/n/g, ""),
                        end = opts.end.replace(/n/g, "");
                    map.drawRoute({
                        origin: start,
                        destination: end,
                        travelMode: opts.travelmode,
                        strokeColor: opts.color,
                        strokeOpacity: opts.opacity,
                        strokeWeight: opts.strokeweight
                    })
                }
            }
            jQuery(window).on("shortcodelic_ev", function() {
                map.refresh()
            })
        })
    };
    shortcodelicMaps()
});