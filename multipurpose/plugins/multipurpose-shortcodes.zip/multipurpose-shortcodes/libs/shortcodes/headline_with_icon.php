<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// shortcode for Headline with image
add_shortcode('headline_with_icon','multipurpose_headline_with_icon');

function multipurpose_filter_headline_with_icon_class($content) {
    return $content.' with-icons';
}

function multipurpose_headline_with_icon($atts, $content = null) {
    
    if (!has_filter('multipurpose_filters_column_class', 'multipurpose_filter_headline_with_icon_class', 10))	
        add_filter('multipurpose_filters_column_class', 'multipurpose_filter_headline_with_icon_class', 10);

    if(isset($atts) && !empty($atts))
        array_walk($atts, 'multipurpose_arrangement_shortcode_arr_value');

    extract(shortcode_atts(array(  
            'image_url'=> '',
            'image_alt'=> ''
    ), $atts));

	$output = '<h3><img src="'.$image_url.'" alt="'.$image_alt.'">'.do_shortcode($content).'</h3>';	
    
    return $output;
}