jQuery(document).ready(function($) {

	"use strict";
	
	/* --------------------------------------------------
		Google Map
	-------------------------------------------------- */
	
	if ( $('.exp-google-map').length ) {
		
		var mapAPI = $('.exp-google-map').first().data('map-api');		
		
		// Asynchronously Load the map API 
		var script = document.createElement('script');
		script.src = 'http://maps.googleapis.com/maps/api/js?key='+mapAPI+'&callback=initialize';
		document.body.appendChild(script);
	
	}
	

	/* --------------------------------------------------
		FlexSlider
	-------------------------------------------------- */
	
	if($.isFunction($.fn.flexslider)){				

		/* Slider (Small) */
		$('.flexslider.flexslider-small').each(function(i, el) {
			
			var startAt = $(el).data('flexslider-startat') - 1;
			var slideshowSpeed = $(el).data('flexslider-slideshowspeed') || 7000;
			var animationSpeed = $(el).data('flexslider-animationspeed') || 600;
			
			$(el).flexslider({
				animation:		"fade",
				controlNav:		false,
				prevText:		"",
				nextText:		"",				
				startAt:		startAt,
				slideshowSpeed:	slideshowSpeed,
				animationSpeed:	animationSpeed,
				start:			function() {
					$('.slides video').each(function(){
						$(this).get(0).play();
					});
				}
			});
		
		});
		
		/* Slider (Content) */
		$('.flexslider.flexslider-big').each(function(i, el) {
		
			var startAt = $(el).data('flexslider-startat') - 1;
			var slideshowSpeed = $(el).data('flexslider-slideshowspeed') || 7000;
			var animationSpeed = $(el).data('flexslider-animationspeed') || 600;
			
			$(el).flexslider({
				animation:		"slide",
				directionNav:	false,
				startAt:		startAt,
				slideshowSpeed:	slideshowSpeed,
				animationSpeed:	animationSpeed,
				start:			function() {
					$('.slides video').each(function(){
						$(this).get(0).play();
					});
				}					
			});
		
		});
		
	}
	
	
	/* --------------------------------------------------
		Fancybox
	-------------------------------------------------- */

	if($.isFunction($.fn.fancybox)){
		
		var $video_player, _videoHref, _videoPoster, _videoWidth, _videoHeight, _dataCaption, _player, _isPlaying = false, _verIE = getInternetExplorerVersion();
		
		jQuery('.fancybox').fancybox({
			scrolling	: "no",			
			padding		: 0,
			nextEffect	: "fade",
			prevEffect	: "fade",
			nextSpeed	: 0,
			prevSpeed	: 0,
			closeBtn   : false,
			modal      : false, // hide default close and navigation buttons
			helpers    : {
				media		: {},
				title		: {
					type		: "outside"
				},
				buttons 	: {}, // use buttons helpers so navigation button won't overlap video controls
				overlay 	: {
					showEarly 	: false
				}
			},
			tpl			: {
				next		: '<a title="Next" class="fancybox-nav fancybox-next" href="javascript:;"><span class="funky-icon-arrow-right"></span></a>',
				prev		: '<a title="Previous" class="fancybox-nav fancybox-prev" href="javascript:;"><span class="funky-icon-arrow-left"></span></a>'
			},
			beforeLoad	: function() {
				
				if($.isFunction($.fn.flexslider) && $('.flexslider-big').length){
					$('.flexslider-big').flexslider("pause");
				}
				
				if ( $(window).width() > 703 ) {
					$.extend(this, {
						margin		: [50,100,50,100]
					});
				} else {
					$.extend(this, {
						margin		: [5,10,5,10]
					});
				}
				
				// Get video URL info
				//var theURL = new URL(this.href);
				var theURL = this.href;
				//var path = theURL.pathname.split('.');
				var ext = false;
				
				ext = this.href.split('.').pop();
				
				// Determine video type (web service or WebM/MP4)
				if ( 
					typeof theURL.hostname !== 'undefined'
					&& (
						theURL.hostname == 'www.youtube.com' || theURL.hostname == 'youtube.com' || theURL.hostname == 'youtu.be' 
						|| theURL.hostname == 'www.vimeo.com' || theURL.hostname == 'vimeo.com'
						|| theURL.hostname == 'www.dailymotion.com' || theURL.hostname == 'dailymotion.com'
					)
				) {
					$.extend(this,{type:'iframe'});				
				} else if ( typeof ext !== 'undefined' && typeof ext !== false && ( ext == 'mp4' || ext == 'webm' ) ) {				
					$.extend(this,{type:'html'});				
				}
				
				// if this a video? (html type)				
				if (this.type == "html") {
					// if video is playing and we navigate to next/prev element of a fancyBox gallery
					// safely remove Flash objects in IE
					if (_isPlaying && (_verIE > -1)) {
						// video is playing AND we are using IE
						_verIE < 9.0 ? _player.remove() : $video_player.remove(); // remove player instance for IE
						_isPlaying = false; // reinitialize flag
					};
					// build the HTML5 video structure for fancyBox content with specific parameters
					_videoHref = this.href;
					// validates if data values were passed otherwise set defaults
					_videoPoster = typeof this.element.data("poster") !== "undefined" ? this.element.data("poster") : "";
					_videoWidth = typeof this.element.data("video-width") !== "undefined" ? this.element.data("video-width") : 1024;
					_videoHeight = typeof this.element.data("video-height") !== "undefined" ? this.element.data("video-height") : 576;
					_dataCaption = typeof this.element.data("caption") !== "undefined" ? this.element.data("caption") : "";
					// construct fancyBox title (optional)
					this.title = _dataCaption ? _dataCaption : (this.title ? this.title : "");
					// set fancyBox content and pass parameters
					this.content = "<video id='video_player' src='" + _videoHref + "'  poster='" + _videoPoster + "' width='" + _videoWidth + "' height='" + _videoHeight + "'  controls='controls' preload='none'></video>";
					// set fancyBox dimensions
					this.width = _videoWidth;
					this.height = _videoHeight;
					$.extend(this, {
						fitToView	: false,
						autoSize	: false
					});
				} else if (this.type == "iframe") {
					_videoWidth = typeof this.element.data("video-width") !== "undefined" ? this.element.data("video-width") : 1024;
					_videoHeight = typeof this.element.data("video-height") !== "undefined" ? this.element.data("video-height") : 576;
					this.width = _videoWidth;
					this.height = _videoHeight;
				}			
				
			},
			afterShow	: function() {
				if (this.type == "html") {
					// initialize MEJS player
					var $video_player = new MediaElementPlayer('#video_player', {
						defaultVideoWidth: this.width,
						defaultVideoHeight: this.height,
						success: function(mediaElement, domObject) {
							_player = mediaElement; // override the "mediaElement" instance to be used outside the success setting
							_player.load(); // fixes webkit firing any method before player is ready
							_player.play(); // autoplay video (optional)
							_player.addEventListener('playing', function() {
								_isPlaying = true;
							}, false);
						} // success
					});
				}
			},
			beforeClose	: function() {
				if (this.type == "html") {
					// if video is playing and we close fancyBox
					// safely remove Flash objects in IE
					if (_isPlaying && (_verIE > -1)) {
						// video is playing AND we are using IE
						_verIE < 9.0 ? _player.remove() : $video_player.remove(); // remove player instance for IE
						_isPlaying = false; // reinitialize flag
					};
				}
			},
			afterClose	: function() {
				if($.isFunction($.fn.flexslider) && $('.flexslider-big').length){
					$('.flexslider-big').flexslider("play");
				}				
			}
		});
		
	}
	
});


// Detecting IE more effectively : http://msdn.microsoft.com/en-us/library/ms537509.aspx
function getInternetExplorerVersion() {
    // Returns the version of Internet Explorer or -1 (other browser)
    var rv = -1; // Return value assumes failure.
    if (navigator.appName == 'Microsoft Internet Explorer') {
        var ua = navigator.userAgent;
        var re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
        if (re.exec(ua) != null)
            rv = parseFloat(RegExp.$1);
    };
    return rv;
};

function initialize() {

	jQuery('.exp-google-map').each( function() {
		
		// Map data
		var mapID			= jQuery(this).attr('id');		
		var mapAddress		= jQuery(this).data('map-latlng');
		var mapZoom			= (jQuery(this).data('map-zoom') != '' ? jQuery(this).data('map-zoom') : 11);
		var mapSaturation	= (jQuery(this).data('map-saturation') != '' ? jQuery(this).data('map-saturation') : 0);
		var mapHue			= (jQuery(this).data('map-hue') ? jQuery(this).data('map-hue') : false);
		var mapSimplify 	= (jQuery(this).data('map-simplify') ? 'simplified' : 'on');
		var mapPin 			= (jQuery(this).data('map-pin') ? jQuery(this).data('map-pin') : false );
		var mapPinWidth 	= (jQuery(this).data('map-pin-width') ? jQuery(this).data('map-pin-width') : false);
		var mapPinHeight 	= (jQuery(this).data('map-pin-height') ? jQuery(this).data('map-pin-height') : false);
		
		var map;
	
		// Remove all spaces
		mapAddress.trim();
		
		// Split lat,lng to array and assign to position variable
		var latlng = mapAddress.split(',');		
		var position = {lat: parseFloat(latlng[0]), lng: parseFloat(latlng[1])};
		//console.log(position);
		
		var styles = [
			{
				featureType		: 'all',
				stylers			: [						
					{ saturation :	mapSaturation },
					{ hue :			mapHue }
				]
			},
			{
				'elementType'	: 'geometry',
				'stylers'		: [
					{ 'visibility' : mapSimplify }
				]
			}
		];
		
		var styledMap = new google.maps.StyledMapType(styles, {name : 'Styled Map'});	

		// Create map
		var mapOptions = {
			zoom : 				mapZoom,
			center :			position,
			draggable:			false,
			panControl: 		false,
			scaleControl: 		false,
			streetViewControl:	false,
			zoomControl:		true,
			zoomControlOptions: {
				style: google.maps.ZoomControlStyle.SMALL,
				position: google.maps.ControlPosition.TOP_RIGHT
			},
			scrollwheel:		false,					
			mapTypeControl:		false
		}
				
		// Display a map on the page
		map = new google.maps.Map(document.getElementById(mapID), mapOptions);
		map.setTilt(45);
		
		// Add Marker
		if ( mapPin != false ) {
		
			var image = new google.maps.MarkerImage(
				mapPin,
				new google.maps.Size(mapPinWidth,mapPinheight),
				new google.maps.Point(0,0)
			);
			
			var marker = new google.maps.Marker({
				position :	position,
				map :		map,
				clickable :	false,
				icon :		image
			});
		
		} else { 
		
			var marker = new google.maps.Marker({
				position :	position,
				map :		map,
				clickable :	false
			});
		
		}				
	
		map.mapTypes.set('map_style', styledMap);
		map.setMapTypeId('map_style');	
	
		// Window resize listener
		google.maps.event.addDomListener(window, 'resize', function() {
			var center = map.getCenter();
			google.maps.event.trigger(map, 'resize');			
			map.setCenter(center);
		});					
		
	});

};