<?php

function youxi_importer_handle_frontpage_displays( $data ) {

	$defaults = array( 'show_on_front'  => 'posts', 'page_on_front'  => '', 'page_for_posts' => '' );

	$data = wp_parse_args( $data, $defaults );

	$result = array();
	
	foreach( array_keys( $defaults ) as $option ) {

		if( ! empty( $data[ $option ] ) ) {

			update_option( $option, $data[ $option ] );
			$result[] = $option . ': ' . $data[ $option ];
		}
	}

	return empty( $result ) ? 
		esc_html__( 'Frontpage display settings not imported.', 'youxi' ) : implode( ', ', $result );
}
