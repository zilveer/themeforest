<?php
class WPBakeryShortCode_A13_Hellotext extends WPBakeryShortCode {

    public function outputTitle($title) {
        return '';
    }
}

class WPBakeryShortCode_A13_Title_With_Color extends WPBakeryShortCode {

    public function outputTitle($title) {
        return '';
    }
}

class WPBakeryShortCode_A13_Title_With_Icon extends WPBakeryShortCode {

    public function outputTitle($title) {
        return '';
    }
}

class WPBakeryShortCode_A13_Big_Icon extends WPBakeryShortCode {

    public function outputTitle($title) {
        return '';
    }
}

class WPBakeryShortCode_A13_Counter extends WPBakeryShortCode {

    public function outputTitle($title) {
        return '';
    }
}

