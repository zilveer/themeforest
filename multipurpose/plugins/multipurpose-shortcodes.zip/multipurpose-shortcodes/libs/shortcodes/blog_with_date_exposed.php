<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// add shortcode recent_posts
add_shortcode('blog_with_date_exposed', 'multipurpose_blog_with_date_exposed');

function multipurpose_blog_with_date_exposed($atts, $content = null) {
    $output = '';
	
	//category name paremeter set
	$category_name = '';
	if( !empty($atts['category_name']) ) {
		$category_name = $atts['category_name'];
	} 
    
    $args = array(
        'posts_per_page' => $atts['number_posts'],
        'orderby' => 'post_date',
        'order' => 'DESC',
        'post_type' => 'post',
        'post_status' => 'publish',
		'category_name' => $category_name,
        'suppress_filters' => true);
    $posts_array = get_posts($args);
    
    $output.= '<ul class="event-list">';
    if (!empty($posts_array)) {
        foreach ($posts_array as $key_data => $val_data) {
            $output.= '<li>';
            $output .= '<p class="date"><span>' . get_post_time('j', true, $val_data->ID) . '</span><span>' . get_post_time('M', true, $val_data->ID) . '</span></p>';
            $output .= '<h4><a href="' . get_permalink($val_data->ID) . '">' . $val_data->post_title . '</a></h4>';

            if (isset($atts['excerpt']) && $atts['excerpt'] == 'yes') {
                if (!empty($val_data->post_excerpt)) {
                    $output .= '<p>' . multipurpose_cut_character_word($atts["excerpt_words"], $val_data->post_excerpt, $atts["strip_html"]) . '</p>';
                } elseif (!empty($val_data->post_content)) {
                    $output .= '<p>' . multipurpose_cut_character_word($atts["excerpt_words"], $val_data->post_content, $atts["strip_html"]) . '</p>';
                }
            }
            $output.= '</li>';
        }
    }
    $output.= '</ul>';
    return $output;
}
