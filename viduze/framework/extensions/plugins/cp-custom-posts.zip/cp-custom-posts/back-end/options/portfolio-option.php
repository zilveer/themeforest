<?php

	/*	
	*	Crunchpress Portfolio Option File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		Crunchpress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) Crunchpress
	*	---------------------------------------------------------------------
	*	This file create and contains the portfolio post_type meta elements
	*	---------------------------------------------------------------------
	*/
	
	add_action( 'init', 'create_portfolio' );
	function create_portfolio() {
		
		$labels = array(
			'name' => _x('Portfolio', 'Portfolio General Name', 'crunchpress'),
			'singular_name' => _x('Portfolio Item', 'Portfolio Singular Name', 'crunchpress'),
			'add_new' => _x('Add New', 'Add New Portfolio Name', 'crunchpress'),
			'add_new_item' => __('Add New Portfolio', 'crunchpress'),
			'edit_item' => __('Edit Portfolio', 'crunchpress'),
			'new_item' => __('New Portfolio', 'crunchpress'),
			'view_item' => __('View Portfolio', 'crunchpress'),
			'search_items' => __('Search Portfolio', 'crunchpress'),
			'not_found' =>  __('Nothing found', 'crunchpress'),
			'not_found_in_trash' => __('Nothing found in Trash', 'crunchpress'),
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			//'menu_icon' => CP_PATH_URL . '/back-end/assets/images/portfolio-icon.png',
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_position' => 5,
			'supports' => array('title','editor','author','thumbnail','excerpt','comments','custom-fields'),
			'rewrite' => array('slug' => 'portfolio', 'with_front' => false)
		  ); 
		  
		register_post_type( 'portfolio' , $args);
		
		register_taxonomy(
			"portfolio-category", array("portfolio"), array(
				"hierarchical" => true,
				"label" => "Portfolio Categories", 
				"singular_label" => "Portfolio Categories", 
				"rewrite" => true));
		register_taxonomy_for_object_type('portfolio-category', 'portfolio');
		
		register_taxonomy(
			"portfolio-tag", array("portfolio"), array(
				"hierarchical" => false, 
				"label" => "Portfolio Tag", 
				"singular_label" => "Portfolio Tag", 
				"rewrite" => true));
		register_taxonomy_for_object_type('portfolio-tag', 'portfolio');
		
	}
	
?>