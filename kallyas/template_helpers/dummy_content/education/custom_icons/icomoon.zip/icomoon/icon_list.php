<?php $icons = array();
$icons['icomoon']['ue039'] = 'ue039';
$icons['icomoon']['ue900'] = 'ue900';
$icons['icomoon']['uf2ac'] = 'uf2ac';