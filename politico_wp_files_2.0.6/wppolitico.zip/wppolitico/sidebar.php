<div id="sidebar">
	<ul>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Live Widgets') ) : endif; ?>
	</ul>
</div><!--end sidebar-->