[![Build Status](https://travis-ci.org/pixelgrade/pixlikes.png?branch=development)](https://travis-ci.org/pixelgrade/pixlikes)

=== PixLikes ===

Just another awesome WordPress Likes/Love system. Just what the world needed more :)

=== # ===

~Current Version:1.1.2~

=== # ===

Tags: wordpress, like, plugin
Requires at least: 3.5.1
Tested up to: 3.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

=== # ===
