<?php  

//Register "container" content element

vc_map( array(

    "name" => __("Parallax Testimonials", "wish"),

    "description" => __("Clients testimonials with parallax background", 'wish'),

    "controls" => "full",

    "base" => "wish_parallax_testimonials",

    "as_parent" => array('only' => 'wish_parallax_testimonials_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)

    "content_element" => true,

    "link"  => "http://i.imgur.com/vskVjVi.png",

    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),

    "show_settings_on_create" => true,

    "category" => __('Wish Components', 'wish'),

    "js_view" => 'VcColumnView',

    "params" => array(



        // add params same as with any other content element

        array(

            "type" => "attach_image",

            "holder" => "div",

            "class" => "",

            "heading" => __("Image in the background", 'wish'),

            "param_name" => "image",

            "description" => __("The parallax image in the background", 'wish'),

        ), 



         array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __( "Text Color", "wish" ),

            "param_name" => "color",

            "value" => '#FFFFFF', //Default Red color

            "description" => __( "Choose the text color", "wish" )

         ),





    ),



));//ends vc_map



//////////////child elements

vc_map( array(

    "name" => __("Testimonial", "wish"),

    "base" => "wish_parallax_testimonials_single",

    "content_element" => true,

    "as_child" => array('only' => 'wish_parallax_testimonials'), // Use only|except attributes to limit parent (separate multiple values with comma)

    "params" => array(



        array(

            "type" => "textfield",

            "heading" => __("Client Name", "wish"),

            "param_name" => "title",

            "description" => __("Client Title and Position", "wish"),

            "value" => __("John Doe - Doe Designs", 'wish'),

            "admin_label" => true,

        ),



        array(

            "type" => "exploded_textarea",

            "holder" => "div",

            "class" => "",

            "heading" => __("The testimonial", 'wish'),

            "param_name" => "details",

            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),

            "description" => __("The Details", 'wish'),

            "admin_label" => false,

        ),





         /*Title*/

        array(

            "type" => "google_fonts",

            "class" => "",

            "heading" => __("Title Text Font", "wish" ),

            "param_name" => "title_font",

            "value" => '', //Default Red color

            "description" => __( "Choose Font", "wish" ),

            "group"   => "Fonts & Colors",

            'settings' => array(

                 'fields'=>array(

                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

               )

            )       

        ),





        array(

            "type" => "wish_number",

            "heading" => __("Title Size", "wish"),

            "param_name" => "title_size",

            "description" => __("Font size in px", "wish"),

            "value" => __("14", 'wish'),

            "admin_label" => true,

            "group"       => "Fonts & Colors",

        ),



        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __("Title Text Color", "wish" ),

            "param_name" => "title_color",

            "value" => '#b6b6b6 ', //Default Black color

            "description" => __( "Choose text color", "wish" ),

            "group"         => "Fonts & Colors",

         ),







        /*Details*/

        array(

            "type" => "google_fonts",

            "class" => "",

            "heading" => __("Details Text Font", "wish" ),

            "param_name" => "details_font",

            "value" => '', //Default Red color

            "description" => __( "Choose Font", "wish" ),

            "group"   => "Fonts & Colors",

            'settings' => array(

                 'fields'=>array(

                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

               )

            )       

        ),





        array(

            "type" => "wish_number",

            "heading" => __("Details Size", "wish"),

            "param_name" => "details_size",

            "description" => __("Font size in px", "wish"),

            "value" => __("20", 'wish'),

            "admin_label" => true,

            "group"       => "Fonts & Colors",

        ),



        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __("Details Text Color", "wish" ),

            "param_name" => "details_color",

            "value" => '#fff ', //Default Black color

            "description" => __( "Choose text color", "wish" ),

            "group"         => "Fonts & Colors",

         ),



       

    )//ends params



) );//ends vc_map







////////////////////////////////////Starts container class

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {

    class WPBakeryShortCode_Wish_Parallax_Testimonials extends WPBakeryShortCodesContainer {



    public function content( $atts, $content = null ) {



          extract( shortcode_atts( array(

            'image'   => 'Image',

            'color'   => '#fff'  

          ), $atts ) );



      $imgsrc = wp_get_attachment_image_src( $image, 'full' );

    

      if($image == "Image"){

        $imgsrc[0] = plugins_url('images/dark_street.jpg', __FILE__);

      }



      $output = "<div class='container-fluid testimonials parallax-testimonials  parallax-1' style='background-image:url({$imgsrc[0]});color:{$color};'>

                    <div class='row'>

                        <div class='col-lg-8 col-lg-offset-2'>

                            

                            <div class='testimonial-carousel animated' data-animation='flipInX' data-animation-delay='300'>

                                            " . do_shortcode($content) . "        

                            </div>

                        </div>

                    </div>

                </div>";

      

      return $output;

    }





    }//end of container class

} //end if



///////////////////////////////////////////ends container class





if ( class_exists( 'WPBakeryShortCode' ) ) {

class WPBakeryShortCode_Wish_Parallax_Testimonials_Single extends WPBakeryShortCode {





        public function content( $atts, $content = null ) {

        

          extract( shortcode_atts( array(

            'title'   => 'John Doe - Doe Designs',

            'title_font'    => '',

            'title_size'    => '14',

            'title_color' => '#b6b6b6',



            'details'       => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.',

            'details_font'  => '',

            'details_size'  => '20',

            'details_color' => '#fff'

          ), $atts ) );



        $decode_font = urldecode($title_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );





        $decode_font = urldecode($details_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

          

          $output = "<div>

                        <div class='icon1'><i class='fa fa-quote-left'></i></div>

                        <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>

                        <div class='name' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</div>

                    </div>";



          return $output;

        }





}//end class



} //end if



/////////////////////////////////////////////////////////////////////////////////////////////



?>