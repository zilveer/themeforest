<?php
if( !defined('_MULTIPURPOSE_SHORTCODE')) die('Access denied');

// shortcode Clients
add_shortcode('clients', 'multipurpose_clients');
add_shortcode('client', 'multipurpose_client');

function multipurpose_clients( $atts, $content = null ) {
    $output = '<article class="content-slider our-clients">'; 
	$output .= '<nav class="controls"><a href="#" class="prev">&lt;</a><a href="#" class="next">&gt;</a></nav>';
    if(isset($atts["title"]) && !empty($atts["title"])) 
        $output .= '<h2 class="underline"><span>'.$atts["title"].'</span></h2>';
	
    $output .= '<div class="slider-box">';
    $output .= do_shortcode($content);
    $output .= '</div></article>';
    
    return $output;  
}  

function multipurpose_client($atts, $content = null) {
    
    $link = '';
    $alt = '';
    if(isset($atts["link"]) && !empty($atts["link"]) && $atts["link"] !="Link") {
        $link = $atts["link"];
    } 
    
    if(isset($atts["image_alt"]) && !empty($atts["image_alt"])) {
        $alt = $atts["image_alt"];
    } 
    
    if ($link != '')
        $output = '<p><a href="'.$link.'"><img src="'.$atts["image_url"].'" alt="'.$alt.'" class="logo"></a></p>';
    else 
        $output = '<p><img src="'.$atts["image_url"].'" alt="'.$alt.'" class="logo"></p>';
    
    return $output;
}     
