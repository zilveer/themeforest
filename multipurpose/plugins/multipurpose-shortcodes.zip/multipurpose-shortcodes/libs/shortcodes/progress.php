<?php

if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// shortcode for progress
add_shortcode('progress', 'multipurpose_progress');
function multipurpose_progress($atts, $content=null){
    
    $percent= '';
    extract(shortcode_atts(array(  
        'percent' => ''
    ), $atts));  
    
    $output = '<p class="progress"><span class="fill"';
	
    if ($percent != '')
        $output .= ' data-width="'.$percent.'%"';

    $output .= '><span>'.do_shortcode($content).'</span></span></p>';

    return $output;
} 