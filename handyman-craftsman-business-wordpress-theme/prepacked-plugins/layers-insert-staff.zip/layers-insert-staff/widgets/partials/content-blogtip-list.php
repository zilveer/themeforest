<?php
/**
 * This template part is used for displaying posts in post-tip widget
 *
 * @package Layers
 * @since Layers 1.0.0
 */
global $tl_is_regular_widget, $tl_show_date; // used for regular widgets

$meta_defaults = array('date', 'categories');

if($tl_is_regular_widget){
    if($tl_show_date){
        $meta_defaults = array('date');
    }else{
        $meta_defaults = array();
    }
}
?>
<article class="clearfix push-bottom-large">
       <?php
           global $tl_glob_mobile;
            $thumb_size = ( isset($tl_glob_mobile) && $tl_glob_mobile->is('mobile')) ? 'tl-landscape-medium' : 'tl-square-small';
           if(isset($tl_is_regular_widget)){
               $thumb_size = 'thumbnail';
           }
       ?>

        <?php echo tl_post_featured_media(array(
            'size'      => $thumb_size,//[140, 140],
            'force_img' => true
        )); ?>

    <div class="thumbnail-body">
        <header class="article-title">
            <h3 class="heading"><a title="<?php the_title_rss(); ?>" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        </header>
        <?php
            /* Display meta data */
        tl_layers_post_meta( get_the_ID(), $meta_defaults, 'footer', 'meta-info push-bottom' );
        ?>
    </div>
</article>