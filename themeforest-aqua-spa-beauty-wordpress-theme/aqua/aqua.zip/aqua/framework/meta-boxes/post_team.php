<div id="tb_team_metabox" class='tb-team-metabox'>
	<?php
	$this->text('team_position',
			'Position',
			'',
			__('Enter team position of post team.','jwsthemes')
	);
	$this->text('team_facebook',
			'Facebook',
			'',
			__('Enter facebook of post team. Ex: http://facebook.com/','jwsthemes')
	);
	$this->text('team_twitter',
			'Twitter',
			'',
			__('Enter twitter of post team. Ex: https://twitter.com/','jwsthemes')
	);
	$this->text('team_google_plus',
			'Google Plus',
			'',
			__('Enter google plus of post team. Ex: https://plus.google.com/','jwsthemes')
	);
	$this->text('team_linkedin',
			'Linkedin',
			'',
			__('Enter linkedin of post team. Ex: https://www.linkedin.com/','jwsthemes')
	);
	?>
</div>
	<?php
