<?php
class WPBakeryShortCode_Mnky_Colored_Box extends WPBakeryShortCode {

}