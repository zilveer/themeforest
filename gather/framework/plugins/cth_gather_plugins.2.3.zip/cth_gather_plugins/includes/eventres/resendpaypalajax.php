<?php
if ( ! defined('ABSPATH') ) {
    die('Please do not load this file directly!');
}

add_action( 'wp_ajax_nopriv_eventres_resend_paypal_link', 'cththemes_eventres_resend_paypal_link_callback' );
add_action( 'wp_ajax_eventres_resend_paypal_link', 'cththemes_eventres_resend_paypal_link_callback' );
function cththemes_eventres_resend_paypal_link_callback() {

    $json = array();
    $json['success'] = 0;
    $nonce = $_POST['nonce'];
    //wp_send_json($_POST );
    
    if ( ! wp_verify_nonce( $nonce, 'eventres_resend_paypal_link_action' ) )
        die ( '<p class="error">Security checked!, Cheatn huh?</p>' );

    $payment_id = (int)$_POST['pm_id'];
    $pm_st = $_POST['pm_st'];

    $eventres_is_free_email         = get_post_meta( $payment_id, 'pur_gateway', true );

    if($eventres_is_free_email == 'Free Email Registration'){
        $json['message']  = __('Cannot send the email to free registration client','cth-gather-plugins');
        wp_send_json($json );
    }

    // for option prices
    $paypal_options = array();
    $paypal_options['on0'] = get_option('eventres_item_prices_name' ,'Pass');
    $paypal_options['os0'] = get_post_meta( $payment_id, 'pur_pass', true );
    $prices_option = get_option('eventres_item_prices');
    
    if(!empty($prices_option)){
        $op_in = 0;
        foreach ($prices_option as $pr_arr) {
            $paypal_options['option_select'.$op_in] = trim($pr_arr['name']);
            $paypal_options['option_amount'.$op_in] = trim($pr_arr['value']);
            if($paypal_options['os0'] == trim($pr_arr['name'])){
                //for reservation meta data store
                $pm_price = trim($pr_arr['value']);
            }
            $op_in++;
        }
    }else{
        $pm_price = '99';
        $paypal_options['option_select0'] = 'Default Pass';
        $paypal_options['option_amount0'] = '99';
    }


    // only send to paypal if the pending payment is created successfully
    $listener_url = get_permalink(get_option('eventres_success_page' ) );// trailingslashit( home_url() ).'?cth-listener=IPN';
    $cancel_url = get_permalink(get_option('eventres_cancelled_page' ) );// trailingslashit( home_url() ).'?cth-listener=IPN';
    $return_url = get_permalink(get_option('eventres_success_page' ) );

    // one time payment
    $eventres_test_mode = get_option('eventres_test_mode' );

    if( $eventres_test_mode ) {
        $paypal_link = 'https://www.sandbox.paypal.com/cgi-bin/webscr/?';
    } else {
        $paypal_link = 'https://www.paypal.com/cgi-bin/webscr/?';
    }
    /* email template variable */
    //new in version 2.0
    $allow_field_names = array('first_name','last_name','payer_email','receiver_email','item_name','item_number','quantity','payment_currency','payment_amount','event_pass','date','sitename','paypal_link','payment_id');
    $eventres_add_fields            = get_option('eventres_add_fields','' );
    if(!empty($eventres_add_fields)){
        foreach ($eventres_add_fields as $key => $field) {
            $field_name = str_replace(array(" ","-"), "_", $field['name']);
            // if(!isset($res_meta_datas[$field_name])){
            //     $res_meta_datas[$field_name] = trim($_POST[$field_name]); 
            // }
            $allow_field_names[] = $field_name;
            if(!isset($$field_name)){
                $$field_name = get_post_meta( $payment_id, $field_name, true );
            }
        }
    }

    $allow_field_names = array_unique($allow_field_names);


    $first_name = get_post_meta( $payment_id, 'pur_fname', true );
    $last_name = get_post_meta( $payment_id, 'pur_lname', true );
    $payer_email = get_post_meta( $payment_id, 'pur_email', true );
    $receiver_email = get_option('eventres_paypal_email');
    $item_name = get_option('eventres_item_name' );
    $item_number = get_post_meta( $payment_id, 'pur_custom', true );
    $quantity = get_post_meta( $payment_id, 'pur_quantity', true );
    $payment_currency = get_option('eventres_currency');
    $payment_amount = (float)$pm_price * (int)$quantity;
    $event_pass = get_post_meta( $payment_id, 'pur_pass', true );
    $date           = get_post_meta( $payment_id, 'pur_date', true );
    $sitename           = get_option( 'blogname' );

    $paypal_args = array(
        'cmd' => '_xclick',
        //'amount' => $res_post_datas['price'],
        'item_name' => $item_name,
        'item_number' => $item_number,
        'quantity' => $quantity,
        'currency_code' => $payment_currency,
        'custom' => $payment_id,
        'business' => $receiver_email,
        
        'email' => $payer_email,
        'first_name'=>$first_name,
        'last_name'=>$last_name,
        
        'no_shipping' => '1',
        'no_note' => '1',
        
         
        'charset' => 'UTF-8',
        
        'rm' => '2',//return method / 2: mean post
        'cancel_return'=>$cancel_url,
        'return' => $return_url,
        'notify_url' => $listener_url
    );

    // merge with $paypal_options array
    $paypal_args = array_merge($paypal_args, $paypal_options);
    $paypal_link .= http_build_query($paypal_args);


    $sender_option = get_option('eventres_email_sender','Gather Event' );
    $sender_email_option = get_option('eventres_email_sender_email','contact.cththemes@gmail.com' );

    // to buyer
    $resend_paypal_link_mail_subject = get_option('eventres_resend_paypal_link_email_subject','Your payment have never been completed'); 
    $resend_paypal_link_email_template = get_option('eventres_resend_paypal_link_email_template'); 

    if(preg_match_all("/{([\w_]+)[^\w_]*}/", $resend_paypal_link_email_template, $matches)!= FALSE){
        $fieldsPattern = array();//$matches[0];
        $fieldsReplace = array();
        foreach ($matches[1] as $key => $fn) {
            $fieldsPattern[] = "/{(".$fn.")[^\w_]*}/";

            if( isset( $$fn )&&in_array( $fn, $allow_field_names ) ){
                $fieldsReplace[] = $$fn;  //'['.$fn.']';
            }else{
                $fieldsReplace[] = '{'.$fn.'}';
            }
            
        }


        $resend_paypal_link_email_template = preg_replace($fieldsPattern, $fieldsReplace, $resend_paypal_link_email_template);
    }


    $headers = array();
    // if(get_option('eventres_email_content_type','yes' ) == 'yes'){
    //     $headers[] = 'Content-Type: text/html; charset=UTF-8';
    // }
    $headers[] = 'Content-Type: text/plain; charset=UTF-8';
    //$headers[] = 'From: '. $sender_option.' ' . '<'.$sender_email_option.'>';
    add_filter( 'wp_mail_from_name', 'cth_gather_plugins_custom_wp_mail_from_name' );
    $headers[] = 'Reply-To: '. $sender_option.' ' . '<'.$sender_email_option.'>';

    if (!wp_mail( $payer_email, $resend_paypal_link_mail_subject , $resend_paypal_link_email_template, $headers)) {
        $json['message']  = __('Email send failed','cth-gather-plugins');//'Email send failed';
    }else{
        $json['message']  = __('Email sent','cth-gather-plugins');//'Email sent';
    }
    
    remove_filter( 'wp_mail_from_name', 'cth_gather_plugins_custom_wp_mail_from_name' );

    wp_send_json($json );
}