<?php 
if ( class_exists( 'WPBakeryShortCode' ) ) {

	class WPBakeryShortCode_experience_portfolio_grid extends WPBakeryShortCode {	
		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = null ) {
			
			global $post;			
			
			$experience_vc_utilities = new jsComposerExperienceUtilities();
			
			$output = $css_class = '';
			
			extract( shortcode_atts( array(
				'el_class'				=> '',
				'css'					=> '',
				'color'					=> '',
				'portfolio_category'	=> '',
				'grid_width'			=> '',
				'number'				=> '',
				'hide_title'			=> '',
				'link_type'				=> ''
			), $atts ) );
			
			$class = $this->getExtraClass( $el_class );			
			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );
			
			$output .= '<div class="section-content-wrapper '. esc_attr(  $css_class .' '.  $color ) .'">';
		
				// Number of posts
				if ( intval( $number ) > 0 ) {
					$posts_per_page = esc_html( $number );
				} else {
					$posts_per_page = -1;
				}

				if ( $portfolio_category != "" ) {
					
					$query_args = array(
						'post_type' => array( 'portfolio' ),
						'tax_query' => array(
							array(
								'taxonomy'	=> 'portfolio_category',
								'field'		=> 'name',
								'terms'		=> esc_html( $portfolio_category )
							)
						),
						'posts_per_page' => intval( $posts_per_page )
					);

				} else {
					
					$query_args = array(
						'post_type' => array( 'portfolio' ),
						'posts_per_page' => $posts_per_page
					);

				}

				$portfolio_query = new WP_query( $query_args );
			
				if ( $portfolio_query->have_posts() ) :				
					
					$output .= '<div class="post-grid portfolio-grid clearfix '. esc_attr( $grid_width ) .'">';
					
						while ( $portfolio_query->have_posts() ) :
						
							$portfolio_query->the_post();
							
							// Set colour scheme
							if ( get_post_meta( $post->ID, 'experience_header_color_scheme', true ) != "" ) {		
								$color_scheme = 'color-scheme-'. get_post_meta( $post->ID, 'experience_portfolio_item_preview_color_scheme', true );
							} else {
								$color_scheme = '';
							}
			
							$output .= '<article class="post-grid-item '. esc_attr( $color_scheme ) .'" ontouchstart="">
				
								<div class="post-grid-item-image">';
								
									// Background Image
									if ( has_post_thumbnail() ) {
										$background_image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'experience-post-grid' );
										$background_image = $background_image[0];
									} else {
										$background_image = false;
									}
									
									$output .= $experience_vc_utilities->experienceGetBackground(					
										$background_image,
										false,
										false,
										false, 
										false,
										false,
										false
									);
									
								$output .= '</div>';
								
								$output .= '<div class="post-grid-item-content">
									
									<span class="post-grid-item-content-bg"></span>
									
									<div class="holder">
									
										<div class="cont">';
											
											if ( $hide_title != 'true' ) {
												$output .= '<h2>'. get_the_title() .'</h2>';
											}
											
										$output .= '</div>
										
									</div>
								
									<div class="holder">
						
										<div class="cont">';
											
											if ( $link_type == 'title' ) {
												$output .= '<a href="'. get_the_permalink() .'" rel="bookmark"><h2>'. get_the_title() .'</h2></a>';
											} else {
												$output .= '<a class="vc_btn3" href="'. get_the_permalink() .'" rel="bookmark">'. esc_html__( "View", "js_composer_experience" ) .'</a>';
											}
											
										$output .= '</div>
										
									</div>
							
								</div>
								
							</article>';
							
						endwhile;
						
					$output .= '</div>';

				else :
					
					$output .= '<p>'. esc_html__( "There are no portfolio items to display.", "js_composer_experience" ).'</p>';
					
				endif;
				
				wp_reset_postdata();
				
			$output .= '</div>';
			
			return $output;
		
		}	

	}
	
}


/* --------- PORTFOLIO GRID --------- */

vc_map( array(
	"base"			=> "experience_portfolio_grid",
	"name"			=> esc_html__( "Portfolio (Grid)", "js_composer_experience" ),
	"description"	=> esc_html__( "Portfolio created from existing Categories", "js_composer_experience" ),
	"class"			=> "",
	"params"		=> array(
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			"type"			=> "textfield",
			'admin_label'	=> true
		),		
		
		// Portfolio Category
		array(
			"param_name"	=> "portfolio_category",
			"heading"		=> esc_html__( "Portfolio Category", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the name of the portfolio category to display in this portfolio.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label" => true
		),			
	
		// Number of Posts
		array(
			"param_name"	=> "number",
			"heading"		=> esc_html__( "Number of Posts", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the number of portfolio items to display. Leave blank to display all portfolio items in the specified category.", "js_composer_experience" ),
			"type"			=> "textfield"
		),
		
		// Hide Title
		array(
			"param_name"	=> "hide_title",
			"heading"		=> esc_html__( "Hide Title", "js_composer_experience" ),
			"description"	=> esc_html__( "Do not show the portfolio item titles.", "js_composer_experience" ),
			"type"			=> "checkbox"
		),
		
		// Link Type
		array(
			"param_name"	=> "link_type",			
			"heading"		=> esc_html__( "Link Style", "js_composer_experience" ),
			"description"	=> esc_html__( "Choose the style of link shown on portfolio grid items.", "js_composer_experience" ),
			"type"			=> "dropdown",
			'value'			=> array(
				esc_html__( 'Button', "js_composer_experience" )	=> '',
				esc_html__( 'Title', "js_composer_experience" )	=> 'title'
			)
		),
		
		// CSS
		array(
			"type"		 => "css_editor",
			"heading"	 => esc_html__( "CSS", "js_composer_experience" ),
			"param_name" => "css",
			"group"		 => esc_html__( "Design options", "js_composer_experience" )
		)
		
	)
	
) );