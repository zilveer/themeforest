<?php

add_action('init', 'tb_block_number_integrateWithVC');

function tb_block_number_integrateWithVC() {
    vc_map(array(
        "name" => __("Block Number", 'jwsthemes'),
        "base" => "tb_block_number",
        "category" => __('Aqua', 'jwsthemes'),
        "icon" => "tb-icon-for-vc",
        "params" => array(
            array(
                "type" => "dropdown",
                "class" => "",
                "heading" => __("Type", 'jwsthemes'),
                "param_name" => "type",
                "value" => array(
                    "Square" => "square",
                    "Circle" => "circle",
                    "Rounded" => "rounded",
                ),
                "description" => __('Select type for block number', 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => __("Text", 'jwsthemes'),
                "param_name" => "text",
                "value" => "",
                "description" => __("Please, enter text for block number.", 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => __("Title", 'jwsthemes'),
                "param_name" => "title",
                "value" => "",
                "description" => __("Please, enter title for block number.", 'jwsthemes')
            ),
            array(
                "type" => "textarea",
                "class" => "",
                "heading" => __("Content", 'jwsthemes'),
                "param_name" => "block_number_content",
                "value" => "",
                "description" => __("Please, enter Content for block number.", 'jwsthemes')
            ),          
            array(
                "type" => "colorpicker",
                "class" => "",
                "heading" => __("Color", 'jwsthemes'),
                "param_name" => "color",
                "value" => "",
                "description" => __("Select color for block number.", 'jwsthemes')
            ),
            array(
                "type" => "colorpicker",
                "class" => "",
                "heading" => __("Background", 'jwsthemes'),
                "param_name" => "background",
                "value" => "",
                "description" => __("Select background color for block number.", 'jwsthemes')
            ),
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => __("Extra Class", 'jwsthemes'),
                "param_name" => "el_class",
                "value" => "",
                "description" => __ ( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'jwsthemes' )
            ),
        )
    ));
}
