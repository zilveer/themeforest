<?php  /*IJAZ AHMAD*/

//Register "container" content element

vc_map( array(

    "name" => __("Vertical Timeline", "wish"),

    "description" => __("Timeline with Title and Details", 'wish'),

    "controls" => "full",

    "base" => "wish_vertical_timeline",

    "as_parent" => array('only' => 'wish_vertical_timeline_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)

    "content_element" => true,

    "link" => "http://i.imgur.com/NTSQM18.png",

    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),

    "show_settings_on_create" => true,

    "category" => __('Wish Components', 'wish'),

    "js_view" => 'VcColumnView',

    "params" => array(



        // add params same as with any other content element

        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __( "Background Color", "wish" ),

            "param_name" => "bgcolor",

            "value" => '#FFFFFF', //Default Red color

            "description" => __( "Choose the background color", "wish" )

         ),





    ),



));//ends vc_map



//////////////child elements

vc_map( array(

    "name" => __("timeline", "wish"),

    "base" => "wish_vertical_timeline_single",

    "content_element" => true,

    "as_child" => array('only' => 'wish_vertical_timeline'), // Use only|except attributes to limit parent (separate multiple values with comma)

    "params" => array(



        array(

            "type" => "textfield",

            "heading" => __("Date", "wish"),

            "param_name" => "date",

            "description" => __("", "wish"),

            "value" => __("Jan 14", 'wish'),

            "admin_label" => false,

        ),





        // array(

        //     "type" => "dropdown",

        //     "heading" => __("Image Left/Right", "wish"),

        //     "param_name" => "img_pos",

        //     "description" => __("Image position Left or right?", "wish"),

        //     "value" => array( 

        //                       "Left"     => "Left",

        //                       "Right"     => "Right",

        //                     ),

        //     "std"       =>   5,

        // ),





        array(

            "type" => "textfield",

            "heading" => __("title", "wish"),

            "param_name" => "title",

            "description" => __("", "wish"),

            "value" => __("Title of section", 'wish'),

            "admin_label" => false,

        ),



        array(

            "type" => "textarea",

            "holder" => "div",

            "class" => "",

            "heading" => __("Details", 'wish'),

            "param_name" => "details",

            "value" => __("Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, optio, dolorum provident rerum aut hic quasi placeat iure tempora laudantium ipsa ad debitis unde? Iste voluptatibus minus veritatis qui ut.", 'wish'),

            "description" => __("The details below the title", 'wish'),

            "admin_label" => false,

        ),



        array(

            "type" => "vc_link",

            "holder" => "div",

            "class" => "",

            "heading" => __("Link To The Page", 'wish'),

            "param_name" => "link",

            "description" => __("The Link To The Appointment page.", 'wish'),

            "admin_label" => false,

        ),



        array(

            "type" => "textfield",

            "heading" => __("Link Title", "wish"),

            "param_name" => "link_text",

            "description" => __("Title of the link", "wish"),

            "value" => __("Read More", 'wish'),

            "admin_label" => false,

        ),





        /*Date*/

        array(

            "type" => "google_fonts",

            "class" => "",

            "heading" => __("Date Text Font", "wish" ),

            "param_name" => "date_font",

            "value" => '', //Default Red color

            "description" => __( "Choose Font", "wish" ),

            "group"   => "Fonts & Colors",

            'settings' => array(

                 'fields'=>array(

                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

               )

            )       

        ),





        array(

            "type" => "wish_number",

            "heading" => __("Date Size", "wish"),

            "param_name" => "date_size",

            "description" => __("Font size in px", "wish"),

            "value" => __("20", 'wish'),

            "admin_label" => true,

            "group"       => "Fonts & Colors",

        ),



        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __("Date Text Color", "wish" ),

            "param_name" => "date_color",

            "value" => '#7f8c97 ', 

            "description" => __( "Choose text color", "wish" ),

            "group"         => "Fonts & Colors",

         ),



        /*Title*/

        array(

            "type" => "google_fonts",

            "class" => "",

            "heading" => __("Title Text Font", "wish" ),

            "param_name" => "title_font",

            "value" => '', 

            "description" => __( "Choose Font", "wish" ),

            "group"   => "Fonts & Colors",

            'settings' => array(

                 'fields'=>array(

                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

               )

            )       

        ),





        array(

            "type" => "wish_number",

            "heading" => __("Title Size", "wish"),

            "param_name" => "title_size",

            "description" => __("Font size in px", "wish"),

            "value" => __("24", 'wish'),

            "admin_label" => true,

            "group"       => "Fonts & Colors",

        ),



        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __("Title Text Color", "wish" ),

            "param_name" => "title_color",

            "value" => '#000 ',

            "description" => __( "Choose text color", "wish" ),

            "group"         => "Fonts & Colors",

         ),





        /*Details*/

        array(

            "type" => "google_fonts",

            "class" => "",

            "heading" => __("Details Text Font", "wish" ),

            "param_name" => "details_font",

            "value" => '', 

            "description" => __( "Choose Font", "wish" ),

            "group"   => "Fonts & Colors",

            'settings' => array(

                 'fields'=>array(

                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

               )

            )       

        ),





        array(

            "type" => "wish_number",

            "heading" => __("Details Size", "wish"),

            "param_name" => "details_size",

            "description" => __("Font size in px", "wish"),

            "value" => __("14", 'wish'),

            "admin_label" => true,

            "group"       => "Fonts & Colors",

        ),



        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __("Details Text Color", "wish" ),

            "param_name" => "details_color",

            "value" => '#f7f7f7', 

            "description" => __( "Choose text color", "wish" ),

            "group"         => "Fonts & Colors",

         ),





        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __( "Icon circle background color", "wish" ),

            "param_name" => "circle_bgcolor",

            "value" => '#75ce66', 

            "description" => __( "Choose color of icon", "wish" ),

            "group"         => "Fonts & Colors",

         ),



        array(

            "type" => "colorpicker",

            "class" => "",

            "heading" => __( "Background Color", "wish" ),

            "param_name" => "bgcolor",

            "value" => '#FFFFFF', //Default Red color

            "description" => __( "Choose the background color", "wish" ),

            "group"         => "Fonts & Colors",

         ),

    )//ends params



) );//ends vc_map







////////////////////////////////////Starts container class

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {

    class WPBakeryShortCode_Wish_Vertical_Timeline extends WPBakeryShortCodesContainer {



    public function content( $atts, $content = null ) {



          extract( shortcode_atts( array(

            'bgcolor'   => '#fff'  

          ), $atts ) );





      $output = "<div id='cd-timeline' style='background-color:{$bgcolor}'>

                    " . do_shortcode($content) . "

                

            </div>";

      

      return $output;

    }





    }//end of container class

} //end if



///////////////////////////////////////////ends container class





if ( class_exists( 'WPBakeryShortCode' ) ) {

class WPBakeryShortCode_Wish_Vertical_Timeline_Single extends WPBakeryShortCode {





        public function content( $atts, $content = null ) {

        

          extract( shortcode_atts( array(

            'date'   => 'Jan 14',

            'date_font'    => '',

            'date_size'    => '24',

            'date_color' => '#7f8c97',



            'title'   => 'Title of section',

            'title_font'    => '',

            'title_size'    => '24',

            'title_color' => '#000',



            'details' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, optio, dolorum provident rerum aut hic quasi placeat iure tempora laudantium ipsa ad debitis unde? Iste voluptatibus minus veritatis qui ut.',

            'details_font'  => '',

            'details_size'  => '14',

            'details_color' => '#f7f7f7',



            'link'  => '',

            'link_text' => 'Read More',

            'circle_bgcolor'    => '#75ce66',

            'bgcolor'   => '#fff'

          ), $atts ) );





        /*date*/

        $decode_font = urldecode($date_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $date_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );





        /*title*/

        $decode_font = urldecode($title_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );







        /*details*/

        $decode_font = urldecode($details_font);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



        wp_register_script('wish-modernizr', plugins_url('assets/modernizr.js', __FILE__), array('jquery') );

        wp_register_script('wish-vertical_timeline', plugins_url('assets/vertical_timeline.js', __FILE__), array('jquery') );





          if($link == "||" || $link == "" ){

            

            $link_text = "Read More";

            $link_url = "#";

            $link_target = "";

            $link_String="";



          }else{



            $link = vc_build_link($link); //parse the link

            $link_url = esc_url($link["url"]);

            $link_target = esc_attr($link["target"]);

            $link_String="<a href='{$link_url}' class='cd-read-more'>{$link_text}</a>";

            if ($link_text == "") {

                $link_String = "";

            }



          }



        $output = "<div class='cd-timeline-block'>

        <div class='cd-timeline-img' style='background-color:{$circle_bgcolor}'>

        </div> 


        <style>.cd-timeline-content::before{
                border-color: transparent transparent transparent {$bgcolor};
        }

        .cd-timeline-block:nth-child(2n) .cd-timeline-content::before{
            border-color: transparent {$bgcolor} transparent transparent;
        }

        </style>
 

        <div class='cd-timeline-content' style='background-color:{$bgcolor}'>

            <h2 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h2>

            <p style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</p>

            {$link_String}

            <span class='cd-date' style='font-family:{$date_font_family};font-size:{$date_size}px;color:{$date_color};'>{$date}</span>

        </div> <!-- cd-timeline-content -->

    </div> <!-- cd-timeline-block -->";

          return $output;

        }





}//end class



} //end if



/////////////////////////////////////////////////////////////////////////////////////////////



?>