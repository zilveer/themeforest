<?php /**
 * TL_Layers_BlogTips_Widget Widget
 *
 * This file is used to register and display the Layers - TL_Layers_BlogTips_Widget.
 *
 * @package Layers
 * @since Layers 1.0.0
 */
if (!class_exists('TL_Layers_Abstract_Widget')) { return; }

if (!class_exists('TL_Layers_Promotional_Widget')) {
    class TL_Layers_Promotional_Widget extends TL_Layers_Abstract_Widget
    {

        /**
         *  Widget construction
         */
        public function __construct()
        {
            /**
             * Widget variables
             *
             * @param    string $widget_title Widget title
             * @param    string $widget_id Widget slug for use as an ID/classname
             * @param    string $post_type (optional) Post type for use in widget options
             * @param    string $taxonomy (optional) Taxonomy slug for use as an ID/classname
             * @param    array $checkboxes (optional) Array of checkbox names to be saved in this widget. Don't forget these please!
             */
            $this->widget_title = __('TL Promotional', TL_INSERT_STAFF_SLUG);
            $this->widget_id = 'tl_promotional';
            $this->post_type = '';
            $this->taxonomy = '';
            $this->checkboxes = array('overlay', 'push-left');

            /* Widget settings. */
            $widget_ops = array('classname' => 'obox-layers-' . $this->widget_id . '-widget',
                'description' => __('This widget is used to display your ', 'layerswp') . $this->widget_title . '.');

            /* Widget control settings. */
            $control_ops = array('width' => LAYERS_WIDGET_WIDTH_SMALL,
                'height' => NULL,
                'id_base' => LAYERS_THEME_SLUG . '-widget-' . $this->widget_id);

            /* Create the widget. */
            parent::__construct(LAYERS_THEME_SLUG . '-widget-' . $this->widget_id, $this->widget_title, $widget_ops, $control_ops);

            /* Setup Widget Defaults */
            $this->defaults = array(
                'heading' => '<mark>Handyman</mark> Special Offer This Month',
                'excerpt' => '-20% For all cursusdignissimos perspiciatis dictmust beatea aliqua qon minus etiam illo ultricies purus nulla faucibus reppesumbda for all tenetur mollis eius proident.',
                'link_label' => __('GET A JOB DONE', TL_INSERT_STAFF_SLUG),
                'custom_link' => '',
                'page_id' => null,
                'icon' => null,
                'design' => array(
                    'layout' => 'layout-boxed',
                    'background' => array('position' => 'center',
                        'repeat' => 'no-repeat',
                        'overlay' => 'on'
                    ),
                    'fonts' => array(
                        // Main heading
                        'align' => 'text-left',
                        'size' => 'medium',
                        'color' => '#ffffff',
                        // Excerpt
                        'excerpt-align' => 'text-left',
                        'excerpt-size' => 'medium',
                        'excerpt-color' => '#ffffff',
                    ),
                    'buttons' => array(
                        'size' => 'btn-large',
                        'push-left' => null,
                    ),
                )
            );

            $this->_addFilters();

            $this->get_theme_colors();

            add_action('wp_enqueue_scripts', array($this, 'enqueue_css'), 999);
        }


        public function enqueue_css(){
            wp_enqueue_style(
                'theme-flaticons',
                parent::asset_path('css/themify-icons.min.css', false, true),
                array(),
                TL_THEME_VER
            );
        }

        /**
         * Widget front end display
         *
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        {
            $this->backup_inline_css();

            // Turn $args array into variables.
            extract($args);

            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            if (!empty($widget['design']['fonts']['excerpt-color'])) {
                $this->inline_css .= layers_inline_styles('#' . $widget_id . ' .section-content div.excerpt{
                                                                color: ' . $widget['design']['fonts']['excerpt-color'] . ';
                                                                color: rgba(' . apply_filters('tl/hex2rgba', $widget['design']['fonts']['excerpt-color'], 0.85, true) . ');}'
                );
            }

            $this->_apply_button_styling($widget_id, $widget);

            // Apply Section Styling
            $this->_apply_widget_section_styling($widget_id, $widget);


            /**
             * Generate the widget container class
             */
            $widget_container_class = array();
            $widget_container_class[] = 'widget content-vertical-massive';
            $widget_container_class[] = $this->widget_id;
            $widget_container_class[] = $this->check_and_return($widget, 'design', 'advanced', 'customclass');
            $widget_container_class[] = $this->get_widget_spacing_class($widget);
            $widget_container_class = implode(' ', $widget_container_class);

            $overlay = $this->check_and_return($widget, 'design', 'background', 'overlay');
            $pull_icon_right = $this->check_and_return($widget, 'icon_pull_right');
            $has_icon = ($this->check_and_return($widget, 'icon') != 'ti-none') && $this->check_and_return($widget, 'icon');

            // Inline Colors

            if($this->colors){
                if ($has_icon) {
                    $widget['icon'] = $this->_isAwesomeIcon($widget['icon']) ? 'fa ' . $widget['icon'] : $widget['icon'];
                    $this->inline_css .= layers_inline_styles('#' . $widget_id, array('selectors' => array('.icon-wrapper i'),
                        'css' => array('background-color' => $this->colors->get('_secondary'),
                            'background-position' => 'center',
                            'background-repeat' => 'repeat',
                            'background-image' => 'url(' . parent::asset_path('images/transparent_bg_dark_pattern.png', false, true) . ')')));
                }

                // Overlay
                $this->inline_css .= layers_inline_styles('#' . $widget_id . ' .overlay{
                                                            background-color: ' . $this->colors->get('_primary') . ';
                                                            background-color: rgba(' . apply_filters('tl/hex2rgba', $this->colors->get('_primary'), '0.75', true) . '); }');

                $this->inline_css .= layers_inline_styles('#' . $widget_id, array('selectors' => array('.slogan-container mark'),
                    'css' => array('color' => $this->colors->get('_secondary'))));
            }
            ?>
            <div class="<?php echo esc_attr($widget_container_class); ?>" id="<?php echo esc_attr($widget_id); ?>">
                <?php echo $this->custom_anchor( $widget ); ?>
                <?php do_action( 'layers_before_'.$this->widget_id.'_widget_inner', $this, $widget ); ?>
                    <?php if ($overlay == 'on'): ?>
                        <div class="overlay"></div>
                    <?php endif; ?>

                    <div class="<?php echo($pull_icon_right ? 'badge-pull-right' : ''); ?> clearfix <?php echo esc_attr($this->get_widget_layout_class($widget)); ?> list-grid">

                        <div class="grid">
                            <?php if (!$pull_icon_right && $has_icon): ?>
                                <div class="layers-masonry-column icon-column column-flush span-2">
                                    <div class="icon-wrapper">
                                        <i class="<?php echo esc_attr(apply_filters('tl/themify_filter', $widget['icon'])) ?>"></i>
                                    </div>
                                </div><!-- icon -->
                            <?php endif; ?>

                            <div class="layers-masonry-column <?php echo $pull_icon_right ? 'column' : 'column-flush'?> <?php echo $has_icon ? 'span-10' : 'span-12'; ?>">
                                <?php
                                $section_title_class = array();
                                $section_title_class[] = 'section-title clearfix';
                                $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'size');
                                $section_title_class[] = $this->check_and_return($widget, 'design', 'fonts', 'align');
                                $section_title_class = implode(' ', $section_title_class);

                                $has_button = $this->check_and_return($widget, 'page_id') || ($this->check_and_return($widget, 'link_label') && $this->check_and_return($widget, 'custom_link'));

                                $push_button = '';
                                if($has_button && $this->check_and_return($widget, 'design', 'buttons', 'push-left')){
                                    $push_button = 'reverse-items';
                                }
                                ?>
                                <div class="slogan-container layers-masonry-row">
                                    <div class="<?php echo esc_attr($section_title_class) ?>">
                                        <h3 class="heading"><?php layers_the_content($widget['heading']); ?></h3>
                                    </div>

                                    <div class="section-content grid clearfix <?php echo esc_attr($push_button); ?>">
                                        <?php
                                        $excerpt_class[] = $this->check_and_return($widget, 'design', 'fonts', 'excerpt-size');
                                        $excerpt_class[] = $this->check_and_return($widget, 'design', 'fonts', 'excerpt-align');
                                        $excerpt_class = implode(' ', $excerpt_class);

                                        if ($has_button) {
                                            $link = '';
                                            if ($this->check_and_return($widget, 'page_id')) {
                                                $posts = tl_get_posts(array(
                                                    'post_type' => 'page',
                                                    'post__in' => array($widget['page_id'])
                                                ), true);

                                                $post = isset($posts[0]) ? $posts[0] : 0;

                                                $button_label = isset($post->post_title) ? $post->post_title : '';
                                                $link = get_permalink($widget['page_id']);
                                            } else {
                                                $link = isset($widget['custom_link']) ? $widget['custom_link'] : '';
                                            }
                                            $button_label = $this->check_and_return($widget, 'link_label') ? $widget['link_label'] : $button_label;
                                        }
                                        ?>

                                        <div class="column <?php echo($has_button ? 'span-9' : 'span-12')?>">
                                            <div class="excerpt <?php echo esc_attr($excerpt_class) ?>">
                                                <?php echo apply_filters('the_content', $widget['excerpt']) ?>
                                            </div>
                                        </div>
                                        <?php if ($has_button):

                                            $btn_classes   = array();
                                            $btn_classes[] = 'button';
                                            $btn_classes[] = $push_button ? '' : 'pull-right';
                                            $btn_classes[] = 'btn-' . $this->check_and_return($widget, 'design', 'buttons', 'buttons-size');
                                            $btn_classes[] = $this->check_and_return($widget, 'design', 'buttons', 'animation');
                                            $btn_classes = implode(' ', $btn_classes);

                                            ?>
                                            <div class="column span-3">
                                                <a class="<?php echo esc_attr($btn_classes); ?>" href="<?php echo apply_filters('the_title', $link); ?>" title="<?php echo esc_attr($button_label) ?>">
                                                    <?php echo apply_filters('the_title', $button_label); ?>
                                                    <i class="icon-ti-angle-double-right"></i>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <?php if ($pull_icon_right && $has_icon): ?>
                                <div class="layers-masonry-column icon-column column span-2">
                                    <div class="icon-wrapper pull-right">
                                        <i class="<?php /* this filter TBD in the future */
                                        echo esc_attr(apply_filters('tl/themify_filter', $widget['icon'])) ?>"></i>
                                    </div>
                                </div><!-- icon -->
                            <?php endif; ?>
                            <!-- slogans -->
                        </div>
                    </div>
                    <!-- .container -->
                    <?php do_action( 'layers_after_' . $this->id . '_widget_inner', $this, $widget );

                    // Print the Inline Styles for this Widget
                    $this->print_inline_css();

                    // Apply the advanced widget styling
                    $this->apply_widget_advanced_styling($widget_id, $widget);
                    ?>
            </div>
        <?php }


        /**
         * Widget form
         *
         * @param array $instance
         * @return string|void
         */
        function form($instance)
        {
            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );

            if (TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_start('tl_sanitize_output');

            $this->design_bar(
                'side', // CSS Class Name
                array(
                    'name' => $this->get_layers_field_name('design'),
                    'id' => $this->get_layers_field_id('design'),
                    'widget_id' => $this->widget_id,
                ), // Widget Object
                $widget, // Widget Values
                apply_filters('layers_' . $this->widget_id . '_widget_design_bar_components', array(
                    'layout',
                    'fonts',
                    'buttons',
                    'custom',
                    'background',
                    'advanced'
                ))// Standard Components
            ); ?>
            <div class="layers-container-large promotional-widget-admin">
                <?php $this->form_elements()->header(array(
                    'title' => __('Promotional', TL_INSERT_STAFF_SLUG),
                    'icon_class' => 'post'
                )); ?>
                <section class="layers-accordion-section layers-content">
                    <div class="layers-row layers-push-bottom">
                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('heading')); ?>"><?php _e('Heading', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'rte',
                                    'name' => $this->get_layers_field_name('heading'),
                                    'label' => __('Heading', TL_INSERT_STAFF_SLUG),
                                    'id' => $this->get_layers_field_id('heading'),
                                    'value' => (isset($widget['heading'])) ? $widget['heading'] : NULL,
                                    'class' => 'layers-text layers-large'
                                )
                            ); ?>
                        </p>

                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('excerpt')); ?>"><?php _e('Excerpt', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'rte',
                                    'name' => $this->get_layers_field_name('excerpt'),
                                    'id' => $this->get_layers_field_id('excerpt'),
                                    'label' => __('Description', TL_INSERT_STAFF_SLUG),
                                    'value' => (isset($widget['excerpt'])) ? $widget['excerpt'] : NULL,
                                    'class' => 'layers-textarea layers-large'
                                )
                            ); ?>
                        </p>

                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('page_id')); ?>"><?php _e('Pick an existing link for button', TL_INSERT_STAFF_SLUG); ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'select',
                                    'name' => $this->get_layers_field_name('page_id'),
                                    'id' => $this->get_layers_field_id('page_id'),
                                    'value' => (isset($widget['page_id'])) ? $widget['page_id'] : NULL,
                                    'options' => tl_get_posts(array('post_type' => 'page')),
                                    'placeholder' => __('-- None --', TL_INSERT_STAFF_SLUG),
                                    'class' => 'layers-select layers-large tl-select-post-item',
                                )
                            ); ?>
                            <small class="layers-small-note">Link the button to an existing page.</small>
                        </p>
                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('link_label'))?>"><?php _e('Button Label', TL_INSERT_STAFF_SLUG) ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'text',
                                    'name' => $this->get_layers_field_name('link_label'),
                                    'id' => $this->get_layers_field_id('link_label'),
                                    'value' => (isset($widget['link_label'])) ? $widget['link_label'] : NULL,
                                    'placeholder' => __('Button Label', TL_INSERT_STAFF_SLUG),
                                    'class' => 'layers-text tl-select-post-item',
                                )
                            ); ?>
                        </p>

                        <p class="layers-form-item">
                            <label for="<?php echo esc_attr($this->get_layers_field_id('custom_link'))?>"><?php _e('Button Link', TL_INSERT_STAFF_SLUG) ?></label>
                            <?php echo $this->form_elements()->input(
                                array(
                                    'type' => 'text',
                                    'name' => $this->get_layers_field_name('custom_link'),
                                    'id' => $this->get_layers_field_id('custom_link'),
                                    'value' => (isset($widget['custom_link'])) ? $widget['custom_link'] : NULL,
                                    'placeholder' => 'http://',
                                    'class' => 'layers-text tl-select-post-item',
                                )
                            ); ?>
                            <small class="layers-small-note"><?php _e('This value is overwritten if page selected from dropdown box.', TL_INSERT_STAFF_SLUG); ?></small>
                        </p>
                        <ul class="layers-accordions layers-accordions-sortable layers-sortable layers-visuals-wrapper">
                            <li class="layers-accordion-item layers-visuals-item">
                                <a class="layers-accordion-title">
                                    <span><?php _e('Icon settings', TL_INSERT_STAFF_SLUG); ?></span>
                                </a>
                                <section class="layers-accordion-section layers-content">
                                    <div class="layers-form-item layers-span-6">
                                        <div class="layers-checkbox-wrapper layers-form-item">
                                            <?php echo $this->form_elements()->input(
                                                array(
                                                    'type' => 'checkbox',
                                                    'label' => __('Move Icon to the right', TL_INSERT_STAFF_SLUG),
                                                    'name' => $this->get_layers_field_name('icon_pull_right'),
                                                    'id' => $this->get_layers_field_id('icon_pull_right'),
                                                    'value' => (isset($widget['icon_pull_right'])) ? $widget['icon_pull_right'] : null,
                                                    'class' => 'layers-span-6'
                                                )
                                            ); ?>
                                        </div>
                                        <small class="layers-small-note">Check option to move icon to the right</small>
                                    </div>
                                    <div class="layers-select-icons-wrapper layers-form-item">
                                        <?php echo $this->form_elements()->input(
                                            array(
                                                'type' => 'button',
                                                'label' => __('Select an Icon', TL_INSERT_STAFF_SLUG),
                                                'name' => $this->get_layers_field_name('icon_btn'),
                                                'id' => $this->get_layers_field_id('icon_btn'),
                                                'value' => (isset($widget['icon_btn'])) ? $widget['icon_btn'] : null,
                                                'class' => 'expand-icons all-icons'
                                            )
                                        ); ?>
                                        <div class="layers-hidden-wrapper layers-form-item ">
                                            <?php echo $this->form_elements()->input(
                                                array(
                                                    'type' => 'hidden',
                                                    'label' => __('Select an Icon', TL_INSERT_STAFF_SLUG),
                                                    'name' => $this->get_layers_field_name('icon'),
                                                    'id' => $this->get_layers_field_id('icon'),
                                                    'value' => (isset($widget['icon'])) ? $widget['icon'] : null,
                                                    'class' => 'expand-icons all-icons')
                                            ); ?>
                                        </div>
                                    </div>
                                </section>
                            </li>
                        </ul>
                        <!-- Icon Settings End -->
                    </div>
                </section>
            </div>
            <?php
            if (TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_end_flush();
        } // Form



        protected function _addFilters()
        {
            add_filter('tl/layers/background_component/' . $this->widget_id . '/args', array($this, 'customizeBackgroundComponent'), 10, 4);
            add_filter('tl/layers/fonts_component/' . $this->widget_id . '/args', array($this, 'customizeFontsComponent'), 10, 4);
            add_filter('tl/layers/buttons_component/' . $this->widget_id . '/args', array($this, 'customizeButtonsComponent'), 10, 4);
        }


        /**
         * @param $args
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeFontsComponent($args, $position, $widget, $values)
        {

            //Add at the beggining of the array
            $args['elements'] = array('fonts-title-heading' => array('type' => 'layers-heading', 'label' => 'Title Options')) + $args['elements'];


            $args['elements']['fonts-excerpt-heading'] = array(
                'type' => 'layers-heading',
                'label' => 'Excerpt Options',
            );

            $args['elements']['fonts-excerpt-align'] = array(
                'type' => 'select-icons',
                'label' => __('Text Align', 'layerswp'),
                'name' => $widget['name'] . '[fonts][excerpt-align]',
                'id' => $widget['id'] . '-fonts-excerpt-align',
                'value' => (isset($values['fonts']['excerpt-align'])) ? $values['fonts']['excerpt-align'] : NULL,
                'options' => array(
                    'text-left' => __('Left', 'layerswp'),
                    'text-center' => __('Center', 'layerswp'),
                    'text-right' => __('Right', 'layerswp'),
                    'text-justify' => __('Justify', 'layerswp')
                ),
                'wrapper' => 'div',
                'wrapper-class' => 'layers-icon-group'
            );

            $args['elements']['fonts-excerpt-size'] = array(
                'type' => 'select',
                'label' => __('Text Size', 'layerswp'),
                'name' => $widget['name'] . '[fonts][excerpt-size]',
                'id' => $widget['id'] . '-fonts-excerpt-size',
                'value' => (isset($values['fonts']['excerpt-size'])) ? $values['fonts']['excerpt-size'] : NULL,
                'options' => array(
                    'small' => __('Small', 'layerswp'),
                    'medium' => __('Medium', 'layerswp'),
                    'large' => __('Large', 'layerswp')
                )
            );

            $args['elements']['fonts-excerpt-color'] = array(
                'type' => 'color',
                'label' => 'Excerpt Color',
                'name' => $widget['name'] . '[fonts][excerpt-color]',
                'id' => $widget['id'] . '-fonts-excerpt-color',
                'value' => isset($values['fonts']['excerpt-color']) ? $values['fonts']['excerpt-color'] : null,
            );

            return $args;
        }


        /**
         * @param array $args
         * @param string $position (side|)
         * @param array $widget
         * @param array $values
         * @return mixed
         */
        public function customizeBackgroundComponent($args, $position, $widget, $values)
        {
            unset($args['elements']['background-darken']);
            $args['elements']['background-overlay'] = array(
                'type' => 'checkbox',
                'label' => __('Background Overlay', TL_INSERT_STAFF_SLUG),
                'name' => $widget['name'] . '[background][overlay]',
                'id' => $widget['id'] . '-background-overlay',
                'value' => (isset($values['background']['overlay'])) ? $values['background']['overlay'] : NULL,
            );
            return $args;
        }


        /**
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeButtonsComponent($args, $position, $widget, $values)
        {
            if ($position == 'side') {
                //unset($args['elements']['buttons-size']);
                unset($args['elements']['buttons-label']);
                unset($args['elements']['buttons-align']);

                $args['elements']['buttons-push-left'] = array(
                    'type' => 'checkbox',
                    'label' => __('Push button to the left',TL_INSERT_STAFF_SLUG),
                    'name' => $widget['name'] . '[buttons][push-left]',
                    'id' => $widget['id'] . '-buttons-push-left',
                    'value' => (isset($values['buttons']['push-left'])) ? $values['buttons']['push-left'] : NULL,
                );
            }

            return $args;
        }


        /**
         *
         */
        protected function _loadIcons()
        {
            global $tl_icons, $awesome_icons;
            $icons = '';

            require_once 'icons.php';
            require_once 'awesome-icons.php';

            foreach ($tl_icons as $class) {
                $icons[$class] = '';
            }

            foreach ($awesome_icons as $class) {
                $icons[$class] = '';
            }

            /*wp_enqueue_style(
                TL_THEME_SLUG . '-flaticons',
                parent::asset_path('css/themify-icons.min.css', false, true),
                array(),
                TL_THEME_VER
            );*/

            return $icons;
        }


        /**
         * @param $class
         * @return bool
         */
        protected function _isAwesomeIcon($class)
        {
            return strpos($class, 'fa-') === 0;
        }


    } // Class

    // Add our function to the widgets_init hook.
    register_widget("TL_Layers_Promotional_Widget");
}