<?php
/**
 * Adds the woocommerce settings tab
 * @author: createIT
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists( 'ctWooVideoSettings' ) ) :

class ctWooVideoSettings extends WC_Settings_Page {

    /**
     * Constructor
     */

    public function __construct() {

        $this->id    = 'ct_woovideo';
        $this->label = __( 'CT Videos', 'ct-woovideo' );

        add_filter( 'woocommerce_settings_tabs_array', array( $this, 'add_settings_page' ), 1000 );
        add_action( 'woocommerce_settings_' . $this->id , array( $this, 'output' ) );
        add_action( 'woocommerce_settings_save_' . $this->id, array( $this, 'save' ), 1 );
        add_action( 'woocommerce_sections_' . $this->id, array( $this, 'output_sections' ) );
    }

    /**
     * Get sections
     *
     * @return array
     */

    public function get_sections() {

        $sections = array(
            ''          	=> __( 'Video settings', 'ct-woovideo' ),
            'button'       => __( 'Popup Button settings', 'ct-woovideo' ),
            'add_video' 	=> __( 'Add video to product list', 'ct-woovideo' ),
        );

        return apply_filters( 'woocommerce_get_sections_' . $this->id, $sections );
    }

    /**
     * Output the settings
     */

    public function output()
    {

        global $current_section;

        $settings = $this->get_settings( $current_section );

        WC_Admin_Settings::output_fields( $settings );

    }

    /**
     * Save settings
     */
    public function save() {
        global $current_section;

        $settings = $this->get_settings( $current_section );

        WC_Admin_Settings::save_fields( $settings );
    }

    /**
     * Gets settings array
     * @return mixed|void
     */

    public function get_settings($current_section = '')
    {

        if ('button' == $current_section) {

            $settings = apply_filters('wc_ct_woovideo_button_settings', array(
                array(
                    'title' => __('Popup button default settings', 'ct-woovideo'),
                    'type'  => 'title',
                    'id'    => 'wc_ct_woovideo_button_settings'
                ),
                array(
                    'name'    => __('Popup Button Location', 'ct-woovideo'),
                    'desc'    => __('Choose the default popup button location', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_location',
                    'type'    => 'select',
                    'class'   => 'chosen_select',
                    'css'     => 'min-width:300px;',
                    'std'     => 'above_tabs',
                    'default' => 'above_tabs',
                    'options' => array(
                        'after_add_to_cart_button' => __("After 'Add to Cart' Button", 'ct-woovideo'),
                        'after_product_info'       => __('After Product Info', 'ct-woovideo'),
                        'product_gallery'          => __('Under the Product Gallery', 'ct-woovideo'),
                        'above_tabs'               => __('Above the Product Summary Tabs', 'ct-woovideo'),
                        'tab'                      => __("Inside the 'Videos' tab", 'ct-woovideo'),
                        'shortcode'                => __('Shortcode', 'ct-woovideo')
                    ),
                ),
                array(
                    'name'    => __( 'Location priority', 'ct-woovideo' ),
                    'desc'    => __( 'Set to zero for auto positioning', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_button_location_priority',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 100,
                ),
                array(
                    'name'    => __('Button Label', 'ct-woovideo'),
                    'desc'    => __('Choose the default popup button label', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_label',
                    'type'    => 'select',
                    'class'   => 'chosen_select',
                    'css'     => 'min-width:300px;',
                    'std'     => 'custom',
                    'default' => 'custom',
                    'options' => array(
                        'title' => __('Video Title', 'ct-woovideo'),
                        'thumbnail' => __('Thumbnail', 'ct-woovideo'),
                        'custom' => __('Custom', 'ct-woovideo')
                    ),
                ),
                array(
                    'name'    => __('Custom button label', 'ct-woovideo'),
                    'desc'    => __('Enter a custom button label', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_custom_button_label',
                    'css'     => 'min-width:300px;',
                    'type'    => 'text',
                    'default' => 'Video',
                    'std'     => 'Video',
                    'class'   => 'ct-woovideo-setting'
                ),
                array(
                    'name'    => __('Button color', 'ct-woovideo'),
                    'desc'    => __('Set the button background color', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_color',
                    'css'     => 'max-width:60px;',
                    'type'    => 'color',
                    'default' => '000000',
                ),
                array(
                    'name'    => __('Button text color', 'ct-woovideo'),
                    'desc'    => __('Set the button text color', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_text_color',
                    'css'     => 'max-width:60px;',
                    'type'    => 'color',
                    'default' => 'ffffff',
                ),
                array(
                    'name'    => __('Button align', 'ct-woovideo'),
                    'desc'    => __('To which side the button should float?', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_align',
                    'type'    => 'select',
                    'class'   => 'chosen_select',
                    'css'     => 'max-width:80px;',
                    'std'     => 'left',
                    'default' => 'left',
                    'options' => array(
                        'left' => __('Left', 'ct-woovideo'),
                        'right'=> __('Right', 'ct-woovideo'),
                        'none' => __('None', 'ct-woovideo'),
                    ),
                ),
                array(
                    'name'    => __('Button clearing', 'ct-woovideo'),
                    'desc'    => __('Allow floating elements on the sides of the button?', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_clearing',
                    'type'    => 'select',
                    'class'   => 'chosen_select',
                    'css'     => 'max-width:80px;',
                    'std'     => 'no',
                    'default' => 'no',
                    'options' => array(
                        'on' => __('Yes', 'ct-woovideo'),
                        'no' => __('No', 'ct-woovideo'),
                    ),
                ),
                array(
                    'name'    => __('Button class', 'ct-woovideo'),
                    'desc'    => __('Add a custom class to the button', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_class',
                    'type'    => 'text',
                    'default' => '',
                    'std'     => ''
                ),
                array(
                    'name'    => __('Margin left', 'ct-woovideo'),
                    'desc'    => __('Enter the left margin of the button', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_margin_left',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                array(
                    'name'    => __('Margin top', 'ct-woovideo'),
                    'desc'    => __('Enter the top margin of the button', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_margin_top',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                array(
                    'name'    => __('Margin right', 'ct-woovideo'),
                    'desc'    => __('Enter the right margin of the button', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_margin_right',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                array(
                    'name'    => __('Margin bottom', 'ct-woovideo'),
                    'desc'    => __('Enter the bottom margin of the button', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_margin_bottom',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                array(
                    'name'    => __('Padding left', 'ct-woovideo'),
                    'desc'    => __('Enter the left padding of the content in the popup window', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_padding_left',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 10,
                ),
                array(
                    'name'    => __('Padding top', 'ct-woovideo'),
                    'desc'    => __('Enter the top padding of the content in the popup window', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_padding_top',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 5,
                ),
                array(
                    'name'    => __('Padding right', 'ct-woovideo'),
                    'desc'    => __('Enter the right padding of the content in the popup window', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_padding_right',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 10,
                ),
                array(
                    'name'    => __('Padding bottom', 'ct-woovideo'),
                    'desc'    => __('Enter the bottom padding of the content in the popup window', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_padding_bottom',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 5,
                ),
                array(
                    'name'    => __('Height', 'ct-woovideo'),
                    'desc'    => __('Enter the height for button with label set to thumbnail', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_height',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 100,
                ),
                array(
                    'name'    => __('Width', 'ct-woovideo'),
                    'desc'    => __('Enter the width for button with label set to thumbnail', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_width',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 100,
                ),
                array(
                    'name'    => __('Border radius', 'ct-woovideo'),
                    'desc'    => __('Set the border radius for rounded corners', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_button_border_radius',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 5,
                ),
                array(
                    'name'    => __('Popup overlay color', 'ct-woovideo'),
                    'desc'    => __('Click to pick the color of the popup background overlay', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_overlay_color',
                    'css'     => 'max-width:60px;',
                    'type'    => 'color',
                    'default' => '000000',
                ),
                'section_end' => array(
                    'type' => 'sectionend',
                    'id'   => 'wc_ct_woovideo_button_settings'
                )

            ));

        } elseif('add_video' == $current_section) {

            $settings = apply_filters( 'wc_ct_woovideo_list_video_settings', array(

                array(
                    'name' => __( 'Add video on top of the product list', 'ct-woovideo' ),
                    'type' => 'title',
                    'id'   => 'wc_ct_woovideo_add_video_to_list',
                ),
                array(
                    'name'      => __('Generic iframe url', 'ct-woovideo'),
                    'desc_tip'  => __('Make sure to embed only from trusted sources.', 'ct-woovideo'),
                    'id'        => 'wc_ct_woovideo_list_iframe_url',
                    'css'       => 'min-width:400px;',
                    'type'      => 'text',
                    'class'     =>  'ct-woovideo-setting ct-woovideo-list-iframe-setting'
                ),
                array(
                    'name'      => __('Enter external video url', 'ct-woovideo'),
                    'desc_tip'  => __('Youtube, Vimeo etc.', 'ct-woovideo'),
                    'id'        => 'wc_ct_woovideo_list_video_external_url',
                    'css'       => 'min-width:400px;',
                    'type'      => 'text',
                    'class'     => 'ct-woovideo-setting'
                ),
                array(
                    'name'  => __('Upload .mp4 video', 'ct-woovideo'),
                    'desc'  => (get_option('wc_ct_woovideo_list_video_mp4_url')) ? esc_html(basename(wp_get_attachment_url(get_option('wc_ct_woovideo_list_video_mp4_url')))) : ' ',
                    'id'    => 'wc_ct_woovideo_list_video_mp4_url',
                    'class' => 'ct-woovideo-settings-upload-video',
                    'type'  => 'text',
                ),
                array(
                    'name'  => __('Upload .webm video', 'ct-woovideo'),
                    'desc'  => (get_option('wc_ct_woovideo_list_video_webm_url')) ? esc_html(basename(wp_get_attachment_url(get_option('wc_ct_woovideo_list_video_webm_url')))) : ' ',
                    'id'    => 'wc_ct_woovideo_list_video_webm_url',
                    'class' => 'ct-woovideo-settings-upload-video',
                    'type'  => 'text',
                ),
                array(
                    'name'  => __('Upload .ogg video', 'ct-woovideo'),
                    'desc'  => (get_option('wc_ct_woovideo_list_video_ogg_url')) ? esc_html(basename(wp_get_attachment_url(get_option('wc_ct_woovideo_list_video_ogg_url')))) : ' ',
                    'id'    => 'wc_ct_woovideo_list_video_ogg_url',
                    'class' => 'ct-woovideo-settings-upload-video',
                    'type'  => 'text',
                ),
                array(
                    'name'    => __( 'Video class', 'ct-woovideo' ),
                    'desc'    => __( 'Add a custom class to the video', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_list_video_class',
                    'type'    => 'text',
                    'default' => '',
                    'std'     => '',
                ),
                array(
                    'name'    => __('Autoplay', 'ct-woovideo'),
                    'desc'    => __('Enable autoplay?', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_list_video_autoplay',
                    'type'    => 'select',
                    'class'   => 'chosen_select',
                    'css'     => 'max-width:80px;',
                    'std'     => 'on',
                    'default' => 'on',
                    'options' => array(
                        'on' => __('Yes', 'ct-woovideo'),
                        'no' => __('No', 'ct-woovideo'),
                    ),
                ),
                array(
                    'name'     => __( 'Video (max) height', 'ct-woovideo' ),
                    'desc'     => __( 'Set the videos maximum height', 'ct-woovideo' ),
                    'id'       => 'wc_ct_woovideo_list_player_height',
                    'class'    => 'ct-woovideo-list-player-height',
                    'css'      => 'max-width:60px;',
                    'type'     => 'number',
                    'default'  => 0,
                    'desc_tip' => __( 'Set to zero for auto scaling', 'ct-woovideo' ),
                ),
                array(
                    'name'     => __( 'Video (max) width', 'ct-woovideo' ),
                    'desc'     => __( 'Set the videos maximum width', 'ct-woovideo' ),
                    'id'       => 'wc_ct_woovideo_list_player_width',
                    'class'    => 'ct-woovideo-list-player-width',
                    'css'      => 'max-width:60px;',
                    'type'     => 'number',
                    'default'  => 0,
                    'desc_tip' => __( 'Set to zero for auto scaling', 'ct-woovideo' ),
                ),
                array(
                    'name'    => __( 'Video margin left', 'ct-woovideo' ),
                    'desc'    => __( 'Left margin of the video', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_list_video_margin_left',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                array(
                    'name'    => __( 'Video margin top', 'ct-woovideo' ),
                    'desc'    => __( 'Top margin of the video', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_list_video_margin_top',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                array(
                    'name'    => __( 'Video margin right', 'ct-woovideo' ),
                    'desc'    => __( 'Right margin of the video', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_list_video_margin_right',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                array(
                    'name'    => __( 'Video margin bottom', 'ct-woovideo' ),
                    'desc'    => __( 'Bottom margin of the video', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_list_video_margin_bottom',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                'section_end' => array(
                    'type' => 'sectionend',
                    'id'   => 'wc_ct_woovideo_add_video_to_list'
                )
            ));

        } else {

            $settings = apply_filters( 'wc_ct_woovideo_video_settings', array(

                array(
                    'name' => __( 'Video default settings', 'ct-woovideo' ),
                    'type' => 'title',
                    'id'   => 'wc_ct_woovideo_video_settings'
                ),
                array(
                    'name'     => __('Generic iframe', 'ct-woovideo'),
                    'desc'     => __('Enable generic iframe?', 'ct-woovideo'),
                    'desc_tip' => __('When enabled, you can embed any other page into an iframe. Make sure to embed only from trusted sources.', 'ct-woovideo'),
                    'id'       => 'wc_ct_woovideo_iframe_enabled',
                    'type'     => 'select',
                    'class'    => 'chosen_select',
                    'css'      => 'max-width:80px;',
                    'std'      => 'no',
                    'default'  => 'no',
                    'options'  => array(
                        'on' => __('Yes', 'ct-woovideo'),
                        'no' => __('No', 'ct-woovideo'),
                    ),
                ),
                array(
                    'name'    => __( 'Video Location', 'ct-woovideo' ),
                    'desc'    => __( 'Choose the default video location', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_location',
                    'type'    => 'select',
                    'class'   => 'chosen_select',
                    'css'     => 'min-width:300px;',
                    'default' => 'tab',
                    'options' => array(
                        'tab'           => __( 'Tab', 'ct-woovideo' ),
                        'image_gallery' => __( 'Image Gallery', 'ct-woovideo' ),
                        'button'        => __( 'Popup Button', 'ct-woovideo' ),
                        'shortcode'     => __( 'Shortcode', 'ct-woovideo' )
                    ),
                ),
                array(
                    'name'    => __('Gallery Videos Location', 'ct-woovideo'),
                    'desc'    => __('Choose where the gallery videos will display', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_gallery_location',
                    'type'    => 'select',
                    'class'   => 'chosen_select',
                    'css'     => 'min-width:300px;',
                    'std'     => 'above',
                    'default' => 'in',
                    'options' => array(
                        'above' => __('Above Product', 'ct-woovideo'),
                        'in' => __('Instead of Main Image', 'ct-woovideo'),
                    ),
                ),
                array(
                    'name'     => __( 'Location priority', 'ct-woovideo' ),
                    'desc_tip' => __( 'Set to zero for auto positioning', 'ct-woovideo' ),
                    'desc'     => __( 'Position the video in relation to other page elements', 'ct-woovideo' ),
                    'id'       => 'wc_ct_woovideo_video_location_priority',
                    'css'      => 'max-width:60px;',
                    'type'     => 'number',
                    'default'  => 100,
                ),
                array(
                    'name'    => __( 'Video class', 'ct-woovideo' ),
                    'desc'    => __( 'Add a custom class to the video', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_video_class',
                    'type'    => 'text',
                    'default' => '',
                    'std'     => '',
                ),
                array(
                    'name'     => __( 'Video max height', 'ct-woovideo' ),
                    'desc'     => __( 'Set the videos maximum height', 'ct-woovideo' ),
                    'id'       => 'wc_ct_woovideo_player_height',
                    'css'      => 'max-width:60px;',
                    'class'    => 'ct-woovideo-setting',
                    'type'     => 'number',
                    'default'  => 0,
                    'desc_tip' => __( 'Set to zero for auto scaling', 'ct-woovideo' ),
                ),
                array(
                    'name'     => __( 'Video max width', 'ct-woovideo' ),
                    'desc'     => __( 'Set the videos maximum width', 'ct-woovideo' ),
                    'id'       => 'wc_ct_woovideo_player_width',
                    'css'      => 'max-width:60px;',
                    'type'     => 'number',
                    'default'  => 0,
                    'desc_tip' => __( 'Set to zero for auto scaling', 'ct-woovideo' ),
                ),
                array(
                    'name'     => __('Autoplay', 'ct-woovideo'),
                    'desc'     => __('Enable autoplay?', 'ct-woovideo'),
                    'desc_tip' => __('Video will play when page is loaded or when the button is clicked', 'ct-woovideo'),
                    'id'       => 'wc_ct_woovideo_video_autoplay',
                    'type'     => 'select',
                    'class'    => 'chosen_select',
                    'css'      => 'max-width:80px;',
                    'std'      => 'no',
                    'default'  => 'no',
                    'options'  => array(
                        'on' => __('Yes', 'ct-woovideo'),
                        'no' => __('No', 'ct-woovideo'),
                    ),
                ),
                array(
                    'name'     => __( 'Video align', 'ct-woovideo' ),
                    'desc'     => __('To which side the video should float?', 'ct-woovideo'),
                    'desc_tip' => __( 'Set to none for auto positioning', 'ct-woovideo' ),
                    'id'       => 'wc_ct_woovideo_video_align',
                    'type'     => 'select',
                    'class'    => 'chosen_select',
                    'css'      => 'max-width:80px;',
                    'std'      => 'none',
                    'default'  => 'none',
                    'options'  => array(
                        'none'  => __( 'None', 'ct-woovideo' ),
                        'left'  => __( 'Left', 'ct-woovideo' ),
                        'right' => __( 'Right', 'ct-woovideo' ),
                    ),
                ),
                array(
                    'name'    => __( 'Video clearing', 'ct-woovideo' ),
                    'desc'    => __( 'Allow floating elements on the sides of the video?', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_video_clearing',
                    'type'    => 'select',
                    'class'   => 'chosen_select',
                    'css'     => 'max-width:80px;',
                    'std'     => 'no',
                    'default' => 'no',
                    'options' => array(
                        'on'  => __( 'Yes', 'ct-woovideo' ),
                        'no'  => __( 'No', 'ct-woovideo' ),
                    ),
                ),
                array(
                    'name'    => __( 'Video margin left', 'ct-woovideo' ),
                    'desc'    => __( 'Enter the left margin of the video', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_video_margin_left',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                array(
                    'name'    => __( 'Video margin top', 'ct-woovideo' ),
                    'desc'    => __( 'Enter the top margin of the video', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_video_margin_top',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                array(
                    'name'    => __( 'Video margin right', 'ct-woovideo' ),
                    'desc'    => __( 'Enter the right margin of the video', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_video_margin_right',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                array(
                    'name'    => __( 'Video margin bottom', 'ct-woovideo' ),
                    'desc'    => __( 'Enter the bottom margin of the video', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_video_margin_bottom',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 0,
                ),
                array(
                    'name'    => __( 'Thumbnail icon', 'ct-woovideo' ),
                    'desc'    => __( 'Choose icon to appear on video thumbnails', 'ct-woovideo' ),
                    'id'      => 'wc_ct_woovideo_select_icon',
                    'type'    => 'radio',
                    'class'   => 'ct-woovideo-settings-icon',
                    'std'     => 'play-circle-o',
                    'default' => 'play-circle-o',
                    'options' => apply_filters('wc_ct_woovideo_icons', array(
                        'file-video'    => __( '<img src="' . CT_WOOVIDEO_ASSETS . '/images/file-video.png' . '"/>', 'ct-woovideo' ),
                        'film'          => __( '<img src="' . CT_WOOVIDEO_ASSETS . '/images/film.png' . '"/>', 'ct-woovideo' ),
                        'play-circle'   => __( '<img src="' . CT_WOOVIDEO_ASSETS . '/images/play-circle.png' . '"/>', 'ct-woovideo' ),
                        'play-circle-o' => __( '<img src="' . CT_WOOVIDEO_ASSETS . '/images/play-circle-o.png' . '"/>', 'ct-woovideo' ),
                        'video-camera'  => __( '<img src="' . CT_WOOVIDEO_ASSETS . '/images/video-camera.png' . '"/>', 'ct-woovideo' ),
                        'youtube-play'  => __( '<img src="' . CT_WOOVIDEO_ASSETS . '/images/youtube-play.png' . '"/>', 'ct-woovideo' ),
                        'none'          => __( 'none', 'ct-woovideo' )
                    ), CT_WOOVIDEO_ASSETS),
                ),
                array(
                    'name'    => __('Icon size', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_icon_size',
                    'css'     => 'max-width:60px;',
                    'type'    => 'number',
                    'default' => 80,
                ),
                array(
                    'name'    => __('Icon position in thumbnail', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_icon_position',
                    'css'     => 'max-width:200px;',
                    'type'    => 'select',
                    'std'     => 'center',
                    'default' => 'center',
                    'options' => array(
                        'center'       => __( 'Center', 'ct-woovideo' ),
                        'top_left'     => __( 'Top left corner', 'ct-woovideo' ),
                        'top_right'    => __( 'Top right corner', 'ct-woovideo' ),
                        'bottom_left'  => __( 'Bottom left corner', 'ct-woovideo' ),
                        'bottom_right' => __( 'Bottom right corner', 'ct-woovideo' )
                    ),
                ),
                array(
                    'name'    => __('Icon opacity level', 'ct-woovideo'),
                    'id'      => 'wc_ct_woovideo_icon_opacity',
                    'type'    => 'select',
                    'default' => '5',
                    'std'     => '5',
                    'options' => array(
                        '0' => __('0', 'ct-woovideo'),
                        '1' => __('1', 'ct-woovideo'),
                        '2' => __('2', 'ct-woovideo'),
                        '3' => __('3', 'ct-woovideo'),
                        '4' => __('4', 'ct-woovideo'),
                        '5' => __('5', 'ct-woovideo'),
                        '6' => __('6', 'ct-woovideo'),
                        '7' => __('7', 'ct-woovideo'),
                        '8' => __('8', 'ct-woovideo'),
                        '9' => __('9', 'ct-woovideo'),
                    ),
                ),
                array(
                    'type' => 'sectionend',
                    'id'   => 'wc_ct_woovideo_video_settings'
                ),
            ));

        }


        return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings, $current_section );
    }


}

endif;

new ctWooVideoSettings;
