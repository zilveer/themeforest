<?php
/**
 * @package WordPress
 * @subpackage Geode
 * @since Geode 1.0
 */

get_header(); ?>

<?php get_template_part( 'title', 'page' ); ?>
	<div id="primary" class="site-content cf">
		<div id="content" role="main">

			<div class="row">
				<div class="row-inside">
					<div class="sc-grid cf" <?php do_action('geode_loop_product_data'); ?>>
						<?php if ( have_posts() ) :

							while ( have_posts() ) : the_post();

								sc_get_template_part( 'content', 'standard' );

							endwhile;

						else :
							sc_get_template_part( 'content', 'standard' );

						endif; ?>
					</div><!-- .sc-grid -->
				</div><!-- .row-inside -->
			</div><!-- .row -->
		</div><!-- #content -->
	</div><!-- #primary.site-content -->
<?php get_footer(); ?>