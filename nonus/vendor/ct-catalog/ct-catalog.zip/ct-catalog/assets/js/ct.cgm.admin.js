(function($){
    "use strict";
    $(document).ready(function() {

        var $toggle = $("[data-toggle]");
        $toggle.each(function(){
            var $this = $(this);
            var $isChecked = $this.attr("checked");
            if($isChecked != "checked"){
                $("." + $this.data('toggle')).closest('tr').toggle();
            }
        });

        $($toggle).click(function(){
            var $this = $(this);
            $("." + $this.data('toggle')).closest('tr').toggle();
        })

    });
}(jQuery))
