<div class="my_meta_control">
	<p class="my_meta_p">
    	<strong>Autoplay Slideshow?</strong>
		<?php 
			$mb->the_field('alchemy_autoplay');
			if(!($mb->get_the_value()))
			{
				$mb->the_checkbox_state = 'checked';
			}
		?>
		<input type="checkbox" name="<?php $mb->the_name(); ?>" value="yes"<?php $mb->the_checkbox_state('yes'); ?>/><br/>
	</p>
	<p class="my_meta_p">
    	<strong>Play slideshow even when mouse is over?</strong>
		<?php 
			$mb->the_field('alchemy_hover');
			if(!($mb->get_the_value()))
			{
				$mb->the_checkbox_state = 'checked';
			}
		?>
		<input type="checkbox" name="<?php $mb->the_name(); ?>" value="yes"<?php $mb->the_checkbox_state('yes'); ?>/><br/>
	</p>
    	<p class="my_meta_p">
            <strong>&nbsp;Slideshow delay in miliseconds:</strong> (Optional)
            <?php $mb->the_field('alchemy_full_delay'); ?><br />
            <input type="text" name="<?php $mb->the_name(); ?>" value="<?php $mb->the_value(); ?>" size="5" style="width:100px"/>
        </p>
    	<p>
    		<?php
        	$control_options = array(
    			'bullets' => array(
    			'value' => 'bullets',
    			'label' => __( 'Dots', 'samba_lang' )
    			),
    			'arrows' => array(
    			'value' => 'arrows',
    			'label' => __( 'Arrows', 'samba_lang' )
    			));
    			$mb->the_field('controls_type'); 
    			?>
    			<label for="controls_type" class="small_label">Slider navigation controls?</label>
    			<select id="" name="<?php $metabox->the_name(); ?>">
    				<?php   
    				foreach ( $control_options as $sld_size_option ) 
    				{
    					$label = $sld_size_option['label'];
    					if ( $metabox->get_the_value() == $sld_size_option['value'] ) // Make default first in list
    						echo "\n\t<option selected='selected' value='" . esc_attr( $sld_size_option['value'] ) . "'>$label</option>";
    					else
    						echo "\n\t<option value='" . esc_attr( $sld_size_option['value'] ) . "'>$label</option>";
    				}
    				?>
    			</select>
    	</p>
        <?php 
			//FLAG TO KNOW WHEN WE ARE GOING THROUGH THE GROUPS
			$mb->the_field('helper_fk');
		?>
        <input type="hidden" name="<?php $mb->the_name(); ?>" value="weirdostf"/><br/>		
        <?php
        	$terms=get_terms('pirenko_slide_set');
			$count = count($terms);
			if ($count>0)
			{   
				echo "<div class='btm_12'><span class='prk_alt_opt'>Groups to be displayed on this page:</span> (Leave blank for all)<br /><table>";
            	foreach ( $terms as $term ) { 
					$mb->the_field($term->slug);
					echo "<tr><td>";
					echo $term->name;
					echo "</td>";echo "<td>";
					?>
                    <input type="checkbox" name="<?php $mb->the_name(); ?>" value="<?php echo $term->slug; ?>"<?php echo $mb->is_value($term->slug)?' checked="checked"':''; ?>/>
                    </td></tr>
                    <?php
              	}
				echo "</table><div class='clear'></div></div>";
			}
		?>
</div>

