<?php  
// Plain Hero, no images and stuff
class Wish_Projects_Slider {

        var $shortcode = 'wish_projects_slider';
        var $title = "Projects Slider";
        var $details = "Shows Projects as massive slider";
        //var $path = "/templates/rating_hero.php";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link"  => "http://i.imgur.com/hOcfJTx.png",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'wish'),
            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor
            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
            "params" => array(


                            array(
                                "type" => "dropdown",
                                "heading" => __("Max Items", "wish"),
                                "param_name" => "max_items",
                                "description" => __("Maximum Number Of Portfolio Items to show.", "wish"),
                                "value" => array( 
                                                  "4"     => "4",
                                                  "5"     => "5",
                                                  "8"     => "8",
                                                  "10"     => "10",
                                                  "12"     => "12",
                                                  "16"     => "16",
                                                  "20"     => "20",
                                                ),
                                "std"       =>   10,
                            ),

                            /*Title*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __( "Title Text Font", "wish" ),
                                "param_name" => "title_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Title Size", "wish"),
                                "param_name" => "title_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("60", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Title Text Color", "wish" ),
                                "param_name" => "title_color",
                                "value" => '#fff ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),


                            /*Heading*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __( "Heading Text Font", "wish" ),
                                "param_name" => "heading_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Heading Size", "wish"),
                                "param_name" => "heading_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("18", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Heading Text Color", "wish" ),
                                "param_name" => "heading_color",
                                "value" => '#fff', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),


                            /*Info*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __( "Info Text Font", "wish" ),
                                "param_name" => "info_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Info Size", "wish"),
                                "param_name" => "info_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("16", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Info Text Color", "wish" ),
                                "param_name" => "info_color",
                                "value" => '#fff', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),





                    )

        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title_font'   => '',
        'title_size'   => '60',
        'title_color'  => '#fff',

        'heading_font'  => '',
        'heading_size'  => '18',
        'heading_color' => '#fff',

        'info_font'   => '',
        'info_size'   => '16',
        'info_color'  => '#fff',      

        'sub_title'    => 'sub_title',
        "max_items"    => "",
      ), $atts ) );


        wp_enqueue_script('wish-flex-js', plugins_url('assets/flex-slider/jquery.flexslider.js', __FILE__), array('jquery') );
        wp_enqueue_script('wish-flex-custom', plugins_url('assets/flex-slider/flexslider.js', __FILE__), array('jquery') );

        //in progress
        $args = array(
          'post_type' => 'wish_projects',
          'posts_per_page'  => $max_items,
        );

        $proj_query = new WP_Query( $args );


         /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Heading*/
        $decode_font = urldecode($heading_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $heading_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Info*/
        $decode_font = urldecode($info_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $info_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


                // $ctax = get_terms('projects_categories');
                // $tarray = array();
                // foreach($ctax as $tkey=>$tvalue){
                //         $tarray[$tvalue->slug] =  $tvalue->name;
                // }

                        
      $output = "<div class='container-fluid portfolio-1'>
                    <div class='flexslider row no-gutter-6' id='slider'>
                        <ul class='slides'>";
                    
                        while ( $proj_query->have_posts() ) : $proj_query->the_post();  

                               $pid =  get_the_ID();
                               

                               $thumbid = get_post_thumbnail_id( $pid );
                               $thumb = wp_get_attachment_image_src($thumbid, 'project-slider-thumb');
                               $thumb_big = wp_get_attachment_image_src($thumbid, 'project-slider-big');

                               $title = get_the_title($pid);
                               $subtitle = get_post_meta($pid, "wish_project_subtitle", true);
                               
                               $terms = get_the_terms( $pid, 'projects_categories' ,  ' ' );

                               $slg = "";
                                if(!empty($terms)){ 
                                       foreach($terms as $slug){
                                            $slg .= sanitize_html_class($slug->slug) . " ";
                                       }
                                }

                               $out_thumb = $thumb[0];
                               $out_big = $thumb_big[0];


                               if($thumb_big[0] == ""){
                                    $out_big = plugins_url('images/1000x1000.gif', __FILE__);   
                               }               

                               $link = esc_url(get_post_permalink());
                               $title = get_the_title();  

                                $output .= "<li class='green-bg-2'>
                                              <div class='col-lg-6'><img src='{$out_big}' class='img-responsive' alt=''></div>
                                              <div class='col-lg-6'>
                                                <div class='intro'>
                                                  <h3>{$subtitle}</h3>
                                                  <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>
                                                  <div class='detail'>
                                                    <div class='heading' style='font-family:{$heading_font_family};font-size:{$heading_size}px;color:{$heading_color}'>Project Name</div>
                                                    <div class='info' style='font-family:{$info_font_family};font-size:{$info_size}px;color:{$info_color}'>Premium Tumblr Theme</div>
                                                    <div class='heading' style='font-family:{$heading_font_family};font-size:{$heading_size}px;color:{$heading_color}'>Deliverables</div>
                                                    <div class='info' style='font-family:{$info_font_family};font-size:{$info_size}px;color:{$info_color}'>unique, minimalistic, clean</div>
                                                    <div class='heading' style='font-family:{$heading_font_family};font-size:{$heading_size}px;color:{$heading_color}'>Awards & Recognition</div>
                                                    <div class='info' style='font-family:{$info_font_family};font-size:{$info_size}px;color:{$info_color}'>Awwwards</div>
                                                  </div>
                                                  <div class='buttons'><a href='{$link}' class='nofill'>Visit Site <i class='fa fa-angle-right'></i></a></div>
                                                </div>
                                              </div>
                                            </li>";



                        endwhile;   
                        wp_reset_postdata();        


                     $output .=   "</ul></div>";

                     $output .= "<div id='carousel' class='flexslider'>
                                    <ul class='slides'>";

                                    while ( $proj_query->have_posts() ) : $proj_query->the_post();  
                                        $pid =  get_the_ID();    
                                        $thumbid = get_post_thumbnail_id( $pid );
                                        $thumb = wp_get_attachment_image_src($thumbid, 'project-slider-thumb');

                                        $out_thumb = $thumb[0];

                                        if($thumb[0] == ""){
                                            $out_thumb = plugins_url('images/240x240.gif', __FILE__);   
                                        } 

                      $output .=  "<li> <img src='{$out_thumb}' class='img-responsive' alt=''> </li>";
                        endwhile;   
                        wp_reset_postdata(); 
                      
                      $output .= "</ul>
                                </div>"; 




      return $output;
    }

    /*
    Load plugin css and javascript files which you may need on front end of your site
    */
    public function loadCssAndJs() {
      //wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
      //wp_enqueue_style( 'vc_extend_style' );

      // If you need any javascript files on front end, here is how you can load them.
      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );
    }

    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }



}//end of class
?>