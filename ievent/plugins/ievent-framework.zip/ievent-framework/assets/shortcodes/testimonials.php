<?php 
	
	/* Testimonials  ---------------------------------------------*/
	
	add_shortcode('testimonials', 'jx_ievent_testimonials');
	
	function jx_ievent_testimonials($atts, $content = null) { 
		extract(shortcode_atts(array(
				'post_count' => ''
				), $atts)); 
		 
		
		//initial variables
		$out='';
		$testimonial_company=''; 
		 
		$args = array('post_type' => 'testimonials','orderby' => 'date', 'order' => 'ASC','showposts' => $post_count ); 
			
		$out ='
		<div class="jx-ievent-testimonial">		
			<div class="flexslider">
				<ul class="slides">'; 
			$loop = new WP_Query( $args ); 		
			while ( $loop->have_posts() ) : $loop->the_post();  
			
		//function code
			
			
			$out .='<li><div class="jx-ievent-testimonial-item">
                
                	<div class="jx-ievent-photo">'.get_the_post_thumbnail(get_the_ID(),'testimonial').'</div>
                    <!-- Image -->
                    
                    <div class="jx-ievent-testimonial-content">
                    	<div class="jx-ievent-name"><i class="fa fa-quote-left"></i><span>'. get_the_title() .'</span></div>
                        <div class="jx-ievent-content"><p>'.get_the_content().'</p></div>
                    
                    </div>
					<div class="clearfix"></div>
                	             
                </div></li>';
			
			
			/*$out .='	
			<li>
				<div class="jx-ievent-testimonial-item">
					<div class="jx-ievent-testimonial-image">'.get_the_post_thumbnail(get_the_ID(),'testimonial').'</div>
					<!-- Left item -->
					
					<div class="jx-ievent-testimonial-details clearfix">
						<div class="jx-ievent-testimonial-content">
							<div class="jx-ievent-testimonial-description"><p>'.get_the_content().'</p></div>
							<div class="jx-ievent-testimonial-name jx-ievent-uppercase">'. get_the_title() .'</div>
							<div class="jx-ievent-testimonial-company">'.$testimonial_company.'</div>
						</div>
						<!-- EOF testimonial content -->
					</div>
				</div>                                                       
			</li>
			<!-- Item 01 -->
			';*/

			endwhile;
			$out .='</ul>
						</div>
							</div>
			'; 
			wp_reset_query();   


		
		//return output
		return $out;
	}
	
	
	
	
		//Visual Composer
	
	
	add_action( 'vc_before_init', 'vc_testimonials' );
	
	
	function vc_testimonials() {	
		vc_map(array(
      "name" => esc_html__( "Testimonials", "TEXT_DOMAIN" ),
      "base" => "testimonials",
      "class" => "",
	  "icon" => get_template_directory_uri().'/images/icon/vc_testimonial.png',
      "category" => esc_html__( "iEvent Shortcodes", "TEXT_DOMAIN"),
	  "description" => __('Add Testimonials','TEXT_DOMAIN'),
      "params" => array(
		 		 
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__( "Count", "TEXT_DOMAIN" ),
            "param_name" => "post_count",
			"value" =>"4", //Default Counter Up Text
            "description" => esc_html__( "You Can Change Count", "TEXT_DOMAIN" )
         )
		 

      )
   )); 
	}



?>