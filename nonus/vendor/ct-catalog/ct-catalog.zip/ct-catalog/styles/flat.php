<?php
/** Default */
//Colors
($btnBgClr=="")? $btnBgClr='#2ecc71':$btnBgClr=$btnBgClr;
($btnBgClrHover=="")? $btnBgClrHover='#28b062':$btnBgClrHover=$btnBgClrHover;
($btnTxtClr=="")? $btnTxtClr='#fff':$btnTxtClr=$btnTxtClr;

//Border
($btnRadiusValue=="")? $btnRadiusValue='4':$btnRadiusValue=$btnRadiusValue;

//Padding small
($btpTop=="")? $btpTopSmall='7':$btpTopSmall=$btpTop;
($btpRight=="")? $btpRightSmall='12':$btpRightSmall=$btpRight;
($btpBottom=="")? $btpBottomSmall='7':$btpBottomSmall=$btpBottom;
($btpLeft=="")? $btpLeftSmall='12':$btpLeftSmall=$btpLeft;

//Padding
($btpTop=="")? $btpTop='7':$btpTop=$btpTop;
($btpRight=="")? $btpRight='12':$btpRight=$btpRight;
($btpBottom=="")? $btpBottom='7':$btpBottom=$btpBottom;
($btpLeft=="")? $btpLeft='12':$btpLeft=$btpLeft;

?>
<style type="text/css">
    .ct-style-flat.<?php echo $value; ?> {
        background:<?php echo $btnBgClr; ?> !important;
        border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -moz-border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -webkit-border-radius: <?php echo $btnRadiusValue; ?>px !important;
        color: <?php echo $btnTxtClr; ?> !important;
        font-size: 12px !important;
        text-transform: uppercase !important;
        letter-spacing: 0.2em !important;
        text-decoration: none !important;
        display: inline-block !important;
        padding: <?php echo $btpTop; ?>px <?php echo $btpRight; ?>px <?php echo $btpBottom; ?>px <?php echo $btpLeft; ?>px !important;

        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClr; ?> !important;
        margin: <?php echo $btmTop; ?>px <?php echo $btmRight; ?>px <?php echo $btmBottom; ?>px <?php echo $btmLeft; ?>px !important;
        -webkit-box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        -moz-box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
    }

    .ct-style-flat.small.<?php echo $value; ?> {
        font-size: 11px !important;
        padding: <?php echo $btpTopSmall; ?>px <?php echo $btpRightSmall; ?>px <?php echo $btpBottomSmall; ?>px <?php echo $btpLeftSmall; ?>px !important;
        display:block !important;
        text-align: center !important;
    }

    .ct-style-flat.<?php echo $value; ?>:hover, .ct-style-flat.small.<?php echo $value; ?>:hover {
        background:<?php echo $btnBgClrHover; ?> !important;

        color: <?php echo $btnTxtClrHover; ?> !important;
        text-decoration: none !important;
        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClrHover; ?> !important;
    }
</style>