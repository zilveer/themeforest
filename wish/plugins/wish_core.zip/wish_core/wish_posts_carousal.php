<?php  /*IJAZ AHMAD*/

// Plain Hero, no images and stuff

class Wish_posts_carousal {



        var $shortcode = 'wish_posts_carousal';

        var $title = "Wish Posts Carousal";

        var $details = "Show latest posts in carousal";

        //var $path = "/templates/rating_hero.php";



    function __construct() {

        // We safely integrate with VC with this hook

        add_action( 'init', array( $this, 'integrateWithVC' ) );

 

        // Use this when creating a shortcode addon

        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );



        // Register CSS and JS

        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );

    }

 

    public function integrateWithVC() {

        // Check if Visual Composer is installed

        if ( ! defined( 'WPB_VC_VERSION' ) ) {

            // Display notice that Visual Compser is required

            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));

            return;

        }

 

        vc_map( array(

            "name" => __($this->title, 'wish'),

            "description" => __($this->details, 'wish'),

            "base" => $this->shortcode,

            "class" => "",

            "controls" => "full",

            "link" => "http://i.imgur.com/CnirPix.png",

            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"

            "category" => __('Wish Components', 'wish'),

            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor

            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor

            "params" => array(



                            array(

                                "type" => "textfield",

                                "heading" => __("Heading", "wish"),

                                "param_name" => "news_heading",
                                "description" => __("Heading", "wish"),

                                "value" => __("News", 'wish'),

                                "admin_label" => false,

                            ),
 array(

                                "type" => "dropdown",

                                "heading" => __("Max Posts", "wish"),

                                "param_name" => "max_posts",

                                "description" => __("Maximum Number Of Posts to show.", "wish"),

                                "value" => array( 

                                                  "All"  => "-1",
												  
												  "3"     => "3",
												  
												  "4"     => "4",

                                                  "5"     => "5",

                                                  "8"     => "8",

                                                  "10"     => "10",

                                                ),

                                "std"       =>   5,

                            ),
array(

                                "type" => "checkbox",

                                "heading" => __("Parallax?", "wish"),

                                "param_name" => "news_parallax",
                                "description" => __("Heading", "wish"),
								"value" => false,

								"description" => __( "Want it to be a parallax?", "wish" ),
					
								"admin_label" => false,

                            ),
							

                            /**/

                            array(

                                "type" => "google_fonts",

                                "class" => "",

                                "heading" => __("Heading Text Font", "wish" ),

                                "param_name" => "font_carousal_heading",

                                "value" => '', //Default Red color

                                "description" => __( "Choose Font", "wish" ),

                                "group"   => "Fonts & Colors",

                                'settings' => array(

                                     'fields'=>array(

                                         'font_family'=>'Lato',

                                         'font_style'=>'400:normal', 
                                   )

                                )       

                            ),





                            array(

                                "type" => "wish_number",

                                "heading" => __("Heading Size", "wish"),

                                "param_name" => "heading_size",

                                "description" => __("Heading size in px", "wish"),

                                "value" => __("18", 'wish'),

                                "admin_label" => true,

                                "group"       => "Fonts & Colors",

                            ),



                            array(

                                "type" => "colorpicker",

                                "class" => "",

                                "heading" => __("Heading Text Color", "wish" ),

                                "param_name" => "heading_color",

                                "value" => '#000 ', //Default Black color

                                "description" => __( "Choose text color", "wish" ),

                                "group"         => "Fonts & Colors",

                             ),
							 
							  array(

                                "type" => "colorpicker",

                                "class" => "",

                                "heading" => __("Link Color", "wish" ),

                                "param_name" => "link_color",

                                "value" => '#000 ', //Default Black color

                                "description" => __( "Choose Link color", "wish" ),

                                "group"         => "Fonts & Colors",

                             ),

 array(

                                "type" => "wish_number",

                                "heading" => __("Link font Size", "wish"),

                                "param_name" => "link_font_size",

                                "description" => __("Link size in px", "wish"),

                                "value" => __("14", 'wish'),

                                "admin_label" => true,

                                "group"       => "Fonts & Colors",

                            ),
							 array(

                                "type" => "wish_number",

                                "heading" => __("Date font Size", "wish"),

                                "param_name" => "date_font_size",

                                "description" => __("Link size in px", "wish"),

                                "value" => __("13", 'wish'),

                                "admin_label" => true,

                                "group"       => "Fonts & Colors",

                            ),

 array(

                                "type" => "colorpicker",

                                "class" => "",

                                "heading" => __("Date text Color", "wish" ),

                                "param_name" => "date_color",

                                "value" => '#7FC7EC ', //Default Black color

                                "description" => __( "Choose Link color", "wish" ),

                                "group"         => "Fonts & Colors",

                             ),

                           array(

            "type" => "attach_image",

            "holder" => "div",

            "class" => "",

            "heading" => __("Bankground Image", 'wish'),

            "param_name" => "image",

            "description" => __("Large image in background", 'wish'),

            "admin_label" => false,

        ),       



                    )



        ) );

    }

    



    public function renderShortcode( $atts, $content = null ) {

      extract( shortcode_atts( array(

        'news_heading'         => 'News',
		
		'max_posts'				=> '5',

        'font_carousal_heading'    => '',

        'heading_size'    => '18',
		
		'link_font_size' => '14',

        'heading_color'   => '#000',
		
		'date_font_size' 	=> '13',
		
		'link_color'   => '#000',
		
		'date_color'	=> '#7FC7EC',
		
		'news_parallax'	=> false,

		'image'			=> 'Image'


      ), $atts ) );



        /*Quote*/

        $decode_font = urldecode($font_carousal_heading);

        $decode_font = explode('|', $decode_font);

        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

        preg_match("/family=(.*):/", $font_string, $output_array);

        $posts_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Lato";



        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );
		
		
		
		
	
	
	wp_register_style('posts-carousal-css', plugins_url('assets/posts-carousal-css.css', __FILE__), array(), '1', 'all' );
	wp_enqueue_style('posts-carousal-css');
	wp_enqueue_script('bootstrap-modalmanager.min', plugins_url('assets/bootstrap-modalmanager.js', __FILE__), array('jquery') );
	wp_enqueue_script('posts-carousal', plugins_url('assets/posts-carousal.js', __FILE__), array('jquery') );
//////////////////////////////// passing variable
	wp_register_script( 'my_js_library', plugins_url('assets/posts-carousal.js', __FILE__), array('jquery') );
wp_localize_script( 'my_js_library', 'php_vars', array( 'url'  => get_bloginfo('url').'/'));
wp_enqueue_script( 'my_js_library' );
		 
	
	
	
		 

  $img = wp_get_attachment_image_src( $image, 'full' );
  
  $parallax = '';
  
  if($news_parallax) { $parallax = 'parallax-1'; }

       $out = '<section class="'.$parallax.'" id="wish-carousal-posts" data-speed="-5" data-type="background" style="background-image: url('.$img[0].')">
 <div id="responsive" class="modal fade modal_fade" tabindex="-1" data-width="760" style="display: none;">
 <div class="modal-dialog team-modal-dialog posts_carousal_modal">
  <div class="modal-header" style="border-bottom:none;">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><img class="cross_img" src="'. plugins_url('images/close_cross.png', __FILE__) .'"></button>
  </div>
	
 		
  			<div class="modal-body modal-padding">
    			<div class="row carousal-post-contents">
    			</div>
  		</div>
	</div>
</div>
        <div class="container">
		    <div id="posts-carousal" class="carousel slide">



      <div class="carousel-inner">'; ?>

<?php 

			$args = array( 'numberposts' => $max_posts, 'post_type' => 'post', 'suppress_filters' => false );

$myposts = get_posts( $args );
$i=0;
foreach( $myposts as $key => $post ) :	setup_postdata($post);   ?>
<?php 
$numItems = count($myposts);
$preper = '';
$nextpost = '';
 if(++$i != $numItems){ $nextpost = $key+1; $nextper = get_permalink( $myposts[$nextpost]->ID ); } else { $nextper=''; }  
 $prevpost = ''; if($key >= 1){ $prevpost = $key-1; $preper = get_permalink( $myposts[$prevpost]->ID );  }
 $slide_state = '';
 $next_post_data = '';
 $prevpost_id = '';
 $next_post_id = '';
 if($key==0){ $slide_state = 'active'; }
 if($nextper){ $next_post_data = $nextper; }
 if($nextpost){ $next_post_id = $myposts[$nextpost]->ID; }
 if($prevpost){ $prevpost_id = $myposts[$prevpost]->ID; }
  ?>
       <?php $out .= '<div class="item '.$slide_state.'">
          <div class="container">
            <div class="carousel-caption">
<form name="newsform" class="newsform">
<input type="hidden" name="date" value="NEWS / ' . get_the_date('d.m.Y') . '" />
<input type="hidden" name="amount_posts" value="'.$max_posts.'" />
<input type="hidden" name="newstitle" value="' . get_the_title( $post->ID ) .'" />
<input type="hidden" name="next_post" value="'.$next_post_data.'" />
<input type="hidden" name="next_postid" value="'.$next_post_id.'" />
<input type="hidden" name="prev_post" value="'.$preper.'" />
<input type="hidden" name="prev_postid" value="'.$prevpost_id.'" />
<input type="hidden" name="thumb" value="'.$post->ID.'" />
</form>

              <p class="news_date" style="font-family:'.$posts_font_family.';font-size:'.$date_font_size.'px;color:'.$date_color.';">NEWS / ' . get_the_date('d.m.Y') . '</p>



  <h4 style="font-family:'.$posts_font_family.';font-size:'.$heading_size.'px;color:'.$heading_color.';">' . get_the_title( $post->ID ) . '</h4>


<a style="font-family:'.$posts_font_family.';font-size:'.$link_font_size.'px;color:'.$link_color.';" class="readmoreNews demo" data-toggle="modal" href="#responsive">Read more</a>

            </div>

          </div>

        </div>'; ?>

<?php endforeach; ?>

				<?php wp_reset_postdata();?>

       

		<?php $out .= '<div class="arrows">



      <a class="left1 carousel-control1" href="#posts-carousal" data-slide="prev"><img src="' . plugins_url('images/left-arrow.png', __FILE__) . '"></a>&nbsp;

      <a class="right2 carousel-control2" href="#posts-carousal" data-slide="next"><img src="' . plugins_url('images/right-arrow.png', __FILE__) . '"></a>
	  	</div>
      </div>
    </div>

 </div>
    </section>';


      return $out;

    }



    /*

    Load plugin css and javascript files which you may need on front end of your site

    */

    public function loadCssAndJs() {

      //wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );

      //wp_enqueue_style( 'vc_extend_style' );



      // If you need any javascript files on front end, here is how you can load them.

      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );

    }



    /*

    Show notice if your plugin is activated but Visual Composer is not

    */

    public function showVcVersionNotice() {

        $plugin_data = get_plugin_data(__FILE__);

        echo '

        <div class="updated">

          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>

        </div>';

    }







}//end of class

?>