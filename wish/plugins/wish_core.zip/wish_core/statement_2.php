<?php  
// Plain Hero, no images and stuff
class Wish_Simple_Statement_2{

        var $shortcode = 'wish_simple_statement_2';
        var $title = "Simple Statement 2";
        var $details = "A simple statement with a title and text";

    function __construct() {
        // We safely integrate with VC with this hook
        add_action( 'init', array( $this, 'integrateWithVC' ) );
 
        // Use this when creating a shortcode addon
        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );

        // Register CSS and JS
        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
    }
 
    public function integrateWithVC() {
        // Check if Visual Composer is installed
        if ( ! defined( 'WPB_VC_VERSION' ) ) {
            // Display notice that Visual Compser is required
            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
 
        vc_map( array(
            "name" => __($this->title, 'wish'),
            "description" => __($this->details, 'wish'),
            "base" => $this->shortcode,
            "class" => "",
            "controls" => "full",
            "link" => "http://i.imgur.com/Nuf8qrm.png",
            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
            "category" => __('Wish Components', 'wish'),
            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor
            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor
            "params" => array(

                            array(
                                    "type" => "textfield",
                                    "heading" => __("Title", "wish"),
                                    "param_name" => "title",
                                    "admin_label" => true,
                                    "description" => __("The Title.", "wish"),
                                    "value" => __("Our Story", 'wish'),
                                    "admin_label" => true,
                            ),

                            array(
                                    "type" => "textfield",
                                    "heading" => __("Details 1", "wish"),
                                    "param_name" => "details1",
                                    "admin_label" => true,
                                    "description" => __("The SubTitle.", "wish"),
                                    "value" => __("Dive into each project with beautifully crafted & pages for each individual project. Wherever you’re a print designer, web designer or photographer.", 'wish'),
                                    "admin_label" => true,
                            ),

                            array(
                                "type" => "textarea",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Details 2", 'wish'),
                                "param_name" => "details2",
                                "value" => __("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.
                                    when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.", 'wish'),
                                "description" => __("Text in Column 1 (left)", 'wish'),
                                "admin_label" => false,
                            ),


                            array(
                                "type" => "vc_link",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Link To The Page", 'wish'),
                                "param_name" => "link1",
                                "description" => __("The Link To page.", 'wish'),
                                "admin_label" => false,
                            ),

                            array(
                                "type" => "textfield",
                                "heading" => __("Link Title", "wish"),
                                "param_name" => "link1_text",
                                "description" => __("Title of the link", "wish"),
                                "value" => __("Read More", 'wish'),
                                "admin_label" => false,
                            ),
                            
                            array(
                                "type" => "vc_link",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Link To The Page", 'wish'),
                                "param_name" => "link2",
                                "description" => __("The Link To page.", 'wish'),
                                "admin_label" => false,
                            ),

                            array(
                                "type" => "textfield",
                                "heading" => __("Link Title", "wish"),
                                "param_name" => "link2_text",
                                "description" => __("Title of the link", "wish"),
                                "value" => __("Buy Theme", 'wish'),
                                "admin_label" => false,
                            ),

                            /*Title*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __( "Title Text Font", "wish" ),
                                "param_name" => "title_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Title Size", "wish"),
                                "param_name" => "title_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("60", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Title Text Color", "wish" ),
                                "param_name" => "title_color",
                                "value" => '#000 ', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),


                            /*Details 1*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __( "Details 1 Text Font", "wish" ),
                                "param_name" => "details1_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Details 1 Size", "wish"),
                                "param_name" => "details1_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("16", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Details 1 Text Color", "wish" ),
                                "param_name" => "details1_color",
                                "value" => '#000', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),


                            /*Details 2*/
                            array(
                                "type" => "google_fonts",
                                "class" => "",
                                "heading" => __( "Details 2 Text Font", "wish" ),
                                "param_name" => "details2_font",
                                "value" => '', //Default Red color
                                "description" => __( "Choose Font", "wish" ),
                                "group"   => "Fonts & Colors",
                                'settings' => array(
                                     'fields'=>array(
                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
                                   )
                                )       
                            ),


                            array(
                                "type" => "wish_number",
                                "heading" => __("Details 2 Size", "wish"),
                                "param_name" => "details2_size",
                                "description" => __("Font size in px", "wish"),
                                "value" => __("16", 'wish'),
                                "admin_label" => true,
                                "group"       => "Fonts & Colors",
                            ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Details 2 Text Color", "wish" ),
                                "param_name" => "details2_color",
                                "value" => '#000', //Default Black color
                                "description" => __( "Choose text color", "wish" ),
                                "group"         => "Fonts & Colors",
                             ),

                            array(
                                "type" => "colorpicker",
                                "class" => "",
                                "heading" => __( "Backgroung Color", "wish" ),
                                "param_name" => "bgcolor",
                                "value" => '#FFFFFF',
                                "description" => __( "Choose the background color", "wish" ),
                                "group"         => "Fonts & Colors",
                            ),

                             



                    )

        ) );
    }
    

    public function renderShortcode( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'             => 'Our Story',
        'title_font'        => '',
        'title_size'        => '60',
        'title_color'       => '#000',

        'details1'          => 'Dive into each project with beautifully crafted & pages for each individual project. Wherever you’re a print designer, web designer or photographer.',
        'details1_font'     => '',
        'details1_size'     => '16',
        'details1_color'    => '#fff',

        'details2'          => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.',
        'details2_font'     => '',
        'details2_size'     => '16',
        'details2_color'    => '#000',

        'link1'             => '#',
        'link2'             => 'http://themeforest.net/item/wishmultipurpose-multipage-one-page/11253052',
        'link1_text'        => 'Read More',
        'link2_text'        => 'Buy Theme',
        'link_title_color'  => '#000',
        'bgcolor'           => 'bgcolor',
      ), $atts ) );


        /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Details 1*/
        $decode_font = urldecode($details1_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details1_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Details 2*/
        $decode_font = urldecode($details2_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details2_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );




      if($link1 == "||" || $link1 == "" ){
            
            $link1_text = "Make an Appointment";
            $link1_url = "#";
            $link1_target = "";
            $link1_String="";

          }else{

            $link1 = vc_build_link($link1); //parse the link
            $link1_url = esc_url($link1["url"]);
            $link1_target = esc_attr($link1["target"]);
            $link1_String="<a href='{$link1_url}' class='fill hidden-xs'>{$link1_text}</a>";
            if ($link1_text == "") {
                $link1_String = "";
            }

          }


          if($link2 == "||" || $link2 == "" ){
            
            $link2_text = "Make an Appointment";
            $link2_url = "#";
            $link2_target = "";
            $link2_String="";

          }else{

            $link2 = vc_build_link($link2); //parse the link
            $link2_url = esc_url($link2["url"]);
            $link2_target = esc_attr($link2["target"]);
            $link2_String="<a href='{$link2_url}' class='nofill'>{$link2_text}</a>";
            if ($link2_text == "") {
                $link2_String = "";
            }

          }
      

      $output = "<div class='container statement-2'>
            <!-- Detail Starts -->
            <div class='row detail'>
                <div class='col-lg-6'>
                    <h1 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>
                    <div class='description animated' data-animation='fadeInUp' data-animation-delay='300' style='font-family:{$details1_font_family};font-size:{$details1_size}px;color:{$details1_color}'>{$details1}</div>
                    <div class='buttons animated' data-animation='fadeInUp' data-animation-delay='500'>{$link1_String}{$link2_String}</div>
                </div>
                <div class='col-lg-6'>
                    <div class='description animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$details2_font_family};font-size:{$details2_size}px;color:{$details2_color}'>{$details2}</div>
                </div>
            </div>
            <!-- Detail Ends -->
            
        </div>";
      return $output;
    }

    /*
    Load plugin css and javascript files which you may need on front end of your site
    */
    public function loadCssAndJs() {
      //wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
      //wp_enqueue_style( 'vc_extend_style' );

      // If you need any javascript files on front end, here is how you can load them.
      //wp_enqueue_script( 'vc_extend_js', plugins_url('assets/vc_extend.js', __FILE__), array('jquery') );
    }

    /*
    Show notice if your plugin is activated but Visual Composer is not
    */
    public function showVcVersionNotice() {
        $plugin_data = get_plugin_data(__FILE__);
        echo '
        <div class="updated">
          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
        </div>';
    }



}//end of class
?>