<?php
$ct_icons = array(
			
			'header-web' => '--------- Web Application Icons ---------',
				'adjust' => 'fa-adjust',
				'arrows-h' => 'fa-arrows-h',
				'bar-chart-o' => 'bar-chart-o',
				'bell' => 'fa-bell',
				'bookmark' => 'fa-bookmark',
				'building-o' => 'fa-building-o',
				'calendar-o' => 'fa-calendar-o',
				'caret-square-o-left' => 'fa-caret-square-o-left',
				'check' => 'fa-check',
				'check-square-o' => 'fa-check-square-o',
				'cloud' => 'fa-cloud',
				'code-fork' => 'fa-code-fork',
				'comment' => 'fa-comment',
				'compass' => 'fa-compass',
				'cutlery' => 'fa-cutlery',
				'download' => 'fa-download',
				'envelope' => 'fa-envelope',
				'exclamation' => 'fa-exclamation',
				'external-link-square' => 'fa-external-link-square',
				'fighter-jet' => 'fa-fighter-jet',
				'fire-extinguisher' => 'fa-fire-extinguesher',
				'flash' => 'fa-flash',
				'folder-open' => 'fa-folder-open',
				'gavel' => 'fa-gavel',
				'glass' => 'fa-glass',
				'headphones' => 'fa-headphones',
				'inbox' => 'fa-inbox',
				'keyboard-o' => 'fa-keyboard-o',
				'lemon-o' => 'fa-lemon-o',
				'location-arrow' => 'fa-location-arrow',
				'mail-forward' => 'fa-mail-forward',
				'map-marker' => 'fa-map-marker',
				'minus' => 'fa-minus',
				'mobile' => 'fa-mobile',
				'music' => 'fa-music',
				'phone' => 'fa-phone',
				'plus' => 'fa-plus',
				'power-off' => 'fa-power-off',
				'question' => 'fa-question',
				'random' => 'fa-random',
				'retweet' => 'fa-retweet',
				'rss-square' => 'fa-rss-square',
				'share' => 'fa-share',
				'shopping-cart' => 'fa-shopping-cart',
				'sitemap' => 'fa-sitemap',
				'sort-alpha-desc' => 'fa-sort-alpha-desc',
				'sort-desc' => 'fa-sort-desc',
				'sort-up' => 'fa-sort-up',
				'star' => 'fa-star',
				'star-half-o' => 'fa-star-half-o',
				'sun-o' => 'fa-sun-o',
				'tag' => 'fa-tag',
				'thumb-tack' => 'fa-thumb-tack',
				'thumbs-up' => 'fa-thumbs-up',
				'times-circle-o' => 'fa-times-circle-o',
				'toggle-right' => 'fa-toggle-right',
				'truck' => 'fa-truck',
				'unsorted' => 'fa-unsorted',
				'video-camera' => 'fa-video-camera',
				'warning' => 'fa-warning',
				'anchor' => 'fa-anchor',
				'arrows-v' => 'fa-arrows-v',
				'barcode' => 'fa-barcode',
				'bell-o' => 'fa-bell-o',
				'bookmark-o' => 'fa-bookmark-o',
				'bullhorn' => 'fa-bullhorn',
				'camera' => 'fa-camera',
				'caret-square-o-right' => 'fa-caret-square-o-right',
				'check-circle' => 'fa-check-circle',
				'circle' => 'fa-circle',
				'cloud-download' => 'fa-cloud-download',
				'coffee' => 'fa-coffee',
				'comment-o' => 'fa-comment-o',
				'credit-card' => 'fa-credit-card',
				'dashboard' => 'fa-dashboard',
				'edit' => 'fa-edit',
				'envelope-o' => 'fa-envelope-o',
				'exclamation-circle' => 'fa-exclamation-circle',
				'eye' => 'fa-eye',
				'film' => 'fa-film',
				'flag' => 'fa-flag',
				'flask' => 'fa-flask',
				'folder-open-o' => 'fa-folder-open-o',
				'gear' => 'fa-gear',
				'globe' => 'fa-globe',
				'heart' => 'fa-heart',
				'info' => 'fa-info',
				'laptop' => 'fa-laptop',
				'level-down' => 'fa-level-down',
				'lock' => 'fa-lock',
				'mail-reply' => 'fa-mail-reply',
				'meh-o' => 'fa-meh-o',
				'minus-circle' => 'fa-minus-circle',
				'mobile-phone' => 'fa-mobile-phone',
				'pencil' => 'fa-pencil',
				'phone-square' => 'fa-phone-square',
				'plus-circle' => 'fa-plus-circle',
				'print' => 'fa-print',
				'question-circle' => 'fa-question-circle',
				'refresh' => 'fa-refresh',
				'road' => 'fa-road',
				'search' => 'fa-search',
				'share-square' => 'fa-share-square',
				'sign-in' => 'fa-sign-in',
				'smile-o' => 'fa-smile-o',
				'sort-amount-asc' => 'fa-sort-amount-asc',
				'sort-down' => 'fa-sort-down',
				'spinner' => 'fa-spinner',
				'star-half' => 'fa-star-half',
				'star-o' => 'fa-star-o',
				'super-script' => 'fa-super-script',
				'tags' => 'fa-tags',
				'thumbs-down' => 'fa-thumbs-down',
				'ticket' => 'fa-ticket',
				'tint' => 'fa-tint',
				'toggle-up' => 'fa-toggle-up',
				'umbrella' => 'fa-umbrella',
				'upload' => 'fa-upload',
				'volume-down' => 'fa-volume-down',
				'wheelchair' => 'fa-wheelchair',
				'archive' => 'fa-archive',
				'asterisk' => 'fa-asterisk',
				'bars' => 'fa-bars',
				'bolt' => 'fa-bolt',
				'briefcase' => 'fa-briefcase',
				'bullseye' => 'fa-bullseye',
				'camera-retro' => 'fa-camera-retro',
				'caret-square-o-up' => 'fa-caret-square-o-up',
				'check-circle-o' => 'fa-check-circle-o',
				'circle-o' => 'fa-circle-o',
				'cloud-upload' => 'fa-cloud-upload',
				'cog' => 'fa-cog',
				'comments' => 'fa-comments',
				'crop' => 'fa-crop',
				'desktop' => 'fa-desktop',
				'ellipsis-h' => 'fa-ellipsis-h',
				'eraser' => 'fa-eraser',
				'exclamation-triangle' => 'fa-exclamation-triangle',
				'eye-slash' => 'fa-eye-slash',
				'filter' => 'fa-filter',
				'flag-checkered' => 'fa-flag-checkered',
				'folder' => 'fa-folder',
				'frown-o' => 'fa-frown-o',
				'gears' => 'fa-gears',
				'group' => 'fa-group',
				'heart-o' => 'fa-heart-o',
				'info-circle' => 'fa-info-circle',
				'leaf' => 'fa-leaf',
				'level-up' => 'fa-level-up',
				'magic' => 'fa-magic',
				'mail-reply-all' => 'fa-mail-reply-all',
				'microphone' => 'fa-microphone',
				'minus-square' => 'fa-minus-square',
				'money' => 'fa-money',
				'pencil-square' => 'fa-pencil-square',
				'picture-o' => 'fa-picture-o',
				'plus-square' => 'fa-plus-square',
				'puzzle-piece' => 'fa-puzzle-piece',
				'quote-left' => 'fa-quote-left',
				'reply' => 'fa-reply',
				'rocket' => 'fa-rocket',
				'search-minus' => 'fa-search-minus',
				'share-square-o' => 'fa-share-square-o',
				'sign-out' => 'fa-sign-out',
				'sort' => 'fa-sort',
				'sort-amount-desc' => 'fa-sort-amount-desc',
				'sort-numeric-asc' => 'fa-sort-numeric-asc',
				'square' => 'fa-square',
				'star-half-empty' => 'fa-star-half-empty',
				'subscript' => 'fa-subscript',
				'tablet' => 'fa-tablet',
				'tasks' => 'fa-tasks',
				'thumbs-o-down' => 'fa-thumbs-o-down',
				'times' => 'fa-times',
				'toggle-down' => 'fa-toggle-down',
				'trash-o' => 'fa-trash-o',
				'unlock' => 'fa-unlock',
				'user' => 'fa-user',
				'volume-off' => 'fa-volume-off',
				'wrench' => 'fa-wrench',
				'arrows' => 'fa-arrows',
				'ban' => 'fa-ban',
				'beer' => 'fa-beer',
				'book' => 'fa-book',
				'bug' => 'fa-bug',
				'calendar' => 'fa-calendar',
				'caret-square-o-down' => 'fa-caret-square-o-down',
				'certificate' => 'fa-certificate',
				'check-square' => 'fa-check-square',
				'clock-o' => 'fa-clock-o',
				'code' => 'fa-code',
				'cogs' => 'fa-cogs',
				'comments-o' => 'fa-comments-o',
				'crosschairs' => 'fa-crosschairs',
				'dot-circle-o' => 'fa-dot-circle-o',
				'ellipsis-v' => 'fa-ellipsis-v',	
				'exchange' => 'fa-exchange',
				'external-link' => 'fa-external-link',
				'female' => 'fa-female',
				'fire' => 'fa-fire',
				'flag-o' => 'fa-flag-o',
				'folder-o' => 'fa-folder-o',
				'gamepad' => 'fa-gamepad',
				'gift' => 'fa-gift',
				'hdd-o' => 'fa-hdd-o',
				'home' => 'fa-home',
				'key' => 'fa-key',
				'legal' => 'fa-legal',
				'lightbulb-o' => 'fa-lightbulb-o',
				'magnet' => 'fa-magnet',
				'male' => 'fa-male',
				'microphone-slash' => 'fa-microphone-slash',
				'minus-square-o' => 'fa-minus-square-o',
				'moon-o' => 'fa-moon-o',
				'pencil-square-o' => 'fa-pencil-square-o',
				'plane' => 'fa-plane',
				'plus-square-o' => 'fa-plus-square-o',
				'qrcode' => 'fa-qrcode',
				'quote-right' => 'fa-quote-right',
				'reply-all' => 'fa-reply-all',
				'rss' => 'fa-rss',
				'search-plus' => 'fa-search-plus',
				'shield' => 'fa-shield',
				'signal' => 'fa-signal',
				'sort-alpha-asc' => 'fa-sort-alpha-asc',
				'sort-asc' => 'fa-sort-asc',
				'sort-numeric-desc' => 'fa-sort-numeric-desc',
				'square-o' => 'fa-square-o',
				'star-half-full' => 'fa-star-half-full',
				'suitcase' => 'fa-suitcase',
				'tachometer' => 'fa-tachometer',
				'terminal' => 'fa-terminal',
				'thumbs-o-up' => 'fa-thumbs-o-up',
				'times-circle' => 'fa-times-circle',
				'togle-left' => 'fa-toggle-left',
				'trophy' => 'fa-trophy',
				'unlock-alt' => 'fa-unlock-alt',
				'users' => 'fa-users',
				'volume-up' => 'fa-volume-up',
	'header-formcontrol' => '--------- Form Control Icons ---------',
				'check-square' => 'fa-check-square',
				'dot-circle-o' => 'fa-dot-circle-o',
				'plus-square-o' => 'fa-plus-square-o',
				'check-square-o' => 'fa-check-square-o',
				'minus-square' => 'fa-minus-square',
				'square' => 'fa-square',
				'circle' => 'fa-circle',
				'minus-square-o' => 'fa-minus-square-o',
				'square-o' => 'fa-square-o',
				'circle-o' => 'fa-circle-o',
				'plus-square' => 'fa-plus-square',
	'header-currency' => '--------- Currency Icons ---------',
				'bitcoin' => 'fa-bitcoin',
				'eur' => 'fa-eur',
				'jpy' => 'fa-jpy',
				'rouble' => 'fa-rouble',
				'try' => 'fa-try',
				'yen' => 'fa-yen',
				'btc' => 'fa-btc',
				'euro' => 'fa-euro',
				'krw' => 'fa-krw',
				'rub' => 'fa-rub',
				'turkish-lira' => 'fa-turkish-lira',
				'cny' => 'fa-cny',
				'gbp' => 'fa-gbp',
				'money' => 'fa-money',
				'ruble' => 'fa-ruble',
				'usd' => 'fa-usd',
				'dollar' => 'fa-dollar',
				'inr' => 'fa-inr',
				'rmb' => 'fa-rmb',
				'rupee' => 'fa-rupee',
				'won' => 'fa-won',
	'header-text' => '--------- Text Editor Icons ---------',
				'align-center' => 'fa-align-center',
				'bold' => 'fa-bold',
				'columns' => 'fa-columns',
				'eraser' => 'fa-eraser',
				'file-text-o' => 'fa-file-text-o',
				'indent' => 'fa-indent',
				'list-alt' => 'fa-list-alt',
				'paperclip' => 'fa-paperclip',
				'rotate-right' => 'fa-rotate-right',
				'table' => 'fa-table',
				'th-large' => 'fa-th-large',
				'unlink' => 'fa-unlink',
				'align-justify' => 'fa-align-justify',
				'chain' => 'fa-chain',
				'copy' => 'fa-copy',
				'file' => 'fa-file',
				'files-o' => 'fa-files-o',
				'italic' => 'fa-italic',
				'list-ol' => 'fa-list-ol',
				'paste' => 'fa-paste',
				'save' => 'fa-save',
				'text-height' => 'fa-text-height',
				'th-list' => 'fa-th-list',
				'align-left' => 'fa-align-left',
				'chain-broken' => 'fa-chain-broken',
				'cut' => 'fa-cut',
				'file-o' => 'fa-file-o',
				'floppy-o' => 'fa-floppy-o',
				'link' => 'fa-link',
				'list-ul' => 'fa-list-ul',
				'repeat' => 'fa-repeat',
				'scissors' => 'fa-scissors',
				'text-width' => 'fa-text-width',
				'underline' => 'fa-underline',
				'align-right' => 'fa-align-right',
				'clipboard' => 'fa-clipboard',
				'dedent' => 'fa-dedent',
				'file-text' => 'fa-file-text',
				'font' => 'fa-font',
				'list' => 'fa-list',
				'outdent' => 'fa-outdent',
				'rotate-left' => 'fa-rotate-left',
				'strikethrough' => 'fa-strikethrough',
				'th' => 'fa-th',
				'undo' => 'fa-undo',
	'header-directional' => '--------- Directional Icons ---------',				
				'angle-double-down' => 'fa-angle-double-down',
				'angle-down' => 'fa-angle-down',
				'arrow-circle-down' => 'fa-arrow-circle-down',
				'arrow-circle-o-right' => 'fa-arrow-circle-o-right',
				'arrow-down' => 'fa-arrow-down',
				'arrows' => 'fa-arrows',
				'caret-down' => 'fa-caret-down',
				'caret-square-o-left' => 'fa-caret-square-o-left',
				'chevron-circle-down' => 'fa-chevron-circle-down',
				'chevron-down' => 'fa-chevron-down',
				'hand-o-down' => 'fa-hand-o-down',
				'long-arrow-down' => 'fa-long-arrow-down',
				'toggle-down' => 'fa-toggle-down',
				'angle-double-left' => 'fa-angle-double-left',
				'angle-left' => 'fa-angle-left',
				'arrow-circle-left' => 'fa-arrow-circle-left',
				'arrow-circle-o-up' => 'fa-arrow-circle-o-up',
				'arrow-left' => 'fa-arrow-left',
				'arrows-alt' => 'fa-arrows-alt',
				'caret-left' => 'fa-caret-left',
				'caret-square-o-right' => 'fa-caret-square-o-right',
				'chevron-circle-left' => 'fa-chevron-circle-left',
				'chevron-left' => 'fa-chevron-left',
				'hand-o-left' => 'fa-hand-o-left',
				'long-arrow-left' => 'fa-long-arrow-left',
				'toggle-left' => 'fa-toggle-left',
				'angle-double-right' => 'fa-angle-double-right',
				'angle-right' => 'fa-angle-right',
				'arrow-circle-o-down' => 'fa-arrow-circle-o-down',
				'arrow-circle-right' => 'fa-arrow-circle-right',
				'arrow-right' => 'fa-arrow-right',
				'arrows-h' => 'fa-arrows-h',
				'caret-right' => 'fa-caret-right',
				'caret-square-o-up' => 'fa-caret-square-o-up',
				'chevron-circle-right' => 'fa-chevron-circle-right',
				'chevron-right' => 'fa-chevron-right',
				'hand-o-right' => 'fa-hand-o-right',
				'long-arrow-right' => 'fa-long-arrow-right',
				'toggle-right' => 'fa-toggle-right',
				'angle-double-up' => 'fa-angle-double-up',
				'angle-up' => 'fa-angle-up',
				'arrow-circle-o-left' => 'fa-arrow-circle-o-left',
				'arrow-circle-up' => 'fa-arrow-circle-up',
				'arrow-up' => 'fa-arrow-up',
				'arrows-v' => 'fa-arrows-v',
				'caret-square-o-down' => 'fa-caret-square-o-down',
				'caret-up' => 'fa-caret-up',
				'chevron-circle-up' => 'fa-chevron-circle-up',
				'chevron-up' => 'fa-chevron-up',
				'hand-o-up' => 'fa-hand-o-up',
				'long-arrow-up' => 'fa-long-arrow-up',
				'toggle-up' => 'fa-toggle-up',
	'header-video' => '--------- Video Player Icons ---------',
				'arrows-alt' => 'fa-arrows-alt',
				'expand' => 'fa-expand',
				'pause' => 'fa-pause',
				'step-backward' => 'fa-step-backward',
				'backward' => 'fa-backward',
				'fast-backward' => 'fa-fast-backward',
				'play' => 'fa-play',
				'step-forward' => 'fa-step-forward',
				'compress' => 'fa-compress',
				'fast-forward' => 'fa-fast-forward',
				'play-circle' => 'fa-play-circle',	
				'stop' => 'fa-stop',
				'eject' => 'fa-eject',
				'forward' => 'fa-forward',
				'play-circle-o' => 'fa-play-circle-o',
				'youtube-play' => 'fa-youtube-play',
	'header-brand' => '--------- Brand Icons ---------',
				'adn' => 'fa-adn',
				'bitbucket-square' => 'fa-bitbucket-square',
				'dribbble' => 'fa-dribbble',
				'flickr' => 'fa-flickr',
				'github-square' => 'fa-github-square',
				'html5' => 'fa-html5',
				'linux' => 'fa-linux',
				'pinterest-square' => 'fa-pinterest-square',
				'stack-overflow' => 'fa-stack-overflow',
				'twitter' => 'fa-twitter',
				'weibo' => 'fa-weibo',
				'youtube' => 'fa-youtube',
				'android' => 'fa-android',
				'bitcoin' => 'fa-bitcoin',
				'dropbox' => 'fa-dropbox',
				'foursquare' => 'fa-foursquare',
				'gittip' => 'fa-gittip',
				'instagram' => 'fa-instagram',
				'maxcdn' => 'fa-maxcdn',
				'renren' => 'fa-renren',
				'trello' => 'fa-trello',
				'twitter-square' => 'fa-twitter-square',
				'windows' => 'fa-windows',
				'youtube-play' => 'fa-youtube-play',
				'apple' => 'fa-apple',
				'btc' => 'fa-btc',
				'facebook' => 'fa-facebook',
				'github' => 'fa-github',
				'google-plus' => 'fa-google-plus',
				'linkedin' => 'fa-linkedin',
				'pagelines' => 'fa-pagelines',
				'skype' => 'fa-skype',
				'tumblr' => 'fa-tumblr',
				'viemo-square' => 'fa-vimeo-square',
				'xing' => 'fa-xing',
				'youtube-square' => 'fa-youtube-square',
				'bitbucket' => 'fa-bitbucket',
				'css3' => 'fa-css3',
				'facebook-square' => 'fa-facebook-square',
				'github-alt' => 'fa-github-alt',
				'google-plus-square' => 'fa-google-plus-square',
				'linkedin-square' => 'fa-linkedin-square',
				'pinterest' => 'fa-pinterest',
				'stack-exchange' => 'fa-stack-exchange',
				'tumblr-square' => 'fa-tumblr-square',
				'vk' => 'fa-vk',
				'xing-square' => 'fa-xing-square',
	'header-medical' => '--------- Medical Icons ---------',		
				'ambulance' => 'fa-ambulance',
				'plus-square' => 'fa-plus-square',
				'h-square' => 'fa-h-square',
				'stethoscope' => 'fa-stethoscope',
				'hospital-o' => 'fa-hospital-o',
				'user-md' => 'fa-user-md',		
				'medkit' => 'fa-medkit',
				'wheelchair' => 'fa-wheelchair'
			);

/*-----------------------------------------------------------------------------------*/
/*	Button Config
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['func_button'] = array(
	'no_preview' => true,
	'params' => array(
		'url' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Button URL', 'textdomain'),
			'desc' => __('Add the button\'s url eg http://example.com', 'textdomain')
		),
		'style' => array(
			'type' => 'select',
			'label' => __('Button Style', 'textdomain'),
			'desc' => __('Select the button\'s style, ie the button\'s colour', 'textdomain'),
			'options' => array(
				'default'	=> 'Default',
				'primary'	=> 'Primary',
				'success'	=> 'Success',
				'info'		=> 'Info',
				'warning'	=> 'Warning',
				'danger'	=> 'Danger'
			)			
		),
		'size' => array(
			'type' => 'select',
			'label' => __('Button Size', 'textdomain'),
			'desc' => __('Select the button\'s size', 'textdomain'),
			'options' => array(
				'small' => 'Small',
				'medium' => 'Medium',
				'large' => 'Large'
			)
		),
		'type' => array(
			'type' => 'select',
			'label' => __('Button Type', 'textdomain'),
			'desc' => __('Select the button\'s type', 'textdomain'),
			'options' => array(
				'round' => 'Round',
				'square' => 'Square'
			)
		),
		'target' => array(
			'type' => 'select',
			'label' => __('Button Target', 'textdomain'),
			'desc' => __('_self = open in same window. _blank = open in new window', 'textdomain'),
			'options' => array(
				'_self' => '_self',
				'_blank' => '_blank'
			)
		),
		'content' => array(
			'std' => 'Button Text',
			'type' => 'text',
			'label' => __('Button\'s Text', 'textdomain'),
			'desc' => __('Add the button\'s text', 'textdomain'),
		)
	),
	'shortcode' => '[ct_button url="{{url}}" style="btn btn-{{style}}" size="{{size}}" type="{{type}}" target="{{target}}"] {{content}} [/ct_button]',
	'popup_title' => __('Insert Button Shortcode', 'textdomain')
);


/*-----------------------------------------------------------------------------------*/
/*	Margins Config
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['margins'] = array(
	'no_preview' => true,
	'params' => array(
		'style' => array(
			'type' => 'select',
			'label' => __('The type of the margins', 'textdomain'),
			'desc' => __('The type of the margins', 'textdomain'),
			'options' => array(
				'top' => 'Top Margin',
				'bottom' => 'Bottom Margin',
				'no-top' => 'No Top Margin',
				'no-bottom' => 'No Bottom Margin'
			)	
		),
		'margin' => array(
			'type' => 'select',
			'label' => __('Margins', 'textdomain'),
			'desc' => __('Select the margin. Ignore if Type: No Top Margin or No Bottom Margin', 'textdomain'),
			'options' => array(
				'5' => 'Margin 5px',
				'10' => 'Margin 10px',
				'15' => 'Margin 15px',
				'20' => 'Margin 20px',
				'25' => 'Margin 25px',
				'30' => 'Margin 30px',
				'35' => 'Margin 35px',
				'40' => 'Margin 40px',
				'45' => 'Margin 45px',
				'50' => 'Margin 50px',
				'55' => 'Margin 55px',
				'60' => 'Margin 60px',
				'65' => 'Margin 65px',
				'70' => 'Margin 70px',
				'75' => 'Margin 75px',
				'80' => 'Margin 80px',
				'85' => 'Margin 85px',
				'90' => 'Margin 90px',
				'95' => 'Margin 95px',
				'100' => 'Margin 100px'
			)
		)	
	),
	'shortcode' => '[ct_margin style="{{style}}" margin="{{margin}}"][/ct_margin]',
	'popup_title' => __('Insert Margin Shortcode', 'textdomain')
);


/*-----------------------------------------------------------------------------------*/
/*	Highlights Config
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['highlights'] = array(
	'no_preview' => true,
	'params' => array(
		'color' => array(
			'type' => 'select',
			'label' => __('Color', 'textdomain'),
			'desc' => __('Select the Highlights color', 'textdomain'),
			'options' => array(
				'pink' => 'Pink',
				'green' => 'Green',
				'red' => 'Red',
				'orange' => 'Orange',
				'blue' => 'Blue',
				'yellow' => 'Yellow',
				'yellowgreen' => 'YellowGreen',
				'tomato' => 'Tomato',
				'teal' => 'Teal',
				'steelblue' => 'SteelBlue',
				'slategray' => 'SlateGray',
				'seagreen' => 'SeaGreen',
				'salmon' => 'Salmon',
				'peru' => 'Peru',
				'olive' => 'Olive',
				'moccasin' => 'Moccasin',
				'magenta' => 'Magenta',
				'khaki' => 'Khaki',
				'indianred' => 'IndianRed',
				'dodgerblue' => 'DodgerBlue',
				'darkgreen' => 'DarkGreen',
				'coral' => 'Coral',
				'beige' => 'Beige',
				'aquamarine' => 'AquaMarine'
			)
		),
		'type' => array(
			'type' => 'select',
			'label' => __('Type', 'textdomain'),
			'desc' => __('Select the type', 'textdomain'),
			'options' => array(
				'square' => 'Square',
				'round' => 'Round'
			)
		),		
		'content' => array(
			'std' => 'Your Highlights!',
			'type' => 'textarea',
			'label' => __('Highlights Text', 'textdomain'),
			'desc' => __('Add the highlights\'s text', 'textdomain'),
		)
		
	),
	'shortcode' => '[ct_highlight color="{{color}}" type="{{type}}"] {{content}} [/ct_highlight]',
	'popup_title' => __('Insert Highlight Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Dropcap Config
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['dropcaps'] = array(
	'no_preview' => true,
	'params' => array(
		'color' => array(
			'type' => 'select',
			'label' => __('Color', 'textdomain'),
			'desc' => __('Select the Dropcap color', 'textdomain'),
			'options' => array(
				'pink' => 'Pink',
				'green' => 'Green',
				'red' => 'Red',
				'orange' => 'Orange',
				'blue' => 'Blue',
				'yellow' => 'Yellow',
				'yellowgreen' => 'YellowGreen',
				'tomato' => 'Tomato',
				'teal' => 'Teal',
				'steelblue' => 'SteelBlue',
				'slategray' => 'SlateGray',
				'seagreen' => 'SeaGreen',
				'salmon' => 'Salmon',
				'peru' => 'Peru',
				'olive' => 'Olive',
				'moccasin' => 'Moccasin',
				'magenta' => 'Magenta',
				'khaki' => 'Khaki',
				'indianred' => 'IndianRed',
				'dodgerblue' => 'DodgerBlue',
				'darkgreen' => 'DarkGreen',
				'coral' => 'Coral',
				'beige' => 'Beige',
				'aquamarine' => 'AquaMarine'
			)
		),	
		'size' => array(
			'type' => 'select',
			'label' => __('Size', 'textdomain'),
			'desc' => __('Select the Dropcap size', 'textdomain'),
			'options' => array(
				'small' => 'Small',
				'medium' => 'Medium',
				'large' => 'Large'
			)
		),			
		'content' => array(
			'std' => 'ABC',
			'type' => 'textarea',
			'label' => __('Dropcap Letter', 'textdomain'),
			'desc' => __('Add the letter', 'textdomain'),
		)
		
	),
	'shortcode' => '[ct_dropcap color="{{color}}" size="{{size}}"] {{content}} [/ct_dropcap]',
	'popup_title' => __('Insert Dropcap Shortcode', 'textdomain')
);


/*-----------------------------------------------------------------------------------*/
/*	Labels Config.
/*	Note: All the styles for the Labels uses from bootstrap.css
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['labels'] = array(
	'no_preview' => true,
	'params' => array(
		'type' => array(
			'type' => 'select',
			'label' => __('Type', 'textdomain'),
			'desc' => __('Select the type for label', 'textdomain'),
			'options' => array(
				'default'	=> 'Default',
				'primary'	=> 'Primary',
				'success'	=> 'Success',
				'info'		=> 'Info',
				'warning'	=> 'Warning',
				'danger'	=> 'Danger'
			)
		),	
		'content' => array(
			'std' => 'Label Text Here!',
			'type' => 'textarea',
			'label' => __('Label Text', 'textdomain'),
			'desc' => __('Add the label text', 'textdomain'),
		)
		
	),
	'shortcode' => '[ct_label type="{{type}}"] {{content}} [/ct_label]',
	'popup_title' => __('Insert Label Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Badges Config. 
/*	Note: All the styles for the Badges uses from bootstrap.css
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['badges'] = array(
	'no_preview' => true,
	'params' => array(
		'type' => array(
			'type' => 'select',
			'label' => __('Type', 'textdomain'),
			'desc' => __('Select the type for badge', 'textdomain'),
			'options' => array(
				'default' => 'Default'
			)
		),	
		'content' => array(
			'std' => 'Badge Text Here!',
			'type' => 'textarea',
			'label' => __('Badge Text', 'textdomain'),
			'desc' => __('Add the badge text', 'textdomain'),
		)
		
	),
	'shortcode' => '[ct_badge type="{{type}}"] {{content}} [/ct_badge]',
	'popup_title' => __('Insert Badge Shortcode', 'textdomain')
);


/*-----------------------------------------------------------------------------------*/
/*	Toggle Config. 
/*	Note: All the styles for the Badges uses from bootstrap.css
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['toggle_func'] = array(
	'no_preview' => true,
	'params' => array(
		'title' => array(
			'std' => 'Toggle Title',
			'type' => 'text',
			'label' => __('Enter The Title', 'textdomain'),
			'desc' => __('Add the title', 'textdomain'),
		),	
		'content' => array(
			'std' => 'Toggle Content Here',
			'type' => 'textarea',
			'label' => __('The Content', 'textdomain'),
			'desc' => __('Add the content', 'textdomain'),
		)
		
	),
	'shortcode' => '[ct_toggle title="{{title}}"] {{content}} [/ct_toggle]',
	'popup_title' => __('Insert Toggle Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Alerts Config. 
/*	Note: All the styles for the Alerts uses from bootstrap.css
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['alerts'] = array(
	'no_preview' => true,
	'params' => array(
		'type' => array(
			'type' => 'select',
			'label' => __('Type', 'textdomain'),
			'desc' => __('Select the type for alert', 'textdomain'),
			'options' => array(
				'success'	=> 'Success',
				'info'		=> 'Info',
				'warning'	=> 'Warning',
				'danger'	=> 'Danger'
			)
		),
		'title' => array(
			'std' => 'Alert Title',
			'type' => 'text',
			'label' => __('Title', 'textdomain'),
			'desc' => __('Add the alert title text', 'textdomain'),
		),
		'content' => array(
			'std' => 'Alert Text Here!',
			'type' => 'textarea',
			'label' => __('Alert Text', 'textdomain'),
			'desc' => __('Add the alert text', 'textdomain'),
		)
		
	),
	'shortcode' => '[ct_alert type="{{type}}" title="{{title}}"] {{content}} [/ct_alert]',
	'popup_title' => __('Insert Alert Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Pogress Bars Config. 
/*	Note: All the styles for the Progress Bars uses from bootstrap.css
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['p_bars'] = array(
	'no_preview' => true,
	'params' => array(
		'type' => array(
			'type' => 'select',
			'label' => __('Type', 'textdomain'),
			'desc' => __('Select the type for progress bar', 'textdomain'),
			'options' => array(
				'info' => 'Info',
				'success' => 'Success',
				'warning' => 'Warning',
				'danger' => 'Danger'
			)
		),
		'striped' => array(
			'type' => 'select',
			'label' => __('Striped?', 'textdomain'),
			'desc' => __('Select Yes or No', 'textdomain'),
			'options' => array(
				'yes' => 'Yes',
				'no' => 'No'
			)
		),			
		'animation' => array(
			'type' => 'select',
			'label' => __('Animation', 'textdomain'),
			'desc' => __('Select Yes or No', 'textdomain'),
			'options' => array(
				'yes' => 'Yes',
				'no' => 'No'
			)
		),				

		'value' => array(
			'std' => '50',
			'type' => 'text',
			'label' => __('Type value for Progress Bar', 'textdomain'),
			'desc' => __('Type value in percentage (without %)', 'textdomain'),
		),				

		'title' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Enter the title for progress', 'textdomain'),
			'desc' => __('Enter the title for progress', 'textdomain'),
		)
		
	),
	'shortcode' => '[ct_progress type="{{type}}" striped="{{striped}}" animation="{{animation}}" value="{{value}}" title="{{title}}"][/ct_progress]',
	'popup_title' => __('Insert Progress Bar Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Icons Config. 
/*	Note: All the styles for the Icons uses from font-awesome.min.css
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['f_icons'] = array(
	'no_preview' => true,
	'params' => array(
		'icon' => array(
			'type' => 'select',
			'label' => __('Icon', 'textdomain'),
			'desc' => __('Select the icon', 'textdomain'),
			'options' => $ct_icons

		),	
		'position' => array(
			'type' => 'select',
			'label' => __('Select Icon Position', 'textdomain'),
			'desc' => __('Select the position for icon (left or right)', 'textdomain'),
			'options' => array(
				'none' => 'None',
				'left' => 'Left',
				'right' => 'Right'
			)
		),
	
		'size' => array(
			'std' => '18',
			'type' => 'text',
			'label' => __('Type size for Icon', 'textdomain'),
			'desc' => __('Type size in pixels (without px)', 'textdomain'),
		),
		
		'color' => array(
			'std' => '#111111',
			'type' => 'text',
			'label' => __('Enter color for Icon', 'textdomain'),
			'desc' => __('Enter color in HEX Format ( example: #111111 )', 'textdomain'),
		),
		'title' => array(
			'std' => 'Icon Title',
			'type' => 'text',
			'label' => __('Title Text', 'textdomain'),
			'desc' => __('Add the text', 'textdomain'),
		)
	),
	'shortcode' => '[ct_icon icon="{{icon}}" size="{{size}}" color="{{color}}" title="{{title}}" position="{{position}}"][/ct_icon]',
	'popup_title' => __('Insert Icon Shortcode', 'textdomain')
);



/*-----------------------------------------------------------------------------------*/
/*	Toggle Config
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['toggle'] = array(
	'no_preview' => true,
	'params' => array(
		'title' => array(
			'type' => 'text',
			'label' => __('Toggle Content Title', 'textdomain'),
			'desc' => __('Add the title that will go above the toggle content', 'textdomain'),
			'std' => 'Title'
		),
		'content' => array(
			'std' => 'Content',
			'type' => 'textarea',
			'label' => __('Toggle Content', 'textdomain'),
			'desc' => __('Add the toggle content. Will accept HTML', 'textdomain'),
		),
		'state' => array(
			'type' => 'select',
			'label' => __('Toggle State', 'textdomain'),
			'desc' => __('Select the state of the toggle on page load', 'textdomain'),
			'options' => array(
				'open' => 'Open',
				'closed' => 'Closed'
			)
		),
		
	),
	'shortcode' => '[ct_toggle title="{{title}}" state="{{state}}"] {{content}} [/ct_toggle]',
	'popup_title' => __('Insert Toggle Content Shortcode', 'textdomain')
);



/*-----------------------------------------------------------------------------------*/
/*	Tabs Config
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['tabs'] = array(
    'params' => array(
		'title' => array(
			'type' => 'text',
			'label' => __('Tab Title', 'textdomain'),
			'desc' => __('Add the title that will go above the tab content', 'textdomain'),
			'std' => ''
		),
    ),
    'no_preview' => true,   
    'shortcode' => '[ct_tabs title="{{title}}"] {{child_shortcode}} [/ct_tabs]',
    'popup_title' => __('Insert Tab Shortcode', 'textdomain'),
    
    'child_shortcode' => array(
        'params' => array(
            'title' => array(
                'std' => 'Title',
                'type' => 'text',
                'label' => __('Tab Title', 'textdomain'),
                'desc' => __('Title of the tab', 'textdomain'),
            ),
            'content' => array(
                'std' => 'Tab Content',
                'type' => 'textarea',
                'label' => __('Tab Content', 'textdomain'),
                'desc' => __('Add the tabs content', 'textdomain')
            )
        ),
        'shortcode' => '[ct_tab title="{{title}}"] {{content}} [/ct_tab]',
        'clone_button' => __('Add Tab', 'textdomain')
    )
);




/*-----------------------------------------------------------------------------------*/
/*	Headings Shortcode
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['headings'] = array(
	'no_preview' => true,
	'params' => array(
		'level' => array(
			'type' => 'select',
			'label' => __('Headings type', 'textdomain'),
			'desc' => __('Select the levels (h1,h2,h3,h4,h5)', 'textdomain'),
			'options' => array(
				'h1' => 'H1 Heading',
				'h2' => 'H2 Heading',
				'h3' => 'H3 Heading',
				'h4' => 'H4 Heading',
				'h5' => 'H5 Heading',
				'h6' => 'H6 Heading'
			)
		),
            'content' => array(
                'std' => 'Content Here',
                'type' => 'textarea',
                'label' => __('The Content', 'textdomain'),
                'desc' => __('Add the content', 'textdomain')
            )        		
	),
	'shortcode' => '[ct_headings level="{{level}}"] {{content}} [/ct_headings]',
	'popup_title' => __('Insert Headings Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Video Shortcode
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['video_func'] = array(
	'no_preview' => true,
	'params' => array(
		'title' => array(
			'type' => 'text',
			'label' => __('Video Shortcode Title', 'textdomain'),
			'desc' => __('Add the title that will go above the video', 'textdomain'),
			'std' => 'Title'
		),
		'type' => array(
			'type' => 'select',
			'label' => __('Select the type of the video', 'textdomain'),
			'desc' => __('Select the type (vimeo, youtube, dailymotion)', 'textdomain'),
			'options' => array(
				'vimeo' => 'Vimeo',
				'youtube' => 'Youtube',
				'dailymotion' => 'Dailymotion'
			)
		),
		'id' => array(
			'type' => 'text',
			'label' => __('Type the video ID', 'textdomain'),
			'desc' => __('Enter the video ID from the video services', 'textdomain'),
			'std' => '7449107'
		),

            'content' => array(
                'std' => 'Your description text must be here',
                'type' => 'textarea',
                'label' => __('The Content', 'textdomain'),
                'desc' => __('Add the content', 'textdomain')
            )        		
	),
	'shortcode' => '[ct_video title="{{title}}" type="{{type}}" id="{{id}}"] {{content}} [/ct_video]',
	'popup_title' => __('Insert Video Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Soundcloud Shortcode
/*-----------------------------------------------------------------------------------*/

$ct_shortcodes['soundcloud_func'] = array(
	'no_preview' => true,
	'params' => array(
		'title' => array(
			'type' => 'text',
			'label' => __('Soundcloud Shortcode Title', 'textdomain'),
			'desc' => __('Add the title that will go above the soundcloud', 'textdomain'),
			'std' => 'Title'
		),
		'url' => array(
			'type' => 'text',
			'label' => __('Paste Link From Soundcloud', 'textdomain'),
			'desc' => __('Paste the URL from soundcloud service', 'textdomain'),
			'std' => ''
		),

		'height' => array(
			'type' => 'text',
			'label' => __('Type the height For Soundcloud', 'textdomain'),
			'desc' => __('Enter the height', 'textdomain'),
			'std' => '200'
		),

		'auto_play' => array(
			'type' => 'select',
			'label' => __('Enable/Disable Auto Play Function' , 'textdomain'),
			'desc' => __('Select Yes or No', 'textdomain'),
			'options' => array(
				'yes' => 'Yes',
				'no' => 'No'
			)
		),
            'content' => array(
                'std' => 'Your description text must be here',
                'type' => 'textarea',
                'label' => __('The Content', 'textdomain'),
                'desc' => __('Add the content', 'textdomain')
            )        		
	),
	'shortcode' => '[ct_soundcloud title="{{title}}" url="{{url}}" height="{{height}}" auto_play="{{auto_play}}"] {{content}} [/ct_soundcloud]',
	'popup_title' => __('Insert Video Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Columns Config
/*-----------------------------------------------------------------------------------*/
$ct_shortcodes['row'] = array(
	'params' => array(),
	'shortcode' => ' {{child_shortcode}} ', // as there is no wrapper shortcode
	'popup_title' => __('Insert Row (container for Columns) Shortcode', 'textdomain'),
	'no_preview' => false,
        'shortcode' => '[row] insert columns here [/row]',

);


$ct_shortcodes['columns'] = array(
	'params' => array(),
	'shortcode' => ' {{child_shortcode}} ', // as there is no wrapper shortcode
	'popup_title' => __('Insert Columns Shortcode', 'textdomain'),
	'no_preview' => true,
	
	// child shortcode is clonable & sortable
	'child_shortcode' => array(
		'params' => array(
			'column' => array(
				'type' => 'select',
				'label' => __('Column Type', 'textdomain'),
				'desc' => __('Select the type, i.e. width of the column.', 'textdomain'),
				'options' => array(
					'col-lg-1' => 'One Column',
					'col-lg-2' => 'Two Columns',
					'col-lg-3' => 'Three Columns',
					'col-lg-4' => 'Four Columns',
					'col-lg-5' => 'Five Columns',
					'col-lg-6' => 'Six Columns',
					'col-lg-7' => 'Seven Columns',
					'col-lg-8' => 'Eight Columns',
					'col-lg-9' => 'Nine Columns',
					'col-lg-10' => 'Ten Columns',
					'col-lg-11' => 'Eleven Columns',
					'col-lg-12' => 'Twelve Columns'
				)
			),
			'content' => array(
				'std' => '',
				'type' => 'textarea',
				'label' => __('Column Content', 'textdomain'),
				'desc' => __('Add the column content.', 'textdomain'),
			)
		),
		'shortcode' => '[{{column}}] {{content}} [/{{column}}]',
		'clone_button' => __('Add Column', 'textdomain')
	)
);

?>