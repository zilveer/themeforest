function cp_calculatedfieldsf_insertForm() {
    send_to_editor('[CP_CALCULATED_FIELDS]');
}

function cp_calculatedfieldsf_insertVar() {
    send_to_editor('[CP_CALCULATED_FIELDS_VAR name=""]');
}