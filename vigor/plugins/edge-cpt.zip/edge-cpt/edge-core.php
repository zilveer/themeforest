<?php
/**
 * @package Edge CPT
 * @version 1.1.2
 */
/*
Plugin Name: Edge CPT
Description: Edge CPT plugin
Author: Edge-Themes
Version: 1.1.2
*/

require_once 'bootstrap.php';

/**
 * Function that sets plugin text domain to edgt_core
 *
 * @see load_plugin_textdomain()
 */
function edgtc_text_domain() {
    load_plugin_textdomain('edgt_cpt', false, EDGE_CORE_REL_PATH.'/languages');
}

add_action('plugins_loaded', 'edgtc_text_domain');

/**
 * Function that adds class to body element so we can easily see which version of plugin is installed
 * @param $classes array of existing body classes
 * @return array array of body classes with our body class added
 */
function edgtc_body_class($classes) {
    $classes[] = 'edgt-core-'.EDGE_CORE_VERSION;

    return $classes;
}

add_action('body_class', 'edgtc_body_class');

/**
 * Function that calls CPT registration method when plugin is activated.
 * Rewrite rules needs to flushed so our custom slug for CPT can work properly
 * without saving permalinks in Settings page
 *
 * @see EdgeCPT::registerCPT()
 */
function edgtc_activation() {
    EdgeCPT::getInstance()->registerCPT();
    flush_rewrite_rules();
}

register_activation_hook(__FILE__, 'edgtc_activation');
