<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Hi there!  I\'m just a plugin, not much I can do when called directly.' );
}

/**
 * [counter] handler
 */
function youxi_shortcode_counter_handler( $atts, $content, $tag ) {

	extract( $atts, EXTR_PREFIX_ALL, 'counter' );

	return esc_html( $content ) . '<br>' . esc_html( $counter_label );
}

/**
 * [progressbar] handler
 */
function youxi_shortcode_progressbar_handler( $atts, $content, $tag ) {

	extract( $atts, EXTR_PREFIX_ALL, 'progressbar' );

	$container_classes = array( 'progress' );

	if( in_array( $progressbar_type, array( 'success', 'info', 'warning', 'danger' ), true ) ) {
		$container_classes[] = "progress-{$progressbar_type}";
	}
	if( wp_validate_boolean( $progressbar_striped ) ) {
		$container_classes[] = "progress-striped";
	}
	if( wp_validate_boolean( $progressbar_animated ) ) {
		$container_classes[] = 'progress-animated';
	}

	$container_classes = implode( ' ', $container_classes );

	$o = '<progress class="' . esc_attr( $container_classes ) . '" value="' . esc_attr( $progressbar_value ) . '" max="100">';

		$o .= '<div class="' . esc_attr( $container_classes ) . '">';

			$o .= '<div class="progress-bar" role="progressbar" aria-valuenow="' . esc_attr( $progressbar_value ) . '" aria-valuemin="0" aria-valuemax="100" style="width: ' . esc_attr( $progressbar_value ) . '%"></div>';

		$o .= '</div>';

	$o .= '</progress>';

	return $o;
}

/**
 * Define Statistic Shortcodes
 */
function define_statistic_shortcodes( $manager ) {

	/**
	 * Statistic Category
	 */
	$manager->add_category( 'statistic', array(
		'label' => esc_html__( 'Statistic Shortcodes', 'youxi' ), 
		'priority' => 30
	));

	/**
	 * [counter] shortcode
	 */
	$manager->add_shortcode( 'counter', array(
		'label' => esc_html__( 'Counter', 'youxi' ), 
		'category' => 'statistic', 
		'priority' => 10, 
		'icon' => 'fa fa-clock-o', 
		'insert_nl' => false, 
		'atts' => array(
			'label' => array(
				'type' => 'text', 
				'label' => esc_html__( 'Label', 'youxi' ), 
				'description' => esc_html__( 'Specify the counter label.', 'youxi' )
			)
		), 
		'content' => array(
			'type' => 'uispinner', 
			'label' => esc_html__( 'Value', 'youxi' ), 
			'description' => esc_html__( 'Specify the counter value.', 'youxi' ), 
			'widgetopts' => array(
				'min' => 0, 
				'step' => 0.1
			), 
			'std' => 0
		), 
		'callback' => 'youxi_shortcode_counter_handler'
	));

	/**
	 * [progressbar] shortcode
	 */
	$manager->add_shortcode( 'progressbar', array(
		'label' => esc_html__( 'Progressbar', 'youxi' ), 
		'category' => 'statistic', 
		'priority' => 20, 
		'icon' => 'fa fa-tasks', 
		'atts' => array(
			'type' => array(
				'type' => 'select', 
				'label' => esc_html__( 'Type', 'youxi' ), 
				'description' => esc_html__( 'Choose the type of the progressbar.', 'youxi' ), 
				'choices' => array(
					0         => esc_html__( 'Default', 'youxi' ), 
					'success' => esc_html__( 'Success', 'youxi' ), 
					'info'    => esc_html__( 'Info', 'youxi' ), 
					'warning' => esc_html__( 'Warning', 'youxi' ), 
					'danger'  => esc_html__( 'Danger', 'youxi' )
				), 
				'std' => 0
			), 
			'value' => array(
				'type' => 'uislider', 
				'label' => esc_html__( 'Value', 'youxi' ), 
				'description' => esc_html__( 'Specify the value of the progressbar.', 'youxi' ), 
				'std' => '100'
			), 
			'striped' => array(
				'type' => 'switch', 
				'label' => esc_html__( 'Show Stripes', 'youxi' ), 
				'description' => esc_html__( 'Switch to show stripes on the progressbar.', 'youxi' ), 
				'std' => true
			), 
			'animated' => array(
				'type' => 'switch', 
				'label' => esc_html__( 'Animate', 'youxi' ), 
				'description' => esc_html__( 'Switch to animate the progressbar.', 'youxi' ), 
				'std' => true
			)
		), 
		'callback' => 'youxi_shortcode_progressbar_handler'
	));
}

/**
 * Hook to 'youxi_shortcode_register'
 */
add_action( 'youxi_shortcode_register', 'define_statistic_shortcodes', 1 );