<?php

/*
 * Meet the Team Plugin v0.1.0
 * http://meet-the-team.jeffreycarandang.com/
 *
 * Date: Thur, 24 Jan 2013
 */

/*##################################
	CUSTOM POST TYPE
################################## */

function register_wpmtp_post_type(){
	$labels=array(
					'name' => 'Teams',
					'singular_name' => 'team',
					'add_new' => 'Add New Member',
					'add_new_item' => 'Add New Member',
					'edit_item' => 'Edit Member',
					'new_item' => 'New Member',
					'view_item' => 'View Member',
					'search_items' => 'Search Member',
					'not_found' => 'No Members Found',
					'not_found_in_trash' => 'No Members Found in Trash'
					
				);
	$supports=array('title','editor','author','thumbnail','comments','custom-fields','revisions');
		// if(WCP_OPTIONS()->orderby == "manual")
		// array_push($supports,'page-attributes');
		
	$args = array(
				'public' => true,
				'query_var' => true,
				'rewrite' => true,
				'show_in_nav_menus' => true,
				'publicly_queryable' => true,
				'has_archive' => true,
				'can_export' => true,
				'supports' => $supports,
				'exclude_from_search' => true,
				'menu_position' => 5,
				'singular_label' => 'community',
				'labels' => $labels ,
				'capability_type' => 'post',
				'register_meta_box_cb' => 'wpmtp_info_create_metabox',
				''
	);
	register_post_type('team',$args);
}
add_action('init','register_wpmtp_post_type');

function register_wpmtp_taxonomy(){
	$labels = array(
				'name' => 'Group / Categories',
				'singular_name' => 'Group',
				'search_items' => 'Search Group',
				'popular_items' => 'Popular Groups',
				'all_items' => 'All Groups' ,
				'edit_item' => 'Edit Group Information' , 
				'update_item' => 'Update Group Information',
				'add_new_item' =>  'Add New' ,
				'new_item_name' => 'New Group',
				'menu_name' => 'Group / Categories',
			);
			
	$args = array(
						'hierarchical' => true,
						'labels' => $labels,
						'show_ui' => true,
						'query_var' => true,
						'show_tagcloud' => true,
						'rewrite' => true
					);
	//Register Taxonomy				
	register_taxonomy('team-category','team',$args);
}
add_action('init','register_wpmtp_taxonomy');

function edit_wpmtp_columns( $columns ) {

	$columns = array(
		'cb' => '<input type="checkbox" />',
		'title' => __( 'Name','wpmtp' ),
		'jobtitle' => __( 'Job Title','wpmtp' ),
		'tagline' => __( 'Tagline','wpmtp' ),
		'group' => __( 'Groups / Categories','wpmtp' ),
		'socials' => __( 'Social Media','wpmtp' )
	);

	return $columns;
}
add_filter( 'manage_edit-team_columns', 'edit_wpmtp_columns' ) ;

function manage_wpmtp_columns( $column, $post_id ) {
	global $post;

	switch( $column ) {

		case 'group' :
			$terms = get_the_terms( $post_id, 'team-category' );
			if ( !empty( $terms ) ) {

				$out = array();

				foreach ( $terms as $term ) {
					$out[] = sprintf( '<a href="%s">%s</a>',
						esc_url( add_query_arg( array( 'post_type' => $post->post_type, 'team-category' => $term->slug ), 'edit.php' ) ),
						esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'team', 'display' ) )
					);
				}
				echo join( ', ', $out );
			}

			else {
				_e( 'Uncategorized','wpmtp' );
			}
			break;
		case 'jobtitle' :
			_e( get_post_meta($post_id,'_jobtitle',true) );
		break;

		case 'tagline' :
			_e( get_post_meta($post_id,'_tagline',true) );
		break;

		case 'socials' :
			$metas = get_post_meta($post_id,'', false);
			echo "<div id='wpmtp-socials'>";
			foreach($metas as $key => $meta){
				switch ($key) {

					case '_facebook':
						_e('<a href="'. $meta[0] .'" class="wpmtp-facebook" alt="Facebook" target="_blank">Facebook</a>');

						break;

					case '_twitter':
						_e('<a href="'. $meta[0] .'" class="wpmtp-twitter" alt="Twitter" target="_blank">Twitter</a>');
						break;

					case '_plus':
						_e('<a href="'. $meta[0] .'" class="wpmtp-plus" alt="Google+" target="_blank">Google+</a>');
						break;

					case '_linkedin':
						_e('<a href="'. $meta[0] .'" class="wpmtp-linkedin" alt="Linkedin" target="_blank">Linkedin</a>');;
						break;

					case '_youtube':
						_e('<a href="'. $meta[0] .'" class="wpmtp-youtube" alt="Youtube" target="_blank">Youtube</a>');
						break;

					case '_pinterest':
						_e('<a href="'. $meta[0] .'" class="wpmtp-pinterest" alt="Pinterest" target="_blank">Pinterest</a>');
						break;

					case '_flickr':
						_e('<a href="'. $meta[0] .'" class="wpmtp-flickr" alt="Flickr" target="_blank">Flickr</a>');
						break;

					case '_email':
						_e('<a href="mailto:'. $meta[0] .'" class="wpmtp-email" alt="Email">Email</a>');
						break;
					
					default:
						# code...
						break;
				}
			}
			echo "</div>";
		break;
		
		default :
			break;
	}
}
add_action( 'manage_team_posts_custom_column', 'manage_wpmtp_columns', 10, 2 );

function register_team_column_views_sortable( $newcolumn ) {
    $newcolumn['jobtitle'] = 'jobtitle';
    $newcolumn['tagline'] = 'tagline';
    return $newcolumn;
}
add_filter( 'manage_edit-team_sortable_columns', 'register_team_column_views_sortable' );

function sort_views_column( $vars ) 
{
    if ( isset( $vars['orderby'] ) ) {
    	switch ($vars['orderby']) {
    		case 'jobtitle':
    			$key = '_jobtitle';
    			break;

    		case 'tagline':
    			$key = '_tagline';
    			break;

    		default:
    			# code...
    			break;
    	}
    	if(!empty($key)){
    		$vars = array_merge( $vars, array(
	            'meta_key' => $key, //Custom field key
	            'orderby' => 'meta_value') //Custom field value (number)
	        );
    	}
    }
    return $vars;
}
add_filter( 'request', 'sort_views_column' );

function wpmtp_admin_css() { ?>
	<style>
		#wpmtp-socials a{
			display: inline-block;
			width: 24px;
			height: 24px;
			margin: 5px;
			overflow: hidden;
			text-indent: -9999px;
			vertical-align: middle;
			-o-transition: all .3s;
			-moz-transition: all .3s;
			-webkit-transition: all .3s;
			-ms-transition: all .3s;
			opacity:0.9;
		}
		#wpmtp-socials a.wpmtp-email{
			background: url('<?php echo WPMTP_IMG;?>/email.png') left top no-repeat;
		}
		#wpmtp-socials a.wpmtp-facebook{
			background: url('<?php echo WPMTP_IMG;?>/facebook.png') left top no-repeat;
		}
		#wpmtp-socials a.wpmtp-twitter{
			background: url('<?php echo WPMTP_IMG;?>/twitter.png') left top no-repeat;
		}
		#wpmtp-socials a.wpmtp-plus{
			background: url('<?php echo WPMTP_IMG;?>/googleplus.png') left top no-repeat;
		}
		#wpmtp-socials a.wpmtp-linkedin{
			background: url('<?php echo WPMTP_IMG;?>/linkedin.png') left top no-repeat;
		}
		#wpmtp-socials a.wpmtp-pinterest{
			background: url('<?php echo WPMTP_IMG;?>/pinterest.png') left top no-repeat;
		}
		#wpmtp-socials a.wpmtp-youtube{
			background: url('<?php echo WPMTP_IMG;?>/youtube.png') left top no-repeat;
		}
		#wpmtp-socials a.wpmtp-flickr{
			background: url('<?php echo WPMTP_IMG;?>/flickr.png') left top no-repeat;
		}

		#wpmtp-socials a:hover{
			background-position: left -34px;
		}
	</style>
<?php }
add_action('admin_head', 'wpmtp_admin_css');

function wpmtp_group_order() {
	// this will add the custom meta field to the add new term page
	?>
	<div class="form-field">
		<label for="term_meta[wpmtp_group_order]"><?php _e( 'Order', 'wpmtp' ); ?></label>
		<input type="text" name="term_meta[wpmtp_group_order]" id="term_meta[wpmtp_group_order]" value="">
		<p class="description"><?php _e( 'Enter a value for this field','wpmtp' ); ?></p>
	</div>
<?php
}
add_action( 'team-category_add_form_fields', 'wpmtp_group_order', 10, 2 );

// Edit term page
function wpmtp_edit_group_order($term) {
 
	// put the term ID into a variable
	$t_id = $term->term_id;
 
	// retrieve the existing value(s) for this meta field. This returns an array
	$term_meta = get_option( "taxonomy_$t_id" ); ?>
	<tr class="form-field">
	<th scope="row" valign="top"><label for="term_meta[wpmtp_group_order]"><?php _e( 'Order', 'wpmtp' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[wpmtp_group_order]" id="term_meta[wpmtp_group_order]" value="<?php echo esc_attr( $term_meta ); ?>">
			<p class="description"><?php _e( 'Enter a value for this field','wpmtp' ); ?></p>
		</td>
	</tr>
<?php
}
add_action( 'team-category_edit_form_fields', 'wpmtp_edit_group_order', 10, 2 );

// Save extra taxonomy fields callback function.
function wpmtp_save_taxonomy_order( $term_id ) {
	if ( isset( $_POST['term_meta'] ) ) {
		$t_id = $term_id;
		$term_meta = get_option( "taxonomy_$t_id" );
		$cat_keys = array_keys( $_POST['term_meta'] );
		foreach ( $cat_keys as $key ) {
			if ( isset ( $_POST['term_meta'][$key] ) ) {
				$term_meta = $_POST['term_meta'][$key];
			}
		}
		// Save the option array.
		update_option( "taxonomy_$t_id", $term_meta );
	}
}  
add_action( 'edited_team-category', 'wpmtp_save_taxonomy_order', 10, 2 );  
add_action( 'create_team-category', 'wpmtp_save_taxonomy_order', 10, 2 );
 
function wpmtp_order_columns($theme_columns) {
    $new_columns = array(
        'cb' => '<input type="checkbox" />',
        'name' => __('Name','wpmtp'),
	    'description' => __('Description','wpmtp'),
        'slug' => __('Slug','wpmtp'),
        'posts' => __('Members','wpmtp'),
        'order' => __('Order','wpmtp')
        );
    return $new_columns;
}
add_filter("manage_edit-team-category_columns", 'wpmtp_order_columns'); 
 
function wpmtp_manage_columns($out, $column_name, $term_id) {
	$term_meta = get_option( "taxonomy_$term_id" );
    switch ($column_name) {
        case 'order': 
            $out .= esc_attr( $term_meta ); 
            break;
 
        default:
            break;
    }
    return $out;    
}
add_filter("manage_team-category_custom_column", 'wpmtp_manage_columns', 10, 3);

function wpmtp_queryCustomPostType( $query ) {
	if(is_category() || is_tag() || is_tax()) {
		$post_type = get_query_var( 'post_type' );

		if( !empty( $post_type ) ) {
			$post_type = $post_type;
		} else {
			// $post_type = array( 'post', $this->post_type );
			$post_type = get_post_types();
		}
		
		$query->set( 'post_type', $post_type );

		return $query;
	}
}
add_filter( 'pre_get_posts', 'wpmtp_queryCustomPostType' );


//Create Custom Metabox
function wpmtp_info_create_metabox(){
	add_meta_box('team-info','Member Information','wpmtp_info_metabox','team','normal','high');
}

function wpmtp_info_metabox($post){

		?>
		<input type="hidden" name="wpmtp_info_nonce" value="<?php _e( wp_create_nonce(basename(__FILE__)) );?>" />
		<table id="newmeta" style="width: 100%;">
			<tbody>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_jobtitle"><?php _e('Job Title','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_jobtitle" name="wpmtp_jobtitle" size="40" value="<?php echo WPMTP_POSTMETA()->jobtitle;?>"></td>
				</tr>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_tagline"><?php _e('Tagline','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_tagline" name="wpmtp_tagline" size="40" value="<?php echo WPMTP_POSTMETA()->tagline;?>"></td>
				</tr>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_contact"><?php _e('Contact Number','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_contact" name="wpmtp_contact" size="40" value="<?php echo WPMTP_POSTMETA()->contact;?>"></td>
				</tr>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_email"><?php _e('Email Address','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_email" name="wpmtp_email" size="40" value="<?php echo WPMTP_POSTMETA()->email;?>"></td>
				</tr>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_website"><?php _e('Website / Portfolio','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_website" name="wpmtp_website" size="40" value="<?php echo WPMTP_POSTMETA()->website;?>"></td>
				</tr>

				<!-- Social Medias -->
				<tr>
					<td id="newmetaleft" class="left"><h4><?php _e('Social Media','wpmtp');?> <span>*<?php _e('add complete url value','wpmtp');?></span></h4></td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_facebook"><?php _e('Facebook','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_facebook" name="wpmtp_facebook" size="40" value="<?php echo WPMTP_POSTMETA()->facebook;?>" placeholder="http://facebook.com/username"></td>
				</tr>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_twitter"><?php _e('Twitter','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_twitter" name="wpmtp_twitter" size="40" value="<?php echo WPMTP_POSTMETA()->twitter;?>" placeholder="http://twitter.com/username"></td>
				</tr>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_plus"><?php _e('Google+','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_plus" name="wpmtp_plus" size="40" value="<?php echo WPMTP_POSTMETA()->plus;?>" placeholder="http://plus.google.com/userid"></td>
				</tr>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_linkedin"><?php _e('Linkedin','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_linkedin" name="wpmtp_linkedin" size="40" value="<?php echo WPMTP_POSTMETA()->linkedin;?>" placeholder="http://linkedin.com/pub/username"></td>
				</tr>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_youtube"><?php _e('Youtube','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_youtube" name="wpmtp_youtube" size="40" value="<?php echo WPMTP_POSTMETA()->youtube;?>" placeholder="http://youtube.com/user/username"></td>
				</tr>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_pinterest"><?php _e('Pinterest','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_pinterest" name="wpmtp_pinterest" size="40" value="<?php echo WPMTP_POSTMETA()->pinterest;?>" placeholder="http://pinterest.com/username"></td>
				</tr>
				<tr>
					<td id="newmetaleft" class="left"><label for="wpmtp_flickr"><?php _e('Flickr','wpmtp');?></label></td>
					<td><input type="text" class="widefat" id="wpmtp_flickr" name="wpmtp_flickr" size="40" value="<?php echo WPMTP_POSTMETA()->flickr;?>" placeholder="http://flickr.com/people/username"></td>
				</tr>
			</tbody>
		</table>
		<?php
}

function wpmtp_address_savemeta($post_id){
	if(isset($_POST['wpmtp_info_nonce'])){
		update_post_meta($post_id,'_jobtitle',strip_tags($_POST['wpmtp_jobtitle']));
		update_post_meta($post_id,'_tagline',strip_tags($_POST['wpmtp_tagline']));
		update_post_meta($post_id,'_contact',strip_tags($_POST['wpmtp_contact']));
		update_post_meta($post_id,'_email',strip_tags($_POST['wpmtp_email']));			
		update_post_meta($post_id,'_website',strip_tags($_POST['wpmtp_website']));

		update_post_meta($post_id,'_facebook',strip_tags($_POST['wpmtp_facebook']));
		update_post_meta($post_id,'_twitter',strip_tags($_POST['wpmtp_twitter']));
		update_post_meta($post_id,'_plus',strip_tags($_POST['wpmtp_plus']));
		update_post_meta($post_id,'_linkedin',strip_tags($_POST['wpmtp_linkedin']));			
		update_post_meta($post_id,'_youtube',strip_tags($_POST['wpmtp_youtube']));
		update_post_meta($post_id,'_pinterest',strip_tags($_POST['wpmtp_pinterest']));
		update_post_meta($post_id,'_flickr',strip_tags($_POST['wpmtp_flickr']));				
	}
}
add_action('save_post','wpmtp_address_savemeta');

function WPMTP_POSTMETA(){
	global $post;
	$meta= new stdClass;
	$meta->jobtitle=get_post_meta($post->ID,'_jobtitle',true);
	$meta->tagline=get_post_meta($post->ID,'_tagline',true);
	$meta->contact=get_post_meta($post->ID,'_contact',true);
	$meta->email=get_post_meta($post->ID,'_email',true);
	$meta->website=get_post_meta($post->ID,'_website',true);

	$meta->facebook=get_post_meta($post->ID,'_facebook',true);
	$meta->twitter=get_post_meta($post->ID,'_twitter',true);
	$meta->plus=get_post_meta($post->ID,'_plus',true);
	$meta->linkedin=get_post_meta($post->ID,'_linkedin',true);
	$meta->youtube=get_post_meta($post->ID,'_youtube',true);
	$meta->pinterest=get_post_meta($post->ID,'_pinterest',true);
	$meta->flickr=get_post_meta($post->ID,'_flickr',true);	
	
	return $meta;
}
