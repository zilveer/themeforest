<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Our Clients 2", "wish"),
    "description" => __("Our Clients 2 with Images", 'wish'),
    "controls" => "full",
    "base" => "wish_our_clients_2",
    "as_parent" => array('only' => 'wish_our_client_2_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link" => "http://i.imgur.com/eioljYX.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element

         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#fff', //Default Red color
            "description" => __( "Choose the background color", "wish" )
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Add Client", "wish"),
    "base" => "wish_our_client_2_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_our_clients_2'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "value" => "Image",
            "admin_label" => false,    
        ),

    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Our_Clients_2 extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'bgcolor'   => '#fff',
          ), $atts ) );


      $output = "<div style='background-color:{$bgcolor}'>
      <div class='clients container'>
      <div class='row'>
                    " . do_shortcode($content) . "
                
            </div>
            </div>
            </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Our_Client_2_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image'   => 'Image',
          ), $atts ) );

          $img = wp_get_attachment_image_src( $image, array(210,125) );

          if($image == "Image"){
            $imgsrc = plugins_url('images/our_client.jpg', __FILE__);
            $img[0] = $imgsrc;
          }


          $output = "<div class='col-lg-3 col-md-6 col-sm-6 animated' data-animation='flipInX' data-animation-delay='100'><img src='{$img[0]}' class='img-responsive center-block' alt=''></div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>