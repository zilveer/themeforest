<?php
/** Portfolio Post Type **/
function portfolio_post_type () {
    $labels = array (
        'name' => _x ( 'Portfolios', 'Portfolios', 'mango_core' ),
        'singular_name' => _x ( 'Portfolio', 'Portfolio', 'mango_core' ),
        'menu_name' => __ ( 'Portfolios', 'mango_core' ),
        'parent_item_colon' => __ ( 'Parent Portoflio:', 'mango_core' ),
        'all_items' => __ ( 'All Portoflios', 'mango_core' ),
        'view_item' => __ ( 'View Portoflio', 'mango_core' ),
        'add_new_item' => __ ( 'Add New Portoflio', 'mango_core' ),
        'add_new' => __ ( 'Add New', 'mango_core' ),
        'edit_item' => __ ( 'Edit Portoflio', 'mango_core' ),
        'update_item' => __ ( 'Update Portoflio', 'mango_core' ),
        'search_items' => __ ( 'Search Portoflio', 'mango_core' ),
        'not_found' => __ ( 'Not found', 'mango_core' ),
        'not_found_in_trash' => __ ( 'Not found in Trash', 'mango_core' ),
    );
    $rewrite = array (
        'slug' => 'portfolios',
        'with_front' => true,
        'pages' => true,
        'feeds' => true,
    );
    $args = array (
        'label' => __ ( 'Portfolio', 'mango_core' ),
        'description' => __ ( 'Portfolio Description', 'mango_core' ),
        'labels' => $labels,
        'supports' => array ( 'title', 'editor', 'thumbnail', 'revisions', 'comments' ),
        'taxonomies' => array ( 'portfolio-category' ),
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 5,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'rewrite' => $rewrite,
        'capability_type' => 'page',
    );
    register_post_type ( 'portfolio', $args );
    $labels = array (
        'name' => __ ( 'Portfolio Categories', 'mango_core' ),
        'singular_name' => __ ( 'Portfolio Category', 'mango_core' ),
        'search_items' => __ ( 'Search Portfolio Category', 'mango_core' ),
        'all_items' => __ ( 'All Portfolio Category', 'mango_core' ),
        'parent_item' => __ ( 'Parent Portfolio Category', 'mango_core' ),
        'parent_item_colon' => __ ( 'Parent Portfolio Category:', 'mango_core' ),
        'edit_item' => __ ( 'Edit Portfolio Category', 'mango_core' ),
        'update_item' => __ ( 'Update Portfolio Category', 'mango_core' ),
        'add_new_item' => __ ( 'Add New Portfolio Category', 'mango_core' ),
        'new_item_name' => __ ( 'New Portfolio Category', 'mango_core' ),
        'menu_name' => __ ( 'Portfolio Categories', 'mango_core' )
    );
    $args = array (
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'query_var' => true,
        'show_in_nav_menus' => true,
        'rewrite' => array (
            'slug' => 'portfolio',
            'hierarchical' => true
        )
    );
    register_taxonomy ( 'portfolio-category', 'portfolio', $args );
}
// Hook into the 'init' action
add_action ( 'init', 'portfolio_post_type', 0 );
/** Testimonials Post Type **/
function testimonials_post_type () {
    $labels = array (
        'name' => _x ( 'Testimonials', 'Testimonials', 'mango_core' ),
        'singular_name' => _x ( 'Testimonial', 'Testimonial', 'mango_core' ),
        'menu_name' => __ ( 'Testimonials', 'mango_core' ),
        'parent_item_colon' => __ ( 'Parent Testimonial:', 'mango_core' ),
        'all_items' => __ ( 'All Testimonial', 'mango_core' ),
        'view_item' => __ ( 'View Testimonial', 'mango_core' ),
        'add_new_item' => __ ( 'Add New Testimonial', 'mango_core' ),
        'add_new' => __ ( 'Add New', 'mango_core' ),
        'edit_item' => __ ( 'Edit Testimonial', 'mango_core' ),
        'update_item' => __ ( 'Update Testimonial', 'mango_core' ),
        'search_items' => __ ( 'Search Testimonial', 'mango_core' ),
        'not_found' => __ ( 'Not found', 'mango_core' ),
        'not_found_in_trash' => __ ( 'Not found in Trash', 'mango_core' ),
    );
    $rewrite = array (
        'slug' => 'testimonial',
        'with_front' => true,
        'pages' => true,
        'feeds' => true,
    );
    $args = array (
        'label' => __ ( 'Testimonial', 'mango_core' ),
        'description' => __ ( 'Testimonial Description', 'mango_core' ),
        'labels' => $labels,
        'supports' => array ( 'title', 'editor', 'revision', 'thumbnail' ),
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 6,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'rewrite' => $rewrite,
        'capability_type' => 'page',
    );
    register_post_type ( 'testimonial', $args );
}

// Hook into the 'init' action

add_action ( 'init', 'testimonials_post_type', 0 );
function clients_post_type () {
    $labels = array (
        'name' => _x ( 'Clients', 'Clients', 'mango_core' ),
        'singular_name' => _x ( 'Client', 'Client', 'mango_core' ),
        'menu_name' => __ ( 'Clients', 'mango_core' ),
        'parent_item_colon' => __ ( 'Parent Client:', 'mango_core' ),
        'all_items' => __ ( 'All Clients', 'mango_core' ),
        'view_item' => __ ( 'View Client', 'mango_core' ),
        'add_new_item' => __ ( 'Add New Client', 'mango_core' ),
        'add_new' => __ ( 'Add New', 'mango_core' ),
        'edit_item' => __ ( 'Edit Client', 'mango_core' ),
        'update_item' => __ ( 'Update Client', 'mango_core' ),
        'search_items' => __ ( 'Search Client', 'mango_core' ),
        'not_found' => __ ( 'Not found', 'mango_core' ),
        'not_found_in_trash' => __ ( 'Not found in Trash', 'mango_core' ),
    );
    $rewrite = array (
        'slug' => 'clients',
        'with_front' => true,
        'pages' => true,
        'feeds' => true,
    );
    $args = array (
        'label' => __ ( 'Clients', 'mango_core' ),
        'description' => __ ( 'Client Description', 'mango_core' ),
        'labels' => $labels,
        'supports' => array ( 'title', 'editor', 'revision', 'thumbnail' ),
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 6,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'rewrite' => $rewrite,
        'capability_type' => 'page',
    );
    register_post_type ( 'clients', $args );
}

// Hook into the 'init' action
add_action ( 'init', 'clients_post_type', 0 );

function mfields_set_default_object_terms ( $post_id, $post ) {
    if ( 'publish' === $post->post_status && $post->post_type === 'portfolio' ) {
        $defaults = array (
            'portfolio-category' => array ( 'uncategorized' )
        );
        $taxonomies = get_object_taxonomies ( $post->post_type );
        foreach ( (array)$taxonomies as $taxonomy ) {
            $terms = wp_get_post_terms ( $post_id, $taxonomy );
            if ( empty( $terms ) && array_key_exists ( $taxonomy, $defaults ) ) {
                wp_set_object_terms ( $post_id, $defaults[ $taxonomy ], $taxonomy );
            }
        }
    }
}
add_action ( 'save_post', 'mfields_set_default_object_terms', 100, 2 );

function faqs_post_type () {
    $labels = array (
        'name' => _x ( 'FAQs', 'FAQs', 'mango_core' ),
        'singular_name' => _x ( 'FAQ', 'FAQ', 'mango_core' ),
        'menu_name' => __ ( 'FAQs', 'mango_core' ),
        'parent_item_colon' => __ ( 'Parent FAQs:', 'mango_core' ),
        'all_items' => __ ( 'All FAQs', 'mango_core' ),
        'view_item' => __ ( 'View FAQs', 'mango_core' ),
        'add_new_item' => __ ( 'Add New FAQs', 'mango_core' ),
        'add_new' => __ ( 'Add New', 'mango_core' ),
        'edit_item' => __ ( 'Edit FAQs', 'mango_core' ),
        'update_item' => __ ( 'Update FAQs', 'mango_core' ),
        'search_items' => __ ( 'Search FAQs', 'mango_core' ),
        'not_found' => __ ( 'Not found', 'mango_core' ),
        'not_found_in_trash' => __ ( 'Not found in Trash', 'mango_core' ),
    );
    $rewrite = array (
        'slug' => 'faqs',
        'with_front' => true,
        'pages' => true,
        'feeds' => true,
    );
    $args = array (
        'label' => __ ( 'FAQs', 'mango_core' ),
        'description' => __ ( 'FAQs Description', 'mango_core' ),
        'labels' => $labels,
        'supports' => array ( 'title', 'editor', 'thumbnail', 'revisions' ),
        'taxonomies' => array ( 'faq-category' ),
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 5,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'rewrite' => $rewrite,
        'capability_type' => 'page',
    );
    register_post_type ( 'faq', $args );
    $labels = array (
        'name' => __ ( 'FAQs Categories', 'mango_core' ),
        'singular_name' => __ ( 'FAQs Category', 'mango_core' ),
        'search_items' => __ ( 'Search FAQs Category', 'mango_core' ),
        'all_items' => __ ( 'All FAQs Category', 'mango_core' ),
        'parent_item' => __ ( 'Parent FAQs Category', 'mango_core' ),
        'parent_item_colon' => __ ( 'Parent FAQs Category:', 'mango_core' ),
        'edit_item' => __ ( 'Edit FAQs Category', 'mango_core' ),
        'update_item' => __ ( 'Update FAQs Category', 'mango_core' ),
        'add_new_item' => __ ( 'Add New FAQs Category', 'mango_core' ),
        'new_item_name' => __ ( 'New FAQs Category', 'mango_core' ),
        'menu_name' => __ ( 'Categories', 'mango_core' )
    );
    $args = array (
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'query_var' => true,
        'show_in_nav_menus' => true,
        'rewrite' => array (
        'slug' => 'faq',
        'hierarchical' => true
        )
    );
    register_taxonomy ( 'faq-category', 'faq', $args );
}

// Hook into the 'init' action
add_action ( 'init', 'faqs_post_type', 0 );



function members_post_type () {
    $labels = array (
        'name' => _x ( 'Members', 'Members', 'mango_core' ),
        'singular_name' => _x ( 'Member', 'Member', 'mango_core' ),
        'menu_name' => __ ( 'Members', 'mango_core' ),
        'parent_item_colon' => __ ( 'Parent Members:', 'mango_core' ),
        'all_items' => __ ( 'All Members', 'mango_core' ),
        'view_item' => __ ( 'View Members', 'mango_core' ),
        'add_new_item' => __ ( 'Add New Members', 'mango_core' ),
        'add_new' => __ ( 'Add New', 'mango_core' ),
        'edit_item' => __ ( 'Edit Members', 'mango_core' ),
        'update_item' => __ ( 'Update Members', 'mango_core' ),
        'search_items' => __ ( 'Search Members', 'mango_core' ),
        'not_found' => __ ( 'Not found', 'mango_core' ),
        'not_found_in_trash' => __ ( 'Not found in Trash', 'mango_core' ),
    );
    $rewrite = array (
        'slug' => 'members',
        'with_front' => true,
        'pages' => true,
        'feeds' => true,
    );
    $args = array (
        'label' => __ ( 'Members', 'mango_core' ),
        'description' => __ ( 'Members Description', 'mango_core' ),
        'labels' => $labels,
        'supports' => array ( 'title', 'editor', 'thumbnail', 'revisions' ),
        'taxonomies' => array ( 'member-category' ),
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 5,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'rewrite' => $rewrite,
        'capability_type' => 'page',
    );
    register_post_type ( 'Member', $args );
    $labels = array (
        'name' => __ ( 'Members Categories', 'mango_core' ),
        'singular_name' => __ ( 'Members Category', 'mango_core' ),
        'search_items' => __ ( 'Search Members Category', 'mango_core' ),
        'all_items' => __ ( 'All Members Category', 'mango_core' ),
        'parent_item' => __ ( 'Parent Members Category', 'mango_core' ),
        'parent_item_colon' => __ ( 'Parent Members Category:', 'mango_core' ),
        'edit_item' => __ ( 'Edit Members Category', 'mango_core' ),
        'update_item' => __ ( 'Update Members Category', 'mango_core' ),
        'add_new_item' => __ ( 'Add New Members Category', 'mango_core' ),
        'new_item_name' => __ ( 'New Members Category', 'mango_core' ),
        'menu_name' => __ ( 'Categories', 'mango_core' )
    );
    $args = array (
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'query_var' => true,
        'show_in_nav_menus' => true,
        'rewrite' => array (
        'slug' => 'member',
        'hierarchical' => true
        )
    );
    register_taxonomy ( 'member-category', 'member', $args );
}

// Hook into the 'init' action
add_action ( 'init', 'members_post_type', 0 );



/************* create custom post *****************/
if(!function_exists('mango_menu_block')){
    function mango_menu_block(){
        $labels = array(
            'name' => __( 'Block', 'mango_core' ),
            'singular_name' => __( 'Block', 'mango_core' ),
            'add_new' => __( 'Add New', 'mango_core' ),
            'add_new_item' => __( 'Add New Block', 'mango_core' ),
            'edit_item' => __( 'Edit Block', 'mango_core' ),
            'new_item' => __( 'New Block', 'mango_core' ),
            'view_item' => __( 'View Block', 'mango_core' ),
            'search_items' => __( 'Search Block', 'mango_core' ),
            'not_found' => __( 'No block found', 'mango_core' ),
            'not_found_in_trash' => __( 'No block member found in Trash', 'mango_core' ),
            'parent_item_colon' => __( 'Parent Block:', 'mango_core' ),
            'menu_name' => __( 'Block ', 'mango_core' ),
            'all_items' => __( 'All Block ', 'mango_core' ),
            'search_items' => __( 'No block found', 'mango_core' )
        );
        $args = array(
            'labels' => $labels,
            'hierarchical' => false,
            'supports' => array( 'title', 'editor' ),
            'public' => true,
            'show_ui' => true,
            'show_in_nav_menus' => false,
            'publicly_queryable' => true,
            'exclude_from_search' => true,
            'has_archive' => false,
            'query_var' => true,
            'can_export' => true,
            'rewrite' => true,
            'menu_icon' => 'dashicons-clipboard',
        );
        register_post_type( 'block', $args );
    }
    add_action( 'init', 'mango_menu_block' );
}
?>