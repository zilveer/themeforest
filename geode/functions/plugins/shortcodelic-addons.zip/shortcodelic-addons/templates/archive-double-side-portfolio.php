<?php
/**
 * @package WordPress
 * @subpackage Geode
 * @since Geode 1.0
 */

get_header(); ?>

<?php get_template_part( 'title', 'page' ); ?>
<div class="site-content cf site-main double-side-template">

	<?php get_sidebar(apply_filters('scadd_sidebar-2','extra')); ?>

	<div id="primary" class="alignleft" data-delay="0">
		<div id="content" role="main">
			<div class="sc-grid cf" data-grid="<?php echo sc_data_grid(); ?>">

				<?php if ( have_posts() ) :

						while ( have_posts() ) : the_post();

							sc_get_template_part( 'content', 'standard' );

						endwhile;

					else :
						sc_get_template_part( 'content', 'standard' );

					endif;
				?>
			</div><!-- .sc-grid -->
		</div><!-- #content -->
	</div><!-- #primary -->

	<?php get_sidebar(); ?>
</div><!-- .site-content -->

<?php get_footer(); ?>