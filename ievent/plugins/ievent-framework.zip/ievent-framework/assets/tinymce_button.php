<?php 

	/* Add Shortcode Buttons ---------------------------------------------*/
	add_action('init', 'olen_add_button'); 
	function olen_add_button() { 
	 global $data; 
	  if ( current_user_can('edit_posts') && current_user_can('edit_pages') ) 
	  { 
			if ( get_user_option('rich_editing') == 'true') { 	
				add_filter('mce_external_plugins', 'olen_add_plugin'); 
				add_filter('mce_buttons_2', 'olen_register_button'); 
			} 
		} 
	} // EOF add_button
	
	
	/* Register Shortcode Buttons ---------------------------------------------*/
	
	function olen_register_button($buttons) { 
     array_push($buttons,"|","shortcode_dropdown"); 
     return $buttons; 
 	} // EOF register_button
	
	
	/* Add Shortcode Plugin ---------------------------------------------------*/
	function olen_add_plugin($plugin_array) {			
		if(get_bloginfo('version') > 3.8):
			$plugin_array['shortcode_dropdown'] = plugin_dir_url( __file__ ).'js/shortcodes-3.9.js';
		else:
			$plugin_array['shortcode_dropdown'] = plugin_dir_url( __file__ ).'js/shortcodes.js';
		endif;
		
		return $plugin_array; 
	}// EOF add_plugin
	
	
	function add_shortcode_menu() {
?>	

<div class="hidden" style="display:none">
<div class="shortcode-html">
	<a href="javascript:;" class="button-add-shortcode">[+]</a>
	<ul> 
        <li><a href="#" data-all='[partners_logo post_count="5"][/partners_logo]'>Partners Logo</a></li>
        
        <li><a href="#" data-all='[portfolio box_pos_1="1" box_title_1="25 Jan" box_subtitle_1="Day 1" box_pos_2="6" box_title_2="26 Jan" box_subtitle_2="Day 2" box_pos_3="12" box_title_3="27 Jan" box_subtitle_3="Day 3" post_count="16"][/portfolio]'>Portfolio</a></li>
        
        <li><a href="#" data-all='[service_box_group color_style="light , dark"]<br/>[service_box icon="icon-paper-plane" title="Discussion Board"][/service_box]<br/>[/service_box_group]' data-tag='service_box' data-all="" data-text="Messages text">Service Box</a></li>
        
        <li><a href="#" data-all='[media_center color_style="light , dark" post_count="3"][/media_center]' data-tag='media_center' data-all="" data-text="Messages text">Media Center</a></li>
        
        <li><a href="#" data-all='[speakers title="Meet Our" bold_title="Speakers" count="8"]Your Description[/speakers]'>Speakers</a></li>
        
        <li><a href="#" data-param='' data-tag='subscribe' data-all="" data-text="Messages text">Subscribe</a></li> 
        
        <li><a href="#" data-all='[section_title_group style="Style-A , Style-B" color_style="light , dark"]<br/>[section_title icon="icon-pencil" title="HURRY UP"][/section_title]<br/>[/section_title_group]'>Section Title</a></li>
        
        <li><a href="#" data-all='[interactive_map_group image="http://janxcode.com/ievent/images/exhibition-floor.png"]<br/>[interactive_point title="Section A" description=" Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae distinctio esse placeat minus fugit, voluptate, quos, ea, nisi temporibus repudiandae perspiciatis natus quasi ipsa corrupti ipsum amet facere ut nihil."][/interactive_point]<br/>[/interactive_map_group]'>Interactive Map</a></li>
        
        <li><a href="#" data-all='[exhibition_placeholder_group]<br/>[exhibition_placeholder]<br/>[exhibition_placeholder_point title="01.Rocko Co."][/exhibition_placeholder_point]<br/>[/exhibition_placeholder]<br/>[/exhibition_placeholder_group]'>Exhibition Placeholder</a></li>
        
        <li><a href="#" data-all='[tabs_group]<br/>[tab][/tab]<br/>[subtabs_group]<br/>[subtabs]<br/>[tabs_point][/tabs_point]<br/>[/subtabs]<br/>[/subtabs_group]<br/>[/tabs_group]'>Tabs</a></li>
        
        <li><a href="#" data-all='[contact_us email""][/contact_us]'>Contact Us</a></li>
        <li><a href="#" data-all='[map title="VENUE" description="Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. montes" place_name="MAriot Hotel, Browadway" address_a="339 Marina Street, New York, NY 10001" address_b="1 987 586-45432" address_c="4.9 mi / 7.9 km from Downtown"][/map]'>Maps</a></li> 
        
        <li><a href="#" data-param='' data-tag='registration' data-all="" data-text="Messages text">Registration</a></li> 
        
        <li><a href="#" data-param='title="" description="" event_date="" event_time="" btn_text="" btn_link=""' data-tag='countdown' data-all="" data-text="Messages text">Countdown</a></li> 
                
        <li><a href="#" data-all='[faq_group]<br/>[faq color_style="light , dark" description="Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu." title="Q1: Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor" according="open , close"]Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.[/faq]<br/>[/faq_group]'>FAQ</a></li>
        
        <li><a href="#" data-param='id="about" container_class="" bg_color="white" jx_tint="jx-ievent-tint-black" bg_image="http://ievent.janxcode.com/wp-content/uploads/2015/09/portfolio_24.jpg" bg_pos="0px -274px" bg_icon="fa-quote-left" padding="jx-padding" class="jx-ievent-countdown-form"' data-tag='container' data-all="" data-text="Messages text">Container</a></li> 
        
        
        <li><a href="#" data-all='[price_table_group]<br/>[price_table standard_price="149" standard_sub_price="99" standard_package_name="Basic"  standard_feature_a="Conference Tickets" standard_feature_b="Easy Access" standard_feature_c="Printed Materials" vip_price="255" vip_sub_price="99" vip_package_name="Basic"  vip_feature_a="Conference Tickets" vip_feature_b="Easy Access" vip_feature_c="Printed Materials"][/price_table]<br/>[/price_table_group]'>Price Table</a></li>
        
        <li><a href="#" data-all='[testimonials post_count="4"][/testimonials]'>Testimonials</a></li>
        
        <li><a href="#" data-all='[counter_up_group color_style="light , dark"]<br/>[counter_up count_up="3,400" count_up_text="Developers" count_up_icon="icon-paper-plane"][/counter_up]<br/>[/counter_up_group]'>Counter Up</a></li>
        
        <li><a href="#" data-all='[slider_group]<br/>[slider image="http://janxcode.com/ievent/images/slide-2.jpg" date="25" month="Jan"]<br/>[/slider]<br/>[/slider_group]'>Slider</a></li>
        <li><a href="#" data-all='[event_box start_date="25" end_date="27" month="Jan 2015" pretitle="2015 ANNUAL Conference" title="Wordpress and Hackers" location="Manama, Kingdom of Bahrain"][/event_box]'>Event Box</a></li>
        <li><a href="#" data-all='[event_play pretitle="2015 ANNUAL Conference" title="Wordpress and Hackers" location="Manama, Kingdom of Bahrain" video_link=""][/event_play]'>Event Play</a></li>
        <li><a href="#" data-all='[event_counter start_date="25" end_date="27" month="Jan 2015" pretitle="2015 ANNUAL Conference" title="Wordpress and Hackers"][/event_counter]'>Event Counter</a></li>
        <li><a href="#" data-all='[event_form type="1 , 2" start_date="25" end_date="27" month="Jan 2015" pretitle="2015 ANNUAL Conference" title="Wordpress and Hackers"][/event_form]'>Event Form</a></li>
        <li><a href="#" data-all='[info_bar icon="icon-calendar" title="DATE" description="25-27 Jan 2015"][/info_bar]'>Info Bar</a></li>
        
        

	</ul>
</div>
</div>

<?php 
}
add_action('admin_head', 'add_shortcode_menu');

?>