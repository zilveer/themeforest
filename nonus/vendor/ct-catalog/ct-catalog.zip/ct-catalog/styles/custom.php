<?php
$chosenClass = get_option('wc_catalog_mode_' . $value . 'class');
if (!$chosenClass) {
    //default values
    //Colors
    ($btnBgClr == "") ? $btnBgClr = '#47a9e6' : $btnBgClr = $btnBgClr;
    ($btnBgClrHover == "") ? $btnBgClrHover = '#299be2' : $btnBgClrHover = $btnBgClrHover;
    ($btnTxtClr == "") ? $btnTxtClr = '#ffffff' : $btnTxtClr = $btnTxtClr;

    //Border
    ($btnThicknessValue == "") ? $btnThicknessValue = '1' : $btnThicknessValue = $btnThicknessValue;
    ($btnRadiusValue == "") ? $btnRadiusValue = '4' : $btnRadiusValue = $btnRadiusValue;
    ($btnBorderClr == "") ? $btnBorderClr = '#3e9cd7' : $btnBorderClr = $btnBorderClr;
    ($btnBorderClrHover == "") ? $btnBorderClrHover = '#3e9cd7' : $btnBorderClrHover = $btnBorderClrHover;

    //Padding
    ($btpTop == "") ? $btpTop = '10' : $btpTop = $btpTop;
    ($btpRight == "") ? $btpRight = '20' : $btpRight = $btpRight;
    ($btpBottom == "") ? $btpBottom = '10' : $btpBottom = $btpBottom;
    ($btpLeft == "") ? $btpLeft = '20' : $btpLeft = $btpLeft;

}
?>

<style type="text/css">
    .ct-custom-click.click-link-btn.<?php echo $value; ?> {
        background: <?php echo $btnBgClr; ?> !important;
        color: <?php echo $btnTxtClr; ?> !important;
        text-decoration: none !important;
        border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -moz-border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -webkit-border-radius: <?php echo $btnRadiusValue; ?>px !important;
        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClr; ?> !important;
        margin: <?php echo $btmTop; ?>px <?php echo $btmRight; ?>px <?php echo $btmBottom; ?>px <?php echo $btmLeft; ?>px !important;
        padding: <?php echo $btpTop; ?>px <?php echo $btpRight; ?>px <?php echo $btpBottom; ?>px <?php echo $btpLeft; ?>px !important;
        box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        display: inline-block; !important;
        text-align: center !important;

    }
    .ct-custom-click.click-link-btn.small.<?php echo $value; ?> {
        display: block !important;
        text-align: center !important;
    }

    .ct-custom-click.click-link-btn.<?php echo $value; ?>:hover {
        background: <?php echo $btnBgClrHover; ?> !important;
        color: <?php echo $btnTxtClrHover; ?> !important;
        text-decoration: none !important;
        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClrHover; ?> !important;
    }
</style>