<?php
vc_map ( array (
		"name" => 'Bubble',
		"base" => "tb_bubble",
		"icon" => "tb-icon-for-vc",
		"category" => __ ( 'Aqua', 'jwsthemes' ),
		"params" => array (
				array (
						"type" => "textfield",
						"holder" => "div",
						"heading" => __ ( 'Author', 'jwsthemes' ),
						"param_name" => "author",
						"value" => '',
						"description" => __ ( 'Please, enter author for bubble.', 'jwsthemes' )
				),
				array (
						"type" => "colorpicker",
						"heading" => __ ( 'Color', 'jwsthemes' ),
						"param_name" => "color",
						"value" => '',
						"description" => __ ( 'Select color for bubble.', 'jwsthemes' )
				),
				array (
						"type" => "colorpicker",
						"heading" => __ ( 'Background', 'jwsthemes' ),
						"param_name" => "background",
						"value" => '',
						"description" => __ ( 'Select background color for bubble.', 'jwsthemes' )
				),
				array (
						"type" => "textfield",
						"heading" => __ ( 'Border Width', 'jwsthemes' ),
						"param_name" => "border_width",
						"value" => '',
						"description" => __ ( 'Please, enter number with "px" of border for bubble.', 'jwsthemes' )
				),
				array (
						"type" => "colorpicker",
						"heading" => __ ( 'Border Color', 'jwsthemes' ),
						"param_name" => "border_color",
						"value" => '',
						"description" => __ ( 'Select color of border for bubble.', 'jwsthemes' )
				),
				array (
						"type" => "dropdown",
						"heading" => __ ( 'Border Style', 'jwsthemes' ),
						"param_name" => "border_style",
						"value" => array('none','hidden','dotted','dashed','solid','double','groove','ridge','inset','outset','initial','inherit'),
						"description" => __ ( 'Select style of border for bubble.', 'jwsthemes' )
				),
				array (
						"type" => "textfield",
						"heading" => __ ( 'Padding', 'jwsthemes' ),
						"param_name" => "padding",
						"value" => '',
						"description" => __ ( 'Please, enter number with "px" of padding for bubble.', 'jwsthemes' )
				),
				array (
						"type" => "textarea_html",
						"heading" => __ ( 'Content', 'jwsthemes' ),
						"param_name" => "content",
						"value" => '',
						"description" => __ ( 'Please, enter content for bubble.', 'jwsthemes' )
				)
		)
) );