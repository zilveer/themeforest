<?php

/* ************************************************************************************** 
	Logos Post Type
************************************************************************************** */

add_action( 'init', 'swm_posttype_logos' );
if (!function_exists('swm_posttype_logos')) {
	function swm_posttype_logos() {	
		$labels = array(
			'name' => __( 'Logos', 'swmtranslate'),
			'singular_name' => __( 'Logo' , 'swmtranslate'),
			'add_new' =>  __( 'Add New' , 'swmtranslate'),
			'add_new_item' => __('Add New Logo', 'swmtranslate'),
			'edit_item' => __('Edit Logo', 'swmtranslate'),
			'new_item' => __('New Logo Item', 'swmtranslate'),
			'view_item' => __('View Logo Item', 'swmtranslate'),
			'search_items' => __('Search Logos', 'swmtranslate'),
			'not_found' =>  __('No logo items found', 'swmtranslate'),
			'not_found_in_trash' => __('No logo items found in Trash', 'swmtranslate'),
			'parent_item_colon' => ''
		);
		  
		$args = array(
			'labels' => $labels,
			'public' => true,
			'exclude_from_search' => false,
			'publicly_queryable' => true,
			'rewrite' => array('slug' => 'client-logos'),
			'show_ui' => true, 
			'query_var' => true,
			'capability_type' => 'post',
			'hierarchical' => false,		
			'menu_position' => null,
			'supports' => array('title','thumbnail')
		); 
		  
		register_post_type(__( 'logos' , 'swmtranslate'),$args);	
		
	}
}
/* ------------------------------------------------------------------------------ */	

add_action( 'init', 'swm_posttype_logo_taxonomies', 0 );
if (!function_exists('swm_posttype_logo_taxonomies')) {
	function swm_posttype_logo_taxonomies(){
		
		register_taxonomy(__( "logo_category" , 'swmtranslate'), 
			array(__( "logos" , 'swmtranslate'),), 
			array(
				"hierarchical" => true, 
				"query_var" => true, 
				"rewrite" => array(
					'slug' => 'logo_category', 
					'hierarchical' => true, 
					'with_front' => false )
			)); 
		
	}
}

/* ------------------------------------------------------------------------------ */
 
add_filter("manage_edit-logos_columns", "swm_posttype_logos_edit_columns"); 
if (!function_exists('swm_posttype_logos_edit_columns')) {
	function swm_posttype_logos_edit_columns($columns){  
		$columns = array(  
			"cb" => "<input type=\"checkbox\" />",  
			"title" => __( 'Logo Title' , 'swmtranslate'),			
			"Image" => __( 'Image' , 'swmtranslate'),
			"Category" => __( 'Category' , 'swmtranslate')
		); 
		return $columns;  
	} 
}	
/* ------------------------------------------------------------------------------ */
	
add_action("manage_posts_custom_column",  "swm_posttype_logos_image_column");	
if (!function_exists('swm_posttype_logos_image_column')) {  
	function swm_posttype_logos_image_column($column){  
		global $post;  
		switch ($column)  {
			
			case "title":  
				echo get_the_title();  
				break;	

			case 'Category':  
				echo wp_strip_all_tags( get_the_term_list($post->ID, 'logo_category', '', ', ',''));  
				break;		
		}  
	}
}
/* Edit "Featured Image" box text --------------------------------------------------- */

add_filter( 'gettext', 'logos_post_edit_change_text', 20, 3 );
if (!function_exists('logos_post_edit_change_text')) {
	function logos_post_edit_change_text( $translated_text, $text, $domain ) {
	    if( ( is_logos_admin_page() ) ) {
	         switch( $translated_text ) {
	        case 'Featured Image' :
	            $translated_text = __( 'Add Logo Image', 'circle-carousel' );
	        break;
	        case 'Set Featured Image' :
	            $translated_text = __( 'Set Logo image', 'circle-carousel' );
	        break;
	        case 'Set featured image' :
	            $translated_text = __( 'Set logo image', 'circle-carousel' );
	        break;
	        case 'Remove featured image' :
	            $translated_text = __( 'Remove logo image', 'circle-carousel' );
	        break;
	        }
	    }
	    return $translated_text;
	}
}

if (!function_exists('is_logos_admin_page')) {
	function is_logos_admin_page() {
	    global $pagenow;

	    if( $pagenow == 'post-new.php' ) {
	        if( isset( $_GET['post_type'] ) && $_GET['post_type'] == 'logos' )
	            return true;
	    }

	    if( $pagenow == 'post.php' ) {
	        if( isset( $_GET['post'] ) && get_post_type( $_GET['post'] ) == 'logos' )
	            return true;
	    }
	    return false;
	}
}
if( defined( 'DOING_AJAX' ) && 'DOING_AJAX' ) {
    if( isset( $_POST['post_id'] ) && get_post_type( $_POST['post_id'] ) == 'logos' )
        return true;
}