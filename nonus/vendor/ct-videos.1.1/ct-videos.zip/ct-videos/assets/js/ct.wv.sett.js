jQuery( function ( $ ) {


    //add class to settings page
    $('.ct-woovideo-setting').closest('form#mainform').find('table.form-table').addClass('ct-woovideo-settings-table');

    //view labels on settings page
    $('.ct-woovideo-settings-table .ct-woovideo-settings-icon').parent().addClass('ct-woovideo-settings-icon-label');


    //create upload video buttons
    var upload_videos = $.find('.ct-woovideo-settings-upload-video');

    $.each(upload_videos, function() {
        $this = $(this);

        var id = $this.attr('id');
        var text = ct_woovideo_admin_videos.upload_list_video;
        var desc = $this.next('.description');

        $this.parent().prepend("<a href='#' class='button ct-woovideo-upload-video-button' rel='product_list'>" + text + "</a>");
        $this.css('display', 'none');

        if (desc.text() != ' ') {
            desc.append('<a href="#" class="ct-woovideo-remove-uploaded-video-button"></a>');
        }
    });

    //upload video button
    var upload_video_frame;
    var setting_video;

    $('.ct-woovideo-settings-table').on( 'click', '.ct-woovideo-upload-video-button', function ( event ) {

        var $button                = $( this );
        var $parent                = $button.closest( '.forminp' );
        setting_video    = $parent;

        event.preventDefault();

        // If the media frame already exists, reopen it.
        if ( upload_video_frame ) {
            upload_video_frame.open();
            return;
        }

        // Create the media frame.
        upload_video_frame = wp.media.frames.video = wp.media({
            // Set the title of the modal.
            title: ct_woovideo_admin_videos.i18n_choose_video,
            button: {
                text: ct_woovideo_admin_videos.i18n_set_video
            },
            multiple: false,
            type: 'video',
            library: {type: 'video'},
            states : [
                new wp.media.controller.Library({
                    title: ct_woovideo_admin_videos.i18n_choose_video,
                    filterable :	'all'
                })
            ]

        });

        upload_video_frame.on( 'select', function () {

            var attachment = upload_video_frame.state().get( 'selection' ).first().toJSON();

            setting_video.find( '.description' ).text( attachment.filename)
                .append('<a href="#" class="ct-woovideo-remove-uploaded-video-button"></a>');
            setting_video.find( '.ct-woovideo-settings-upload-video' ).val( attachment.id );

        });

        // Finally, open the modal.
        upload_video_frame.open();

    });

    //'remove uploaded video' button
    $('.ct-woovideo-settings-table').on( 'click', '.ct-woovideo-remove-uploaded-video-button', function ( event ) {
        var $button      = $( this );
        var $parent      = $button.closest( '.forminp' );

        event.preventDefault();

        $parent.find( '.description' ).text( ' ' );
        $parent.find( '.ct-woovideo-settings-upload-video' ).val( '' );
        $parent.find( '.ct-woovideo-remove-uploaded-video-button' ).detach();

    });

});
