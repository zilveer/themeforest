<section class="slider3 p%PATTERN%">
  <div class="slider">
