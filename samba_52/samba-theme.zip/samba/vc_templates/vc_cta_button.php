<?php
global $prk_samba_frontend_options;
if ($prk_samba_frontend_options['samba_light_vc']=="yes") {
    /**
     * WPBakery Visual Composer shortcodes
     *
     * @package WPBakeryVisualComposer
     *
     */
    $color = $icon = $size = $target = $href = $title = $call_text = $call_desc= $position = $el_class = $text_align='';
    extract(shortcode_atts(array(
        'color' => 'theme_button',
        'icon' => 'none',
        'size' => '',
        'target' => '',
        'href' => '',
        'title' => __('Text on the button', "js_composer"),
        'call_text' => '',
        'call_desc' => '',
        'text_align' => '',
        'button_align' => '',
        'position' => 'cta_align_right',
        'el_class' => '',
        'bk_color' => ''
    ), $atts));
    $output = '';

    $el_class = $this->getExtraClass($el_class);

    if ( $target == 'same' || $target == '_self' ) { $target = ''; }
    if ( $target != '' ) { $target = ' target="'.$target.'"'; }

    $icon = ( $icon != '' && $icon != 'none' ) ? ' '.$icon : '';
    $i_icon = ( $icon != '' ) ? ' <i class="icon"> </i>' : '';
    if ($color!="theme_button" && $color!="theme_button_inverted")
        $color = ( $color != '' ) ? ' wpb_'.$color : '';
    else {
        $sizar=" ".$size;
    }


    $size = ( $size != '' && $size != 'wpb_regularsize' ) ? ' wpb_'.$size : ' '.$size;

    $a_class = '';
    if ( $el_class != '' ) {
        $tmp_class = explode(" ", $el_class);
    }
    
    if ( $href != '' ) {
        if ($color!="theme_button" && $color!="theme_button_inverted") 
        {
            $button = '<span class="wpb_button '.$color.$size.$icon.'">'.$title.$i_icon.'</span>';
            if ( $position == 'cta_align_bottom' ) 
            {
                $button = '<div class="twelve columns '.$button_align.'"><a class="wpb_button_a'.$a_class.'" href="'.$href.'"'.$target.'>' . $button . '</a></div>';
                $prk_cols="twelve columns ";
            }
            else 
            {
                $button = '<div class="four columns '.$button_align.'"><a class="wpb_button_a'.$a_class.'" href="'.$href.'"'.$target.'>' . $button . '</a></div>';
                $prk_cols="eight columns ";
            }
        }
        else
        {
            if ( $position == 'cta_align_bottom' ) 
            {
                $button = '<div class="twelve columns '.$button_align.'"><div class="'.$color.$sizar.'"><a href="'.$href.'"'.$target.'>' . $title . '</a></div></div>';
                $prk_cols="twelve columns ";
            }
            else 
            {
                $button = '<div class="four columns '.$button_align.'"><div class="'.$color.$sizar.'"><a href="'.$href.'"'.$target.'>' . $title . '</a></div></div>';
                $prk_cols="eight columns ";
            }
        }
        
    } else {
        //$button = '<button class="wpb_button '.$color.$size.$icon.'">'.$title.$i_icon.'</button>';
        $button = '';
        $el_class .= ' cta_no_button';
        $prk_cols="twelve columns ";
    }
    $css_class = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'wpb_call_to_action wpb_content_element clearfix '.$position.$el_class, $this->settings['base']);

    $custom_style='';
    if ($bk_color!="")
    {
        $custom_style=' style="background-color:'.$bk_color.';"';
    }

    $output .= '<div class="'.$css_class.'"'.$custom_style.'>';
    $output .= '<div class="row">';
    if ( $position == 'cta_align_left' )
    { 
        $output .= $button;
    }
    $output.='<div class="'.$prk_cols.''.$text_align.'">';
    $output .= apply_filters('wpb_cta_text', '<div class="wpb_call_text zero_color bd_headings_text_shadow twelve"><h3 class="header_font small">'. $call_text . '</h3></div><div class="clearfix"></div>', array('content'=>$call_text));
    $output .= '<div class="wpb_call_desc">'. $call_desc . '</div>';
    $output.='</div>';
    if ( $position != 'cta_align_left' )
    {
        $output .= $button;
    }
    $output.='</div>';
    $output .= '</div> ' . $this->endBlockComment('.wpb_call_to_action') . "\n";

    echo $output;
}
else {
    /**
     * Shortcode attributes
     * @var $atts
     * @var $color
     * @var $icon
     * @var $size
     * @var $target
     * @var $href
     * @var $title
     * @var $call_text
     * @var $position
     * @var $el_class
     * @var $css_animation
     * Shortcode class
     * @var $this WPBakeryShortCode_VC_Cta_button
     */
    $output = '';
    $atts = vc_map_get_attributes( $this->getShortcode(), $atts );
    extract( $atts );

    $el_class = $this->getExtraClass( $el_class );

    if ( 'same' === $target || '_self' === $target ) {
        $target = '';
    }
    if ( '' !== $target ) {
        $target = ' target="' . $target . '"';
    }

    $icon = ( '' !== $icon && 'none' !== $icon ) ? ' ' . $icon : '';
    $i_icon = ( '' !== $icon ) ? ' <i class="icon"> </i>' : '';

    $color = ( '' !== $color ) ? ' wpb_' . $color : '';
    $size = ( '' !== $size && $size !== 'wpb_regularsize' ) ? ' wpb_' . $size : ' ' . $size;

    $a_class = '';
    if ( '' !== $el_class ) {
        $tmp_class = explode( ' ', $el_class );
        if ( in_array( 'prettyphoto', $tmp_class ) ) {
            wp_enqueue_script( 'prettyphoto' );
            wp_enqueue_style( 'prettyphoto' );
            $a_class .= ' prettyphoto';
            $el_class = str_ireplace( 'prettyphoto', '', $el_class );
        }
    }

    if ( '' !== $href ) {
        $button = '<span class="wpb_button ' . $color . $size . $icon . '">' . $title . $i_icon . '</span>';
        $button = '<a class="wpb_button_a' . $a_class . '" href="' . $href . '"' . $target . '>' . $button . '</a>';
    } else {
        $button = '';
        $el_class .= ' cta_no_button';
    }
    $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'wpb_call_to_action wpb_content_element vc_clearfix ' . $position . $el_class, $this->settings['base'], $atts );
    $css_class .= $this->getCSSAnimation( $css_animation );

    $output .= '<div class="' . $css_class . '">';
    if ( 'cta_align_bottom' !== $position ) {
        $output .= $button;
    }
    $output .= apply_filters( 'wpb_cta_text', '<h2 class="wpb_call_text">' . $call_text . '</h2>', array( 'content' => $call_text ) );
    if ( 'cta_align_bottom' === $position ) {
        $output .= $button;
    }
    $output .= '</div>';

    echo $output;
}
