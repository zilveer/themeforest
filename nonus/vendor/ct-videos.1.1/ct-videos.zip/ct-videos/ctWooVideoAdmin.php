<?php
/**
 * Adds the Product Video Settings section
 * @author: createIT
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class ctWooVideoAdmin {

    public function __construct() {

        add_filter('woocommerce_product_data_tabs', array( $this, 'addAdminProductVideoTab'));
        add_action('woocommerce_product_data_panels', array( $this, 'adminProductVideoPanel'));

        //AJAX functions
        add_action('wp_ajax_ct_woovideo_add_video', array( $this, 'addVideoButton'));
        add_action('wp_ajax_ct_woovideo_remove_video', array( $this, 'removeVideoButton'));
        add_action('wp_ajax_ct_woovideo_save_videos', array( $this, 'saveVideos'));
        add_action('wp_ajax_ct_woovideo_show_shortcode', array( $this, 'showVideoShortcode'));
        add_action('wp_ajax_ct_woovideo_show_button_shortcode', array( $this, 'showButtonShortcode'));
        add_action('wp_ajax_ct_woovideo_restore_defaults', array( $this, 'restoreDefaults'));

    }

    /**
     * Add video via ajax function
     */

    public function addVideoButton() {

        check_ajax_referer( 'add-video', 'security' );

        $thepostid = intval( $_POST['post_id'] );
        $loop = intval( $_POST['loop'] );
        $id_loop = get_post_meta($thepostid, '_ct_woovideo_loop', true);

        $id_loop = (int)$id_loop + 1;
        update_post_meta( $thepostid,'_ct_woovideo_loop', $id_loop);
        $id_loop = get_post_meta($thepostid, '_ct_woovideo_loop', true);


        $video = apply_filters('ct_woovideo_attributes', array(
            '_id' => $id_loop,
            '_parent_id' => $thepostid,
            '_global_video_id' => $thepostid . '_' . $id_loop,
            '_title' => '#' . $id_loop,
            '_location' => (get_option('wc_ct_woovideo_location')) ? get_option('wc_ct_woovideo_location') : 'tab',
            '_gallery_location' => (get_option('wc_ct_woovideo_gallery_location')) ? get_option('wc_ct_woovideo_gallery_location') : 'above',
            '_video_location_priority' => (get_option('wc_ct_woovideo_video_location_priority')) ? get_option('wc_ct_woovideo_video_location_priority') : 100,
            '_position' => '',
            '_video_shortcode' => "[ct_woovideo id='$id_loop']",
            '_external_url' => null,
            '_iframe_url' => null,
            '_custom_video_class' => (get_option('wc_ct_woovideo_video_class')) ? get_option('wc_ct_woovideo_video_class') : '',

            //inline video settings
            '_video_align' => (get_option('wc_ct_woovideo_video_align')) ? get_option('wc_ct_woovideo_video_align') : 'none',
            '_video_clearing' => (get_option('wc_ct_woovideo_video_clearing')) ? get_option('wc_ct_woovideo_video_clearing') : 'no',
            '_video_autoplay' => (get_option('wc_ct_woovideo_video_autoplay')) ? get_option('wc_ct_woovideo_video_autoplay') : 'no',
            '_video_margin_left' => (get_option('wc_ct_woovideo_video_margin_left')) ? get_option('wc_ct_woovideo_video_margin_left') : 0,
            '_video_margin_top' => (get_option('wc_ct_woovideo_video_margin_top')) ? get_option('wc_ct_woovideo_video_margin_top') : 0,
            '_video_margin_right' => (get_option('wc_ct_woovideo_video_margin_right')) ? get_option('wc_ct_woovideo_video_margin_right') : 0,
            '_video_margin_bottom' => (get_option('wc_ct_woovideo_video_margin_bottom')) ? get_option('wc_ct_woovideo_video_margin_bottom') : 0,

            //thumbnail settings
            '_thumbnail_id' => null,
            '_image' => null,
            '_image_url' => null,
            '_thumbnail_icon' => (get_option('wc_ct_woovideo_select_icon')) ? get_option('wc_ct_woovideo_select_icon') : 'play-circle-o',
            '_icon_size' => (get_option('wc_ct_woovideo_icon_size')) ? get_option('wc_ct_woovideo_icon_size') : '80',
            '_icon_position' => (get_option('wc_ct_woovideo_icon_position')) ? get_option('wc_ct_woovideo_icon_position') : 'center',
            '_icon_opacity' => (get_option('wc_ct_woovideo_icon_opacity')) ? get_option('wc_ct_woovideo_icon_opacity') : '5',

            //mp4
            '_upload_video_mp4_id' => null,
            '_upload_video_mp4_url' => null,
            '_upload_video_mp4_name' => '',
            //webm
            '_upload_video_webm_id' => null,
            '_upload_video_webm_url' => null,
            '_upload_video_webm_name' => '',
            //ogg
            '_upload_video_ogg_id' => null,
            '_upload_video_ogg_url' => null,
            '_upload_video_ogg_name'=> '',

            '_video_url' => null,

            //player settings
            '_player_height' => (get_option('wc_ct_woovideo_player_height')) ? get_option('wc_ct_woovideo_player_height') : 0,
            '_player_width' => (get_option('wc_ct_woovideo_player_width')) ? get_option('wc_ct_woovideo_player_width') : 0,

            //button_settings
            '_button_location' => (get_option('wc_ct_woovideo_button_location')) ? get_option('wc_ct_woovideo_button_location') : 'above_tabs',
            '_button_location_priority' => (get_option('wc_ct_woovideo_button_location_priority')) ? get_option('wc_ct_woovideo_button_location_priority') : 100,
            '_video_button_shortcode' => "[ct_woovideo_button id='$id_loop']",
            '_button_color' => (get_option('wc_ct_woovideo_button_color')) ? get_option('wc_ct_woovideo_button_color') : '',
            '_button_text_color' => (get_option('wc_ct_woovideo_button_text_color')) ? get_option('wc_ct_woovideo_button_text_color') : '#000000',
            '_button_label' => (get_option('wc_ct_woovideo_button_label')) ? get_option('wc_ct_woovideo_button_label') : 'custom',
            '_custom_button_label' => (get_option('wc_ct_woovideo_custom_button_label')) ? get_option('wc_ct_woovideo_custom_button_label') : 'Video',
            '_button_align' => (get_option('wc_ct_woovideo_button_align')) ? get_option('wc_ct_woovideo_button_align') : 'left',
            '_button_clearing' => (get_option('wc_ct_woovideo_button_clearing')) ? get_option('wc_ct_woovideo_button_clearing') : 'no',
            '_custom_button_class' => (get_option('wc_ct_woovideo_button_class')) ? get_option('wc_ct_woovideo_button_class') : '',
            '_button_margin_left' => (get_option('wc_ct_woovideo_button_margin_left')) ? get_option('wc_ct_woovideo_button_margin_left') : 0,
            '_button_margin_top' => (get_option('wc_ct_woovideo_button_margin_top')) ? get_option('wc_ct_woovideo_button_margin_top') : 0,
            '_button_margin_right' => (get_option('wc_ct_woovideo_button_margin_right')) ? get_option('wc_ct_woovideo_button_margin_right') : 0,
            '_button_margin_bottom' => (get_option('wc_ct_woovideo_button_margin_bottom')) ? get_option('wc_ct_woovideo_button_margin_bottom') : 0,
            '_button_padding_left' => (get_option('wc_ct_woovideo_button_padding_left')) ? get_option('wc_ct_woovideo_button_padding_left') : 10,
            '_button_padding_top' => (get_option('wc_ct_woovideo_button_padding_top')) ? get_option('wc_ct_woovideo_button_padding_top') : 5,
            '_button_padding_right' => (get_option('wc_ct_woovideo_button_padding_right')) ? get_option('wc_ct_woovideo_button_padding_right') : 10,
            '_button_padding_bottom' => (get_option('wc_ct_woovideo_button_padding_bottom')) ? get_option('wc_ct_woovideo_button_padding_bottom') : 5,
            '_button_height' => (get_option('wc_ct_woovideo_button_height')) ? get_option('wc_ct_woovideo_button_height') : 100,
            '_button_width' => (get_option('wc_ct_woovideo_button_width')) ? get_option('wc_ct_woovideo_button_width') : 100,
            '_button_border_radius' => (get_option('wc_ct_woovideo_button_border_radius')) ? get_option('wc_ct_woovideo_button_border_radius') : 5,

        ));

        include(dirname(__FILE__) . ('/views/html-video-admin.php'));

        die();
    }


    /**
     * Delete video via ajax function
     */

    public function removeVideoButton() {

        check_ajax_referer( 'delete-videos', 'security' );

        $video_ids = maybe_unserialize((array)$_POST['video_ids']);
        $thepostid = intval( $_POST['post_id'] );
        $videos = maybe_unserialize(get_post_meta($thepostid, '_ct_woovideo_videos'));
        $videos = $videos[0];
        $gal = maybe_unserialize(get_post_meta($thepostid, '_product_image_gallery', true));
        $gal = array_filter( explode(",", $gal));
        $update_gal = false;

        foreach ($video_ids as $video_id) {
            foreach ($videos as $video) {

                if ($video['_id']==$video_id) {
                    $keys = array_keys($videos, $video );
                    $key = $keys[0];
                    unset($videos[$key]);
                }

                if ($video['_location']=='image_gallery') {
                    if (in_array($video['_thumbnail_id'], $gal)) {
                        $keys = array_keys($gal, $video['_thumbnail_id'] );
                        $key = $keys[0];
                        unset($gal[$key]);
                        $update_gal = true;
                    }
                }
            }
        }
        update_post_meta($thepostid, '_ct_woovideo_videos', $videos);

        if ($update_gal === true) {
            $gal = implode( ',', $gal );
            update_post_meta( $thepostid, '_product_image_gallery', $gal );
        }

        die();
    }

    /**
     * Save videos via ajax function
     */

    public function saveVideos() {

        check_ajax_referer( 'save-videos', 'security' );

        // Get post data
        parse_str( $_POST['data'], $data );
        $thepostid = absint( $_POST['post_id'] );

        $gal = maybe_unserialize(get_post_meta($thepostid, '_product_image_gallery', true));
        $gal = array_filter( explode(",", $gal));
        $update_gal = false;

        // Save videos
        $videos = maybe_unserialize(get_post_meta($thepostid, '_ct_woovideo_videos'));

        if ( isset ($data['ct_woovideo_post_id'])) {

            $ct_woovideo_post_ids = array_map( 'stripslashes',$data['ct_woovideo_post_id']);
            $ct_woovideo_location = $data['ct_woovideo_location'];
            $ct_woovideo_gallery_location = $data['ct_woovideo_gallery_location'];
            $ct_woovideo_video_location_priority = $data['ct_woovideo_video_location_priority'];
            $ct_woovideo_title = $data['ct_woovideo_title'];
            $ct_woovideo_position = $data['ct_woovideo_position'];
            $ct_woovideo_shortcode = $data['ct_woovideo_shortcode'];
            $ct_woovideo_external_video_url = $data['ct_woovideo_external_video_url'];
            $ct_woovideo_iframe_url = $data['ct_woovideo_iframe_url'];
            $ct_woovideo_video_class = $data['ct_woovideo_video_class'];

            //inline video settings
            $ct_woovideo_video_align = $data['ct_woovideo_video_align'];
            $ct_woovideo_video_clearing = (!empty($data['ct_woovideo_video_clearing'])) ? $data['ct_woovideo_video_clearing'] : null;
            $ct_woovideo_video_autoplay = (!empty($data['ct_woovideo_video_autoplay'])) ? $data['ct_woovideo_video_autoplay'] : null;
            $ct_woovideo_video_margin_left = $data['ct_woovideo_video_margin_left'];
            $ct_woovideo_video_margin_top = $data['ct_woovideo_video_margin_top'];
            $ct_woovideo_video_margin_right = $data['ct_woovideo_video_margin_right'];
            $ct_woovideo_video_margin_bottom = $data['ct_woovideo_video_margin_bottom'];

            //thumbnail settings
            $ct_woovideo_thumbnail_id = $data['ct_woovideo_thumbnail_id'];
            $ct_woovideo_select_icon = $data['ct_woovideo_select_icon'];
            $ct_woovideo_icon_size = $data['ct_woovideo_icon_size'];
            $ct_woovideo_icon_position = $data['ct_woovideo_icon_position'];
            $ct_woovideo_icon_opacity = $data['ct_woovideo_icon_opacity'];

            //upload video
            $ct_upload_video_mp4_id = $data['ct_upload_video_mp4_id'];
            $ct_upload_video_webm_id = $data['ct_upload_video_webm_id'];
            $ct_upload_video_ogg_id = $data['ct_upload_video_ogg_id'];
            $ct_upload_video_mp4_name = $data['ct_upload_video_mp4_name'];
            $ct_upload_video_webm_name = $data['ct_upload_video_webm_name'];
            $ct_upload_video_ogg_name = $data['ct_upload_video_ogg_name'];

            //player settings
            $ct_woovideo_player_height = $data['ct_woovideo_player_height'];
            $ct_woovideo_player_width = $data['ct_woovideo_player_width'];

            //video settings
            $ct_woovideo_button_location = $data['ct_woovideo_button_location'];
            $ct_woovideo_button_location_priority = $data['ct_woovideo_button_location_priority'];
            $ct_woovideo_button_shortcode = $data['ct_woovideo_button_shortcode'];
            $ct_woovideo_button_color = $data['ct_woovideo_button_color'];
            $ct_woovideo_button_text_color = $data['ct_woovideo_button_text_color'];
            $ct_woovideo_button_label = $data['ct_woovideo_button_label'];
            $ct_woovideo_custom_button_label = $data['ct_woovideo_custom_button_label'];
            $ct_woovideo_button_align = $data['ct_woovideo_button_align'];
            $ct_woovideo_button_clearing = (!empty($data['ct_woovideo_button_clearing'])) ? $data['ct_woovideo_button_clearing'] : null;
            $ct_woovideo_button_class = $data['ct_woovideo_button_class'];
            $ct_woovideo_button_margin_left = $data['ct_woovideo_button_margin_left'];
            $ct_woovideo_button_margin_top = $data['ct_woovideo_button_margin_top'];
            $ct_woovideo_button_margin_right = $data['ct_woovideo_button_margin_right'];
            $ct_woovideo_button_margin_bottom = $data['ct_woovideo_button_margin_bottom'];
            $ct_woovideo_button_padding_left = $data['ct_woovideo_button_padding_left'];
            $ct_woovideo_button_padding_top = $data['ct_woovideo_button_padding_top'];
            $ct_woovideo_button_padding_right = $data['ct_woovideo_button_padding_right'];
            $ct_woovideo_button_padding_bottom = $data['ct_woovideo_button_padding_bottom'];
            $ct_woovideo_button_height = $data['ct_woovideo_button_height'];
            $ct_woovideo_button_width = $data['ct_woovideo_button_width'];
            $ct_woovideo_button_border_radius = $data['ct_woovideo_button_border_radius'];

            $video_post_ids_count = sizeof($ct_woovideo_post_ids);

            for ( $i = 0; $i < $video_post_ids_count ; $i++ ) {

                if (isset ($ct_woovideo_post_ids[$i])){
                    $videos [$i] = apply_filters('ct_woovideo_video_save_atts', array(
                        '_id' => $ct_woovideo_post_ids[$i],
                        '_title' => (!empty($ct_woovideo_title[$i])) ? wc_clean($ct_woovideo_title[$i]) : '#' . $ct_woovideo_post_ids[$i],
                        '_location' => $ct_woovideo_location[$i],
                        '_gallery_location' => $ct_woovideo_gallery_location[$i],
                        '_video_location_priority' => (!empty($ct_woovideo_video_location_priority[$i]) ? intval($ct_woovideo_video_location_priority[$i]) : 100),
                        '_external_url' => (!empty($ct_woovideo_external_video_url[$i])) ? esc_url($ct_woovideo_external_video_url[$i], array('http', 'https')) : null,
                        '_iframe_url' => (!empty($ct_woovideo_iframe_url[$i])) ? esc_url($ct_woovideo_iframe_url[$i], array('http', 'https')) : null,
                        '_position' => absint($ct_woovideo_position[$i]),
                        '_video_shortcode' => (!empty($ct_woovideo_shortcode[$i])) ? $ct_woovideo_shortcode[$i] : null,

                        //thumbnail settings
                        '_thumbnail_id' => (!empty($ct_woovideo_thumbnail_id[$i])) ? absint($ct_woovideo_thumbnail_id[$i]) : '',
                        '_image' => (!empty($ct_woovideo_thumbnail_id[$i])) ? wp_get_attachment_thumb_url($ct_woovideo_thumbnail_id[$i]) : '',
                        '_image_url' => (!empty($ct_woovideo_thumbnail_id[$i])) ? wp_get_attachment_url($ct_woovideo_thumbnail_id[$i]) : '',
                        '_thumbnail_icon' => (!empty($ct_woovideo_select_icon[$i])) ? ($ct_woovideo_select_icon[$i]) : '',
                        '_icon_size' => (!empty($ct_woovideo_icon_size[$i])) ? intval($ct_woovideo_icon_size[$i]) : 0,
                        '_icon_position' => (!empty($ct_woovideo_icon_position[$i])) ? ($ct_woovideo_icon_position[$i]) : 'center',
                        '_icon_opacity' => (!empty($ct_woovideo_icon_opacity[$i])) ? intval($ct_woovideo_icon_opacity[$i]) : 0,

                        //inline video settings
                        '_video_align' => (!empty($ct_woovideo_video_align[$i])) ? $ct_woovideo_video_align[$i] : 'left',
                        '_video_clearing' => (isset($ct_woovideo_video_clearing[$i])) ? 'on' : 'no',
                        '_video_autoplay' => (isset($ct_woovideo_video_autoplay[$i])) ? 'on' : 'no',
                        '_video_class' => (!empty($ct_woovideo_video_class[$i])) ? $ct_woovideo_video_class[$i] : '',
                        '_video_margin_left' => (!empty($ct_woovideo_video_margin_left[$i])) ? intval($ct_woovideo_video_margin_left[$i]) : 0,
                        '_video_margin_top' => (!empty($ct_woovideo_video_margin_top[$i])) ? intval($ct_woovideo_video_margin_top[$i]) : 0,
                        '_video_margin_right' => (!empty($ct_woovideo_video_margin_right[$i])) ? intval($ct_woovideo_video_margin_right[$i]) : 0,
                        '_video_margin_bottom' => (!empty($ct_woovideo_video_margin_bottom[$i])) ? intval($ct_woovideo_video_margin_bottom[$i]) : 0,

                        //upload video
                        '_upload_video_mp4_id' => (!empty($ct_upload_video_mp4_id[$i])) ? absint($ct_upload_video_mp4_id[$i]) : '',
                        '_upload_video_webm_id' => (!empty($ct_upload_video_webm_id[$i])) ? absint($ct_upload_video_webm_id[$i]) : '',
                        '_upload_video_ogg_id' => (!empty($ct_upload_video_ogg_id[$i])) ? absint($ct_upload_video_ogg_id[$i]) : '',
                        '_upload_video_mp4_name' => (!empty($ct_upload_video_mp4_name[$i])) ? wc_clean($ct_upload_video_mp4_name[$i]) : '',
                        '_upload_video_webm_name' => (!empty($ct_upload_video_webm_name[$i])) ? wc_clean($ct_upload_video_webm_name[$i]) : '',
                        '_upload_video_ogg_name' => (!empty($ct_upload_video_ogg_name[$i])) ? wc_clean($ct_upload_video_ogg_name[$i]) : '',

                        //player settings

                        '_player_height' => (!empty($ct_woovideo_player_height[$i])) ? absint($ct_woovideo_player_height[$i]) : 0,
                        '_player_width' => (!empty($ct_woovideo_player_width[$i])) ? absint($ct_woovideo_player_width[$i]) : 0,

                        //button settings
                        '_button_location' => $ct_woovideo_button_location[$i],
                        '_button_location_priority' => (!empty($ct_woovideo_button_location_priority[$i]) ? intval($ct_woovideo_button_location_priority[$i]) : 100),
                        '_video_button_shortcode' => (!empty($ct_woovideo_button_shortcode[$i])) ? $ct_woovideo_button_shortcode[$i] : null,
                        '_button_color' => (preg_match('/^#[a-f0-9]{6}$/i', $ct_woovideo_button_color[$i])) ? ($ct_woovideo_button_color[$i]) : '',
                        '_button_text_color' => (preg_match('/^#[a-f0-9]{6}$/i', $ct_woovideo_button_text_color[$i])) ? ($ct_woovideo_button_text_color[$i]) : '#000000',
                        '_button_label' => (!empty($ct_woovideo_button_label[$i])) ? $ct_woovideo_button_label[$i] : '',
                        '_custom_button_label' => (!empty($ct_woovideo_custom_button_label[$i])) ? wc_clean($ct_woovideo_custom_button_label[$i]) : '',
                        '_button_align' => (!empty($ct_woovideo_button_align[$i])) ? $ct_woovideo_button_align[$i] : 'left',
                        '_button_clearing' => (isset($ct_woovideo_button_clearing[$i])) ? 'on' : 'no',
                        '_button_class' => (!empty($ct_woovideo_button_class[$i])) ? $ct_woovideo_button_class[$i] : '',
                        '_button_margin_left' => (!empty($ct_woovideo_button_margin_left[$i])) ? intval($ct_woovideo_button_margin_left[$i]) : 0,
                        '_button_margin_top' => (!empty($ct_woovideo_button_margin_top[$i])) ? intval($ct_woovideo_button_margin_top[$i]) : 0,
                        '_button_margin_right' => (!empty($ct_woovideo_button_margin_right[$i])) ? intval($ct_woovideo_button_margin_right[$i]) : 0,
                        '_button_margin_bottom' => (!empty($ct_woovideo_button_margin_bottom[$i])) ? intval($ct_woovideo_button_margin_bottom[$i]) : 0,
                        '_button_padding_left' => (!empty($ct_woovideo_button_padding_left[$i])) ? intval($ct_woovideo_button_padding_left[$i]) : 0,
                        '_button_padding_top' => (!empty($ct_woovideo_button_padding_top[$i])) ? intval($ct_woovideo_button_padding_top[$i]) : 0,
                        '_button_padding_right' => (!empty($ct_woovideo_button_padding_right[$i])) ? intval($ct_woovideo_button_padding_right[$i]) : 0,
                        '_button_padding_bottom' => (!empty($ct_woovideo_button_padding_bottom[$i])) ? intval($ct_woovideo_button_padding_bottom[$i]) : 0,
                        '_button_height' => (!empty($ct_woovideo_button_height[$i])) ? absint($ct_woovideo_button_height[$i]) : 0,
                        '_button_width' => (!empty($ct_woovideo_button_width[$i])) ? absint($ct_woovideo_button_width[$i]) : 0,
                        '_button_border_radius' => (!empty($ct_woovideo_button_border_radius[$i])) ? intval($ct_woovideo_button_border_radius[$i]) : 0,

                    ));

                    $videos[$i]['_global_id'] = $thepostid . '-' . $videos[$i]['_id'];


                    if (!empty($videos[$i]['_icon_opacity'])) {
                        if (($videos[$i]['_icon_opacity'] > 10) || $videos[$i]['_icon_opacity'] < 0) {
                            $videos[$i]['_icon_opacity'] = 5;
                        }
                    }

                    if (!empty($videos[$i]['_thumbnail_icon'])) {
                            $videos[$i]['_icon_url'] = CT_WOOVIDEO_ASSETS . '/images/' . esc_attr($videos[$i]['_thumbnail_icon']) . '.png';
                    }

                    if (!empty($videos[$i]['_upload_video_mp4_id'])) {
                        $videos[$i]['_upload_video_mp4_url'] = wp_get_attachment_url($videos[$i]['_upload_video_mp4_id']);
                        $type = wp_check_filetype($videos[$i]['_upload_video_mp4_url']);
                        if ($type['type'] != 'video/mp4') {
                            $videos[$i]['_upload_video_mp4_url'] = null;
                            $videos[$i]['_upload_video_mp4_id'] = null;
                            $videos[$i]['_upload_video_mp4_name'] = null;
                        }
                    }  else {
                        $videos[$i]['_upload_video_mp4_url'] = null;
                        $videos[$i]['_upload_video_mp4_id'] = null;
                        $videos[$i]['_upload_video_mp4_name'] = null;
                    }

                    if (!empty($videos[$i]['_upload_video_ogg_id'])) {
                        $videos[$i]['_upload_video_ogg_url'] = wp_get_attachment_url($videos[$i]['_upload_video_ogg_id']);
                        $type = wp_check_filetype($videos[$i]['_upload_video_ogg_url']);
                        if ($type['type'] != 'video/ogg') {
                            $videos[$i]['_upload_video_ogg_url'] = null;
                            $videos[$i]['_upload_video_ogg_id'] = null;
                            $videos[$i]['_upload_video_ogg_name'] = null;
                        }
                    }  else {
                        $videos[$i]['_upload_video_ogg_url'] = null;
                        $videos[$i]['_upload_video_ogg_id'] = null;
                        $videos[$i]['_upload_video_ogg_name'] = null;
                    }

                    if (!empty($videos[$i]['_upload_video_webm_id'])) {
                        $videos[$i]['_upload_video_webm_url'] = wp_get_attachment_url($videos[$i]['_upload_video_webm_id']);
                        $type = wp_check_filetype($videos[$i]['_upload_video_webm_url']);
                        if ($type['type'] != 'video/webm') {
                            $videos[$i]['_upload_video_webm_url'] = null;
                            $videos[$i]['_upload_video_webm_id'] = null;
                            $videos[$i]['_upload_video_webm_name'] = null;
                        }
                    }  else {
                        $videos[$i]['_upload_video_webm_url'] = null;
                        $videos[$i]['_upload_video_webm_id'] = null;
                        $videos[$i]['_upload_video_webm_name'] = null;
                    }

                    if ($videos[$i]['_external_url']){
                        $videos[$i]['_video_url'] = esc_url($ct_woovideo_external_video_url[$i], array('http', 'https'));
                    } elseif ($videos[$i]['_upload_video_mp4_url']) {
                        $videos[$i]['_video_url'] = $videos[$i]['_upload_video_mp4_url'];
                    } elseif ($videos[$i]['_upload_video_webm_url']) {
                        $videos[$i]['_video_url'] = $videos[$i]['_upload_video_webm_url'];
                    } elseif ($videos[$i]['_upload_video_ogg_url']) {
                        $videos[$i]['_video_url'] = $videos[$i]['_upload_video_ogg_url'];
                    } elseif (($videos[$i]['_iframe_url']) && (get_option('wc_ct_woovideo_iframe_enabled') == 'on')) {
                        $videos[$i]['_video_url'] = $videos[$i]['_iframe_url'];
                    } else {
                        $videos[$i]['_video_url'] = null;
                    }

                    if (($videos[$i]['_location'] == 'image_gallery') && (!empty($videos[$i]['_thumbnail_id'])) && (!in_array($videos[$i]['_thumbnail_id'], $gal)) && (!empty($videos[$i]['_video_url']))) {

                        array_push($gal, (string)$videos[$i]['_thumbnail_id']);
                        $update_gal = true;

                    }

                    if ($videos[$i]['_location']!='image_gallery') {
                        if (in_array($videos[$i]['_thumbnail_id'], $gal)) {

                            $keys = array_keys($gal, $videos[$i]['_thumbnail_id'] );
                            $key = $keys[0];
                            unset($gal[$key]);
                            $update_gal = true;

                        }
                    }

                    if (($videos[$i]['_location']=='image_gallery') && (empty($videos[$i]['_thumbnail_id']))) {
                        $keys = array_keys($gal, $videos[$i]['_thumbnail_id'] );
                        if ($keys) {
                            $key = $keys[0];
                            unset($gal[$key]);
                            $update_gal = true;

                        }
                    }

                    if ( !in_array($videos[$i]['_location'], array('tab', 'image_gallery', 'button', 'shortcode'))) {
                        $videos[$i]['_location'] = 'tab';
                    }

                    if ( !in_array($videos[$i]['_gallery_location'], array('above', 'in'))) {
                        $videos[$i]['_gallery_location'] = 'in';
                    }

                    if ( !in_array($videos[$i]['_button_location'], array('after_add_to_cart_button', 'after_product_info', 'product_gallery', 'above_tabs', 'tab', 'shortcode'))) {
                        $videos[$i]['_button_location'] = 'above_tabs';
                    }

                    if ( !in_array($videos[$i]['_button_label'], array('title', 'thumbnail', 'custom'))) {
                        $videos[$i]['_button_label'] = 'custom';
                    }

                    do_action('ct_woovideo_video_save');
                }
            }

            if ( ! function_exists( 'ctSortVideos' ) ) {
                function ctSortVideos( $a, $b ) {
                    if ( $a['_position'] == $b['_position'] ) {
                        return ( $a['_id'] < $b['_id'] ) ? -1 : 1;
                    }

                    return ( $a['_position'] < $b['_position'] ) ? -1 : 1;
                }
            }
            uasort( $videos, 'ctSortVideos' );

            do_action('ct_woovideo_before_save');

            update_post_meta( $thepostid, '_ct_woovideo_videos', $videos );

            if ($update_gal === true) {

                $gal = implode( ',', $gal );
                update_post_meta($thepostid, '_product_image_gallery', $gal);
            }
        }

        die();
    }

    /**
     * Show shortcode for video via ajax function
     */

    public function showVideoShortcode(){
        check_ajax_referer( 'show-shortcode', 'security' );

        // Get post data
        parse_str( $_POST['data'], $data );

        foreach ($data['ct_woovideo_post_id'] as $video_id) {
            if ($video_id != '0') {
                echo "[ct_woovideo id='$video_id']";
            }
        }
        die();
    }

    /**
     * Restore default settings via ajax function
     */

    public function restoreDefaults(){
        check_ajax_referer( 'restore-defaults', 'security' );

        // Get post data
        parse_str( $_POST['data'], $data );

        foreach ($data as $key => $value) {
            $data[$key] = (get_option("wc_$key"));
        }

        $data['ct_woovideo_button_clearing'] = get_option('wc_ct_woovideo_button_clearing');
        $data['ct_woovideo_video_clearing'] = get_option('wc_ct_woovideo_video_clearing');
        $data['ct_woovideo_video_autoplay'] = get_option('wc_ct_woovideo_video_autoplay');
        $data['ct_woovideo_select_icon'] = get_option('wc_ct_woovideo_select_icon');

        $data = json_encode($data);

        //ajax response:
        echo $data;

        die();
    }

    /**
     * Show shortcode for button via ajax function
     */

    public function showButtonShortcode(){
        check_ajax_referer( 'show-button-shortcode', 'security' );

        // Get post data
        parse_str( $_POST['data'], $data );

        foreach ($data['ct_woovideo_post_id'] as $video_id) {
            if ($video_id != '0') {
                echo "[ct_woovideo_button id='$video_id']";
            }
        }
        die();
    }


    /**
     * Create a Video tab in Admin Product Data Metabox
     * @param $product_data_tabs
     * @return mixed
     */

    public function addAdminProductVideoTab ($product_data_tabs) {
        $product_data_tabs['videos'] = array(
                'label'  => __( 'Videos', 'ct_woovideo' ),
                'target' => 'ct-woovideo-product-options',
                'class'  => array('ct-woovideo-tab')
            );

        return $product_data_tabs;

    }

    /**
     * Video Panels content in Admin Product Data Metabox
     */

    public function adminProductVideoPanel() {

        global $post, $thepostid;

        $thepostid = $post->ID;

        ?>

    <div id='ct-woovideo-product-options' class='panel wc-metaboxes-wrapper woocommerce_options_panel'>
        <div id="ct-woovideo-product-options-inner">
        <p class="toolbar">
            <a href="#" class="close_all"><?php _e('Close all', 'ct-woovideo'); ?></a><a href="#" class="expand_all"><?php _e('Expand all', 'ct-woovideo'); ?></a>
            <select id="field_to_edit">
                <option autocomplete= "off" selected="selected" value=""><?php _e( 'Choose a field to bulk edit&hellip;', 'ct-woovideo' ); ?></option>
                <option autocomplete= "off" value="remove_all"><?php _e( 'Remove all videos', 'ct-woovideo' ); ?></option>
                <option autocomplete= "off" value="restore_video_defaults"><?php _e( 'Restore video defaults', 'ct-woovideo' ); ?></option>
                <option autocomplete= "off" value="restore_button_defaults"><?php _e( 'Restore button defaults', 'ct-woovideo' ); ?></option>
                <?php do_action( 'ct_woovideo_bulk_edit_actions' ); ?>
            </select>

            <a class="button bulk_edit"><?php _e('Go', 'ct-woovideo'); ?></a>
        </p>

        <div class="ct-woovideo-woocommerce-videos wc-metaboxes">

            <?php

            // Get videos
            $videos = maybe_unserialize(get_post_meta($thepostid, '_ct_woovideo_videos'));

            $loop = 0;

            if ($videos) {

                $videos = $videos[0];

                foreach ($videos as $video) {

                    include(dirname(__FILE__) . ('/views/html-video-admin.php'));

                    $loop++;
                }
            }

            ?>

        </div>
            <p class="toolbar">
                <button type="button" class="button save_videos"><?php _e( 'Save Videos', 'ct-woovideo' ); ?></button>
                <button type="button" class="button button-primary ct-woovideo-add-video"><?php _e('Add Video', 'ct-woovideo'); ?></button>

            </p>
        </div>

    <?php
    }

}


new ctWooVideoAdmin;