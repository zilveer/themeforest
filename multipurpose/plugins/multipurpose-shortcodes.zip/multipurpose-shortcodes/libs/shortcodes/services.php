<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');
// add shortcode for Services
add_shortcode('services', 'multipurpose_services');
add_shortcode('service', 'multipurpose_service');

function multipurpose_services($atts, $content = null) {
    $output = '<ul class="hp-services">'.do_shortcode($content).'</ul>';
    return $output;
}

function multipurpose_service($atts, $content = null) {
    if(isset($atts) && !empty($atts))
        array_walk($atts, 'multipurpose_arrangement_shortcode_arr_value');

    extract(shortcode_atts(array(  
            'image_url'=> '',
            'image_alt'=> ''
    ), $atts));  

    $output = '<li>';
    $output .= '<img src="'.$image_url.'" alt="'.$image_alt.'">';
    $output .= '<div>'.do_shortcode($content).'</div></li>';
    return $output;
	
}