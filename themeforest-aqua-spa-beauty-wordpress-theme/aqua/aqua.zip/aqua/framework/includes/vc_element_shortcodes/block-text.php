<?php
vc_map ( array (
		"name" => 'Block Text',
		"base" => "tb_block_text",
		"icon" => "tb-icon-for-vc",
		"category" => __ ( 'Aqua', 'jwsthemes' ),
		"params" => array (
				array (
						"type" => "dropdown",
						"heading" => __ ( 'Type', 'jwsthemes' ),
						"param_name" => "type",
						"value" => array(
							"Default" => "default",
							"Rounded" => "rounded",
						),
						"description" =>  __ ( 'Select type for block text.', 'jwsthemes' )
				),
				array (
						"type" => "colorpicker",
						"heading" => __ ( 'Color', 'jwsthemes' ),
						"param_name" => "color",
						"value" => '',
						"description" => __ ( 'Select color for block text.', 'jwsthemes' )
				),
				array (
						"type" => "colorpicker",
						"heading" => __ ( 'Background', 'jwsthemes' ),
						"param_name" => "background",
						"value" => '',
						"description" => __ ( 'Select background for block text.', 'jwsthemes' )
				),
				array (
						"type" => "textfield",
						"heading" => __ ( 'Border Width', 'jwsthemes' ),
						"param_name" => "border_width",
						"value" => '',
						"description" => __( 'Please, enter number with "px" of border for block text.', 'jwsthemes' )
				),
				array (
						"type" => "colorpicker",
						"heading" => __ ( 'Border Color', 'jwsthemes' ),
						"param_name" => "border_color",
						"value" => '',
						"description" => __ ( 'select color of border for block text.', 'jwsthemes' )
				),
				array (
						"type" => "dropdown",
						"heading" => __ ( 'Border Style', 'jwsthemes' ),
						"param_name" => "border_style",
						"value" => array('none','hidden','dotted','dashed','solid','double','groove','ridge','inset','outset','initial','inherit'),
						"description" => __ ( 'Select style of border for block text.', 'jwsthemes' )
				),
				array (
						"type" => "textfield",
						"heading" => __ ( 'Padding', 'jwsthemes' ),
						"param_name" => "padding",
						"value" => '',
						"description" =>  __ ( 'Please, enter number with "px" of padding for block text.', 'jwsthemes' )
				),
				array (
						"type" => "textarea_html",
						"holder" => "div",
						"heading" => __ ( 'Content', 'jwsthemes' ),
						"param_name" => "content",
						"value" => '',
						"description" => __ ( 'Please, enter content for block text.', 'jwsthemes' )
				)
		)
) );