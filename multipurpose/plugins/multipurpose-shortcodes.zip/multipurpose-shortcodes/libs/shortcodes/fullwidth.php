<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

function multipurpose_fullwidth($attr, $content = null) {
	extract(shortcode_atts(array('id' => '', 'edges' => false, 'padding_top' => 0, 'padding_right' => 0, 'padding_bottom' => 0, 'padding_left' => 0, 'background_color' => '', 'background_image' => '', 'background_position' => '', 'background_repeat' => false, 'parallax' => false, 'margin_top' => '', 'margin_bottom' => ''), $attr));
	$classes = array('fullwidth');
	if ($edges) $classes[] = 'with-edges';
	if ($parallax) $classes[] = 'parallax';
	$classes = implode(' ', $classes);

	$style = array();
	if (isset($background_color)) $style[] = 'background-color: ' . $background_color;
	if (isset($background_image)) $style[] = 'background-image: url(' . $background_image . ')';
	if (isset($background_position)) $style[] = 'background-position: ' . $background_position;
	if (isset($background_repeat)) $style[] = 'background-repeat: ' . $background_repeat;
	if (isset($padding_top)) $style[] = 'padding-top: ' . $padding_top . 'px';
	if (isset($padding_right)) $style[] = 'padding-right: ' . $padding_right . 'px';
	if (isset($padding_bottom)) $style[] = 'padding-bottom: ' . $padding_bottom . 'px';
	if (isset($padding_left)) $style[] = 'padding-left: ' . $padding_left . 'px';
	if ($margin_top) $style[] = 'margin-top: ' . $margin_top . 'px';
	if ($margin_bottom) $style[] = 'margin-bottom: ' . $margin_bottom . 'px';
	$style = implode('; ', $style);
	$html = '<section ';
	if (isset($id)) {$html .= 'id="'.$id.'" ';}
	$html .= 'class="'. $classes . '" style="' . $style . '">'. do_shortcode($content) . '</section>';
	return $html;
}

function multipurpose_fullwidth_shortcodes() {
	add_shortcode('fullwidth', 'multipurpose_fullwidth');
}

add_action('init', 'multipurpose_fullwidth_shortcodes');