<?php
class WPBakeryShortCode_Mnky_List_Item extends WPBakeryShortCode {

}