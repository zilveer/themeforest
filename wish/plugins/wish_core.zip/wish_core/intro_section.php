<?php  
//Register "container" content element
vc_map( array(
    "name" => __("Wish Intro", "wish"),
    "description" => __("Intro Section", 'wish'),
    "controls" => "full",
    "base" => "wish_intro_section",
    "as_parent" => array('only' => 'wish_intro_section_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link" => "http://i.imgur.com/DjyQynm.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
                "type" => "textfield",
                "heading" => __("Title", "wish"),
                "param_name" => "title",
                "admin_label" => true,
                "description" => __("The Title on the top.", "wish"),
                "value" => __("Welcome to PizzaNet", 'wish'),
                "admin_label" => true,
        ),

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
            "description" => __("Details under the title on top", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Bottom Image", 'wish'),
            "param_name" => "image",
            "description" => __("Large image at the bottom", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Ribbon Image", 'wish'),
            "param_name" => "ribbon",
            "description" => __("Banner image behind the title, leave blank for default", 'wish'),
            "admin_label" => false,
        ),

        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("24", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#fff', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

    ),
));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Intro Item", "wish"),
    "base" => "wish_intro_section_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_intro_section'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Item Title", "wish"),
            "value" => __("Pizza", 'wish'),
            "admin_label" => true,
        ), 

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Item Details", 'wish'),
            "param_name" => "details",
            "value" => __("Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.", 'wish'),
            "description" => __("Item details below the title", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Image", 'wish'),
            "param_name" => "image",
            "description" => __("The item image at the top of the box", 'wish'),
            "admin_label" => false,
        ), 

        array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("Link To The Page", 'wish'),
            "param_name" => "link",
            "description" => __("The link at the bottom of the item box", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Link text", "wish"),
            "param_name" => "link_text",
            "description" => __("Item text for above link", "wish"),
            "value" => __("Order Now", 'wish'),
            "admin_label" => false,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("24", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#e06f00 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#fff', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),
       
    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Intro_Section extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title'         => 'Welcome to PizzaNet',
        'title_font'    => '',
        'title_size'    => '24',
        'title_color'   => '#fff',

        'details'       => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.',
        'details_font'  => '',
        'details_size'  => '14',
        'details_color' => '#fff',

        'image'   => 'Image',
        'ribbon'   => 'ribbon',
      ), $atts ) );

        /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

      $img = wp_get_attachment_image_src( $image, 'full' );

      if($image == "Image"){
        $imgsrc = plugins_url('images/pizza.jpg', __FILE__);
        $img[0] = $imgsrc;
      }

      $rib = wp_get_attachment_image_src( $ribbon, 'full' );

      if($ribbon == "ribbon"){
        $ribsrc = plugins_url('images/heading-bg.png', __FILE__);
        $rib[0] = $ribsrc;
      }

      $output = "<!----------- Intro Section ---------->
                <div class='home-intro meroon-bg'>
                    <div class='container'>
                        <div class='row'>
                            <div class='col-lg-8 col-lg-offset-2'>
                                <div class='pizza-intro-title main-heading animated' data-animation='flipInX' data-animation-delay='100' style='background-image:url({$rib[0]});'>
                                    <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                                </div>
                                <div class='description animated' data-animation='flipInX' data-animation-delay='400' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>
                            </div>
                        </div>
                        <div class='row blocks'>

                        ".do_shortcode($content)."

                        </div>

                        <div class='row'>
                            <div class='col-lg-12 picture animated' data-animation='flipInX' data-animation-delay='2000'>
                                <img src='{$img[0]}' class='img-responsive center-block' alt=''>
                            </div>
                        </div>
                    </div>
                </div>
                ";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Intro_Section_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'title'         => 'Pizza',
            'title_font'    => '',
            'title_size'    => '24',
            'title_color'   => '#e06f00',

            'details'       => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillumdolo eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt.',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#fff',

            'image'     => 'Image',
            'icon'      => 'Icon',
            'link'      => '#',
            'link_text' => 'Order Now',
          ), $atts ) );

        /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

          $img = wp_get_attachment_image_src( $image, 'wish-intro-item' );

          if($image == "Image"){
            $imgsrc = plugins_url('images/small_pizza.png', __FILE__);
            $img[0] = $imgsrc;
          }


          $ic = wp_get_attachment_image_src( $icon, 'wish-intro-icon' );

          if($icon == "Icon"){
            $iconsrc = plugins_url('images/small_icon.png', __FILE__);
            $ic[0] = $iconsrc;
          }

          $link = vc_build_link($link); //parse the link
          $link = $link["url"];


          $output = "<div class='col-lg-4'>
                        <div class='block animated' data-animation='fadeInUp' data-animation-delay='800'>
                            <div class='icon'><img src='{$img[0]}' width='50' height='50' alt=''></div>
                            <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                            <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                            <div class='icon'><img src='{$ic[0]}' width='22' height='23' alt=''></div>
                            <div class='btn center-block'><a href='{$link}'>{$link_text}</a></div>
                        </div>
                    </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>