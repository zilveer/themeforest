<nav id="{$location}">
	<div class="nav-previous">{prevPostLink '<span class="meta-nav">&larr;</span>'}</div>
	<div class="nav-next">{nextPostLink '<span class="meta-nav">&rarr;</span>'}</div>
</nav>