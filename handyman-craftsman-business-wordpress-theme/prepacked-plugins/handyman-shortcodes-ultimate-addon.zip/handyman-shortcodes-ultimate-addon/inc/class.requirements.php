<?php
if (!class_exists('TL_Requirements')) {
    class TL_Requirements
    {
        const version = '1.0.0';

        static public $config = [
            'php' => null,
            'wp' => null
        ];


        /**
         * @var
         */
        static public $text_domain;


        /**
         * Path to main plugin file
         * @var
         */
        static public $path;


        /**
         * Plugin unique ID
         *
         * @var
         */
        static protected $id;


        /**
         * Constructor
         */
        public function __construct($id, $path, $text_domain='', $config=[])
        {
            self::$config = wp_parse_args($config, self::$config);

            self::$text_domain = $text_domain;
            self::$path        = $path;
            self::$id          = $id;

            add_action($id . '_tl_activation', [$this, 'php']);
            add_action($id . '_tl_activation', [$this, 'wp']);
        }

        /**
         * Check PHP version
         */
        public static function php()
        {

            if(self::$config['php'] == null) return;

            $php = phpversion();
            load_plugin_textdomain(self::$text_domain, false, dirname(plugin_basename(self::$path)), '/lang/');
            $msg = sprintf(__('<h1>Oops! Plugin not activated&hellip;</h1> <p>The Plugin is not fully compatible with your PHP version (%s).<br />Recommended PHP version &ndash; %s (or higher).</p><a href="%s">&larr; Return to the plugins screen</a> <a href="%s"%s>Continue and activate anyway &rarr;</a>', self::$text_domain), $php, self::$config['php'], network_admin_url('plugins.php?deactivate=true'), $_SERVER['REQUEST_URI'] . '&continue=true', ' style="float:right;font-weight:bold"');
            // Check Forced activation
            if (isset($_GET['continue'])) return;
            // PHP version is too low
            elseif (version_compare(self::$config['php'], $php, '>=')) {
                deactivate_plugins(plugin_basename(self::$path));
                wp_die($msg);
            }
        }

        /**
         * Check WordPress version
         */
        public static function wp()
        {
            if(self::$config['wp'] == null) return;

            $wp = get_bloginfo('version');
            load_plugin_textdomain(self::$text_domain, false, dirname(plugin_basename(self::$path)), '/lang/');
            $msg = sprintf(__('<h1>Oops! Plugin not activated&hellip;</h1> <p>The plugin is not fully compatible with your version of WordPress (%s).<br />Recommended WordPress version &ndash; %s (or higher).</p><a href="%s">&larr; Return to the plugins screen</a> <a href="%s"%s>Continue and activate anyway &rarr;</a>', self::$text_domain), $wp, self::$config['wp'], network_admin_url('plugins.php?deactivate=true'), $_SERVER['REQUEST_URI'] . '&continue=true', ' style="float:right;font-weight:bold"');
            // Check Forced activation
            if (isset($_GET['continue'])) return;
            // PHP version is too low
            elseif (version_compare(self::$config['wp'], $wp, '>=')) {
                deactivate_plugins(plugin_basename(self::$path));
                wp_die($msg);
            }
        }
    }
}
new TL_Requirements(TL_SHORTCODES_ADDON_SLUG,
                    TL_SHORTCODES_ADDON_FILE,
                    TL_SHORTCODES_ADDON_SLUG,
                    [
                        'php' => TL_SHORTCODES_ADDON_REQ_PHP,
                        'wp'  => TL_SHORTCODES_ADDON_REQ_WP
                    ]
);