<?php
/*
Plugin Name: Skeleton Shortcodes
Plugin URI: http://themeisland.net
Description: This plugins adds the rad shortcodes used in Super Skeleton themes.
Version: 1.0
Author: Theme Island Studios
Author URI: http://themeisland.net
License: GPLv2
*/

/* Load Theme Specific Shortcodes for the theme */
include(plugin_dir_path( __FILE__ ) . '/shortcodes.php');

?>