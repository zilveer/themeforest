<?php $icons = array();
$icons['icomoon']['ue900'] = 'ue900';