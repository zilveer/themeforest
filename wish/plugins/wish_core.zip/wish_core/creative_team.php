<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Creative Team", "wish"),
    "description" => __("Team with Image Name and Links", 'wish'),
    "controls" => "full",
    "base" => "wish_creative_team",
    "as_parent" => array('only' => 'wish_creative_team_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link" => "http://i.imgur.com/oV75b2B.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Heading", "wish"),
            "param_name" => "title",
            "description" => __("Staff Title and Position", "wish"),
            "value" => __("CREATIVE TEAM", 'wish'),
            "admin_label" => false,
        ), 

        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Font Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),


         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#f4f4f4', 
            "description" => __( "Choose the background color", "wish" ),
            "group"       => "Fonts & Colors",
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Team Member", "wish"),
    "base" => "wish_creative_team_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_creative_team'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,    
        ),

        array(
            "type" => "textfield",
            "heading" => __("Name", "wish"),
            "param_name" => "name",
            "description" => __("Staff Member Name", "wish"),
            "value" => __("MARGARET ANDERSON", 'wish'),
            "admin_label" => false,
        ),
    
        array(
            "type" => "textfield",
            "heading" => __("Profession", "wish"),
            "param_name" => "profession",
            "description" => __("ART DIRECTOR", "wish"),
            "value" => __("ART DIRECTOR", 'wish'),
            "admin_label" => false,
        ),

        /*name*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Name Text Font", "wish" ),
            "param_name" => "name_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Name Font Size", "wish"),
            "param_name" => "name_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("16", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Name Text Color", "wish" ),
            "param_name" => "name_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),


        /*profession*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Profession Text Font", "wish" ),
            "param_name" => "pro_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Profession Font Size", "wish"),
            "param_name" => "pro_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Profession Text Color", "wish" ),
            "param_name" => "pro_color",
            "value" => '#838383', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),
        
/*        
        array(
            "type" => "textfield",
             "holder" => "div",
             "class" => "",
             "heading" => __("Facebook", 'wish'),
             "param_name" => "facebook",
             "description" => __("facebook", 'wish'),
             "admin_label" => false,
         ),*/
        array(
            "type" => "textfield",
            "heading" => __("Facebook", "wish"),
            "param_name" => "facebook",
            "description" => __("Facebook", "wish"),
            "value" => __("", 'wish'),
            "admin_label" => false,
        ),
        array(
            "type" => "textfield",
            "heading" => __("Twitter", "wish"),
            "param_name" => "twitter",
            "description" => __("Twitter", "wish"),
            "value" => __("", 'wish'),
            "admin_label" => false,
        ),
        array(
            "type" => "textfield",
            "heading" => __("Google Plus", "wish"),
            "param_name" => "googleplus",
            "description" => __("Google Plus", "wish"),
            "value" => __("", 'wish'),
            "admin_label" => false,
        ),
        array(
            "type" => "textfield",
            "heading" => __("Skype", "wish"),
            "param_name" => "skype",
            "description" => __("Skype", "wish"),
            "value" => __("", 'wish'),
            "admin_label" => false,
        ),
        array(
            "type" => "textfield",
            "heading" => __("Linkedin", "wish"),
            "param_name" => "linkedin",
            "description" => __("Linkedin", "wish"),
            "value" => __("", 'wish'),
            "admin_label" => false,
        ),


    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Creative_Team extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title' => 'CREATIVE TEAM',
            'title_font' => '',
            'title_size' => '20',
            'title_color' => '#000',
            'bgcolor'   => '#f4f4f4'  
          ), $atts ) );


           /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


      $output = "<div class='our-team grey-bg' id='team'>
            <div class='container'>
                <div class='row'>
                    <div class='col-lg-12'>
                        <h1 class='animated fadeInUp visible' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>
                    </div>
                    " . do_shortcode($content) . "
                
            </div>
            </div>
            </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Creative_Team_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image'   => 'Image',
            
            'name'          => 'MARGARET ANDERSON',
            'name_font'     => '',
            'name_size'     => '16',
            'name_color'    => '#000',

            'profession'=> 'ART DIRECTOR',
            'pro_font'  => '',
            'pro_size'  => '14',
            'pro_color' => '#838383',



            'facebook'      => 'facebook',
            'twitter'       => 'twitter',
            'googleplus'    => 'googleplus',
            'skype'         => 'skype',
            'linkedin'      => 'linkedin'
          ), $atts ) );

           /*Name*/
        $decode_font = urldecode($name_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $name_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



         /*Profession*/
        $decode_font = urldecode($pro_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $pro_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


          $facebook_text = "<li><a href='{$facebook}'><i class='fa fa-facebook'></i></a></li>";
          if($facebook == "facebook"){
            $facebook_text = "";
          }
          $twitter_text = "<li><a href='{$twitter}'><i class='fa fa-twitter'></i></a></li>";
          if($twitter == "twitter"){
            $twitter_text = "";
          }
          $googleplus_text = "<li><a href='{$googleplus}'><i class='fa fa-google-plus'></i></a></li>";
          if($googleplus == "googleplus"){
            $googleplus_text = "";
          }
          $skype_text = "<li><a href='{$skype}'><i class='fa fa-skype'></i></a></li>";
          if($skype == "skype"){
            $skype_text = "";
          }
          $linkedin_text = "<li><a href='{$linkedin}'><i class='fa fa-linkedin'></i></a></li>";
          if($linkedin == "linkedin"){
            $linkedin_text = "";
          }

          $img = wp_get_attachment_image_src( $image, array(360,220) );

          if($image == "Image"){
            $imgsrc = plugins_url('images/staff.jpg', __FILE__);
            $img[0] = $imgsrc;
          }

          $output = "<div class='col-lg-3 col-md-6 col-sm-6 block'>
                        <div class='picture'><img src='{$img[0]}' class='img-responsive' alt=''></div>
                        <div class='name' style='font-family:{$name_font_family};font-size:{$name_size}px;color:{$name_color}'>{$name}</div>
                        <div class='designation' style='font-family:{$pro_font_family};font-size:{$pro_size}px;color:{$pro_color}'>{$profession}</div>
                        <div class='s-icons'>
                            <ul>
                                {$facebook_text}
                                {$twitter_text}
                                {$googleplus_text}
                                {$skype_text}
                                {$linkedin_text}
                            </ul>
                        </div>
                    </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>