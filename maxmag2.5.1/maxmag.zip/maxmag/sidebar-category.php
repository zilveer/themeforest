<div id="sidebar-home-wrapper">
	<div id="home-right">
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Category Middle Widget Area')): endif; ?>
	</div><!--home-right-->
	<div class="side-home">
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar Widget Area')): endif; ?>
	</div><!--side-home-->
</div><!--sidebar-home-wrapper-->