<?php
if (!class_exists('TL_Layers_Abstract_Widget')) { return; }

if (!class_exists('TL_Layers_Header_Widget')) {
    class TL_Layers_Header_Widget extends TL_Layers_Abstract_Widget
    {

        /**
         *  Widget construction
         */
        public function __construct()
        {
            /**
             * Widget variables
             *
             * @param    string $widget_title Widget title
             * @param    string $widget_id Widget slug for use as an ID/classname
             * @param    string $post_type (optional) Post type for use in widget options
             * @param    string $taxonomy (optional) Taxonomy slug for use as an ID/classname
             * @param    array $checkboxes (optional) Array of checkbox names to be saved in this widget. Don't forget these please!
             */
            $this->widget_title = __('TL Page Header', TL_INSERT_STAFF_SLUG);
            $this->widget_id = 'tl_header';
            $this->checkboxes = array(
                'hide_breadcrumbs',
                'exclude_home',
                'hide_navigation',
                'transparent_header'
            );

            /* Widget settings. */
            $widget_ops = array('classname' => 'obox-layers-' . $this->widget_id . '-widget', 'description' => __('This widget is used to display your ', 'layerswp') . $this->widget_title . '.');

            /* Widget control settings. */
            $control_ops = array('width' => LAYERS_WIDGET_WIDTH_SMALL,
                'height' => NULL,
                'id_base' => LAYERS_THEME_SLUG . '-widget-' . $this->widget_id);

            /* Create the widget. */
            parent::__construct(LAYERS_THEME_SLUG . '-widget-' . $this->widget_id, $this->widget_title, $widget_ops, $control_ops);

            /* Setup Widget Defaults */
            $this->defaults = array(
                'title' => __('HEADER TITLE', TL_INSERT_STAFF_SLUG),
            );

            /* Add filters */
            $this->_addFilters();


            $this->get_theme_colors();
        }


        /**
         * @param array $instance
         * @return string|void
         */
        public function form($instance)
        {
            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );


            if(TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_start('tl_sanitize_output');

            $this->design_bar(
                'side', // CSS Class Name
                array(
                    'name' => $this->get_layers_field_name('design'),
                    'id' => $this->get_layers_field_id('design'),
                    'widget_id' => $this->widget_id,
                ), // Widget Object
                $widget, // Widget Values
                apply_filters('layers_' . $this->widget_id . '_widget_design_bar_components', array(
                    'display' => array(
                        'icon-css' => 'icon-display',
                        'label' => __('Display', 'layerswp'),
                        'elements' => array(
                            'hide_breadcrumbs' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('hide_breadcrumbs'),
                                'id' => $this->get_layers_field_id('hide_breadcrumbs'),
                                'value' => (isset($widget['hide_breadcrumbs'])) ? $widget['hide_breadcrumbs'] : NULL,
                                'label' => __('Hide Breadcrumbs', TL_INSERT_STAFF_SLUG)
                            ),
                            'exclude_home' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('exclude_home'),
                                'id' => $this->get_layers_field_id('exclude_home'),
                                'value' => (isset($widget['exclude_home'])) ? $widget['exclude_home'] : NULL,
                                'label' => __('Exclude Home', TL_INSERT_STAFF_SLUG),
                                'description' => __('Removes "Root" item from breadcrumb', TL_INSERT_STAFF_SLUG),
                            ),
                            'hide_navigation' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('hide_navigation'),
                                'id' => $this->get_layers_field_id('hide_navigation'),
                                'value' => (isset($widget['hide_navigation'])) ? $widget['hide_navigation'] : NULL,
                                'label' => __('Hide Navigation', TL_INSERT_STAFF_SLUG),
                            ),
                            'transparent_header' => array(
                                'type' => 'checkbox',
                                'name' => $this->get_layers_field_name('transparent_header'),
                                'id' => $this->get_layers_field_id('transparent_header'),
                                'value' => (isset($widget['transparent_header'])) ? $widget['transparent_header'] : NULL,
                                'label' => __('Make Header Background Transparent', TL_INSERT_STAFF_SLUG),
                            )
                        )
                    ),
                    'background'
                ))
            );
            ?>
            <div class="layers-container-large" >
                <?php $this->form_elements()->header(array(
                        'title'      => __('Header', TL_INSERT_STAFF_SLUG),
                        'icon_class' => 'post'
                )); ?>
                <section class="layers-accordion-section layers-content">
                    <div class="layers-row layers-push-bottom">
                        <p class="layers-form-item">
                            <?php echo $this->form_elements()->input(
                                                array(
                                                    'type' => 'text',
                                                    'name' => $this->get_layers_field_name('title'),
                                                    'id'   => $this->get_layers_field_id('title'),
                                                    'placeholder' => __('Heading Text', TL_INSERT_STAFF_SLUG),
                                                    'value'       => (isset($widget['title'])) ? $widget['title'] : NULL,
                                                    'class'       => 'layers-text layers-large',

                                                )
                                            ); ?>
                            <small class="layers-small-note"><?php _e('Header Title. Leave it blank to remove heading.', TL_INSERT_STAFF_SLUG)?></small>
                        </p>
                        <p class="layers-form-item">
                            <?php
                            $menus = get_registered_nav_menus();

                            echo $this->form_elements()->input(
                                array(
                                    'type' => 'select',
                                    'name' => $this->get_layers_field_name('navigation_menu'),
                                    'id'   => $this->get_layers_field_id('navigation_menu'),
                                    'label' => 'Select Navigation Menu',
                                    'value'       => (isset($widget['navigation_menu'])) ? $widget['navigation_menu'] : NULL,
                                    'options' => $menus,
                                    'class' => 'layers-select layers-large tl-select-post-item',
                                    'placeholder' => __('-- Default --', 'layerswp'),
                                )
                            ); ?>
                            <small class="layers-small-note"><?php _e('Header Title. Leave it blank to remove heading.', TL_INSERT_STAFF_SLUG)?></small>
                        </p>
                    </div>
                </section>
            </div>
        <?php
            if(TL_INSERT_STAFF_WIDGET_FORM_MIN) ob_end_flush();
        }


        /**
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        {
            global $header_widget ,$widget_id;

            $this->backup_inline_css();

            // Turn $args array into variables.
            extract($args);

            // Use defaults if $instance is empty.
            if( empty( $instance ) && ! empty( $this->defaults ) ) {
                $instance = wp_parse_args( $instance, $this->defaults );
            }

            // Mix in new/unset defaults on every instance load (NEW)
            $widget = $this->apply_defaults( $instance );


            // Set header bar backgorund color. First check theme options. If not defined set secondary color
            if($bg_header_color = layers_get_theme_mod('header-background-color', false)){
                // Set inline CSS styles
                $this->inline_css .= layers_inline_styles(array('selectors' => array('.header-site'),
                                           'css'       => array('background-color' =>  $bg_header_color . ' !important;')));
            }else{
                if(isset($this->colors)) {
                    $this->inline_css .= layers_inline_styles(array('selectors' => array('.header-site'),
                        'css' => array('background-color' => $this->colors->get('_secondary') . ' !important')));
                }
            }


            // Background image
            if($this->check_and_return($widget, 'design', 'background', 'image') || $this->check_and_return($widget, 'design', 'background', 'color')){
                $this->inline_css .= layers_inline_styles('#' . $widget_id, 'background', array('background' => $widget['design']['background']));
            }

            if($this->check_and_return($widget, 'transparent_header')){
                $this->inline_css .= layers_inline_styles( '.header-site{ background-color: transparent !important; }' );
            }
            echo $this->custom_anchor( $widget );
            include_once(TL_INSERT_STAFF_DIR . '/widgets/partials/content-header-widget.php');

            // Print the Inline Styles for this Widget
            $this->print_inline_css();
        }



        /**
         *
         */
        protected function _addFilters()
        {
            add_filter('tl/layers/background_component/' . $this->widget_id . '/args', array($this, 'customizeBackgroundComponent'), 10, 4);
        }


        /**
         * @param $args
         * @param $position
         * @param $widget
         * @param $values
         * @return mixed
         */
        public function customizeBackgroundComponent($args, $position, $widget, $values)
        {
            if($position == 'side'){
                unset($args['elements']['background-darken']);
            }
            return $args;
        }

    }

    // Add our function to the widgets_init hook.
    register_widget("TL_Layers_Header_Widget");
}