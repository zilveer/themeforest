function asd(){
	alert(1);
}