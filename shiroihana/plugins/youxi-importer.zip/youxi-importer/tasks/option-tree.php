<?php

function youxi_importer_handle_ot( $data ) {

	if( ! class_exists( 'OT_Loader' ) ) {
		return new WP_Error( 'theme_options_ot_not_found', esc_html__( 'Option Tree is not installed, theme options not imported.', 'youxi' ) );
	}

	try {

		/* decode the theme options data */
		$options = unserialize( ot_decode( $data ) );

		/* has options */
		if ( is_array( $options ) ) {
			/* update the option tree options */
			update_option( ot_options_id(), $options );
		} else {
			return new WP_Error( 'theme_options_invalid_data', esc_html__( 'The supplied theme options data is invalid.', 'youxi' ) );	
		}

	} catch( Exception $e ) {
		return new WP_Error( 'theme_options_unknown_error', $e->getMessage() );
	}

	return esc_html__( 'Theme options successfully imported.', 'youxi' );
}
