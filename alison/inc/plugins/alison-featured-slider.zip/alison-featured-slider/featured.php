<?php

/**
* Plugin Name: Alison Featured Slider
* Plugin URI: http://www.angrygorilla.us
* Description: This plugin adds featured slider for Alison Wordpress Theme.
* Version: 1.0.1
* Author: Angry Gorilla
* Author URI: http://www.angrygorilla.us
* License: GPL2
*/

// Prevent loading this file directly
if ( ! defined( 'ABSPATH' ) ) { exit; }

function gorilla_featured_slider_init(){

	// Admin Controls
	if ( is_admin() ) {

		/* Featured Slider
		--------------------------------------------------------------------------*/

		load_plugin_textdomain('gorilla_featured_slider', false, dirname(plugin_basename( __FILE__ )) . '/lang/');

		include(plugin_dir_path( __FILE__ ).'/featured-admin.php');

	}
}

add_action('init', 'gorilla_featured_slider_init');

if ( !function_exists( 'admin_custom_scripts' ) ) {
	// ADMIN JS&CSS
	function admin_custom_css_js() {

		wp_enqueue_script( 'jquery-ui-js', plugin_dir_url( __FILE__ ).'/assets/js/jquery-ui.min.js', '', '', true );

	}
}

add_action('admin_head', 'admin_custom_css_js');


// Shortcode
add_shortcode('gorilla_featured_slider', 'gorilla_featured_slider_frontend');
function gorilla_featured_slider_frontend(){
	global $gorilla_featured_area_width, $gorilla_featured_area_type, $post, $gorilla_is_mobile;
	
	$gorilla_featured_area_transition = get_theme_mod( 'gorilla_featured_area_transition',"slide" );
	$gorilla_featured_area_autoplay_enabled = get_theme_mod( 'gorilla_featured_area_autoplay_enabled',"true" );
	$gorilla_featured_slide_ids = "";
	$gorilla_featured_area_options = get_option("gorilla_featured_area_options");
	$gorilla_featured_area_slides = get_theme_mod( 'gorilla_featured_area_slides' );

	$gorilla_template_uri = get_template_directory_uri();

	if(!empty($gorilla_featured_area_options)){
		$gorilla_featured_slide_array = unserialize($gorilla_featured_area_options);

		foreach ($gorilla_featured_slide_array as $key => $value) {
			$gorilla_featured_slide_ids[] = $value["post_id"];
		}		
	}

	$arg = array( 
		'post_type' => 'post', 
		'post__in' => $gorilla_featured_slide_ids, 
		'pagination' => false,
		'posts_per_page' => $gorilla_featured_area_slides, 
		'orderby'=>'post__in', 
		'ignore_sticky_posts' => true 
	);

	$gorilla_feat_query = new WP_Query( $arg );

?>

<div class="featured-area <?php echo esc_attr($gorilla_featured_area_width); ?>" data-slider-type="slider" data-slider-transition="<?php echo esc_attr($gorilla_featured_area_transition); ?>"<?php if($gorilla_featured_area_autoplay_enabled) echo ' data-slider-autoplay-enabled="'.esc_attr($gorilla_featured_area_autoplay_enabled).'"'; ?>>
	
	<?php if($gorilla_featured_area_width == "boxed") : ?>
	<div class="container">
	<?php endif; ?>

	<div class="swiper-container-wrapper">

		<div class="swiper-container">
	        <div class="swiper-wrapper">

	        	<?php if ($gorilla_feat_query->have_posts()) : while ($gorilla_feat_query->have_posts()) : $gorilla_feat_query->the_post(); ?>
				
				<?php
					if(!empty($gorilla_featured_slide_array)){
						foreach ($gorilla_featured_slide_array as $key => $val) {
							if ($val['post_id'] === strval($gorilla_feat_query->post->ID)) {
							   $id = $key;
							   break;
							}
					    }
						
						//$gorilla_featured_slide_color_style = $gorilla_featured_slide_array[$id]["slide_color_style"];
						
					}

					/*if(empty($gorilla_featured_slide_color_style)) {
						$gorilla_featured_slide_color_style = "light";
					}*/
				?>

				<!--<div class="swiper-slide <?php //echo esc_attr($gorilla_featured_slide_color_style); ?>">-->
					<div class="swiper-slide">

					<?php

						if($gorilla_is_mobile) {
							$image_size = 'thumbnail-full';
						}
						else {
							if($gorilla_featured_area_width == "full"){
								$image_size = 'full';
							}
							else {
								$image_size = 'thumbnail-full';
							}
						}

						$gorilla_fullwidth_thumb_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $image_size );
					?>
					<div class="slider-item" data-bg-src="<?php echo esc_url($gorilla_fullwidth_thumb_image_url[0]); ?>">
						
						<?php if($gorilla_featured_area_width == "full") : ?>
						<div class="container">
						<?php endif; ?>

							<div class="vertical-middle">
								<div class="vertical-middle-inner">
									<div class="item-header-wrapper animative">
										<?php gorilla_format_icon($post->ID); ?>
										<?php if(!get_theme_mod('gorilla_featured_cat_hide')) : ?>
											<span class="cat item-postit"><?php gorilla_category('', ' / ',"text"); ?></span>
										<?php endif; ?>
										<h2><a href="<?php echo get_permalink() ?>"><?php the_title(); ?></a></h2>
										<?php if(!get_theme_mod('gorilla_featured_author_hide') || !get_theme_mod('gorilla_featured_date_hide')) : ?>
										<span class="date-author">
											<?php if(!get_theme_mod('gorilla_featured_author_hide')) : ?>
												<span class="author"><?php the_author(); ?></span>
											<?php endif; ?>
											<?php if(!get_theme_mod('gorilla_featured_author_hide') && !get_theme_mod('gorilla_featured_date_hide')) : 
												echo "<span class='seperator'>-</span>";
												endif; ?>
											<?php if(!get_theme_mod('gorilla_featured_date_hide')) : ?>
												<span class="date"><?php the_time( get_option('date_format') ); ?></span>
											<?php endif; ?>

										</span>
										<?php endif; ?>
									</div>
								</div>
							</div>

						<?php if($gorilla_featured_area_width == "full") : ?>
						</div>
						<?php endif; ?>
						
					</div>

				</div>
				<?php endwhile; endif; ?>

	        </div>
	        <!-- Add Pagination -->
	        <!--<div class="swiper-pagination"></div>-->

	    </div>

	    <!-- Add Next/Prev -->
	    <div class="swiper-button-prev-custom"><i class="fa fa-angle-left"></i></div>
		<div class="swiper-button-next-custom"><i class="fa fa-angle-right"></i></div>

	</div>

	<?php if($gorilla_featured_area_width == "boxed") : ?>
	</div>
	<?php endif; ?>
	
</div>

<?php
}