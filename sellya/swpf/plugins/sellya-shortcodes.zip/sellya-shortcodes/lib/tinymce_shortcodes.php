<?php file_exists('../../../../wp-load.php') ? require_once('../../../../wp-load.php') : require_once('../../../../../wp-load.php'); 

$version = get_bloginfo('version');
?><!DOCTYPE html>

<html <?php language_attributes(); ?>>

<head>

	

<meta charset="<?php bloginfo( 'charset' ); ?>" />

<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

	<title></title>



	<link rel="stylesheet" type="text/css" href="shortcode_styles.css" />

	<script type="text/javascript" src="<?php echo includes_url('js/jquery/jquery.js?ver=1.8.3')?>"></script>

    <script type="text/javascript" src="<?php echo site_url(); ?>/wp-includes/js/tinymce/tiny_mce_popup.js"></script>

    <script type="text/javascript">

		jQuery(document).ready(function() {

			jQuery('#insert').attr("disabled", true);

			jQuery('#insert').addClass("disabled");

			jQuery('#select_shortcode').change(function() {

				if( jQuery(this).val() == '' ) {

					jQuery('#insert').attr("disabled", true);

					jQuery('#insert').addClass("disabled");

				} else {

					jQuery('#insert').removeAttr("disabled");

					jQuery('#insert').removeClass("disabled");

				}

			});

		});

		

		function returnShortcodeValue() {

			var out;

			

			switch(jQuery('#select_shortcode').val())

			{

                                case "full": 

					out = "[full]<p>Your content here...</p>[/full]<br />";

					break;

				case "half": 

					out = "[half]<p>Your content here...</p>[/half]<br />";

					break;

				case "half_first": 

					out = "[half_first]<p>Your content here...</p>[/half_first]<br />";

					break;

				case "one_third": 

					out = "[one_third]<p>Your content here...</p>[/one_third]<br />";

					break;

				case "one_third_first": 

					out = "[one_third_first]<p>Your content here...</p>[/one_third_first]<br />";

					break;

				case "two_thirds": 

					out = "[two_thirds]p>Your content here...</p>[/two_thirds]<br />";

					break;

				case "two_thirds_first": 

					out = "[two_thirds_first]<p>Your content here...</p>[/two_thirds_first]<br />";

					break;

				case "one_fourth": 

					out = "[one_fourth]<p>Your content here...</p>[/one_fourth]<br />";

					break;

				case "one_fourth_first": 

					out = "[one_fourth_first]<p>Your content here...</p>[/one_fourth_first]<br />";

					break;

				case "three_fourths": 

					out = "[three_fourths]<p>Your content here...</p>[/three_fourths]<br />";

					break;

				case "three_fourths_first": 

					out = "[three_fourths_first]<p>Your content here...</p>[/three_fourths_first]<br />";

					break;
                                
                                
				case "flexslider":

					out = "[flexslider id='flexslider']<br />[ftab title=\"title1\" link=\"\" imageurl=\"\"][/ftab]<br />[ftab title=\"title1\" link=\"\" imageurl=\"\"][/ftab]<br />[ftab title=\"title1\" link=\"\" imageurl=\"\"][/ftab]<br />[ftab title=\"title1\" link=\"\" imageurl=\"\"][/ftab]<br />[/flexslider]<br />";

					break;	

				case "cameraslider":

					out = "[cameraslider id='camera_wrap']<br />[ctab link=\"\" imageurl=\"\"][/ctab]<br />[ctab link=\"\" imageurl=\"\"][/ctab]<br />[ctab link=\"\" imageurl=\"\"][/ctab]<br />[ctab link=\"\" imageurl=\"\"][/ctab]<br />[/cameraslider]<br />";

					break;					

                                case "productslider":
                                
                                        out = "[productslider showproducts='-1']<br />";
                                
                                        break;
                                
                                case "sellya-productcats":
                                
                                        out = "[sellya-productcats]<br />";
                                
                                        break;
                                

                                case "latest_posts":

					out = "[sellya_latest_posts posts_per_page='<?php echo get_option('posts_per_page')?>' column='3']<br />";

					break;	

				case "button_purche":

					out = "[button_purche url=http://www.google.com bottom_text=\"add boottom text for purche button\"]Purche[/button_purche]<br />";

					break;	
                                        
                                case "button_download":

					out = "[button_download url=http://www.google.com bottom_text=\"add boottom text for download button\"]Download[/button_download]<br />";

					break;		

				case "button_search_c":

					out = "[button_search_c url=http://www.google.com bottom_text=\"add boottom text for search button\"]Search[/button_search_c]<br />";

					break;						

				case "buttons_small":

					out = "[buttons_small][/buttons_small]<br />";

					break;
					
				case "buttons_medium":

					out = "[buttons_medium][/buttons_medium]<br />";

					break;
					
				case "buttons_large":

					out = "[buttons_large][/buttons_large]<br />";

					break;

				case "button":

					out = "[button]Button[/button]";

					break;
					
				case "button_grey":

					out = "[button_grey]Button[/button_grey]";

					break;
					
				case "button_red":

					out = "[button_red]Button[/button_red]";

					break;
					
				case "button_yellow":

					out = "[button_yellow]Button[/button_yellow]";

					break;
					
				case "button_olive":

					out = "[button_olive]Button[/button_olive]";

					break;
					
				case "button_lightblue":

					out = "[button_lightblue]Button[/button_lightblue]";

					break;
					
				case "button_black":

					out = "[button_black]Button[/button_black]";

					break;
													

				case "ribbon_red":

					out = "[ribbon_red url=http://www.google.com]Ribbon[/ribbon_red]<br />";

					break;		

				case "ribbon_blue":

					out = "[ribbon_blue url=http://www.google.com]Ribbon[/ribbon_blue]<br />";

					break;	

				case "ribbon_white":

					out = "[ribbon_white url=http://www.google.com]Ribbon[/ribbon_white]<br />";

					break;	

				case "ribbon_yellow":

					out = "[ribbon_yellow url=http://www.google.com]Ribbon[/ribbon_yellow]<br />";

					break;	

				case "ribbon_green":

					out = "[ribbon_green url=http://www.google.com]Ribbon[/ribbon_green]<br />";

					break;						

				case "box_1":

					out = "[info]<br />Content...<br />[/info]<br />";

					break;

				case "box_2":

					out = "[success]<br />Content...<br />[/success]<br />";

					break;

				case "box_3":

					out = "[question]<br />Content...<br />[/question]<br />";

					break;

				case "box_4":

					out = "[error]<br />Content...<br />[/error]<br />";

					break;
					
					
				case "msgbox":

					out = "[msgbox]Content...[/msgbox]<br />";

					break;
				
				case "msgbox2":

					out = "[msgbox2]Content...[/msgbox2]<br />";

					break;
					
				case "msgbox3":

					out = "[msgbox3]Content...[/msgbox3]<br />";

					break;
					
				case "msgbox4":

					out = "[msgbox4]Content...[/msgbox4]<br />";

					break;	

				case "progressbar":

					out = "[progressbar progress=30 color=#fff]Title[/progressbar]<br />";

					break;						

				case "accordion":

					out = "[accordion][atab title=\"First tab\"]Tab content goes here[/atab][atab title=\"Second tab\"]Tab content goes here[/atab][atab title=\"Third tab\"]Tab content goes here[/atab][/accordion]<br />";

					break;
				
				case "tabs":

					out = "[tabgroup]<br />[tab title=\"First tab\"]Tab content goes here[/tab]<br />[tab title=\"Second tab\"]Tab content goes here[/tab]<br />[tab title=\"Third tab\"]Tab content goes here[/tab]<br /> [/tabgroup]<br />";

					break;

				case "toggle":

					out = "[toggle title=\"Toggle title...\"]Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.[/toggle]<br />";

					break;

				case "title":

					out = "[title]Title Example[/title]<br />";

					break;

				case "break":

					out = "[break/]<br />";

					break;

				case "totop":

					out = "[dividertop]<br />";

					break;					

				case "dropcap_with_bg":

					out = "[dropcap_with_bg]A[/dropcap_with_bg]";

					break;

				case "dropcap":

					out = "[dropcap]A[/dropcap]";

					break;
					
				case "list_checkbox":

					out = "[list_checkbox][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_checkbox]";

					break;
					
				case "list_cross":

					out = "[list_cross][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_cross]";

					break;
					
				case "list_rarrow":

					out = "[list_rarrow][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_rarrow]";

					break;
					
				case "list_circle":

					out = "[list_circle][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_circle]";

					break;
					
				case "list_checkbox2":

					out = "[list_checkbox2][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_checkbox2]";

					break;
					
				case "list_cross2":

					out = "[list_cross2][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_cross2]";

					break;
					
				case "list_rarrow":

					out = "[list_rarrow2][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_rarrow2]";

					break;
					
				case "list_circle2":

					out = "[list_circle2][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_circle2]";

					break;
					
				case "list_checkbox3":

					out = "[list_checkbox3][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_checkbox3]";

					break;
					
				case "list_cross3":

					out = "[list_cross3][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_cross3]";

					break;
					
				case "list_rarrow3":

					out = "[list_rarrow3][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_rarrow3]";

					break;
					
				case "list_circle":

					out = "[list_circle][li]list item...[/li][li]list item...[/li][li]list item...[/li][/list_circle]";

					break;


				case "list_comment":

					out = "[list_comment]<br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br />[/list_comment]<br />";

					break;


				case "list_plus":

					out = "[list_plus]<br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br />[/list_plus]<br />";

					break;

				case "list_ribbon":

					out = "[list_ribbon]<br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br />[/list_ribbon]<br />";

					break;

				case "list_settings":

					out = "[list_settings]<br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br />[/list_settings]<br />";

					break;

				case "list_star":

					out = "[list_star]<br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br />[/list_star]<br />";

					break;

				case "list_image":

					out = "[list_image]<br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br />[/list_image]<br />";

					break;

				case "list_link":

					out = "[list_link]<br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br />[/list_link]<br />";

					break;		

				case "list_mail":

					out = "[list_mail]<br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br />[/list_mail]<br />";

					break;						

				case "list_arrow":

					out = "[list_arrow]<br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br />[/list_arrow]<br />";

					break;

				case "list_tick":

					out = "[list_tick]<br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br />[/list_tick]<br />";

					break;					

				case "list_arrow_point":

					out = "[list_arrow_point]<br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br /><li>list item...</li><br />[/list_arrow_point]<br />";

					break;	

				case "block-quote":

					out = "[block-quote]Lorem ipsum dolor sit amet....[/block-quote]<br />";

					break;

				case "block-quote-left":

					out = "[block-quote-left]Lorem ipsum dolor sit amet....[/block-quote-left] <br />";

					break;
					
				case "block-quote-right":

					out = "[block-quote-right]Lorem ipsum dolor sit amet....[/block-quote-right] <br />";

					break;
					
				case "testimonial_quote":

					out = "[testimonial_quote name = 'Name']Lorem ipsum dolor sit amet....[/testimonial_quote] <br />";

					break;
					
				case "gmap":
				
					out = "[gmap elem='map' lat='-34.397' lng='150.644' zoom='8' height='350' title='']";
				
					break;

				default: 

					out = '';

			}
                        <?php if($version < 3.9){?>

                        window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.editorId, 'mceInsertContent', false, out);
                        window.tinyMCE.activeEditor.execCommand('mceRepaint');
                        tinyMCEPopup.close();

                        <?php }else{?>
                        parent.tinyMCE.execCommand('mceInsertContent', false,out);
                        parent.tinyMCE.activeEditor.windowManager.close();
                        <?php }?>
			

//			window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.editorId, 'mceInsertContent', false, out);
//			window.tinyMCE.activeEditor.execCommand('mceRepaint');
//			tinyMCEPopup.close();

		}

    </script>

</head>

<body>

	<fieldset>

    <legend>Select a Shortcode</legend>

	<div>

        <select id="select_shortcode">

			<option value="">Select</option>
                            <optgroup label="Columns">
					
					<option value="full">Full</option>

					<option value="half">Half</option>

					<option value="half_first">Half First</option>

					<option value="one_third">One Third</option>

					<option value="one_third_first">One Third First</option>

					<option value="two_thirds">Two Thirds</option>

					<option value="two_thirds_first">Two Thirds First</option>

					<option value="one_fourth">One Fourth</option>

					<option value="one_fourth_first">One Fourth First</option>

					<option value="three_fourths">Three Fourths</option>

					<option value="three_fourths_first">Three Fourths First</option>


				</optgroup>
        	<optgroup label="Buttons with images">				

				<option value="button_purche">Purche Button</option> 

				<option value="button_download">Download Button</option> 	

				<option value="button_search_c">Search Button</option> 	

				<option value="ribbon_red">Ribbon red</option> 			

				<option value="ribbon_blue">Ribbon blue</option> 	

				<option value="ribbon_white">Ribbon white</option> 	

				<option value="ribbon_green">Ribbon green</option> 	

				<option value="ribbon_yellow">Ribbon yellow</option> 					

			</optgroup>			
			<optgroup label="Blockquotes">
            
            	<option value="block-quote">Blockquote</option>
                
                <option value="block-quote-left">Blockquote left</option>
                
                <option value="block-quote-right">Blockquote right</option>
            
            	<option value="testimonial_quote">Testimonial Quote</option>
            
            </optgroup>

			<optgroup label="Button sizes">
            
            	<option value="buttons_small">Small</option>
                
                <option value="buttons_medium">Medium</option>
                
                <option value="buttons_large">Large</option>
            
            </optgroup>

        	<optgroup label="Buttons">			

				<option value="button">Light White Button</option>

				<option value="button_grey">Grey Button</option>  

				<option value="button_red">Red Button</option>  

				<option value="button_yellow">Yellow Button</option>  

				<option value="button_olive">Olive Button</option>  
				
                <option value="button_lightblue">Light Blue Button</option>
				  
 				<option value="button_black">Black Button</option>

			</optgroup>
			<optgroup label="Message boxes">

				<option value="msgbox">Message box 1</option>
                
                <option value="msgbox2">Message box 2</option>
                
                <option value="msgbox3">Message box 3</option>
                
                <option value="msgbox4">Message box 4</option>

			</optgroup>
                        <optgroup label="Image Sliders">
                            <option value="flexslider">Flexslider</option>				
                            <option value="cameraslider">Camera slider</option>
                            <option value="productslider">Product slider</option>
                        </optgroup>
			<optgroup label="Toggle Elements">                                                                
                            <option value="accordion">Accordion</option>
                            <option value="tabs">Tabs</option>  
                            <option value="toggle">Toggle</option>				
			</optgroup>	
			<optgroup label="Google Map">
            	<option value="gmap">Google Map</option>
            </optgroup>
            <optgroup label="Sliders">            	
                <option value="cameraslider">Camera Slider</option>
            	<option value="flexslider">Flexslider</option>
            </optgroup>
            <optgroup label="Posts">
            	<option value="latest_posts">Latest Posts</option>                
            </optgroup>
            <optgroup label="Product Category">
            	<option value="sellya-productcats">Woocommerce Product Category</option>                
            </optgroup>
        	<optgroup label="Styling Elements">

                        <option value="dropcap_with_bg">Drop cap for background</option>

                        <option value="dropcap">Drop Cap</option>	

                        <option value="break">Line Break</option>	

                        <option value="list_checkbox">Checkbox List</option>

                        <option value="list_cross">Cross List</option>
                
                        <option value="list_rarrow">Right Arrow List</option>

                        <option value="list_circle">Circle List</option>

                        <option value="list_checkbox2">Checkbox List 2</option>

			<option value="list_cross2">Cross List 2</option>
                
                        <option value="list_rarrow2">Right Arrow List 2</option>

                        <option value="list_circle2">Circle List 2</option>

                        <option value="list_checkbox2">Checkbox List 3</option>

			<option value="list_cross3">Cross List 3</option>
                
                        <option value="list_rarrow3">Right Arrow List 3</option>
                
                        <option value="list_circle3">Circle List 3</option>
			

                </optgroup>		

        </select>

		</div>

		</fieldset>



    <div>

        <input type="submit" value="Add" onclick="returnShortcodeValue()" id="insert" /> <input type="button" value="Close" onclick="tinyMCEPopup.close()" id="cancel" />

	</div>



</body>

</html>