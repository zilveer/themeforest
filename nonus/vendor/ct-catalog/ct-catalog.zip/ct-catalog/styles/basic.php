<?php
/** Default */
//Colors
($btnBgClr=="")? $btnBgClr='#ebebeb':$btnBgClr=$btnBgClr;
($btnBgClrHover=="")? $btnBgClrHover='#f3f3f3':$btnBgClrHover=$btnBgClrHover;
($btnTxtClr=="")? $btnTxtClr='#767676':$btnTxtClr=$btnTxtClr;

//Border
($btnThicknessValue=="")? $btnThicknessValue='1':$btnThicknessValue=$btnThicknessValue;
($btnBorderClr=="")? $btnBorderClr='#c7c7c7':$btnBorderClr=$btnBorderClr;

//Padding small
($btpTop=="")? $btpTopSmall='7':$btpTopSmall=$btpTop;
($btpRight=="")? $btpRightSmall='12':$btpRightSmall=$btpRight;
($btpBottom=="")? $btpBottomSmall='7':$btpBottomSmall=$btpBottom;
($btpLeft=="")? $btpLeftSmall='12':$btpLeftSmall=$btpLeft;

//Padding
($btpTop=="")? $btpTop='10':$btpTop=$btpTop;
($btpRight=="")? $btpRight='15':$btpRight=$btpRight;
($btpBottom=="")? $btpBottom='10':$btpBottom=$btpBottom;
($btpLeft=="")? $btpLeft='15':$btpLeft=$btpLeft;

?>


<style type="text/css">
    .ct-style-basic.<?php echo $value; ?> {
        background:<?php echo $btnBgClr; ?>;
        color: <?php echo $btnTxtClr; ?> !important;
        font-weight: bold;
        padding: <?php echo $btpTop; ?>px <?php echo $btpRight; ?>px <?php echo $btpBottom; ?>px <?php echo $btpLeft; ?>px !important;
        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClr; ?> !important;
        text-decoration: none !important;
        display: inline-block !important;

        -webkit-box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        -moz-box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        box-shadow: <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -moz-border-radius: <?php echo $btnRadiusValue; ?>px !important;
        -webkit-border-radius: <?php echo $btnRadiusValue; ?>px !important;
        margin: <?php echo $btmTop; ?>px <?php echo $btmRight; ?>px <?php echo $btmBottom; ?>px <?php echo $btmLeft; ?>px !important;
    }

    .ct-style-basic.small.<?php echo $value; ?> {
        font-size: 12px !important;
        padding: <?php echo $btpTopSmall; ?>px <?php echo $btpRightSmall; ?>px <?php echo $btpBottomSmall; ?>px <?php echo $btpLeftSmall; ?>px !important;
    }

    .ct-style-basic.<?php echo $value; ?>:hover, .basic.small.<?php echo $value; ?>:hover {
        background:<?php echo $btnBgClrHover; ?> !important;

        color: <?php echo $btnTxtClrHover; ?> !important;
        text-decoration: none !important;
        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClrHover; ?> !important;
    }
</style>