<?php

if (!class_exists("Redux_Framework_Aura_Mobile_Config")) {

    class Redux_Framework_Aura_Mobile_Config {

        public $args = array();
        public $sections = array();
        public $theme;
        public $ReduxFramework;

        public function __construct() {
            // This is needed. Bah WordPress bugs.  ;)
            if ( defined('TEMPLATEPATH') && strpos(__FILE__,TEMPLATEPATH) !== false) {
                $this->initSettings();
            } else {
                add_action('plugins_loaded', array($this, 'initSettings'), 10);    
            }
        }

        public function initSettings() {

            if ( !class_exists("ReduxFramework" ) ) {
                return;
            }       
            
            // Just for demo purposes. Not needed per say.
            $this->theme = wp_get_theme();

            // Set the default arguments
            $this->setArguments();

            // Set a few help tabs so you can see how it's done
            $this->setHelpTabs();

            // Create the sections and fields
            $this->setSections();

            if (!isset($this->args['opt_name'])) { // No errors please
                return;
            }

            // If Redux is running as a plugin, this will remove the demo notice and links
            add_action( 'redux/loaded', array( $this, 'remove_demo' ) );
            add_filter('redux/options/' . $this->args['opt_name'] . '/sections', array($this, 'dynamic_section'));

            $this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
        }

        function compiler_action($options, $css) {
            
        }

        function dynamic_section($sections) {
            //$sections = array();
            
            return $sections;
        }

        function change_arguments($args) {
            //$args['dev_mode'] = true;

            return $args;
        }

  
        function remove_demo() {

            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if (class_exists('ReduxFrameworkPlugin')) {
                remove_filter('plugin_row_meta', array(ReduxFrameworkPlugin::instance(), 'plugin_metalinks'), null, 2);

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));
            }
        }

        public function setSections() {
            $aura_menu_bg_path = ReduxFramework::$_dir . '../aura/menuimages/';
            $aura_menu_bg_url = ReduxFramework::$_url . '../aura/menuimages/';
            $aura_menu_bg = array();

            if (is_dir($aura_menu_bg_path)) :

                if ($aura_menu_bg_dir = opendir($aura_menu_bg_path)) :
                    $aura_menu_bg = array();

                    while (( $aura_menu_bg_file = readdir($aura_menu_bg_dir) ) !== false) {

                        if (stristr($aura_menu_bg_file, '.png') !== false || stristr($aura_menu_bg_file, '.jpg') !== false) {
                            $name = explode(".", $aura_menu_bg_file);
                            $name = str_replace('.' . end($name), '', $aura_menu_bg_file);
                            $aura_menu_bg[] = array('alt' => $name, 'img' => $aura_menu_bg_url . $aura_menu_bg_file);
                        }
                    }
                endif;
            endif;

            ob_start();

            $ct = wp_get_theme();
            $this->theme = $ct;
            $item_name = $this->theme->get('Name');
            $tags = $this->theme->Tags;
            $screenshot = $this->theme->get_screenshot();
            $class = $screenshot ? 'has-screenshot' : '';

            $customize_title = sprintf(__('Customize &#8220;%s&#8221;', 'auraplgt2d'), $this->theme->display('Name'));
            ?>
            <div id="current-theme" class="<?php echo esc_attr($class); ?>">
            <?php if ($screenshot) : ?>
                <?php if (current_user_can('edit_theme_options')) : ?>
                        <a href="<?php echo wp_customize_url(); ?>" class="load-customize hide-if-no-customize" title="<?php echo esc_attr($customize_title); ?>">
                            <img src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview'); ?>" />
                        </a>
                <?php endif; ?>
                    <img class="hide-if-customize" src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview'); ?>" />
            <?php endif; ?>

                <h4>
            <?php echo $this->theme->display('Name'); ?>
                </h4>

                <div>
                    <ul class="theme-info">
                        <li><?php printf(__('By %s', 'auraplgt2d'), $this->theme->display('Author')); ?></li>
                        <li><?php printf(__('Version %s', 'auraplgt2d'), $this->theme->display('Version')); ?></li>
                        <li><?php echo '<strong>' . __('Tags', 'auraplgt2d') . ':</strong> '; ?><?php printf($this->theme->display('Tags')); ?></li>
                    </ul>
                    <p class="theme-description"><?php echo $this->theme->display('Description'); ?></p>
                <?php
                if ($this->theme->parent()) {
                    printf(' <p class="howto">' . __('This <a href="%1$s">child theme</a> requires its parent theme, %2$s.') . '</p>', __('http://codex.wordpress.org/Child_Themes', 'auraplgt2d'), $this->theme->parent()->display('Name'));
                }
                ?>

                </div>

            </div>

            <?php
            $item_info = ob_get_contents();

            ob_end_clean();

            $sampleHTML = '';
            if (file_exists(dirname(__FILE__) . '/info-html.html')) {
                /** @global WP_Filesystem_Direct $wp_filesystem  */
                global $wp_filesystem;
                if (empty($wp_filesystem)) {
                    require_once(ABSPATH . '/wp-admin/includes/file.php');
                    WP_Filesystem();
                }
                $sampleHTML = $wp_filesystem->get_contents(dirname(__FILE__) . '/info-html.html');
            }




            // ACTUAL DECLARATION OF SECTIONS

            $this->sections[] = array(
			'id' => 'general',
			'title' => 'General',
			'icon' => 'el-icon-cogs',
			'fields' => array (
				array (
					'id' => 'general_themeswitchermode',
					'desc' => __('This option will enable / disable menu and widget registration when use Aura in Theme Switcher Mode. Please only activate when using Aura with your existing website.', 'auraplgt2d'),
					'type' => 'switch',
					'title' => __('Theme Switcher Mode', 'auraplgt2d'),
					'default' => '0',
				),
				array (
					'id' => 'general_swipe',
					'desc' => __('This option will enable / disable swipe left/right feature.', 'auraplgt2d'),
					'type' => 'switch',
					'title' => __('Swipe Feature', 'auraplgt2d'),
					'default' => '1',
				),
				array (
					'id' => 'general_ioswebapp',
					'desc' => __('This option will enable / disable iOS iWeb App feature.', 'auraplgt2d'),
					'type' => 'switch',
					'title' => __('iOS Web App', 'auraplgt2d'),
					'default' => '1',
				),
				array (
					'id' => 'general_loading',
					'desc' => __('Stop loading animation by disable this.', 'auraplgt2d'),
					'type' => 'switch',
					'title' => __('Loading Animation', 'auraplgt2d'),
					'default' => '1',
				),
				array(
					'id' => 'general_autoopenstart',
					'desc' => __('If this enabled menu will open auto at web site entrance.', 'auraplgt2d'),
					'type' => 'switch',
					'title' => __('Auta Open Menu at Startup', 'auraplgt2d'),
					'default' => '0',
				),
				array(
                        'id' => 'general_loadingcolor',
                        'type' => 'button_set',
                        'title' => __('Loading Window BG Color', 'auraplgt2d'),
                        'desc' => __('Change loading animation background color. Default: Black', 'auraplgt2d'),
                        'options' => array('black' => __('Black', 'auraplgt2d'), 'white' => __('White', 'auraplgt2d')), //Must provide key => value pairs for radio options
                        'default' => 'black'
                    ),
				array (
					'id' => 'general_customcss',
					'desc' => __('Copy & paste your custom css codes in this area. (Optional)', 'auraplgt2d'),
					'type' => 'ace_editor',
					'title' => __('Custom CSS Code', 'auraplgt2d'),
					'mode' => 'css',
                    'theme' => 'monokai',
				),
				array (
					'id' => 'googleanalytics_code',
					'desc' => __('Please copy & paste your google analytic code with script	tags.', 'auraplgt2d'),
					'type' => 'ace_editor',
					'title' => __('Google Analytics Code', 'auraplgt2d'),
					'mode' => 'javascript',
                    'theme' => 'chrome',
				),
			),
		);
		
		$this->sections[] = array (
			'id' => 'menudefaults',
			'title' => 'Menu Settings',
			'icon' => 'el-icon-wrench',
			'fields' => array (
				array (
					'id' => 'mhelpbox_help1465',
					'desc' => __('Please change menu default settings and configs below.', 'auraplgt2d'),
					'type' => 'info',
					'title' => __('Info', 'auraplgt2d'),
				),
				array(
					'id' => 'menudefaults_buttontype',
					'type' => 'button_set',
					'title' => __('Button Type', 'auraplgt2d'),
					'options' => array('1' => 'Circle', '2' => 'Square', '3' => 'Rounded Square'), 
					'default' => '3'
				),
				array(
					'id' => 'menudefaults_bordertype',
					'type' => 'border',
					'title' => __('Border Type', 'auraplgt2d'),
					'subtitle' => __('Please choose a border type of menu.', 'auraplgt2d'),
					'color' => false,
					'all' => true,
					'default' => array('border-style' => 'solid', 'border-top' => '3px', 'border-right' => '3px', 'border-bottom' => '3px', 'border-left' => '3px')
				),
				array(
					'id' => 'menudefaults_iconbgcolor',
					'type' => 'color',
					'title' => __('Button Background Color', 'auraplgt2d'),
					'subtitle' => __('Pick a background color for the menu .', 'auraplgt2d'),
					'default' => '#FFFFFF',
					'validate' => 'color',
				),
				array(
					'id' => 'menudefaults_iconbordercolor',
					'type' => 'color',
					'title' => __('Button Border Color', 'auraplgt2d'),
					'subtitle' => __('Pick a border color for the menu .', 'auraplgt2d'),
					'default' => '#FFFFFF',
					'validate' => 'color',
				),
				array(
					'id' => 'menudefaults_icontextcolor',
					'type' => 'color',
					'title' => __('Icon Color', 'auraplgt2d'),
					'subtitle' => __('Pick a icon color for the menu .', 'auraplgt2d'),
					'default' => '#FFFFFF',
					'validate' => 'color',
				),
				array (
					'id' => 'mhelpbox_help14652',
					'desc' => __('Please select a font background color or image. Recommended size: any photo tileable.', 'auraplgt2d'),
					'type' => 'info',
					'title' => __('Info', 'auraplgt2d'),
				),
				array (
					'id' => 'menudefaults_menufont',
					'type' => 'typography',
					'title' => __('Menu Font', 'auraplgt2d'),
					'google'      => true, 
					'font-backup' => true,
					'font-size'   => true, 
					'line-height' => true,
					'output'      => array('.aura-menu-icon-text'),
					'units'       =>'px',
					'default'     => array(
						'color'       => '#422c2c', 
						'font-style'  => '300', 
						'font-family' => 'Roboto', 
						'google'      => true,
						'font-size'   => '13px', 
						'line-height' => '16px',
					),
				),
				
				array(
					'id' => 'menudefaults_custommenubgimage',
					'type' => 'background',
					'output' => array('.auraoverlay'),
					'title' => __('Menu Background', 'auraplgt2d'),
					'subtitle' => __('If want to use custom image for menu background please upload on this section.', 'auraplgt2d'),
					'default' => array('background-color'=>'#ffffff'),
				),
				
			),
		);
		
			$this->sections[] = array (
			'id' => 'menulayout',
			'title' => 'Top Bar Settings',
			'icon' => 'el-icon-website',
			'fields' => array (
				array (
					'id' => 'mhelpbox_help1',
					'desc' => __('Below settings will effect top bar area. Leave blank for load default settings. If need help about this page please check help documentations. <strong>Icon sizes must be same as our surces > fontawesome icon sizes Ex: 512px x 346px.</strong> We are using big icons because seen more sharp on retina devices.', 'auraplgt2d'),
					'type' => 'info',
					'title' => __('Info', 'auraplgt2d'),
				),
				array (
					'id' => 'tcustomizer_topheaderbackground',
					'type' => 'color',
					'title' => __('Top Bar Background', 'auraplgt2d'),
					'default' => '#37afea',
				),
				
				array(
					'id' => 'tcustomizer_topheaderheight',
					'type' => 'slider',
					'title' => __('Top Bar Height (px)', 'auraplgt2d'),
					'desc' => __('Change top bar height value. Default:46px;', 'auraplgt2d'),
					"default" => "43",
					"min" => "40",
					"step" => "1",
					"max" => "60",
				),
				array(
					'id' => 'tcustomizer_topheaderborderp',
					'type' => 'border',
					'title' => __('Header Border Option', 'auraplgt2d'),
					'output' => array('#auratoolbar'), 
					'left' => false,
					'right' => false,
					'top' => false,
					'bottom' => true,
					'all' => false,
					'default' => array('border-color' => '#ffffff', 'border-style' => 'solid', 'border-bottom' => '1px')
				),
				array (
					'id' => 'topbar_menuimg',
					'desc' => __('<small>Upload your custom menu icon and disable existing image. If leave empty default menu icon will be displayed. Sample icons in sources folder > fontawesome-image-icons-black/white.</small>', 'auraplgt2d'),
					'type' => 'media',
					'title' => __('Menu Icon', 'auraplgt2d'),
				),
				
				array (
					'id' => 'topbar_menucloseimg',
					'desc' => __('<small>Upload your custom menu close icon and disable existing image. If leave empty default menu close icon will be displayed. Sample icons in sources folder > fontawesome-image-icons-black/white.</small>', 'auraplgt2d'),
					'type' => 'media',
					'title' => __('Menu Close Icon', 'auraplgt2d'),
				),
				
				array (
					'id' => 'topbar_backimg',
					'desc' => __('<small>Upload your custom back icon and disable existing image. If leave empty default back icon will be displayed. Sample icons in sources folder > fontawesome-image-icons-black/white.</small>', 'auraplgt2d'),
					'type' => 'media',
					'title' => __('Back Icon', 'auraplgt2d'),
				),
				
				 array(
					'id' => 'section-topbarbutton1-start',
					'type' => 'section',
					'title' => __('Button 1', 'auraplgt2d'),
					'indent' => true 
				),
					array (
						'id' => 'topbar_buton1icon',
						'desc' => __('<small>Upload your custom button icon. Sample icons in sources folder > fontawesome-image-icons-black/white.</small>', 'auraplgt2d'),
						'type' => 'media',
						'title' => __('Button Icon', 'auraplgt2d'),
					),
					array(
						'id' => 'topbar_buton1link',
						'type' => 'text',
						'title' => __('Buton URL', 'auraplgt2d'),
						'desc' => __('<small>Please write an url for this button. This must be have (http://) (mailto:) (tel:).</small>', 'auraplgt2d'),
					),
				array(
					'id' => 'section-topbarbutton1-end',
					'type' => 'section',
					'indent' => false
				),
				
				
				array(
					'id' => 'section-topbarbutton2-start',
					'type' => 'section',
					'title' => __('Button 2', 'auraplgt2d'),
					'indent' => true 
				),
					array (
						'id' => 'topbar_buton2icon',
						'desc' => __('<small>Upload your custom button icon. Sample icons in sources folder > fontawesome-image-icons-black/white.</small>', 'auraplgt2d'),
						'type' => 'media',
						'title' => __('Button Icon', 'auraplgt2d'),
					),
					array(
						'id' => 'topbar_buton2link',
						'type' => 'text',
						'title' => __('Buton URL', 'auraplgt2d'),
						'desc' => __('<small>Please write an url for this button. This must be have (http://) (mailto:) (tel:).</small>', 'auraplgt2d'),
					),
				array(
					'id' => 'section-topbarbutton2-end',
					'type' => 'section',
					'indent' => false 
				),
				
				
				array(
					'id' => 'section-topbarbutton3-start',
					'type' => 'section',
					'title' => __('Button 3', 'auraplgt2d'),
					'indent' => true 
				),
					array (
						'id' => 'topbar_buton3icon',
						'desc' => __('<small>Upload your custom button icon. Sample icons in sources folder > fontawesome-image-icons-black/white.</small>', 'auraplgt2d'),
						'type' => 'media',
						'title' => __('Button Icon', 'auraplgt2d'),
					),
					array(
						'id' => 'topbar_buton3link',
						'type' => 'text',
						'title' => __('Buton URL', 'auraplgt2d'),
						'desc' => __('<small>Please write an url for this button. This must be have (http://) (mailto:) (tel:).</small>', 'auraplgt2d'),
					),
				array(
					'id' => 'section-topbarbutton3-end',
					'type' => 'section',
					'indent' => false 
				),
				
				
				array(
					'id' => 'section-topbarbutton4-start',
					'type' => 'section',
					'title' => __('Button 4', 'auraplgt2d'),
					'indent' => true 
				),
					array (
						'id' => 'topbar_buton4icon',
						'desc' => __('<small>Upload your custom button icon. Sample icons in sources folder > fontawesome-image-icons-black/white.</small>', 'auraplgt2d'),
						'type' => 'media',
						'title' => __('Button Icon', 'auraplgt2d'),
					),
					array(
						'id' => 'topbar_buton4link',
						'type' => 'text',
						'title' => __('Buton URL', 'auraplgt2d'),
						'desc' => __('<small>Please write an url for this button. This must be have (http://) (mailto:) (tel:).</small>', 'auraplgt2d'),
					),
				array(
					'id' => 'section-topbarbutton4-end',
					'type' => 'section',
					'indent' => false 
				),
				
				array(
					'id' => 'section-topbarbutton5-start',
					'type' => 'section',
					'title' => __('Button 5', 'auraplgt2d'),
					'indent' => true 
				),
					array (
						'id' => 'topbar_buton5icon',
						'desc' => __('<small>Upload your custom button icon. Sample icons in sources folder > fontawesome-image-icons-black/white.</small>', 'auraplgt2d'),
						'type' => 'media',
						'title' => __('Button Icon', 'auraplgt2d'),
					),
					array(
						'id' => 'topbar_buton5link',
						'type' => 'text',
						'title' => __('Buton URL', 'auraplgt2d'),
						'desc' => __('<small>Please write an url for this button. This must be have (http://) (mailto:) (tel:).</small>', 'auraplgt2d'),
					),
				array(
					'id' => 'section-topbarbutton5-end',
					'type' => 'section',
					'indent' => false 
				),	
			),
		);
		
			$this->sections[] = array (
			'id' => 'logobar',
			'title' => 'Logo Bar Settings',
			'icon' => 'el-icon-puzzle',
			'fields' => array (
				
				array (
					'id' => 'logosettings_image',
					'desc' => __('Upload your custom logo image and disable text logo. If leave empty text logo will be displayed. Also you can find a sample logo in sources folder.', 'auraplgt2d'),
					'type' => 'media',
					'title' => __('Logo Image', 'auraplgt2d'),
				),
				array(
					'id' => 'logosettings_bgcolor',
					'type' => 'color',
					'title' => __('Logo Bar Background Color', 'auraplgt2d'),
					'subtitle' => __('Pick a background color for the logo bar .', 'auraplgt2d'),
					'default' => '#37afea',
					'validate' => 'color',
				),
				
				array(
					'id' => 'logosettings_barheight',
					'type' => 'slider',
					'title' => __('Logo Bar Height', 'auraplgt2d'),
					'desc' => __('Please select logo bar height for your custom logo', 'auraplgt2d'),
					"default" => "85",
					"min" => "1",
					"step" => "1",
					"max" => "400",
				),
				
				array(
					'id' => 'logosettings_margins',
					'type' => 'spacing',
					'mode' => 'margin', // absolute, padding, margin, defaults to padding
					'top' => true, // Disable the top
					'right' => false, // Disable the right
					'bottom' => false, // Disable the bottom
					'left' => false, // Disable the left
					'units' => 'px', // You can specify a unit value. Possible: px, em, %
					'units_extended' => 'false', // Allow users to select any type of unit
					'display_units' => 'true', // Set to false to hide the units if the units are specified
					'title' => __('Margin Option for Logo', 'auraplgt2d'),
					'subtitle' => __('Please change margins as you want. These settings for better configure logo place.', 'auraplgt2d'),
					'desc' => __('Top Margin. (px)', 'auraplgt2d'),
					'default' => array('margin-top' => '13px')
				),
				array(
					'id' => 'logosettings_retina',
					'type' => 'switch',
					'title' => __('Retina Logo', 'auraplgt2d'),
					'subtitle' => __('If you want to enable retina setting please turn on. This mean you need to upload your logo 2x sized.', 'auraplgt2d'),
					"default" => 1,
                    ),
				array(
					'id' => 'logosettings_home',
					'type' => 'switch',
					'title' => __('Go to Home Page on Click', 'auraplgt2d'),
					'subtitle' => __('If you want to enable go to home page on logo click please switch this on.', 'auraplgt2d'),
					"default" => 1,
                    ),
				
					
			),
		);
		
			$this->sections[] = array (
			'id' => 'maincontentsettings',
			'title' => 'Content Settings',
			'icon' => 'el-icon-photo',
			'fields' => array (
				array (
					'id' => 'tcustomizer_contentbackground',
					'type' => 'background',
					'output'      => array('#maincontent'),
					'title' => __('Content Background', 'auraplgt2d'),
					'default' => array('background-color'=>'#fff'),
				),
				array (
					'id' => 'tcustomizer_typography',
					'type' => 'typography',
					'title' => __('Content Typography (body)', 'auraplgt2d'),
					'google'      => true, 
					'font-backup' => true,
					'output'      => array('body','.wmf_separator div'),
					'units'       =>'px',
					'default'     => array(
						'color'       => '#3d0b0b', 
						'font-style'  => '300', 
						'font-family' => 'Roboto', 
						'google'      => true,
						'font-size'   => '12px', 
						'line-height' => '16px',
					),
				),
				array (
					'id' => 'tcustomizer_contentelementcolor1',
					'type' => 'color',
					'title' => __('Content Elements Color 1', 'auraplgt2d'),
					'default' => '#37afea'
				),
				array (
					'id' => 'tcustomizer_contentelementcolor2',
					'type' => 'color',
					'title' => __('Content Elements Color 2', 'auraplgt2d'),
					'default' => '#efefef'
				),				
				array (
					'id' => 'blogbgcolor',
					'type' => 'color',
					'title' => __('Blog Box Background Color', 'auraplgt2d'),
					'default' => '#efefef'
				),
			),
		);
		
			$this->sections[] = array (
			'id' => 'general_typography',
			'title' => 'Typography',
			'icon' => 'el-icon-font',
			'fields' => array (
				
				array(
                        'id' => 'tcustomizer_linkcolor',
                        'type' => 'link_color',
                        'title' => __('Links Color','auraplgt2d'),
                        'desc' => __('Change link colors by using this controls.','auraplgt2d'),
                        'default' => array(
                            'regular' => '#000',
                            'hover' => '#7a7a7a',
                            'active' => '#000'
                        )
                    ),
				array (
					'id' => 'tcustomizer_linkstypo',
					'type' => 'typography',
					'title' => __('Links Typography','auraplgt2d'),
					'google'      => true, 
					'font-backup' => true,
					'output'      => array('a'),
					'units'       =>'px',
					'color'       => false,
					'default'     => array(
						'font-style'  => '400', 
						'font-family' => 'Roboto', 
						'google'      => true,
						'font-size'   => '13px', 
						'line-height' => '16px',
					),
				),
				
				array (
					'id' => 'tcustomizer_typographyh1',
					'type' => 'typography',
					'title' => __('H1 Typography','auraplgt2d'),
					'google'      => true, 
					'font-backup' => true,
					'output'      => array('h1'),
					'units'       =>'px',
					'default'     => array(
						'color'       => '#333', 
						'font-style'  => '400', 
						'font-family' => 'Arial', 
						'google'      => true,
						'font-size'   => '24px', 
						'line-height' => '26px',
					),
				),
				
				array (
					'id' => 'tcustomizer_typographyh2',
					'type' => 'typography',
					'title' => __('H2 Typography','auraplgt2d'),
					'google'      => true, 
					'font-backup' => true,
					'output'      => array('h2'),
					'units'       =>'px',
					'default'     => array(
						'color'       => '#333', 
						'font-style'  => '400', 
						'font-family' => 'Arial', 
						'google'      => true,
						'font-size'   => '22px', 
						'line-height' => '22px'
					),
				),
				array (
					'id' => 'tcustomizer_typographyh3',
					'type' => 'typography',
					'title' => __('H3 Typography','auraplgt2d'),
					'google'      => true, 
					'font-backup' => true,
					'output'      => array('h3'),
					'units'       =>'px',
					'default'     => array(
						'color'       => '400', 
						'font-family' => 'Arial', 
						'google'      => true,
						'font-size'   => '18px', 
						'line-height' => '20px'
					),
				),
				array (
					'id' => 'tcustomizer_typographyh4',
					'type' => 'typography',
					'title' => __('H4 Typography','auraplgt2d'),
					'google'      => true, 
					'font-backup' => true,
					'output'      => array('h4'),
					'units'       =>'px',
					'default'     => array(
						'color'       => '#333', 
						'font-style'  => '400', 
						'font-family' => 'Arial', 
						'google'      => true,
						'font-size'   => '14px', 
						'line-height' => '16px'
					),
				),
				array (
					'id' => 'tcustomizer_typographyh5',
					'type' => 'typography',
					'title' => __('H5 Typography','auraplgt2d'),
					'google'      => true, 
					'font-backup' => true,
					'output'      => array('h5'),
					'units'       =>'px',
					'default'     => array(
						'color'       => '#333', 
						'font-style'  => '400', 
						'font-family' => 'Arial', 
						'google'      => true,
						'font-size'   => '12px', 
						'line-height' => '15px'
					),
				),
				array (
					'id' => 'tcustomizer_typographyh6',
					'type' => 'typography',
					'title' => __('H6 Typography','auraplgt2d'),
					'google'      => true, 
					'font-backup' => true,
					'output'      => array('h6'),
					'units'       =>'px',
					'default'     => array(
						'color'       => '#333', 
						'font-style'  => '400', 
						'font-family' => 'Arial', 
						'google'      => true,
						'font-size'   => '10px', 
						'line-height' => '12px'
					),
				),
			),
		);
		
			$this->sections[] = array (
			'id' => 'splashscreen',
			'title' => 'iOS Splash Screens',
			'icon' => 'el-icon-screen',
			'fields' => array (
				array(
					'id' => 'helpboxwmf002',
					'type' => 'info',
					'desc' => __('This feature only work in iOS devices. You will see different sized images below this instruction. These images are designed for device position &amp; type. Please upload all images. Sample images in Downloaded content &gt; Sources &gt; splash-screens folder.','auraplgt2d')
                    ),
				array (
					'id' => 'splashscreen_iphone3',
					'desc' => __('<small>Upload your own splash screen image. Check sources folder for sample.(Sources > splash-screens > apple-touch-startup-image-320x460.png)','auraplgt2d'),
					'type' => 'media',
					'title' => __('Splash Screen iPhone 3','auraplgt2d'),
				),
				array (
					'id' => 'splashscreen_iphone4',
					'desc' => __('<small>Upload your own splash screen image. Check sources folder for sample.(Sources > splash-screens > apple-touch-startup-image-640x920.png)','auraplgt2d'),
					'type' => 'media',
					'title' => __('Splash Screen iPhone4','auraplgt2d'),
				),
				array (
					'id' => 'splashscreen_iphone5',
					'desc' => __('<small>Upload your own splash screen image. Check sources folder for sample.(Sources > splash-screens > apple-touch-startup-image-640x1096.png)</small>','auraplgt2d'),
					'type' => 'media',
					'title' => __('Splash Screen iPhone 5','auraplgt2d'),
				),
				array (
					'id' => 'splashscreen_iphone6',
					'desc' => __('<small>Size: 375x667 (px)</small>','auraplgt2d'),
					'type' => 'media',
					'title' => __('Splash Screen iPhone 6','auraplgt2d'),
				),
				array (
					'id' => 'splashscreen_iphone62',
					'desc' => __('<small>Size: 414x736 (px)</small>','auraplgt2d'),
					'type' => 'media',
					'title' => __('Splash Screen iPhone 6+','auraplgt2d'),
				),
				array (
					'id' => 'splashscreen_porttablet',
					'desc' => __('<small>Upload your own splash screen image. Check sources folder for sample.(Sources > splash-screens > apple-touch-startup-image-768x1004.png)</small>','auraplgt2d'),
					'type' => 'media',
					'title' => __('Splash Screen Portrait Tablets','auraplgt2d'),
				),
				array (
					'id' => 'splashscreen_landtablet',
					'desc' => __('<small>Upload your own splash screen image. Check sources folder for sample.(Sources > splash-screens > apple-touch-startup-image-748x1024.png)</small>','auraplgt2d'),
					'type' => 'media',
					'title' => __('Splash Screen Landscape Tablets','auraplgt2d'),
				),
				array (
					'id' => 'splashscreen_porttabletret',
					'desc' => __('<small>Upload your own splash screen image. Check sources folder for sample.(Sources > splash-screens > apple-touch-startup-image-1536x2008.png)</small>','auraplgt2d'),
					'type' => 'media',
					'title' => __('Splash Screen Portrait Retina Tablets','auraplgt2d'),
				),
				array (
					'id' => 'splashscreen_landtabletret',
					'desc' => __('<small>Upload your own splash screen image. Check sources folder for sample.(Sources > splash-screens > apple-touch-startup-image-1496x2048.png)</small>','auraplgt2d'),
					'type' => 'media',
					'title' => __('Splash Screen Landscape Retina Tablets','auraplgt2d'),
				),
			),
		);
		
			$this->sections[] = array (
			'id' => 'iossettings',
			'title' => 'iOS Add Home Bubble',
			'icon' => 'el-icon-heart',
			'fields' => array (
				array (
					'id' => 'mhelpbox_help10',
					'desc' => __('This feature only work on iOS devices & only work in Front Page. Please dont forget to select your static front page from Settings > Reading page.','auraplgt2d'),
					'type' => 'info',
					'title' => __('Info','auraplgt2d'),
				),
				
				array(
                        'id' => 'iossettings_add2home',
                        'type' => 'button_set',
                        'title' => __('IOS Add Home Bubble','auraplgt2d'),
                        'desc' => __('<br>Show/Hide Add to Home Bubble on IOS devices.(Default: Show)','auraplgt2d'),
                        'options' => array('1' => __('Show','auraplgt2d'), '0' => __('Hide','auraplgt2d')), //Must provide key => value pairs for radio options
                        'default' => '1'
                    ),

				array(
                        'id' => 'iossettings_startdelay',
                        'type' => 'slider',
                        'title' => __('Start Delay','auraplgt2d'),
                        'desc' => __('Start delay for message. (ms) 2000 for 2 sec.','auraplgt2d'),
                        "default" => "2000",
                        "min" => "0",
                        "step" => "1000",
                        "max" => "10000",
                    ),
				
				array(
                        'id' => 'iossettings_lifespan',
                        'type' => 'slider',
                        'title' => __('Lifespan','auraplgt2d'),
                        'desc' => __('Time before it is automatically destroyed. (ms) 5000 for 5 sec.','auraplgt2d'),
                        "default" => "5000",
                        "min" => "0",
                        "step" => "1000",
                        "max" => "30000",
                    ),
				array(
                        'id' => 'iossettings_returningvisitor',
                        'type' => 'button_set',
                        'title' => __('Returning Visitor','auraplgt2d'),
                        'desc' => __('Show the message only to returning visitors. (ie: don\'t show it the first time)','auraplgt2d'),
                        'options' => array('true' => 'Enable', 'false' => 'Disable'), //Must provide key => value pairs for radio options
                        'default' => 'false'
                    ),
				array(
                        'id' => 'iossettings_touchicon',
                        'type' => 'button_set',
                        'title' => __('Touch Icon','auraplgt2d'),
                        'desc' => __('This option will show an icon in to the add home balloon. If you enable touch icon you need to upload touch icons from touch icon section on the left menu.','auraplgt2d'),
                        'options' => array('true' => __('Enable','auraplgt2d'), 'false' => __('Disable','auraplgt2d')), //Must provide key => value pairs for radio options
                        'default' => 'true'
                    ),
				
			),
		);
		
			$this->sections[] = array (
			'id' => 'iostouchicon',
			'title' => 'iOS Touch Icons',
			'icon' => 'el-icon-th',
			'fields' => array (
				array(
					'id' => 'helpboxwmf001',
					'type' => 'info',
					'desc' => __('Touch icons will help to iOS users while adding your site to the home screen. The sizes are different because retina &amp; non-retina devices using different size icons. For find sample icons only check downloaded content &gt; sources &gt; touch-icons folder. You can change these images &amp; re upload here easily.','auraplgt2d')
                    ),
				array (
					'id' => 'iostouchicon_1',
					'desc' => __('<small>Upload 57x57 px touch icon here. Check sources folder for sample.(touch-icons > apple-touch-icon-57x57.png)</small>','auraplgt2d'),
					'type' => 'media',
					'title' => __('Touch Icon 57x57','auraplgt2d'),
					'default' => ''
				),
				array (
					'id' => 'iostouchicon_2',
					'desc' => __('<small>Upload 72x72 px touch icon here. Check sources folder for sample.(touch-icons > apple-touch-icon-72x72.png)</small>','auraplgt2d'),
					'type' => 'media',
					'title' => __('Touch Icon 72x72','auraplgt2d'),
				),
				array (
					'id' => 'iostouchicon_3',
					'desc' => __('<small>Upload 114x114 px touch icon here. Check sources folder for sample.(touch-icons > apple-touch-icon-114x114.png)</small>','auraplgt2d'),
					'type' => 'media',
					'title' => __('Touch Icon 114x114','auraplgt2d'),
				),
				array (
					'id' => 'iostouchicon_4',
					'desc' => __('<small>Upload 144x144 px touch icon here. Check sources folder for sample.(touch-icons > apple-touch-icon-144x144.png)</small>','auraplgt2d'),
					'type' => 'media',
					'title' => __('Touch Icon 144x144','auraplgt2d'),
				),
			),
		);
		
			


            //$this->sections[] = array(
//                'type' => 'divide',
//            );

            $theme_info = '<div class="redux-framework-section-desc">';
            $theme_info .= '<p class="redux-framework-theme-data description theme-uri">' . __('<strong>Theme URL:</strong> ', 'auraplgt2d') . '<a href="' . $this->theme->get('ThemeURI') . '" target="_blank">' . $this->theme->get('ThemeURI') . '</a></p>';
            $theme_info .= '<p class="redux-framework-theme-data description theme-author">' . __('<strong>Author:</strong> ', 'auraplgt2d') . $this->theme->get('Author') . '</p>';
            $theme_info .= '<p class="redux-framework-theme-data description theme-version">' . __('<strong>Version:</strong> ', 'auraplgt2d') . $this->theme->get('Version') . '</p>';
            $theme_info .= '<p class="redux-framework-theme-data description theme-description">' . $this->theme->get('Description') . '</p>';
            $tabs = $this->theme->get('Tags');
            if (!empty($tabs)) {
                $theme_info .= '<p class="redux-framework-theme-data description theme-tags">' . __('<strong>Tags:</strong> ', 'auraplgt2d') . implode(', ', $tabs) . '</p>';
            }
            $theme_info .= '</div>';

            if (file_exists(dirname(__FILE__) . '/../README.md')) {
                $this->sections['theme_docs'] = array(
                    'icon' => 'el-icon-list-alt',
                    'title' => __('Documentation', 'auraplgt2d'),
                    'fields' => array(
                        array(
                            'id' => '17',
                            'type' => 'raw',
                            'markdown' => true,
                            'content' => file_get_contents(dirname(__FILE__) . '/../README.md')
                        ),
                    ),
                );
            }//if
            // You can append a new section at any time.
           

            if (file_exists(trailingslashit(dirname(__FILE__)) . 'README.html')) {
                $tabs['docs'] = array(
                    'icon' => 'el-icon-book',
                    'title' => __('Documentation', 'auraplgt2d'),
                    'content' => nl2br(file_get_contents(trailingslashit(dirname(__FILE__)) . 'README.html'))
                );
            }
        }

        public function setHelpTabs() {

            // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
            $this->args['help_tabs'][] = array(
                'id' => 'redux-opts-1',
                'title' => __('Theme Information 1', 'auraplgt2d'),
                'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'auraplgt2d')
            );

            $this->args['help_tabs'][] = array(
                'id' => 'splashscreen',
                'title' => __('Theme Information 2', 'auraplgt2d'),
                'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'auraplgt2d')
            );

            // Set the help sidebar
            $this->args['help_sidebar'] = __('<p>This is the sidebar content, HTML is allowed.</p>', 'auraplgt2d');
        }


        public function setArguments() {

            $theme = wp_get_theme(); // For use with some settings. Not necessary.

            $this->args = array(
                // TYPICAL -> Change these values as you need/desire
                'display_name' => 'Aura Mobile Theme', // Name that appears at the top of your panel
                'display_version' => '1.6.2', // Version that appears at the top of your panel
                "opt_name"=>"auramobile_options", // Where your data is stored. Use a different name or use the same name as your current theme. Must match the $database_newName variable in the converter code.
				"menu_title" => "Aura Options", // Title for your menu item
                'menu_type' => 'menu', //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                'allow_sub_menu' => true, // Show the sections below the admin menu item or not
                'page' => __('Aura Mobile Options', 'auraplgt2d'),
				//"page_slug" => "ot_get_option", // Make this the same as your opt_name unless you care otherwise
				"global_variable" => "webbumobile_option", // By default Redux sets your global variable to be the opt_name you set above. This is what the newest SMOF uses as it's variable name. You can change, but you may need to update your files.
				//"intro_text" => "<p>This theme is now using Redux</p>", // Extra header info
				"google_api_key" => "AIzaSyCHo_tn9ks4Ov9WE4iQYo3hqoc_r3uTF54", // You must acquire a Google Web Fonts API key if you want Google Fonts to work
				//'admin_bar' => false, // Show the panel pages on the admin bar
                'dev_mode' => false, // Show the time the page took to load, etc
                'customizer' => false, // Enable basic customizer support
                // OPTIONAL -> Give you extra features
                'page_priority' => null, // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                'page_parent' => 'themes.php', // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                'page_permissions' => 'manage_options', // Permissions needed to access the options panel.
                'menu_icon' => '', // Specify a custom URL to an icon
                'last_tab' => '', // Force your panel to always open to a specific tab (by id)
                'page_icon' => 'icon-themes', // Icon displayed in the admin panel next to your menu_title
                'page_slug' => '_options', // Page slug used to denote the panel
                'save_defaults' => true, // On load save the defaults to DB before user clicks save or not
                'default_show' => false, // If true, shows the default value next to each field that is not the default value.
                'default_mark' => '', // What to print by the field's title if the value shown is default. Suggested: *
                // CAREFUL -> These options are for advanced use only
                'transient_time' => 60 * MINUTE_IN_SECONDS,
                'output' => true, // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                'output_tag' => true, // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                'domain'             	=> 'auraplgt2d', // Translation domain key. Don't change this unless you want to retranslate all of Redux.
                //'footer_credit'      	=> '', // Disable the footer credit of Redux. Please leave if you can help it.
                // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                'database' => '', // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                'show_import_export' => true, // REMOVE
                'system_info' => false, // REMOVE
                'help_tabs' => array(),
                'help_sidebar' => '', // __( '', $this->args['domain'] );        
				'page_position' => '208'          
            );


            // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.		
            $this->args['share_icons'][] = array(
                'url' => 'https://github.com/webbudesign',
                'title' => 'Visit us on GitHub',
                'icon' => 'el-icon-github'
                    // 'img' => '', // You can use icon OR img. IMG needs to be a full URL.
            );
            $this->args['share_icons'][] = array(
                'url' => 'https://www.facebook.com/Webbudesign',
                'title' => 'Like us on Facebook',
                'icon' => 'el-icon-facebook'
            );
            $this->args['share_icons'][] = array(
                'url' => 'http://twitter.com/WebbuDesign',
                'title' => 'Follow us on Twitter',
                'icon' => 'el-icon-twitter'
            );
           
            if (!isset($this->args['global_variable']) || $this->args['global_variable'] !== false) {
                if (!empty($this->args['global_variable'])) {
                    $v = $this->args['global_variable'];
                } else {
                    $v = str_replace("-", "_", $this->args['opt_name']);
                }
            } 

        }

    }

    new Redux_Framework_Aura_Mobile_Config();
}