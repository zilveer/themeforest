<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// add shortcode for Offer
add_shortcode('offers', 'multipurpose_offers');
add_shortcode('offer', 'multipurpose_offer');

function multipurpose_offers($atts, $content = null) {
    return '<section class="latest">'.do_shortcode($content).'</section>';
}

function multipurpose_offer($atts, $content = null) {
    if(isset($atts) && !empty($atts))
        array_walk($atts, 'multipurpose_arrangement_shortcode_arr_value');

    extract(shortcode_atts(array(  
        'image_url'=> '',
        'image_alt'=> '',
		'link'=> ''
    ), $atts));  

    $output = '<article>';
    $output .= '<div class="alignleft">';
	if($link) {
		$output .= '<a href="'.$link.'"><img src="'.$image_url.'" alt="'.$image_alt.'"></a>';
	} else {
		$output .= '<img src="'.$image_url.'" alt="'.$image_alt.'">';
	}
	$output .= '</div>';
    $output .= do_shortcode($content).'</article>';
    
    return $output;
}
