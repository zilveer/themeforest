<?php 
ob_start();
function login_form() {
 
?>
 
<form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
    <div class="login-form">
        <div class="form-group">
			<label class="input-desc" for="login-name">
			<?php _e("Username",'mango_core'); ?>*
			</label>
            <input name="login_name" type="text" class="form-control login-field" value="" id="login-name" />
           
        </div>
 
        <div class="form-group">
		  <label class="input-desc" for="login-pass">
			<?php _e("Password",'mango_core'); ?>*
			</label>
            <input  name="login_password" type="password" class="form-control login-field" value="" id="login-pass" />
          
        </div>
        <input class="btn btn-custom2" type="submit"  name="dlf_submit" value="<?php _e('Log in','mango_core'); ?>" />
</form>
</div>
<?php
}

function mango_auth( $username, $password ) {
 global $user;
 $creds = array();
 $creds['user_login'] = $username;
 $creds['user_password'] =  $password;
 $creds['remember'] = true;
 $user = wp_signon( $creds, false );
 if ( is_wp_error($user) ) {
 echo $user->get_error_message();
 }
 if ( !is_wp_error($user) ) {
 wp_redirect(home_url('wp-admin'));
 }
}
function mango_process() {
 if (isset($_POST['dlf_submit'])) {
  mango_auth($_POST['login_name'], $_POST['login_password']);
 }
  
 login_form();
}

function mango_shortcode() {
ob_start();
mango_process();
return ob_get_clean();
}
 
add_shortcode('mango_login_form', 'mango_shortcode');



	if( ! function_exists('mango_registration_form')){
	function mango_registration_form( $username='', $password='', $email='', $website='', $first_name='', $last_name='', $nickname='', $bio='' ) {

    echo '<div class="row">
		<form action="' . $_SERVER['REQUEST_URI'] . '" method="post" class="post_form v_form form-horizontal">
		<div class="col-md-6">
	    <label for="username" class="input-desc">'.__("Username",'mango_core').' <strong>*</strong></label>
	    <input type="text"  class="form-control" name="username" value="' . ( isset( $_POST['username'] ) ? $username : null ) . '">
		</div>

	<div class="col-md-6">
	   <label for="password" class="input-desc">'.__("Password",'mango_core').' <strong>*</strong></label>
	   <input type="password"  class="form-control" name="password" value="' . ( isset( $_POST['password'] ) ? $password : null ) . '">
	</div>
	
	<div class="col-md-6">
	<label for="email" class="input-desc">'.__("Email",'mango_core').' <strong>*</strong></label>
	  <input type="text" class="form-control" name="email" value="' . ( isset( $_POST['email']) ? $email : null ) . '">
	</div>
	<div class="col-md-6">
    <label for="website" class="input-desc">'.__("Website",'mango_core').'</label>
    <input type="text" class="form-control" name="website" value="' . ( isset( $_POST['website']) ? $website : null ) . '">
	</div>

	<div class="col-md-6">
    <label for="firstname" class="input-desc">'.__("First Name",'mango_core').'</label>
    <input type="text"  class="form-control" name="fname" value="' . ( isset( $_POST['fname']) ? $first_name : null ) . '">
	</div>

	<div class="col-md-6">
    <label for="website" class="input-desc">'.__("Last Name",'mango_core').'</label>
    <input type="text" class="form-control" name="lname" value="' . ( isset( $_POST['lname']) ? $last_name : null ) . '">
	</div>
	<div class="col-md-6">
	<label for="bio" class="input-desc">'.__("About / Bio",'mango_core').'</label>
    <textarea name="bio" class="form-control">' . ( isset( $_POST['bio']) ? $bio : null ) . '</textarea>
	</div>

   <div class="col-md-6">
   <label for="nickname" class="input-desc">'.__("Nickname",'mango_core').'</label>
   <input type="text" class="form-control" name="nickname" value="' . ( isset( $_POST['nickname']) ? $nickname : null ) . '">
	</div>
		
	<div class="col-md-12">
	<button type="submit" name="submit" class="btn btn-custom" value="'.__("Register",'mango_core').'">'.__("Register",'mango_core').'</button>
	</div>
	</form>
	</div>
    ';
	}
 }

if( ! function_exists('mango_registration_validation')){
	function mango_registration_validation($username, $password, $email){
	 if(isset($_POST['submit']) && $_POST['submit']){
	  global $reg_errors;
	  $reg_errors = new WP_Error;

	if ( empty( $username ) || empty( $password ) || empty( $email ) ) {
	  $reg_errors->add('field', __('Required form field is missing (Username, Password or Email)','mango_core'));
	}

	if ( 4 > strlen( $username ) ) {
	  $reg_errors->add( 'username_length', __('Username too short. At least 4 characters is required','mango_core') );
	}

	if ( username_exists( $username ) )
	 $reg_errors->add('user_name', __('Sorry, that username already exists!','mango_core'));
		if ( ! validate_username( $username ) ) {
			$reg_errors->add( 'username_invalid', __('Sorry, the username you entered is not valid','mango_core') );
		}

		if ( 5 > strlen( $password ) ) {
			$reg_errors->add( 'password', __('Password length must be greater than 5','mango_core') );
			}

		if ( !is_email( $email ) ) {
			$reg_errors->add( 'email_invalid', __('Email is not valid' ,'mango_core'));
		}

		if ( email_exists( $email ) ) {
			$reg_errors->add( 'email', __('Email Already in use','mango_core') );
		}

		if ( ! empty( $website ) ) {
			if ( ! filter_var( $website, FILTER_VALIDATE_URL ) ) {
			$reg_errors->add( 'website', __('Website is not a valid URL','mango_core') );
			}
		}

		if ( is_wp_error( $reg_errors ) ) {
			foreach ( $reg_errors->get_error_messages() as $error ) {
				echo '<div class="alert v_alert_box alert-error alert-dismissable">';
				echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&#10006;</button>';
				echo '<strong>'.__("ERROR",'mango_core').'</strong>: ';
				echo $error . '<br/>';
				echo '</div>';    
				}
			echo '<br />';
			}
		}
	}
}

if( ! function_exists('mango_complete_registration')){
function mango_complete_registration() {
    global $reg_errors, $username, $password, $email, $website, $first_name, $last_name, $nickname, $bio;
    if ( 1 > count( $reg_errors->get_error_messages() ) ) {
        $userdata = array(
        'user_login'    =>   $username,
        'user_email'    =>   $email,
        'user_pass'     =>   $password,
        'user_url'      =>   $website,
        'first_name'    =>   $first_name,
        'last_name'     =>   $last_name,
        'nickname'      =>   $nickname,
        'description'   =>   $bio,
        );
        $user = wp_insert_user( $userdata );
        echo '<div class="alert v_alert_box alert-success alert-dismissable">';
			echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&#10006;</button>';
			echo __('Registration complete.','mango_core').' '.__("Go to",'mango_core').' <a href="' . get_site_url() . '/wp-login.php">'.__("login page",'mango_core').'</a>.';
		echo '</div><br />'; 
		$_POST = '';
		}
	}
}

if( ! function_exists('mango_registration_function')){
function mango_registration_function() {
    if ( isset($_POST['submit'] ) ) {
     mango_registration_validation(
       $_POST['username'],
       $_POST['password'],
       $_POST['email'],
       $_POST['website'],
       $_POST['fname'],
       $_POST['lname'],
       $_POST['nickname'],
       $_POST['bio']
       );
        // sanitize user form input
       global $username, $password, $email, $website, $first_name, $last_name, $nickname, $bio;
       $username   =   sanitize_user( $_POST['username'] );
       $password   =   esc_attr( $_POST['password'] );
       $email      =   sanitize_email( $_POST['email'] );
       $website    =   esc_url( $_POST['website'] );
       $first_name =   sanitize_text_field( $_POST['fname'] );
       $last_name  =   sanitize_text_field( $_POST['lname'] );
       $nickname   =   sanitize_text_field( $_POST['nickname'] );
       $bio        =   esc_textarea( $_POST['bio'] );

       mango_complete_registration(
        $username,
        $password,
        $email,
        $website,
        $first_name,
        $last_name,
        $nickname,
        $bio
        );
    }

    mango_registration_form(
      isset($_POST['username']) ? $username : '',
      isset($_POST['password']) ? $password : '',
      isset($_POST['email']) ? $email : '',
      isset($_POST['website']) ? $website : '',
      isset($_POST['first_name']) ? $first_name : '',
      isset($_POST['last_name']) ? $last_name : '',
      isset($_POST['nickname']) ? $nickname : '',
      isset($_POST['bio']) ? $bio : ''
      );
	}
 }

// Register a new shortcode: [mango_user_registeration_form]
add_shortcode( 'mango_user_registeration_form', 'mango_user_registeration_form' );
function mango_user_registeration_form() {
    ob_start();
    mango_registration_function();
    return ob_get_clean();
}

function mango_woocomerce_bestsellers() {
    global $wpdb;
    $prefix = $wpdb->prefix;
    $p = $prefix . 'posts';
    $pm = $prefix . 'postmeta';
    $results = $wpdb->get_results( "
			SELECT DISTINCT p.ID, pm.meta_value FROM " . $p . " p, " . $pm . " pm
			WHERE pm.meta_key = 'total_sales'
			AND p.post_status = 'publish'
			AND p.post_type = 'product'
			AND p.ID = pm.post_id
			AND pm.meta_value != 0
			ORDER BY meta_value DESC
		" );
    $ids = array();
    foreach( $results as $key ) {
        $ids[ ] = $key->ID;
    }
    return $ids;
}
?>