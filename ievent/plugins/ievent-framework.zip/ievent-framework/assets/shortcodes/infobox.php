<?php 
	
	/* Info Bbox Shortcode  ---------------------------------------------*/
	
	add_shortcode('info_box', 'jx_ievent_info_box');
	
	function jx_ievent_info_box($atts, $content = null) { 
		extract(shortcode_atts(array(
			'icon_1' => '',
			'title_1' => '',
			'info_1' => '',
			'icon_2' => '',
			'title_2' => '',
			'info_2' => '',
			
			
		), $atts)); 		

		
		//initial variables
		$out=''; 
		 
		
		//function code
			
			$out ='
			<div class="jx-ievent-summary-info">
				<div class="container">
					
					<ul class="jx-ievent-summary-box">
						<li class="one-third columns">
							<div class="jx-ievent-location-event">
								<i class="line-icon '.$icon_1.'"></i>
								<div class="jx-ievent-info">
									<div class="jx-ievent-bar-head">'.$title_1.'</div>
									<div class="jx-ievent-bar-title">'.$info_1.'</div>
								</div>
							</div>
						</li>
						<li class="one-third columns">
							<div class="jx-ievent-hotline-event">
								<i class="line-icon '.$icon_2.'"></i>
								<div class="jx-ievent-info">
									<div class="jx-ievent-bar-head">'.$title_2.'</div>
									<div class="jx-ievent-bar-title">'.$info_2.'</div>
								</div>
							</div>
						</li>                
						<li class="one-third columns">
							<div class="jx-ievent-subscribe-event" id="mailchimp-sign-up">
								<h2>'.esc_html__('Subscribe To Newsletter','ievent').'</h2>		
								<p></p>
								<form action="#" method="post" id="mailchimp" name="mc-embedded-subscribe-form" target="_blank" novalidate>                       
									<span class="ajax-loader"></span>									
									<div class="jx-ievent-newsletter-box">
									<input type="email" name="email" placeholder="'.esc_html__('Type Your Email','ievent').'" data-validation="email" data-validation="required"/>
									</div>
									<div class="jx-ievent-newsletter-submit"><input type="submit" name="subscribe" value="'.esc_html__('Submit','ievent').'" id="mc-embedded-subscribe"/></div>                    
								</form>
							</div>
						</li>
					</ul>                
				</div>        
			</div>
			';

		
		//return output
		return $out;
	}


	

?>