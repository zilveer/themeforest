<?php 
if ( class_exists( 'WPBakeryShortCode' ) ) {

	class WPBakeryShortCode_experience_slider_text extends WPBakeryShortCodesContainer {
	
		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = null ) {
			
			$experience_vc_utilities = new jsComposerExperienceUtilities();
			
			$output = $css_class = '';
			
			extract( shortcode_atts( array(
				'css'					=> '',
				'el_class'				=> '',
				'color' 			 	=> '',
				'start_at'				=> '',
				'slideshow_speed'		=> 7000,
				'animation_speed'		=> 600				
			), $atts ) );
			
			$class = $this->getExtraClass( $el_class );			
			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );
			
			if ( $start_at != '' ) {
				$start_at = 'data-flexslider-startat="'. esc_attr( $start_at ) .'" ';
			}
			
			if ( $slideshow_speed != '' ) {
				$slideshow_speed = 'data-flexslider-slideshowspeed="'. esc_attr( $slideshow_speed ) .'" ';
			}
			
			if ( $animation_speed != '' ) {
				$animation_speed = 'data-flexslider-animationspeed="'. esc_attr( $animation_speed ) .'" ';
			}			
			
			$output .= '<div class="flexslider flexslider-small text-align-center'. esc_attr( $css_class .' '. $color ) .'" '. $start_at . $slideshow_speed . $animation_speed .'>';
				
				$output .= '<ul class="slides">'. wpb_js_remove_wpautop( $content ) .'</ul>';
				
			$output .= '</div>';
			
			return $output;
		
		}	

	}


	// ---------- SLIDE (SMALL) ---------- //

	class WPBakeryShortCode_experience_slider_text_slide extends WPBakeryShortCode {

		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = null ) {
			
			$output = $class = '';
			
			extract( shortcode_atts( array(
				'el_class'	=> '',
				'title'		=> '',
				'subtitle'	=> '',
			), $atts ) );		
			
			$class = $this->getExtraClass( $el_class );
			
			$output .= '<li class="'. esc_attr( $class ) .'">';			
				
				$output .= '<div class="exp_ie-flexbox-fixer">';
				
					$output .= '<div class="exp-flexbox exp-content-middle">';
					
						$output .= '<div class="exp-flexbox-inner">';
							
							$output .= '<div class="slide-content site-width padding-h">';
							
									if ( $title != "" ) {						
										$output .= '<p>'. esc_html( $title ) .'</p>';
									}
								
									if ( $subtitle != "" ) {
										$output .= '<span class="slide-subtitle">' . esc_html( $subtitle ) .'</span>';
									}						
								
							$output .= '</div>';
						
						$output .= '</div>';
					
					$output .= '</div>';
				
				$output .= '</div>';
			
			$output .= '</li>';
			
			return $output;
		
		}
		
	}
	
}

/* ---------- SLIDER TEXT ---------- */

vc_map( array(
	"base"						=> "experience_slider_text",
	"name"						=> esc_html__( "Slider (Text)", "js_composer_experience" ),
	"description"				=> esc_html__( "Small text slider", "js_composer_experience" ),
	"as_parent"					=> array( "only" => "experience_slider_text_slide" ),
	"content_element"			=> true,
	"show_settings_on_create"	=> false,
	"js_view"					=> "VcColumnView",
	"params"					=> array(
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			"type"			=> "textfield",
			'admin_label'	=> true
		),
		
		// StartAt
		array(
			"param_name"	=> "start_at",
			"heading"		=> esc_html__( "StartAt", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the slide number the slider should begin on when first loaded.", "js_composer_experience" ),
			"type"			=> "textfield"
		),
		
		// Slideshow Speed
		array(
			"param_name"	=> "slideshow_speed",
			"heading"		=> esc_html__( "Slideshow Speed", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the duration of each slide (milliseconds)", "js_composer_experience" ),
			"type"			=> "textfield",
			"value"			=> 7000
		),
		
		// Animation Speed
		array(
			"param_name"	=> "animation_speed",
			"heading"		=> esc_html__( "Animation Speed", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the duration of slide transition animation (milliseconds).", "js_composer_experience" ),
			"type"			=> "textfield",
			"value"			=> 600
		),	
		
		// CSS
		array(
			"param_name" => "css",
			"heading"	 => esc_html__( "CSS", "js_composer_experience" ),
			"type"		 => "css_editor",
			"group"		 => esc_html__( "Design options", "js_composer_experience" )
		)

	)
	
) );


/* --------- SLIDE TEXT SLIDE  --------- */

vc_map( array(
	"base"				=> "experience_slider_text_slide",
	"name"				=> esc_html__( "Slide (Text)", "js_composer_experience" ),
	"content_element"	=> true,
	"as_child"			=> array( "only" => "experience_slider_text" ),
	"params"			=> array(				
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"type"			=> "textfield",
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			'admin_label'	=> true
		),
		
		// Title
		array(
			"param_name"	=> "title",
			"heading"		=> esc_html__( "Content", "js_composer_experience" ),
			"type"			=> "textarea",
			"description"	=> esc_html__( "Enter the slide content.", "js_composer_experience" ),
			'admin_label' => true
		),
		
		// Subtitle
		array(
			"param_name"	=> "subtitle",
			"heading"		=> esc_html__( "Subtitle", "js_composer_experience" ),
			"type"			=> "textfield",
			"description"	=> esc_html__( "Add a subtitle below the slide content.", "js_composer_experience" ),
			'admin_label' => true			
		)			
	
	)
	
) );