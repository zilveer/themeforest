<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Image List", "wish"),
    "description" => __("Image List with Name and Links", 'wish'),
    "controls" => "full",
    "base" => "wish_image_list",
    "as_parent" => array('only' => 'wish_image_list_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/Hf6T1z0.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Heading", "wish"),
            "param_name" => "title",
            "description" => __("Meal of The Day Title and Position", "wish"),
            "value" => __("Meal of The Day", 'wish'),
            "admin_label" => true,
        ), 

        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Font Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("40", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

          array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Font Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000',
            "group"   => "Fonts & Colors",
         ),


         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#FFFFFF', //Default Red color
            "description" => __( "Choose the background color", "wish" ),
            "group"   => "Fonts & Colors",
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("item", "wish"),
    "base" => "wish_image_list_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_image_list'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,    
        ),

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Staff Member Name", "wish"),
            "value" => __("Soup of the Day", 'wish'),
            "admin_label" => false,
        ),


        array(
            "type" => "textfield",
            "heading" => __("Details", "wish"),
            "param_name" => "details",
            "description" => __("", "wish"),
            "value" => __("WordPress is our preferred open source tool for fast, simple publishing and modifying of content.", 'wish'),
            "admin_label" => false,
        ),

        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Font Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("24", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

          array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Font Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000',
            "group"   => "Fonts & Colors",
         ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Font Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

          array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Font Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000',
            "group"   => "Fonts & Colors",
         ),


    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Image_List extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title'         => 'Meal of The Day',
            'title_font'    => '',
            'title_size'    => '40',
            'title_color'   => '#000',
            'bgcolor'       => ''  
          ), $atts ) );

          /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



      $output = "<div class='container meal-of-the-day' style='background-color:{$bgcolor};'>
            <div class='row'>
                <div class='col-lg-12'>
                    <h1 class='animated fadeInUp visible' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>
                </div>
                    " . do_shortcode($content) . "
                
            </div>
            </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Image_List_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'title'         => 'Soup of the Day',
            'title_font'    => '',
            'title_size'    => '24',
            'title_color'   => '#000',

            'details'       => 'WordPress is our preferred open source tool for fast, simple publishing and modifying of content.',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#000',
            'image'         => 'Image',
          ), $atts ) );

          /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


          $img = wp_get_attachment_image_src( $image, array(263,161) );

          if($image == "Image"){
            $imgsrc = plugins_url('images/meal1.jpg', __FILE__);
            $img[0] = $imgsrc;
          }


          $output = "<div class='col-lg-3 block animated fadeInUp visible' data-animation='fadeInUp' data-animation-delay='500'>
                    <div class='picture'><img src='{$img[0]}' class='img-responsive' alt=''></div>
                    <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>
                    <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}</div>
                </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>