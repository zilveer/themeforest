<?php $icons = array();
$icons['icomoon']['ue700'] = 'ue700';
$icons['icomoon']['ue900'] = 'ue900';
$icons['icomoon']['ue901'] = 'ue901';
$icons['icomoon']['ue902'] = 'ue902';