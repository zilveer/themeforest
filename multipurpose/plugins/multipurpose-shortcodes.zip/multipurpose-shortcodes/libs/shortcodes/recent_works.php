<?php

if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// add shortcode recent_works
add_shortcode('recent_works', 'multipurpose_recent_works');

function multipurpose_recent_works($atts, $content = null) {
    $output = '<section class="columns posts-slider content-slider">';
	$output .= '<nav class="controls"><a href="#" class="prev">&lt;</a><a href="#" class="next">&gt;</a></nav>';

    if (!empty($atts['title'])) {
        $output .= '<h2 class="underline"><span>' . $atts["title"] . '</span></h2>';
    } else {
        $output .= $atts["title"];
    }

    $output .='<div class="slider-box">';
    $args = array(
        'posts_per_page' => $atts['number_posts'],
        'orderby' => 'post_date',
        'order' => 'DESC',
        'post_type' => 'project',
        'post_status' => 'publish',
        'suppress_filters' => true
    );

    $posts_array = get_posts($args);
    if (!empty($posts_array)) {
        foreach ($posts_array as $key_data => $val_data) {

            $url = wp_get_attachment_image_src(get_post_thumbnail_id($val_data->ID), 'large');
            $output .= '<article>';
            $output .= '<div class="img">';
            if (has_post_thumbnail($val_data->ID)) {
                $output .= get_the_post_thumbnail($val_data->ID, 'project-thumbnail');
            }

            $output .= '<div class="actions">';
            $output .= '<ul>';
            if (isset($atts['view_anchor_text'])) {
                $output .= '<li><a href="' . $url[0] . '" class="action view">' . $atts['view_anchor_text'] . '</a></li>';
            }
            if (isset($atts['go_anchor_text'])) {
                $output .= '<li><a href="' . get_permalink($val_data->ID) . '" class="action go">' . $atts['go_anchor_text'] . '</a></li>';
            }
            $output .= '</ul> </div>';
            $output .= '</div>';
            if (isset($atts["headline"]) && $atts["headline"] == 'yes') {
                $output .= '<h3><a href="' . get_permalink($val_data->ID) . '">' . $val_data->post_title . '</a></h3>';
            }
            if (isset($atts["excerpt_words"]) && isset($atts["strip_html"])) {
                if (!empty($val_data->post_excerpt)) {
                    $output .= '<p>' . multipurpose_cut_character_word($atts["excerpt_words"], $val_data->post_excerpt, $atts["strip_html"]) . '</p>';
                } elseif (!empty($val_data->post_content)) {
                    $output .= '<p>' . multipurpose_cut_character_word($atts["excerpt_words"], $val_data->post_content, $atts["strip_html"]) . '</p>';
                }
            }
            $output .= '</article>';
        }
    }
    $output .= '</div></section>';
    return $output;
}

function multipurpose_get_excerpt_max_charlength($charlength, $str, $strip_html = true) {
    if ($strip_html == 'yes') {
        $excerpt = strip_tags($str);
    } else {
        $excerpt = $str;
    }
    $string = strip_shortcodes($excerpt);
    $charlength++;

    if (mb_strlen($string, 'utf8') > $charlength) {
        //$last_space = strrpos( substr( $string, 0, $charlength + 1 ), ' ' );
        $str = substr($string, 0, $charlength);
        if (!empty($str)) {
            $str = $str . '[...]';
        }
    } else {
        $str = $string;
    }
    return $str;
}

function multipurpose_cut_character_word($number = 0, $str = '', $strip_html = true) {
    if ($strip_html == 'yes') {
		$excerpt = strip_tags($str);
    } else {
        $excerpt = $str;
    }
    $string = strip_shortcodes($excerpt);

    $string = explode(' ', $string);
    $str = '';
    $i = 0;

    foreach ($string as $key => $value) {

        if ($i == $number) {
            return $str;
        } else {
            $str.= $value . ' ';
        }
        $i++;
    }
    return $str;
}

function multipurpose_strip_html_tags($text) {
    $text = preg_replace(
            array(
        // Remove invisible content
        '@<head[^>]*?>.*?</head>@siu',
        '@<style[^>]*?>.*?</style>@siu',
        '@<script[^>]*?.*?</script>@siu',
        '@<object[^>]*?.*?</object>@siu',
        '@<embed[^>]*?.*?</embed>@siu',
        '@<applet[^>]*?.*?</applet>@siu',
        '@<noframes[^>]*?.*?</noframes>@siu',
        '@<noscript[^>]*?.*?</noscript>@siu',
        '@<noembed[^>]*?.*?</noembed>@siu',
        // Add line breaks before and after blocks
        '@</?((address)|(blockquote)|(center)|(del))@iu',
        '@</?((div)|(h[1-9])|(ins)|(isindex)|(p)|(pre))@iu',
        '@</?((dir)|(dl)|(dt)|(dd)|(li)|(menu)|(ol)|(ul))@iu',
        '@</?((table)|(th)|(td)|(caption))@iu',
        '@</?((form)|(button)|(fieldset)|(legend)|(input))@iu',
        '@</?((label)|(select)|(optgroup)|(option)|(textarea))@iu',
        '@</?((frameset)|(frame)|(iframe))@iu',
            ), array(
        ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
        "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0",
        "\n\$0", "\n\$0",
            ), $text);
    return strip_tags($text);
}


