<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Tabs - Services 2", "wish"),
    "description" => __("Services Tabs 2 With Text and Icon", 'wish'),
    "controls" => "full",
    "base" => "wish_services_tabs_2",
    "as_parent" => array('only' => 'wish_service_tab_2_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/AaS2klO.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("The Main Title", "wish"),
            "value" => __("SERVICES", 'wish'),
            "admin_label" => true,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Font Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("20", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" )
         ),


        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#fff', //Default Red color
            "description" => __( "Choose background color", "wish" ),
            "group"     => 'Fonts & Colors'
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Tab", "wish"),
    "base" => "wish_service_tab_2_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_services_tabs_2'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(
        
        array(
            "type" => "wish_fontawesome_param",
            "holder" => "div",
            "class" => "",
            "heading" => __("Custom Icon", 'wish'),
            "param_name" => "custom_icon",
            "value" => __("fa-coffee", 'wish'),
            "description" => __("Get Font Awesome Icons Code Here: <a target='_blank' href='http://fortawesome.github.io/Font-Awesome/cheatsheet/'>Link</a>, New icons may not work. Leave blank if you want to use the above icon.", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Icon color", "wish" ),
            "param_name" => "icon_color",
            "value" => '#cecece', //Default Red color
            "description" => __( "Choose icon color", "wish" ),
            "group"       => "Fonts & Colors",
            
         ),


        array(
            "type" => "textfield",
            "heading" => __("Tab Title", "wish"),
            "param_name" => "title",
            "description" => __("The Title Of The Tab", "wish"),
            "value" => __("BRAND", 'wish'),
            "admin_label" => true,
        ), 

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat", 'wish'),
            "description" => __("The details below the title", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("Image in the background", 'wish'),
            "param_name" => "image",
            "description" => __("Service Tab image", 'wish'),
            "admin_label" => false,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Font Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("16", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#cecece', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),
        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Font Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),


        array(
            "type" => "vc_link",
            "holder" => "div",
            "class" => "",
            "heading" => __("Link To The Page", 'wish'),
            "param_name" => "link",
            "description" => __("The Link below the text", 'wish'),
            "admin_label" => false,
        ),





       
    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_services_Tabs_2 extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {
      extract( shortcode_atts( array(
        'title' => 'SERVICES',
        'title_font'    => '',
        'title_size'    => '20',
        'title_color'   => '#000',
        'bgcolor'     => '#fff'
      ), $atts ) );



    $pattern = get_shortcode_regex();


    if (   preg_match_all( '/'. $pattern .'/s', $content, $matches ) && array_key_exists( 2, $matches ) && in_array( 'wish_service_tab_single', $matches[2] ) )
    {
        //found the shortcode    
        //print_r($matches);
    }

    $shortcode = $matches[0];

    $image_html = array();
    $li = array();

    foreach ($shortcode as $key => $value) {
        $image_html[] =  explode("|||", do_shortcode($value) );
    }


     /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


    //print_r($image_html);

      $output = "
      <style>
      .home-services-tabs .nav-pills>li.active>a,.home-services-tabs .nav-pills>li:hover>a, .home-services-tabs .nav-pills>li.active>a:focus, .home-services-tabs .nav-pills>li.active>a:hover {
            color: #000;
            border-bottom-width: 1px;
            border-bottom-style: solid;
            border-bottom-color: #000;
            background-color: transparent;
            -webkit-transition: all 0.3s;
            -moz-transition: all 0.3s;
            transition: all 0.3s;
        }
      </style>
      <div class='home-services-tabs' style='background-color:{$bgcolor}'>
            <div class='container'>
                <h1 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>
                <!-- Tabs Starts -->
                <div role='tabpanel'>
                    <!-- Nav tabs -->
                    <ul class='nav nav-pills nav-justified' role='tablist'>";

                                        foreach ($image_html as $value) {
                                            $output.= $value[0];
                                        }
   
                    $output .=    "</ul>
                </div>
            </div>
            <!-- Tab panes -->
            <div class='container'>
                <div class='row'>
                    <div class='tab-content'>";

                                        foreach ($image_html as $value) {
                                            $output .= $value[1];
                                        }


                    $output .=   "</div>
                </div>
            </div>
            <!-- Tabs Ends -->
        </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_service_Tab_2_Single extends WPBakeryShortCode {

        private static $count = 0;

        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'custom_icon'   => 'fa-coffee',
            'icon_color'    => '#cecece',
            'title'         => 'BRAND',
            'image'         => 'Image',
            'details'       => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat',

            'title_font'    => '',
            'title_size'    => '16',
            'title_color'   => '#cecece',

            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#000',
            'link'          => '',
          ), $atts ) );
         

         /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

          $img = wp_get_attachment_image_src( $image, array(1007,368) );
    
          if($image == "Image"){
            $imgsrc = plugins_url('images/service_img1.jpg', __FILE__);
            $img[0] = $imgsrc;
          }

            $count1 = self::$count++;

            $extra_class = "";

            if($count1 == 0){
                $extra_class = "active";
            }

             $control_id = "services" . "-" . rand();



             if($link == "" || $link == "||"){
                    $link_string = "";
             }else{

                 $link = vc_build_link($link);
                 $link_url = esc_url($link["url"]);
                 $link_target = esc_attr($link["target"]);
                 $link_title = esc_attr($link["title"]);
                 $link_string = "<a target='".$link_target."' href='".$link_url."'>".$link_title."</a>";

             }



            // ||| is the seprator
            $output = "
            <li role='presentation' class='{$extra_class} animated' data-animation='fadeIn' data-animation-delay='100'>
                            <a href='#{$control_id}' aria-controls='{$control_id}' role='tab' data-toggle='tab'>
                                <div class='icon'><i class='fa {$custom_icon}'></i></div>
                                <div class='caption' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</div>
                            </a>
                        </li>
                        |||
                        <div role='tabpanel' class='tab-pane {$extra_class}' id='{$control_id}'>
                            <div class='col-lg-12'>
                                <div class='description animated' data-animation='fadeInUp' data-animation-delay='500' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}</div>
                                <div class='link animated' data-animation='fadeInUp' data-animation-delay='700'>{$link_string}</div>
                                <div class='picture animated' data-animation='fadeInUp' data-animation-delay='900'><img src='{$img[0]}' class='img-responsive center-block' alt=''></div>
                            </div>
                        </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>