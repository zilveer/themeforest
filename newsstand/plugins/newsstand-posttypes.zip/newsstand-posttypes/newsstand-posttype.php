<?php
/*
Plugin Name: NewsStand Post Types
Plugin URI: #
Description: Add Custom Post Types for this theme
Version: 1.0
Author: AvaThemes
Author URI: http://themeforest.net/user/AVAThemes
*/


/* Events */
add_action( 'init', 'newsstand_events_posttype', 0 );
function newsstand_events_posttype() {

	$labels = array(
		'name'                => _x( 'Events', 'Post Type General Name', 'sk8er' ),
		'singular_name'       => _x( 'Event', 'Post Type Singular Name', 'sk8er' ),
		'menu_name'           => __( 'Events', 'sk8er' ),
		'parent_item_colon'   => __( 'Parent Event:', 'sk8er' ),
		'all_items'           => __( 'All Events', 'sk8er' ),
		'view_item'           => __( 'View Event', 'sk8er' ),
		'add_new_item'        => __( 'Add New Event', 'sk8er' ),
		'add_new'             => __( 'Add New', 'sk8er' ),
		'edit_item'           => __( 'Edit Event', 'sk8er' ),
		'update_item'         => __( 'Update Event', 'sk8er' ),
		'search_items'        => __( 'Search Event', 'sk8er' ),
		'not_found'           => __( 'Not found', 'sk8er' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'sk8er' ),
	);

	$args = array(
		'label'               => __( 'event', 'sk8er' ),
		'description'         => __( 'Event Post Type', 'sk8er' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-calendar-alt',
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	register_post_type( 'event', $args );
}

/* Blog */
add_action( 'init', 'newsstand_blog_posttype', 0 );
function newsstand_blog_posttype() {

	$labels = array(
		'name'                => _x( 'Blog', 'Post Type General Name', 'sk8er' ),
		'singular_name'       => _x( 'Blog Post', 'Post Type Singular Name', 'sk8er' ),
		'menu_name'           => __( 'Blog', 'sk8er' ),
		'parent_item_colon'   => __( 'Parent Blog Post:', 'sk8er' ),
		'all_items'           => __( 'All Posts', 'sk8er' ),
		'view_item'           => __( 'View Post', 'sk8er' ),
		'add_new_item'        => __( 'Add New Post', 'sk8er' ),
		'add_new'             => __( 'Add New', 'sk8er' ),
		'edit_item'           => __( 'Edit Post', 'sk8er' ),
		'update_item'         => __( 'Update Post', 'sk8er' ),
		'search_items'        => __( 'Search Posts', 'sk8er' ),
		'not_found'           => __( 'Not found', 'sk8er' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'sk8er' ),
	);

	$args = array(
		'label'               => __( 'Blog Post', 'sk8er' ),
		'description'         => __( 'Blog Post Type', 'sk8er' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'comments' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-megaphone',
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	register_post_type( 'blog', $args );
}

/* Recipes */
add_action( 'init', 'newsstand_recipes_posttype', 0 );
function newsstand_recipes_posttype() {

	$labels = array(
		'name'                => _x( 'Recipes', 'Post Type General Name', 'sk8er' ),
		'singular_name'       => _x( 'Recipe', 'Post Type Singular Name', 'sk8er' ),
		'menu_name'           => __( 'Recipes', 'sk8er' ),
		'parent_item_colon'   => __( 'Parent Recipe:', 'sk8er' ),
		'all_items'           => __( 'All Recipes', 'sk8er' ),
		'view_item'           => __( 'View Recipe', 'sk8er' ),
		'add_new_item'        => __( 'Add New Recipe', 'sk8er' ),
		'add_new'             => __( 'Add New', 'sk8er' ),
		'edit_item'           => __( 'Edit Recipe', 'sk8er' ),
		'update_item'         => __( 'Update Recipe', 'sk8er' ),
		'search_items'        => __( 'Search Recipes', 'sk8er' ),
		'not_found'           => __( 'Not found', 'sk8er' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'sk8er' ),
	);

	$args = array(
		'label'               => __( 'Recipes', 'sk8er' ),
		'description'         => __( 'Recipes', 'sk8er' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-carrot',
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	register_post_type( 'recipe', $args );
}

/* Galleries */
add_action( 'init', 'newsstand_galleries_posttype', 0 );
function newsstand_galleries_posttype() {

	$labels = array(
		'name'                => _x( 'Galleries', 'Post Type General Name', 'sk8er' ),
		'singular_name'       => _x( 'Gallery', 'Post Type Singular Name', 'sk8er' ),
		'menu_name'           => __( 'Galleries', 'sk8er' ),
		'parent_item_colon'   => __( 'Parent Gallery:', 'sk8er' ),
		'all_items'           => __( 'All Galleries', 'sk8er' ),
		'view_item'           => __( 'View Gallery', 'sk8er' ),
		'add_new_item'        => __( 'Add New Gallery', 'sk8er' ),
		'add_new'             => __( 'Add New', 'sk8er' ),
		'edit_item'           => __( 'Edit Gallery', 'sk8er' ),
		'update_item'         => __( 'Update Gallery', 'sk8er' ),
		'search_items'        => __( 'Search Galleries', 'sk8er' ),
		'not_found'           => __( 'Not found', 'sk8er' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'sk8er' ),
	);

	$args = array(
		'label'               => __( 'Galleries', 'sk8er' ),
		'description'         => __( 'Galleries', 'sk8er' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'comments' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-format-gallery',
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	register_post_type( 'gallery', $args );
}

/* Videos */
add_action( 'init', 'newsstand_videos_posttype', 0 );
function newsstand_videos_posttype() {

	$labels = array(
		'name'                => _x( 'Videos', 'Post Type General Name', 'sk8er' ),
		'singular_name'       => _x( 'Video', 'Post Type Singular Name', 'sk8er' ),
		'menu_name'           => __( 'Videos', 'sk8er' ),
		'parent_item_colon'   => __( 'Parent Video:', 'sk8er' ),
		'all_items'           => __( 'All Videos', 'sk8er' ),
		'view_item'           => __( 'View Video', 'sk8er' ),
		'add_new_item'        => __( 'Add New Video', 'sk8er' ),
		'add_new'             => __( 'Add New', 'sk8er' ),
		'edit_item'           => __( 'Edit Video', 'sk8er' ),
		'update_item'         => __( 'Update Video', 'sk8er' ),
		'search_items'        => __( 'Search Videos', 'sk8er' ),
		'not_found'           => __( 'Not found', 'sk8er' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'sk8er' ),
	);

	$args = array(
		'label'               => __( 'Videos', 'sk8er' ),
		'description'         => __( 'Videos', 'sk8er' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'comments' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-format-video',
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	register_post_type( 'video', $args );
}

/* Team */
add_action( 'init', 'newsstand_team_posttype', 0 );
function newsstand_team_posttype() {

	$labels = array(
		'name'                => _x( 'Team', 'Post Type General Name', 'sk8er' ),
		'singular_name'       => _x( 'Member', 'Post Type Singular Name', 'sk8er' ),
		'menu_name'           => __( 'Team', 'sk8er' ),
		'parent_item_colon'   => __( 'Parent Member:', 'sk8er' ),
		'all_items'           => __( 'All Members', 'sk8er' ),
		'view_item'           => __( 'View Member', 'sk8er' ),
		'add_new_item'        => __( 'Add New Member', 'sk8er' ),
		'add_new'             => __( 'Add New', 'sk8er' ),
		'edit_item'           => __( 'Edit Member', 'sk8er' ),
		'update_item'         => __( 'Update Member', 'sk8er' ),
		'search_items'        => __( 'Search Member', 'sk8er' ),
		'not_found'           => __( 'Not found', 'sk8er' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'sk8er' ),
	);

	$args = array(
		'label'               => __( 'Member', 'sk8er' ),
		'description'         => __( 'Member', 'sk8er' ),
		'labels'              => $labels,
		'supports'            => array('title'),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-nametag',
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	register_post_type( 'team', $args );
}

/* Reviews */
add_action( 'init', 'newsstand_reviews_posttype', 0 );
function newsstand_reviews_posttype() {

	$labels = array(
		'name'                => _x( 'Reviews', 'Post Type General Name', 'sk8er' ),
		'singular_name'       => _x( 'Review', 'Post Type Singular Name', 'sk8er' ),
		'menu_name'           => __( 'Reviews', 'sk8er' ),
		'parent_item_colon'   => __( 'Parent Review:', 'sk8er' ),
		'all_items'           => __( 'All Reviews', 'sk8er' ),
		'view_item'           => __( 'View Review', 'sk8er' ),
		'add_new_item'        => __( 'Add New Review', 'sk8er' ),
		'add_new'             => __( 'Add New', 'sk8er' ),
		'edit_item'           => __( 'Edit Review', 'sk8er' ),
		'update_item'         => __( 'Update Review', 'sk8er' ),
		'search_items'        => __( 'Search Reviews', 'sk8er' ),
		'not_found'           => __( 'Not found', 'sk8er' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'sk8er' ),
	);

	$args = array(
		'label'               => __( 'Reviews', 'sk8er' ),
		'description'         => __( 'Reviews', 'sk8er' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'comments' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-star-half',
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	register_post_type( 'review', $args );
}