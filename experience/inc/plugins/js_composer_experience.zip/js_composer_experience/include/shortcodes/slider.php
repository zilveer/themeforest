<?php 
if ( class_exists( 'WPBakeryShortCode' ) ) {

	class WPBakeryShortCode_experience_slider extends WPBakeryShortCodesContainer {

		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = null ) {
			
			$output = $css_class = '';
			
			extract( shortcode_atts( array(
				'css'				=> '',
				'el_class' 			=> '',
				'start_at'			=> '',
				'slideshow_speed'	=> 7000,
				'animation_speed'	=> 600
			), $atts ) );
			
			$class = $this->getExtraClass( $el_class );			
			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );
		
			if ( $start_at != '' ) {
				$start_at = 'data-flexslider-startat="'. esc_attr( $start_at ) .'" ';
			}
			
			if ( $slideshow_speed != '' ) {
				$slideshow_speed = 'data-flexslider-slideshowspeed="'. esc_attr( $slideshow_speed ) .'" ';
			}
			
			if ( $animation_speed != '' ) {
				$animation_speed = 'data-flexslider-animationspeed="'. esc_attr( $animation_speed ) .'" ';
			}
			
			$output .= '<div class="section-header">';
			
				$output .= '<div id="flexslider" class="flexslider flexslider-big text-align-center'. esc_attr( $css_class ) .'" data-fill-screen="true" '. $start_at . $slideshow_speed .$animation_speed .'>';
					
					$output .= '<ul class="slides">'. wpb_js_remove_wpautop( $content ) .'</ul>';
				
				$output .= '</div>';
			
			$output .= '</div>';
			
			return $output;
			
			
		}	

	}
	
	class WPBakeryShortCode_experience_slider_slide extends WPBakeryShortCode {
		
		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		protected function content( $atts, $content = null ) {
			
			$experience_vc_utilities = new jsComposerExperienceUtilities();
			
			$output = $padding = '';
			
			extract( shortcode_atts( array(
				'el_class' 				=> '',
				'color' 			  	=> '',
				'background_image'	  	=> '',
				'background_video'	  	=> '',
				'label'					=> '',
				'title'					=> '',				
				'button'				=> '',
			), $atts ) );		
			
			$parallax = $parallax_image = $video_bg_url = '';
			$attributes = array();
			$css_classes = array();
			
			$css_classes[] = $this->getExtraClass( $el_class );
			$title = $experience_vc_utilities->experienceResizeText( $title );
			
			$parallax = 'content-moving';
			$parallax_speed = '1.5';
			
			if ( !empty ( $background_image ) ) {
				$parallax_image = esc_url( $background_image );
			}
			
			if ( !empty ( $background_video ) ) {
				$video_bg_url = esc_url( $background_video );
			}
	
			$has_video_bg = ( ! empty( $video_bg_url ) && vc_extract_youtube_id( $video_bg_url ) );

			if ( $has_video_bg ) {
				$parallax_image = $video_bg_url;
				$css_classes[] = ' vc_video-bg-container';
			}

			if ( ! empty( $parallax ) ) {						
				$attributes[] = 'data-vc-parallax="'. esc_attr( $parallax_speed ) .'"';
				$css_classes[] = 'vc_general vc_parallax vc_parallax-' . $parallax;
				$css_classes[] = 'js-vc_parallax-o-fixed';
			}

			if ( ! empty( $parallax_image ) ) {
				if ( $has_video_bg ) {
					$parallax_image_src = $parallax_image;
				} else {
					$parallax_image_id = preg_replace( '/[^\d]/', '', $parallax_image );
					$parallax_image_src = wp_get_attachment_image_src( $parallax_image_id, 'full' );
					if ( ! empty( $parallax_image_src[0] ) ) {
						$parallax_image_src = $parallax_image_src[0];
					}
				}
				$attributes[] = 'data-vc-parallax-image="'. esc_url( $parallax_image_src ) .'"';
			}
			
			if ( ! $parallax && $has_video_bg ) {
				$attributes[] = 'data-vc-video-bg="'. esc_url( $video_bg_url ) .'"';
			}

			// Set Slide colour scheme
			if ( !empty( $color ) ) {
				$attributes[] = 'color-scheme-'. $color;
			}
	
			$output .= '<li class="'. esc_attr( implode( ' ', $css_classes ) ) .' " '. implode( ' ', $attributes ) .'>';
				
				$output .= '<div class="exp_ie-flexbox-fixer">';
				
					$output .= '<div class="exp-full-height exp-flexbox exp-content-middle">';
				
						if ( $label == '' && $subtitle == '' ) {							
							$padding = '';							
						} else if ( $label != '' && $subtitle == '' ) {
							$padding = 'no-padding-top';							
						} else {
							$padding = '';							
						}
						
						$output .= '<div class="exp-flexbox-inner">';
							
							$output .= '<div class="section-header-content narrow-width padding-v '. esc_attr( $padding ) .'">';
				
								if ( $label != "" ) {
									$output .= '<span class="heading-label">'. wp_kses( $label, array( 'img' => array( 'src' => array(), 'height' => array(), 'width' => array(), 'alt' => array() ) ) ) .'</span>';
								}

								if ( $title != "" ) {						
									$output .= '<h2 class="heading-title">'. esc_html( $title ) .'</h2>';
								}						
								
							$output .= '</div>';
							
						$output .= '</div>';
						
					$output .= '</div>';
				
				$output .= '</div>';					
					
				if ( $button != "" ) {
					
					$button = vc_build_link( $button );
					
					$fancybox_class = '';						
					
					// Detect lightbox content type
					$path_info = pathinfo( $button['url'] );
					$url_info = parse_url( $button['url'] );

					// MP4 / WEBM
					if (
						(
							isset( $path_info['extension'] )
							&& in_array( $path_info['extension'], array( 'mp4', 'webm' ) )
						)
						|| (
							isset( $url_info['host'] )
							&& ( 
								$url_info['host'] == 'www.youtube.com' || $url_info['host'] == 'youtube.com' || $url_info['host'] == 'youtu.be'
								|| $url_info['host'] == 'www.vimeo.com' || $url_info['host'] == 'vimeo.com'
								|| $url_info['host'] == 'www.dailymotion.com' || $url_info['host'] == 'dailymotion.com'
							)
						)
					) {
						$fancybox_class = 'fancybox';
					}
	
					$output .= '<div class="slider-button-center">
						<a class="vc_btn3 '. esc_attr( $fancybox_class ) .'" href="'. esc_url( $button['url'] ) .'" target="'. esc_attr( $button['target'] ) .'">'. esc_html( $button['title'] ) .'</a>
					</div>';
				}
			
			$output .= '</li>';
			
			return $output;
		
		}
		
	}
	
}


/* ---------- SLIDER ---------- */

vc_map( array(
	"base"						=> "experience_slider",
	"name"						=> esc_html__( "Slider", "js_composer_experience" ),
	"description"				=> esc_html__( "Full screen slider with image/video backgrounds", "js_composer_experience" ),
	"as_parent"					=> array( "only" => "experience_slider_slide" ),
	"content_element"			=> true,
	"show_settings_on_create"	=> false,
	"js_view"					=> "VcColumnView",
	"params"					=> array(
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label"	=> true
		),
		
		// StartAt
		array(
			"param_name"	=> "start_at",
			"heading"		=> esc_html__( "StartAt", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the slide number the slider should begin on when first loaded.", "js_composer_experience" ),
			"type"			=> "textfield"
		),
		
		// Slideshow Speed
		array(
			"param_name"	=> "slideshow_speed",
			"heading"		=> esc_html__( "Slideshow Speed", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the duration of each slide (milliseconds)", "js_composer_experience" ),
			"type"			=> "textfield",
			"value"			=> 7000
		),
		
		// Animation Speed
		array(
			"param_name"	=> "animation_speed",
			"heading"		=> esc_html__( "Animation Speed", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the duration of slide transition animation (milliseconds).", "js_composer_experience" ),
			"type"			=> "textfield",
			"value"			=> 600
		),
		
		// CSS
		array(
			"param_name" => "css",
			"heading"	 => esc_html__( "CSS", "js_composer_experience" ),
			"type"		 => "css_editor",
			"group"		 => esc_html__( "Design options", "js_composer_experience" )
		)

	)
) );


/* --------- SLIDE --------- */

vc_map( array(
	"base"				=> "experience_slider_slide",
	"name"				=> esc_html__( "Slide", "js_composer_experience" ),
	"content_element"	=> true,
	"as_child"			=> array( "only" => "experience_slider" ),
	"params"			=> array(
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label"	=> true
		),	
		
		// Label
		array(
			"param_name"	=> "label",
			"heading"		=> esc_html__( "Label", "js_composer_experience" ),
			"description"	=> esc_html__( "Add a text label above the slide title.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label" => true
		),
		
		// Title
		array(
			"param_name"	=> "title",
			"heading"		=> esc_html__( "Title", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the slide title.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label" => true
		),
		
		// Button
		array(
			"param_name"	=> "button",
			"heading"		=> esc_html__( "Button URL", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the URL this button links to. Entering the file path to a MP4 or WebM video, or a link to a YouTube, Vimeo or Dailymotion video page will open the video in a lightbox.", "js_composer_experience" ),
			"type"			=> "vc_link",
			"admin_label"	=> true			
		),
		
		// ----- BACKGROUND ----- //
		
		// Background Image
		array(
			"param_name"	=> 'background_image',
			"heading"		=> esc_html__( 'Background Image', "js_composer_experience" ),
			"description"	=> esc_html__( "Select a background image for this row.", "js_composer_experience" ),
			"type"			=> 'attach_image',
			"group"			=> esc_html__( "Background", "js_composer_experience" ),
			"weight"		=> 900
		),
		
		// Background Video
		array(
			"param_name"	=> 'background_video',
			"heading"		=> esc_html__( 'Background Video', "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the page URL to a YouTube video to use as the slide background.", 'js_composer_experience' ),
			"type"			=> 'textfield',
			"group"			=> esc_html__( "Background", "js_composer_experience" ),
			"weight"		=> 900
		)
	
	)
) );