<?php 

/** 
 * Plugin Name: Contact Us Widget 
 * Description: Display a series of Contact Us (from Font Awesome) in a contact widget. 
 * Plugin URI: https://github.com/dtbaker/contact-us-widget/ 
 * Version: 1.1.2 
 * Author: dtbaker 
 * Author URI: http://dtbaker.net 
 * Text Domain: contact-us-widget 
 */ 


// Block direct requests
if ( !defined('ABSPATH') )
	die('-1');


/**
 * Tribe_Image_Widget class
 **/
class dtbaker_contact_us_widget extends WP_Widget {

	/**
	 * Contact Us constructor
	 */
	function __construct() {
		load_plugin_textdomain( 'contact_us_widget', false, trailingslashit(basename(dirname(__FILE__))) . 'lang/');
		$widget_ops = array( 'classname' => 'widget_contact_us_widget', 'description' => __( 'Display a series of Contact Us (Facebook, YouTube, etc..)', 'contact-us-widget' ) );
		$control_ops = array( 'id_base' => 'widget_contact_us_widget' );
		parent::__construct('widget_contact_us_widget', __('Contact Us', 'contact-us-widget'), $widget_ops, $control_ops);

        add_action( 'sidebar_admin_setup', array( $this, 'admin_setup' ) );
        add_action( 'wp_enqueue_scripts', array($this, 'frontend_setup' ) );
	}


	/**
	 * Enqueue all the styles for displaying icons in admin area.
	 */
	function admin_setup() {
		//wp_enqueue_media();
		wp_enqueue_style( 'dtbaker-contact-us-widget', plugins_url('contact-us.css', __FILE__) );
		wp_enqueue_script( 'dtbaker-contact-us-widget-admin', plugins_url('webicons-admin.js', __FILE__) );
	}

    function frontend_setup(){
        //if ( is_active_widget(false, false, $this->id_base, true) ) {
            wp_enqueue_style( 'dtbaker-contact-us-widget', plugins_url('contact-us.css', __FILE__) );
        //}
    }

	/**
	 * Widget frontend output
	 *
	 * @param array $args
	 * @param array $instance
	 */
	function widget( $args, $instance ) {
		extract( $args );
		$instance = wp_parse_args( (array) $instance, self::get_defaults() );

        $instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'] );
        $instance['description'] = apply_filters( 'widget_text', $instance['description'], $args, $instance );
		$instance['icons'] = empty( $instance['icons'] ) ? array() : (is_array($instance['icons']) ? $instance['icons'] : json_decode($instance['icons'], true));

        extract( $instance );

        include( $this->getTemplateHierarchy( 'widget' ) );
	}

	/**
	 * Update widget options
	 *
	 * @param object $new_instance Widget Instance
	 * @param object $old_instance Widget Instance
	 * @return object
	 * @author Modern Tribe, Inc.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$new_instance = wp_parse_args( (array) $new_instance, self::get_defaults() );
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['icon_size'] = strip_tags($new_instance['icon_size']);
		$instance['align'] = strip_tags($new_instance['align']);
		if ( current_user_can('unfiltered_html') ) {
			$instance['description'] = $new_instance['description'];
		} else {
			$instance['description'] = wp_filter_post_kses($new_instance['description']);
		}

        $instance['enabled_icons'] = array();
        if(is_array($new_instance['enabled_icons'])){
            $instance['enabled_icons'] = $new_instance['enabled_icons'];
        }
        $instance['enabled_icons'] = json_encode($instance['enabled_icons']);

		return $instance;
	}


	/**
	 * Render an array of default values.
	 *
	 * @return array default values
	 */
	public static function get_defaults() {

		$defaults = array(
			'title' => 'Contact Us',
			'description' => "Phone:||1800 123 123\nFax:||1800 321 321\nAddress:||Sydney, Australia",
			'icon_size' => 'large',
			'align' => '',
			'icons' => array(),
			'enabled_icons' => array(),
		);

		$iconlist = json_decode(file_get_contents(trailingslashit(plugin_dir_path(__FILE__)) . 'fontawesome.json'),true);

		// what categories to show in the icon selection dialog?
		$categories = array(
			"Brand Icons" => array()
		);

		foreach($categories as $category => $icons){
			foreach($iconlist as $icon){
				if(in_array($category,$icon['categories'])){
					$categories[$category][] = $icon;
				}
			}
		}

		$defaults['icons'] = $categories;

        $defaults['icons'] = json_encode($defaults['icons']);
        $defaults['enabled_icons'] = json_encode($defaults['enabled_icons']);

		return $defaults;
	}


	/**
	 * Form UI
	 *
	 * @param object $instance Widget Instance
	 * @author Modern Tribe, Inc.
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, self::get_defaults() );
        include( $this->getTemplateHierarchy( 'widget-admin' ) );
	}



	/**
	 * Loads theme files in appropriate hierarchy: 1) child theme,
	 * 2) parent template, 3) plugin resources. will look in the contact-us-widget/
	 * directory in a theme and the views/ directory in the plugin
	 *
	 * @param string $template template file to search for
	 * @return template path
	 * @author Modern Tribe, Inc. (Matt Wiebe) - from image-widget plugin
	 **/

	function getTemplateHierarchy($template) {
		// whether or not .php was added
		$template_slug = rtrim($template, '.php');
		$template = $template_slug . '.php';

		if ( $theme_file = locate_template(array('contact-us-widget/'.$template)) ) {
			$file = $theme_file;
		} else {
			$file = 'views/' . $template;
		}
		return apply_filters( 'template_contact-us-widget_'.$template, $file);
	}


}
add_action('widgets_init', create_function('', 'return register_widget("dtbaker_contact_us_widget");'));
