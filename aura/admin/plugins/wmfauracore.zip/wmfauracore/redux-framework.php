<?php
/**
 *
 * Plugin Name:     Webbu Aura Mobile Theme Core Elements
 * Plugin URI:      http://themeforest.net/user/Webbu
 * Description:     This plugin included with Aura Theme Options Panel & Menu area modifications. You need to activate this plugin for run Aura Theme.
 * Author:          Webbu
 * Author URI:      http://themeforest.net/user/Webbu
 * Version:         1.3.1
 *
 */

/**************************************************************************
*
* Below setting belong to translation system.
*
**************************************************************************/
function auramobile_lang_init() {
  load_plugin_textdomain( 'auraplgt2d', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}
add_action('plugins_loaded', 'auramobile_lang_init');

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if ( is_plugin_active('redux-framework/redux-framework.php') ) {
	require_once( plugin_dir_path( __FILE__ ) . 'ReduxFramework.config.php' ); 
}

// Include aura core options.
require_once( plugin_dir_path( __FILE__ ) . 'aura/aura.php' );

//Auto updater - Source: http://w-shadow.com/blog/2010/09/02/automatic-updates-for-any-plugin/
include 'plugin-updates/plugin-update-checker.php';
$AuraExampleUpdateChecker = new PluginUpdateChecker(
	'http://www.webbudesign.com/plugins/wmfauracore/info.json',
	__FILE__, 'wmfauracore'
);


//Here's how you can add query arguments to the URL.
function addSecretKeyAuraCore($query){
	$query['secret'] = 'foo';
	return $query;
}
$AuraExampleUpdateChecker->addQueryArgFilter('addSecretKeyAuraCore');