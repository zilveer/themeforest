<?php 
if ( !class_exists( 'SWM_Recent_Posts_Slider' ) ) {
	class SWM_Recent_Posts_Slider extends WP_Widget {
		
	    function __construct() {
			$widget_ops = array('description' => __('Display latest blog posts with slider', 'swmtranslate'));	
			parent::__construct('swm_recent_posts_slider_wid',$name = __('Widget - Recent Posts Slider', 'swmtranslate'),$widget_ops);
	    }

	  	/* Displays the Widget in the front-end */
	    function widget($args, $instance){
			extract($args);
			$title = apply_filters('widget_title', !empty($instance['title']) ? $instance['title'] : __('Recent Posts', 'swmtranslate') );
			$no_of_posts = !empty($instance['no_of_posts']) ? $instance['no_of_posts'] : '2' ;		
			$add_category = !empty($instance['add_category']) ? $instance['add_category'] : '' ;
			$auto_slideshow = $instance['auto_slideshow'] ? 'true' : 'false';
			$slideshow_interval = !empty($instance['slideshow_interval']) ? $instance['slideshow_interval'] : '500' ;			

			echo $before_widget;
			echo $before_title . $title . $after_title;		
			echo '<div class="recent_posts_slider '; 

			if ( $no_of_posts > 1 ) {			
				echo 'owl-recent-posts';
			}
			echo '" data-autoSlideshow="'.$auto_slideshow.'" data-slideshowInterval="'.$slideshow_interval.'">';
			
			$cnt = 0;

			if($add_category != ""){
				$recentposts = new WP_Query('cat='.$add_category.'&posts_per_page='.$no_of_posts.'&orderby=date&order=DESC');
			}else{
				$recentposts = new WP_Query('posts_per_page='.$no_of_posts.'&orderby=date&order=DESC');
			}
			
			while($recentposts->have_posts()): $recentposts->the_post();

			$format = get_post_format(); 		
						
			if($cnt < $no_of_posts){
			?>
				<div class="recent_posts_slider_content">
					<?php
					if(has_post_thumbnail()) { ?>
						<a href="<?php echo get_permalink(); ?>" title="<?php echo esc_attr(strip_tags(get_the_title())); ?>" class="tiny_img"> 
							<?php the_post_thumbnail('blog-grid-post'); ?>
						</a>
						<?php
					} elseif ( $format == 'video' ) {

						if (function_exists('rwmb_meta')) {								
							$swm_pf_meta_video = rwmb_meta('swm_meta_video');
							if( !empty( $swm_pf_meta_video ) ) {			
								echo "<div class='fitVids'>";
								echo stripslashes(htmlspecialchars_decode($swm_pf_meta_video));								
								echo '</div>';	
							}		
						}	

					}
					  ?>
					

					<div class="recent_posts_slider_title">				
						<p><a href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></p>				
						<span><?php the_time('jS F Y ')  ?>  / <a href="<?php get_permalink(); ?>"><?php echo get_comments_number(get_the_ID()).' '.__('Comments', 'swmtranslate'); ?></a></span>
					</div>

					<div class="recent_posts_slider_excerpt">
						<span></span>				
						<p><?php echo swm_the_excerpt(110); ?></p>						
					</div>
					
					<div class="clear"></div>
				</div>			
				
				<?php	

				$cnt++;		
			}	

			endwhile;	

			echo '</div>';
			echo '<div class="clear"></div>';
			echo $after_widget;		
		}

	  	/*Saves the settings. */
	    function update($new_instance, $old_instance){
			$instance = $old_instance;
			$instance['title'] = stripslashes($new_instance['title']);
			$instance['no_of_posts'] = stripslashes($new_instance['no_of_posts']);		
			$instance['add_category'] = stripslashes($new_instance['add_category']);
			$instance['auto_slideshow'] = !empty($new_instance['auto_slideshow']) ? true : false;
			$instance['slideshow_interval'] = stripslashes($new_instance['slideshow_interval']);
			
			return $instance;
		}
		
	    function form($instance){
			//Defaults
			$instance = wp_parse_args( (array) $instance, array('title'=> __('Recent Posts', 'swmtranslate'), 'no_of_posts'=>'2','add_category'=>'','blog_summery_text'=>'50', 'readmore_btn'=> __('read more', 'swmtranslate'),'slideshow_interval' => 5000,'auto_slideshow' => true) );

			$title = htmlspecialchars($instance['title']);
			$no_of_posts = $instance['no_of_posts'];		
			$add_category = $instance['add_category'];
			$auto_slideshow = isset($instance['auto_slideshow']) ? (bool) $instance['auto_slideshow'] :true;
			$slideshow_interval = $instance['slideshow_interval'];
			
			echo '<p><label for="' . $this->get_field_id('title') . '">' . __('Widget Title:', 'swmtranslate') . '</label><input class="widefat" id="' . $this->get_field_id('title') . '" name="' . $this->get_field_name('title') . '" type="text" value="' . $title . '" /></p>';
			
			echo '<p><label for="' . $this->get_field_id('no_of_posts') . '">' . __('Number of Posts to Display:', 'swmtranslate') . '</label><input class="widefat" id="' . $this->get_field_id('no_of_posts') . '" name="' . $this->get_field_name('no_of_posts') . '" type="text" value="' . $no_of_posts . '" /></p>';		
			
			
			echo '<p><label for="' . $this->get_field_id('add_category') . '">' . __('Display Specific Categories:', 'swmtranslate') . '</label><input class="widefat" id="' . $this->get_field_id('add_category') . '" name="' . $this->get_field_name('add_category') . '" type="text" value="' . $add_category . '" /><br /><small>' . __('If you want to display specific category(ies) recent posts only, then add Category IDs with comma seperated (e.g. 1,2,3) or <strong>Leave it blank for default.</strong>', 'swmtranslate') . '</small></p>';	
?>	
			<hr>
			<p>
				<input class="checkbox" type="checkbox" <?php checked($instance['auto_slideshow'], true) ?> id="<?php echo $this->get_field_id('auto_slideshow'); ?>" name="<?php echo $this->get_field_name('auto_slideshow'); ?>" />
				<label for="<?php echo $this->get_field_id('auto_slideshow'); ?>"><?php _e('Enable Auto Slideshow', 'swmtranslate') ?></label>		
			</p>

			<p>
				<label for="<?php echo $this->get_field_id( 'slideshow_interval' ); ?>"><?php _e('Slideshow Interval', 'swmtranslate') ?></label>
				<input id="<?php echo $this->get_field_id( 'slideshow_interval' ); ?>" name="<?php echo $this->get_field_name( 'slideshow_interval' ); ?>" value="<?php echo $instance['slideshow_interval']; ?>" style="width:95%;" /><br >
				<small><?php _e('The amount of time (in ms) between each auto transition', 'swmtranslate') ?></small>
			</p><?php
			
		}
	}
}

function SWM_Recent_Posts_Slider_Widget() {
  register_widget('SWM_Recent_Posts_Slider');
}
add_action('widgets_init', 'SWM_Recent_Posts_Slider_Widget');
?>