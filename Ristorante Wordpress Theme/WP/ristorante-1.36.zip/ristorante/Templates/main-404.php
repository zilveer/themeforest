{extends 'main-layout.php'}
{block content}

<div id="container" class="subpage defaultContentWidth onecolumn clearfix left">

	<div id="content" class="mainbar entry-content" role="main">

		<h1>{_}This is somewhat embarrassing, isn't it?{/_}</h1>

		<p>{_}Apologies, but the page you requested could not be found. Perhaps searching will help.{/_}</p>

		{include general-search-form.php}

	</div>

</div>

{/block}