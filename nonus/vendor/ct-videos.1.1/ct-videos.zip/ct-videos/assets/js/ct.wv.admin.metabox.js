jQuery( function ( $ ) {


	var video_sortable_options = {
		items: '.ct-woovideo-woocommerce-video',
		cursor: 'move',
		axis: 'y',
		handle: 'h3',
		scrollSensitivity: 40,
		forcePlaceholderSize: true,
		helper: 'clone',
		opacity: 0.65,
		placeholder: 'wc-metabox-sortable-placeholder',
		start: function( event, ui ) {
			ui.item.css( 'background-color', '#f6f6f6' );
		},
		stop: function ( event, ui ) {
			ui.item.removeAttr( 'style' );
			video_row_indexes();
		}
	};

    var $woovideo_options = $( '#ct-woovideo-product-options' );

    var restoreVideoSettings = function(defaults, $parent) {
        $.each(defaults, function(index, value){

            var $input = $parent.find("[name^=" + index + "]");

            $input.not('.ct-woovideo-select-icon').not('.ct-woovideo-video-clearing').not('.ct-woovideo-video-autoplay').not('.ct-woovideo-video-ratio').val(value);

            if(index == 'ct_woovideo_location') {
                if (value == 'shortcode') {
                    $input.closest('.ct-woovideo-video-location').find('.ct-woovideo-shortcode-info').removeClass('hidden');
                } else {
                    $input.closest('.ct-woovideo-video-location').find('.ct-woovideo-shortcode-info').addClass('hidden');
                }

                if (value == 'button') {
                    $input.closest('.ct-woovideo-video-settings').find('.ct-woovideo-button-settings').removeClass('hidden');
                } else {
                    $input.closest('.ct-woovideo-video-settings').find('.ct-woovideo-button-settings').addClass('hidden');
                }

                if (value == 'image_gallery') {
                    $input.closest('.ct-woovideo-video-settings').find('.ct-woovideo-gallery-location').removeClass('hidden');
                } else {
                    $input.closest('.ct-woovideo-video-settings').find('.ct-woovideo-gallery-location').addClass('hidden');
                }
            }

            if(index == 'ct_woovideo_select_icon') {
                $input.closest('.ct-woovideo-icon-settings').find('.ct-woovideo-select-icon[value=' + value + ']').prop('checked', true);
            }

            if(index == 'ct_woovideo_video_ratio') {
                $input.closest('.ct-woovideo-video-player').find('.ct-woovideo-video-ratio[value=' + value + ']').prop('checked', true);
            }

            if(index == 'ct_woovideo_icon_color') {
                $input.closest('.wp-picker-container').find('.wp-color-result').css('background-color', value);
            }

            if(index== 'ct_woovideo_video_clearing'){
                if (value== 'on') {
                    $input.prop('checked', true);
                } else {
                    $input.prop('checked', false);
                }
            }

            if(index== 'ct_woovideo_video_autoplay'){
                if (value== 'on') {
                    $input.prop('checked', true);
                } else {
                    $input.prop('checked', false);
                }
            }
        });
    };

    var restoreButtonSettings = function(defaults, $parent) {
        $.each(defaults, function(index, value){

            var $input = $parent.find("[name^=" + index + "]");
            $input.val(value);

            if(index == 'ct_woovideo_button_location') {
                if (value== 'shortcode') {
                    $input.closest('.ct-woovideo-button-settings').find('.ct-woovideo-button-shortcode-info').removeClass('hidden');
                } else {
                    $input.closest('.ct-woovideo-button-settings').find('.ct-woovideo-button-shortcode-info').addClass('hidden');
                }
            }

            if((index == 'ct_woovideo_button_color')||(index == 'ct_woovideo_button_text_color')) {
                $input.closest('.wp-picker-container').find('.wp-color-result').css('background-color', value);
            }

            if(index == 'ct_woovideo_button_label'){
                if (value== 'custom') {
                    $input.closest('.ct-woovideo-button-settings').find('.ct-woovideo-custom-button-label').removeClass('hidden');
                } else {
                    $input.closest('.ct-woovideo-button-settings').find('.ct-woovideo-custom-button-label').addClass('hidden');
                }
                if (value == 'thumbnail') {
                    $input.closest('.ct-woovideo-button-settings').find('.ct-woovideo-button-dimentions').removeClass('hidden');
                    $input.closest('.ct-woovideo-button-settings').find('.ct-woovideo-button-paddings').addClass('hidden');
                } else {
                    $input.closest('.ct-woovideo-button-settings').find('.ct-woovideo-button-dimentions').addClass('hidden');
                    $input.closest('.ct-woovideo-button-settings').find('.ct-woovideo-button-paddings').removeClass('hidden');
                }
            }

            if(index == 'ct_woovideo_button_clearing'){
                if (value== 'on') {
                    $input.prop('checked', true);
                } else {
                    $input.prop('checked', false);
                }
            }
        });
    };



	// Add a video
	$woovideo_options.on( 'click', 'button.ct-woovideo-add-video', function () {

		$('.ct-woovideo-woocommerce-videos').block({
			message: null,
			overlayCSS: {
				background: '#fff',
				opacity: 0.6
			}
		});

		var loop = $('.ct-woovideo-woocommerce-video').size();

		var data = {
			action: 'ct_woovideo_add_video',
			post_id: ct_woovideo_admin_videos.post_id,
			loop: loop,
			security: ct_woovideo_admin_videos.add_video_nonce
		};

		$.post( ct_woovideo_admin_videos.ajax_url, data, function ( response ) {

			$( '.ct-woovideo-woocommerce-videos' ).append( response );

			$( '.tips' ).tipTip({
				'attribute': 'data-tip',
				'fadeIn': 50,
				'fadeOut': 50
			});

			//$( 'input.video_is_downloadable, input.video_is_virtual, input.video_manage_stock' ).change();
			$( '.ct-woovideo-woocommerce-videos' ).unblock();
			$woovideo_options.trigger( 'woocommerce_videos_added' );
		});

		return false;

	});

    // Remove a video
	$woovideo_options.on( 'click', 'button.ct-woovideo-remove-video', function ( e ) {
		e.preventDefault();
		var answer = window.confirm( ct_woovideo_admin_videos.i18n_remove_video );
		if ( answer ) {

			var el = $( this ).parent().parent();

			var video = $( this ).attr( 'rel' );

			if ( video != '' ) {

				$( el ).block({
					message: null,
					overlayCSS: {
						background: '#fff',
						opacity: 0.6
					}
				});

				var video_ids = [];
				video_ids.push( video );

				var data = {
					action: 'ct_woovideo_remove_video',
                    post_id: ct_woovideo_admin_videos.post_id,
					video_ids: video_ids,
					security: ct_woovideo_admin_videos.delete_videos_nonce
				};


				$.post( ct_woovideo_admin_videos.ajax_url, data, function ( response ) {
					// Success
					$( el ).fadeOut( '300', function () {
						$( el ).remove();
					});
				});

			} else {
				$( el ).fadeOut( '300', function () {
					$( el ).remove();
				});
			}

		}
		return false;
	});

    // Save videos
    $('.save_videos').on('click', function(){

        $('.ct-woovideo-woocommerce-video').block({ message: null, overlayCSS: { background: '#fff', opacity: 0.6 } });

        var data = {
            post_id: 		ct_woovideo_admin_videos.post_id,
            data:			$('.ct-woovideo-woocommerce-video').find('input, select, textarea').serialize(),
            action: 		'ct_woovideo_save_videos',
            security: 		ct_woovideo_admin_videos.save_videos_nonce
        };

         $.post( ct_woovideo_admin_videos.ajax_url, data, function( response ) {
            console.log( response );
            $('.ct-woovideo-woocommerce-video').unblock();

        });

    });

    // Bulk options
    $woovideo_options.on( 'click', 'a.bulk_edit', function ( event ) {

        event.preventDefault();
        var bulk_edit  = $( 'select#field_to_edit' ).val(),
            checkbox,
            answer,
            value;

        switch ( bulk_edit ) {
            case 'remove_all' :
                answer = window.confirm( ct_woovideo_admin_videos.i18n_delete_all_videos );
                if ( answer ) {
                    var $parent = $( this ).closest('#ct-woovideo-product-options');
                    var $container = $parent.find('.ct-woovideo-woocommerce-videos');
                    var videos = $container.find('.ct-woovideo-post-id');

                    if ( videos != '' ) {

                        $( $container ).block({
                            message: null,
                            overlayCSS: {
                                background: '#fff',
                                opacity: 0.6
                            }
                        });

                        var video_ids = [];
                        var video_id;

                        $.each(videos, function(){
                            video_id = $(this).attr('value');
                            video_ids.push( video_id );
                        });

                        var data = {
                            action: 'ct_woovideo_remove_video',
                            post_id: ct_woovideo_admin_videos.post_id,
                            video_ids: video_ids,
                            security: ct_woovideo_admin_videos.delete_videos_nonce
                        };


                        $.post( ct_woovideo_admin_videos.ajax_url, data, function ( response ) {
                            // Success
                            $( $container ).fadeOut( '300', function () {
                                $( videos ).remove();
                            });
                        });

                    } else {
                        $( $container ).fadeOut( '300', function () {
                            $( videos ).remove();
                        });
                    }
                }
                break;
            case 'restore_video_defaults' :
                answer = window.confirm( ct_woovideo_admin_videos.i18n_restore_all_video_defaults );
                if ( answer ) {

                    var $parent = $( this ).closest( '#ct-woovideo-product-options' );
                    var $video_options = $parent.find('.ct-woovideo-inline-video-settings');

                    $video_options.block({ message: null, overlayCSS: { background: '#fff', opacity: 0.6 } });

                    var data = {
                        post_id: 		ct_woovideo_admin_videos.post_id,
                        data:			$video_options.find('input, select, textarea')
                                            .not('.ct-woovideo-shortcode-input')
                                            .not('.ct-woovideo-upload-image-id')
                                            .not('.ct-woovideo-restore-video-defaults')
                                            .serialize(),
                        action: 		'ct_woovideo_restore_defaults',
                        security: 		ct_woovideo_admin_videos.restore_defaults_nonce
                    };

                    $.post( ct_woovideo_admin_videos.ajax_url, data, function( response ) {

                        var defaults = $.parseJSON(response);

                        restoreVideoSettings(defaults, $parent);

                        $video_options.unblock();

                    });

                }
                break;
            case 'restore_button_defaults' :
                answer = window.confirm( ct_woovideo_admin_videos.i18n_restore_all_button_defaults );
                if ( answer ) {

                    var $parent = $( this ).closest( '#ct-woovideo-product-options' );
                    var $button_options = $parent.find('.ct-woovideo-button-settings');

                    $button_options.block({ message: null, overlayCSS: { background: '#fff', opacity: 0.6 } });

                    var data = {
                        post_id: 		ct_woovideo_admin_videos.post_id,
                        data:           $button_options.find('input, select, textarea').not('.ct-woovideo-button-shortcode-input').serialize(),
                        action: 		'ct_woovideo_restore_defaults',
                        security: 		ct_woovideo_admin_videos.restore_defaults_nonce
                    };

                    $.post( ct_woovideo_admin_videos.ajax_url, data, function( response ) {

                        var defaults = $.parseJSON(response);

                        restoreButtonSettings(defaults, $parent);

                        $button_options.unblock();

                    });
                }
                break;

            default:
                $( 'select#field_to_edit' ).trigger( bulk_edit );
                break;

        }
    });

	// Ordering
	$woovideo_options.on( 'woocommerce_videos_added', function () {
		$( '.ct-woovideo-woocommerce-videos' ).sortable( video_sortable_options );
	} );

	$( '.ct-woovideo-woocommerce-videos' ).sortable( video_sortable_options );

	function video_row_indexes() {
		$( '.ct-woovideo-woocommerce-videos .ct-woovideo-woocommerce-video' ).each( function ( index, el ) {
			$( '.ct-woovideo-video-position', el ).val( parseInt( $( el ).index( '.ct-woovideo-woocommerce-videos .ct-woovideo-woocommerce-video' ), 10 ) );
		});
	}


	// Upload thumbnail
	var video_image_frame;
	var setting_video_image_id;
	var setting_video_image;
	var wp_media_post_id = wp.media.model.settings.post.id;

	$woovideo_options.on( 'click', '.ct-woovideo-upload-image-button', function ( event ) {

		var $button                = $( this );
		var post_id                = $button.attr( 'rel' );
		var $parent                = $button.closest( '.ct-woovideo-video-image' );
		setting_video_image    = $parent;
		setting_video_image_id = post_id;

		event.preventDefault();

		if ( $button.is( '.remove' ) ) {

			setting_video_image.find( '.ct-woovideo-upload-image-id' ).val( '' );
			setting_video_image.find( 'img' ).eq( 0 ).attr( 'src', ct_woovideo_admin_videos.woocommerce_placeholder_img_src );
			setting_video_image.find( '.ct-woovideo-upload-image-button' ).removeClass( 'remove' );
			setting_video_image.find( '.ct-woovideo-icon-settings ' ).addClass( 'hidden' );

		} else {

			// If the media frame already exists, reopen it.
			if ( video_image_frame ) {
				video_image_frame.uploader.uploader.param( 'post_id', setting_video_image_id );
				video_image_frame.open();
				return;
			} else {
				wp.media.model.settings.post.id = setting_video_image_id;
			}

			// Create the media frame.
			video_image_frame = wp.media.frames.video_image = wp.media({
				// Set the title of the modal.
				title: ct_woovideo_admin_videos.i18n_choose_image,
				button: {
					text: ct_woovideo_admin_videos.i18n_set_image
				},
				states : [
					new wp.media.controller.Library({
						title: ct_woovideo_admin_videos.i18n_choose_image,
						filterable :	'all'
					})
				]
			});

            // When an image is selected, run a callback.
			video_image_frame.on( 'select', function () {

				var attachment = video_image_frame.state().get( 'selection' ).first().toJSON(),
					url = attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;

				setting_video_image.find( '.ct-woovideo-upload-image-id' ).val( attachment.id );
				setting_video_image.find( '.ct-woovideo-upload-image-button' ).addClass( 'remove' );
				setting_video_image.find( 'img' ).eq( 0 ).attr( 'src', url );
                setting_video_image.find( '.ct-woovideo-icon-settings ' ).removeClass( 'hidden' );

				wp.media.model.settings.post.id = wp_media_post_id;

			});

			// Finally, open the modal.
			video_image_frame.open();
		}

	});

    //upload video button
    var upload_video_frame;
    var setting_video_id;
    var setting_video;

    $woovideo_options.on( 'click', '.ct-woovideo-upload-video-button', function ( event ) {

    var $button                = $( this );
    var post_id                = $button.attr( 'rel' );
    var $parent                = $button.closest( '.ct-woovideo-upload-video' );
    setting_video    = $parent;
    setting_video_id = post_id;

    event.preventDefault();

        // If the media frame already exists, reopen it.
        if ( upload_video_frame ) {
            upload_video_frame.uploader.uploader.param( 'post_id', setting_video_id );
            upload_video_frame.open();
            return;
        } else {
            wp.media.model.settings.post.id = setting_video_id;
        }


        // Create the media frame.
        upload_video_frame = wp.media.frames.video = wp.media({
            // Set the title of the modal.
            title: ct_woovideo_admin_videos.i18n_choose_video,
            button: {
                text: ct_woovideo_admin_videos.i18n_set_video
            },
            multiple: false,
            states : [
                new wp.media.controller.Library({
                    title: ct_woovideo_admin_videos.i18n_choose_video,
                    filterable: 'all'
                })
            ]

        });

        // When a video is selected, run a callback.
        upload_video_frame.on( 'select', function () {
            console.log(upload_video_frame.state());
            var attachment = upload_video_frame.state().get( 'selection' ).first().toJSON(),
                url = attachment.url;

            setting_video.find( '.ct-woovideo-upload-video-id' ).val( attachment.id );
            setting_video.find( '.ct-woovideo-remove-uploaded-video-button' ).addClass( 'remove' );
            setting_video.find( '.ct-woovideo-upload-video-name' ).text(attachment.filename);
            setting_video.find( '.ct-woovideo-upload-video-name-input').val(attachment.filename);

            wp.media.model.settings.post.id = wp_media_post_id;
        });

        // Finally, open the modal.
        upload_video_frame.open();

});


    //'remove uploaded video' button
    $woovideo_options.on( 'click', '.ct-woovideo-remove-uploaded-video-button', function ( event ) {
        var $button      = $( this );
        var $parent      = $button.closest( '.ct-woovideo-upload-video' );
        setting_video    = $parent;

        event.preventDefault();

        setting_video.find( '.ct-woovideo-upload-video-id' ).val( '' );
        setting_video.find( '.ct-woovideo-upload-video-name-input' ).val( '' );
        setting_video.find( '.ct-woovideo-upload-video-name' ).text('');
        setting_video.find( '.ct-woovideo-remove-uploaded-video-button' ).removeClass( 'remove' );

    });

    //view 'gallery video location' field awhen 'image gallery' location selected

    $woovideo_options.on('change', '.ct-woovideo-select-location', function () {

        var val = $("option:selected", this).val();

        if (val == 'image_gallery') {
            $(this)
                .closest('.ct-woovideo-video-settings')
                .find('.ct-woovideo-gallery-location')
                .removeClass('hidden');
        } else {
            $(this)
                .closest('.ct-woovideo-video-settings')
                .find('.ct-woovideo-gallery-location')
                .addClass('hidden');
        }

    });

    //view 'button location' field and button options when 'button' location selected

    $woovideo_options.on('change', '.ct-woovideo-select-location', function () {

        var val = $("option:selected", this).val();

        if (val == 'button') {
            $(this)
                .closest('.ct-woovideo-video-settings')
                .find('.ct-woovideo-button-settings')
                .removeClass('hidden');
        } else {
            $(this)
                .closest('.ct-woovideo-video-settings')
                .find('.ct-woovideo-button-settings')
                .addClass('hidden');
        }

    });

    //view 'button dimentions' fields when label set to thumbnail

    $woovideo_options.on('change', '.ct-woovideo-button-label', function () {

        var val = $("option:selected", this).val();

        if (val == 'thumbnail') {
            $(this)
                .closest('.ct-woovideo-button-settings')
                .find('.ct-woovideo-button-dimentions')
                .removeClass('hidden');
            $(this)
                .closest('.ct-woovideo-button-settings')
                .find('.ct-woovideo-button-paddings')
                .addClass('hidden');
        } else {
            $(this)
                .closest('.ct-woovideo-button-settings')
                .find('.ct-woovideo-button-dimentions')
                .addClass('hidden');
            $(this)
                .closest('.ct-woovideo-button-settings')
                .find('.ct-woovideo-button-paddings')
                .removeClass('hidden');
        }

    });

    //view 'custom label' field when 'custom' label selected

    $woovideo_options.on('change', '.ct-woovideo-button-label', function () {

        var val = $("option:selected", this).val();

        if (val == 'custom') {
            $(this)
                .closest('.ct-woovideo-button-settings')
                .find('.ct-woovideo-custom-button-label')
                .removeClass('hidden');
        } else {
            $(this)
                .closest('.ct-woovideo-button-settings')
                .find('.ct-woovideo-custom-button-label')
                .addClass('hidden');
        }

    });



    //view shortcode when 'shortcode' location selected


    $woovideo_options.on('change', '.ct-woovideo-select-location', function (event) {

        var $setting      = $( this );
        var $parent      = $setting.closest( '.ct-woovideo-video-settings' );
        setting_location    = $parent;
        event.preventDefault();

        var shortcode = setting_location.find('.ct-woovideo-shortcode');
        var shortcode_info = setting_location.find('.ct-woovideo-shortcode-info');
        var shortcode_input = setting_location.find('.ct-woovideo-shortcode-input');

        var val = $("option:selected", this).val();

        if (val == 'shortcode') {

            var data = {
                post_id: 		ct_woovideo_admin_videos.post_id,
                data:			$(this).closest('.ct-woovideo-woocommerce-video').find('.ct-woovideo-post-id').serialize(),
                action: 		'ct_woovideo_show_shortcode',
                security: 		ct_woovideo_admin_videos.ct_woovideo_show_shortcode_nonce
            };

            $.post( ct_woovideo_admin_videos.ajax_url, data, function( response ) {
                shortcode.text(response);
                shortcode_input.val(response);
                shortcode_info.removeClass('hidden');


            });
        } else {
            shortcode_info.addClass('hidden');
        }
    });

    //view button shortcode when 'shortcode' button location selected
    $woovideo_options.on('change', '.ct-woovideo-select-button-location', function (event) {
        event.preventDefault();

        var $this      = $( this );
        var $parent      = $this.closest( '.ct-woovideo-button-settings' );

        var shortcode = $parent.find('.ct-woovideo-button-shortcode');
        var shortcode_info = $parent.find('.ct-woovideo-button-shortcode-info');
        var shortcode_input = $parent.find('.ct-woovideo-button-shortcode-input');

        var val = $("option:selected", this).val();

        if (val == 'shortcode') {


            var data = {
                post_id: 		ct_woovideo_admin_videos.post_id,
                data:			$(this).closest('.ct-woovideo-woocommerce-video').find('.ct-woovideo-post-id').serialize(),
                action: 		'ct_woovideo_show_button_shortcode',
                security: 		ct_woovideo_admin_videos.ct_woovideo_show_button_shortcode_nonce
            };

            $.post( ct_woovideo_admin_videos.ajax_url, data, function( response ) {
                shortcode.text(response);
                shortcode_input.val(response);
                shortcode_info.removeClass('hidden');
            });
        } else {
            shortcode_info.addClass('hidden');
        }
    });


    //'restore default video settings' button
    $woovideo_options.on( 'click', '.ct-woovideo-restore-video-defaults', function ( event ) {
        event.preventDefault();

        var $button      = $( this );
        var $parent      = $button.closest( '.ct-woovideo-inline-video-settings' );

        $parent.block({ message: null, overlayCSS: { background: '#fff', opacity: 0.6 } });

        var data = {
            post_id: 		ct_woovideo_admin_videos.post_id,
            data:			$parent.find('input, select, textarea')
                                .not('.ct-woovideo-shortcode-input')
                                .not('.ct-woovideo-upload-image-id')
                                .not('.ct-woovideo-restore-video-defaults')
                                .serialize(),
            action: 		'ct_woovideo_restore_defaults',
            security: 		ct_woovideo_admin_videos.restore_defaults_nonce
        };

        $.post( ct_woovideo_admin_videos.ajax_url, data, function( response ) {

            var defaults = $.parseJSON(response);

            restoreVideoSettings(defaults, $parent);

            $parent.unblock();

        });

    });

    //'restore default button settings' button
    $woovideo_options.on( 'click', '.ct-woovideo-restore-button-defaults', function ( event ) {
        event.preventDefault();

        var $button      = $( this );
        var $parent      = $button.closest( '.ct-woovideo-button-settings' );

        $parent.block({ message: null, overlayCSS: { background: '#fff', opacity: 0.6 } });

        var data = {
            post_id: 		ct_woovideo_admin_videos.post_id,
            data:			$parent.find('input, select, textarea').not('.ct-woovideo-button-shortcode-input').serialize(),
            action: 		'ct_woovideo_restore_defaults',
            security: 		ct_woovideo_admin_videos.restore_defaults_nonce
        };

        $.post( ct_woovideo_admin_videos.ajax_url, data, function( response ) {

            var defaults = $.parseJSON(response);

            restoreButtonSettings(defaults, $parent);

            $parent.unblock();

        });

    });


    //color picker
    $woovideo_options.on( 'woocommerce_videos_added', function () {
        $('.ct-woovideo-color-picker').wpColorPicker();
    });

    $('.ct-woovideo-color-picker').wpColorPicker();


	// Restore ID
	$( 'a.add_media' ).on(' click', function () {
		wp.media.model.settings.post.id = wp_media_post_id;
	});

});

