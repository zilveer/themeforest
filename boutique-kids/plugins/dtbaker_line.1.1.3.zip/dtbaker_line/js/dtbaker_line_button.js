var dtbaker_plugin_buttons = dtbaker_plugin_buttons || [];
( function() {
    dtbaker_plugin_buttons.push({
        text: 'Line',
        icon: false,
        onclick: function() {
            wp.mce.dtbaker_line.popupwindow(tinyMCE.activeEditor);
        }
    });
    tinymce.PluginManager.add( 'dtbaker_plugin_buttons', function( editor, url ) {
        editor.addButton( 'dtbaker_plugin_buttons_insert', {
            text: 'Insert',
            type: 'listbox',
            icon: false,
            onselect: function(e){},
            values: dtbaker_plugin_buttons
        });
    } );
} )();