<?php
//Register "container" content element

vc_map( array(
    "name" => __("Vertical Tabs", "wish"),
    "description" => __("Vertical Tabs", 'wish'),
    "controls" => "full",
    "base" => "wish_vertical_tabs2",
    "as_parent" => array('only' => 'wish_vertical_tabs2_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/AcyaKAO.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(
        
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Top Title", "wish"),
            "value" => __("Vertical Tabs", 'wish'),
            "admin_label" => true,
        ),
 
        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("36", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#fff', //Default Red color
            "description" => __( "Choose background color", "wish" ),
            "group" => "Fonts & Colors",
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Tab", "wish"),
    "base" => "wish_vertical_tabs2_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_vertical_tabs2'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "wish_fontawesome_param",
            "holder" => "div",
            "class" => "",
            "heading" => __("Custom Icon", 'wish'),
            "param_name" => "custom_icon",
            "value" => __("fa-heart-o", 'wish'),
            "description" => __("Get Font Awesome Icons Code Here: <a target='_blank' href='http://fortawesome.github.io/Font-Awesome/cheatsheet/'>Link</a>, New icons may not work. Leave blank if you want to use the above icon.", 'wish'),
            "admin_label" => false,
        ),
         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Icon color", "wish" ),
            "param_name" => "icon_color",
            "value" => '#df4322', //Default Red color
            "description" => __( "Choose color of icon", "wish" ),
            "group" => "Fonts & Colors",
         ),

        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Top Title", "wish"),
            "value" => __("Insights", 'wish'),
            "admin_label" => true,
        ), 
        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's Standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make.", 'wish'),
            "description" => __("The Details", 'wish'),
            "admin_label" => false,
        ),


         /*Title 1*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title 1 Text Font", "wish" ),
            "param_name" => "title1_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title 1 Size", "wish"),
            "param_name" => "title1_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("16", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title 1 Text Color", "wish" ),
            "param_name" => "title1_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        


        /*Title 2*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title 2 Text Font", "wish" ),
            "param_name" => "title2_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title 2 Size", "wish"),
            "param_name" => "title2_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("24", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title 2 Text Color", "wish" ),
            "param_name" => "title2_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Vertical_Tabs2 extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title' => 'Vertical Tabs',
            'title_font' => '',
            'title_size' => '',
            'title_color' => '#000',
            'bgcolor'   => '#fff'  
          ), $atts ) );


        /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

           $shortcode = substr_replace( do_shortcode($content), '||||', -1); 

          $data =  explode("||||", $shortcode );


      $output = "<div class='container' style='background-color:{$bgcolor}'>
                <div class='row'>
                    <h1 class='heading' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>
                    <!-- Vertical Tabs Starts -->
                    <div class='col-lg-12 vertical-tabs'>
                        <div role='tabpanel'>
                            <div class='row'>
                                <div class='col-lg-3'>
                                    <!-- Nav tabs -->
                                    <ul class='nav nav-stacked' role='tablist'>";
                                            foreach ($data as $key => $value) {
                                                $li =  explode("|||", $value );
                                                $output .= $li[0];
                                            }
                    $output .=    "</ul>
                                </div>
                                <div class='col-lg-8'>
                                    <!-- Tab panes -->
                                    <div class='tab-content'>";

                                            foreach ($data as $key => $value) {
                                                $image_html =  explode("|||", $value );
                                                $output .= $image_html[1];
                                            }


                    $output .=   "</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Vertical Tabs Ends -->
                </div>
            </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Vertical_Tabs2_Single extends WPBakeryShortCode {
        static $count = 0;

        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'custom_icon' => 'fa-heart-o',
            'icon_color' => '#df4322',
            
            'title' => 'insights',
            'title1_font' => '',
            'title2_font' => '',
            'title1_size' => '16',
            'title2_size' => '24',
            'title1_color' => '#000',
            'title2_color' => '#000',
            
            'details' => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's Standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make.",
            'details_font' => '',
            'details_size' => '14',
            'details_color' => '#000'
          ), $atts ) );


          /*Title1*/
        $decode_font = urldecode($title1_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title1_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*Title2*/
        $decode_font = urldecode($title2_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title2_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

     
        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

          self::$count++;


          //$var = self::$count;
          
          if (self::$count == 1) {
            $addclass = 'active';
          }
          else{
            $addclass = '';
          }

$title_id = str_replace(' ', '', $title);


          $output = "
          <style>
          .vertical-tabs .nav-stacked li .icon{
            color:{$icon_color};
          }
          .vertical-tabs .nav-stacked li .icon:hover{
            color: #fff;
          }
          </style>
          <li role='presentation' class='animated {$addclass}' data-animation='flipInY' data-animation-delay='100'>
                                            <a href='#{$title_id}' role='tab' data-toggle='tab' aria-expanded='false' style='font-family:{$title1_font_family};font-size:{$title1_size}px;color:{$title1_color}'>
                                                <div class='icon'><i class='fa {$custom_icon}'></i></div>
                                                {$title}
                                            </a>
                                        </li>
                                        |||
                                        <div role='tabpanel' class='tab-pane {$addclass}' id='{$title_id}'>
                                            <h3 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title2_font_family};font-size:{$title2_size}px;color:{$title2_color}'>{$title}</h3>
                                            <div class='description animated' data-animation='fadeInUp' data-animation-delay='300' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}</div>
                                        </div>
                                        ||||";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>