<?php $icons = array();
$icons['icomoon']['ue095'] = 'ue095';