<style type="text/css">
    .wooDefault.<?php echo $value; ?> {
        margin: <?php echo $btmTop; ?>px <?php echo $btmRight; ?>px <?php echo $btmBottom; ?>px <?php echo $btmLeft; ?>px !important;
        padding: <?php echo $btpTop; ?>px <?php echo $btpRight; ?>px <?php echo $btpBottom; ?>px <?php echo $btpLeft; ?>px !important;
    }
    .wooDefault.small.<?php echo $value; ?> {
        display:block !important;
        text-align: center !important;
    }
</style>