<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// add shortcode for intro
add_shortcode('intro','multipurpose_intro');

function multipurpose_intro($atts, $content = null) {
    $output = '<article class="intro">'. do_shortcode($content) .'</article>';
    return $output;
}