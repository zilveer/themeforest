<?php
/** 
 * @package WordPress
 * @subpackage All Around Child Theme
 * Use to override functions in the functions.php All Around theme file.
 * Declare a function you wish to override.
 *
 * EXAMPLE
 *
 * function allaround_setup_theme() {
 * //write your own function allaround_setup_theme() function
 * }
 *
 *
 */

?>