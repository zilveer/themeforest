<?php 
if ( class_exists( 'WPBakeryShortCode' ) ) {

	class WPBakeryShortCode_experience_heading extends WPBakeryShortCode {
		
		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		 
		protected function content( $atts, $content = null ) {
		
			extract( shortcode_atts( array(
				'el_class' 			=> '',
				'label'				=> '',
				'text' 				=> '',
				'url'				=> '',
				'button_text'		=> '',
				'css' 				=> ''
			), $atts ) );
			
			$output = $css_class = $link = $link_class = '';			

			$class = $this->getExtraClass( $el_class );			
			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );

			$output .= '<div class="section-header'. esc_attr( $css_class ) .'">';
				
				$output .= '<div class="section-header-content padding-h narrow-width">';
					
					if ( $label != "" ) {
						$output .= '<span class="heading-label">'. wp_kses( $label, array( 'img' => array( 'src' => array(), 'height' => array(), 'width' => array(), 'alt' => array() ) ) ) .'</span>';
					}
					
					if ( $text != "" ) {
						$output .= '<h2 class="heading-title">'. experience_resize_text( $text ) .'</h2>';
					}
					
					if ( $url != "" ) {
						
						$link = vc_build_link( $url );
						
						if ( $link['title'] != "" ) {
							$link_class = 'vc_btn3';				
						} else {
							$link_class = 'custom-heading-link';
						}
						
						$output .= '<a class="'. esc_attr( $link_class ) .'" href="'. esc_url( $link['url'] ) .'"'
						. ( $link['target'] ? ' target="'. esc_attr( $link['target'] ) .'"' : '' )
						.'>'. ( $link['title'] ? esc_attr( $link['title'] ) : '' ) .'</a>';

					}

				$output .= '</div>';

			$output .= '</div>';

			return $output;			
			
		}
		
	}
	
}


/* --------- HEADING --------- */
	
vc_map( array(
	"base"			=> "experience_heading",
	"name"			=> esc_html__( "Heading", "js_composer_experience" ),
	"description"	=> esc_html__( "Display a section heading matching theme default styles.", "js_composer_experience" ),
	"class"			=> "",	
	"params"		=> array(
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			"type"			=> "textfield",
			'admin_label'	=> true
		),
		
		// Label
		array(
			"param_name"	=> "label",
			"heading"		=> esc_html__( "Label", 'js_composer_experience' ),
			"type"			=> "textfield",
			"description"	=> esc_html__( "Add a text label above the title text.", 'js_composer_experience' ),
			"admin_label" => true
		),
		
		// Text
		array(
			"param_name"	=> "text",
			"heading"		=> esc_html__( "Title", 'js_composer_experience' ),
			"type"			=> "textfield",
			"description"	=> esc_html__( "Enter the heading's title text.", 'js_composer_experience' ),
			"admin_label" => true
		),
		
		// URL
		array(
			"param_name"	=> "url",
			"heading"		=> esc_html__( "URL", 'js_composer_experience' ),
			"type"			=> "vc_link",
			"description"	=> esc_html__( "Enter the URL this header links to. Text entered in the Link Text field will be used as the button text. If the Link Text field is left empty the entire heading text will be a clickable link.", 'js_composer_experience' ),
			"admin_label" => true			
		),
		
		// Button Text
		//array(
		//	"param_name"	=> "button_text",
		//	"heading"		=> esc_html__( "Button Text", 'js_composer_experience' ),
		//	"type"			=> "textfield",
		//	"description"	=> esc_html__( "Enter the text to display on the heading's button.", 'js_composer_experience' ),
		//	"admin_label" => true
		//),
		
		// CSS
		array(
			"param_name" => "css",
			"heading"	 => esc_html__( "CSS", "js_composer_experience" ),
			"type"		 => "css_editor",
			"group"		 => esc_html__( "Design options", "js_composer_experience" )
		)
	
	)
	
) );