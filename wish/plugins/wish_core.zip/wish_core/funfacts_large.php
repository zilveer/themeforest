<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Funfacts Large", "wish"),
    "description" => __("Funfacts with Image and Name", 'wish'),
    "controls" => "full",
    "base" => "wish_funfacts_large",
    "as_parent" => array('only' => 'wish_funfact_large_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/8sUfHAd.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("The title", "wish"),
            "value" => __("Between the Numbers", 'wish'),
            "admin_label" => false,
        ),
        array(
            "type" => "textfield",
            "heading" => __("Subtitle", "wish"),
            "param_name" => "subtitle",
            "description" => __("The subtitle", "wish"),
            "value" => __("idea to an unforgetable digital experience", 'wish'),
            "admin_label" => false,
        ),
        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Dive into each project with beautifully crafted & pages for each individual project. Wherever you’re a print designer, web designer or photographer. Dive into each project with beautifully crafted & pages for each individual project. Wherever you’re a print designer, web designer or photographer.", 'wish'),
            "description" => __("Details", 'wish'),
            "admin_label" => false,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("30", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        /*Subtitle*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Subtitle Text Font", "wish" ),
            "param_name" => "subtitle_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Subtitle Size", "wish"),
            "param_name" => "subtitle_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("70", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Subtitle Text Color", "wish" ),
            "param_name" => "subtitle_color",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("16", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),



        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#43b572', //Default Light Green color
            "description" => __( "Choose background gradient color 1", "wish" ),
            "group"         => "Fonts & Colors",
        ), 

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Gradient Color 1", "wish" ),
            "param_name" => "bgcolor1",
            "value" => 'rgba(173,206,57,1)', //Default Light Green color
            "description" => __( "Choose background gradient color 1", "wish" ),
            "group"         => "Fonts & Colors",
        ), 
        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Gradient Color 2", "wish" ),
            "param_name" => "bgcolor2",
            "value" => 'rgba(67,181,151,1)', //Default sky blue color
            "description" => __( "Choose background gradient color 2", "wish" ),
            "group"         => "Fonts & Colors",
        ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Funfact Large", "wish"),
    "base" => "wish_funfact_large_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_funfacts_large'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,    
        ),

         array(
            "type" => "textfield",
            "heading" => __("Title", "wish"),
            "param_name" => "title",
            "description" => __("Funfact Name", "wish"),
            "value" => __("Projects Completed", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textfield",
            "heading" => __("Count", "wish"),
            "param_name" => "count",
            "description" => __("Funfact Count", "wish"),
            "value" => __("458", 'wish'),
            "admin_label" => false,
        ),


         /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("18", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),


        /*Count*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __("Count Text Font", "wish" ),
            "param_name" => "count_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Count Size", "wish"),
            "param_name" => "count_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("90", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Count Text Color", "wish" ),
            "param_name" => "count_color",
            "value" => '#000 ', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"         => "Fonts & Colors",
         ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __("Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#fff ', //Default Black color
            "description" => __( "Choose background color", "wish" ),
            "group"         => "Fonts & Colors",
         ),




    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_funfacts_Large extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title' => 'Between the Numbers',
            'title_font'    => '',
            'title_size'    => '30',
            'title_color'   => '#fff',

            'subtitle' => 'idea to an unforgetable digital experience',
            'subtitle_font' => '',
            'subtitle_size' => '70',
            'subtitle_color'=> '#fff',

            'details' => 'Dive into each project with beautifully crafted & pages for each individual project. Wherever you’re a print designer, web designer or photographer. Dive into each project with beautifully crafted & pages for each individual project. Wherever you’re a print designer, web designer or photographer.',
            'details_font'  => '',
            'details_size'  => '16',
            'details_color' => '#fff',

            'bgcolor' => '#43b572',
            'bgcolor1'   => 'rgba(173,206,57,1)',
            'bgcolor2'   => 'rgba(67,181,151,1)',
          ), $atts ) );


          /*title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*subtitle*/
        $decode_font = urldecode($subtitle_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $subtitle_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


      $output = "
      <style>
      .green-bg {
            background-color: {$bgcolor};
            background: -webkit-linear-gradient(left, {$bgcolor1}, {$bgcolor2});
            background: -o-linear-gradient(left, {$bgcolor1}, {$bgcolor2};
            background: -moz-linear-gradient(left, {$bgcolor1}, {$bgcolor2});
            background: linear-gradient(to left, {$bgcolor1}, {$bgcolor2};
        }
      </style>
      <div class='container-fluid funfacts'>
            <div class='row row-eq-height'>
                <div class='col-lg-4 green-bg'>
                    <div class='intro'>
                        <h3 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h3>
                        <h1 class='animated' data-animation='fadeInUp' data-animation-delay='500' style='font-family:{$subtitle_font_family};font-size:{$subtitle_size}px;color:{$subtitle_color};'>{$subtitle}</h1>
                        <div class='description animated' data-animation='fadeInUp' data-animation-delay='800' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                    </div>
                </div>
                <div class='col-lg-8'>
                    <div class='row'>
                    " . do_shortcode($content) . "
                
            </div>
                </div>
            </div>
        </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_funfact_Large_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image'   => 'Image',
            
            'title' => 'Projects Completed',
            'title_font'    => '',
            'title_size'    => '18',
            'title_color'   => '#000',

            'count' => '458',
            'count_font'    => '',
            'count_size'    => '90',
            'count_color' => '#000',

            'title_color'   => '#000',

            'bgcolor'   => '#fff'
          ), $atts ) );

        /*title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

        /*count*/
        $decode_font = urldecode($count_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $count_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );

          $img = wp_get_attachment_image_src( $image, 'full' );

          if($image == "Image"){
            $imgsrc = plugins_url('images/funtact_img.png', __FILE__);
            $img[0] = $imgsrc;
          }

          $output = "<div class='col-lg-4 col-md-4 box' style='background-color:{$bgcolor}'>
                            <div class='icon animated' data-animation='rotateIn' data-animation-delay='200'><img src='{$img[0]}' class='img-responsive center-block' alt=''></div>
                            <div class='count' style='font-family:{$count_font_family};font-size:{$count_size}px;color:{$count_color};'>{$count}</div>
                            <div class='caption animated' data-animation='fadeInUp' data-animation-delay='400' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</div>
                        </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>