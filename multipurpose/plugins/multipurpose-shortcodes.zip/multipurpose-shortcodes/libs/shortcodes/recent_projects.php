<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// add shortcode recent_projects
add_shortcode('recent_projects','multipurpose_recent_projects');
function multipurpose_recent_projects($atts, $content = null) {
    if(isset($atts) && !empty($atts))
        array_walk($atts, 'multipurpose_arrangement_shortcode_arr_value');

    extract(shortcode_atts(array(  
        'title'=> '',
        'number_of_columns'=> '',
        'view_anchor_text'=> '',
        'go_anchor_text'=> '',
        'excerpt'=> '',
        'excerpt_words'=> '',
        'strip_html'=> '',
        'headline'=> ''
    ), $atts));  

    $output = '<section class="columns portfolio no-filter">';

    if(!empty($title))
        $output .= '<h2 class="underline"><span>'.$atts["title"].'</span></h2>';
	
    $args = array(
        'posts_per_page'  => $number_of_columns,
        'orderby'         => 'post_date',
        'order'           => 'DESC',
        'post_type'       => 'project',
        'post_status'     => 'publish',
        'suppress_filters' => true );

    $posts_array = get_posts( $args );
    if(!empty($posts_array)) {
        foreach($posts_array as $key_data => $val_data) {
            
            $output .= '<article class="col col'.$number_of_columns.'">';
            if (!empty($go_anchor_text) || !empty($view_anchor_text)) {

                    if(has_post_thumbnail($val_data->ID)) {
                            $img = wp_get_attachment_image_src( get_post_thumbnail_id( $val_data->ID ), 'project-thumbnail' );
                            $output .= '<div class="img">';
                            $output .= '<img src="'.$img[0].'" width="'.$img[1].'" height="'.$img[2].'" alt="'.get_post_meta(get_post_thumbnail_id( $val_data->ID ) , '_wp_attachment_image_alt', true).'"/>';
                            $output .= '<div>';
                            $output .= '<ul>';
                            $output .= '<li><a href="'.wp_get_attachment_url(get_post_thumbnail_id($val_data->ID)).'" class="action view">'.$view_anchor_text.'</a></li>';
                            $output .= '<li><a href="'.get_permalink($val_data->ID).'" class="action go">'.$go_anchor_text.'</a></li>';
                            $output .= '</ul>';
                            $output .= '</div>';
                            $output .= '</div>';
                    }
            }
            else {
                if(has_post_thumbnail($val_data->ID)) {
                    $output .= '<p class="img"><a href="'.get_permalink($val_data->ID).'">'.get_the_post_thumbnail($val_data->ID,'thumbnail',$val_data->post_title).'</a></p>';
                }
            }

            if($headline =='yes') {
                $output .= '<h3><a href="'.get_permalink($val_data->ID).'">'.$val_data->post_title.'</a></h3>';
            }

            if($excerpt == 'yes') {
                if(!empty($val_data->post_excerpt)) {
                        $output .= '<p>'.multipurpose_cut_character_word($excerpt_words,$val_data->post_excerpt,$strip_html).'</p>';
                } elseif(!empty($val_data->post_content)) {
                        $output .= '<p>'.multipurpose_cut_character_word($excerpt_words,$val_data->post_content,$strip_html).'</p>';
                }
            }

            $output.= '</article>';
        }
    }

    $output .= '</section>';
    return $output;
}