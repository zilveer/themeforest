<?php
/** Defaults */
//Colors
($btnBgClr=="")? $btnBgClr='#88afda':$btnBgClr=$btnBgClr;
($btnBgClrHover=="")? $btnBgClrHover='#a2c0e2':$btnBgClrHover=$btnBgClrHover;
($btnTxtClr=="")? $btnTxtClr='#fff':$btnTxtClr=$btnTxtClr;

//Shadow
($hboxshadow=="0")? $hboxshadow='0':$hboxshadow=$hboxshadow;
($vboxshadow=="0")? $vboxshadow='1':$vboxshadow=$vboxshadow;
($bboxshadow=="0")? $bboxshadow='0':$bboxshadow=$bboxshadow;
($sboxshadow=="0")? $sboxshadow='0':$sboxshadow=$sboxshadow;
($cboxshadow=="")? $cboxshadow='rgba(255,255,255,0.2)':$cboxshadow=$cboxshadow;

//Border
($btnRadiusValue=="")? $btnRadiusSmallValue='7':$btnRadiusSmallValue=$btnRadiusValue;
($btnRadiusValue=="")? $btnRadiusValue='10':$btnRadiusValue=$btnRadiusValue;
($btnThicknessValue=="")? $btnThicknessValue='1':$btnThicknessValue=$btnThicknessValue;
($btnBorderClr=="")? $btnBorderClr='#7593B9':$btnBorderClr=$btnBorderClr;
($btnBorderClrHover=="")? $btnBorderClrHover='#8ca5c4':$btnBorderClrHover=$btnBorderClrHover;

//Padding small
($btpTop=="")? $btpTopSmall='7':$btpTopSmall=$btpTop;
($btpRight=="")? $btpRightSmall='15':$btpRightSmall=$btpRight;
($btpBottom=="")? $btpBottomSmall='7':$btpBottomSmall=$btpBottom;
($btpLeft=="")? $btpLeftSmall='15':$btpLeftSmall=$btpLeft;

//Padding
($btpTop=="")? $btpTop='15':$btpTop=$btpTop;
($btpRight=="")? $btpRight='30':$btpRight=$btpRight;
($btpBottom=="")? $btpBottom='15':$btpBottom=$btpBottom;
($btpLeft=="")? $btpLeft='30':$btpLeft=$btpLeft;

?>

<style type="text/css">
    .ct-style-slick.<?php echo $value; ?> {
        background: linear-gradient(to bottom,  <?php echo $btnBgClr; ?> 0%,#4d73a0 100%) !important;
        text-shadow: 0px -1px 0px rgba(0,0,0,.4) !important;
        box-shadow:inset <?php echo $hboxshadow; ?>px <?php echo $vboxshadow; ?>px <?php echo $bboxshadow; ?>px <?php echo $sboxshadow; ?>px <?php echo $cboxshadow; ?> !important;
        border-radius:  <?php echo $btnRadiusValue; ?>px !important;
        color: <?php echo $btnTxtClr; ?>; !important;
        font-size: 16px !important;
        font-weight: bold !important;
        padding: <?php echo $btpTop; ?>px <?php echo $btpRight; ?>px <?php echo $btpBottom; ?>px <?php echo $btpLeft; ?>px !important;
        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClr; ?> !important;
        text-decoration: none !important;
        display: inline-block !important;
    }

    .ct-style-slick.small.<?php echo $value; ?> {
        border-radius:  <?php echo $btnRadiusSmallValue; ?>px !important;
        font-size: 14px !important;
        padding: <?php echo $btpTopSmall; ?>px <?php echo $btpRightSmall; ?>px <?php echo $btpBottomSmall; ?>px <?php echo $btpLeftSmall; ?>px !important;
        display:block !important;
        text-align: center !important;
    }

    .ct-style-slick.<?php echo $value; ?>:hover, .ct-style-slick.small.<?php echo $value; ?>:hover {
        background: <?php echo $btnBgClrHover; ?> !important;
        background: linear-gradient(to bottom,  <?php echo $btnBgClrHover; ?>; 0%,#5e84b1 100%) !important;
        border: <?php echo $btnThicknessValue; ?>px solid <?php echo $btnBorderClrHover; ?> !important;
        color: <?php echo $btnTxtClrHover; ?> !important;
        text-decoration: none !important;


    }
</style>