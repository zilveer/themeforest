<?php  /*IJAZ AHMAD*/
//Register "container" content element
vc_map( array(
    "name" => __("Our Team", "wish"),
    "description" => __("Our Team with Images and details", 'wish'),
    "controls" => "full",
    "base" => "wish_our_team",
    "as_parent" => array('only' => 'wish_our_team_single'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "link"  => "http://i.imgur.com/wh2IhZE.png",
    "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__),
    "show_settings_on_create" => true,
    "category" => __('Wish Components', 'wish'),
    "js_view" => 'VcColumnView',
    "params" => array(

        // add params same as with any other content element
        array(
            "type" => "textfield",
            "heading" => __("Heading", "wish"),
            "param_name" => "title",
            "description" => __("Our Team Title and Position", "wish"),
            "value" => __("OUR TEAM", 'wish'),
            "admin_label" => true,
        ),
  
        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram.", 'wish'),
            "description" => __("Details", 'wish'),
            "admin_label" => false,
        ),


        /*Title*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Title Text Font", "wish" ),
            "param_name" => "title_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Title Font Size", "wish"),
            "param_name" => "title_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("26", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Title Text Color", "wish" ),
            "param_name" => "title_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),

        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Font Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),

         array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Background Color", "wish" ),
            "param_name" => "bgcolor",
            "value" => '#FFFFFF', //Default Red color
            "description" => __( "Choose the background color", "wish" ),
            "group"       => "Fonts & Colors",
         ),


    ),

));//ends vc_map

//////////////child elements
vc_map( array(
    "name" => __("Team Member", "wish"),
    "base" => "wish_our_team_single",
    "content_element" => true,
    "as_child" => array('only' => 'wish_our_team'), // Use only|except attributes to limit parent (separate multiple values with comma)
    "params" => array(

        array(
            "type" => "attach_image",
            "holder" => "div",
            "class" => "",
            "heading" => __("The Image", 'wish'),
            "param_name" => "image",
            "admin_label" => false,    
        ),

        array(
            "type" => "textfield",
            "heading" => __("Name", "wish"),
            "param_name" => "name",
            "description" => __("Team Member Name", "wish"),
            "value" => __("Mark Simon", 'wish'),
            "admin_label" => false,
        ),
  
        array(
            "type" => "textfield",
            "heading" => __("Designation", "wish"),
            "param_name" => "designation",
            "description" => __("Our Team member designation", "wish"),
            "value" => __("Project Manager", 'wish'),
            "admin_label" => false,
        ),

        array(
            "type" => "textarea",
            "holder" => "div",
            "class" => "",
            "heading" => __("Details", 'wish'),
            "param_name" => "details",
            "value" => __("Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum.", 'wish'),
            "description" => __("Details", 'wish'),
            "admin_label" => false,
        ),


         /*Name*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Name Text Font", "wish" ),
            "param_name" => "name_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Name Font Size", "wish"),
            "param_name" => "name_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("16", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Name Text Color", "wish" ),
            "param_name" => "name_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),



         /*Designation*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Designation Text Font", "wish" ),
            "param_name" => "designation_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Designation Font Size", "wish"),
            "param_name" => "designation_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Designation Text Color", "wish" ),
            "param_name" => "designation_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),




        /*Details*/
        array(
            "type" => "google_fonts",
            "class" => "",
            "heading" => __( "Details Text Font", "wish" ),
            "param_name" => "details_font",
            "value" => '', //Default Red color
            "description" => __( "Choose Font", "wish" ),
            "group"   => "Fonts & Colors",
            'settings' => array(
                 'fields'=>array(
                     'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch
                     'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"
               )
            )       
        ),


        array(
            "type" => "wish_number",
            "heading" => __("Details Font Size", "wish"),
            "param_name" => "details_size",
            "description" => __("Font size in px", "wish"),
            "value" => __("14", 'wish'),
            "admin_label" => true,
            "group"       => "Fonts & Colors",
        ),

        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Details Text Color", "wish" ),
            "param_name" => "details_color",
            "value" => '#000', //Default Black color
            "description" => __( "Choose text color", "wish" ),
            "group"       => "Fonts & Colors",
         ),

        
        array(
            "type" => "colorpicker",
            "class" => "",
            "heading" => __( "Info area Border Color", "wish" ),
            "param_name" => "border_color",
            "value" => '#f8ae1c', //Default Red color
            "description" => __( "Choose border color of info section", "wish" ),
            "group"       => "Fonts & Colors",
        ),

    )//ends params

) );//ends vc_map



////////////////////////////////////Starts container class
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Wish_Our_Team extends WPBakeryShortCodesContainer {

    public function content( $atts, $content = null ) {

          extract( shortcode_atts( array(
            'title'         => 'OUR TEAM',
            'title_font'    => '',
            'title_size'    => '26',
            'title_color'   => '#000',

            'details'       => 'Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram.',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#000',

            'bgcolor'       => '#ffffff',  
          ), $atts ) );


            /*Title*/
        $decode_font = urldecode($title_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


      $output = "<div class='team' style='background-color:{$bgcolor};'>
        <div class='container'>
            <div class='row'>
                <div class='col-lg-8 col-lg-offset-2'>
                    <h1 class='animated' data-animation='fadeInUp' data-animation-delay='100' style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color};'>{$title}</h1>
                    <div class='description animated' data-animation='fadeInUp' data-animation-delay='300' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}
                    </div>
                </div>
                    " . do_shortcode($content) . "
                
            </div>
            </div>
            </div>";
      
      return $output;
    }


    }//end of container class
} //end if

///////////////////////////////////////////ends container class


if ( class_exists( 'WPBakeryShortCode' ) ) {
class WPBakeryShortCode_Wish_Our_Team_Single extends WPBakeryShortCode {


        public function content( $atts, $content = null ) {
        
          extract( shortcode_atts( array(
            'image'         => 'Image',

            'name'          => 'Mark Simon',
            'name_font'     => '',
            'name_size'     => '16',
            'name_color'    => '#000',

            'designation'       => 'Project Manager',
            'designation_font'  => '',
            'designation_size'  => '14',
            'designation_color' => '#000',

            'details'       => 'Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum.',
            'details_font'  => '',
            'details_size'  => '14',
            'details_color' => '#000',

            'border_color'  => '#f8ae1c',

          ), $atts ) );

        /*Name*/
        $decode_font = urldecode($name_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $name_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*Details*/
        $decode_font = urldecode($details_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );


        /*Designation*/
        $decode_font = urldecode($designation_font);
        $decode_font = explode('|', $decode_font);
        $font_string = str_replace('font_family:', 'family=', $decode_font[0]);
        preg_match("/family=(.*):/", $font_string, $output_array);
        $designation_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";

        wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



          $img = wp_get_attachment_image_src( $image, array(360,395) );

          if($image == "Image"){
            $imgsrc = plugins_url('images/team2.jpg', __FILE__);
            $img[0] = $imgsrc;
          }

          $output = "<div class='col-lg-4 block animated' data-animation='fadeInUp' data-animation-delay='600'>
                    <div class='picture'><img src='{$img[0]}' class='img-responsive center-block' alt=''></div>
                    <div class='info' style='border-color:{$border_color};'>
                        <div class='name' style='font-family:{$name_font_family};font-size:{$name_size}px;color:{$name_color};'>{$name}</div>
                        <div class='designation' style='font-family:{$designation_font_family};font-size:{$designation_size}px;color:{$designation_color};'>{$designation}</div>
                        <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color};'>{$details}</div>
                    </div>
                </div>";

          return $output;
        }


}//end class

} //end if

/////////////////////////////////////////////////////////////////////////////////////////////

?>