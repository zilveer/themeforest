<?php
/**
* Plugin Name: Event Station Theme: Page Builder Elements
* Plugin URI: http://themeforest.net/user/gloriatheme
* Description: Event Station theme page builder elements plugin
* Version: 1.0
* Author: Gloria Theme
* Author URI: http://gloriatheme.com/
*/

/*------------- CONTENT WIDGET TITLE START -------------*/
function content_widget_title_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'style' => '',
			'title' => '',
			'text' => '',
			'icon' => '',
			'separator' => '',
			'titlefontsize' => '',
			'textfontsize' => '',
			'textfontsize' => '',
			'titlecolor' => '',
			'textcolor' => '',
			'separatorcolor' => '',
			'iconbackground' => '',
			'iconcolor' => '',
			'customclass' => '',
		), $atts
	);
	
	$output = '';
	
	$allowed_html = array ( 'br' => array() );
	
	if( !empty( $atts['iconcolor'] ) ) {
		$iconcolor = 'color:' . esc_attr( $atts['iconcolor'] ) . ';';
	}
	else {
		$iconcolor ="";
	}

	if( !empty( $atts['iconbackground'] ) ) {
		$iconbackground = 'background:' . esc_attr( $atts['iconbackground'] ) . ';';
	}
	else {
		$iconbackground ="";
	}
	
	if( !empty( $atts['iconcolor'] ) or !empty( $atts['iconbackground'] ) ) {
		$iconStyle = ' style="' . $iconcolor . $iconbackground . '"';
	} else {
		$iconStyle = "";
	}
	
	if( !empty( $atts['titlecolor'] ) ) {
		$titlecolor = 'color:' . esc_attr( $atts['titlecolor'] ) . ';';
	}
	else {
		$titlecolor ="";
	}

	if( !empty( $atts['titlefontsize'] ) ) {
		$titlefontsize = 'font-size:' . esc_attr( $atts['titlefontsize'] ) . ';';
	}
	else {
		$titlefontsize ="";
	}
	
	if( !empty( $atts['titlecolor'] ) or !empty( $atts['titlefontsize'] ) ) {
		$titleStyle = ' style="' . $titlecolor . $titlefontsize . '"';
	} else {
		$titleStyle = "";
	}
	
	if( !empty( $atts['textcolor'] ) ) {
		$textcolor = 'color:' . esc_attr( $atts['textcolor'] ) . ';';
	}
	else {
		$textcolor ="";
	}

	if( !empty( $atts['textfontsize'] ) ) {
		$textfontsize = 'font-size:' . esc_attr( $atts['textfontsize'] ) . ';';
	}
	else {
		$textfontsize ="";
	}
	
	if( !empty( $atts['textcolor'] ) or !empty( $atts['textfontsize'] ) ) {
		$textStyle = ' style="' . $textcolor . $textfontsize . '"';
	} else {
		$textStyle = "";
	}

	if( !empty( $atts['separatorcolor'] ) ) {
		$separatorbg = ' style="background:' . esc_attr( $atts['separatorcolor'] ) . ';"';
	}
	else {
		$separatorbg ="";
	}

	if( !empty( $atts['separatorcolor'] ) ) {
		$separatordot = ' style="border-color:' . esc_attr( $atts['separatorcolor'] ) . ';"';
	}
	else {
		$separatordot ="";
	}

	if( !empty( $atts['customclass'] ) ) {
		$customClass = ' ' . esc_attr( $atts['customclass'] );
	} else {
		$customClass = "";
	}

	if( !empty( $atts['style'] ) ) {
		$style = ' ' . esc_attr( $atts['style'] );
	} else {
		$style = "";
	}
	
	if( !empty( $atts['title'] ) ) {
		$output .= '<div class="content-widget-title' . $customClass . $style . '"><div class="content-title-text">';
			if( !empty( $atts['icon'] ) ) {
				$output .= '<i class="fa fa-' . esc_attr( $atts['icon'] ) . '"' . $iconStyle . '></i>';
			}
			if( !empty( $atts['title'] ) ) {
				$output .= '<h3' . $titleStyle . '>' . wp_kses( $atts['title'] , $allowed_html );
					if( !$atts['separator'] == "false" ) {
						$output .= '<span class="separator">
											<span class="separator-line"' . $separatorbg . '></span>
											<span class="separator-dot"' . $separatordot . '></span>
										</span>';
					}
				$output .= '</h3>';
			}
			if( !empty( $atts['text'] ) ) {
				$output .= '<p' . $textStyle . '>' . esc_attr( $atts['text'] ) . '</p>';
			}
		$output .= '</div></div>';
	}

	return $output;
}
add_shortcode("contentwidgettitle", "content_widget_title_shortcode");

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Content Widget Title", 'eventstation'),
		"base" => "contentwidgettitle",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/content_widget_title.png',
		"description" =>esc_html__( 'Content widget title widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style",'eventstation'),
				"description" => esc_html__("You can select the design style.",'eventstation'),
				"param_name" => "style",
				"value" => array(
					esc_html__("Big", 'eventstation') => "big",
					esc_html__("Small", 'eventstation') => "small"
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title",'eventstation'),
				"description" => esc_html__("You can enter the title.",'eventstation'),
				"param_name" => "title",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Text",'eventstation'),
				"description" => esc_html__("You can enter the text.",'eventstation'),
				"param_name" => "text",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Icon",'eventstation'),
				"description" => esc_html__("You can enter the icon name. List of the icons is available in the documentation file. Example: edge, automobile, bel-o.", 'eventstation'),
				"param_name" => "icon",
				"value" => "",
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Separator",'eventstation'),
				"description" => esc_html__("You can select the separate status.",'eventstation'),
				"param_name" => "separator",
				"value" => array(
					esc_html__("True", 'eventstation') => "true",
					esc_html__("False", 'eventstation') => "false",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Title Font Size",'eventstation'),
				"description" => esc_html__("You can enter the title font size. Example: 15px.", 'eventstation'),
				"param_name" => "titlefontsize",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Text Font Size",'eventstation'),
				"description" => esc_html__("You can enter the text font size. Example: 15px.", 'eventstation'),
				"param_name" => "textfontsize",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Title Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "titlecolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Text Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "textcolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Separator Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "separatorcolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Background",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconbackground",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconcolor",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}
/*------------- CONTENT WIDGET TITLE END -------------*/

/*------------- CLIENTS START -------------*/
function eventstation_clients_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'style' => '',
			'loop' => '',
			'customclass' => ''
		), $atts
	);
	
	$output = '';
		
		if( !empty( $atts['style'] ) ) {
			$columnMargin = "80";
		} else {
			$columnMargin = "70";
		}

		if( $atts['loop'] == "false" ) {
			$loop = "false";
		} else {
			$loop = "true";
		}

		if( !empty( $atts['customclass'] ) ) {
			$customClass = ' ' . esc_attr( $atts['customclass'] );
		} else {
			$customClass = "";
		}
		
		$random_id = rand( 0, 99999999 );
		
		$output .= '<div class="clients-widget' . esc_attr( $customClass ) . '">';
			$output .= '<div class="owl-carousel-clients-' . esc_attr( $random_id ) . '">';
				$output .= do_shortcode( $content );
			$output .= '</div>';
		$output .= '</div>';
		
		$output .= "<script>
							jQuery(document).ready(function($){
								$('.owl-carousel-clients-" . esc_attr( $random_id ) . "').owlCarousel({
									loop:" . esc_attr( $loop ) . ",
									nav:false,
									margin:" . esc_attr( $columnMargin ) . ",
									dots:false,
									autoWidth:true,
									responsive:{
										0:{
											items:2,
										},
										768:{
											items:7,
										},
									}
								});
							});
						</script>";
			

	return $output;
}
add_shortcode("eventstation_clients", "eventstation_clients_shortcode");

function client_logo_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'clientimage' => '',
			'clientlink' => ''
		), $atts
	);
	
	$output = '';
	
	if( !empty( $atts['clientimage'] ) ) {
		$image = wp_get_attachment_image_src( $atts["clientimage"], "full" );
		$output .= '<div class="item">';
			$output .= '<a href="' . esc_url( $atts['clientlink'] ) . '" title="' . esc_html__( 'Client','eventstation' ) . '" ><img src="' . esc_url( $image[0] ) . '" alt="' . esc_html__( 'Client','eventstation' ) . '" /></a>';
		$output .= '</div>';
	}

	return $output;
}
add_shortcode("client_logo", "client_logo_shortcode");

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__( "Clients", 'eventstation' ),
		"base" => "eventstation_clients",
		"class" => "",
		"as_parent" => array('only' => 'client_logo'),
		"js_view" => 'VcColumnView',
		"content_element" => true,
		"category" => esc_html__( "Event Station Theme", 'eventstation' ),
		"icon" => get_template_directory_uri().'/assets/img/icons/client_logo.png',
		"description" =>esc_html__( 'Clients widget.','eventstation' ),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style",'eventstation'),
				"description" => esc_html__("You can select the design style.",'eventstation'),
				"param_name" => "style",
				"value" => array(
					esc_html__("Default", 'eventstation') => "default",
					esc_html__("Alternative", 'eventstation') => "alternative",
				)
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Loop",'eventstation'),
				"description" => esc_html__("You can select the loop status.",'eventstation'),
				"param_name" => "loop",
				"value" => array(
					esc_html__("True", 'eventstation') => "true",
					esc_html__("False", 'eventstation') => "false",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Custom Extra Class Name",'eventstation' ),
				"description" => esc_html__( "You can enter the custom class.",'eventstation' ),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__( "Client Logo", 'eventstation' ),
		"base" => "client_logo",
		"class" => "",
		"as_child" => array( 'only' => 'eventstation_clients' ),
		"content_element" => true,
		"category" => esc_html__( "Event Station Theme", 'eventstation' ),
		"icon" => get_template_directory_uri().'/assets/img/icons/client_logo.png',
		"description" =>esc_html__( 'Client logo widget.','eventstation' ),
		"params" => array(
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__( "Client Image",'eventstation' ),
				"description" => esc_html__( "You can the upload your client logo.", 'eventstation' ),
				"param_name" => "clientimage",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( "Client Link",'eventstation' ),
				"description" => esc_html__( "You can enter the client link.", 'eventstation' ),
				"param_name" => "clientlink",
				"value" => "",
			),
		)
	) );
}

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_eventstation_clients extends WPBakeryShortCodesContainer {}
}
/*------------- CLIENTS END -------------*/

/*------------- MAILCHIMP START -------------*/
function eventstationnewsletter_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'formid' => '',
			'customclass' => ''
		), $atts
	);

	if( !empty( $atts['customclass'] ) ) {
		$customClass = ' ' . esc_attr( $atts['customclass'] );
	} else {
		$customClass = "";
	}
	
	$output = '';
	
		if( !empty( $atts['formid'] ) ) {
			$formid = '<div class="eventstation-mailchmip' . $customClass . '">[mc4wp_form id="' . esc_attr( $atts['formid'] ) . '"]</div>';
			$output .= do_shortcode( $formid );
		}
		
	return $output;
	
}
add_shortcode("eventstationnewsletter", "eventstationnewsletter_shortcode");

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("MailChimp Newsletter", 'eventstation'),
		"base" => "eventstationnewsletter",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/mailchimp.png',
		"description" =>esc_html__( 'MailChimp newsletter widget.','eventstation'),
		"params" => array(
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Form ID",'eventstation'),
				"description" => esc_html__("You can enter the form id of MailChimp Newsletter.", 'eventstation'),
				"param_name" => "formid",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}
/*------------- MAILCHIMP END -------------*/

/*------------- SOCIAL MEDIA START -------------*/
function socialmedia_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'style' => '',
			'customclass' => ''
		), $atts
	);

	if( !empty( $atts['customclass'] ) ) {
		$customClass = ' ' . esc_attr( $atts['customclass'] );
	} else {
		$customClass = "";
	}
	
	$output = '';
	
		if( $atts['style'] == "white" ) {
			$style = "white";
		}
		else {
			$style = "default";
		}
	
		$output .='<div class="social-media-widget social-media-' . esc_attr ( $style ) . $customClass . '">';
			$output .='<ul>';
				if( !ot_get_option( 'social_media_facebook' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_facebook' ) . '" title="' . esc_html__( 'Facebook', 'eventstation' ) . '" target="_blank"><i class="fa fa-facebook"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_twitter' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_twitter' ) . '" title="' . esc_html__( 'Twitter', 'eventstation' ) . '" target="_blank"><i class="fa fa-twitter"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_googleplus' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_googleplus' ) . '" title="' . esc_html__( 'Google+', 'eventstation' ) . '" target="_blank"><i class="fa fa-google-plus"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_instagram' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_instagram' ) . '" title="' . esc_html__( 'Instagram', 'eventstation' ) . '" target="_blank"><i class="fa fa-instagram"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_linkedin' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_linkedin' ) . '" title="' . esc_html__( 'Linkedin', 'eventstation' ) . '" target="_blank"><i class="fa fa-linkedin"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_vine' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_vine' ) . '" title="' . esc_html__( 'Vine', 'eventstation' ) . '" target="_blank"><i class="fa fa-vine"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_youtube' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_youtube' ) . '" title="' . esc_html__( 'YouTube', 'eventstation' ) . '" target="_blank"><i class="fa fa-youtube"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_pinterest' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_pinterest' ) . '" title="' . esc_html__( 'Pinterest', 'eventstation' ) . '" target="_blank"><i class="fa fa-pinterest"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_behance' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_behance' ) . '" title="' . esc_html__( 'Behance', 'eventstation' ) . '" target="_blank"><i class="fa fa-behance"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_deviantart' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_deviantart' ) . '" title="' . esc_html__( 'Deviantart', 'eventstation' ) . '" target="_blank"><i class="fa fa-deviantart"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_digg' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_digg' ) . '" title="' . esc_html__( 'Digg', 'eventstation' ) . '" target="_blank"><i class="fa fa-digg"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_dribbble' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_dribbble' ) . '" title="' . esc_html__( 'Dribbble', 'eventstation' ) . '" target="_blank"><i class="fa fa-dribbble"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_flickr' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_flickr' ) . '" title="' . esc_html__( 'Flickr', 'eventstation' ) . '" target="_blank"><i class="fa fa-flickr"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_github' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_github' ) . '" title="' . esc_html__( 'GitHub', 'eventstation' ) . '" target="_blank"><i class="fa fa-github"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_lastfm' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_lastfm' ) . '" title="' . esc_html__( 'Last.fm', 'eventstation' ) . '" target="_blank"><i class="fa fa-lastfm"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_reddit' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_reddit' ) . '" title="' . esc_html__( 'Reddit', 'eventstation' ) . '" target="_blank"><i class="fa fa-reddit"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_soundcloud' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_soundcloud' ) . '" title="' . esc_html__( 'SoundCloud', 'eventstation' ) . '" target="_blank"><i class="fa fa-soundcloud"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_tumblr' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_tumblr' ) . '" title="' . esc_html__( 'Tumblr', 'eventstation' ) . '" target="_blank"><i class="fa fa-tumblr"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_vimeo' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_vimeo' ) . '" title="' . esc_html__( 'Vimeo', 'eventstation' ) . '" target="_blank"><i class="fa fa-vimeo"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_vk' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_vk' ) . '" title="' . esc_html__( 'VK', 'eventstation' ) . '" target="_blank"><i class="fa fa-vk"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_medium' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_medium' ) . '" title="' . esc_html__( 'Medium', 'eventstation' ) . '" target="_blank"><i class="fa fa-medium"></i></a></li>';
				endif;

				if( !ot_get_option( 'social_media_rss' ) == ""  ) :
					$output .='<li><a href="' . ot_get_option( 'social_media_rss' ) . '" title="' . esc_html__( 'RSS', 'eventstation' ) . '" target="_blank"><i class="fa fa-rss"></i></a></li>';
				endif;
			$output .='</ul>';
		$output .='</div>';
		
	return $output;
	
}
add_shortcode("socialmedia", "socialmedia_shortcode");

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Social Media", 'eventstation'),
		"base" => "socialmedia",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/social_media.png',
		"description" =>esc_html__( 'Social media widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style",'eventstation'),
				"description" => esc_html__("You can select the design style.",'eventstation'),
				"param_name" => "style",
				"value" => array(
					esc_html__("Default", 'eventstation') => "default",
					esc_html__("White", 'eventstation') => "white",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}
/*------------- SOCIAL MEDIA END -------------*/

/*------------- 3D TOUR START -------------*/
function map3dtour_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'container' => '',
			'bgimage' => '',
			'title' => '',
			'text' => '',
			'icon' => '',
			'buttontext' => '',
			'apikey' => '',
			'location' => '',
			'mapheight' => '',
			'pitch' => '',
			'heading' => '',
			'fov' => '',
			'music' => '',
			'titlefontsize' => '',
			'textfontsize' => '',
			'titlecolor' => '',
			'textcolor' => '',
			'iconbackground' => '',
			'iconcolor' => '',
			'customclass' => ''
		), $atts
	);
	
	$output = '';
	
	$allowed_html = array ( 'br' => array() );
	
	if( !empty( $atts['iconcolor'] ) ) {
		$iconcolor = 'color:' . esc_attr( $atts['iconcolor'] ) . ';';
	}
	else {
		$iconcolor ="";
	}

	if( !empty( $atts['iconbackground'] ) ) {
		$iconbackground = 'background:' . esc_attr( $atts['iconbackground'] ) . ';';
	}
	else {
		$iconbackground ="";
	}
	
	if( !empty( $atts['iconcolor'] ) or !empty( $atts['iconbackground'] ) ) {
		$iconStyle = ' style="' . $iconcolor . $iconbackground . '"';
	} else {
		$iconStyle = "";
	}
	
	if( !empty( $atts['titlecolor'] ) ) {
		$titlecolor = 'color:' . esc_attr( $atts['titlecolor'] ) . ';';
	}
	else {
		$titlecolor ="";
	}

	if( !empty( $atts['titlefontsize'] ) ) {
		$titlefontsize = 'font-size:' . esc_attr( $atts['titlefontsize'] ) . ';';
	}
	else {
		$titlefontsize ="";
	}
	
	if( !empty( $atts['titlecolor'] ) or !empty( $atts['titlefontsize'] ) ) {
		$titleStyle = ' style="' . $titlecolor . $titlefontsize . '"';
	} else {
		$titleStyle = "";
	}
	
	if( !empty( $atts['textcolor'] ) ) {
		$textcolor = 'color:' . esc_attr( $atts['textcolor'] ) . ';';
	}
	else {
		$textcolor ="";
	}

	if( !empty( $atts['textfontsize'] ) ) {
		$textfontsize = 'font-size:' . esc_attr( $atts['textfontsize'] ) . ';';
	}
	else {
		$textfontsize ="";
	}
	
	if( !empty( $atts['textcolor'] ) or !empty( $atts['textfontsize'] ) ) {
		$textStyle = ' style="' . $textcolor . $textfontsize . '"';
	} else {
		$textStyle = "";
	}

	if( !empty( $atts['bgimage'] ) ) {
		$background_url = wp_get_attachment_image_src($atts["bgimage"], "full");
		$background = ' style="background-image:url(' . $background_url[0] . ');"';
	}
	else {
		$background = "";
	}

	if( !empty( $atts['apikey'] ) ) {
		$apikey = '&key=' . esc_attr( $atts['apikey'] );
	} else {
		$apikey = '&key=AIzaSyCQ25_pI7p53Hkr0Y7UG-VSy687PtjxWzA';
	}

	if( !empty( $atts['location'] ) ) {
		$location = '?location=' . esc_attr( $atts['location'] );
	} else {
		$location = "?location=42.762321,-83.2835739";
	}

	if( !empty( $atts['mapheight'] ) ) {
		$mapheight = '&key=' . esc_attr( $atts['mapheight'] );
	} else {
		$mapheight = "";
	}
	
	if( !empty( $atts['heading'] ) ) {
		$heading = '&heading=' . esc_attr( $atts['heading'] );
	} else {
		$heading = "";
	}

	if( !empty( $atts['fov'] ) ) {
		$fov = '&fov=' . esc_attr( $atts['fov'] );
	} else {
		$fov = "";
	}

	if( !empty( $atts['pitch'] ) ) {
		$pitch = '&pitch=' . esc_attr( $atts['pitch'] );
	} else {
		$pitch = "";
	}

	if( !empty( $atts['music'] ) ) {
		$music = '<div class="map-3d-tour-music-button map3dTourMusicButton">';
			$music .= '<i class="fa fa-play"></i>';
			$music .= '<audio id="map-3d-tour-playTune"><source src="' . esc_url( $atts['music'] ) . '"></audio>';
		$music .= '</div>';
	} else {
		$music = "";
	}

	if( !empty( $atts['customclass'] ) ) {
		$customClass = ' ' . esc_attr( $atts['customclass'] );
	} else {
		$customClass = "";
	}
	
	$iframe_url = $location . $apikey . $heading . $fov . $pitch;
	$output .= '<div class="map-3d-tour' . $customClass . '">';
		$output .= '<div class="map-3d-tour-content"' . $background . '>';
			if( $atts["container"] == "true" ) {
				$output .= '<div class="container">';
			}
				if( !empty( $atts['icon'] ) ) {
					$output .= '<i class="map-3d-tour-icon fa fa-' . esc_attr( $atts['icon'] ) . '"' . $iconStyle . '></i>';
				}
				
				if( !empty( $atts['title'] ) ) {
					$output .= '<h3' . $titleStyle . ' class="animate anim-fadeIn">' . wp_kses( $atts['title'] , $allowed_html ) . '</h3>';
				}
				
				if( !empty( $atts['text'] ) ) {
					$output .= '<p' . $textStyle . ' class="animate anim-fadeIn">' . wp_kses( $atts['text'] , $allowed_html ) . '</p>';
				}
				
				if( !empty( $atts['buttontext'] ) ) {
					$output .= '<div class="map-3d-tour-button animate anim-fadeIn"><span>' . esc_attr( $atts['buttontext'] ) . '</span><i class="fa fa-angle-right"></i></div>';
				}
			if( $atts["container"] == "true" ) {
				$output .= '</div>';
			}
		$output .= '</div>';
		$output .= '<div class="map-3d-tour-iframe">';
			$output .= '<i class="close fa fa-times"></i>';
			$output .= $music;
			$output .= '<iframe style="border:0" src="https://www.google.com/maps/embed/v1/streetview' . $iframe_url . '"></iframe>';
		$output .= '</div>';
	$output .= '</div>';
		
	return $output;
	
}
add_shortcode("map3dtour", "map3dtour_shortcode");

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("3D Tour", 'eventstation'),
		"base" => "map3dtour",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/3d-tour.png',
		"description" =>esc_html__( '3D map tour widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Container",'eventstation'),
				"description" => esc_html__("You can select the status of the container.",'eventstation'),
				"param_name" => "container",
				"value" => array(
					esc_html__("False", 'eventstation') => "false",
					esc_html__("True", 'eventstation') => "true",
				)
			),
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__("Background Image",'eventstation'),
				"description" => esc_html__("You can the upload your background image.", 'eventstation'),
				"param_name" => "bgimage",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title",'eventstation'),
				"description" => esc_html__("You can enter the title.",'eventstation'),
				"param_name" => "title",
				"value" => "",
			),
			array(
				"type" => "textarea",
				"class" => "",
				"heading" => esc_html__("Text",'eventstation'),
				"description" => esc_html__("You can enter the text.",'eventstation'),
				"param_name" => "text",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Icon",'eventstation'),
				"description" => esc_html__("You can enter the icon name. List of the icons is available in the documentation file. Example: edge, automobile, bel-o.", 'eventstation'),
				"param_name" => "icon",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Button Text",'eventstation'),
				"description" => esc_html__("You can enter the button text.",'eventstation'),
				"param_name" => "buttontext",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Google Street View Api Key",'eventstation'),
				"description" => esc_html__("You can enter the Google Street view api key. Code generation page: https://goo.gl/9glphK", 'eventstation'),
				"param_name" => "apikey",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Location",'eventstation'),
				"description" => esc_html__("You can enter the map location. Example location: 42.762321,-83.2835739.", 'eventstation'),
				"param_name" => "location",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Map Height",'eventstation'),
				"description" => esc_html__("You can enter the map height. Default: 600px.", 'eventstation'),
				"param_name" => "mapheight",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Pitch (Optional)",'eventstation'),
				"description" => esc_html__("Pitch specifies the angle, up or down, of the camera. The pitch is specified in degrees from -90° to 90°. Positive values will angle the camera up, while negative values will angle the camera down. The default pitch of 0° is set based on on the position of the camera when the image was captured. Because of this, a pitch of 0° is often, but not always, horizontal. For example, an image taken on a hill will likely exhibit a default pitch that is not horizontal.", 'eventstation'),
				"param_name" => "pitch",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Heading (Optional)",'eventstation'),
				"description" => esc_html__("Heading indicates the compass heading of the camera in degrees clockwise from North. Accepted values are from -180° to 360°.", 'eventstation'),
				"param_name" => "heading",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Fav (Optional)",'eventstation'),
				"description" => esc_html__("Fov determines the horizontal field of view of the image. The field of view is expressed in degrees, with a range of 10° - 100°. It defaults to 90°. When dealing with a fixed-size viewport the field of view is can be considered the zoom level, with smaller numbers indicating a higher level of zoom.", 'eventstation'),
				"param_name" => "fov",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Music (Optional)",'eventstation'),
				"description" => esc_html__( "You can the upload your sound.", 'eventstation' ),
				"param_name" => "music",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Title Font Size",'eventstation'),
				"description" => esc_html__("You can enter the title font size. Example: 15px.", 'eventstation'),
				"param_name" => "titlefontsize",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Text Font Size",'eventstation'),
				"description" => esc_html__("You can enter the text font size. Example: 15px.", 'eventstation'),
				"param_name" => "textfontsize",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Title Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "titlecolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Text Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "textcolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Background",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconbackground",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconcolor",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}
/*------------- 3D TOUR END -------------*/

/*------------- PRICING TABLE START -------------*/
function eventstation_pricing_table_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'style' => '',
			'packagename' => '',
			'text' => '',
			'price' => '',
			'currency' => '',
			'banner' => '',
			'star' => '',
			'buttontext' => '',
			'buttonlink' => '',
			'productid' => '',
			'pricefontsize' => '',
			'packagenamefontsize' => '',
			'packagetextfontsize' => '',
			'customclass' => ''
		), $atts
	);
	
	$output = '';
	
		if( !empty( $atts['star'] ) ) {
			
			if( $atts['star'] == "1" ) {
				$star = '<div class="price-table-star">';
					$star .= '<i class="fa fa-star"></i>';
				$star .= '</div>';
			}
			
			elseif( $atts['star'] == "2" ) {
				$star = '<div class="price-table-star">';
					$star .= '<i class="fa fa-star"></i>';
					$star .= '<i class="fa fa-star"></i>';
				$star .= '</div>';
			}
			
			elseif( $atts['star'] == "3" ) {
				$star = '<div class="price-table-star">';
					$star .= '<i class="fa fa-star"></i>';
					$star .= '<i class="fa fa-star"></i>';
					$star .= '<i class="fa fa-star"></i>';
				$star .= '</div>';
			}
			
			elseif( $atts['star'] == "4" ) {
				$star = '<div class="price-table-star">';
					$star .= '<i class="fa fa-star"></i>';
					$star .= '<i class="fa fa-star"></i>';
					$star .= '<i class="fa fa-star"></i>';
					$star .= '<i class="fa fa-star"></i>';
				$star .= '</div>';
			}
			
			elseif( $atts['star'] == "5") {
				$star = '<div class="price-table-star">';
					$star .= '<i class="fa fa-star"></i>';
					$star .= '<i class="fa fa-star"></i>';
					$star .= '<i class="fa fa-star"></i>';
					$star .= '<i class="fa fa-star"></i>';
					$star .= '<i class="fa fa-star"></i>';
				$star .= '</div>';
			}
			
			else {
				$star = '';
			}
			
		} else {
			$star = '';
		}
		
		if( !empty( $atts['banner'] ) ) {
			$banner_url = wp_get_attachment_image_src($atts["banner"], "full");
			$banner = ' style="background-image:url(' . $banner_url[0] . ');"';
		} else {
			$banner_url = "";
			$banner = "";
		}

		if( !empty( $atts['pricefontsize'] ) ) {
			$pricefontsize = 'font-size:' . esc_attr( $atts['pricefontsize'] ) . ';';
		}
		else {
			$pricefontsize ="";
		}
		
		if( !empty( $atts['pricefontsize'] ) ) {
			$priceStyle = ' style="' . $pricefontsize . '"';
		} else {
			$priceStyle = "";
		}

		if( !empty( $atts['packagenamefontsize'] ) ) {
			$packagenamefontsize = 'font-size:' . esc_attr( $atts['packagenamefontsize'] ) . ';';
		}
		else {
			$packagenamefontsize ="";
		}
		
		if( !empty( $atts['packagenamefontsize'] ) ) {
			$packageNameStyle = ' style="' . $packagenamefontsize . '"';
		} else {
			$packageNameStyle = "";
		}

		if( !empty( $atts['packagetextfontsize'] ) ) {
			$packagetextfontsize = 'font-size:' . esc_attr( $atts['packagetextfontsize'] ) . ';';
		}
		else {
			$packagetextfontsize ="";
		}
		
		if( !empty( $atts['packagetextfontsize'] ) ) {
			$packageTextStyle = ' style="' . $packagetextfontsize . '"';
		} else {
			$packageTextStyle = "";
		}

		if( !empty( $atts['customclass'] ) ) {
			$customClass = ' ' . esc_attr( $atts['customclass'] );
		} else {
			$customClass = "";
		}
	
		if( !empty( $atts['price'] ) or !empty( $atts['packagename'] ) ) {
			
			/* STYLE CLASSIC START */
			if( $atts['style'] == "classic" ) {
				$output .= '<div class="pricing-table pricing-table-classic' . $customClass . '">';
					$output .= '<div class="pricing-table-header-wrapper"><div class="pricing-table-header">';
							if( !empty( $atts['price'] ) ) {
								$output .= '<div class="pricing-table-price"' . $priceStyle . '>';
									if( !empty( $atts['currency'] ) ) {
										$output .= '<span>' . esc_attr( $atts['currency'] ) . '</span>';
									}
									$output .= esc_attr( $atts['price'] );
								$output .= '</div>';
							}
							if( !empty( $atts['price'] ) and !empty( $atts['packagename'] ) ) {
								$output .= '<div class="separator"></div>';
							}
							if( !empty( $atts['packagename'] ) ) {
								$output .= '<div class="pricing-table-packagename"' . $packageNameStyle . '>' . esc_attr( $atts['packagename'] ) . '</div>';
							}
					$output .= '</div></div>';
					
					if( !empty( $content ) ) {
						$output .= '<div class="pricing-table-body"><ul>';
							$output .= do_shortcode( $content );
						$output .= '</ul></div>';
					}
					
					if( !empty( $atts['buttontext'] ) ) {
						
						if( !empty( $atts['productid'] ) ) {
							$package_link = '?add-to-cart=' . esc_attr( $atts['productid'] );
						} else {
							$package_link = esc_url( $atts['buttonlink'] );
						}
						
						if( !empty( $atts['productid'] ) ) {
							$package_icon = '<i class="fa fa-shopping-cart" aria-hidden="true"></i>';
						} else {
							$package_icon = '<i>&gt;</i>';
						}
						
						$output .= '<div class="pricing-table-bottom">';
							$output .= '<div class="pricing-table-button"><a href="' . $package_link . '" title="' . esc_attr( $atts['buttontext'] ) . '">' . $package_icon . '<div class="separator"></div><span>' . esc_attr( $atts['buttontext'] ) . '</span></a></div>';
						$output .= '</div>';
					}
				
				$output .= '</div>';
			}
			/* STYLE CLASSIC END */
			
			/* STYLE MODERN START */
			else {
				$output .= '<div class="pricing-table pricing-table-modern' . $customClass . '">';
					$output .= '<div class="pricing-table-header animate anim-fadeInUp"' . $banner . '>';
						$output .= '<div class="pricing-table-header-left">';
							$output .= '<div class="pricing-table-header-left-wrapper">';
								$output .= $star;
								if( !empty( $atts['price'] ) ) {
									$output .= '<div class="pricing-table-price"' . $priceStyle . '>';
										if( !empty( $atts['currency'] ) ) {
											$output .= '<span>' . esc_attr( $atts['currency'] ) . '</span>';
										}
										$output .= esc_attr( $atts['price'] );
									$output .= '</div>';
								}
							$output .= '</div>';
						$output .= '</div>';
						$output .= '<div class="pricing-table-header-right">';
							if( !empty( $atts['packagename'] ) ) {
								$output .= '<div class="pricing-table-packagename"' . $packageNameStyle . '>' . esc_attr( $atts['packagename'] ) . '</div>';
							}
							if( !empty( $atts['text'] ) ) {
								$output .= '<div class="pricing-table-text"' . $packageTextStyle . '>' . esc_attr( $atts['text'] ) . '</div>';
							}
						$output .= '</div>';
					$output .= '</div>';
					
					if( !empty( $content ) ) {
						$output .= '<div class="pricing-table-body animate anim-fadeInUp"><ul>';
							$output .= do_shortcode( $content );
						$output .= '</ul></div>';
					}
					
					if( !empty( $atts['buttontext'] ) ) {
						
						if( !empty( $atts['productid'] ) ) {
							$package_link = '?add-to-cart=' . esc_attr( $atts['productid'] );
						} else {
							$package_link = esc_url( $atts['buttonlink'] );
						}
						
						if( !empty( $atts['productid'] ) ) {
							$package_icon = '<i class="fa fa-shopping-cart" aria-hidden="true"></i>';
						} else {
							$package_icon = '<i>&gt;</i>';
						}
						
						$output .= '<div class="pricing-table-bottom">';
							$output .= '<div class="pricing-table-button"><a href="' . $package_link . '" title="' . esc_attr( $atts['buttontext'] ) . '"><span>' . esc_attr( $atts['buttontext'] ) . '</span>' . $package_icon . '</a></div>';
						$output .= '</div>';
					}
				
				$output .= '</div>';
			}
			/* STYLE MODERN END */
		}
	

	return $output;
}
add_shortcode("eventstation_pricing_table", "eventstation_pricing_table_shortcode");

function eventstation_pricing_list_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'icon' => '',
			'text' => ''
		), $atts
	);
	
	$output = '';
	
		if( !empty( $atts['icon'] ) or !empty( $atts['text'] ) ) {
			
				$output .= '<li>';
				
					$output .= '<div class="pricing-list-icon">';
						if( $atts['icon'] == "false" ) {
							$output .= '<i class="fa fa-times no"></i>';
						}
						else {									
							$output .= '<i class="fa fa-check yes"></i>';
						}
					$output .= '</div>';
							
					if( !empty( $atts['text'] ) ) {
							$output .= '<div class="pricing-list-text">';
								$output .= esc_attr( $atts['text'] );
							$output .= '</div>';
					}
				
				$output .= '</li>';
		}

	return $output;
}
add_shortcode("eventstation_pricing_list", "eventstation_pricing_list_shortcode");

function image_price_style( $settings, $value ) {
	return '<div class="my_param_block">'
	.'<input name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput ' .
	esc_attr( $settings['param_name'] ) . ' ' .
	esc_attr( $settings['type'] ) . '_field" type="hidden" value="' . esc_attr( $value ) . '" />
	<img src="'.esc_attr( $value ).'">'.
	'</div>';
}
vc_add_shortcode_param( 'price_style', 'image_price_style' );

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Pricing Table", 'eventstation'),
		"base" => "eventstation_pricing_table",
		"class" => "",
		"as_parent" => array('only' => 'eventstation_pricing_list'),
		"js_view" => 'VcColumnView',
		"content_element" => true,
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/pricing_table.png',
		"description" =>esc_html__( 'Pricing table widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style",'eventstation'),
				"description" => esc_html__("You can select the design style.",'eventstation'),
				"param_name" => "style",
				"value" => array(
					esc_html__("Modern", 'eventstation') => "modern",
					esc_html__("Classic", 'eventstation') => "classic",
				)
			),
			array(
				'type'	=> 'price_style',
				'heading'	=> '',
				'param_name'	=> 'pricestyleone',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/price-1.jpg',
				'dependency' => array('element' => "style", 'value' => array('classic'))			
			),
			array(
				'type'	=> 'price_style',
				'heading'	=> '',
				'param_name'	=> 'pricestyletwo',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/price-2.jpg',
				'dependency' => array('element' => "style", 'value' => array('modern'))			
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Package Name",'eventstation'),
				"description" => esc_html__("You can enter the package name.", 'eventstation'),
				"param_name" => "packagename",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Text",'eventstation'),
				"description" => esc_html__("You can enter the package text.", 'eventstation'),
				"param_name" => "text",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Price",'eventstation'),
				"description" => esc_html__("You can enter the package price. Example: 49", 'eventstation'),
				"param_name" => "price",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Currency",'eventstation'),
				"description" => esc_html__("You can enter the currency. Example: $, €", 'eventstation'),
				"param_name" => "currency",
				"value" => "",
			),
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__("Banner",'eventstation'),
				"description" => esc_html__( "You can the upload your package banner.", 'eventstation' ),
				"param_name" => "banner",
				"value" => "",
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Star",'eventstation'),
				"description" => esc_html__("You can select the icon type.",'eventstation'),
				"param_name" => "star",
				"value" => array(
					esc_html__("None", 'eventstation') => "none",
					esc_html__("One", 'eventstation') => "1",
					esc_html__("Two", 'eventstation') => "2",
					esc_html__("Three", 'eventstation') => "3",
					esc_html__("Four", 'eventstation') => "4",
					esc_html__("Five", 'eventstation') => "5",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Button Text",'eventstation'),
				"description" => esc_html__("You can enter the button title.", 'eventstation'),
				"param_name" => "buttontext",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Button Link",'eventstation'),
				"description" => esc_html__("You can enter the button link.", 'eventstation'),
				"param_name" => "buttonlink",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Product ID",'eventstation'),
				"description" => esc_html__("You can enter the WooCommerce product id. How to learn WooCommerce product id?: https://goo.gl/DEJ5fU", 'eventstation'),
				"param_name" => "productid",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Price Font Size",'eventstation'),
				"description" => esc_html__("You can enter the title font size. Example: 15px.", 'eventstation'),
				"param_name" => "pricefontsize",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Package Name Font Size",'eventstation'),
				"description" => esc_html__("You can enter the title font size. Example: 15px.", 'eventstation'),
				"param_name" => "packagenamefontsize",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Package Text Font Size",'eventstation'),
				"description" => esc_html__("You can enter the title font size. Example: 15px.", 'eventstation'),
				"param_name" => "packagetextfontsize",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Pricing List", 'eventstation'),
		"base" => "eventstation_pricing_list",
		"class" => "",
		"as_child" => array( 'only' => 'eventstation_pricing_table' ),
		"content_element" => true,
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/pricing_list.png',
		"description" =>esc_html__( 'Pricing list widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Icon",'eventstation'),
				"description" => esc_html__("You can select the icon type.",'eventstation'),
				"param_name" => "icon",
				"value" => array(
					esc_html__("True", 'eventstation') => "true",
					esc_html__("False", 'eventstation') => "false",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Text",'eventstation'),
				"description" => esc_html__("You can enter the list text.", 'eventstation'),
				"param_name" => "text",
				"value" => "",
			)
		)
	) );
}

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_eventstation_pricing_table extends WPBakeryShortCodesContainer {}
}
/*------------- PRICING TABLE END -------------*/

/*------------- SPEAKERS START START -------------*/
function speakers_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'column' => '',
			'style' => '',
			'dot' => '',
			'customclass' => ''
		), $atts
	);
	
	$output = '';

	if( !empty( $atts['customclass'] ) ) {
		$customClass = ' ' . esc_attr( $atts['customclass'] );
	} else {
		$customClass = "";
	}
	
	if( !empty( $atts['column'] ) ) {
		$column = esc_attr( $atts['column'] );
	} else {
		$column = "4";
	}
	
	if( !empty( $atts['style'] ) ) {
		$style = " " . esc_attr( $atts['style'] );
	} else {
		$style = "";
	}
	
	if( !empty( $atts['style'] ) ) {
		$columnMargin = "15";
	} else {
		$columnMargin = "45";
	}
		
	$random_id = rand( 0, 99999999 );
	$random_id = $column * $random_id;
		
	
	$output .= '<div class="speakers-widget speakers-widget-' . $random_id . $style . $customClass . '">';
		$output .= do_shortcode( $content );
	$output .= '</div>';
		
	$output .= "<script>
						jQuery(document).ready(function($){
							$('.speakers-widget-" . esc_attr( $random_id ) . "').owlCarousel({
								loop:true,
								nav:false,
								margin:" . esc_attr( $columnMargin ) . ",
								dots:true,
								responsive:{
									0:{
										items:1,
									},
									768:{
										items:2,
									},
									1000:{
										items:3,
									},
									1300:{
										items:" . esc_attr( $column ) .",
									},
								}
							});
						});
					</script>";

	return $output;
}
add_shortcode("speakers", "speakers_shortcode");

function speakers_item_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'image' => '',
			'name' => '',
			'job' => '',
			'date' => '',
			'hour' => '',
			'hall' => '',
			'topic' => '',
			'sociallink1' => '',
			'sociallink1url' => '',
			'sociallink2' => '',
			'sociallink2url' => '',
			'sociallink3' => '',
			'sociallink3url' => '',
			'sociallink4' => '',
			'sociallink4url' => '',
			'sociallink5' => '',
			'sociallink5url' => '',
			'sociallink6' => '',
			'sociallink6url' => '',
			'namefontsize' => '',
			'jobfontsize' => '',
			'topicfontsize' => '',
			'infofontsize' => '',
			'namecolor' => '',
			'jobcolor' => '',
			'infocolor' => '',
			'topiccolor' => '',
		), $atts
	);
	
	$output = '';
	
	if( !empty( $atts['namecolor'] ) ) {
		$namecolor = 'color:' . esc_attr( $atts['namecolor'] ) . ';';
	}
	else {
		$namecolor ="";
	}

	if( !empty( $atts['namefontsize'] ) ) {
		$namefontsize = 'font-size:' . esc_attr( $atts['namefontsize'] ) . ';';
	}
	else {
		$namefontsize ="";
	}
	
	if( !empty( $atts['namecolor'] ) or !empty( $atts['namefontsize'] ) ) {
		$nameStyle = ' style="' . $namecolor . $namefontsize . '"';
	} else {
		$nameStyle = "";
	}
	
	if( !empty( $atts['jobcolor'] ) ) {
		$jobcolor = 'color:' . esc_attr( $atts['jobcolor'] ) . ';';
	}
	else {
		$jobcolor ="";
	}

	if( !empty( $atts['jobfontsize'] ) ) {
		$jobfontsize = 'font-size:' . esc_attr( $atts['jobfontsize'] ) . ';';
	}
	else {
		$jobfontsize ="";
	}
	
	if( !empty( $atts['jobcolor'] ) or !empty( $atts['jobfontsize'] ) ) {
		$jobStyle = ' style="' . $jobcolor . $jobfontsize . '"';
	} else {
		$jobStyle = "";
	}
	
	if( !empty( $atts['infocolor'] ) ) {
		$infocolor = 'color:' . esc_attr( $atts['infocolor'] ) . ';';
	}
	else {
		$infocolor ="";
	}

	if( !empty( $atts['infofontsize'] ) ) {
		$infofontsize = 'font-size:' . esc_attr( $atts['infofontsize'] ) . ';';
	}
	else {
		$infofontsize ="";
	}
	
	if( !empty( $atts['infocolor'] ) or !empty( $atts['infofontsize'] ) ) {
		$infoStyle = ' style="' . $infocolor . $infofontsize . '"';
	} else {
		$infoStyle = "";
	}
	
	if( !empty( $atts['topiccolor'] ) ) {
		$topiccolor = 'color:' . esc_attr( $atts['topiccolor'] ) . ';';
	}
	else {
		$topiccolor ="";
	}

	if( !empty( $atts['topicfontsize'] ) ) {
		$topicfontsize = 'font-size:' . esc_attr( $atts['topicfontsize'] ) . ';';
	}
	else {
		$topicfontsize ="";
	}
	
	if( !empty( $atts['topiccolor'] ) or !empty( $atts['topicfontsize'] ) ) {
		$topicStyle = ' style="' . $topiccolor . $topicfontsize . '"';
	} else {
		$topicStyle = "";
	}
	
	if( !empty( $atts['name'] ) or !empty( $atts['image'] ) ) {
	
		$output .= '<div class="item">';

			if( !empty( $atts['image'] ) ) {
				$image_url = wp_get_attachment_image_src( $atts["image"], "eventstation-speaker-image" );
				$image = ' style="background-image:url(' . esc_url( $image_url[0] ) . ');"';
			} else {
				$image = "";
			}
		
			$output .= '<div class="speaker-item-header"' . $image . '>';
			
				if( !empty( $atts['topic'] ) ) {
					$output .= '<div class="speaker-item-topic-wrapper"><h4 class="speaker-item-topic-title"' . $topicStyle . '>' . esc_attr( $atts['topic'] ) . '</h4></div>';
				}
				
			$output .= '</div>';
		
			$output .= '<div class="speaker-item-body">';
			
				if( !empty( $atts['date'] ) or !empty( $atts['hour'] ) or !empty( $atts['hall'] ) ) {
					$output .= '<ul class="speaker-item-information"' . $infoStyle . '>';
					
						if( !empty( $atts['date'] ) ) {
							$output .= '<li><i class="fa fa-calendar-check-o"></i><span>' . esc_attr( $atts['date'] ) . '</span></li>';
						}
						
						if( !empty( $atts['hour'] ) ) {
							$output .= '<li><i class="fa fa-clock-o"></i><span>' . esc_attr( $atts['hour'] ) . '</span></li>';
						}
						
						if( !empty( $atts['hall'] ) ) {
							$output .= '<li><i class="fa fa-map"></i><span>' . esc_attr( $atts['hall'] ) . '</span></li>';
						}
						
					$output .= '</ul>';
				}
				
				$output .= '<div class="name-job">';
					
					$output .= '<h2' . $nameStyle . '>' . esc_attr( $atts['name'] ) . '</h2>';
					
					if( !empty( $atts['job'] ) ) {
						$output .= '<h3' . $jobStyle . '>' . esc_attr( $atts['job'] ) . '</h3>';
					}
					
				$output .= '</div>';
				
				if( !empty( $atts['sociallink1'] ) or !empty( $atts['sociallink2'] ) or !empty( $atts['sociallink3'] ) or !empty( $atts['sociallink4'] ) or !empty( $atts['sociallink5'] ) or !empty( $atts['sociallink6'] ) or !empty( $atts['sociallink1url'] ) or !empty( $atts['sociallink2url'] ) or !empty( $atts['sociallink3url'] ) or !empty( $atts['sociallink4url'] ) or !empty( $atts['sociallink5url'] ) or !empty( $atts['sociallink6url'] ) ) {
					$output .= '<ul class="speaker-item-social-links">';
						
						if( !empty( $atts['sociallink2'] ) or !empty( $atts['sociallink3'] ) or !empty( $atts['sociallink4'] ) or !empty( $atts['sociallink5'] ) or !empty( $atts['sociallink6'] ) ) {
							$social_icon2 = $atts['sociallink2'];
							$social_icon3 = $atts['sociallink3'];
							$social_icon4 = $atts['sociallink4'];
							$social_icon5 = $atts['sociallink5'];
							$social_icon6 = $atts['sociallink6'];
						} else {
							$social_icon2 = esc_html__( 'facebook', 'eventstation' );
							$social_icon3 = esc_html__( 'facebook', 'eventstation' );
							$social_icon4 = esc_html__( 'facebook', 'eventstation' );
							$social_icon5 = esc_html__( 'facebook', 'eventstation' );
							$social_icon6 = esc_html__( 'facebook', 'eventstation' );
						}
						
						if( empty( $atts['sociallink1'] ) ) {
							$social_icon1 = esc_html__( 'facebook', 'eventstation' );
						}
						
						if( empty( $atts['sociallink1'] ) and !empty( $atts['sociallink1url'] ) ) {
							$output .= '<li><a href="' . esc_url( $atts['sociallink1url'] ) . '" target="_blank"><i class="fa fa-' . esc_attr( $social_icon1 ) . '"></i></a></li>';
						}
						
						if( !empty( $atts['sociallink2'] ) and !empty( $atts['sociallink2url'] ) ) {
							$output .= '<li><a href="' . esc_url( $atts['sociallink2url'] ) . '" target="_blank"><i class="fa fa-' . esc_attr( $social_icon2 ) . '"></i></a></li>';
						}
						
						if( !empty( $atts['sociallink3'] ) and !empty( $atts['sociallink3url'] ) ) {
							$output .= '<li><a href="' . esc_url( $atts['sociallink3url'] ) . '" target="_blank"><i class="fa fa-' . esc_attr( $social_icon3 ) . '"></i></a></li>';
						}
						
						if( !empty( $atts['sociallink4'] ) and !empty( $atts['sociallink4url'] ) ) {
							$output .= '<li><a href="' . esc_url( $atts['sociallink4url'] ) . '" target="_blank"><i class="fa fa-' . esc_attr( $social_icon4 ) . '"></i></a></li>';
						}
						
						if( !empty( $atts['sociallink5'] ) and !empty( $atts['sociallink5url'] ) ) {
							$output .= '<li><a href="' . esc_url( $atts['sociallink5url'] ) . '" target="_blank"><i class="fa fa-' . esc_attr( $social_icon5 ) . '"></i></a></li>';
						}
						
						if( !empty( $atts['sociallink6'] ) and !empty( $atts['sociallink6url'] ) ) {
							$output .= '<li><a href="' . esc_url( $atts['sociallink6url'] ) . '" target="_blank"><i class="fa fa-' . esc_attr( $social_icon6 ) . '"></i></a></li>';
						}
						
					$output .= '</ul>';
				}
				
			$output .= '</div>';
					
			if( !empty( $atts['text'] ) ) {
					$output .= '<div class="pricing-list-text">';
						$output .= esc_attr( $atts['text'] );
					$output .= '</div>';
			}
		
		$output .= '</div>';
	}

	return $output;
}
add_shortcode("speakers_item", "speakers_item_shortcode");

function image_speakers_style( $settings, $value ) {
	return '<div class="my_param_block">'
	.'<input name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput ' .
	esc_attr( $settings['param_name'] ) . ' ' .
	esc_attr( $settings['type'] ) . '_field" type="hidden" value="' . esc_attr( $value ) . '" />
	<img src="'.esc_attr( $value ).'">'.
	'</div>';
}
vc_add_shortcode_param( 'speakers_style', 'image_speakers_style' );

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Speakers", 'eventstation'),
		"base" => "speakers",
		"class" => "",
		"as_parent" => array('only' => 'speakers_item'),
		"js_view" => 'VcColumnView',
		"content_element" => true,
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/speakers.png',
		"description" =>esc_html__( 'Speakers widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style",'eventstation'),
				"description" => esc_html__("You can select the design style.",'eventstation'),
				"param_name" => "style",
				"value" => array(
					esc_html__("Default", 'eventstation') => "default",
					esc_html__("Alternative", 'eventstation') => "alternative",
				)
			),
			array(
				'type'	=> 'speakers_style',
				'heading'	=> '',
				'param_name' => 'speakersstyleone',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/speakers-1.jpg',
				'dependency' => array('element' => "style", 'value' => array('default'))			
			),
			array(
				'type'	=> 'speakers_style',
				'heading'	=> '',
				'param_name' => 'speakersstyletwo',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/speakers-2.jpg',
				'dependency' => array('element' => "style", 'value' => array('alternative'))			
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Column",'eventstation'),
				"description" => esc_html__("You can select the design column.",'eventstation'),
				"param_name" => "column",
				"value" => array(
					esc_html__("One", 'eventstation') => "1",
					esc_html__("Two", 'eventstation') => "2",
					esc_html__("Three", 'eventstation') => "3",
					esc_html__("Four", 'eventstation') => "4",
					esc_html__("Five", 'eventstation') => "5"
				)
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Dot",'eventstation'),
				"description" => esc_html__("You can select the dot style.",'eventstation'),
				"param_name" => "dot",
				"value" => array(
					esc_html__("Default", 'eventstation') => "default",
					esc_html__("White", 'eventstation') => "white"
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Speakers Item", 'eventstation'),
		"base" => "speakers_item",
		"class" => "",
		"as_child" => array( 'only' => 'speakers' ),
		"content_element" => true,
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/speakers_item.png',
		"description" =>esc_html__( 'Speakers item widget.','eventstation'),
		"params" => array(
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__("Image",'eventstation'),
				"description" => esc_html__( "You can the upload your speaker image.", 'eventstation' ),
				"param_name" => "image",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Name",'eventstation'),
				"description" => esc_html__("You can enter the speaker name.", 'eventstation'),
				"param_name" => "name",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Job",'eventstation'),
				"description" => esc_html__("You can enter the speaker job.", 'eventstation'),
				"param_name" => "job",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Date",'eventstation'),
				"description" => esc_html__("You can enter the date.", 'eventstation'),
				"param_name" => "date",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Hour",'eventstation'),
				"description" => esc_html__("You can enter the hour.", 'eventstation'),
				"param_name" => "hour",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Hall",'eventstation'),
				"description" => esc_html__("You can enter the hall name.", 'eventstation'),
				"param_name" => "hall",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Topic",'eventstation'),
				"description" => esc_html__("You can enter the topic name.", 'eventstation'),
				"param_name" => "topic",
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Link 1",'eventstation'),
				"description" => esc_html__("You can select the social link1.",'eventstation'),
				"param_name" => "sociallink1",
				"value" => array(
					esc_html__("Facebook", 'eventstation') => "facebook",
					esc_html__("Twitter", 'eventstation') => "twitter",
					esc_html__("Google+", 'eventstation') => "google-plus",
					esc_html__("Pinterest", 'eventstation') => "pinterest",
					esc_html__("Instagram", 'eventstation') => "instagram",
					esc_html__("Vine", 'eventstation') => "vine",
					esc_html__("YouTube", 'eventstation') => "youtube",
					esc_html__("Behance", 'eventstation') => "behance",
					esc_html__("DeviantArt", 'eventstation') => "deviantart",
					esc_html__("Digg", 'eventstation') => "digg",
					esc_html__("Dribbble", 'eventstation') => "dribbble",
					esc_html__("Flickr", 'eventstation') => "flickr",
					esc_html__("GitHub", 'eventstation') => "github",
					esc_html__("Last.fm", 'eventstation') => "lastfm",
					esc_html__("Reddit", 'eventstation') => "reddit",
					esc_html__("SoundCloud", 'eventstation') => "soundcloud",
					esc_html__("Tumblr", 'eventstation') => "tumblr",
					esc_html__("Vimeo", 'eventstation') => "vimeo",
					esc_html__("VK", 'eventstation') => "vk",
					esc_html__("Medium", 'eventstation') => "medium",
					esc_html__("Other Link", 'eventstation') => "link",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Social Link 1 URL",'eventstation'),
				"description" => esc_html__("You can enter the link url.", 'eventstation'),
				"param_name" => "sociallink1url",
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Link 2",'eventstation'),
				"description" => esc_html__("You can select the social link2.",'eventstation'),
				"param_name" => "sociallink2",
				"value" => array(
					esc_html__("Facebook", 'eventstation') => "facebook",
					esc_html__("Twitter", 'eventstation') => "twitter",
					esc_html__("Google+", 'eventstation') => "google-plus",
					esc_html__("Pinterest", 'eventstation') => "pinterest",
					esc_html__("Instagram", 'eventstation') => "instagram",
					esc_html__("Vine", 'eventstation') => "vine",
					esc_html__("YouTube", 'eventstation') => "youtube",
					esc_html__("Behance", 'eventstation') => "behance",
					esc_html__("DeviantArt", 'eventstation') => "deviantart",
					esc_html__("Digg", 'eventstation') => "digg",
					esc_html__("Dribbble", 'eventstation') => "dribbble",
					esc_html__("Flickr", 'eventstation') => "flickr",
					esc_html__("GitHub", 'eventstation') => "github",
					esc_html__("Last.fm", 'eventstation') => "lastfm",
					esc_html__("Reddit", 'eventstation') => "reddit",
					esc_html__("SoundCloud", 'eventstation') => "soundcloud",
					esc_html__("Tumblr", 'eventstation') => "tumblr",
					esc_html__("Vimeo", 'eventstation') => "vimeo",
					esc_html__("VK", 'eventstation') => "vk",
					esc_html__("Medium", 'eventstation') => "medium",
					esc_html__("Other Link", 'eventstation') => "link",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Social Link 2 URL",'eventstation'),
				"description" => esc_html__("You can enter the link url.", 'eventstation'),
				"param_name" => "sociallink2url",
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Link 3",'eventstation'),
				"description" => esc_html__("You can select the social link3.",'eventstation'),
				"param_name" => "sociallink3",
				"value" => array(
					esc_html__("Facebook", 'eventstation') => "facebook",
					esc_html__("Twitter", 'eventstation') => "twitter",
					esc_html__("Google+", 'eventstation') => "google-plus",
					esc_html__("Pinterest", 'eventstation') => "pinterest",
					esc_html__("Instagram", 'eventstation') => "instagram",
					esc_html__("Vine", 'eventstation') => "vine",
					esc_html__("YouTube", 'eventstation') => "youtube",
					esc_html__("Behance", 'eventstation') => "behance",
					esc_html__("DeviantArt", 'eventstation') => "deviantart",
					esc_html__("Digg", 'eventstation') => "digg",
					esc_html__("Dribbble", 'eventstation') => "dribbble",
					esc_html__("Flickr", 'eventstation') => "flickr",
					esc_html__("GitHub", 'eventstation') => "github",
					esc_html__("Last.fm", 'eventstation') => "lastfm",
					esc_html__("Reddit", 'eventstation') => "reddit",
					esc_html__("SoundCloud", 'eventstation') => "soundcloud",
					esc_html__("Tumblr", 'eventstation') => "tumblr",
					esc_html__("Vimeo", 'eventstation') => "vimeo",
					esc_html__("VK", 'eventstation') => "vk",
					esc_html__("Medium", 'eventstation') => "medium",
					esc_html__("Other Link", 'eventstation') => "link",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Social Link 3 URL",'eventstation'),
				"description" => esc_html__("You can enter the link url.", 'eventstation'),
				"param_name" => "sociallink3url",
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Link 4",'eventstation'),
				"description" => esc_html__("You can select the social link4.",'eventstation'),
				"param_name" => "sociallink4",
				"value" => array(
					esc_html__("Facebook", 'eventstation') => "facebook",
					esc_html__("Twitter", 'eventstation') => "twitter",
					esc_html__("Google+", 'eventstation') => "google-plus",
					esc_html__("Pinterest", 'eventstation') => "pinterest",
					esc_html__("Instagram", 'eventstation') => "instagram",
					esc_html__("Vine", 'eventstation') => "vine",
					esc_html__("YouTube", 'eventstation') => "youtube",
					esc_html__("Behance", 'eventstation') => "behance",
					esc_html__("DeviantArt", 'eventstation') => "deviantart",
					esc_html__("Digg", 'eventstation') => "digg",
					esc_html__("Dribbble", 'eventstation') => "dribbble",
					esc_html__("Flickr", 'eventstation') => "flickr",
					esc_html__("GitHub", 'eventstation') => "github",
					esc_html__("Last.fm", 'eventstation') => "lastfm",
					esc_html__("Reddit", 'eventstation') => "reddit",
					esc_html__("SoundCloud", 'eventstation') => "soundcloud",
					esc_html__("Tumblr", 'eventstation') => "tumblr",
					esc_html__("Vimeo", 'eventstation') => "vimeo",
					esc_html__("VK", 'eventstation') => "vk",
					esc_html__("Medium", 'eventstation') => "medium",
					esc_html__("Other Link", 'eventstation') => "link",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Social Link 4 URL",'eventstation'),
				"description" => esc_html__("You can enter the link url.", 'eventstation'),
				"param_name" => "sociallink4url",
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Link 5",'eventstation'),
				"description" => esc_html__("You can select the social link5.",'eventstation'),
				"param_name" => "sociallink5",
				"value" => array(
					esc_html__("Facebook", 'eventstation') => "facebook",
					esc_html__("Twitter", 'eventstation') => "twitter",
					esc_html__("Google+", 'eventstation') => "google-plus",
					esc_html__("Pinterest", 'eventstation') => "pinterest",
					esc_html__("Instagram", 'eventstation') => "instagram",
					esc_html__("Vine", 'eventstation') => "vine",
					esc_html__("YouTube", 'eventstation') => "youtube",
					esc_html__("Behance", 'eventstation') => "behance",
					esc_html__("DeviantArt", 'eventstation') => "deviantart",
					esc_html__("Digg", 'eventstation') => "digg",
					esc_html__("Dribbble", 'eventstation') => "dribbble",
					esc_html__("Flickr", 'eventstation') => "flickr",
					esc_html__("GitHub", 'eventstation') => "github",
					esc_html__("Last.fm", 'eventstation') => "lastfm",
					esc_html__("Reddit", 'eventstation') => "reddit",
					esc_html__("SoundCloud", 'eventstation') => "soundcloud",
					esc_html__("Tumblr", 'eventstation') => "tumblr",
					esc_html__("Vimeo", 'eventstation') => "vimeo",
					esc_html__("VK", 'eventstation') => "vk",
					esc_html__("Medium", 'eventstation') => "medium",
					esc_html__("Other Link", 'eventstation') => "link",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Social Link 5 URL",'eventstation'),
				"description" => esc_html__("You can enter the link url.", 'eventstation'),
				"param_name" => "sociallink5url",
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Link 6",'eventstation'),
				"description" => esc_html__("You can select the social link6.",'eventstation'),
				"param_name" => "sociallink6",
				"value" => array(
					esc_html__("Facebook", 'eventstation') => "facebook",
					esc_html__("Twitter", 'eventstation') => "twitter",
					esc_html__("Google+", 'eventstation') => "google-plus",
					esc_html__("Pinterest", 'eventstation') => "pinterest",
					esc_html__("Instagram", 'eventstation') => "instagram",
					esc_html__("Vine", 'eventstation') => "vine",
					esc_html__("YouTube", 'eventstation') => "youtube",
					esc_html__("Behance", 'eventstation') => "behance",
					esc_html__("DeviantArt", 'eventstation') => "deviantart",
					esc_html__("Digg", 'eventstation') => "digg",
					esc_html__("Dribbble", 'eventstation') => "dribbble",
					esc_html__("Flickr", 'eventstation') => "flickr",
					esc_html__("GitHub", 'eventstation') => "github",
					esc_html__("Last.fm", 'eventstation') => "lastfm",
					esc_html__("Reddit", 'eventstation') => "reddit",
					esc_html__("SoundCloud", 'eventstation') => "soundcloud",
					esc_html__("Tumblr", 'eventstation') => "tumblr",
					esc_html__("Vimeo", 'eventstation') => "vimeo",
					esc_html__("VK", 'eventstation') => "vk",
					esc_html__("Medium", 'eventstation') => "medium",
					esc_html__("Other Link", 'eventstation') => "link",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Social Link 6 URL",'eventstation'),
				"description" => esc_html__("You can enter the link url.", 'eventstation'),
				"param_name" => "sociallink6url",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Name Font Size",'eventstation'),
				"description" => esc_html__("You can enter the name font size. Example: 15px.", 'eventstation'),
				"param_name" => "namefontsize",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Job Font Size",'eventstation'),
				"description" => esc_html__("You can enter the job font size. Example: 15px.", 'eventstation'),
				"param_name" => "jobfontsize",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Topic Font Size",'eventstation'),
				"description" => esc_html__("You can enter the topic font size. Example: 15px.", 'eventstation'),
				"param_name" => "topicfontsize",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Information Font Size",'eventstation'),
				"description" => esc_html__("You can enter the date, hour and hall font size. Example: 15px.", 'eventstation'),
				"param_name" => "infofontsize",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Name Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "namecolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Job Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "jobcolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Information Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "infocolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Topic Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "topiccolor",
				"value" => "",
			)
		)
	) );
}

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_speakers extends WPBakeryShortCodesContainer {}
}
/*------------- SPEAKERS START END -------------*/

/*------------- SERVICES BOX START -------------*/
function services_box_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'style' => '',
			'image' => '',
			'title' => '',
			'excerpt' => '',
			'text' => '',
			'icon' => '',
			'titlefontsize' => '',
			'textfontsize' => '',
			'titlecolor' => '',
			'textcolor' => '',
			'iconbackground' => '',
			'iconcolor' => '',
			'iconbordercolor' => '',
			'readmorebg' => '',
			'readmorecolor' => '',
			'customclass' => '',
		), $atts
	);
	
	$output = '';
	
		$allowed_html = array ( 'br' => array() );
	
		if( !empty( $atts['titlecolor'] ) ) {
			$titlecolor = 'color:' . esc_attr( $atts['titlecolor'] ) . ';';
		}
		else {
			$titlecolor ="";
		}

		if( !empty( $atts['titlefontsize'] ) ) {
			$titlefontsize = 'font-size:' . esc_attr( $atts['titlefontsize'] ) . ';';
		}
		else {
			$titlefontsize ="";
		}
		
		if( !empty( $atts['titlecolor'] ) or !empty( $atts['titlefontsize'] ) ) {
			$titleStyle = ' style="' . $titlecolor . $titlefontsize . '"';
		} else {
			$titleStyle = "";
		}
	
		if( !empty( $atts['titlecolor'] ) or !empty( $atts['titlefontsize'] ) ) {
			$titleStyle = ' style="' . $titlecolor . $titlefontsize . '"';
		} else {
			$titleStyle = "";
		}
		
		if( !empty( $atts['textcolor'] ) ) {
			$textcolor = 'color:' . esc_attr( $atts['textcolor'] ) . ';';
		}
		else {
			$textcolor ="";
		}

		if( !empty( $atts['textfontsize'] ) ) {
			$textfontsize = 'font-size:' . esc_attr( $atts['textfontsize'] ) . ';';
		}
		else {
			$textfontsize ="";
		}
		
		if( !empty( $atts['textcolor'] ) or !empty( $atts['textfontsize'] ) ) {
			$textStyle = ' style="' . $textcolor . $textfontsize . '"';
		} else {
			$textStyle = "";
		}
	
		if( !empty( $atts['iconcolor'] ) ) {
			$iconcolor = 'color:' . esc_attr( $atts['iconcolor'] ) . ';';
		}
		else {
			$iconcolor ="";
		}

		if( !empty( $atts['iconbackground'] ) ) {
			$iconbackground = 'background:' . esc_attr( $atts['iconbackground'] ) . ';';
		}
		else {
			$iconbackground ="";
		}

		if( !empty( $atts['iconbordercolor'] ) ) {
			$iconbordercolor = 'border-color:' . esc_attr( $atts['iconbordercolor'] ) . ';';
		}
		else {
			$iconbordercolor ="";
		}
		
		if( !empty( $atts['iconcolor'] ) or !empty( $atts['iconbackground'] ) ) {
			$iconStyle = ' style="' . $iconcolor . $iconbackground . '"';
		} else {
			$iconStyle = "";
		}
		
		if( !empty( $atts['iconcolor'] ) or !empty( $atts['iconbackground'] )  or !empty( $atts['iconbordercolor'] ) ) {
			$iconStyle2 = ' style="' . $iconcolor . $iconbackground . $iconbordercolor . '"';
		} else {
			$iconStyle2 = "";
		}
	
		if( !empty( $atts['readmorecolor'] ) ) {
			$readmorecolor = 'color:' . esc_attr( $atts['readmorecolor'] ) . ';';
		}
		else {
			$readmorecolor ="";
		}

		if( !empty( $atts['readmorebg'] ) ) {
			$readmorebg = 'background:' . esc_attr( $atts['readmorebg'] ) . ';';
		}
		else {
			$readmorebg ="";
		}
		
		if( !empty( $atts['readmorecolor'] ) or !empty( $atts['readmorebg'] ) ) {
			$readMoreStyle = ' style="' . $readmorecolor . $readmorebg . '"';
		} else {
			$readMoreStyle = "";
		}

		if( !empty( $atts['customclass'] ) ) {
			$customClass = ' ' . esc_attr( $atts['customclass'] );
		} else {
			$customClass = "";
		}
	
		if( !empty( $atts['title'] ) and !empty( $atts['excerpt'] ) ) {
			
			/* STYLE IMAGE START */
			if( $atts['style'] == "image" ) {
		
				if( !empty( $atts['image'] ) ) {
					$image_url = wp_get_attachment_image_src( $atts["image"], "eventstation-speaker-image" );
					$image = ' style="background-image:url(' . esc_url( $image_url[0] ) . ');"';
				} else {
					$image = "";
				}
				
				$random_id = rand( 0, 99999999 );
				
				$output .= '<div class="service-box service-box-' . $random_id . ' service-box-image-style' . $customClass . '">';
					
					$output .= '<div class="service-box-image-style-content">';
				
						if( !empty( $atts['icon'] ) ) {
							$output .= '<div class="service-box-icon"><i class="fa fa-' . esc_attr( $atts['icon'] ) . '"' . $iconStyle . '></i></div>';
						}
					
						if( !empty( $atts['title'] ) ) {
							$output .= '<h2' . $titleStyle . '>' . wp_kses( $atts['title'] , $allowed_html ) . '</h2>';
						}
					
						if( !empty( $atts['excerpt'] ) ) {
							$output .= '<p' . $textStyle . '>' . esc_attr( $atts['excerpt'] ) . '</p>';
						}
						
					$output .= '</div>';
					
					$output .= '<div class="service-box-image-style-image"' . $image . '>';
					$output .= '<div class="service-box-image-style-more"' . $readMoreStyle . '><i class="fa fa-search"></i><span>' . esc_html__( 'More' , 'eventstation' ) . '</span></div>';
					$output .= '</div>';
					
					$output .= '<div class="service-box-image-style-hover-content-wrapper">';
						$output .= '<div class="service-box-image-style-hover-content">';
					
							$output .= '<div class="service-box-close-icon">x</div>';
							
							if( !empty( $atts['icon'] ) ) {
								$output .= '<div class="service-box-icon"><i class="fa fa-' . esc_attr( $atts['icon'] ) . '"></i></div>';
							}
						
							if( !empty( $atts['title'] ) ) {
								$output .= '<h2>' . wp_kses( $atts['title'] , $allowed_html ) . '</h2>';
							}
						
							if( !empty( $atts['text'] ) ) {
								$output .= '<p>' . esc_attr( $atts['text'] ) . '</p>';
							}
							
						$output .= '</div>';
					$output .= '</div>';
		
					$output .= "<script>
										jQuery(document).ready(function($){
		$(document).on('click', '.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-image .service-box-image-style-more', function(){
			$('.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-image .service-box-image-style-more').fadeOut();
			$('.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-hover-content-wrapper').fadeIn();
		});
	
		$(document).on('click', '.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-hover-content-wrapper .service-box-image-style-hover-content .service-box-close-icon', function(){
			$('.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-hover-content-wrapper').fadeOut();
			$('.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-image .service-box-image-style-more').fadeIn();
		});
										});
									</script>";
					
				$output .= '</div>';
			}
			/* STYLE IMAGE END */
			
			/* STYLE ICON START */
			else {
				$output .= '<div class="service-box service-box-icon-style' . $customClass . '">';
				
					if( !empty( $atts['icon'] ) ) {
						$output .= '<div class="service-box-icon animate anim-fadeInDown animate-delay-0"' . $iconStyle2 . '><i class="fa fa-' . esc_attr( $atts['icon'] ) . '"></i></div>';
					}
					
					if( !empty( $atts['title'] ) ) {
						$output .= '<h2' . $titleStyle . ' class="animate anim-fadeInDown animate-delay-0-20">' . esc_attr( $atts['title'] ) . '</h2>';
					}
					
					if( !empty( $atts['excerpt'] ) ) {
						$output .= '<p' . $textStyle . ' class="animate anim-fadeInDown animate-delay-0-40">' . esc_attr( $atts['excerpt'] ) . '</p>';
					}
					
				$output .= '</div>';
			}
			/* STYLE ICON END */
			
		}	

	return $output;
}
add_shortcode("services_box", "services_box_shortcode");

function image_servicesbox_style( $settings, $value ) {
	return '<div class="my_param_block">'
	.'<input name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput ' .
	esc_attr( $settings['param_name'] ) . ' ' .
	esc_attr( $settings['type'] ) . '_field" type="hidden" value="' . esc_attr( $value ) . '" />
	<img src="'.esc_attr( $value ).'">'.
	'</div>';
}
vc_add_shortcode_param( 'servicesbox_style', 'image_servicesbox_style' );

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Services Box", 'eventstation'),
		"base" => "services_box",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/services_box.png',
		"description" =>esc_html__( 'Services box widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style",'eventstation'),
				"description" => esc_html__("You can select the design style.",'eventstation'),
				"param_name" => "style",
				"value" => array(
					esc_html__("Icon", 'eventstation') => "icon",
					esc_html__("Image", 'eventstation') => "image"
				)
			),
			array(
				'type'	=> 'servicesbox_style',
				'heading'	=> '',
				'param_name'	=> 'servicesboxstyleone',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/services-box-1.jpg',
				'dependency' => array('element' => "style", 'value' => array('icon'))			
			),
			array(
				'type'	=> 'servicesbox_style',
				'heading'	=> '',
				'param_name'	=> 'servicesboxstyletwo',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/services-box-2.jpg',
				'dependency' => array('element' => "style", 'value' => array('image'))			
			),
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__( "Image",'eventstation' ),
				"description" => esc_html__( "You can the upload your service image.", 'eventstation' ),
				"param_name" => "image",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title",'eventstation'),
				"description" => esc_html__("You can enter the service title.", 'eventstation'),
				"param_name" => "title",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Excerpt",'eventstation'),
				"description" => esc_html__("You can enter the service excerpt.", 'eventstation'),
				"param_name" => "excerpt",
				"value" => "",
			),
			array(
				"type" => "textarea",
				"class" => "",
				"heading" => esc_html__("Text",'eventstation'),
				"description" => esc_html__("You can enter the text.",'eventstation'),
				"param_name" => "text",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Icon",'eventstation'),
				"description" => esc_html__("You can enter the icon name. List of the icons is available in the documentation file. Example: edge, automobile, bel-o.", 'eventstation'),
				"param_name" => "icon",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Title Font Size",'eventstation'),
				"description" => esc_html__("You can enter the title font size. Example: 15px.", 'eventstation'),
				"param_name" => "titlefontsize",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Text Font Size",'eventstation'),
				"description" => esc_html__("You can enter the text font size. Example: 15px.", 'eventstation'),
				"param_name" => "textfontsize",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Title Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "titlecolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Text Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "textcolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Background",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconbackground",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconcolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Border Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconbordercolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Read More Background",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "readmorebg",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Read More Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "readmorecolor",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}
/*------------- SERVICES BOX END -------------*/

/*------------- INFO BOX START -------------*/
function info_box_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'style' => '',
			'image' => '',
			'title' => '',
			'excerpt' => '',
			'text' => '',
			'icon' => '',
			'titlefontsize' => '',
			'textfontsize' => '',
			'titlecolor' => '',
			'textcolor' => '',
			'iconbackground' => '',
			'iconcolor' => '',
			'customclass' => ''
		), $atts
	);
	
	$output = '';		

		if( !empty( $atts['customclass'] ) ) {
			$customClass = ' ' . esc_attr( $atts['customclass'] );
		} else {
			$customClass = "";
		}
	
		if( !empty( $atts['titlecolor'] ) ) {
			$titlecolor = 'color:' . esc_attr( $atts['titlecolor'] ) . ';';
		}
		else {
			$titlecolor ="";
		}

		if( !empty( $atts['titlefontsize'] ) ) {
			$titlefontsize = 'font-size:' . esc_attr( $atts['titlefontsize'] ) . ';';
		}
		else {
			$titlefontsize ="";
		}
		
		if( !empty( $atts['titlecolor'] ) or !empty( $atts['titlefontsize'] ) ) {
			$titleStyle = ' style="' . $titlecolor . $titlefontsize . '"';
		} else {
			$titleStyle = "";
		}
	
		if( !empty( $atts['titlecolor'] ) or !empty( $atts['titlefontsize'] ) ) {
			$titleStyle = ' style="' . $titlecolor . $titlefontsize . '"';
		} else {
			$titleStyle = "";
		}
		
		if( !empty( $atts['textcolor'] ) ) {
			$textcolor = 'color:' . esc_attr( $atts['textcolor'] ) . ';';
		}
		else {
			$textcolor ="";
		}

		if( !empty( $atts['textfontsize'] ) ) {
			$textfontsize = 'font-size:' . esc_attr( $atts['textfontsize'] ) . ';';
		}
		else {
			$textfontsize ="";
		}
		
		if( !empty( $atts['textcolor'] ) or !empty( $atts['textfontsize'] ) ) {
			$textStyle = ' style="' . $textcolor . $textfontsize . '"';
		} else {
			$textStyle = "";
		}
	
		if( !empty( $atts['iconcolor'] ) ) {
			$iconcolor = 'color:' . esc_attr( $atts['iconcolor'] ) . ';';
		}
		else {
			$iconcolor ="";
		}

		if( !empty( $atts['iconbackground'] ) ) {
			$iconbackground = 'background:' . esc_attr( $atts['iconbackground'] ) . ';';
		}
		else {
			$iconbackground ="";
		}
		
		if( !empty( $atts['iconcolor'] ) or !empty( $atts['iconbackground'] ) ) {
			$iconStyle = ' style="' . $iconcolor . $iconbackground . '"';
		} else {
			$iconStyle = "";
		}
	
		if( !empty( $atts['title'] ) and !empty( $atts['excerpt'] ) ) {
			
			/* STYLE ALTERNATIVE START */
			if( $atts['style'] == "alternative" ) {
		
				if( !empty( $atts['image'] ) ) {
					$image_url = wp_get_attachment_image_src( $atts["image"], "full" );
					$image = ' style="background-image:url(' . esc_url( $image_url[0] ) . ');"';
				} else {
					$image = "";
				}
				
				$random_id = rand( 0, 99999999 );
				
				$output .= '<div class="info-box info-box-' . esc_attr( $random_id ) . ' info-box-alternative-style' . $customClass . '">';
					
					$output .= '<div class="info-box-alternative-style-image"' . $image . '>';
						
						$output .= '<div class="info-box-alternative-style-image-wrapper">';
						
							if( !empty( $atts['icon'] ) ) {
								$output .= '<div class="info-box-icon"><i class="fa fa-' . esc_attr( $atts['icon'] ) . '"' . $iconStyle . '></i></div>';
							}
							
							if( !empty( $atts['title'] ) ) {
								$output .= '<h2' . $titleStyle . ' class="animate anim-fadeIn animate-delay-0-20">' . esc_attr( $atts['title'] ) . '</h2>';
							}
						
						$output .= '</div>';
						
					$output .= '</div>';
						
					$output .= '<div class="info-box-alternative-style-content">';
					
						if( !empty( $atts['excerpt'] ) ) {
							$output .= '<p' . $textStyle . ' class="animate anim-fadeIn animate-delay-0-40">' . esc_attr( $atts['excerpt'] ) . '</p>';
						}
						
						$output .= '<div class="readmore animate anim-fadeIn animate-delay-0-60"><span>' . esc_html__( 'Read More' , 'eventstation' ) . '</span><i class="fa fa-angle-right"></i></div>';
						
					$output .= '</div>';
					
					$output .= '<div class="info-box-alternative-style-hover-content-wrapper">';
						$output .= '<div class="info-box-alternative-style-hover-content scrollbar-outer">';
					
							$output .= '<div class="info-box-close-icon">x</div>';
							
							if( !empty( $atts['icon'] ) ) {
								$output .= '<div class="info-box-icon"><i class="fa fa-' . esc_attr( $atts['icon'] ) . '"></i></div>';
							}
						
							if( !empty( $atts['title'] ) ) {
								$output .= '<h2>' . esc_attr( $atts['title'] ) . '</h2>';
							}
						
							if( !empty( $atts['text'] ) ) {
								$output .= '<p>' . $atts['text'] . '</p>';
							}
							
						$output .= '</div>';
					$output .= '</div>';
		
					$output .= "<script>
										jQuery(document).ready(function($){
											$(document).on('click', '.info-box.info-box-" . esc_attr( $random_id ) . " .info-box-alternative-style-content .readmore', function(){
												$('.info-box.info-box-" . esc_attr( $random_id ) . " .info-box-alternative-style-hover-content-wrapper').fadeIn();
											});
										
											$(document).on('click', '.info-box.info-box-" . esc_attr( $random_id ) . ".info-box-alternative-style .info-box-alternative-style-hover-content-wrapper .info-box-alternative-style-hover-content .info-box-close-icon', function(){
												$('.info-box.info-box-" . esc_attr( $random_id ) . ".info-box-alternative-style .info-box-alternative-style-hover-content-wrapper').fadeOut();
												$('.info-box.info-box-" . esc_attr( $random_id ) . ".info-box-alternative-style .info-box-alternative-style-alternative .info-box-alternative-style-more').fadeIn();
											});
										});
									</script>";
					
				$output .= '</div>';
				
			}
			/* STYLE ALTERNATIVE END */
			
			/* STYLE DEFAULT START */
			else {
		
				if( !empty( $atts['image'] ) ) {
					$image_url = wp_get_attachment_image_src( $atts["image"], "full" );
					$image = ' style="background-image:url(' . esc_url( $image_url[0] ) . ');"';
				} else {
					$image = "";
				}
				
				$random_id = rand( 0, 99999999 );
				
				$output .= '<div class="info-box info-box-' . esc_attr( $random_id ) . ' info-box-default-style' . $customClass . '">';
					
					$output .= '<div class="info-box-default-style-image"' . $image . '>';
						
						$output .= '<div class="info-box-default-style-image-wrapper">';
						
							if( !empty( $atts['icon'] ) ) {
								$output .= '<div class="info-box-icon"><i class="fa fa-' . esc_attr( $atts['icon'] ) . '"' . $iconStyle . '></i></div>';
							}
						
							$output .= '<div class="info-box-default-style-content">';
							
								if( !empty( $atts['title'] ) ) {
									$output .= '<h2' . $titleStyle . ' class="animate anim-fadeIn animate-delay-0-20">' . esc_attr( $atts['title'] ) . '</h2>';
								}
							
								if( !empty( $atts['excerpt'] ) ) {
									$output .= '<p' . $textStyle . ' class="animate anim-fadeIn animate-delay-0-40">' . esc_attr( $atts['excerpt'] ) . '</p>';
								}
								
								$output .= '<div class="readmore animate anim-fadeIn animate-delay-0-60"><span>' . esc_html__( 'Read More' , 'eventstation' ) . '</span><i class="fa fa-angle-right"></i></div>';
								
							$output .= '</div>';
						
						$output .= '</div>';
						
					$output .= '</div>';
					
					$output .= '<div class="info-box-default-style-hover-content-wrapper">';
						$output .= '<div class="info-box-default-style-hover-content scrollbar-outer">';
					
							$output .= '<div class="info-box-close-icon">x</div>';
							
							if( !empty( $atts['icon'] ) ) {
								$output .= '<div class="info-box-icon"><i class="fa fa-' . esc_attr( $atts['icon'] ) . '"></i></div>';
							}
						
							if( !empty( $atts['title'] ) ) {
								$output .= '<h2>' . esc_attr( $atts['title'] ) . '</h2>';
							}
						
							if( !empty( $atts['text'] ) ) {
								$output .= '<p>' . $atts['text'] . '</p>';
							}
							
						$output .= '</div>';
					$output .= '</div>';
		
					$output .= "<script>
										jQuery(document).ready(function($){
											$(document).on('click', '.info-box.info-box-" . esc_attr( $random_id ) . " .info-box-default-style-image .info-box-default-style-image-wrapper .info-box-default-style-content .readmore', function(){
												$('.info-box.info-box-" . esc_attr( $random_id ) . " .info-box-default-style-hover-content-wrapper').fadeIn();
											});
										
											$(document).on('click', '.info-box.info-box-" . esc_attr( $random_id ) . ".info-box-default-style .info-box-default-style-hover-content-wrapper .info-box-default-style-hover-content .info-box-close-icon', function(){
												$('.info-box.info-box-" . esc_attr( $random_id ) . ".info-box-default-style .info-box-default-style-hover-content-wrapper').fadeOut();
												$('.info-box.info-box-" . esc_attr( $random_id ) . ".info-box-default-style .info-box-default-style-default .info-box-default-style-more').fadeIn();
											});
										});
									</script>";
					
				$output .= '</div>';
				
			}
			/* STYLE DEFAULT END */
			
		}	

	return $output;
}
add_shortcode("info_box", "info_box_shortcode");

function image_info_box_style( $settings, $value ) {
	return '<div class="my_param_block">'
	.'<input name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput ' .
	esc_attr( $settings['param_name'] ) . ' ' .
	esc_attr( $settings['type'] ) . '_field" type="hidden" value="' . esc_attr( $value ) . '" />
	<img src="'.esc_attr( $value ).'">'.
	'</div>';
}
vc_add_shortcode_param( 'info_box_style', 'image_info_box_style' );

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Info Box", 'eventstation'),
		"base" => "info_box",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/info_box.png',
		"description" =>esc_html__( 'Info box widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style",'eventstation'),
				"description" => esc_html__("You can select the design style.",'eventstation'),
				"param_name" => "style",
				"value" => array(
					esc_html__("Default", 'eventstation') => "default",
					esc_html__("Alternative", 'eventstation') => "alternative"
				)
			),
			array(
				'type'	=> 'info_box_style',
				'heading'	=> '',
				'param_name' => 'infoboxstyleone',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/info-box-1.jpg',
				'dependency' => array('element' => "style", 'value' => array('default'))			
			),
			array(
				'type'	=> 'info_box_style',
				'heading'	=> '',
				'param_name' => 'infoboxstyletwo',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/info-box-2.jpg',
				'dependency' => array('element' => "style", 'value' => array('alternative'))			
			),
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__( "Image",'eventstation' ),
				"description" => esc_html__( "You can the upload your service image.", 'eventstation' ),
				"param_name" => "image",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title",'eventstation'),
				"description" => esc_html__("You can enter the service title.", 'eventstation'),
				"param_name" => "title",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Excerpt",'eventstation'),
				"description" => esc_html__("You can enter the service excerpt.", 'eventstation'),
				"param_name" => "excerpt",
				"value" => "",
			),
			array(
				"type" => "textarea",
				"class" => "",
				"heading" => esc_html__("Text",'eventstation'),
				"description" => esc_html__("You can enter the text.",'eventstation'),
				"param_name" => "text",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Icon",'eventstation'),
				"description" => esc_html__("You can enter the icon name. List of the icons is available in the documentation file. Example: edge, automobile, bel-o.", 'eventstation'),
				"param_name" => "icon",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Title Font Size",'eventstation'),
				"description" => esc_html__("You can enter the title font size. Example: 15px.", 'eventstation'),
				"param_name" => "titlefontsize",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Text Font Size",'eventstation'),
				"description" => esc_html__("You can enter the text font size. Example: 15px.", 'eventstation'),
				"param_name" => "textfontsize",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Title Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "titlecolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Text Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "textcolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Background",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconbackground",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconcolor",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}
/*------------- INFO BOX END -------------*/

/*------------- EVENT BOX START -------------*/
function event_box_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'align' => '',
			'image' => '',
			'toplefttext' => '',
			'toprighttext' => '',
			'topbottomtext' => '',
			'days' => '',
			'monthyear' => '',
			'address' => '',
			'buttontext' => '',
			'buttonlink' => '',
			'productid' => '',
			'colorone' => '',
			'colortwo' => '',
			'customclass' => '',
		), $atts
	);
	
	$output = '';	
		
		if( !empty( $atts['colorone'] ) ) {
			$colorone = 'color:' . esc_attr( $atts['colorone'] ) . ';';
		}
		else {
			$colorone ="";
		}
		
		if( !empty( $atts['colorone'] ) ) {
			$coloroneborder = 'background:' . esc_attr( $atts['colorone'] ) . ';';
		}
		else {
			$coloroneborder ="";
		}
	
		if( !empty( $atts['colorone'] ) ) {
			$colorOneStyle = ' style="' . $colorone . '"';
		} else {
			$colorOneStyle = "";
		}
	
		if( !empty( $atts['colorone'] ) ) {
			$colorOneBorderStyle = ' style="' . $coloroneborder . '"';
		} else {
			$colorOneBorderStyle = "";
		}
		
		if( !empty( $atts['colortwo'] ) ) {
			$colortwo = 'color:' . esc_attr( $atts['colortwo'] ) . ';';
		}
		else {
			$colortwo ="";
		}
	
		if( !empty( $atts['colortwo'] ) ) {
			$colorTwoStyle = ' style="' . $colortwo . '"';
		} else {
			$colorTwoStyle = "";
		}

		if( !empty( $atts['customclass'] ) ) {
			$customClass = ' ' . esc_attr( $atts['customclass'] );
		} else {
			$customClass = "";
		}

		if( !empty( $atts['align'] ) ) {
			$align = ' ' . esc_attr( $atts['align'] );
		} else {
			$align = "";
		}
		
		if( !empty( $atts['image'] ) ) {
			$image_url = wp_get_attachment_image_src( $atts["image"], "full" );
			$image = ' style="background-image:url(' . esc_url( $image_url[0] ) . ');"';
		} else {
			$image = "";
		}
	
		$output .= '<div class="event-box' . $customClass . $align . '">';
					
			$output .= '<div class="event-box-image"' . $image . '>';
			
				$output .= '<div class="event-box-image-wrapper"' . $colorOneStyle . '>';
				
					$output .= '<div class="event-box-image-content-wrapper">';
						
						$output .= '<div class="event-box-image-content">';
						
							if( !empty( $atts['toplefttext'] ) or !empty( $atts['toprighttext'] ) or !empty( $atts['topbottomtext'] ) ) {
						
								$output .= '<div class="event-box-image-content-top">';
								
									if( !empty( $atts['toplefttext'] ) ) {
									
										$output .= '<div class="left">' . esc_attr( $atts['toplefttext'] ) . '</div>';
										
									}
								
									if( !empty( $atts['toprighttext'] ) ) {
									
										$output .= '<div class="right">' . esc_attr( $atts['toprighttext'] ) . '</div>';
										
									}
								
									if( !empty( $atts['topbottomtext'] ) ) {
									
										$output .= '<div class="bottom">' . esc_attr( $atts['topbottomtext'] ) . '</div>';
										
									}
						
								$output .= '</div>';
						
							}
							
							if( !empty( $atts['days'] ) or !empty( $atts['monthyear'] ) ) {
								
								$output .= '<div class="event-box-image-content-date">';
								
									$output .= '<div class="event-box-image-content-date-left">';
										$output .= '<div class="event-box-image-content-date-left-left"' . $colorOneBorderStyle . '></div>';
										$output .= '<div class="event-box-image-content-date-left-top"' . $colorOneBorderStyle . '></div>';
										$output .= '<div class="event-box-image-content-date-left-bottom"' . $colorOneBorderStyle . '></div>';
									$output .= '</div>';
								
									$output .= '<div class="event-box-image-content-date-center">';
									
										if( !empty( $atts['topbottomtext'] ) ) {
											
											$output .= '<div class="event-box-image-content-date-days"' . $colorTwoStyle . '>' . esc_attr( $atts['days'] ) . '</div>';
										}
									
										if( !empty( $atts['monthyear'] ) ) {
											
											$output .= '<div class="event-box-image-content-date-monthyear"' . $colorOneStyle . '>' . esc_attr( $atts['monthyear'] ) . '</div>';
										}
						
									$output .= '</div>';

									$output .= '<div class="event-box-image-content-date-right">';
										$output .= '<div class="event-box-image-content-date-right-top"' . $colorOneBorderStyle . '></div>';
										$output .= '<div class="event-box-image-content-date-right-right"' . $colorOneBorderStyle . '></div>';
										$output .= '<div class="event-box-image-content-date-right-bottom"' . $colorOneBorderStyle . '></div>';
									$output .= '</div>';
						
								$output .= '</div>';
								
							}
							
							if( !empty( $atts['address'] ) ) {
								
								$output .= '<div class="event-box-image-content-address">' . esc_attr( $atts['address'] ) . '</div>';
								
							}
					
							if( !empty( $atts['buttontext'] ) ) {
								
								if( !empty( $atts['productid'] ) ) {
									
									$package_link = '?add-to-cart=' . esc_attr( $atts['productid'] );
									
								} else {
									
									$package_link = esc_url( $atts['buttonlink'] );
									
								}
								
								if( !empty( $atts['productid'] ) ) {
									
									$package_icon = '<i class="fa fa-chevron-right" aria-hidden="true"></i>';
									
								} else {
									
									$package_icon = '<i class="fa fa-chevron-right" aria-hidden="true"></i>';
									
								}
								
								$output .= '<div class="event-box-button"><a href="' . $package_link . '" title="' . esc_attr( $atts['buttontext'] ) . '"><span>' . esc_attr( $atts['buttontext'] ) . '</span>' . $package_icon . '</a></div>';
								
							}
						
						$output .= '</div>';
					
					$output .= '</div>';
				
				$output .= '</div>';
			
			$output .= '</div>';
		
		$output .= '</div>';

	return $output;
}
add_shortcode("event_box", "event_box_shortcode");

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Event Box", 'eventstation'),
		"base" => "event_box",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/event_box.png',
		"description" =>esc_html__( 'Event box widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Align",'eventstation'),
				"description" => esc_html__("You can select the design align.",'eventstation'),
				"param_name" => "align",
				"value" => array(
					esc_html__("Right", 'eventstation') => "right",
					esc_html__("Left", 'eventstation') => "left"
				)
			),
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__( "Image",'eventstation' ),
				"description" => esc_html__( "You can the upload your service image.", 'eventstation' ),
				"param_name" => "image",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Top Left Text",'eventstation'),
				"description" => esc_html__("You can enter the top left text.", 'eventstation'),
				"param_name" => "toplefttext",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Top Right Text",'eventstation'),
				"description" => esc_html__("You can enter the top right text.", 'eventstation'),
				"param_name" => "toprighttext",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Top Bottom Text",'eventstation'),
				"description" => esc_html__("You can enter the top bottom text.", 'eventstation'),
				"param_name" => "topbottomtext",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Days",'eventstation'),
				"description" => esc_html__("You can enter the event days. Example: 22, 23, 24, 25.", 'eventstation'),
				"param_name" => "days",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Month - Year",'eventstation'),
				"description" => esc_html__("You can enter the event month and year. Example: June 2016.", 'eventstation'),
				"param_name" => "monthyear",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Address",'eventstation'),
				"description" => esc_html__("You can enter the event adress", 'eventstation'),
				"param_name" => "address",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Button Text",'eventstation'),
				"description" => esc_html__("You can enter the button title.", 'eventstation'),
				"param_name" => "buttontext",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Button Link",'eventstation'),
				"description" => esc_html__("You can enter the button link.", 'eventstation'),
				"param_name" => "buttonlink",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Product ID",'eventstation'),
				"description" => esc_html__("You can enter the WooCommerce product id. How to learn WooCommerce product id?: https://goo.gl/DEJ5fU", 'eventstation'),
				"param_name" => "productid",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Color One",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "colorone",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Color Two",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "colortwo",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}
/*------------- EVENT BOX END -------------*/

/*------------- COUNTER START -------------*/
function counter_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'sliderimages' => '',
			'toplefttext' => '',
			'toprighttext' => '',
			'topbottomtext' => '',
			'days' => '',
			'monthyear' => '',
			'address' => '',
			'counterdate' => '',
			'buttontext' => '',
			'buttonlink' => '',
			'productid' => '',
			'colorone' => '',
			'colortwo' => '',
			'customclass' => '',
		), $atts
	);
	
	$output = '';	
		
	if( !empty( $atts['sliderimages'] ) ) {
		$image = $atts['sliderimages'];
	} else {
		$image = "";
	}
	
	if( !empty( $atts['sliderimages'] ) ) {
		
		$output .= "<script>
							jQuery(document).ready(function($){
								$('.counter .counter-images').vegas({
									timer:false,
									slides: [";
									
												$image_ids = explode( ',', $image ); 
												foreach( $image_ids as $image_id ){
													$image_url = wp_get_attachment_image_src( $image_id, "full" );
													$output .="{ src: '" . $image_url[0] . "' },";
												} 
		
		$output .= "]
							});
								});
							</script>";
						
	}
		
	if( !empty( $atts['colorone'] ) ) {
		$colorone = 'color:' . esc_attr( $atts['colorone'] ) . ';';
	}
	else {
		$colorone ="";
	}
	
	if( !empty( $atts['colorone'] ) ) {
		$coloroneborder = 'background:' . esc_attr( $atts['colorone'] ) . ';';
	}
	else {
		$coloroneborder ="";
	}

	if( !empty( $atts['colorone'] ) ) {
		$colorOneStyle = ' style="' . $colorone . '"';
	} else {
		$colorOneStyle = "";
	}

	if( !empty( $atts['colorone'] ) ) {
		$colorOneBorderStyle = ' style="' . $coloroneborder . '"';
	} else {
		$colorOneBorderStyle = "";
	}
	
	if( !empty( $atts['colortwo'] ) ) {
		$colortwo = 'color:' . esc_attr( $atts['colortwo'] ) . ';';
	}
	else {
		$colortwo ="";
	}

	if( !empty( $atts['colortwo'] ) ) {
		$colorTwoStyle = ' style="' . $colortwo . '"';
	} else {
		$colorTwoStyle = "";
	}

	if( !empty( $atts['customclass'] ) ) {
		$customClass = ' ' . esc_attr( $atts['customclass'] );
	} else {
		$customClass = "";
	}

	$output .= '<div class="counter' . $customClass . '">';
	
		$output .= '<div class="counter-images"></div>';

		$output .= '<div class="counter-box">';
			
			$output .= '<div class="counter-box-general-wrapper"' . $colorOneStyle . '>';
			
				$output .= '<div class="counter-box-general-content-wrapper">';
					
					$output .= '<div class="counter-box-general-content">';
					
						if( !empty( $atts['toplefttext'] ) or !empty( $atts['toprighttext'] ) or !empty( $atts['topbottomtext'] ) ) {
					
							$output .= '<div class="counter-box-general-content-top">';
							
								if( !empty( $atts['toplefttext'] ) ) {
								
									$output .= '<div class="left">' . esc_attr( $atts['toplefttext'] ) . '</div>';
									
								}
							
								if( !empty( $atts['toprighttext'] ) ) {
								
									$output .= '<div class="right">' . esc_attr( $atts['toprighttext'] ) . '</div>';
									
								}
							
								if( !empty( $atts['topbottomtext'] ) ) {
								
									$output .= '<div class="bottom">' . esc_attr( $atts['topbottomtext'] ) . '</div>';
									
								}
					
							$output .= '</div>';
					
						}
						
						if( !empty( $atts['days'] ) or !empty( $atts['monthyear'] ) ) {
							
							$output .= '<div class="counter-box-general-content-date">';
							
								$output .= '<div class="counter-box-general-content-date-left">';
									$output .= '<div class="counter-box-general-content-date-left-left"' . $colorOneBorderStyle . '></div>';
									$output .= '<div class="counter-box-general-content-date-left-top"' . $colorOneBorderStyle . '></div>';
									$output .= '<div class="counter-box-general-content-date-left-bottom"' . $colorOneBorderStyle . '></div>';
								$output .= '</div>';
							
								$output .= '<div class="counter-box-general-content-date-center">';
								
									if( !empty( $atts['topbottomtext'] ) ) {
										
										$output .= '<div class="counter-box-general-content-date-days"' . $colorTwoStyle . '>' . esc_attr( $atts['days'] ) . '</div>';
									}
								
									if( !empty( $atts['monthyear'] ) ) {
										
										$output .= '<div class="counter-box-general-content-date-monthyear"' . $colorOneStyle . '>' . esc_attr( $atts['monthyear'] ) . '</div>';
									}
					
								$output .= '</div>';

								$output .= '<div class="counter-box-general-content-date-right">';
									$output .= '<div class="counter-box-general-content-date-right-top"' . $colorOneBorderStyle . '></div>';
									$output .= '<div class="counter-box-general-content-date-right-right"' . $colorOneBorderStyle . '></div>';
									$output .= '<div class="counter-box-general-content-date-right-bottom"' . $colorOneBorderStyle . '></div>';
								$output .= '</div>';
					
							$output .= '</div>';
							
						}
						
						if( !empty( $atts['address'] ) ) {
							
							$output .= '<div class="counter-box-general-content-address">' . esc_attr( $atts['address'] ) . '</div>';
							
						}
				
						if( !empty( $atts['counterdate'] ) ) {
							
	
						$output .= "<div class='DateCountdown' data-date='" . esc_attr( $atts['counterdate'] ) . "'></div>";
						
						$output .= "<script>
												jQuery(document).ready(function($){
													 $('.DateCountdown').TimeCircles({
														  'animation': 'smooth',
														  'use_background': false,
														  'bg_width': 0,
														  'fg_width': 0,
														  'time': {
															  'Days': {
																  'text': '" . esc_html__("Days", 'eventstation') . "',
																  'show': true
															  },
															  'Hours': {
																  'text': '" . esc_html__("Hours", 'eventstation') . "',
																  'show': true
															  },
															  'Minutes': {
																  'text': '" . esc_html__("Minutes", 'eventstation') . "',
																  'show': true
															  },
															  'Seconds': {
																  'text': '" . esc_html__("Seconds", 'eventstation') . "',
																  'show': true
															  }
														  }
													 }); 
												});
											</script>";
						
						}
							
						if( !empty( $atts['buttontext'] ) ) {
							
							if( !empty( $atts['productid'] ) ) {
								
								$package_link = '?add-to-cart=' . esc_attr( $atts['productid'] );
								
							} else {
								
								$package_link = esc_url( $atts['buttonlink'] );
								
							}
							
							if( !empty( $atts['productid'] ) ) {
								
								$package_icon = '<i class="fa fa-chevron-right" aria-hidden="true"></i>';
								
							} else {
								
								$package_icon = '<i class="fa fa-chevron-right" aria-hidden="true"></i>';
								
							}
							
							$output .= '<div class="counter-box-button"><a href="' . $package_link . '" title="' . esc_attr( $atts['buttontext'] ) . '"><span>' . esc_attr( $atts['buttontext'] ) . '</span>' . $package_icon . '</a></div>';
							
						}
					
					$output .= '</div>';
				
				$output .= '</div>';
			
			$output .= '</div>';
		
		$output .= '</div>';
		
	$output .= '</div>';

	return $output;
}
add_shortcode("counter", "counter_shortcode");

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Counter", 'eventstation'),
		"base" => "counter",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/counter.png',
		"description" =>esc_html__( 'Counter widget.','eventstation'),
		"params" => array(
			array(
				"type" => "attach_images",
				"class" => "",
				"heading" => esc_html__("Slider Images",'eventstation'),
				"description" => esc_html__( "You can the upload your slider images.", 'eventstation' ),
				"param_name" => "sliderimages",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Top Left Text",'eventstation'),
				"description" => esc_html__("You can enter the top left text.", 'eventstation'),
				"param_name" => "toplefttext",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Top Right Text",'eventstation'),
				"description" => esc_html__("You can enter the top right text.", 'eventstation'),
				"param_name" => "toprighttext",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Top Bottom Text",'eventstation'),
				"description" => esc_html__("You can enter the top bottom text.", 'eventstation'),
				"param_name" => "topbottomtext",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Days",'eventstation'),
				"description" => esc_html__("You can enter the event days. Example: 22, 23, 24, 25.", 'eventstation'),
				"param_name" => "days",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Month - Year",'eventstation'),
				"description" => esc_html__("You can enter the event month and year. Example: June 2016.", 'eventstation'),
				"param_name" => "monthyear",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Address",'eventstation'),
				"description" => esc_html__("You can enter the event adress.", 'eventstation'),
				"param_name" => "address",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Counter Date",'eventstation'),
				"description" => esc_html__("You can enter the counter days. Example: 2040-01-01 50:00:00.", 'eventstation'),
				"param_name" => "counterdate",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Button Text",'eventstation'),
				"description" => esc_html__("You can enter the button title.", 'eventstation'),
				"param_name" => "buttontext",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Button Link",'eventstation'),
				"description" => esc_html__("You can enter the button link.", 'eventstation'),
				"param_name" => "buttonlink",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Product ID",'eventstation'),
				"description" => esc_html__("You can enter the WooCommerce product id. How to learn WooCommerce product id?: https://goo.gl/DEJ5fU", 'eventstation'),
				"param_name" => "productid",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Color One",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "colorone",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Color Two",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "colortwo",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}
/*------------- COUNTER END -------------*/

/*------------- BLOG POSTS START -------------*/
function blogposts_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'style' => '',
			'querytype' => '',
			'tag' => '',
			'category' => '',
			'excludeposts' => '',
			'postcount' => '',
			'designfeatures' => ''
		), $atts
	);
	
	$output = '';

	if( !empty( $atts['excludeposts'] ) ) :
		$excludeposts = $atts['excludeposts'];
		$excludeposts = esc_attr( explode( ',', $excludeposts ) );
	else:
		$excludeposts = "";
	endif;

	if( !empty( $atts['postcount'] ) ) :
		$postcount = esc_attr( $atts['postcount'] );
	else:
		$postcount = "";
	endif;

	if( !empty( $atts['category'] ) ) :
		$category = esc_attr( $atts['category'] );
	else:
		$category = "";
	endif;

	if( !empty( $atts['tag'] ) ) :
		$tag = esc_attr( $atts['tag'] );
	else:
		$tag = "";
	endif;
	

	$args_blogposts_left = array(
		'posts_per_page' => 1,
		'post__not_in' => $excludeposts,
		'cat' => $category,
		'tag' => $tag,
		'post_status' => 'publish',
		'ignore_sticky_posts' => true,
		'post_type' => 'post'
	);
	
	$args_blogposts_right = array(
		'posts_per_page' => $postcount,
		'post__not_in' => $excludeposts,
		'cat' => $category,
		'tag' => $tag,
		'post_status' => 'publish',
		'ignore_sticky_posts' => true,
		'post_type' => 'post',
		'offset' => 1
	);
	
	
	$output .= '<div class="blog-posts-widget">';
		
		$output .= '<div class="row">';
		
			if( $atts['style'] == "stylev2" ) {
				$output .= '<div class="col-sm-6 col-xs-12">';
			} else {
				$output .= '<div class="col-sm-8 col-xs-12">';
			}
			
				$output .= '<ul>';
					$wp_query_blogposts_left = new WP_Query( $args_blogposts_left );
					while ( $wp_query_blogposts_left->have_posts() ) :
					$wp_query_blogposts_left->the_post();
						$output .= '<li class="animate anim-fadeIn animate-delay-0">';
						
							if( strstr( $atts['designfeatures'], "image" ) ) {
								if ( has_post_thumbnail( get_the_ID() ) ) {
									$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'eventstation-blog-posts' );
									$image = '<div class="image">';
										$image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
									$image .= '</div>';
								} else {
									$image = "";
								}
							} else {
								$image = "";
							}
							
							if( strstr( $atts['designfeatures'], "information" ) ) {
								$post_information = '<ul class="post-information">
									<li class="author">' . esc_html__( 'Author:', 'eventstation' ) . ' <span>' . get_the_author_posts_link() . '</span></li>
									<li class="separator">&#45;</li>
									<li class="date">' . esc_html__( 'Date:', 'eventstation' ) . ' <span>' . get_the_time( get_option( 'date_format' ) ) . '</span></li>
								</ul>';
							} else {
								$post_information = "";
							}
										
							if( strstr( $atts['designfeatures'], "excerpt" ) ) {
								$excerpt = '<div class="post-excerpt"><p>' . get_the_excerpt() . '</p></div>';
							} else {
								$excerpt = "";
							}
							
							if( strstr( $atts['designfeatures'], "readmore" ) ) {
								$readmore = '<div class="post-read-more"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '" class="more">' . esc_html__( 'Read More', 'eventstation' ) . ' <i class="fa fa-chevron-right"></i></a></div>';
							} else {
								$readmore = "";
							}

							$output .= '<article class="post">' . $image . $post_information . '<h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>';
							$output .= $excerpt . $readmore . '</article>';
						
						$output .= '</li>';
					endwhile;
					wp_reset_postdata();
				$output .= '</ul>';
			$output .= '</div>';
			
			if( $atts['style'] == "stylev2" ) {
				$output .= '<div class="col-sm-6 col-xs-12">';
					$output .= '<ul class="row">';
						$wp_query_blogposts_right = new WP_Query( $args_blogposts_right );
						while ( $wp_query_blogposts_right->have_posts() ) :
						$wp_query_blogposts_right->the_post();
							$output .= '<li class="col-sm-6 col-xs-12 animate anim-fadeIn">';
							
								if( strstr( $atts['designfeatures'], "image" ) ) {
									if ( has_post_thumbnail( get_the_ID() ) ) {
										$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'eventstation-blog-posts' );
										$image = '<div class="image">';
											$image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
										$image .= '</div>';
									} else {
										$image = "";
									}
								} else {
									$image = "";
								}
								
								if( strstr( $atts['designfeatures'], "information" ) ) {
									$post_information = '<ul class="post-information">
										<li class="author">' . esc_html__( 'Author:', 'eventstation' ) . ' <span>' . get_the_author_posts_link() . '</span></li>
										<li class="separator">&#45;</li>
										<li class="date">' . esc_html__( 'Date:', 'eventstation' ) . ' <span>' . get_the_time( get_option( 'date_format' ) ) . '</span></li>
									</ul>';
								} else {
									$post_information = "";
								}
											
								if( strstr( $atts['designfeatures'], "excerpt" ) ) {
									$excerpt = '<div class="post-excerpt"><p>' . get_the_excerpt() . '</p></div>';
								} else {
									$excerpt = "";
								}

								$output .= '<article class="post">' . $image . $post_information . '<h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>';
								$output .= $excerpt . '</article>';
							
							$output .= '</li>';
						endwhile;
						wp_reset_postdata();
					$output .= '</ul>';
					
				$output .= '</div>';
			} else {
				$output .= '<div class="col-sm-4 col-xs-12">';
					$output .= '<ul>';
						$wp_query_blogposts_right = new WP_Query( $args_blogposts_right );
						while ( $wp_query_blogposts_right->have_posts() ) :
						$wp_query_blogposts_right->the_post();
							$output .= '<li class="animate">';
							
								if( strstr( $atts['designfeatures'], "image" ) ) {
									if ( has_post_thumbnail( get_the_ID() ) ) {
										$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'eventstation-blog-posts' );
										$image = '<div class="image">';
											$image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
										$image .= '</div>';
									} else {
										$image = "";
									}
								} else {
									$image = "";
								}
								
								if( strstr( $atts['designfeatures'], "information" ) ) {
									$post_information = '<ul class="post-information">
										<li class="author">' . esc_html__( 'Author:', 'eventstation' ) . ' <span>' . get_the_author_posts_link() . '</span></li>
										<li class="separator">&#45;</li>
										<li class="date">' . esc_html__( 'Date:', 'eventstation' ) . ' <span>' . get_the_time( get_option( 'date_format' ) ) . '</span></li>
									</ul>';
								} else {
									$post_information = "";
								}
											
								if( strstr( $atts['designfeatures'], "excerpt" ) ) {
									$excerpt = '<div class="post-excerpt"><p>' . get_the_excerpt() . '</p></div>';
								} else {
									$excerpt = "";
								}

								$output .= '<article class="post">' . $image . $post_information . '<h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>';
								$output .= $excerpt . '</article>';
							
							$output .= '</li>';
						endwhile;
						wp_reset_postdata();
					$output .= '</ul>';
					
				$output .= '</div>';
			}
		
		$output .= '</div>';
	
	$output .= '</div>';
	
	return $output;
}
add_shortcode("blogposts", "blogposts_shortcode");

function image_blog_style( $settings, $value ) {
	return '<div class="my_param_block">'
	.'<input name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput ' .
	esc_attr( $settings['param_name'] ) . ' ' .
	esc_attr( $settings['type'] ) . '_field" type="hidden" value="' . esc_attr( $value ) . '" />
	<img src="'.esc_attr( $value ).'">'.
	'</div>';
}
vc_add_shortcode_param( 'blog_style', 'image_blog_style' );

if(function_exists('vc_map')){

	$posts_list = get_posts(array(
		'orderby' => 'title',
		'order' => 'ASC',
		'post_type' => 'post'
	));

	$posts_array = array();
	$posts_array[__("All Categories", 'eventstation')] = "-";
	foreach($posts_list as $post) {
		$posts_array[$post->post_title . " (id:" . $post->ID . ")"] = $post->ID;
	}

	$post_categories = get_terms("category");
	$post_categories_array = array();
	$post_categories_array[__("All Categories", 'eventstation')] = "-";
	foreach($post_categories as $post_category) {
		$post_categories_array[$post_category->name] =  $post_category->term_id;
	}

	vc_map( array(
		"name" => esc_html__("Blog Posts", 'eventstation'),
		"base" => "blogposts",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/blog.png',
		"description" =>esc_html__( 'Blog latest posts widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Grid Style",'eventstation'),
				"description" => esc_html__("You can select the design style.",'eventstation'),
				"param_name" => "style",
				"value" => array(
					esc_html__("Style v1", 'eventstation') => "stylev1",
					esc_html__("Style v2", 'eventstation') => "stylev2"
				)
			),
			array(
				'type'	=> 'blog_style',
				'heading'	=> '',
				'param_name'	=> 'blogstyleone',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/blog-1.jpg',
				'dependency' => array('element' => "style", 'value' => array('stylev1'))			
			),
			array(
				'type'	=> 'blog_style',
				'heading'	=> '',
				'param_name'	=> 'blogstyletwo',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/blog-2.jpg',
				'dependency' => array('element' => "style", 'value' => array('stylev2'))			
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Category",'eventstation'),
				"description" => esc_html__("You can select the category.",'eventstation'),
				"param_name" => "category",
				"value" => $post_categories_array
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Tag",'eventstation'),
				"description" => esc_html__("You can enter the the tag you want to display the latest posts.",'eventstation'),
				"param_name" => "tag",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Exclude Posts",'eventstation'),
				"description" => esc_html__("You can enter the exclude posts(s) id. Separate with commas 1,2,3 etc.",'eventstation'),
				"param_name" => "excludeposts",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Post Count",'eventstation'),
				"description" => esc_html__("You can enter the post post count.",'eventstation'),
				"param_name" => "postcount",
				"value" => "",
			),
			array(
				"type" => "checkbox",
				"admin_label" => false,
				"class" => "",
				"heading" => esc_html__("Design Features",'eventstation'),
				"param_name" => "designfeatures",
				"description" => esc_html__("You can select the design features.",'eventstation'),
				"value" => array(
					esc_html__("Feature Image", 'eventstation') => "image",
					esc_html__("Post Information", 'eventstation') => "information",
					esc_html__("Post Excerpt", 'eventstation') => "excerpt",
					esc_html__("Read More Button", 'eventstation') => "readmore"
				)
			)
		)
	) );
}
/*------------- BLOG POSTS END -------------*/

/*------------- STEP BOXES START -------------*/
function step_boxes_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'column1title' => '',
			'column1number' => '',
			'column2title' => '',
			'column2number' => '',
			'column3title' => '',
			'column3number' => '',
			'column4title' => '',
			'column4number' => '',
			'column5title' => '',
			'column5number' => '',
			'column6title' => '',
			'column6number' => ''
		), $atts
	);
	
	$output = '';
		
		if( !empty( $atts['column1number'] ) or !empty( $atts['column2number'] ) or !empty( $atts['column3number'] ) or !empty( $atts['column4number'] ) or !empty( $atts['column5number'] ) ) {
			$output .= '<div class="step-boxes">';
				if( !empty( $atts['column1number'] ) ) {
							
					if( !empty( $atts['column1number'] ) ) {
						$column1number = esc_attr( $atts['column1number'] );
					} else {
						$column1number = "1";
					}
					
					$random_id = rand( 0, 99999999 );
					$random_id = $column1number * $random_id;
			
					$output .= '<div class="step-boxes-item step-boxes-item-1 step-boxes-item-1-' . esc_attr( $random_id ) . '">';
						$output .= '<div class="step-boxes-item-wrapper step-boxes-item-1">';
							$output .= '<div class="step-boxes-item-wrapper-content">';
								if( !empty( $atts['column1number'] ) ) {
									$output .= '<h3>' . esc_attr( $atts['column1number'] ) . '</h3>';
								}
								if( !empty( $atts['column1title'] ) ) {
									$output .= '<p>' . esc_attr( $atts['column1title'] ) . '</p>';
								}
							$output .= '</div>';
						$output .= '</div>';
					
						$output .= '<script type="text/javascript">
											jQuery(document).ready(function($){
												$(".step-boxes-item-1-' . esc_attr( $random_id ) . ' h3").counterUp({
													delay: 10,
													time: 1200
												});
											});
										</script>';
										
					$output .= '</div>';
				}
				if( !empty( $atts['column2number'] ) ) {
							
					if( !empty( $atts['column2number'] ) ) {
						$column2number = esc_attr( $atts['column2number'] );
					} else {
						$column2number = "1";
					}
					
					$random_id = rand( 0, 99999999 );
					$random_id = $column2number * $random_id;
					
					$output .= '<div class="step-boxes-item step-boxes-item-2 step-boxes-item-2-' . esc_attr( $random_id ) . '">';
						$output .= '<div class="step-boxes-item-wrapper step-boxes-item-2">';
							$output .= '<div class="step-boxes-item-wrapper-content">';
								if( !empty( $atts['column2number'] ) ) {
									$output .= '<h3>' . esc_attr( $atts['column2number'] ) . '</h3>';
								}
								if( !empty( $atts['column2title'] ) ) {
									$output .= '<p>' . esc_attr( $atts['column2title'] ) . '</p>';
								}
							$output .= '</div>';
						$output .= '</div>';
					
						$output .= '<script type="text/javascript">
											jQuery(document).ready(function($){
												$(".step-boxes-item-2-' . esc_attr( $random_id ) . ' h3").counterUp({
													delay: 10,
													time: 1200
												});
											});
										</script>';
										
					$output .= '</div>';
									
				}
				if( !empty( $atts['column3number'] ) ) {
							
					if( !empty( $atts['column3number'] ) ) {
						$column3number = esc_attr( $atts['column3number'] );
					} else {
						$column3number = "1";
					}
					
					$random_id = rand( 0, 99999999 );
					$random_id = $column3number * $random_id;
					
					$output .= '<div class="step-boxes-item step-boxes-item-3 step-boxes-item-3-' . esc_attr( $random_id ) . '">';
						$output .= '<div class="step-boxes-item-wrapper step-boxes-item-3">';
							$output .= '<div class="step-boxes-item-wrapper-content">';
								if( !empty( $atts['column3number'] ) ) {
									$output .= '<h3>' . esc_attr( $atts['column3number'] ) . '</h3>';
								}
								if( !empty( $atts['column3title'] ) ) {
									$output .= '<p>' . esc_attr( $atts['column3title'] ) . '</p>';
								}
							$output .= '</div>';
						$output .= '</div>';
					
						$output .= '<script type="text/javascript">
											jQuery(document).ready(function($){
												$(".step-boxes-item-3-' . esc_attr( $random_id ) . ' h3").counterUp({
													delay: 10,
													time: 1200
												});
											});
										</script>';
										
					$output .= '</div>';
									
				}
				if( !empty( $atts['column4number'] ) ) {
							
					if( !empty( $atts['column4number'] ) ) {
						$column4number = esc_attr( $atts['column4number'] );
					} else {
						$column4number = "1";
					}
					
					$random_id = rand( 0, 99999999 );
					$random_id = $column4number * $random_id;
					
					$output .= '<div class="step-boxes-item step-boxes-item-4 step-boxes-item-4-' . esc_attr( $random_id ) . '">';
						$output .= '<div class="step-boxes-item-wrapper step-boxes-item-4">';
							$output .= '<div class="step-boxes-item-wrapper-content">';
								if( !empty( $atts['column4number'] ) ) {
									$output .= '<h3>' . esc_attr( $atts['column4number'] ) . '</h3>';
								}
								if( !empty( $atts['column4title'] ) ) {
									$output .= '<p>' . esc_attr( $atts['column4title'] ) . '</p>';
								}
							$output .= '</div>';
						$output .= '</div>';
						
						$output .= '<script type="text/javascript">
											jQuery(document).ready(function($){
												$(".step-boxes-item-4-' . esc_attr( $random_id ) . ' h3").counterUp({
													delay: 10,
													time: 1200
												});
											});
										</script>';
										
					$output .= '</div>';
									
				}
				
				if( !empty( $atts['column5number'] ) ) {
							
					if( !empty( $atts['column5number'] ) ) {
						$column5number = esc_attr( $atts['column5number'] );
					} else {
						$column5number = "1";
					}
					
					$random_id = rand( 0, 99999999 );
					$random_id = $column5number * $random_id;
					
					$output .= '<div class="step-boxes-item step-boxes-item-5 step-boxes-item-5-' . esc_attr( $random_id ) . '">';
						$output .= '<div class="step-boxes-item-wrapper step-boxes-item-5">';
							$output .= '<div class="step-boxes-item-wrapper-content">';
								if( !empty( $atts['column5number'] ) ) {
									$output .= '<h3>' . esc_attr( $atts['column5number'] ) . '</h3>';
								}
								if( !empty( $atts['column5title'] ) ) {
									$output .= '<p>' . esc_attr( $atts['column5title'] ) . '</p>';
								}
							$output .= '</div>';
						$output .= '</div>';
					
						$output .= '<script type="text/javascript">
											jQuery(document).ready(function($){
												$(".step-boxes-item-5-' . esc_attr( $random_id ) . ' h3").counterUp({
													delay: 10,
													time: 1200
												});
											});
										</script>';
										
					$output .= '</div>';
									
				}
				
				if( !empty( $atts['column6number'] ) ) {
							
					if( !empty( $atts['column6number'] ) ) {
						$column5number = esc_attr( $atts['column6number'] );
					} else {
						$column5number = "1";
					}
					
					$random_id = rand( 0, 99999999 );
					$random_id = $column5number * $random_id;
					
					$output .= '<div class="step-boxes-item step-boxes-item-6 step-boxes-item-6-' . esc_attr( $random_id ) . '">';
						$output .= '<div class="step-boxes-item-wrapper step-boxes-item-6">';
							$output .= '<div class="step-boxes-item-wrapper-content">';
								if( !empty( $atts['column6number'] ) ) {
									$output .= '<h3>' . esc_attr( $atts['column6number'] ) . '</h3>';
								}
								if( !empty( $atts['column6title'] ) ) {
									$output .= '<p>' . esc_attr( $atts['column6title'] ) . '</p>';
								}
							$output .= '</div>';
						$output .= '</div>';
					
						$output .= '<script type="text/javascript">
											jQuery(document).ready(function($){
												$(".step-boxes-item-6-' . esc_attr( $random_id ) . ' h3").counterUp({
													delay: 10,
													time: 1200
												});
											});
										</script>';
										
					$output .= '</div>';
									
				}
				
			$output .= '</div>';
		}

	return $output;
}
add_shortcode("step_boxes", "step_boxes_shortcode");

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Step Boxes", 'eventstation'),
		"base" => "step_boxes",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/step_boxes.png',
		"description" =>esc_html__( 'Step boxes widget.','eventstation'),
		"params" => array(
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 1 - Title",'eventstation'),
				"description" => esc_html__("You can enter the step column 1 for title.", 'eventstation'),
				"param_name" => "column1title",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 1 - Number",'eventstation'),
				"description" => esc_html__("You can enter the step column 1 for number.", 'eventstation'),
				"param_name" => "column1number",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 2 - Title",'eventstation'),
				"description" => esc_html__("You can enter the step column 2 for title.", 'eventstation'),
				"param_name" => "column2title",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 2 - Number",'eventstation'),
				"description" => esc_html__("You can enter the step column 2 for number.", 'eventstation'),
				"param_name" => "column2number",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 3 - Title",'eventstation'),
				"description" => esc_html__("You can enter the step column 2 for title.", 'eventstation'),
				"param_name" => "column3title",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 3 - Number",'eventstation'),
				"description" => esc_html__("You can enter the step column 3 for number.", 'eventstation'),
				"param_name" => "column3number",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 4 - Title",'eventstation'),
				"description" => esc_html__("You can enter the step column 4 for title.", 'eventstation'),
				"param_name" => "column4title",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 4 - Number",'eventstation'),
				"description" => esc_html__("You can enter the step column 4 for number.", 'eventstation'),
				"param_name" => "column4number",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 5 - Title",'eventstation'),
				"description" => esc_html__("You can enter the step column 5 for title.", 'eventstation'),
				"param_name" => "column5title",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 5 - Number",'eventstation'),
				"description" => esc_html__("You can enter the step column 5 for number.", 'eventstation'),
				"param_name" => "column5number",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 6 - Title",'eventstation'),
				"description" => esc_html__("You can enter the step column 6 for title.", 'eventstation'),
				"param_name" => "column6title",
				"value" => ""
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Column 6 - Number",'eventstation'),
				"description" => esc_html__("You can enter the step column 6 for number.", 'eventstation'),
				"param_name" => "column6number",
				"value" => ""
			)
		)
	) );
}
/*------------- STEP BOXES END -------------*/

/*------------- SCHEDULE START -------------*/
function schedule_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'style' => ''
		), $atts
	);
	
	$output = '';
	
	if( $atts["style"] == "stylev2" ) {
		$style = " style2";
	} elseif( $atts["style"] == "stylev3" ) {
		$style = " style3";
	} else {
		$style = " style1";
	}
	
	$output .= '<div class="schedule-widget' . esc_attr( $style ) . '">';
		$schedule_days_terms = get_terms( 'schedule_days' );
		if ( ! empty( $schedule_days_terms ) && ! is_wp_error( $schedule_days_terms ) ){
			$output .= '<ul class="nav nav-tabs animate anim-fadeInDown animate-delay-0" role="tablist">';
				foreach ( $schedule_days_terms as $schedule_days_term ) {
					$schedule_days_name = $schedule_days_term->name;
					$schedule_days_excerpt = $schedule_days_term->description;
					
					$output .= '<li role="presentation"><a href="#schedule_id_' . esc_attr( $schedule_days_term->term_id ) . '" aria-controls="schedule_id_' . esc_attr( $schedule_days_term->term_id ) . '" role="tab" data-toggle="tab">';
					
						if( !empty( $schedule_days_name ) ) {
							$output .= '<h3>' . esc_attr( $schedule_days_name ) . '</h3>';
						}
						
						if( !empty( $schedule_days_excerpt ) ) {
							$output .= '<span>' . esc_attr( $schedule_days_excerpt ) . '</span>';
						}
						
					$output .= '</a></li>';
				}
			$output .= '</ul>';
		}
		
		if ( ! empty( $schedule_days_terms ) && ! is_wp_error( $schedule_days_terms ) ){
			$output .= '<div class="tab-content">';
			
				foreach ( $schedule_days_terms as $schedule_days_term ) {
					$output .= '<div role="tabpanel" class="tab-pane" id="schedule_id_' . esc_attr( $schedule_days_term->term_id ) . '">';
					
						$schedule_days_args = array (
							'post_type' => 'schedule',
							'ignore_sticky_posts' => true,
							'tax_query' => array(
								array(
									'taxonomy' => 'schedule_days',
									'field'    => 'id',
									'terms'    => array( $schedule_days_term->term_id ),
								),
							),
						);
						
						$schedule_days_query = new WP_Query( $schedule_days_args );
						
						if ( $schedule_days_query->have_posts() ) {
							$output .= '<ul class="tab-content-schedule-list">';
								while ( $schedule_days_query->have_posts() ) {
									$schedule_days_query->the_post();
                                    $schedule_hour = get_post_meta( get_the_ID(), "schedule_hour", true );
                                    $schedule_speaker = get_post_meta( get_the_ID(), "schedule_speaker", true );
                                    $schedule_topic = get_post_meta( get_the_ID(), "schedule_topic", true );
                                    $schedule_salon = get_post_meta( get_the_ID(), "schedule_salon", true );
									$output .= '<li class="animate anim-fadeInDown">';
									
										if( !empty( $schedule_hour ) ) {
											$output .= '<div class="hour">' . esc_attr( $schedule_hour ) . '</div>';
										}
										
										$output .= '<div class="title">';
											$output .= '<span class="heading">' . get_the_title() . '</span>';
											
											if( !empty( $schedule_speaker ) ) {
												$output .= '<span class="speaker">' . esc_attr( $schedule_speaker ) . ' / </span>';
											}
											
											if( !empty( $schedule_topic ) ) {
												$output .= '<span class="topic">' . esc_attr( $schedule_topic ) . ' / </span>';
											}
											
											if( !empty( $schedule_salon ) ) {
												$output .= '<span class="salon">' . esc_attr( $schedule_salon ) . '</span>';
											}
											
										$output .= '</div>';
									$output .= '</li>';
								}
							$output .= '</ul>';
						} else {
						}
						wp_reset_postdata();
						
					$output .= '</div>';
				}
				
			$output .= '</div>';
			
		}
		
	$output .= '</div>';

	return $output;
}
add_shortcode("schedule", "schedule_shortcode");

function image_schedule_style( $settings, $value ) {
	return '<div class="my_param_block">'
	.'<input name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput ' .
	esc_attr( $settings['param_name'] ) . ' ' .
	esc_attr( $settings['type'] ) . '_field" type="hidden" value="' . esc_attr( $value ) . '" />
	<img src="'.esc_attr( $value ).'">'.
	'</div>';
}
vc_add_shortcode_param( 'schedule_style', 'image_schedule_style' );

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Schedule", 'eventstation'),
		"base" => "schedule",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/schedule.png',
		"description" =>esc_html__( 'Schedule widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style",'eventstation'),
				"description" => esc_html__("You can select the design style.",'eventstation'),
				"param_name" => "style",
				"value" => array(
					esc_html__("Style 1", 'eventstation') => "stylev1",
					esc_html__("Style 2", 'eventstation') => "stylev2",
					esc_html__("Style 3", 'eventstation') => "stylev3"
				)
			),
			array(
				'type'	=> 'schedule_style',
				'heading'	=> '',
				'param_name'	=> 'schedulestyleone',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/schedule-1.jpg',
				'dependency' => array('element' => "style", 'value' => array('stylev1'))			
			),
			array(
				'type'	=> 'schedule_style',
				'heading'	=> '',
				'param_name'	=> 'schedulestyletwo',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/schedule-2.jpg',
				'dependency' => array('element' => "style", 'value' => array('stylev2'))			
			),
			array(
				'type'	=> 'schedule_style',
				'heading'	=> '',
				'param_name'	=> 'schedulestylethree',
				'value' => get_template_directory_uri() . '/admin/assets/images/admin/vc-featured/schedule-3.jpg',
				'dependency' => array('element' => "style", 'value' => array('stylev3'))			
			),
		)
	) );
}
/*------------- SCHEDULE END -------------*/

/*------------- GALLERY START -------------*/
function eventstationgallery_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'column' => '',
			'images' => '',
			'video1' => '',
			'video1image' => '',
			'video2' => '',
			'video2image' => '',
			'video3' => '',
			'video3image' => '',
			'video4' => '',
			'video4image' => ''
		), $atts
	);
	
	$output = '';
	
	if( $atts["column"] == "four" ) {
		$column = " four-gallery";
	} else {
		$column = " three-gallery";
	}
		
	if( !empty( $atts['images'] ) ) {
		$image = esc_attr( $atts['images'] );
	} else {
		$image = "";
	}
		
	$random_id = rand( 0, 99999999 );
	
	$gallery_group_name = "gallery_name_" . esc_attr( $random_id );
	
	$output .= '<div class="event-station-gallery' . esc_attr( $column ) . '">';
	
		if( !empty( $atts["video1"] ) and !empty( $atts["video1image"] ) ) {
			$video1_image_url = wp_get_attachment_image_src( $atts["video1image"], "eventstation-gallery" );
			$output .= '<div class="gallery-grid video-grid"><a href="' . esc_url( $atts['video1'] ) . '" data-fullscreenmode="true" data-autoslide="true" data-thumbnail="' . esc_url( $video1_image_url[0] ) . '" class="html5lightbox" data-group="' . esc_attr( $gallery_group_name ) . '" title="' . esc_html__( 'Gallery Video', 'eventstation' ) . '"><img alt="' . esc_html__( 'Video Thumbnail', 'eventstation' ) . '" src="' . esc_url( $video1_image_url[0] ) . '"><div class="overlay"></div></a></div>';
		}
	
		if( !empty( $atts["video2"] ) and !empty( $atts["video2image"] ) ) {
			$video2_image_url = wp_get_attachment_image_src( $atts["video2image"], "eventstation-gallery" );
			$output .= '<div class="gallery-grid video-grid"><a href="' . esc_url( $atts['video2'] ) . '" data-fullscreenmode="true" data-autoslide="true" data-thumbnail="' . esc_url( $video2_image_url[0] ) . '" class="html5lightbox" data-group="' . esc_attr( $gallery_group_name ) . '" title="' . esc_html__( 'Gallery Video', 'eventstation' ) . '"><img alt="' . esc_html__( 'Video Thumbnail', 'eventstation' ) . '" src="' . esc_url( $video2_image_url[0] ) . '"><div class="overlay"></div></a></div>';
		}
	
		if( !empty( $atts["video3"] ) and !empty( $atts["video3image"] ) ) {
			$video3_image_url = wp_get_attachment_image_src( $atts["video3image"], "eventstation-gallery" );
			$output .= '<div class="gallery-grid video-grid"><a href="' . esc_url( $atts['video3'] ) . '" data-fullscreenmode="true" data-autoslide="true" data-thumbnail="' . esc_url( $video3_image_url[0] ) . '" class="html5lightbox" data-group="' . esc_attr( $gallery_group_name ) . '" title="' . esc_html__( 'Gallery Video', 'eventstation' ) . '"><img alt="' . esc_html__( 'Video Thumbnail', 'eventstation' ) . '" src="' . esc_url( $video3_image_url[0] ) . '"><div class="overlay"></div></a></div>';
		}
	
		if( !empty( $atts["video4"] ) and !empty( $atts["video4image"] ) ) {
			$video4_image_url = wp_get_attachment_image_src( $atts["video4image"], "eventstation-gallery" );
			$output .= '<div class="gallery-grid video-grid"><a href="' . esc_url( $atts['video4'] ) . '" data-fullscreenmode="true" data-autoslide="true" data-thumbnail="' . esc_url( $video4_image_url[0] ) . '" class="html5lightbox" data-group="' . esc_attr( $gallery_group_name ) . '" title="' . esc_html__( 'Gallery Video', 'eventstation' ) . '"><img alt="' . esc_html__( 'Video Thumbnail', 'eventstation' ) . '" src="' . esc_url( $video4_image_url[0] ) . '"><div class="overlay"></div></a></div>';
		}
		
		if( !empty( $atts['images'] ) ) {
			$image_ids = explode( ',', $image ); 
			foreach( $image_ids as $image_id ){
				$image_url_full = wp_get_attachment_image_src( $image_id, "full" );
				$image_url_thumb = wp_get_attachment_image_src( $image_id, "eventstation-gallery" );
				$output .= '<div class="gallery-grid image-grid animate anim-fadeIn"><a href="' . esc_url( $image_url_full[0] ) . '" data-thumbnail="' . esc_url( $image_url_thumb[0] ) . '" class="html5lightbox" data-group="' . esc_attr( $gallery_group_name ) . '" title="' . esc_html__( 'Gallery Image', 'eventstation' ) . '"><img alt="' . esc_html__( 'Gallery Thumbnail', 'eventstation' ) . '" src="' . esc_url( $image_url_thumb[0] ) . '" /><div class="overlay"></div></a></div>';
			}			
		}
		
	$output .= '</div>';

	return $output;
}
add_shortcode("eventstationgallery", "eventstationgallery_shortcode");

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Event Station Gallery", 'eventstation'),
		"base" => "eventstationgallery",
		"class" => "",
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/gallery.png',
		"description" =>esc_html__( 'Gallery widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Column",'eventstation'),
				"description" => esc_html__("You can select the design column.",'eventstation'),
				"param_name" => "column",
				"value" => array(
					esc_html__("Three", 'eventstation') => "three",
					esc_html__("Four", 'eventstation') => "four",
				)
			),
			array(
				"type" => "attach_images",
				"class" => "",
				"heading" => esc_html__("Images",'eventstation'),
				"description" => esc_html__( "You can the upload your slider images.", 'eventstation' ),
				"param_name" => "images",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Gallery Video - 1 URL",'eventstation'),
				"description" => esc_html__("You can enter the YouTube and Vimeo url. Example: https://www.youtube.com/embed/YE7VzlLtp-4 or https://player.vimeo.com/video/1084537", 'eventstation'),
				"param_name" => "video1",
				"value" => ""
			),
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__("Gallery Video - 1 Image",'eventstation'),
				"description" => esc_html__( "You can the upload your video image.", 'eventstation' ),
				"param_name" => "video1image",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Gallery Video - 2 URL",'eventstation'),
				"description" => esc_html__("You can enter the YouTube and Vimeo url. Example: https://www.youtube.com/embed/YE7VzlLtp-4 or https://player.vimeo.com/video/1084537", 'eventstation'),
				"param_name" => "video2",
				"value" => ""
			),
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__("Gallery Video - 2 Image",'eventstation'),
				"description" => esc_html__( "You can the upload your video image.", 'eventstation' ),
				"param_name" => "video2image",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Gallery Video - 3 URL",'eventstation'),
				"description" => esc_html__("You can enter the YouTube and Vimeo url. Example: https://www.youtube.com/embed/YE7VzlLtp-4 or https://player.vimeo.com/video/1084537", 'eventstation'),
				"param_name" => "video3",
				"value" => ""
			),
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__("Gallery Video - 3 Image",'eventstation'),
				"description" => esc_html__( "You can the upload your video image.", 'eventstation' ),
				"param_name" => "video3image",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Gallery Video - 4 URL",'eventstation'),
				"description" => esc_html__("You can enter the YouTube and Vimeo url. Example: https://www.youtube.com/embed/YE7VzlLtp-4 or https://player.vimeo.com/video/1084537", 'eventstation'),
				"param_name" => "video4",
				"value" => ""
			),
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__("Gallery Video - 4 Image",'eventstation'),
				"description" => esc_html__( "You can the upload your video image.", 'eventstation' ),
				"param_name" => "video4image",
				"value" => "",
			),
		)
	) );
}
/*------------- GALLERY END -------------*/

/*------------- CAROUSEL SERVICE BOX START -------------*/
function carousel_service_box_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'style' => ''
		), $atts
	);
	
	$output = '';

	if( !empty( $atts['customclass'] ) ) {
		$customClass = ' ' . esc_attr( $atts['customclass'] );
	} else {
		$customClass = "";
	}
	
	if( !empty( $atts['style'] ) ) {
		$style = " " . esc_attr( $atts['style'] );
	} else {
		$style = "";
	}
	
		
	$random_id = rand( 0, 99999999 );
	
	$output .= '<div class="carousel-service-box-wrapper' . $style . '">';
		$output .= '<div class="carousel-service-box-widget carousel-service-box-widget-' . $random_id . $style . $customClass . '">';
			$output .= do_shortcode( $content );
		$output .= '</div>';
		$output .= '<div class="carousel-service-box-navigation">
								<a class="carousel-service-box-navigation-prev">&larr;</a>
								<a class="carousel-service-box-navigation-next">&rarr;</a>
							</div>';
	$output .= '</div>';
		
	$output .= "<script>
						jQuery(document).ready(function($){
							$('.carousel-service-box-widget-" . $random_id . "').owlCarousel({
								loop:true,
								nav:false,
								margin: 30,
								dots:false,
								responsive:{
									0:{
										items:1,
									},
									768:{
										items:2,
									}
								}
							});
								
							owl = $('.carousel-service-box-widget-" . $random_id . "').owlCarousel();
							$('.carousel-service-box-navigation-prev').click(function () {
								owl.trigger('prev.owl.carousel');
							});

							$('.carousel-service-box-navigation-next').click(function () {
								owl.trigger('next.owl.carousel');
							});
						});
					</script>";

	return $output;
}
add_shortcode("carousel_service_box", "carousel_service_box_shortcode");

function carousel_service_box_item_shortcode( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'image' => '',
			'title' => '',
			'excerpt' => '',
			'text' => '',
			'icon' => '',
			'titlefontsize' => '',
			'textfontsize' => '',
			'titlecolor' => '',
			'textcolor' => '',
			'iconbackground' => '',
			'iconcolor' => '',
			'iconbordercolor' => '',
			'readmorebg' => '',
			'readmorecolor' => '',
			'customclass' => '',
		), $atts
	);
	
	$output = '';
	
		$allowed_html = array ( 'br' => array() );
	
		if( !empty( $atts['titlecolor'] ) ) {
			$titlecolor = 'color:' . esc_attr( $atts['titlecolor'] ) . ';';
		}
		else {
			$titlecolor ="";
		}

		if( !empty( $atts['titlefontsize'] ) ) {
			$titlefontsize = 'font-size:' . esc_attr( $atts['titlefontsize'] ) . ';';
		}
		else {
			$titlefontsize ="";
		}
		
		if( !empty( $atts['titlecolor'] ) or !empty( $atts['titlefontsize'] ) ) {
			$titleStyle = ' style="' . $titlecolor . $titlefontsize . '"';
		} else {
			$titleStyle = "";
		}
	
		if( !empty( $atts['titlecolor'] ) or !empty( $atts['titlefontsize'] ) ) {
			$titleStyle = ' style="' . $titlecolor . $titlefontsize . '"';
		} else {
			$titleStyle = "";
		}
		
		if( !empty( $atts['textcolor'] ) ) {
			$textcolor = 'color:' . esc_attr( $atts['textcolor'] ) . ';';
		}
		else {
			$textcolor ="";
		}

		if( !empty( $atts['textfontsize'] ) ) {
			$textfontsize = 'font-size:' . esc_attr( $atts['textfontsize'] ) . ';';
		}
		else {
			$textfontsize ="";
		}
		
		if( !empty( $atts['textcolor'] ) or !empty( $atts['textfontsize'] ) ) {
			$textStyle = ' style="' . $textcolor . $textfontsize . '"';
		} else {
			$textStyle = "";
		}
	
		if( !empty( $atts['iconcolor'] ) ) {
			$iconcolor = 'color:' . esc_attr( $atts['iconcolor'] ) . ';';
		}
		else {
			$iconcolor ="";
		}

		if( !empty( $atts['iconbackground'] ) ) {
			$iconbackground = 'background:' . esc_attr( $atts['iconbackground'] ) . ';';
		}
		else {
			$iconbackground ="";
		}

		if( !empty( $atts['iconbordercolor'] ) ) {
			$iconbordercolor = 'border-color:' . esc_attr( $atts['iconbordercolor'] ) . ';';
		}
		else {
			$iconbordercolor ="";
		}
		
		if( !empty( $atts['iconcolor'] ) or !empty( $atts['iconbackground'] ) ) {
			$iconStyle = ' style="' . $iconcolor . $iconbackground . '"';
		} else {
			$iconStyle = "";
		}
		
		if( !empty( $atts['iconcolor'] ) or !empty( $atts['iconbackground'] )  or !empty( $atts['iconbordercolor'] ) ) {
			$iconStyle2 = ' style="' . $iconcolor . $iconbackground . $iconbordercolor . '"';
		} else {
			$iconStyle2 = "";
		}
	
		if( !empty( $atts['readmorecolor'] ) ) {
			$readmorecolor = 'color:' . esc_attr( $atts['readmorecolor'] ) . ';';
		}
		else {
			$readmorecolor ="";
		}

		if( !empty( $atts['readmorebg'] ) ) {
			$readmorebg = 'background:' . esc_attr( $atts['readmorebg'] ) . ';';
		}
		else {
			$readmorebg ="";
		}
		
		if( !empty( $atts['readmorecolor'] ) or !empty( $atts['readmorebg'] ) ) {
			$readMoreStyle = ' style="' . $readmorecolor . $readmorebg . '"';
		} else {
			$readMoreStyle = "";
		}

		if( !empty( $atts['customclass'] ) ) {
			$customClass = ' ' . esc_attr( $atts['customclass'] );
		} else {
			$customClass = "";
		}
	
		if( !empty( $atts['title'] ) and !empty( $atts['excerpt'] ) ) {
		
				if( !empty( $atts['image'] ) ) {
					$image_url = wp_get_attachment_image_src( $atts["image"], "eventstation-speaker-image" );
					$image = ' style="background-image:url(' . esc_url( $image_url[0] ) . ');"';
				} else {
					$image = "";
				}
				
				$random_id = rand( 0, 99999999 );
				
				$output .= '<div class="item service-box service-box-' . $random_id . ' service-box-image-style' . $customClass . '">';
					
					$output .= '<div class="service-box-image-style-content">';
				
						if( !empty( $atts['icon'] ) ) {
							$output .= '<div class="service-box-icon"><i class="fa fa-' . esc_attr( $atts['icon'] ) . '"' . $iconStyle . '></i></div>';
						}
					
						if( !empty( $atts['title'] ) ) {
							$output .= '<h2' . $titleStyle . '>' . wp_kses( $atts['title'] , $allowed_html ) . '</h2>';
						}
					
						if( !empty( $atts['excerpt'] ) ) {
							$output .= '<p' . $textStyle . '>' . esc_attr( $atts['excerpt'] ) . '</p>';
						}
						
					$output .= '</div>';
					
					$output .= '<div class="service-box-image-style-image"' . $image . '>';
					$output .= '<div class="service-box-image-style-more"' . $readMoreStyle . '><i class="fa fa-search"></i><span>' . esc_html__( 'More' , 'eventstation' ) . '</span></div>';
					$output .= '</div>';
					
					$output .= '<div class="service-box-image-style-hover-content-wrapper">';
						$output .= '<div class="service-box-image-style-hover-content scrollbar-outer">';
					
							$output .= '<div class="service-box-close-icon">x</div>';
							
							if( !empty( $atts['icon'] ) ) {
								$output .= '<div class="service-box-icon"><i class="fa fa-' . esc_attr( $atts['icon'] ) . '"></i></div>';
							}
						
							if( !empty( $atts['title'] ) ) {
								$output .= '<h2>' . wp_kses( $atts['title'] , $allowed_html ) . '</h2>';
							}
						
							if( !empty( $atts['text'] ) ) {
								$output .= '<p>' . esc_attr( $atts['text'] ) . '</p>';
							}
							
						$output .= '</div>';
					$output .= '</div>';
		
					$output .= "<script>
										jQuery(document).ready(function($){
		$(document).on('click', '.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-image .service-box-image-style-more', function(){
			$('.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-image .service-box-image-style-more').fadeOut();
			$('.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-hover-content-wrapper').fadeIn();
		});
	
		$(document).on('click', '.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-hover-content-wrapper .service-box-image-style-hover-content .service-box-close-icon', function(){
			$('.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-hover-content-wrapper').fadeOut();
			$('.service-box.service-box-" . $random_id . ".service-box-image-style .service-box-image-style-image .service-box-image-style-more').fadeIn();
		});
										});
									</script>";
					
				$output .= '</div>';			
		}	

	return $output;
}
add_shortcode("carousel_service_box_item", "carousel_service_box_item_shortcode");

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Carousel Service Box", 'eventstation'),
		"base" => "carousel_service_box",
		"class" => "",
		"as_parent" => array('only' => 'carousel_service_box_item'),
		"js_view" => 'VcColumnView',
		"content_element" => true,
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/carousel_service_box.png',
		"description" =>esc_html__( 'Carousel service box widget.','eventstation'),
		"params" => array(
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style",'eventstation'),
				"description" => esc_html__("You can select the design style.",'eventstation'),
				"param_name" => "style",
				"value" => array(
					esc_html__("Default", 'eventstation') => "default",
					esc_html__("Alternative", 'eventstation') => "alternative",
				)
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}

if(function_exists('vc_map')){
	vc_map( array(
		"name" => esc_html__("Carousel Service Box Item", 'eventstation'),
		"base" => "carousel_service_box_item",
		"class" => "",
		"as_child" => array( 'only' => 'carousel_service_box' ),
		"content_element" => true,
		"category" => esc_html__("Event Station Theme", 'eventstation'),
		"icon" => get_template_directory_uri().'/assets/img/icons/carousel_service_box_item.png',
		"description" =>esc_html__( 'Carousel service box item widget.','eventstation'),
		"params" => array(
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__( "Image",'eventstation' ),
				"description" => esc_html__( "You can the upload your service image.", 'eventstation' ),
				"param_name" => "image",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title",'eventstation'),
				"description" => esc_html__("You can enter the service title.", 'eventstation'),
				"param_name" => "title",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Excerpt",'eventstation'),
				"description" => esc_html__("You can enter the service excerpt.", 'eventstation'),
				"param_name" => "excerpt",
				"value" => "",
			),
			array(
				"type" => "textarea",
				"class" => "",
				"heading" => esc_html__("Text",'eventstation'),
				"description" => esc_html__("You can enter the text.",'eventstation'),
				"param_name" => "text",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Icon",'eventstation'),
				"description" => esc_html__("You can enter the icon name. List of the icons is available in the documentation file. Example: edge, automobile, bel-o.", 'eventstation'),
				"param_name" => "icon",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Title Font Size",'eventstation'),
				"description" => esc_html__("You can enter the title font size. Example: 15px.", 'eventstation'),
				"param_name" => "titlefontsize",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Custom Text Font Size",'eventstation'),
				"description" => esc_html__("You can enter the text font size. Example: 15px.", 'eventstation'),
				"param_name" => "textfontsize",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Title Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "titlecolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Text Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "textcolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Background",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconbackground",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconcolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Icon Border Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "iconbordercolor",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Read More Background",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "readmorebg",
				"value" => "",
			),
			array(
				"type" => "colorpicker",
				"class" => "",
				"heading" => esc_html__("Custom Read More Color",'eventstation'),
				"description" => esc_html__("Please choose the color.",'eventstation'),
				"param_name" => "readmorecolor",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class Name",'eventstation'),
				"description" => esc_html__("You can enter the custom class.",'eventstation'),
				"param_name" => "customclass",
				"value" => "",
			)
		)
	) );
}

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_carousel_service_box extends WPBakeryShortCodesContainer {}
}
/*------------- CAROUSEL SERVICE BOX END -------------*/