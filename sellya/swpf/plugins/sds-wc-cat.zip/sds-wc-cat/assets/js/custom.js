/**
 * @file custom.js
 * @plugin sds-wc-cat
 * @description jquery ui declaration
 * 
 */
/*jQuery('.jcarousel-skin-opencart ul.products').each(function(k,v){
   
	jQuery(this).jcarousel({
		vertical: false,
		visible: 4,
		scroll: 3
	});
	
});*/

jQuery(function($){
   
	$( ".sds_tabs" ).tabs();
    
});