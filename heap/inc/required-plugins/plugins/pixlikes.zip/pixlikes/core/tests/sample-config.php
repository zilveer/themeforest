<?php return array
	(
		'template-paths' => array
			(
				dirname(__FILE__).DIRECTORY_SEPARATOR.'sample-templates'
			),

		'fields' => array
			(
				// empty
			),

	); # config
