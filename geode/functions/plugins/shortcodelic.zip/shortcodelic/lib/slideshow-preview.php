<?php
	if ( isset($_POST['wpload']) ) { 
		require_once($_POST['wpload']);
		global $shortcodelic_preview_iframe;

		$shortcodelic_preview_iframe = true;
?>
<html>
	<head>
		<?php
			echo apply_filters('shortcodelic_more_js_iframe','');
			echo apply_filters('shortcodelic_more_css_iframe','');
			wp_head();
		?>
<script>
if ( typeof jQuery != 'undefined' ) {
	jQuery(document).ready(function(){
		parent.jQuery("body").bind("sc_slideshine_preview_started", function(){
			jQuery(".sc_draggable").each(function(){
				var t = jQuery(this),
					ind = parseFloat(jQuery(this).attr("data-index"));
				t.draggable({
					iframeFix: true,
					stop: function(event, ui){
						parent.jQuery(".element-slide-preview").eq(ind).attr("data-position", JSON.stringify(ui.position));
					}
				});
			});
		});
	});
}
</script>
	</head>
	<body>
	</body>
</html>
<?php
	$shortcodelic_preview_iframe = false;
}