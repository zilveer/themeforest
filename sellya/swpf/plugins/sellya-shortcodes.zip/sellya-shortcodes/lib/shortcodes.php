<?php

/*
 * Lastest Post Shortcode
 */

add_shortcode('sellya_latest_posts','sellya_latest_posts_cb');

function sellya_latest_posts_cb($atts = array()){
    
    extract(shortcode_atts(array(
        'post_type'=>'post',
        'posts_per_page'=> get_option('posts_per_page'),
        'column' => 2,
    ),$atts));
    
    $postq = new WP_Query("post_type={$post_type}&posts_per_page={$posts_per_page}");
    
    $i = 0;
    
    $columnarray = array(
            1=>array(
                '12',
                'blog-post-img'
            ),
            2=>array(
                '6',
                array(440,248)
            ),
            3=>array(
                '4',
                array(287,162)
            )
        );
    ob_start();
    if($postq->have_posts()): 
        ?>
<div class="span12 span-first-child">  
    <?php
        while($postq->have_posts()): $postq->the_post();
    
        $eclass = $i % intval($column) == 0 ? "span{$columnarray[intval($column)][0]} span-first-child":"span{$columnarray[intval($column)][0]}";
        
        $i++;
    ?>
    <div id="post-<?php the_ID(); ?>" <?php post_class($eclass)?>>
                    
        <div class="span12 span-first-child">
                <a href="<?php the_permalink();?>" rel="bookmark" title="<?php the_title();?>">
                <?php the_post_thumbnail($columnarray[intval($column)][1]);?>
                </a>                            
            <div class="span12 span-first-child">

                <h2 class="blog_title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h2>

                <div class="authorinfo">
                        <?php
                        $tags = get_the_tags(get_the_ID());							
                        if(!empty($tags)):
                            $t = 0;									
                        ?>
                        <i class="icon-tags"></i>                               
                        <?php foreach($tags as $tag):
                                if($t>0) echo ',';
                                $t++;
                                ?>

                            <a rel="tag" href="<?php echo get_tag_link($tag->term_id);?>"><?php echo ucfirst($tag->name);?></a>
                        <?php endforeach;?>                                

                        <?php endif;?>&nbsp;

                        <i class="icon-user"></i>&nbsp;<a href="<?php echo get_the_author_meta('user_url')?>" rel="author"><?php echo get_the_author()?></a>&nbsp;&nbsp;<i class="icon-tag"></i> 
                                <?php 
                                $cats = get_the_category();

                                foreach($cats as $m=>$cat):

                                        if($m > 0)
                                                echo ', ';

                                        echo "<a href='".get_category_link($cat->term_id)."'>$cat->name</a>";

                                endforeach;

                                ?>
                </div>

                <?php
                if(function_exists('get_sellya_blog_short_text'))                
                    echo get_sellya_blog_short_text(get_the_content());
                else 
                    the_excerpt();
                ?>

                <div class="postinfo">

                    <a class="readmore" href="<?php the_permalink()?>"><?php echo __('Read More&nbsp;<i class="icon-circle-arrow-right"></i>','sellya');?></a>
                    <span class="comments_count"><?php comments_popup_link(__( '<i class="icon-comments"></i> No comments', 'sellya' ),__( '<i class="icon-comment-alt"></i> 1 comment', 'sellya' ),__( '<i class="icon-comments-alt"></i> % comments', 'sellya' ),'',__( '<i class="icon-lock"></i> Comments off', 'sellya' ))?></span>
                </div><!--.postinfo -->
            </div> <!--.span12 -->                                   
        </div><!--.span12 -->						
    </div>	<!--.span4 -->    
    <?php
    
    endwhile; 
    ?>
</div>
<?php
    endif; wp_reset_query();
    
    $contents = ob_get_contents();
    
    ob_end_clean();
    
    return $contents;
    
}



//google map

add_shortcode('gmap','get_gmap');

function get_gmap($atts = array()){

	//[gmap lat='23.746854' lng='90.418446' zoom='16' title='Smart Data Soft']

	$defaults = array(

		'elem'=>'map',	

		'lat'=>'-34.397',

		'lng'=>'150.644',

		'zoom'=>'8',

		'height'=>'350',

		'title'=>''	

	);

	extract(shortcode_atts($defaults,$atts));	

	ob_start();	

	?>

    <style type="text/css">

	#<?php echo $elem?>{

		width:100%;

		height:<?php echo $height;?>px;

		margin-bottom:10px;

	}

	</style>

	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>

    <script type="text/javascript">

		var themap;

		function initialize() {

			var mapOptions = {

				zoom: parseInt('<?php echo $zoom;?>'),

				center: new google.maps.LatLng(parseFloat('<?php echo $lat;?>'), parseFloat('<?php echo $lng;?>')),

				mapTypeId: google.maps.MapTypeId.ROADMAP

			};

			themap = new google.maps.Map(document.getElementById('<?php echo $elem?>'),

			  mapOptions);

			  

			new google.maps.Marker({

				position: mapOptions.center,

				map: themap,

				title: '<?php echo $title?>'

			});

		}

		google.maps.event.addDomListener(window, 'load', initialize);

	</script>

    <div id="<?php echo $elem?>"></div>

	<?php

	$contents = ob_get_contents();

	ob_end_clean();

	return $contents;

}



//full

function shortcode_full($atts, $content = null){

return '<div class="span12">' . do_shortcode($content) . '</div>';

}

add_shortcode('full', 'shortcode_full');



//half

function shortcode_half($atts, $content = null){

return '<div class="span6">' . do_shortcode($content) . '</div>';

}

add_shortcode('half', 'shortcode_half');



//half last

function shortcode_half_first($atts, $content = null){

return '<div class="span6 span-first-child">' . do_shortcode($content) . '</div>';

}

add_shortcode('half_first', 'shortcode_half_first');



//one third

function shortcode_onethird($atts, $content=null){

return '<div class="span4">' . do_shortcode($content) . '</div>';

}

add_shortcode('one_third', 'shortcode_onethird');



//one third last

function shortcode_onethird_first($atts, $content=null){

return '<div class="span4 span-first-child">' . do_shortcode($content) . '</div>';

}

add_shortcode('one_third_first', 'shortcode_onethird_first');



//one fourth

function shortcode_onefourth($atts, $content=null){

return '<div class="span3">' . do_shortcode($content) . '</div>';

}

add_shortcode('one_fourth', 'shortcode_onefourth');



//one fourth last

function shortcode_onefourth_first($atts, $content=null){

return '<div class="span3 span-first-child">' . do_shortcode($content) . '</div>';

}

add_shortcode('one_fourth_first', 'shortcode_onefourth_first');



//two thirds

function shortcode_twothirds_first($atts, $content=null){

	return '<div class="span8 span-first-child">' . do_shortcode($content) . '</div>';

}

add_shortcode('two_thirds_first', 'shortcode_twothirds_first');

function shortcode_twothirds($atts, $content=null){

	return '<div class="span8">' . do_shortcode($content) . '</div>';

}

add_shortcode('two_thirds', 'shortcode_twothirds');

//three fourths last 

function shortcode_three_fourths_first($atts, $content=null){

return '<div class="span9 span-first-child">' . do_shortcode($content) . '</div>';

}

add_shortcode('three_fourths_first', 'shortcode_three_fourths_first');

//three fourths

function shortcode_threefourths($atts, $content=null){

return '<div class="span9">' . do_shortcode($content) . '</div>';

}

add_shortcode('three_fourths', 'shortcode_threefourths');


//break

function shortcode_break($atts, $content=null){

return '<div class="break clearfix">&nbsp;</div>';

}

add_shortcode('break', 'shortcode_break');



//divider

function shortcode_divider($atts, $content=null){

return '<div class="divider clearfix">&nbsp;</div>';

}

add_shortcode('divider', 'shortcode_divider');



//divider top

function shortcode_dividertop( $atts, $content = null ) {

return '<div class="totop"><div class="gototop"></div></div>';

}

add_shortcode('dividertop', 'shortcode_dividertop');



//ribbon red

function shortcode_ribbon_red($atts, $content = null) {

	extract(shortcode_atts(array(

		"url" => ''

	), $atts));

return '<div class="ribbon"><div class="ribbon_left_red"></div><div class="ribbon_center_red"><a href ="'.$url.'">' .do_shortcode($content). '</a></div><div class="ribbon_right_red"></div></div>';

}

add_shortcode('ribbon_red', 'shortcode_ribbon_red');



//ribbon blue

function shortcode_ribbon_blue($atts, $content = null) {

	extract(shortcode_atts(array(

		"url" => ''

	), $atts));

return '<div class="ribbon"><div class="ribbon_left_blue"></div><div class="ribbon_center_blue"><a href ="'.$url.'">' .do_shortcode($content). '</a></div><div class="ribbon_right_blue"></div></div>';

}

add_shortcode('ribbon_blue', 'shortcode_ribbon_blue');



//ribbon yellow

function shortcode_ribbon_yellow($atts, $content = null) {

	extract(shortcode_atts(array(

		"url" => ''

	), $atts));

return '<div class="ribbon"><div class="ribbon_left_yellow"></div><div class="ribbon_center_yellow"><a href ="'.$url.'">' .do_shortcode($content). '</a></div><div class="ribbon_right_yellow"></div></div>';

}

add_shortcode('ribbon_yellow', 'shortcode_ribbon_yellow');



//ribbon green

function shortcode_ribbon_green($atts, $content = null) {

	extract(shortcode_atts(array(

		"url" => ''

	), $atts));

return '<div class="ribbon"><div class="ribbon_left_green"></div><div class="ribbon_center_green"><a href ="'.$url.'">' .do_shortcode($content). '</a></div><div class="ribbon_right_green"></div></div>';

}

add_shortcode('ribbon_green', 'shortcode_ribbon_green');



//ribbon white

function shortcode_ribbon_white($atts, $content = null) {

	extract(shortcode_atts(array(

		"url" => ''

	), $atts));

return '<div class="ribbon"><div class="ribbon_left_white"></div><div class="ribbon_center_white"><a href ="'.$url.'">' .do_shortcode($content). '</a></div><div class="ribbon_right_white"></div></div>';

}

add_shortcode('ribbon_white', 'shortcode_ribbon_white');



//high light dark

function shortcode_highlight_black($atts, $content=null){

return '<span class="black" >' .$content. '</span>';

}

add_shortcode('highlight_black', 'shortcode_highlight_black');





//high light yellow

function shortcode_highlight_yellow($atts, $content=null){

return '<span class="yellow" >' .$content. '</span>';

}

add_shortcode('highlight_yellow', 'shortcode_highlight_yellow');





//high light blue

function shortcode_highlight_blue($atts, $content=null){

return '<span class="blue" >' .$content. '</span>';

}

add_shortcode('highlight_blue', 'shortcode_highlight_blue');





//high light green

function shortcode_highlight_green($atts, $content=null){

return '<span class="green" >' .$content. '</span>';

}

add_shortcode('highlight_green', 'shortcode_highlight_green');



//sellya list shortcodes

function remove_li_shortcode_directives($content)
{
	$content = preg_replace('/\]/','>',preg_replace('/\[/','<',$content));
	
	return $content;
	
}


function shortcode_list_checkbox($atts, $content=null){

return '<ul class="list_style" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_checkbox', 'shortcode_list_checkbox');



function shortcode_list_cross($atts, $content=null){

return '<ul class="list_style style2" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_cross', 'shortcode_list_cross');


function shortcode_list_rarrow($atts, $content=null){

return '<ul class="list_style style3" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_rarrow', 'shortcode_list_rarrow');


function shortcode_list_circle($atts, $content=null){

return '<ul class="list_style style4" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_circle', 'shortcode_list_circle');


function shortcode_list_checkbox2($atts, $content=null){

return '<ul class="list_style style5" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_checkbox2', 'shortcode_list_checkbox2');


function shortcode_list_cross2($atts, $content=null){

return '<ul class="list_style style6" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_cross2', 'shortcode_list_cross2');


function shortcode_list_rarrow2($atts, $content=null){

return '<ul class="list_style style7" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_rarrow2', 'shortcode_list_rarrow2');


function shortcode_list_circle2($atts, $content=null){

return '<ul class="list_style style8" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_circle2', 'shortcode_list_circle2');


function shortcode_list_green_checkbox($atts, $content=null){

return '<ul class="list_style style9" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_checkbox3', 'shortcode_list_green_checkbox');



function shortcode_list_cross3($atts, $content=null){

return '<ul class="list_style style10" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_cross3', 'shortcode_list_cross3');


function shortcode_list_rarrow3($atts, $content=null){

return '<ul class="list_style style11" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_rarrow3', 'shortcode_list_rarrow3');


function shortcode_list_circle3($atts, $content=null){

return '<ul class="list_style style12" >' .remove_li_shortcode_directives($content). '</ul>';

}

add_shortcode('list_circle3', 'shortcode_list_circle3');



//dropcaps

function shortcode_dropcap_with_bg($atts, $content=null) {

return '<span class="dropcap large bg">' .do_shortcode($content). '</span>';

}

add_shortcode('dropcap_with_bg', 'shortcode_dropcap_with_bg');


function shortcode_dropcap($atts, $content=null) {

return '<span class="dropcap">' .$content. '</span>';

}

add_shortcode('dropcap', 'shortcode_dropcap');


//sellya blockquotes

function shortcode_blockquote($atts, $content=null) {

return '<div class="block-quote">' .$content. '</div>';

}

add_shortcode('block-quote', 'shortcode_blockquote');


function shortcode_blockquote_left($atts, $content=null) {

return '<div class="block-quote-left">' .$content. '</div>';

}

add_shortcode('block-quote-left', 'shortcode_blockquote_left');


function shortcode_blockquote_right($atts, $content=null) {

return '<div class="block-quote-right">' .$content. '</div>';

}

add_shortcode('block-quote-right', 'shortcode_blockquote_right');

//sellya testimonial quote

function shortcode_testmonial_quote($atts, $content=null) {

	$defaults = array(
		'name' => 'Name'
	);
	
	extract(shortcode_atts($defaults,$atts));

	return "<div class='testimonial-quote'><p>$content</p><h6 class='name'>$name</h6></div>";

}

add_shortcode('testimonial_quote', 'shortcode_testmonial_quote');


//sellya buttons wrap


function shortcode_button_small($atts, $content = NULL){
	
	return "<div class='buttons'>".do_shortcode($content)."</div>";
	
}

add_shortcode('buttons_small', 'shortcode_button_small');


function shortcode_button_medium($atts, $content = NULL){
	
	return "<div class='buttons medium'>".do_shortcode($content)."</div>";
	
}

add_shortcode('buttons_medium', 'shortcode_button_medium');


function shortcode_button_large($atts, $content = NULL){
	
	return "<div class='buttons large'>".do_shortcode($content)."</div>";
	
}

add_shortcode('buttons_large', 'shortcode_button_large');


//sellya buttons


function shortcode_button($atts, $content = NULL){
	
	$defaults = array(
		'href' => '#'
	);
	
	extract(shortcode_atts($defaults,$atts));	
	
	return "<a class='shortcode-button' href='$href'>$content</a>";
	
}

add_shortcode('button', 'shortcode_button');


function shortcode_button_gray($atts, $content = NULL){
	
	$defaults = array(
		'href' => '#'
	);
	
	extract(shortcode_atts($defaults,$atts));	
	
	return "<a class='shortcode-button gray' href='$href'>$content</a>";
	
}

add_shortcode('button_grey', 'shortcode_button_gray');


function shortcode_button_red($atts, $content = NULL){
	
	$defaults = array(
		'href' => '#'
	);
	
	extract(shortcode_atts($defaults,$atts));	
	
	return "<a class='shortcode-button red' href='$href'>$content</a>";
	
}

add_shortcode('button_red', 'shortcode_button_red');


function shortcode_button_yellow($atts, $content = NULL){
	
	$defaults = array(
		'href' => '#'
	);
	
	extract(shortcode_atts($defaults,$atts));	
	
	return "<a class='shortcode-button yellow' href='$href'>$content</a>";
	
}

add_shortcode('button_yellow', 'shortcode_button_yellow');

function shortcode_button_olive($atts, $content = NULL){
	
	$defaults = array(
		'href' => '#'
	);
	
	extract(shortcode_atts($defaults,$atts));	
	
	return "<a class='shortcode-button olive' href='$href'>$content</a>";
	
}

add_shortcode('button_olive', 'shortcode_button_olive');

function shortcode_button_lightblue($atts, $content = NULL){
	
	$defaults = array(
		'href' => '#'
	);
	
	extract(shortcode_atts($defaults,$atts));	
	
	return "<a class='shortcode-button lightblue' href='$href'>$content</a>";
	
}

add_shortcode('button_lightblue', 'shortcode_button_lightblue');

function shortcode_button_black($atts, $content = NULL){
	
	$defaults = array(
		'href' => '#'
	);
	
	extract(shortcode_atts($defaults,$atts));	
	
	return "<a class='shortcode-button black' href='$href'>$content</a>";
	
}

add_shortcode('button_black', 'shortcode_button_black');




//button buy

function shortcode_button_purche($atts, $content = null) {

	extract(shortcode_atts(array(

		"url" => '',

		"bottom_text"=>''

	), $atts));

return '<div class="button_purche"><a href="'.$url.'"><div class="button_purche_left"></div><div class="button_purche_right"><div class="button_purche_right_top">'.do_shortcode($content).'</div><div class="button_purche_right_bottom">'.$bottom_text.'</div></div></a></div>';

}

add_shortcode('button_purche', 'shortcode_button_purche');



//button download

function shortcode_button_download($atts, $content = null) {

	extract(shortcode_atts(array(

		"url" => '',

		"bottom_text"=>''

	), $atts));

return '<div class="button_download"><a href="'.$url.'"><div class="button_download_left"></div><div class="button_download_right"><div class="button_download_right_top">'.do_shortcode($content).'</div><div class="button_download_right_bottom">'.$bottom_text.'</div></div></a></div>';

}

add_shortcode('button_download', 'shortcode_button_download');



//button search

function shortcode_button_search_c($atts, $content = null) {

	extract(shortcode_atts(array(

		"url" => '',

		"bottom_text"=>''

	), $atts));

return '<div class="button_search"><a href="'.$url.'"><div class="button_search_left"></div><div class="button_search_right"><div class="button_search_right_top">'.do_shortcode($content).'</div><div class="button_search_right_bottom">'.$bottom_text.'</div></div></a></div>';

}

add_shortcode('button_search_c', 'shortcode_button_search_c');




// message boxes

function shortcode_msgbox( $atts, $content = null ) {

return '<div class="msgBox">' . $content . '</div>';

}

add_shortcode('msgbox', 'shortcode_msgbox');

function shortcode_msgbox2( $atts, $content = null ) {

return '<div class="msgBox bg1">' . $content . '</div>';

}

add_shortcode('msgbox2', 'shortcode_msgbox2');

function shortcode_msgbox3( $atts, $content = null ) {

return '<div class="msgBox bg2">' . $content . '</div>';

}

add_shortcode('msgbox3', 'shortcode_msgbox3');

function shortcode_msgbox4( $atts, $content = null ) {

return '<div class="msgBox bg4">' . $content . '</div>';

}

add_shortcode('msgbox4', 'shortcode_msgbox4');

//active sortcodes into text widget

add_filter('widget_text', 'do_shortcode');

//button search





//accordion


function shortcode_accordions($attr,$content){
	
	return "<div class='accordion'>".do_shortcode($content)."</div>";
	
}

add_shortcode( 'accordion', 'shortcode_accordions' );

function shortcode_accordion($atts, $contents){
	
	$defaults = array('title'=>'');
	
	extract(shortcode_atts($defaults, $atts));
	
	ob_start();
	?>
    <h3><?php echo $title;?></h3>
    <div class="toggleText">
        <?php echo $contents;?>
    </div>
    
    <?php
	$content = ob_get_contents();
	
	ob_end_clean();
	
	return $content;
	
}

add_shortcode( 'atab', 'shortcode_accordion' );




//toggle

function shortcode_toggle($atts, $content = null){

	extract(shortcode_atts(array(

		'title' => ''

	), $atts));

return '<div class="toggle-box"><h2 class="trigger">'.$title.'</h2>

<div class="toggle_container">' . do_shortcode($content) . '</div></div>';

}

add_shortcode('toggle', 'shortcode_toggle');





// ui-tabs

function sellya_tabgroup($atts,$contents){
	
	$GLOBALS['tab_counter'] = 1;
	
	do_shortcode($contents);
	
	$GLOBALS['tablink'] .= '</ul>';
	
	return "<div class='sellya_tabs'>".$GLOBALS['tablink'].do_shortcode($GLOBALS['tabcontent'])."</div>";
	
}


add_shortcode('tabgroup','sellya_tabgroup');


function sellya_tab($atts,$contents){
	
	
	extract(shortcode_atts(array(

	'title' => ''
	
	), $atts));
		
	
	if($GLOBALS['tab_counter'] == 1):
	
		$GLOBALS['tablink'] = "<ul><li><a href='#tab-".$GLOBALS['tab_counter']."'>$title</a></li>";
		
		$GLOBALS['tabcontent'] = "<div id='tab-".$GLOBALS['tab_counter']."'><p>$contents</p></div>";
	
	else:
	
		$GLOBALS['tablink'] .= "<li><a href='#tab-".$GLOBALS['tab_counter']."'>$title</a></li>";
		
		$GLOBALS['tabcontent'] .= "<div id='tab-".$GLOBALS['tab_counter']."'><p>$contents</p></div>";
	
	endif;
	
	$GLOBALS['tab_counter']++;
	
}


add_shortcode('tab','sellya_tab');



function flexslider_shortcode($atts, $content){

	$defaults = array(
		'class' => 'flexslider slider-pull-left',
		'id' => 'flexslider'
	);
	
	extract(shortcode_atts($defaults,$atts));
	
	return "<section id='$id' class=\"$class\">
		<ul class=\"slides\">".do_shortcode(str_replace('<br />','',$content))."</ul>
	</section>
	<script type='text/javascript'>
		jQuery(function($){			
			$('#$id').flexslider();	
		});
	</script>";
	
}

add_shortcode('flexslider','flexslider_shortcode');


function flextab_shortcode($atts, $content){
	
	$defaults = array(
		'link' => '',
		'imageurl' => get_template_directory_uri().'/image/responsive.png',
		'title' => 'title'
	);
	
	extract(shortcode_atts($defaults,$atts));
	
	ob_start();
	
	?>
    <li>
      <?php if ($link) { ?>
      <a href="<?php echo $link; ?>"><img src="<?php echo $imageurl; ?>" alt="<?php echo $title; ?>" /></a>
      <?php } else { ?>
      <img src="<?php echo $imageurl; ?>" alt="<?php echo $title; ?>" />
	<?php } ?>
	  </li> 
    
    <?php
	
	$output = ob_get_contents();
	
	ob_end_clean();
	
	return $output;
	
}

add_shortcode('ftab','flextab_shortcode');



function cameraslider_shortcode($atts, $content){

	$defaults = array(
		'class' => 'camera_wrap camera_azure_skin',
		'id' => 'camera_wrap'
	);
	
	extract(shortcode_atts($defaults,$atts));
	
	return "<section class='fluid_container slider-pull-left'><div id='$id' class=\"$class\">".do_shortcode(str_replace('<br />','',$content))."</div></section>
	<script type='text/javascript'>
		jQuery(function($){			
			$('#$id').camera({
				thumbnails: true,
				loader: true,
				hover: false
			});	
		});
	</script>";
	
}

add_shortcode('cameraslider','cameraslider_shortcode');


function camtab_shortcode($atts, $content){
	
	$defaults = array(
		'link' => '',
		'imageurl' => get_template_directory_uri().'/image/responsive.png',		
	);
	
	extract(shortcode_atts($defaults,$atts));
	
	ob_start();
	
	?>
    
    <div data-link="<?php echo $link; ?>" data-thumb="<?php echo $imageurl; ?>" data-src="<?php echo $imageurl; ?>"></div>
    
    <?php
	
	$output = ob_get_contents();
	
	ob_end_clean();
	
	return $output;
	
}

add_shortcode('ctab','camtab_shortcode');

function productslider_shortcode($atts){
    $defaults = array(
         'showproducts' => '-1',           
    );
	
    extract(shortcode_atts($defaults,$atts));
    
    if(!function_exists('homepage_eislideshow_markup')) 
        return '<p><strong>Please active Sellya or Sellya Child Theme.</strong></p>';
	
    
    ob_start();
    echo "<div class='productslider-shortcode slider-pull-left'>";
    homepage_eislideshow_markup(intval($showproducts));
    echo "</div>";
    $content = ob_get_contents();
    
    ob_end_clean();
    
    return $content;    
    
}

add_shortcode('productslider','productslider_shortcode');


function sellya_productcats_cb($atts){
    
    if(!function_exists('sellya_product_category_markup')) 
        return '<p><strong>Please active Sellya or Sellya Child Theme.</strong></p>';
    
    
    ob_start();   
    sellya_product_category_markup();   
    $content = ob_get_contents();    
    ob_end_clean();    
    return $content;    
}

add_shortcode('sellya-productcats', 'sellya_productcats_cb');

?>