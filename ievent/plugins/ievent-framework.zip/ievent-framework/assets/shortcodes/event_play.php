<?php 

	/* Event Play  ---------------------------------------------*/
	
	add_shortcode('event_play', 'jx_ievent_event_play');
	
	function jx_ievent_event_play($atts, $content = null) { 
		extract(shortcode_atts(array(

			'pretitle' => '',
			'title' => '',
			'location' => '',
			'video_link' =>''
			
		), $atts)); 
		 
		
		//initial variables
		$out='';
		 
		
		
		//function code
			
			$out ='
			<div class="jx-ievent-event-box">
				<div class="jx-ievent-event-play">
					<a href="'.$video_link.'" data-rel="prettyPhoto"><i class="fa fa-play"></i></a>
				</div>
				<div class="jx-ievent-event-title-box">
					<div class="jx-ievent-event-pretitle">'.$pretitle.'</div>
					<div class="jx-ievent-event-title">'.$title.'</div>
					<div class="jx-ievent-event-location">'.$location.'</div>
				</div>
			</div> 
			';
			

		//return output
		return $out;
	}


?>