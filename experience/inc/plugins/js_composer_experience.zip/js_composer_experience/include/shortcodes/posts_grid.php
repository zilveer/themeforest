<?php if ( class_exists( 'WPBakeryShortCode' ) ) {

	class WPBakeryShortCode_experience_posts_grid extends WPBakeryShortCode {
		
		/**
		 * @param $atts - shortcode attributes
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 **/
		 
		protected function content( $atts, $content = null ) {
			
			$experience_vc_utilities = new jsComposerExperienceUtilities();
			
			$output = $background_image = '';
			
			extract( shortcode_atts( array(			
				'el_class'		=> '',
				'number'		=> '3',
				'category'		=> '',
				'tag'			=> '',
				'show_date'		=> '',
				'show_author'	=> '',
				'show_category'	=> '',
				'color'			=> '',
				'color_alt'		=> '',
				'grid_width'	=> '',
				'css'			=> ''
			), $atts ) );
			
			// Grid Width
			if ( $grid_width != 'narrow-width' && $grid_width != 'site-width' ) {
				$grid_width = '';
			} 
	
			$query_args = array(
				'post_type'				=> 'post',
				'posts_per_page'		=> intval( $number ),
				'category_name'			=> esc_html( $category ),
				'tag'					=> esc_html( $tag ),
				'ignore_sticky_posts'	=> 1				
			);			
			
			$postslist = new WP_query( $query_args );
			
			if ( $postslist->have_posts() ) {
				
				$class = $this->getExtraClass( $el_class );			
				$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );
				
				$output .= '<div class="post-grid post-container clearfix '. esc_attr( $color .' '. $color_alt .' '.  $css_class .' '. $grid_width ) .'">';
				
					while ( $postslist->have_posts() ) : $postslist->the_post();
					
						global $post, $experience_theme_settings;					

						$output .= '<article class="post-grid-item post-item">';
							
							$output .= '<div class="post-grid-item-image">';
							
								if( has_post_thumbnail() ) {									
									$background_image = wp_get_attachment_image_src( esc_html( get_post_thumbnail_id( $post->ID ) ), 'post-grid' );					
								} else if (
									isset( $experience_theme_settings['blog-default-post-image'] ) 
									&& $experience_theme_settings['blog-default-post-image']['id'] != ''
								) {
									$background_image = wp_get_attachment_image_src( $experience_theme_settings['blog-default-post-image']['id'], 'experience-post-grid' );
								}
								
								if ( $background_image != false ) {
									$output .= $experience_vc_utilities->experienceGetBackground(
										$background_image[0],
										false,
										false,
										false,
										false,
										false,
										false										
									);	
								}
								
								unset( $background_image );
							
							$output .= '</div>';
							
							$output .= '<div class="post-grid-item-content">';
							
								$output .= '<div class="holder">';
								
									$output .= '<div class="cont">';
										
										$output .= '<h2>'. get_the_title() .'</h2>';
										
										if (
											$show_date == 'true'
											|| $show_author == 'true'
											|| $show_category == 'true'
										) {
										
											$output .= '<div class="post-meta">';
											
												if ( $show_author == 'true' ) {
													$output .= '<span class="post-author">'. sprintf( esc_html__( 'By %1$s', "js_composer_experience" ), get_the_author_meta( 'display_name' ) ) .' </span>';
												}
												
												if ( $show_date == 'true' ) {
													
													$output .= '<span class="post-date">';
														
														$output .= '<time class="published" datetime="'. get_the_time( 'c' ) .'">';
														
															if ( $show_author == 'true' ) {
																$output .= '&nbsp;'. sprintf( esc_html__( 'on %1$s', "js_composer_experience" ), get_the_time( get_option( 'date_format' ) ) );
															} else {
																$output .= ucfirst( sprintf( esc_html__( 'on %1$s', "js_composer_experience" ), get_the_time( get_option( 'date_format' ) ) ) );
															}
														
														$output .= '</time>';
														
													$output .= '</span> ';
												
												}
												
												if ( $show_category == 'true' ) {
												
													$output .= '<span class="post-category">';
													
														if ( $show_author == 'true' || $show_date == 'true' ) {
															$output .= '&nbsp;'. sprintf( esc_html__( 'in %1$s' ,"js_composer_experience" ), get_the_category_list( ", " ) );
														} else {
															$output .= ucfirst( sprintf( esc_html__( 'in %1$s' ,"js_composer_experience" ), get_the_category_list( ", " ) ) );
														}
													
													$output .= '</span>';
													
												}

											$output .= '</div>';
											
										}
										
									$output .= '</div>';
								
								$output .= '</div>';
							
							$output .= '</div>';
							
							$output .= '<a href="'. get_the_permalink() .'" rel="bookmark">'. esc_html__( 'Read More', 'js_composer_experience' ) .'</a>';
							
						$output .= '</article>';						
						
					endwhile;	
					
				$output .= '</div>';
				
				wp_reset_postdata();
				
				return $output;
			
			}
		
		}
		
	}
	
}


/* --------- POST GRID --------- */

vc_map( array(
	"base"			=> "experience_posts_grid",
	"name"			=> esc_html__( "Posts Grid", "js_composer_experience" ),
	"description"	=> esc_html__( "Display a list of latest posts.", "js_composer_experience" ),
	"class"			=> "",	
	"params"		=> array(
		
		// Extra Class
		array(
			"param_name"	=> "el_class",
			"heading"		=> esc_html__( "Extra class name", "js_composer_experience" ),
			"description"	=> esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", "js_composer_experience" ),
			"type"			=> "textfield",
			'admin_label'	=> true
		),	
		
		// Number
		array(
			"param_name"	=> "number",
			"heading"		=> esc_html__( "Number of posts", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the number of posts to display.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label" => true
		),
		
		// Category
		array(
			"param_name"	=> "category",
			"heading"		=> esc_html__( "Category", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the post category slug to show. Leave blank to show all latest posts. Separate each category slug with a comma.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label" => true
		),
		
		// Tag
		array(
			"param_name"	=> "tag",
			"heading"		=> esc_html__( "Tag", "js_composer_experience" ),
			"description"	=> esc_html__( "Enter the post tag slug to show. Separate each tag slug with a comma.", "js_composer_experience" ),
			"type"			=> "textfield",
			"admin_label" => true
		),
		
		// Show Author
		array(
			"param_name"	=> "show_author",
			"heading"		=> esc_html__( "Show Author", "js_composer_experience" ),
			"description"	=> esc_html__( "Show the post author meta.", "js_composer_experience" ),
			"type"			=> "checkbox",
			"admin_label" => true
		),
		
		// Show Date
		array(
			"param_name"	=> "show_date",
			"heading"		=> esc_html__( "Show Date", "js_composer_experience" ),
			"description"	=> esc_html__( "Show the post date meta.", "js_composer_experience" ),
			"type"			=> "checkbox",
			"admin_label" => true
		),
		
		// Show Category
		array(
			"param_name"	=> "show_category",
			"heading"		=> esc_html__( "Show Category", "js_composer_experience" ),
			"description"	=> esc_html__( "Show the post category meta.", "js_composer_experience" ),
			"type"			=> "checkbox",
			"admin_label" => true
		),
		
		// CSS
		array(
			"type"		 => "css_editor",
			"heading"	 => esc_html__( "CSS", "js_composer_experience" ),
			"param_name" => "css",
			"group"		 => esc_html__( "Design options", "js_composer_experience" )
		)
	)
	
) );