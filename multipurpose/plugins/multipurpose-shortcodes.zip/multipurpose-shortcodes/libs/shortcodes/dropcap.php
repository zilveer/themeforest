<?php

// shortcode dropcap
add_filter('the_content', "multipurpose_dropcap_remove", 9);
add_filter('the_content', "multipurpose_dropcap_replace", 10);

function multipurpose_dropcap_remove($content)
{
    $new_content = preg_replace('/\[dropcap(.*?)\]/is', '<dropcap$1>', $content);
    return $new_content;
}

function multipurpose_dropcap_replace($content)
{
    $new_content = preg_replace('/<dropcap(.*?)>/', '[dropcap$1]', $content);
    return $new_content;
}

add_shortcode('dropcap','multipurpose_dropcap');

function multipurpose_dropcap($atts, $content = null) {
    if(isset($atts["style"]) && !empty($atts["style"])) {
        $style = '';
        if($atts["style"] == '1') {
                $style = "dc";
        } elseif($atts["style"] == '2') {
                $style = "dc-alt";
        }
        $output = '<span class="'.$style.'">';
    } else {
        $output = '<span>';
    }
    $output .= do_shortcode($content);
    $output .= '</span>';
    
    return $output;
}