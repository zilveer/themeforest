<?php 
// Prevent loading this file directly
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action('admin_menu', 'featured_area_menu');

if ( !function_exists( 'featured_area_menu' ) ) {
	function featured_area_menu() {
		global $featured_area_settings;
		$featured_area_settings = add_menu_page( 'Featured Slider' , 'Featured Slider', 'manage_options', 'featured_area', 'featured_area_config_page', '' );
	
	}
}

function featured_area_config_page() {

    if ( isset( $_POST['featured-slide-add'] ) ) {

    	$nonce = $_REQUEST['_wpnonce'];
	    if (! wp_verify_nonce($nonce, 'featuredarea-updatesettings' ) ) {
	        die('security error');
	    }
		
		$gorilla_featured_area_options = get_option("gorilla_featured_area_options");

    	if(!empty($gorilla_featured_area_options)){
    		$gorilla_featured_slide_array = get_option("gorilla_featured_area_options");
			$gorilla_featured_slide_array = unserialize($gorilla_featured_slide_array);
    	}
    	else {
    		$gorilla_featured_slide_array = array();
    	}

	    //Add
		if(isset($_POST["featured_area_post_checkbox"])){

			foreach ($_POST["featured_area_post_checkbox"] as $key => $value) {

				array_push($gorilla_featured_slide_array, array(
					'post_id' => $value,
					'post_name' => esc_html(strip_tags(get_the_title($value))),
					//'slide_color_style' => 'light'
				));
			}

		}

		// Result
		$gorilla_featured_slide_array = serialize($gorilla_featured_slide_array);
		update_option("gorilla_featured_area_options",$gorilla_featured_slide_array);

	}

	if ( isset( $_POST['featured-area-save-changes'] ) ) {

		$nonce = $_REQUEST['_wpnonce'];
	    if (! wp_verify_nonce($nonce, 'featuredarea-updatesettings' ) ) {
	        die('security error');
	    }

		$gorilla_featured_area_options = get_option("gorilla_featured_area_options");

    	if(!empty($gorilla_featured_area_options)){
    		$gorilla_featured_slide_array = get_option("gorilla_featured_area_options");
			$gorilla_featured_slide_array = unserialize($gorilla_featured_slide_array);
    	}
    	else {
    		$gorilla_featured_slide_array = array();
    	}

		//Delete
		if(isset($_POST["featured_area_remove_post_checkbox"])){

			$gorilla_featured_slide_remove_array = $_POST["featured_area_remove_post_checkbox"];

			foreach($gorilla_featured_slide_remove_array as $del){
		        $cloneArray = $gorilla_featured_slide_array;
		        foreach( $cloneArray as $key => $value )
		        {
		            if ($gorilla_featured_slide_array[$key]["post_id"] == $del){ 
		            	unset( $gorilla_featured_slide_array[$key] );
		            	break;
		            }
		        }
		    }

		}

		//Light-Dark
		/*if(isset($_POST["featured_slide_color_style_hidden"])) {
			$gorilla_featured_slide_style = $_POST["featured_slide_color_style_hidden"];
			$gorilla_featured_slide_style_array = json_decode(stripslashes("[$gorilla_featured_slide_style]"), true);
			$gorilla_featured_slide_array_new = array();

			$gorilla_featured_slide_style_array_in = $gorilla_featured_slide_style_array[0];

			$i = 0;
			foreach($gorilla_featured_slide_style_array_in as $key_style => $style){
		        $cloneArray = $gorilla_featured_slide_array;
		        foreach( $cloneArray as $key => $value )
		        {

		            if (strpos($gorilla_featured_slide_array[$key]["post_id"], strval($key_style) ) !== false) {
		               $gorilla_featured_slide_array[$key]["slide_color_style"] = $style;
		               break;
		            }

		        }

				$i++;
		    }

		}*/

		//Sort
		if(isset($_POST["featured_slides_sort"])){
			
			$gorilla_featured_slides_sort = $_POST["featured_slides_sort"];
			$gorilla_featured_slides_sort = explode(",", $gorilla_featured_slides_sort);
			$gorilla_featured_slide_array_new = array();

			$i = 0;
			foreach($gorilla_featured_slides_sort as $key_sort => $sort){
		        $cloneArray = $gorilla_featured_slide_array;
		        foreach( $cloneArray as $key => $value )
		        {
					if ($gorilla_featured_slide_array[$key]["post_id"] == $sort){
		               $gorilla_featured_slide_array_new[$i] = $value;
					   break;
		            }
		        }
				$i++;
		    }

		    $gorilla_featured_slide_array = $gorilla_featured_slide_array_new;
			
		}

		// Amount of Slides
		if(isset($_POST["amount_of_slides"])){
			$gorilla_amount_of_slides = $_POST["amount_of_slides"];
			set_theme_mod("gorilla_featured_area_slides",$gorilla_amount_of_slides);
		}

		// Result
		$gorilla_featured_slide_array = serialize($gorilla_featured_slide_array);
		update_option("gorilla_featured_area_options",$gorilla_featured_slide_array);

	}

?>

<script>
  jQuery(document).ready(function($) {
  	"use strict";

  	var fixHelper = function(e, ui) {
		ui.children().each(function() {
			$(this).width($(this).width());
		});
		return ui;
	};

  	var featured_slider_posts = $( ".featured-slider-posts tbody" );
    featured_slider_posts.sortable({
      revert: true,
      update: function(event, ui) {
      	var featured_slide_ids = $(this).sortable('toArray', { attribute: 'data-post-id' });
      	$('input[name="featured_slides_sort"]').val(featured_slide_ids);
      },
      helper: fixHelper
    });

    featured_slider_posts.disableSelection();

    /*$("select[name='featured_slide_color_style[]']").on("change",function(){
    	var featured_slide_color_style_val = $("input[name='featured_slide_color_style_hidden']").val();
    	featured_slide_color_style_val = $.parseJSON(featured_slide_color_style_val);

    	var changed_id = $(this).parents("tr").data("post-id");
		featured_slide_color_style_val[changed_id] = $(this).val();

		featured_slide_color_style_val = JSON.stringify(featured_slide_color_style_val);

		$("input[name='featured_slide_color_style_hidden']").val(featured_slide_color_style_val);

    });*/

  });

</script>

<div class="wrap">

	<h2>Featured Slider Settings</h2>

	<?php if(isset($_POST['featured_form_hidden']) && $_POST['featured_form_hidden'] == "Y") { ?>
		<div class="updated"><p><strong>Settings saved.</strong></p></div>
	<?php } ?>

	<form method="post" action="">

		<input type="hidden" name="featured_form_hidden" value="Y">

		<div class="clearfix">

			<div class="col-featured-posts">
				<h3>Featured Slider Posts</h3>

		        <?php wp_nonce_field('featuredarea-updatesettings'); ?>

				<?php

					$gorilla_featured_slide_ids = array();
					$gorilla_featured_slide_array = array();
					$gorilla_featured_area_options = get_option("gorilla_featured_area_options");

					if(!empty($gorilla_featured_area_options)){
						$gorilla_featured_slide_array = get_option("gorilla_featured_area_options");
						$gorilla_featured_slide_array = unserialize($gorilla_featured_slide_array);

						foreach ($gorilla_featured_slide_array as $key => $value) {
							$gorilla_featured_slide_ids[] = $value["post_id"];
						}

					}


					if(!empty($gorilla_featured_slide_ids)){

						$args = array(
							'post_type' => 'post',
							'showposts' => -1,
							'orderby'=> 'post__in',
							'post__in' => $gorilla_featured_slide_ids
						);

						$query_featured_posts = new WP_Query( $args );

						// The Loop
						if($query_featured_posts->have_posts()){
							echo '<table class="featured-slider-posts">
							<thead>
								<tr>
									<td class="col-remove">Remove</td>
									<td>Post Name</td>
									<!--<td class="col-text-color">Text Color</td>-->
								</tr>
							</thead>
							<tbody>';
							$gorilla_featured_slide_sort_array = $gorilla_featured_slide_sort = "";

							while ( $query_featured_posts->have_posts() ) {
								$query_featured_posts->the_post();
								$gorilla_title = strip_tags(get_the_title());

								foreach ($gorilla_featured_slide_array as $key => $val) {
									if ($val['post_id'] === strval($query_featured_posts->post->ID)) {
									   $id = $key;
									   break;
									}
							    }

								$gorilla_featured_slide_sort_array[] = $query_featured_posts->post->ID; ?>

								<tr data-post-id="<?php echo esc_attr($query_featured_posts->post->ID); ?>">
									<td style="text-align:center;">
										<input id="post_remove_<?php echo esc_attr($query_featured_posts->post->ID); ?>" name="featured_area_remove_post_checkbox[]" type="checkbox" value="<?php echo esc_attr($query_featured_posts->post->ID); ?>" />
									</td>
									<td>
										<label for="post_remove_<?php echo esc_attr($query_featured_posts->post->ID); ?>"><?php echo esc_html($gorilla_title); ?></label>
									</td>
									<!--<td>
										<select name="featured_slide_color_style[]">
											<option value="light" <?php selected( $gorilla_featured_slide_array[$id]["slide_color_style"], "light" ); ?>>Light Text</option>
											<option value="dark" <?php selected( $gorilla_featured_slide_array[$id]["slide_color_style"], "dark" ); ?>>Dark Text</option>
										</select>
									</td>-->
								</tr>
							
							<?php

								//$gorilla_featured_slide_color_style_array[$query_featured_posts->post->ID] = $gorilla_featured_slide_array[$id]["slide_color_style"];

							}

							echo '</tbody></table>';

							if(!empty($gorilla_featured_slide_sort_array)){
								$gorilla_featured_slide_sort = implode(",", $gorilla_featured_slide_sort_array);
							}

							//$gorilla_featured_slide_color_style_array = json_encode($gorilla_featured_slide_color_style_array);

							echo '<input type="hidden" name="featured_slides_sort" value="'.esc_attr($gorilla_featured_slide_sort).'" />';
							//echo '<input type="hidden" name="featured_slide_color_style_hidden" value="'.esc_attr($gorilla_featured_slide_color_style_array).'" />';

						}

						wp_reset_postdata();

					}
					else { ?>

					<p>No Selected Posts.</p>

				<?php

					}

				?>

				<h3>Amount of Slides</h3>
				<input type="number" name="amount_of_slides" value="<?php echo esc_attr(get_theme_mod('gorilla_featured_area_slides')); ?>" style="width:50px">

				<?php submit_button(__("Save Changes",'alison'),"primary","featured-area-save-changes"); ?>

			</div>

			<div class="col-all-posts">

				<h3>All Posts</h3>

				<?php

					$pagenum = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;

					$args = array(
						'post_type' => 'post',
						'paged' => $pagenum,
		        		'showposts' => '20'
					);

					$query_all_posts = new WP_Query( $args );

					// The Loop
					if($query_all_posts->have_posts()){
						$gorilla_slide_added = false;

						echo '<table class="all-posts">
							<thead>
								<tr>
									<td class="col-add">Add</td>
									<td>Post Name</td>
									<td class="col-date">Post Date</td>
								</tr>
							</thead>
							<tbody>';
						while ( $query_all_posts->have_posts() ) {
							$query_all_posts->the_post();
							$gorilla_title = strip_tags(get_the_title());

							foreach ($gorilla_featured_slide_ids as $key => $value) {					
								if(intval($value) === $query_all_posts->post->ID){ 
									$gorilla_slide_added = true;
									break;
								}
								else {
									$gorilla_slide_added = false;
								}
							}

							if(!$gorilla_slide_added){ ?>
								<tr>
									<td style="text-align:center;">
										<input id="post_<?php echo esc_attr($query_all_posts->post->ID); ?>" name="featured_area_post_checkbox[]" type="checkbox" value="<?php echo esc_attr($query_all_posts->post->ID); ?>" />
									</td>
									<td>
										<label for="post_<?php echo esc_attr($query_all_posts->post->ID); ?>"><?php echo esc_html($gorilla_title); ?></label>
									</td>
									<td><?php echo get_the_date(); ?></td>
								</tr>
						<?php }

						}
						echo '</tbody></table>';
					}

					$total = $query_all_posts->max_num_pages;

					$big = 999999999; // need an unlikely integer
			        
			        if ($total > 1) {
				        $page_links = paginate_links( array(
				            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
				            'format' => '?paged=%#%',
				            'current' => max( 1, $pagenum ),
				            'total' => $total,
				            'prev_text' => __( '&laquo;', 'aag' ),
							'next_text' => __( '&raquo;', 'aag' ),
				        ) );
			        }

			        if ( isset($page_links) ) {
						echo '<div class="tablenav pagination"><div class="tablenav-pages" style="margin: 1em 0">' . $page_links . '</div></div>';
					}


					wp_reset_postdata();

				?>

				<?php submit_button(__("Add Post(s)",'alison'),"primary","featured-slide-add"); ?>

			</div>

		</div>

	</form>

</div>

<?php } ?>