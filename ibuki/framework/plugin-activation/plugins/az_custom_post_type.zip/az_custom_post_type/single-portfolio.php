<?php get_header(); 
$options = get_option('ibuki');
$portfolio_main_url = $options_ibuki['back-to-portfolio-url'];
?>

<div id="content">
    <?php az_page_header_portfolio($post->ID); ?>

    <section class="wrap_content">
	<?php if(have_posts()) : while(have_posts()) : the_post(); ?>
        <?php //edit_post_link( __('Edit', 'textdomain'), '<span class="edit-post">[', ']</span>' ); ?>
        <?php the_content(); ?>

        <?php if( !empty($options['enable-comment-portfolio-area']) && $options['enable-comment-portfolio-area'] == 1) { 

            $comment_section_layout = get_post_meta($post->ID, '_az_comment_section_layout', true);
            $comment_row_layout = get_post_meta($post->ID, '_az_comment_row_layout', true);

        ?>
        <!-- Comments Template Area -->
        <section class="comment-area no_sidebar">
			<div class="<?php echo $comment_section_layout; ?>">
            	<div class="row">
                	<div class="<?php echo $comment_row_layout; ?>">
						<?php comments_template('', true); ?>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Comments Template Area -->
        <?php } ?>

        <?php 
        $back_class = null;
        if( $options['back-to-portfolio'] == 0) { $back_class = ' no-back'; } 
        ?>
        <!-- Navigation Area -->
        <section class="post-type-navi<?php echo $back_class; ?>">
            <ul>
                <?php if( !empty($options['back-to-portfolio']) && $options['back-to-portfolio'] == 1) { ?>
                <li class="back-portfolio"><a href="<?php echo $portfolio_main_url; ?>" title="<?php _e('Back to Portfolio', AZ_THEME_NAME);?>"><?php _e('Back to Portfolio', AZ_THEME_NAME);?><i class="back-portfolio-icon"></i></a></li>
                <?php } ?>
                <li class="prev"><?php next_post_link(('%link'), 'Prev<i class="prev-icon"></i>') ?></li>
                <li class="next"><?php previous_post_link(('%link'), 'Next<i class="next-icon"></i>') ?></li>
            </ul>
        </section>
        <!-- End Navigation Area -->
        
    <?php endwhile; endif; ?>
    </section>

</div>
            
<?php get_footer(); ?>