<?php

	/*	
	*	CrunchPress Gallery Options File
	*	---------------------------------------------------------------------
	* 	@version	1.0
	* 	@author		CrunchPress
	* 	@link		http://crunchpress.com
	* 	@copyright	Copyright (c) CrunchPress
	*	---------------------------------------------------------------------
	*	This file create and contains the gallery post_type meta elements
	*	---------------------------------------------------------------------
	*/
	
	add_action( 'init', 'create_gallery' );
	function create_gallery() {
	
		$labels = array(
			'name' => _x('Gallery', 'Gallery General Name', 'crunchpress'),
			'singular_name' => _x('Gallery Item', 'Gallery Singular Name', 'crunchpress'),
			'add_new' => _x('Add New', 'Add New Gallery Name', 'crunchpress'),
			'add_new_item' => __('Add New Gallery', 'crunchpress'),
			'edit_item' => __('Edit Gallery', 'crunchpress'),
			'new_item' => __('New Gallery', 'crunchpress'),
			'view_item' => '',
			'search_items' => __('Search Gallery', 'crunchpress'),
			'not_found' =>  __('Nothing found', 'crunchpress'),
			'not_found_in_trash' => __('Nothing found in Trash', 'crunchpress'),
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_position' => 5,
			"show_in_nav_menus" => false,
			'supports' => array('title','thumbnail','custom-fields'),
			'rewrite' => array('slug' => 'cpgallery', 'with_front' => false)
		); 
		  
		register_post_type( 'gallery' , $args);
		
	}
	
	
?>