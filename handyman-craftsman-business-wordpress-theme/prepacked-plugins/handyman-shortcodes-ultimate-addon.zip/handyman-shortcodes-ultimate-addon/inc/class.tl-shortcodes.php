<?php
/**
 * Definitions for all shortcodes
 *
 * Class TL_Shortcodes
 *
 * List of shortcodes:
 *
 *
 * 1. Testimonials
 * 2. Portfolio
 * 3. Services
 * 4. Posts?
 * 5. Accordion+spoiler
 *
 *
 */
class TL_Shortcodes
{


    /**
     * @var
     */
    protected static $_instance;


    /**
     * @var array
     */
    protected $_shortcodes;


    /**
     * @var
     */
    protected $_shortcode_handlers;


    protected function __construct()
    {
        $this->_init();
    }


    /**
     * Set map of params for shortcodes and shortcode handlers
     *
     * @return $this
     */
    protected function _init()
    {
        $s['tl_hero'] = array(
            'name' => __('TL Hero Unit', TL_SHORTCODES_ADDON_SLUG),
            'type' => 'wrap',
            'atts' => array(
                'textcolor' => array(
                    'type' => 'color',
                    'values' => array('#222527', '#888888', '#003386', '#f1a51e'),
                    'default' => '#222527',
                    'name' => __( 'Text color', 'su' ),
                    'desc' => __( 'Pick the color for text', 'su' )
                ),
                'bgcolor'   => array(
                    'type' => 'color',
                    'values' => array('transparent'),
                    'default' => 'transparent',
                    'name' => __( 'Background color', 'su' ),
                    'desc' => __( 'Pick the color for backround', 'su' )
                ),
            ),
            'usage' => '[tl_hero]The content[/tl_hero]',
            'desc' => 'Hero Unit'
        );


        $s['tl_tweets'] = array(
            'name' => __('TL Recent Tweets', TL_SHORTCODES_ADDON_SLUG),
            'type' => 'single',
            'atts' => array(
                'consumerkey'=>array(
                    'name'    => __('Customer Key', TL_SHORTCODES_ADDON_SLUG),
                    //'default' => __('', TL_INSERT_STAFF_SLUG),
                    'type'    => 'text',
                ),
                'consumersecret'=>array(
                    'name'    => __('Customer Secret', TL_SHORTCODES_ADDON_SLUG),
                    //'default' => __('', TL_INSERT_STAFF_SLUG),
                    'type'    => 'text',
                ),
                'accesstoken'=>array(
                    'name'    => __('AccessToken', TL_SHORTCODES_ADDON_SLUG),
                    //'default' => __('', TL_INSERT_STAFF_SLUG),
                    'type'    => 'text',
                ),
                'accesstokensecret'=>array(
                    'name'    => __('AccessToken Secret', TL_SHORTCODES_ADDON_SLUG),
                    //'default' => __('', TL_INSERT_STAFF_SLUG),
                    'type'    => 'text',
                ),
                'cachetime'=>array(
                    'name'    => __('Cache time', TL_SHORTCODES_ADDON_SLUG),
                    'type'    => 'slider',
                    'min' => 1,
                    'max' => 24,
                    'step' => 1,
                    'default' => 3,
                ),
                'username'=>array(
                    'name'    => __('Username', TL_SHORTCODES_ADDON_SLUG),
                    'type'    => 'text',
                ),
                'tweetstoshow'=>array(
                    'name'    => __('Number of tweets to display.', TL_SHORTCODES_ADDON_SLUG),
                    'type'    => 'slider',
                    'min' => 1,
                    'max' => 10,
                    'step' => 1,
                    'default' => 3,
                ),
                'excludereplies'=>array(
                    'name'    => __('Exclude Replies', TL_SHORTCODES_ADDON_SLUG),
                    'default' => 'no',
                    'type'    => 'bool',
                ),
            ),
            'usage' => '[tl_tweets]',
            'desc' => 'Recent Tweets',
        );


        $s['tl_testimonial'] = array(
            'name' => __('TL Testimonial', TL_SHORTCODES_ADDON_SLUG),
            'type' => 'single',
            'atts' => array(
                'yelp' => array(
                    'type' => 'text',
                    'name' => __('Link to Yelp Reviews', TL_SHORTCODES_ADDON_SLUG),
                    'default' => 'http://yelp.com',
                )
            ),
            'usage' => '[tl_testimonial]',
            'desc' => 'Testimonials',
        );


        $s['tl_blockquote'] = array(
            'name' => __('TL Blockquote', TL_SHORTCODES_ADDON_SLUG),
            'type' => 'wrap',
            'atts' => array(),
            'usage' => '[tl_blockquote]',
            'desc' => 'Blockquote',
        );


        $s['tl_contactinfo'] = array(
            'name' => __('TL Contact Info', TL_SHORTCODES_ADDON_SLUG),
            'type' => 'single',
            'atts' => array(
                'info1' => array(
                    'type' => 'text',
                    'default' => 'Contact Us Today',
                    'name' => __('Info 1', TL_SHORTCODES_ADDON_SLUG),
                ),
                'info2' => array(
                    'type' => 'text',
                    'default' => 'We Answer Our Phones 24/7',
                    'name' => __('Info 2', TL_SHORTCODES_ADDON_SLUG),
                ),
                'phone' => array(
                    'type' => 'text',
                    'default' => '0800 123 456',
                    'name' => __('Phone number', TL_SHORTCODES_ADDON_SLUG),
                ),
            ),
            'content' => '0800 123 456',
            'desc' => __('Short sentence + phone number', TL_SHORTCODES_ADDON_SLUG),
        );


        $s['tl_fontweight'] = array(
            'name' => __('TL Text Weight', TL_SHORTCODES_ADDON_SLUG),
            'type' => 'wrap',
            'atts' => array(
                'weight' => array(
                    'type' => 'slider',
                    'min' => 100,
                    'max' => 700,
                    'step' => 100,
                    'default' => 500,
                    'name' => __('Weight', TL_SHORTCODES_ADDON_SLUG),
                ),
            ),
            'content' => __('This is the content', TL_SHORTCODES_ADDON_SLUG),
            'desc' => __('Change default text weight', TL_SHORTCODES_ADDON_SLUG),
            'example' => '[tl_fontweight]Text[/tl_fontweight]'
        );


        // spoiler
        $s['tl_spoiler'] = array(
            'name' => __('TL Spoiler', TL_SHORTCODES_ADDON_SLUG),
            'type' => 'wrap',
            'atts' => array(
                'title' => array(
                    'default' => __('Spoiler title', TL_SHORTCODES_ADDON_SLUG),
                    'name' => __('Title', TL_SHORTCODES_ADDON_SLUG), 'desc' => __('Text in spoiler title', TL_SHORTCODES_ADDON_SLUG)
                ),
                'icon' => array(
                    'type' => 'select',
                    'values' => array(
                        'ok-icon' => __('Checked', TL_SHORTCODES_ADDON_SLUG),
                        'announcement-icon' => __('Annoncement', TL_SHORTCODES_ADDON_SLUG),
                    ),
                    'default' => 'ok-icon',
                    'name' => __('Icon', TL_SHORTCODES_ADDON_SLUG),
                    'desc' => __('Icons for spoiler', TL_SHORTCODES_ADDON_SLUG)
                ),
                'class' => array(
                    'default' => '',
                    'name' => __('Class', TL_SHORTCODES_ADDON_SLUG),
                    'desc' => __('Extra CSS class', TL_SHORTCODES_ADDON_SLUG)
                )
            ),
            'content' => __('This is the content', TL_SHORTCODES_ADDON_SLUG),
            'desc' => __('Spoiler with content', TL_SHORTCODES_ADDON_SLUG),
            'note' => __('Did you know that you can wrap multiple spoilers with [accordion] shortcode to create accordion effect?', 'su'),
            'example' => 'tl_spoilers',
            'icon' => 'list-ul'
        );


        // Mark

        $s['tl_mark'] = array(
            'name' => __('TL Mark', TL_SHORTCODES_ADDON_SLUG),
            'type' => 'wrap',
            'atts' => array(),
            'usage' => '[tl_mark]',
            'desc' => 'Mark text',
        );

        $this->_shortcodes = $s;
        return $this;
    }


    /**
     * Register shortcodes
     */
    public function doShortcodeHandlers()
    {
        /**
         * @param $atts
         * @param $content
         * @return string
         */
        $sh['tl_hero'] = function($atts, $content){

            $atts = shortcode_atts(array(
                'textcolor' => '#222527',
                'bgcolor'   => 'transparent',
            ), $atts, 'tl_hero');

            extract($atts);
            $has_bg = '';
            if($bgcolor != 'transparent' && $bgcolor != ''){
                $has_bg = 'has-bg';
            }

            $html = '<p class="tl-hero ' . esc_attr($has_bg) . '" style="color:' . esc_attr($textcolor) . '; background-color:' . esc_attr($bgcolor) . '">' . su_do_shortcode($content, 'm') . '</p>';
            return $html;
        };


        /**
         * @param $atts
         */
        $sh['tl_tweets'] = function($atts){

            $atts = shortcode_atts(array(
                'consumerkey'    => '',
                'consumersecret' => '',
                'accesstoken'    => '',
                'accesstokensecret' => '',
                'cachetime'     => 3,
                'username'      =>'',
                'tweetstoshow'  => 3,
                'excludereplies'=> 'no'
            ), $atts, 'tl_tweets');

            the_widget( 'TL_Recent_Tweets', $atts );
        };


        /**
         * @param $atts
         * @param $content
         * @return string
         */
        $sh['tl_testimonial'] = function($atts, $content){

            $atts = shortcode_atts(array('yelp' => null), $atts, 'tl_testimonial');

            extract($atts);

            $single = false;
            $testimonials = get_posts(array(
                                        'post_type' => 'tl_testimonial',
                                        'order'       => 'ASC',
                                        'orderby'     => 'menu_order',
                                        'post_status' => 'publish',
                                        'posts_per_page' => -1,
                                        'suppress_filters' => false
            ));

            if(count($testimonials) == 0) return '';
            if(count($testimonials) == 1) $single = true;

            $rand = rand(1,1000);
            $testimonial_id = 'testimonials-' . $rand;

            $js = '  <script type="text/javascript">
                        (function($) {
                          "use strict";
                            $(document).ready(function(){
                                var testimonial_swiper_'.$rand.' = new Swiper(\'#'.$testimonial_id.'\', {
                                      wrapperClass: "tl-testimonials-wrapper",
                                      resizeReInit:true,
                                      slideClass: "tl-blockquote",
                                      loop: true,
                                      slidesPerView:1
                                  });

                                  $("#'.$testimonial_id.' .swiper-arrows a[class^=\'swiper-button-\']").on("click", function(e){
                                        e.preventDefault();
                                        var $that = $(this);

                                        if($that.hasClass("swiper-button-next")){
                                            testimonial_swiper_'.$rand.'.slideNext();
                                        }
                                        if($that.hasClass("swiper-button-prev")){
                                            testimonial_swiper_'.$rand.'.slidePrev();
                                        }
                                });

                                testimonial_swiper_'.$rand.'.init();
                                 //Dirty hack!
                                setTimeout(function(){
                                     testimonial_swiper_'.$rand.'.init();
                                }, 1000);
                            });
                            })(jQuery);
                        </script>';

            $html = '<div id="'.$testimonial_id.'" class="tl-testimonials-container">';
                $html .= '<div class="tl-testimonials-wrapper">';

                foreach($testimonials as $t){
                    $html .= '<div class="tl-blockquote swiper-slide">
                                <blockquote>
                                    ' .  su_do_shortcode($t->post_content, 'm') . '
                                </blockquote>
                                <span>- '. apply_filters('the_title', $t->post_title).'</span>
                              </div>';
                }
                $html .= '</div>';

                $html .= '<div class="swiper-arrows">';

                if(!$single){
                    $html .= '<a class="swiper-button-prev"><i class="icon-ti-arrow-left"></i></a>
                              <a class="swiper-button-next"><i class="icon-ti-arrow-right"></i></a>';
                }
                if($yelp){
                    $html .= '<span class="yelp">' .__('Read all our reviews on:', TL_SHORTCODES_ADDON_SLUG) . '<a title="Yelp" target="_blank" href="' . esc_url($yelp) . '"><img alt="Yelp" src="'.TL_INSERT_STAFF_URI.'assets/images/yelp.png" /></a></span>';
                }
                $html .= '</div>';
            $html .= $js;
            $html .= '</div>';

            wp_reset_postdata();
            return $html;
        };


        /**
         * @param $atts
         * @param $content
         * @return string
         */
        $sh['tl_blockquote'] = function ($atts, $content) {
            return '<div class="tl-blockquote"><blockquote>' . su_do_shortcode($content, 'm') . '</blockquote></div>';
        };


        /**
         * @param $atts
         * @param null $content
         * @return string
         */
        $sh['tl_contactinfo'] = function ($atts, $content = null) {

            $atts = shortcode_atts(array(
                'info1' => 'Contact Us Today',
                'info2' => 'We Answer Our Phones 24/7',
                'phone' => '0800 123 456'
            ), $atts, 'tl_contactinfo');

            $atts['phone'] = esc_html($atts['phone']);
            $digits        = explode(' ', $atts['phone']);

            if (count($digits) > 1) {
                $digits[0]     = '<span>' . $digits[0] . '</span>';
                $atts['phone'] = implode(' ', $digits);
            }

            $html = '<div class="tl-contactinfo">';
            $html .= '<ul>';
            $html .= '<li>' . __(' - or - ', TL_SHORTCODES_ADDON_SLUG) . '</li>';
            $html .= '<li class="text1">' . esc_html($atts['info1']) . ' - <span>' . esc_html($atts['info2']) . '</span></li>';
            $html .= '<li class="phonedigits"><i class="fa fa-phone"></i>' . $atts['phone'] . '</li>';
            $html .= '</ul></div>';

            return $html;
        };


        /**
         * @param $atts
         * @param null $content
         * @return string
         */
        $sh['tl_fontweight'] = function ($atts, $content = null) {

            $atts = shortcode_atts(array(
                'title' => 'This is the content',
                'weight' => 500
            ), $atts, 'tl_fontweight');

            return '<p style="font-weight: ' . esc_attr($atts['weight']) . '">' . su_do_shortcode($content, 's') . '</p>';
        };


        // TL spoiler
        /**
         * @param $atts
         * @param null $content
         * @return string
         */
        $sh['tl_spoiler'] = function ($atts, $content = null) {

            $atts = shortcode_atts(array(
                'title' => 'This is spoiler title',
                'icon' => 'ok-icon',
                'class' => ''
            ), $atts, 'tl_spoiler');

            $sh = '<div class="tl-spoiler ' . esc_attr($atts['class']) . '">
                        <h6 class="' . esc_attr($atts['icon']) . '">' . esc_html(su_scattr($atts['title'])) . '</h6>
                        <div class="su-clearfix tl-spoiler-content">' . su_do_shortcode($content, 's') . '</div>
                  </div>';

            return $sh;
        };


        // tl button
        /**
         * @param $atts
         * @param null $content
         * @return null|string
         */
        $sh['tl_button'] = function ($atts, $content = null) {

            extract(shortcode_atts(array(
                'color' => 'red', /* red, grey, dark */
                'label' => '',
                'url' => '#',
                'target' => '_blank',
            ), $atts, 'tl_button'));

            $content = '<a target="' . esc_attr($target) . '" href="' . esc_url($url) . '" class="tl-button ' . esc_attr($color) . '">' . esc_html($label) . '</a>';
            return $content;
        };


        // tlareli dropcap

        /**
         * @param $atts
         * @param null $content
         * @return null|string
         */
        $sh['tl_dropcap'] = function ($atts, $content = null) {

            extract(shortcode_atts(array(
                'type' => 'dropcap',
            ), $atts));
            $content = '<span class="' . esc_attr($type) . '">' . esc_html($content) . '</span>';
            return $content;
        };


        // Mazzareli dashed line
        /**
         * @param $atts
         * @param null $content
         * @return string
         */
        $sh['tl_dashed'] = function ($atts, $content = null) {
            return '<div class="dashed"></div>';
        };


        // Image with frame
        /**
         * @param $atts
         * @return string
         */
        $sh['tl_imgframe'] = function ($atts) {

            extract(shortcode_atts(array(
                'type' => 'light', /* light, dark */
                'responsive' => 'yes',
                'width' => '320',
                'height' => '200',
                'source' => 'none',
                'link' => '',
                'target' => '_self',
                'alignment' => 'none'
            ), $atts));

            $atts['limit'] = 1;

            $images = (array)\Su_Tools::get_slides($atts);
            $content = '';

            if (count($images)) {

                $images = $images[0];
                $height = (int)$height;
                $width = (int)$width;

                //Resize image
                $resized = \su_image_resize($images['image'], $width, $height);


                if ($responsive == 'no') {
                    $height = ($height > 0) ? 'width="' . esc_attr($height) . '"' : '';
                    $width = ($width > 0) ? 'width="' . esc_attr($width) . '"' : '';
                } else {
                    $height = $width = '';
                }

                $responsive = ($responsive == 'yes') ? 'responsive' : '';
                $alignment = $alignment == 'none' ? '' : $alignment;

                $content = '<img src="' . esc_url($resized['url']) . '" ' . $width . ' ' . $height . ' class="' . esc_attr($alignment) . ' tl-frame-' . $type . ' ' . $responsive . '" alt="' . esc_attr($images['title']) . '"/>';

                if ($link) {
                    $content = '<a href="' . esc_url($link) . '" title="' . esc_attr($images['title']) . '">' . $content . '</a>';
                }
            } else {
                $content = \Su_Tools::error(__FUNCTION__, __('images not found', 'su'));
            }
            return $content;
        };


        // Mark

        /**
         * @param $atts
         * @param $content
         * @return string
         */
        $sh['tl_mark'] = function ($atts, $content) {
            return '<mark class="tl-mark">' . su_do_shortcode($content, 'm') . '</mark>';
        };


        $this->_shortcode_handlers = $sh;
        foreach ($this->_shortcode_handlers as $k => $v) {
            add_shortcode(\su_cmpt() . $k, $v);
        }
    }


    /**
     * Get map for shortcodes
     */
    public function getInterfaces($key = 'all')
    {
        if ($key == 'all') {
            return $this->_shortcodes;
        } else {
            return $this->_shortcodes[$key];
        }
    }


    /**
     * @return __CLASS__
     */
    public static function single()
    {
        if (self::$_instance === null) {
            self::$_instance = new TL_Shortcodes();
        }
        return self::$_instance;
    }
}