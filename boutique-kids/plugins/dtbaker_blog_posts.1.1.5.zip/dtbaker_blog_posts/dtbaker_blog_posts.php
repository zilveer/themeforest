<?php 

/** 
 * Plugin Name: dtbaker Blog Posts 
 * Description: Display blog posts on any page of your website 
 * Plugin URI: http://dtbaker.net 
 * Version: 1.1.5 
 * Author: dtbaker 
 * Author URI: http://dtbaker.net 
 * Text Domain: dtbaker_blog_posts 
 */ 



/**
 * Class dtbaker_blog_posts
 * handles the creation of [blog_posts] shortcode
 * adds a button in MCE editor allowing easy creation of shortcode
 * creates a wordpress view representing this shortcode in the editor
 * edit/delete button on wp view as well makes for easy shortcode managements.
 *
 * separate css is in style.content.css - this is loaded in frontend and also backend with add_editor_style
 *
 * Author: dtbaker@gmail.com
 * Copyright 2014
 */
class dtbaker_blog_posts {
	private static $instance = null;
	public static function get_instance() {
		if ( ! self::$instance )
			self::$instance = new self;
		return self::$instance;
	}
	public $public_base_url = '';
	public function init(){
		//$this->public_base_url = get_template_directory_uri().'/plugins/blog_posts';
		$this->public_base_url = trailingslashit(plugins_url('/',__FILE__));
		// comment this 'add_action' out to disable shortcode backend mce view feature
		add_action( 'admin_init', array( $this, 'init_plugin' ), 20 );
		add_action( 'wp_enqueue_scripts', array( $this, 'init_frontend_scripts' ), 20 );
		add_shortcode( 'blog_posts', array( $this, 'dtbaker_blog_posts_render' ) );
		// elementor integration:
		add_action( 'elementor/widgets/widgets_registered', array( $this, 'widgets_registered' ) );
	}

	public function init_plugin() {
		//
		// This plugin is a back-end admin ehancement for posts and pages
		//
		if ( current_user_can('edit_posts') || current_user_can('edit_pages') ) {
			add_action( 'print_media_templates', array( $this, 'print_media_templates' ) );
			add_action( 'admin_print_footer_scripts', array( $this, 'admin_print_footer_scripts' ), 100 );
			add_action( 'wp_ajax_dtbaker_plugin_buttons', array( $this, 'wp_ajax_dtbaker_plugin_buttons' ) );
			add_action( 'dtbaker_plugin_button_code', array( $this, 'dtbaker_plugin_button_code' ) );
			add_filter( "mce_external_plugins", array( $this, 'mce_plugin' ) );
			add_filter( "mce_buttons", array( $this, 'mce_button' ) );
			//add_editor_style( $this->public_base_url . '/css/blog_posts.css' );
		}

	}

	public function widgets_registered() {

		if(defined('ELEMENTOR_PATH') && class_exists('Elementor\Widget_Base')){
			// get our own widgets up and running:
			// copied from widgets-manager.php

			$widget_file = 'plugins/elementor/blog-posts.php';
			$template_file = locate_template($widget_file);
			if ( !$template_file || !is_readable( $template_file ) ) {
				$template_file = plugin_dir_path(__FILE__).'elementor-blog-posts.php';
			}
			if ( $template_file && is_readable( $template_file ) ) {
				require_once $template_file;
				Elementor\Plugin::instance()->widgets_manager->register_widget( 'Elementor\Widget_dtbaker_Blog_Posts' );
			}
		}
	}

	public function init_frontend_scripts(){
		//wp_enqueue_style( 'dtbaker_blog_posts', $this->public_base_url . '/css/blog_posts.css', false, '1.0.0' );
	}

	// front end shortcode displaying:
	public function dtbaker_blog_posts_render($atts=array(), $innercontent='', $code='') {
//		if(!$atts)return;
		$sc_atts = shortcode_atts(
			array(
				'columns' => 2,
				'posts_per_page' => 10,
				'output' => 'summary',
			),
			$atts
		);
		//$sc_atts['id'] = strtolower(preg_replace('#\W+#','', $sc_atts['text'])); // lets put everything in the view-data object
		$sc_atts = json_decode( json_encode( $sc_atts ) ); // slightly evil way of making $sc_atts an object
		// Use Output Buffering feature to have PHP use it's own enging for templating
		ob_start();
//		echo __DIR__.'/views/dtbaker_blog_posts_view.php';
		include __DIR__.'/views/dtbaker_blog_posts_view.php';
		return ob_get_clean();
	}
	public function wp_ajax_dtbaker_plugin_buttons() {
		if ( isset( $GLOBALS['dtbaker_done_plugin_buttons'] ) ) {
			die();
		}
		$GLOBALS['dtbaker_done_plugin_buttons'] = true;
		header( "Content-type: text/javascript" );
		do_action( 'dtbaker_plugin_button_code' );
	}
	public function dtbaker_plugin_button_code(){
		include_once __DIR__.'/js/dtbaker_blog_posts_inline.js';
	}
	public function mce_plugin($plugin_array){
		$plugin_array['dtbaker_plugin_buttons'] = admin_url('admin-ajax.php?action=dtbaker_plugin_buttons');
		return $plugin_array;
	}
	public function mce_button($buttons){
		array_push($buttons, 'dtbaker_mce_blog_posts');
		return $buttons;
	}
	/**
	 * Outputs the view inside the wordpress editor.
	 */
	public function print_media_templates() {
		if ( ! isset( get_current_screen()->id ) || get_current_screen()->base != 'post' )
			return;
		include_once __DIR__.'/templates/tmpl_editor_dtbaker_blog_posts.html';
	}
	public function admin_print_footer_scripts() {
		if ( ! isset( get_current_screen()->id ) || get_current_screen()->base != 'post' )
			return;
		include_once __DIR__.'/templates/script_editor_dtbaker_blog_posts.html';
	}
}
dtbaker_blog_posts::get_instance()->init();