/********************************
*
*   Open the font selector
*
********************************/
function openVideoUploader($id){
	var div = jQuery('#shortcodelic_video_generator'),
		h = jQuery(window).height(),
		dialog,
		overlay = false;
	if ( jQuery('#shortcodelic-modal-overlay').length ) {
		overlay = true;
	}
	div.dialog({
		height: (h*0.8),
		width: '600',
		modal: false,
		dialogClass: 'wp-dialog shortcodelic-dialog shortcodelic-one-col-dialog',
		position: { my: "center", at: "center", of: window },
		title: div.data('title'),
		zIndex: 100,
		open: function(){
			jQuery('select option[value=""]', div).prop('selected',true);
			jQuery('input', div).val('');
			if ( overlay === false ) {
				jQuery('body').addClass('overflow_hidden').append('<div id="shortcodelic-modal-overlay" />');
			}
			var tdial = jQuery(this);
			tdial.scrollTop(0);
			tdial.closest('.ui-dialog').find('.ui-button').eq(0).addClass('ui-dialog-titlebar-edit');
			getSelectValue(tdial);
			init_sliders();
			init_farbtastic();
			var set = setTimeout(function(){ jQuery(window).triggerHandler('resize'); },100);
		},
		buttons: {
			'': function() {
				var sc = '[shortcodelic-video';
				if ( jQuery('[data-name="mp4"]').val()!=='' ) sc = sc+' mp4="'+jQuery('[data-name="mp4"]').val()+'"';
				if ( jQuery('[data-name="ogg"]').val()!=='' ) sc = sc+' ogg="'+jQuery('[data-name="ogg"]').val()+'"';
				if ( jQuery('[data-name="webm"]').val()!=='' ) sc = sc+' webm="'+jQuery('[data-name="webm"]').val()+'"';
				if ( jQuery('[data-name="autoplay"] option:selected').val()=='true' ) sc = sc+' autoplay="true"';
				if ( jQuery('[data-name="loop"] option:selected').val()=='true' ) sc = sc+' loop="true"';
				if ( jQuery('[data-name="fullsize"] option:selected').val()=='true' ) sc = sc+' fullsize="true"';
				if ( jQuery('[data-name="volume"]').val()!=='' ) sc = sc+' volume="'+jQuery('[data-name="volume"]').val()+'"';
				sc = sc+']';
				tinyMCE.get($id).selection.setContent( sc );
				jQuery( this ).dialog( "close" );
			}
		},
		close: function(){
			if ( overlay === false ) {
				jQuery('body').removeClass('overflow_hidden');
				jQuery('#shortcodelic-modal-overlay').remove();
			}
		}
	});
	jQuery(window).bind('resize',function() {
		h = jQuery(window).height();
		jQuery(div).dialog('option',{'height':(h*0.8),'position':{ my: "center", at: "center", of: window }});
	})/*.triggerHandler('resize')*/;
}

/********************************
*
*   Open the sidebar selector
*
********************************/
function openSidebarSelector($id){
	var div = jQuery('#shortcodelic_sidebars_generator'),
		h = jQuery(window).height(),
		dialog,
		overlay = false;
	if ( jQuery('#shortcodelic-modal-overlay').length ) {
		overlay = true;
	}
	div.dialog({
		height: 300,
		width: '600',
		modal: false,
		dialogClass: 'wp-dialog shortcodelic-dialog shortcodelic-one-col-dialog',
		position: { my: "center", at: "center", of: window },
		title: div.data('title'),
		zIndex: 100,
		open: function(){
			jQuery('select option[value=""]', div).prop('selected',true);
			if ( overlay === false ) {
				jQuery('body').addClass('overflow_hidden').append('<div id="shortcodelic-modal-overlay" />');
			}
			var tdial = jQuery(this);
			tdial.scrollTop(0);
			tdial.closest('.ui-dialog').find('.ui-button').eq(0).addClass('ui-dialog-titlebar-edit');
			getSelectValue(tdial);
			init_sliders();
			init_farbtastic();
			var set = setTimeout(function(){ jQuery(window).triggerHandler('resize'); },100);
		},
		buttons: {
			'': function() {
				var sc = '[shortcodelic-sidebar';
				if ( jQuery('select option:selected', div).val()!=='' ) sc = sc+' sidebar="'+jQuery('select option:selected', div).val()+'"';
				sc = sc+']';
				tinyMCE.get($id).selection.setContent( sc );
				jQuery( this ).dialog( "close" );
			}
		},
		close: function(){
			if ( overlay === false ) {
				jQuery('body').removeClass('overflow_hidden');
				jQuery('#shortcodelic-modal-overlay').remove();
			}
		}
	});
	jQuery(window).bind('resize',function() {
		h = jQuery(window).height();
		jQuery(div).dialog('option',{'position':{ my: "center", at: "center", of: window }});
	})/*.triggerHandler('resize')*/;
}

/********************************
*
*   Open the portfolio shortcode generator
*
********************************/
function openPortfolioSelector($id){
	var div = jQuery('#shortcodelic_portfolio_generator'),
		h = jQuery(window).height(),
		dialog,
		overlay = false;
	if ( jQuery('#shortcodelic-modal-overlay').length ) {
		overlay = true;
	}
	div.dialog({
		height: (h*0.8),
		width: 600,
		modal: false,
		dialogClass: 'wp-dialog shortcodelic-dialog shortcodelic-one-col-dialog',
		position: { my: "center", at: "center", of: window },
		title: div.data('title'),
		zIndex: 100,
		open: function(){
			var selection = tinyMCE.get($id).selection.getContent();
			if ( selection!=='' && selection.match(/\[shortcodelic-portfolio (.*?)\]/)) {
				var match = selection.match(/\[shortcodelic-portfolio (.*?)\]/);
				match = match[1].split(" ");
				jQuery.each(match, function( index, value ) {
					val = value.replace(/(.*?)=\"(.*?)\"/g, function(match, p1, p2) {
						if ( jQuery('[data-name="'+p1+'"][multiple]', div).length || jQuery('input[data-name="'+p1+'"]', div).length ) {
							jQuery('[data-name="'+p1+'"]', div).val(p2.split(','));
						} else {
							jQuery('select[data-name="'+p1+'"]', div).find('option[value="'+p2+'"]').prop('selected',true);
						}
					});
				});
			} else {
				jQuery('select', div).prop('selectedIndex',0);
				jQuery('input', div).val('');
			}
			if ( overlay === false ) {
				jQuery('body').addClass('overflow_hidden').append('<div id="shortcodelic-modal-overlay" />');
			}
			var tdial = jQuery(this);
			tdial.scrollTop(0);
			tdial.closest('.ui-dialog').find('.ui-button').eq(0).addClass('ui-dialog-titlebar-edit');
			getSelectValue(tdial);
			init_sliders();
			var set = setTimeout(function(){ jQuery(window).triggerHandler('resize'); },100);
		},
		buttons: {
			'': function() {
				var sc = '[shortcodelic-portfolio';
				jQuery('select, input', div).each(function(){
					var val;
					if ( jQuery(this).is('select:not([multiple])') ) {
						val = jQuery('option:selected',this).val();
						sc = sc+' '+jQuery(this).data('name')+'="'+val+'"';
					} else {
						val = jQuery(this).val();
						if ( typeof val !== 'string' ) {
							val = val.toString();
							if (val.substring(0, 1) == ',') {
								val = val.substring(1);
							}
						}
						sc = sc+' '+jQuery(this).data('name')+'="'+val+'"';
					}
				});
				sc = sc+']';
				tinyMCE.get($id).selection.setContent( sc );
				jQuery( this ).dialog( "close" );
			}
		},
		close: function(){
			if ( overlay === false ) {
				jQuery('body').removeClass('overflow_hidden');
				jQuery('#shortcodelic-modal-overlay').remove();
			}
		}
	});
	jQuery(window).bind('resize',function() {
		h = jQuery(window).height();
		jQuery(div).dialog('option',{'height':(h*0.8),'position':{ my: "center", at: "center", of: window }});
	})/*.triggerHandler('resize')*/;
}

/********************************
*
*   Open the posts shortcode generator
*
********************************/
function openPostsSelector($id){
	var div = jQuery('#shortcodelic_posts_generator'),
		h = jQuery(window).height(),
		dialog,
		overlay = false;
	if ( jQuery('#shortcodelic-modal-overlay').length ) {
		overlay = true;
	}
	div.dialog({
		height: (h*0.8),
		width: 600,
		modal: false,
		dialogClass: 'wp-dialog shortcodelic-dialog shortcodelic-one-col-dialog',
		position: { my: "center", at: "center", of: window },
		title: div.data('title'),
		zIndex: 100,
		open: function(){
			var selection = tinyMCE.get($id).selection.getContent();
			if ( selection!=='' && selection.match(/\[shortcodelic-posts (.*?)\]/)) {
				var match = selection.match(/\[shortcodelic-posts (.*?)\]/);
				match = match[1].split(" ");
				jQuery.each(match, function( index, value ) {
					val = value.replace(/(.*?)=\"(.*?)\"/g, function(match, p1, p2) {
						if ( jQuery('[data-name="'+p1+'"][multiple]', div).length || jQuery('input[data-name="'+p1+'"]', div).length ) {
							jQuery('[data-name="'+p1+'"]', div).val(p2.split(','));
						} else {
							jQuery('select[data-name="'+p1+'"]', div).find('option[value="'+p2+'"]').prop('selected',true);
						}
					});
				});
			} else {
				jQuery('select', div).prop('selectedIndex',0);
				jQuery('input', div).val('');
			}
			if ( overlay === false ) {
				jQuery('body').addClass('overflow_hidden').append('<div id="shortcodelic-modal-overlay" />');
			}
			var tdial = jQuery(this);
			tdial.scrollTop(0);
			tdial.closest('.ui-dialog').find('.ui-button').eq(0).addClass('ui-dialog-titlebar-edit');
			getSelectValue(tdial);
			init_sliders();
			var set = setTimeout(function(){ jQuery(window).triggerHandler('resize'); },100);
		},
		buttons: {
			'': function() {
				var sc = '[shortcodelic-posts';
				jQuery('select, input', div).each(function(){
					var val;
					if ( jQuery(this).is('select:not([multiple])') ) {
						val = jQuery('option:selected',this).val();
						sc = sc+' '+jQuery(this).data('name')+'="'+val+'"';
					} else {
						val = jQuery(this).val();
						if ( typeof val !== 'string' ) {
							val = val.toString();
							if (val.substring(0, 1) == ',') {
								val = val.substring(1);
							}
						}
						sc = sc+' '+jQuery(this).data('name')+'="'+val+'"';
					}
				});
				sc = sc+']';
				tinyMCE.get($id).selection.setContent( sc );
				jQuery( this ).dialog( "close" );
			}
		},
		close: function(){
			if ( overlay === false ) {
				jQuery('body').removeClass('overflow_hidden');
				jQuery('#shortcodelic-modal-overlay').remove();
			}
		}
	});
	jQuery(window).bind('resize',function() {
		h = jQuery(window).height();
		jQuery(div).dialog('option',{'height':(h*0.8),'position':{ my: "center", at: "center", of: window }});
	})/*.triggerHandler('resize')*/;
}

/********************************
*
*   Upload media
*
********************************/
var uploadImagesScAdd = function(){
	jQuery('.shortcodelic_meta .pix_upload').each(function(){
		var id = jQuery('input[data-type$="id"]', this).val(),
			field = jQuery('.img_preview', this);

		if ( id!=='' ) {
			field.addClass('filled');
			if ( jQuery.isFunction(jQuery.fn.geodeGetThumbnailUrl) ) {
				geodeGetThumbnailUrl(id, field, '');
			}
		}

		jQuery(this).off('click', '.pix_remove_img');
		jQuery(this).on('click', '.pix_remove_img', function( e ){
			e.preventDefault();
			field.removeClass('filled');
			field.css({backgroundImage: 'none'});
			jQuery('input[data-type="id"]',this).val('');
			jQuery('input[data-type="size"]',this).val('');
		});
	});

	jQuery('.shortcodelicadd_meta').off('click','.pix_upload.upload_image a.pix_button, .pix_upload.upload_image span.img_preview');
	jQuery('.shortcodelicadd_meta').on('click', '.pix_upload.upload_image a.pix_button, .pix_upload.upload_image span.img_preview', function( e ){
		e.preventDefault();
		var button = jQuery(this),
			wrap = button.parents('.pix_upload').eq(0);

		var pix_media_frame = wp.media.frames.pix_media_frame = wp.media({

			className: 'media-frame pix-media-frame',
			frame: 'post',
			multiple: false,
			library: {
				type: 'image'
			}
		});

		pix_media_frame.on('insert', function(){
			var media_attachments = pix_media_frame.state().get('selection').toJSON(),
				thumbSize = jQuery('.attachment-display-settings select.size option:selected').val(),
				thumbUrl;

/******************************** Fill the input ********************************/
			jQuery.each(media_attachments, function(index, el) {
				var url = this.url,
					id = this.id,
					size = typeof thumbSize!=='undefined' ? thumbSize : '',
					field = wrap.find('.img_preview').addClass('filled');
				geodeGetThumbnailUrl(id, field, '');
				wrap
					.find('input[data-type="id"]').val(id).end()
					.find('input[data-type="size"]').val(size);

			});
/******************************** Fill the input ********************************/
		});

		pix_media_frame.open();
		jQuery('.media-menu a').eq(1).hide();
		jQuery('.media-toolbar-secondary').hide();
	});

	jQuery('.shortcodelicadd_meta').off('click', '.pix_upload.upload_video a');
	jQuery('.shortcodelicadd_meta').on('click', '.pix_upload.upload_video a', function( e ){
		e.preventDefault();
		var button = jQuery(this);

		var pix_media_frame = wp.media.frames.pix_media_frame = wp.media({

			className: 'media-frame pix-media-frame',
			frame: 'post',
			multiple: false,
			library: {
				type: 'video'
			}
		});

		pix_media_frame.on('insert', function(){
			var media_attachment = pix_media_frame.state().get('selection').first().toJSON(),
				previewUrl;
			//console.log(media_attachment);
			url = media_attachment.url;
			button.parents('.pix_upload').eq(0).find('input').val(url);
			button.off('click');
		});

		pix_media_frame.open();
	});

};

jQuery(document).ready(function(){
	uploadImagesScAdd();
});