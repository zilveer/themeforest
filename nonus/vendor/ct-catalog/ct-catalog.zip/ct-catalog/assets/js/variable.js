jQuery(document).ready(function () {
    "use strict";
    jQuery(".variations_button").remove();
});
