<?php
require_once 'class.abstract-post-type.php';
if (!class_exists('TL_Team_Post_Type')) {

    /**
     * Class TL_Team_Post_Type
     */
    class TL_Team_Post_Type extends TL_Abstract_Post_Type
    {

        /**
         * Custom meta fields related to this CPT
         * @var array
         */
        protected  $_meta_fields = array();


        public function __construct()
        {
            parent::__construct(
                array(
                    'post_type_name' => 'tl_team',
                    'singular' => 'Team Member',
                    'plural' => 'Team Members',
                    'slug' => 'tl_team'
                ),
                array(
                    'public' => true,
                    'exclude_from_search' => false,
                    'publicly_queryable' => true,
                    'show_ui' => true,
                    'menu_position' => 20,
                    'capability_type' => 'post',
                    'hierarchical' => false,
                    'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
                    'can_export' => true,
                    'has_archive' => false,
                    'taxonomies' => array()
                )
            );

            // Available meta fields
            $this->_meta_fields = array(
                '_tl_member_position',
                '_tl_member_fb',
                '_tl_member_gp',
                '_tl_member_ld',
                '_tl_member_yt',
                '_tl_member_tw',
                '_tl_member_pin',
                '_tl_member_cl',
            );

            // Alter placeholder value on add new post item screen
            add_filter('enter_title_here', array($this, 'changeDefaultTitle'));

            add_filter('tl/cpt_' . $this->post_type_name . '/get_meta'     , array($this, 'getMeta'));
            add_filter('tl/cpt_' . $this->post_type_name . '/filter_meta'  , array($this, 'filterMeta'));
            add_filter('tl/cpt_' . $this->post_type_name . '/get_meta_keys', array($this, 'getMetaKeys'),10, 0);

            //@todo investigate
            // Add Template locations
            //add_filter('layers_template_locations', [$this, 'addTemplateLocations']);
        }


        /**
         * @param $post_id
         * @return bool
         */
        public function getMeta($post_id)
        {
            return false;
        }



        /**
         * @return array
         */
        public function getMetaKeys()
        {
            return $this->_meta_fields;
        }



        /**
         * @param $metas
         * @return array
         */
        public function filterMeta($metas)
        {
            return $metas;
        }


        /**
         *
         * @param $title
         * @return string|void
         */
        public function changeDefaultTitle($title)
        {
            $screen = get_current_screen();
            if ($this->slug == $screen->post_type) {
                $title = __('Enter Full Name', $this->textdomain);
            }
            return $title;
        }


        /**
         * Add Template Locations
         *
         * @param $template_locations
         * @return array
         */
        public function addTemplateLocations($template_locations)
        {
            $template_locations[] = TL_INSERT_STAFF_DIR . 'post-types/templates';
            return $template_locations;
        }
    }
}

// Register CPT
new TL_Team_Post_Type();