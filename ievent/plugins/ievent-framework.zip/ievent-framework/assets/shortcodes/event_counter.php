<?php 

	/* Event Counter  ---------------------------------------------*/
	
	add_shortcode('event_counter', 'jx_ievent_event_counter');
	
	function jx_ievent_event_counter($atts, $content = null) { 
		extract(shortcode_atts(array(

			'start_date' => 'start date',
			'end_date' => 'end date',
			'month' => 'month',
			'pretitle' => 'Type Pre Title Here',
			'title' => 'Type Title Here'
			
		), $atts)); 
		 
		
		//initial variables
		$out=''; 
		$end_date_set='';
		
		if ($end_date):
		$end_date_set='<span>-'.$end_date.'</span>';
		endif;
		
		$set_date=$start_date.' '.$month;
		
		$mod_date= str_replace(' ','-',$set_date);
		
		//function code
			
			$out ='
			<div class="jx-ievent-event-box jx-ievent-event-box-counter" data-zone="'.get_option('timezone_string').'" data-time="'.$mod_date.' '.get_post_meta( get_the_ID(), 'jx_ievent_event_time', true ).'">                                    
				
				<div class="jx-ievent-event-date">
					<div class="jx-ievent-event-day">'.$start_date.''.$end_date_set.'</div>
					<div class="jx-ievent-event-month jx-ievent-uppercase">'.$month.'</div>
				</div>
				
				<div class="jx-ievent-event-title-box">
					<div class="jx-ievent-event-pretitle">'.$pretitle.'</div>
					<div class="jx-ievent-event-title">'.$title.'</div>
					<div class="jx-ievent-event-countdown">
					<div class="jx-ievent-countdown">
						<div class="dsb-theme-wrapper countdown">
						<div class="dsb-theme">
							<div class="counter-wrapper">
								<ul>
									<li>
										<div class="days count">00</div>
										<div class="textDays count-text">'.esc_html__('Days','ievent').'</div>
									</li>
									<li>
										<div class="hours count">00</div>
										<div class="textHours count-text">'.esc_html__('Hours','ievent').'</div>
									</li>
									<li>
										<div class="minutes count">00</div>
										<div class="textmins count-text">'.esc_html__('Mins','ievent').'</div>
									</li>
									<li>
										<div class="seconds count">00</div>
										<div class="textSecs count-text">'.esc_html__('Secs','ievent').'</div>
									</li>
								</ul>
								<div class="jC-clear"></div>
							</div>
							
						</div>
					</div>                    
					</div>
				</div>
				</div>
			
			</div> 

			';
			

		//return output
		return $out;
	}
	
	

?>