// JavaScript Document
jQuery(document).ready(function() {
    'use strict';
	jQuery('.modal_fade').on('hidden.bs.modal', function () {
     jQuery('#posts-carousal').carousel('cycle');
})
jQuery('#posts-carousal').carousel();
	jQuery('.readmoreNews').click(function(){
		jQuery('#posts-carousal').carousel('pause');
										   jQuery('.carousal-post-contents').html('');
										jQuery('.modal-body').addClass('pre-loader');
										var memberDate = jQuery(this).parent('div').find('.newsform').serialize();
										jQuery.ajax({
											type: 'post',
											url: '"'+php_vars.url+'"',
											data: memberDate,
											success: function(result){
												jQuery('.carousal-post-contents').html(result);
												jQuery('.modal-body').removeClass('pre-loader');
												}
													});
										
											 });
											 });// main function ends
jQuery(document).on('click','.nextPost', function(e){
												  e.preventDefault();
												   jQuery('.carousal-post-contents').html('');
										jQuery('.modal-body').addClass('pre-loader');
	var postid = jQuery(this).attr('alt');
	var amount_posts = jQuery(this).attr('access');
	jQuery.ajax({
			type: 'post',
			url: '"'+php_vars.url+'"',
			data: 'action=200&postID='+postid+'&amount_posts='+amount_posts,
			success: function(result){
				jQuery('.carousal-post-contents').html(result);
				jQuery('.modal-body').removeClass('pre-loader');
				}
					});
	
												  });
												  		
jQuery(document).on('click','.prevPost', function(e){
												  e.preventDefault();
												   jQuery('.carousal-post-contents').html('');
										jQuery('.modal-body').addClass('pre-loader');
	var postid = jQuery(this).attr('alt');
	var amount_posts = jQuery(this).attr('access');
	jQuery.ajax({
													
			type: 'post',
			url: '"'+php_vars.url+'"',
			data: 'action=201&postID='+postid+'&amount_posts='+amount_posts,
			success: function(result){
				jQuery('.carousal-post-contents').html(result);
				jQuery('.modal-body').removeClass('pre-loader');
				}
					});
	
												  });
jQuery(function(){ jQuery(".newsCont").mCustomScrollbar({ axis:"y", theme: "dark-thin", scrollbarPosition: "outside" }); });
   
