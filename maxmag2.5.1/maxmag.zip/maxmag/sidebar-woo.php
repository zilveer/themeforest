<div id="sidebar-wrapper">
	<div class="side">
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('WooCommerce Sidebar Widget Area')): endif; ?>
	</div><!--side-->
</div><!--sidebar-wrapper-->