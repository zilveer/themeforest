/*
Theme Name: Locus - Responsive One Page Wordpress Theme
Theme URI: http://themes.iki-bir.com/locuswp3
Description: Themeforest Wordpress Theme
Version: 3.4.1
Author: elemis
Author URI: http://iki-bir.com
Tags: portfolio, design agency, news, one-page, javascript, css3, dark, light, darklight
*/

Please read the help documentation carefully.