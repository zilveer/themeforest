<?php
/*
Plugin Name: Select Instagram Feed
Description: Plugin that adds Instagram feed functionality to our theme
Author: Select Themes
Version: 1.0
*/
define('QODEF_INSTAGRAM_FEED_VERSION', '1.0');

include_once 'load.php';