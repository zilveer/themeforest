<?php $icons = array();
$icons['icomoon']['ue700'] = 'ue700';
$icons['icomoon']['ue701'] = 'ue701';
$icons['icomoon']['ue702'] = 'ue702';
$icons['icomoon']['ue703'] = 'ue703';