<?php

// Plain Hero, no images and stuff

class Wish_Newsletter {



        var $shortcode = 'wish_newsletter';

        var $title = "Newsletter";

        var $details = "Subcription";

        //var $path = "/templates/rating_hero.php";



    function __construct() {

        // We safely integrate with VC with this hook

        add_action( 'init', array( $this, 'integrateWithVC' ) );

 

        // Use this when creating a shortcode addon

        add_shortcode( $this->shortcode, array( $this, 'renderShortcode' ) );



        // Register CSS and JS

        //add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );

    }

 

    public function integrateWithVC() {

        // Check if Visual Composer is installed

        if ( ! defined( 'WPB_VC_VERSION' ) ) {

            // Display notice that Visual Compser is required

            add_action('admin_notices', array( $this, 'showVcVersionNotice' ));

            return;

        }

 

        vc_map( array(

            "name" => __($this->title, 'wish'),

            "description" => __($this->details, 'wish'),

            "base" => $this->shortcode,

            "class" => "",

            "controls" => "full",

            "link" => "http://i.imgur.com/g1U0Ri6.png",

            "icon" => plugins_url('assets/icons/23-175-eye.png', __FILE__), // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"

            "category" => __('Wish Components', 'wish'),

            //'admin_enqueue_js' => array(plugins_url('admin_assets/hero_star.js', __FILE__)), // This will load js file in the VC backend editor

            //'admin_enqueue_css' => array(plugins_url('assets/vc_extend_admin.css', __FILE__)), // This will load css file in the VC backend editor

            "params" => array(



                            array(

                                "type" => "attach_image",

                                "holder" => "div",

                                "class" => "",

                                "heading" => __("The Image", 'wish'),

                                "param_name" => "image",

                                "admin_label" => false,    

                            ),



                            array(

                                "type" => "textfield",

                                "heading" => __("Title", "wish"),

                                "param_name" => "title",

                                "admin_label" => true,

                                "description" => __("The Title", "wish"),

                                "value" => __("Newsletter Signup", 'wish'),

                                "admin_label" => true,

                            ),





                            array(

                                "type" => "textarea",

                                "holder" => "div",

                                "class" => "",

                                "heading" => __("Details For Tab 1", 'wish'),

                                "param_name" => "details",

                                "value" => __("Subscribe to our newsletter to stay upto date on upcoming events and special offers.", 'wish'),

                                "description" => __("The Details", 'wish'),

                                "admin_label" => false,

                            ),



                            /*Title*/

                            array(

                                "type" => "google_fonts",

                                "class" => "",

                                "heading" => __( "Title Text Font", "wish" ),

                                "param_name" => "title_font",

                                "value" => '', //Default Red color

                                "description" => __( "Choose Font", "wish" ),

                                "group"   => "Fonts & Colors",

                                'settings' => array(

                                     'fields'=>array(

                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

                                   )

                                )       

                            ),





                            array(

                                "type" => "wish_number",

                                "heading" => __("Title Font Size", "wish"),

                                "param_name" => "title_size",

                                "description" => __("Font size in px", "wish"),

                                "value" => __("32", 'wish'),

                                "admin_label" => true,

                                "group"       => "Fonts & Colors",

                            ),



                              array(

                                "type" => "colorpicker",

                                "class" => "",

                                "heading" => __( "Title Font Color", "wish" ),

                                "param_name" => "title_color",

                                "value" => '#e06f00',

                                "group"   => "Fonts & Colors",

                             ),



                            /*Details*/

                            array(

                                "type" => "google_fonts",

                                "class" => "",

                                "heading" => __( "Details Text Font", "wish" ),

                                "param_name" => "details_font",

                                "value" => '', //Default Red color

                                "description" => __( "Choose Font", "wish" ),

                                "group"   => "Fonts & Colors",

                                'settings' => array(

                                     'fields'=>array(

                                         'font_family'=>'Montserrat',//'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',Default font family and all available styles to fetch

                                         'font_style'=>'400:normal', // Default font style. Name:weight:style, example:"800 bold regular:800:normal"

                                   )

                                )       

                            ),





                            array(

                                "type" => "wish_number",

                                "heading" => __("Details Font Size", "wish"),

                                "param_name" => "details_size",

                                "description" => __("Font size in px", "wish"),

                                "value" => __("16", 'wish'),

                                "admin_label" => true,

                                "group"       => "Fonts & Colors",

                            ),



                              array(

                                "type" => "colorpicker",

                                "class" => "",

                                "heading" => __( "Details Font Color", "wish" ),

                                "param_name" => "details_color",

                                "value" => '#fff',

                                "group"   => "Fonts & Colors",

                             ),





                    )



        ) );

    }

    



    public function renderShortcode( $atts, $content = null ) {

      extract( shortcode_atts( array(

        'title'         => 'Newsletter Signup',

        'title_font'    => '',

        'title_size'    => '32',

        'title_color'   => '#e06f00',



        'details'       => 'Subscribe to our newsletter to stay upto date on upcoming events and special offers.',

        'details_font'  => '',

        'details_size'  => '16',

        'details_color' => '#fff',



        'image'       => 'Image'



      ), $atts ) );





    /*Title*/

    $decode_font = urldecode($title_font);

    $decode_font = explode('|', $decode_font);

    $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

    preg_match("/family=(.*):/", $font_string, $output_array);

    $title_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



    wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );



    /*Details*/

    $decode_font = urldecode($details_font);

    $decode_font = explode('|', $decode_font);

    $font_string = str_replace('font_family:', 'family=', $decode_font[0]);

    preg_match("/family=(.*):/", $font_string, $output_array);

    $details_font_family = array_key_exists(1, $output_array) ? $output_array[1] : "Montserrat";



    wp_enqueue_style('wish-googlefonts-quote' ,'//fonts.googleapis.com/css?' . $font_string );





     $img = wp_get_attachment_image_src( $image, 'full' );



          if($image == "Image"){

            $imgsrc = plugins_url('images/newsletter.jpg', __FILE__);

            $img[0] = $imgsrc;

          }



      $output = "<div class='newsletter parallax-3' style='background-image:url({$img[0]})'>

            <div class='container'>

                <div class='row'>

                    <div class='col-lg-7 animated' data-animation='fadeInUp' data-animation-delay='100'>

                        <h1 style='font-family:{$title_font_family};font-size:{$title_size}px;color:{$title_color}'>{$title}</h1>

                        <div class='description' style='font-family:{$details_font_family};font-size:{$details_size}px;color:{$details_color}'>{$details}</div>

                    </div>

                    <div class='col-lg-5'>

                        <form class='form-inline animated' data-animation='fadeInUp' data-animation-delay='400'>

                            <input type='text' class='form-control' placeholder='Enter your email address.'>

                            <button type='submit' class='btn btn-default'>Subscribe</button>

                        </form>

                    </div>

                </div>

            </div>

        </div>";

      return $output;

    }





    /*

    Show notice if your plugin is activated but Visual Composer is not

    */

    public function showVcVersionNotice() {

        $plugin_data = get_plugin_data(__FILE__);

        echo '

        <div class="updated">

          <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>

        </div>';

    }







}//end of class

?>