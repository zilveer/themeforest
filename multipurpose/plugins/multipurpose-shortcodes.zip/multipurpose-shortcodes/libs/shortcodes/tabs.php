<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// shortcode for tabs
add_shortcode('tabs', 'multipurpose_tabs_group');
add_shortcode('tab', 'multipurpose_tab');
$tabs_divs = '';
$tabs_divs_count = 0;

function multipurpose_tabs_group( $atts, $content = null ) {
    global $tabs_divs;
    $content = preg_replace('#^<\/p>|<p>$#', '', $content);
    // reset divs
    $tabs_divs = '';
    $vertical = $atts["vertical"] == "yes" ? "alt" : "";
    $output= '<div class="tabbed '.$vertical.'"><ul class="tabs">'.do_shortcode($content).'</ul>'.$tabs_divs.'</div>';
    return $output;  
}  

function multipurpose_tab($atts, $content = null) {
    $content = preg_replace('#^<\/p>|<p>$#', '', $content);
    global $tabs_divs;
    global $tabs_divs_count;
    $tabs_divs_count++;
    
    $title = '';
    $active = '';
    
    extract(shortcode_atts(array(  
        'id' => '',
        'title' => '',
        'active'=>'n' 
    ), $atts));  
    
    //if(empty($id))
        //$id = 'tab_item_'.rand(100,999);
    
    $activeClass = $active == 'y' ? 'active' :'';
    
    if(!empty($activeClass)) 
    {
            $output = '<li class="'.$activeClass.'">';
    } 
    else 
    {
        $output = '<li>';    
    }
    
    $output .= '<a href="#" ';
	if($id) {
		$output .= 'id="'.$id.'"';
	}
	$output .= '>'.$title.'</a></li>';
    $tabs_divs .= '<article id="art'.$tabs_divs_count.'" class="tab-content">'.do_shortcode($content).'</article>';
    return $output;
}