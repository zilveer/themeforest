<?php
/*
	Plugin Name: Webbu Mobile First Shortcodes
	Plugin URI: http://themeforest.net/user/Webbu
	Description: Shortcodes for Webbu Mobile Framework (WMF).
	Version: 1.2
	Author: Webbu
	Author URI: http://themeforest.net/user/Webbu
*/


//Define directories.
define("WE_THEME_URL", plugin_dir_url( __FILE__ ));
define("WE_PLUGIN_CSS_URL",WE_THEME_URL."css/");
define("WE_PLUGIN_JS_URL",WE_THEME_URL."js/");
define("WE_PLUGIN_IMAGE_URL",WE_THEME_URL."images/");

function wmf_lang_init() {
  load_plugin_textdomain( 'wmft2d', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
}
add_action('plugins_loaded', 'wmf_lang_init');
	
//Enque Styles & Scripts.
function webbushortcodes_enque()
{
	
	if (!is_admin()) {

		wp_register_script('webbushortcodes_bootstrap_js', WE_PLUGIN_JS_URL . 'bootstrap.min.js', array('jquery'), '3.0', true);
		wp_enqueue_script('webbushortcodes_bootstrap_js');
		
		wp_register_script('webbushortcodes_respond_js', WE_PLUGIN_JS_URL . 'respond.min.js', array('jquery'), '3.0', true);
		wp_enqueue_script('webbushortcodes_respond_js');
		
		wp_register_script('webbushortcodes_fluidvids_js', WE_PLUGIN_JS_URL . 'fluidvids.js', array('jquery'), '3.0', true);
		wp_enqueue_script('webbushortcodes_fluidvids_js');
			
		wp_register_style('webbushortcodes_bootstrap_css', WE_PLUGIN_CSS_URL . 'bootstrap.css', array(), '3.0', 'all');
		wp_enqueue_style('webbushortcodes_bootstrap_css'); 
		
		wp_register_style('webbushortcodes_fontawsesome_css', WE_PLUGIN_CSS_URL . 'font-awesome.min.css', array(), '3.2', 'all');
		wp_enqueue_style('webbushortcodes_fontawsesome_css'); 
		
		wp_register_style('webbushortcodes_style_css', WE_PLUGIN_CSS_URL . 'style.css', array(), '1.0', 'all');
		wp_enqueue_style('webbushortcodes_style_css'); 
	
	}
	
	
	if (is_admin()) {
		
		wp_register_style('webbushortcodes_shortcodes_css', WE_PLUGIN_CSS_URL . 'shortcodes.css', array(), '1.0', 'all');
		wp_enqueue_style('webbushortcodes_shortcodes_css'); 
		
	}
}
add_action('init', 'webbushortcodes_enque');

// Font awesome IE7 fix
function add_fontawesome_fix () {
	if (!is_admin()) {
		echo '<!--[if lt IE 7]>';
		echo '<link rel="stylesheet" href="'.WE_PLUGIN_CSS_URL.'font-awesome-ie7.min.css">';
		echo '<![endif]-->';
	}
}
add_action('wp_head', 'add_fontawesome_fix');

//Auto updater - Source: http://w-shadow.com/blog/2010/09/02/automatic-updates-for-any-plugin/
require 'plugin-updates/plugin-update-checker.php';
$ExampleUpdateChecker = new PluginUpdateChecker(
	'http://www.webbudesign.com/plugins/wmf-shortcodes/info.json',
	__FILE__, 'wmfshortcodes'
);


//Here's how you can add query arguments to the URL.
function addSecretKey($query){
	$query['secret'] = 'foo';
	return $query;
}
$ExampleUpdateChecker->addQueryArgFilter('addSecretKey');


include 'wmf-shortcodes.php'; 
include 'options-page.php'; 
?>