jQuery(document).on( 'click', '.js-composer-experience-vc-notice', function() {
	
	'use strict';
	
    jQuery.ajax({
        url: ajaxurl,
        data: {
            action: 'js_composer_experience_dismiss_notice'
        }
    })

})