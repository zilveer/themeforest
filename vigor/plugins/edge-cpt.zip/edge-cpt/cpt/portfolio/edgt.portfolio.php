<?php
include 'shortcodes/edgt.portfoliolistsc.php';
include 'shortcodes/edgt.portfolioslidersc.php';

class EdgtPortfolio {
    public function __construct() {
        add_filter('single_template', array($this, 'registerTemplate'));
    }

    public function registerTemplate($single) {
        global $post;

        if($post->post_type == 'portfolio_page') {
            if(!file_exists(get_template_directory().'/single-portfolio_page.php')) {
                return EDGE_CORE_ABS_PATH.'/portfolio/templates/single-portfolio_page.php';
            }
        }

        return $single;
    }
}

new EdgtPortfolio();