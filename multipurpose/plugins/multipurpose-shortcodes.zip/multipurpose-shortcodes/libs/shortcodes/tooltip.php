<?php
if (!defined('_MULTIPURPOSE_SHORTCODE'))
    die('Access denied');

// shortcode for tooltip
add_shortcode('tooltip', 'multipurpose_tooltip');
function multipurpose_tooltip($atts, $content=null){
    $color = ''; $title = '';
    extract(shortcode_atts(array(  
        'color' => '',
        'title'=>'title'
    ), $atts));  
    
    return '<span class="tooltip '.$color.'" title="'.$title.'">'.do_shortcode($content).'</span>';
} 